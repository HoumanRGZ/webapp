<?php
/**
 * Plugin Name: RGZ Engineering Studio
 * Plugin URI: https://houmanrgz.ir
 * Description: Combined RGZ Hydraulic Studio and RGZ Pneumatic Studio plugin using one shared production asset and unified admin parent menu. Includes the Mechanical Engineering Deck landing page, guided app tutorials and the Hydraulics/Pneumatics Learning Hub.
 * Version: 1.0.0
 * Author: Houman Rezagholizadeh
 * Author URI: https://houmanrgz.ir
 * License: GPLv2 or later
 * Text Domain: rgz-engineering-studio
 */
if (!defined('ABSPATH')) { exit; }
final class RGZ_Engineering_Studio_Plugin {
    public static function init(){ add_action('admin_menu',[__CLASS__,'admin_menu'],5); }
    public static function admin_menu(){ add_menu_page('RGZ Engineering Studio','RGZ Engineering Studio','manage_options','rgz-engineering-studio',[__CLASS__,'render_admin_page'],'dashicons-hammer',56); add_submenu_page('rgz-engineering-studio','Overview','Overview','manage_options','rgz-engineering-studio',[__CLASS__,'render_admin_page']); }
    public static function render_admin_page(){ if(!current_user_can('manage_options')) wp_die('Permission denied.'); if (class_exists('RGZ_Mechanical_Deck')) { RGZ_Mechanical_Deck::render_overview(); return; } ?><div class="wrap"><h1>RGZ Engineering Studio</h1><p>Combined management center for Hydraulic Studio and Pneumatic Studio.</p><p><a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=rgz-hydraulics')); ?>">Hydraulics</a> <a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=rgz-pneumatics')); ?>">Pneumatics</a></p><p><code>[rgz_hydraulic_studio]</code> <code>[rgz_pneumatic_studio]</code></p></div><?php }
}
final class RGZ_Hydraulic_Studio_Plugin {
    const VERSION = '1.0.0';
    const SHORTCODE = 'rgz_hydraulic_studio';
    const MAX_FILE_BYTES = 524288; // 512 KB
    const DB_OPTION = 'rgz_hydraulic_studio_db_schema';
    const DB_SCHEMA = 'custom_accounts_1';

    public static function init() {
        add_shortcode(self::SHORTCODE, [__CLASS__, 'render_shortcode']);
        add_action('init', [__CLASS__, 'maybe_install']);
        add_action('init', [__CLASS__, 'cleanup_public_source']);
        add_action('admin_menu', [__CLASS__, 'admin_menu']);

        // Custom RGZ account AJAX. These are independent from WordPress user accounts.
        foreach (['wp_ajax_', 'wp_ajax_nopriv_'] as $prefix) {
            add_action($prefix . 'rgz_hydraulic_me', [__CLASS__, 'ajax_me']);
            add_action($prefix . 'rgz_hydraulic_login', [__CLASS__, 'ajax_login']);
            add_action($prefix . 'rgz_hydraulic_register', [__CLASS__, 'ajax_register']);
            add_action($prefix . 'rgz_hydraulic_logout', [__CLASS__, 'ajax_logout']);
            add_action($prefix . 'rgz_hydraulic_save_design', [__CLASS__, 'ajax_save_design']);
            add_action($prefix . 'rgz_hydraulic_my_designs', [__CLASS__, 'ajax_my_designs']);
            add_action($prefix . 'rgz_hydraulic_get_design', [__CLASS__, 'ajax_get_design']);
        }

        add_action('wp_ajax_rgz_hydraulic_save_example', [__CLASS__, 'ajax_save_example']);
        add_action('wp_ajax_rgz_hydraulic_add_example', [__CLASS__, 'ajax_add_example']);
        add_action('wp_ajax_rgz_hydraulic_delete_custom_example', [__CLASS__, 'ajax_delete_custom_example']);
        add_action('wp_ajax_rgz_hydraulic_reset_example', [__CLASS__, 'ajax_reset_example']);

        add_action('admin_post_rgz_hydraulic_download_design', [__CLASS__, 'download_design']);
        add_action('admin_post_rgz_hydraulic_delete_design', [__CLASS__, 'delete_design']);
        add_action('admin_post_rgz_hydraulic_delete_account', [__CLASS__, 'delete_account']);
    }

    public static function accounts_table() {
        global $wpdb;
        return $wpdb->prefix . 'rgz_hydraulic_accounts';
    }

    public static function submissions_table() {
        global $wpdb;
        return $wpdb->prefix . 'rgz_hydraulic_submissions';
    }

    public static function thumb_option() {
        return 'rgz_hydraulic_design_thumbs';
    }

    // Backward-compatible alias used by older admin/download code.
    public static function table_name() {
        return self::submissions_table();
    }

    public static function maybe_install() {
        if (get_option(self::DB_OPTION) === self::DB_SCHEMA) {
            return;
        }
        self::install();
        update_option(self::DB_OPTION, self::DB_SCHEMA, false);
    }

    public static function cleanup_public_source() {
        $minified = plugin_dir_path(__FILE__) . 'assets/app.min.js';
        $source = plugin_dir_path(__FILE__) . 'assets/app.js';
        if (file_exists($minified) && file_exists($source)) {
            @unlink($source);
        }
    }

    public static function install() {
        global $wpdb;
        $accounts = self::accounts_table();
        $submissions = self::submissions_table();
        $charset_collate = $wpdb->get_charset_collate();

        $sql_accounts = "CREATE TABLE {$accounts} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(190) NOT NULL,
            email VARCHAR(190) NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            created_at DATETIME NOT NULL,
            last_login DATETIME NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY email (email),
            KEY created_at (created_at)
        ) {$charset_collate};";

        $sql_submissions = "CREATE TABLE {$submissions} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            account_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            name VARCHAR(190) NOT NULL,
            email VARCHAR(190) NOT NULL,
            file_name VARCHAR(190) NOT NULL,
            file_size INT UNSIGNED NOT NULL DEFAULT 0,
            file_data LONGBLOB NOT NULL,
            password_hint VARCHAR(255) NULL,
            design_password_enc TEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY account_id (account_id),
            KEY user_id (user_id),
            KEY email (email),
            KEY created_at (created_at)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql_accounts);
        dbDelta($sql_submissions);
    }

    private static function b64url_encode($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    private static function b64url_decode($data) {
        $pad = strlen($data) % 4;
        if ($pad) {
            $data .= str_repeat('=', 4 - $pad);
        }
        return base64_decode(strtr($data, '-_', '+/'), true);
    }

    private static function token_secret() {
        return wp_salt('auth') . '|rgz-hydraulic-account-token';
    }

    private static function create_token($account) {
        $payload = [
            'id'    => (int) $account->id,
            'email' => (string) $account->email,
            'exp'   => time() + 30 * DAY_IN_SECONDS,
            'rnd'   => bin2hex(random_bytes(8)),
        ];
        $body = self::b64url_encode(wp_json_encode($payload));
        $sig = self::b64url_encode(hash_hmac('sha256', $body, self::token_secret(), true));
        return $body . '.' . $sig;
    }

    private static function verify_token($token) {
        global $wpdb;
        $token = is_string($token) ? trim($token) : '';
        if ($token === '' || strpos($token, '.') === false) {
            return null;
        }
        [$body, $sig] = explode('.', $token, 2);
        $expected = self::b64url_encode(hash_hmac('sha256', $body, self::token_secret(), true));
        if (!hash_equals($expected, $sig)) {
            return null;
        }
        $json = self::b64url_decode($body);
        $payload = json_decode($json, true);
        if (!is_array($payload) || empty($payload['id']) || empty($payload['email']) || empty($payload['exp']) || (int) $payload['exp'] < time()) {
            return null;
        }
        $account = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::accounts_table() . ' WHERE id = %d AND email = %s', (int) $payload['id'], sanitize_email($payload['email'])));
        return $account ?: null;
    }

    private static function request_token() {
        if (isset($_POST['token'])) {
            return sanitize_text_field(wp_unslash($_POST['token']));
        }
        $header = isset($_SERVER['HTTP_AUTHORIZATION']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_AUTHORIZATION'])) : '';
        if (stripos($header, 'Bearer ') === 0) {
            return trim(substr($header, 7));
        }
        return '';
    }

    private static function auth_account() {
        return self::verify_token(self::request_token());
    }

    private static function account_payload($account) {
        if (!$account) {
            return null;
        }
        return [
            'id'    => (int) $account->id,
            'name'  => (string) $account->name,
            'email' => (string) $account->email,
        ];
    }

    private static function password_key() {
        $auth_key = defined('AUTH_KEY') ? AUTH_KEY : wp_salt('auth');
        return hash('sha256', wp_salt('auth') . '|' . $auth_key . '|rgz-hydraulic-design-password', true);
    }

    private static function encrypt_design_password($password) {
        $password = (string) $password;
        if ($password === '' || !function_exists('openssl_encrypt')) {
            return '';
        }
        $iv = random_bytes(16);
        $cipher = openssl_encrypt($password, 'AES-256-CBC', self::password_key(), OPENSSL_RAW_DATA, $iv);
        if ($cipher === false) {
            return '';
        }
        return base64_encode($iv . $cipher);
    }

    private static function decrypt_design_password($encoded) {
        $encoded = (string) $encoded;
        if ($encoded === '' || !function_exists('openssl_decrypt')) {
            return '';
        }
        $raw = base64_decode($encoded, true);
        if ($raw === false || strlen($raw) <= 16) {
            return '';
        }
        $iv = substr($raw, 0, 16);
        $cipher = substr($raw, 16);
        $plain = openssl_decrypt($cipher, 'AES-256-CBC', self::password_key(), OPENSSL_RAW_DATA, $iv);
        return $plain === false ? '' : $plain;
    }

    public static function studio_url() {
        $pages = get_posts([
            'post_type' => 'page',
            'post_status' => 'publish',
            'posts_per_page' => 20,
            's' => '[rgz_hydraulic_studio',
        ]);
        foreach ($pages as $page) {
            if (has_shortcode($page->post_content, self::SHORTCODE)) {
                return get_permalink($page);
            }
        }
        return home_url('/hydraulic-studio/');
    }

    public static function render_shortcode($atts = []) {
        $plugin_url = plugin_dir_url(__FILE__);

        $css_file = plugin_dir_path(__FILE__) . 'assets/app.css';
        $js_file = plugin_dir_path(__FILE__) . 'assets/app.min.js';
        $js_asset = 'assets/app.min.js';
        if (!file_exists($js_file)) {
            $js_file = plugin_dir_path(__FILE__) . 'assets/app.js';
            $js_asset = 'assets/app.js';
        }
        $css_version = self::VERSION . '-' . (file_exists($css_file) ? filemtime($css_file) : time());
        $js_version = self::VERSION . '-' . (file_exists($js_file) ? filemtime($js_file) : time());

        wp_enqueue_style('rgz-engineering-studio', $plugin_url . 'assets/app.css', [], $css_version);
        wp_enqueue_script('rgz-engineering-studio', $plugin_url . $js_asset, [], $js_version, true);

        wp_localize_script('rgz-engineering-studio', 'RGZHydraulicStudioConfig', [
            'siteUrl'        => home_url('/'),
            'websiteLabel'   => 'https://houmanrgz.ir',
            'assetBase'      => $plugin_url . 'assets/',
            'version'        => self::VERSION,
            'ajaxUrl'        => admin_url('admin-ajax.php'),
            'authNonce'      => wp_create_nonce('rgz_hydraulic_public'),
            'saveNonce'      => wp_create_nonce('rgz_hydraulic_public'),
            'maxUploadBytes'    => self::MAX_FILE_BYTES,
            'user'              => null,
            'canManageExamples' => current_user_can('manage_options'),
            'exampleOverrides'  => get_option('rgz_hydraulic_example_overrides', []),
            'customExamples'    => get_option('rgz_hydraulic_custom_examples', []),
            'tutorial'          => class_exists('RGZ_Mechanical_Deck') ? RGZ_Mechanical_Deck::tour_enabled('hydraulic') : true,
            'tourText'          => class_exists('RGZ_Mechanical_Deck') ? RGZ_Mechanical_Deck::tour_text('hydraulic') : '',
        ]);

        return '<div id="rgz-hydraulic-studio" class="rgz-hydraulic-studio-root" data-rgz-version="' . esc_attr(self::VERSION) . '"></div>';
    }

    public static function ajax_me() {
        $account = self::auth_account();
        wp_send_json_success(['user' => self::account_payload($account), 'token' => $account ? self::request_token() : '']);
    }

    public static function ajax_register() {
        global $wpdb;
        $name = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
        $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
        $password = isset($_POST['password']) ? (string) wp_unslash($_POST['password']) : '';

        if ($name === '' || !is_email($email) || strlen($password) < 6) {
            wp_send_json_error(['message' => 'Name, valid email, and password with at least 6 characters are required.'], 400);
        }

        $exists = $wpdb->get_var($wpdb->prepare('SELECT id FROM ' . self::accounts_table() . ' WHERE email = %s', $email));
        if ($exists) {
            wp_send_json_error(['message' => 'This email is already registered. Please sign in.'], 409);
        }

        $inserted = $wpdb->insert(
            self::accounts_table(),
            [
                'name'          => $name,
                'email'         => $email,
                'password_hash' => wp_hash_password($password),
                'created_at'    => current_time('mysql'),
                'last_login'    => current_time('mysql'),
            ],
            ['%s', '%s', '%s', '%s', '%s']
        );

        if (!$inserted) {
            wp_send_json_error(['message' => 'Could not create the RGZ Hydraulics account.'], 500);
        }

        $account = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::accounts_table() . ' WHERE id = %d', (int) $wpdb->insert_id));
        $token = self::create_token($account);
        wp_send_json_success(['user' => self::account_payload($account), 'token' => $token]);
    }

    public static function ajax_login() {
        global $wpdb;
        $login = isset($_POST['login']) ? sanitize_text_field(wp_unslash($_POST['login'])) : '';
        $password = isset($_POST['password']) ? (string) wp_unslash($_POST['password']) : '';
        if ($login === '' || $password === '') {
            wp_send_json_error(['message' => 'Email and password are required.'], 400);
        }
        $email = is_email($login) ? sanitize_email($login) : '';
        if (!$email) {
            wp_send_json_error(['message' => 'Please sign in with your email address.'], 400);
        }
        $account = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::accounts_table() . ' WHERE email = %s', $email));
        if (!$account || !wp_check_password($password, $account->password_hash)) {
            wp_send_json_error(['message' => 'Sign in failed. Please check your email and password.'], 401);
        }
        $wpdb->update(self::accounts_table(), ['last_login' => current_time('mysql')], ['id' => (int) $account->id], ['%s'], ['%d']);
        $token = self::create_token($account);
        wp_send_json_success(['user' => self::account_payload($account), 'token' => $token]);
    }

    public static function ajax_logout() {
        wp_send_json_success(['user' => null, 'token' => '']);
    }

    public static function ajax_save_design() {
        $account = self::auth_account();
        if (!$account) {
            wp_send_json_error(['message' => 'Please sign in before saving designs.', 'auth_required' => true], 401);
        }

        $file_name = isset($_POST['file_name']) ? sanitize_file_name(wp_unslash($_POST['file_name'])) : 'hydraulic-project.rgz';
        $password_hint = isset($_POST['password_hint']) ? sanitize_text_field(wp_unslash($_POST['password_hint'])) : '';
        $design_password = isset($_POST['design_password']) ? (string) wp_unslash($_POST['design_password']) : '';
        $file_base64 = isset($_POST['file_base64']) ? wp_unslash($_POST['file_base64']) : '';

        $file_base64 = preg_replace('/^data:.*?;base64,/', '', $file_base64);
        $binary = base64_decode($file_base64, true);
        if ($binary === false || strlen($binary) === 0) {
            wp_send_json_error(['message' => 'Invalid RGZ file payload.'], 400);
        }
        if (strlen($binary) > self::MAX_FILE_BYTES) {
            wp_send_json_error(['message' => 'The design file is larger than 512 KB and was not stored.'], 413);
        }

        global $wpdb;
        $inserted = $wpdb->insert(
            self::submissions_table(),
            [
                'account_id'          => (int) $account->id,
                'user_id'             => 0,
                'name'                => $account->name,
                'email'               => $account->email,
                'file_name'           => $file_name ?: 'hydraulic-project.rgz',
                'file_size'           => strlen($binary),
                'file_data'           => $binary,
                'password_hint'       => $password_hint,
                'design_password_enc' => self::encrypt_design_password($design_password),
                'created_at'          => current_time('mysql'),
            ],
            ['%d', '%d', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s']
        );

        if (!$inserted) {
            wp_send_json_error(['message' => 'Could not store the design.'], 500);
        }

        /* Blueprint thumbnail geometry for the Mechanical Deck "My designs"
           overview — a tiny JSON geometry model (positions + line endpoints
           only, no circuit data), sent by the app along with the design. */
        $thumb = isset($_POST['thumb']) ? (string) wp_unslash($_POST['thumb']) : '';
        if ('' !== $thumb && strlen($thumb) <= 60000) {
            $thumb_decoded = json_decode($thumb, true);
            if (is_array($thumb_decoded) && isset($thumb_decoded['comps']) && isset($thumb_decoded['conns'])) {
                $map = get_option(self::thumb_option(), []);
                if (!is_array($map)) { $map = []; }
                $map[(int) $wpdb->insert_id] = wp_json_encode($thumb_decoded);
                while (count($map) > 200) { array_shift($map); }
                update_option(self::thumb_option(), $map, false);
            }
        }

        wp_send_json_success(['message' => 'Design stored in your RGZ Hydraulics account.', 'id' => (int) $wpdb->insert_id]);
    }

    public static function ajax_my_designs() {
        $account = self::auth_account();
        if (!$account) {
            wp_send_json_error(['message' => 'Please sign in first.', 'auth_required' => true], 401);
        }
        global $wpdb;
        $rows = $wpdb->get_results($wpdb->prepare(
            'SELECT id, file_name, file_size, password_hint, created_at FROM ' . self::submissions_table() . ' WHERE account_id = %d ORDER BY created_at DESC LIMIT 100',
            (int) $account->id
        ));
        wp_send_json_success(['designs' => $rows]);
    }

    public static function ajax_get_design() {
        $account = self::auth_account();
        if (!$account) {
            wp_send_json_error(['message' => 'Please sign in first.', 'auth_required' => true], 401);
        }
        $id = isset($_POST['id']) ? absint($_POST['id']) : 0;
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare(
            'SELECT id, file_name, file_size, file_data, created_at FROM ' . self::submissions_table() . ' WHERE id = %d AND account_id = %d',
            $id,
            (int) $account->id
        ));
        if (!$row) {
            wp_send_json_error(['message' => 'Design not found.'], 404);
        }
        wp_send_json_success([
            'design' => [
                'id'          => (int) $row->id,
                'file_name'   => $row->file_name,
                'file_size'   => (int) $row->file_size,
                'created_at'  => $row->created_at,
                'file_base64' => base64_encode($row->file_data),
            ],
        ]);
    }

    public static function ajax_save_example() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Only the site owner can save pre-designed circuits.'], 403);
        }
        $index = isset($_POST['index']) ? absint($_POST['index']) : 0;
        $project_json = isset($_POST['project_json']) ? wp_unslash($_POST['project_json']) : '';
        if ($index < 0 || $index > 44 || $project_json === '') {
            wp_send_json_error(['message' => 'Invalid pre-designed circuit data.'], 400);
        }
        $project = json_decode($project_json, true);
        if (!is_array($project) || empty($project['components']) || !isset($project['connections'])) {
            wp_send_json_error(['message' => 'The current drawing is not a valid RGZ project.'], 400);
        }
        if (strlen($project_json) > 1200000) {
            wp_send_json_error(['message' => 'This template is too large to store as a pre-designed circuit.'], 413);
        }
        $overrides = get_option('rgz_hydraulic_example_overrides', []);
        if (!is_array($overrides)) {
            $overrides = [];
        }
        $project['savedAsPredesignedAt'] = current_time('mysql');
        $overrides[(string) $index] = $project;
        update_option('rgz_hydraulic_example_overrides', $overrides, false);
        wp_send_json_success(['message' => 'Pre-designed circuit saved for all users.', 'index' => $index, 'project' => $project]);
    }

    public static function ajax_add_example() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Only the site owner can add pre-designed circuits.'], 403);
        }
        $level = isset($_POST['level']) ? sanitize_text_field(wp_unslash($_POST['level'])) : 'Owner custom circuits';
        $name = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
        $project_json = isset($_POST['project_json']) ? wp_unslash($_POST['project_json']) : '';
        if ($name === '' || $project_json === '') {
            wp_send_json_error(['message' => 'Circuit title and project data are required.'], 400);
        }
        $project = json_decode($project_json, true);
        if (!is_array($project) || !isset($project['components']) || !isset($project['connections'])) {
            wp_send_json_error(['message' => 'The current drawing is not a valid RGZ project.'], 400);
        }
        if (strlen($project_json) > 1200000) {
            wp_send_json_error(['message' => 'This circuit is too large to store as a pre-designed circuit.'], 413);
        }
        $items = get_option('rgz_hydraulic_custom_examples', []);
        if (!is_array($items)) {
            $items = [];
        }
        $item = [
            'id' => 'custom-' . time() . '-' . wp_generate_password(6, false, false),
            'level' => $level ?: 'Owner custom circuits',
            'name' => $name,
            'project' => $project,
            'created_at' => current_time('mysql'),
        ];
        $items[] = $item;
        update_option('rgz_hydraulic_custom_examples', $items, false);
        wp_send_json_success(['message' => 'Circuit added to the pre-designed library.', 'item' => $item]);
    }

    public static function ajax_delete_custom_example() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Only the site owner can delete custom pre-designed circuits.'], 403);
        }
        $id = isset($_POST['id']) ? sanitize_text_field(wp_unslash($_POST['id'])) : '';
        if ($id === '') {
            wp_send_json_error(['message' => 'Missing custom circuit id.'], 400);
        }
        $items = get_option('rgz_hydraulic_custom_examples', []);
        if (!is_array($items)) {
            $items = [];
        }
        $before = count($items);
        $items = array_values(array_filter($items, static function($item) use ($id) {
            return !is_array($item) || (($item['id'] ?? '') !== $id);
        }));
        update_option('rgz_hydraulic_custom_examples', $items, false);
        wp_send_json_success(['message' => $before === count($items) ? 'No matching custom circuit found.' : 'Custom circuit deleted.', 'id' => $id]);
    }

    public static function ajax_reset_example() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Only the site owner can reset pre-designed circuits.'], 403);
        }
        $index = isset($_POST['index']) ? absint($_POST['index']) : 0;
        $overrides = get_option('rgz_hydraulic_example_overrides', []);
        if (!is_array($overrides)) {
            $overrides = [];
        }
        unset($overrides[(string) $index]);
        update_option('rgz_hydraulic_example_overrides', $overrides, false);
        wp_send_json_success(['message' => 'Pre-designed circuit reset to the built-in version.', 'index' => $index]);
    }

    public static function admin_menu() {
        add_submenu_page('rgz-engineering-studio','Hydraulics','Hydraulics','manage_options','rgz-hydraulics',[__CLASS__, 'render_admin_page']);
    }

    public static function render_admin_page() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to access this page.', 'rgz-hydraulic-studio'));
        }
        global $wpdb;
        $accounts_table = self::accounts_table();
        $submissions_table = self::submissions_table();

        $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
        $selected_account_id = isset($_GET['account_id']) ? absint($_GET['account_id']) : 0;
        $design_search = isset($_GET['design_s']) ? sanitize_text_field(wp_unslash($_GET['design_s'])) : '';

        $total_accounts = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$accounts_table}");
        $total_designs = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$submissions_table}");
        $total_storage = (int) $wpdb->get_var("SELECT COALESCE(SUM(file_size),0) FROM {$submissions_table}");
        $latest_design = $wpdb->get_var("SELECT MAX(created_at) FROM {$submissions_table}");

        $account_where = '1=1';
        $account_args = [];
        if ($search !== '') {
            $like = '%' . $wpdb->esc_like($search) . '%';
            $account_where .= ' AND (a.name LIKE %s OR a.email LIKE %s)';
            $account_args[] = $like;
            $account_args[] = $like;
        }
        $account_sql = "SELECT a.*, COUNT(s.id) AS design_count, COALESCE(SUM(s.file_size),0) AS storage_bytes, MAX(s.created_at) AS last_design
            FROM {$accounts_table} a
            LEFT JOIN {$submissions_table} s ON s.account_id = a.id
            WHERE {$account_where}
            GROUP BY a.id
            ORDER BY last_design DESC, a.created_at DESC
            LIMIT 250";
        $accounts = $account_args ? $wpdb->get_results($wpdb->prepare($account_sql, $account_args)) : $wpdb->get_results($account_sql);

        $selected_account = null;
        if ($selected_account_id) {
            $selected_account = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$accounts_table} WHERE id = %d", $selected_account_id));
        }

        $design_where = '1=1';
        $design_args = [];
        if ($selected_account_id) {
            $design_where .= ' AND account_id = %d';
            $design_args[] = $selected_account_id;
        }
        if ($design_search !== '') {
            $like = '%' . $wpdb->esc_like($design_search) . '%';
            $design_where .= ' AND (file_name LIKE %s OR name LIKE %s OR email LIKE %s OR password_hint LIKE %s)';
            $design_args = array_merge($design_args, [$like, $like, $like, $like]);
        }
        $design_sql = "SELECT id, account_id, user_id, name, email, file_name, file_size, password_hint, design_password_enc, created_at
            FROM {$submissions_table}
            WHERE {$design_where}
            ORDER BY created_at DESC
            LIMIT 300";
        $rows = $design_args ? $wpdb->get_results($wpdb->prepare($design_sql, $design_args)) : $wpdb->get_results($design_sql);
        ?>
        <div class="wrap rgz-admin-wrap">
            <style>
                .rgz-admin-wrap{--rgz-bg:#0f172a;--rgz-card:#fff;--rgz-border:#e5e7eb;--rgz-muted:#64748b;--rgz-accent:#e8793c;--rgz-blue:#2563eb;}
                .rgz-admin-hero{background:linear-gradient(135deg,#0f172a,#1e293b);color:#fff;border-radius:18px;padding:22px 24px;margin:18px 0;display:flex;justify-content:space-between;gap:18px;align-items:center;box-shadow:0 16px 40px rgba(15,23,42,.18)}
                .rgz-admin-hero h1{color:#fff;margin:0 0 6px;font-size:28px;font-weight:800}.rgz-admin-hero p{margin:0;color:#cbd5e1;max-width:780px}.rgz-admin-hero .button{border-color:rgba(255,255,255,.25);color:#fff;background:rgba(255,255,255,.08)}
                .rgz-stats{display:grid;grid-template-columns:repeat(4,minmax(160px,1fr));gap:14px;margin:16px 0}.rgz-stat{background:#fff;border:1px solid var(--rgz-border);border-radius:16px;padding:16px;box-shadow:0 8px 24px rgba(15,23,42,.05)}.rgz-stat span{display:block;color:var(--rgz-muted);font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.06em}.rgz-stat strong{display:block;margin-top:8px;font-size:24px;color:#0f172a}
                .rgz-admin-grid{display:grid;grid-template-columns:minmax(280px,360px) minmax(0,1fr);gap:16px;align-items:start}.rgz-panel-admin{background:#fff;border:1px solid var(--rgz-border);border-radius:18px;box-shadow:0 8px 24px rgba(15,23,42,.05);overflow:hidden}.rgz-panel-head{padding:15px 16px;border-bottom:1px solid var(--rgz-border);display:flex;justify-content:space-between;gap:10px;align-items:center}.rgz-panel-head h2{font-size:15px;margin:0;color:#0f172a}.rgz-panel-body{padding:14px 16px}.rgz-search-form{display:grid;gap:8px}.rgz-search-form input{width:100%;border-radius:10px;border:1px solid #cbd5e1;padding:8px 10px}.rgz-account-list{display:grid;gap:8px;max-height:620px;overflow:auto;padding:12px}.rgz-account-card{display:block;text-decoration:none;border:1px solid #e5e7eb;border-radius:14px;padding:12px;background:#fff;color:#0f172a;transition:.15s}.rgz-account-card:hover{border-color:#fb923c;box-shadow:0 8px 24px rgba(232,121,60,.12)}.rgz-account-card.active{border-color:#e8793c;background:#fff7ed}.rgz-account-card strong{display:block;font-size:14px;color:#0f172a}.rgz-account-card small{display:block;color:#64748b;overflow-wrap:anywhere;margin-top:3px}.rgz-account-meta{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}.rgz-pill{display:inline-flex;border-radius:999px;background:#f1f5f9;color:#334155;font-size:11px;font-weight:700;padding:4px 8px}.rgz-pill.orange{background:#ffedd5;color:#9a3412}.rgz-pill.blue{background:#dbeafe;color:#1d4ed8}.rgz-selected-account{background:#f8fafc;border:1px solid #e2e8f0;border-radius:14px;padding:12px;margin-bottom:12px}.rgz-selected-account h3{margin:0 0 4px}.rgz-actions-row{display:flex;gap:8px;flex-wrap:wrap}.rgz-table-wrap{overflow:auto}.rgz-modern-table{width:100%;border-collapse:separate;border-spacing:0 8px}.rgz-modern-table th{text-align:left;color:#64748b;font-size:11px;text-transform:uppercase;letter-spacing:.06em;padding:0 10px}.rgz-modern-table td{background:#fff;border-top:1px solid #e5e7eb;border-bottom:1px solid #e5e7eb;padding:12px 10px;vertical-align:top}.rgz-modern-table td:first-child{border-left:1px solid #e5e7eb;border-radius:12px 0 0 12px}.rgz-modern-table td:last-child{border-right:1px solid #e5e7eb;border-radius:0 12px 12px 0}.rgz-file-name{font-weight:800;color:#0f172a;overflow-wrap:anywhere}.rgz-muted{color:#64748b;font-size:12px}.rgz-password-box details{max-width:220px}.rgz-password-box code{display:block;margin-top:6px;white-space:normal;overflow-wrap:anywhere;background:#f8fafc;border:1px solid #e2e8f0;padding:6px;border-radius:8px}.rgz-empty{padding:28px;text-align:center;color:#64748b;background:#f8fafc;border-radius:14px}.rgz-filter-bar{display:grid;grid-template-columns:minmax(220px,1fr) auto auto;gap:8px;align-items:center}.rgz-filter-bar input{border-radius:10px;border:1px solid #cbd5e1;padding:8px 10px}.rgz-danger-link{color:#b91c1c!important;border-color:#fecaca!important;background:#fff1f2!important}
                @media(max-width:1100px){.rgz-stats{grid-template-columns:repeat(2,1fr)}.rgz-admin-grid{grid-template-columns:1fr}.rgz-filter-bar{grid-template-columns:1fr}}
            </style>

            <div class="rgz-admin-hero">
                <div>
                    <h1>RGZ Hydraulics</h1>
                    <p>Modern account-based management for Hydraulic Studio students, encrypted RGZ files, support passwords, search, filtering and per-account design history.</p>
                </div>
                <a class="button" href="<?php echo esc_url(self::studio_url()); ?>" target="_blank">Open Studio</a>
            </div>

            <div class="rgz-stats">
                <div class="rgz-stat"><span>Accounts</span><strong><?php echo esc_html((string) $total_accounts); ?></strong></div>
                <div class="rgz-stat"><span>Stored designs</span><strong><?php echo esc_html((string) $total_designs); ?></strong></div>
                <div class="rgz-stat"><span>Total storage</span><strong><?php echo esc_html(size_format($total_storage)); ?></strong></div>
                <div class="rgz-stat"><span>Latest design</span><strong style="font-size:14px"><?php echo esc_html($latest_design ?: '—'); ?></strong></div>
            </div>

            <div class="rgz-admin-grid">
                <div class="rgz-panel-admin">
                    <div class="rgz-panel-head"><h2>Accounts</h2><a class="button button-small" href="<?php echo esc_url(admin_url('admin.php?page=rgz-hydraulics')); ?>">All</a></div>
                    <div class="rgz-panel-body">
                        <form method="get" class="rgz-search-form">
                            <input type="hidden" name="page" value="rgz-hydraulics" />
                            <input type="search" name="s" value="<?php echo esc_attr($search); ?>" placeholder="Search name or email…" />
                            <button class="button button-primary" type="submit">Search accounts</button>
                        </form>
                    </div>
                    <div class="rgz-account-list">
                        <?php if (empty($accounts)) : ?>
                            <div class="rgz-empty">No accounts found.</div>
                        <?php else : ?>
                            <?php foreach ($accounts as $account) :
                                $url = add_query_arg(['page' => 'rgz-hydraulics', 'account_id' => (int) $account->id, 's' => $search], admin_url('admin.php'));
                                $delete_account_url = wp_nonce_url(admin_url('admin-post.php?action=rgz_hydraulic_delete_account&id=' . (int) $account->id), 'rgz_delete_account_' . (int) $account->id);
                                ?>
                                <a class="rgz-account-card <?php echo $selected_account_id === (int) $account->id ? 'active' : ''; ?>" href="<?php echo esc_url($url); ?>">
                                    <strong><?php echo esc_html($account->name); ?></strong>
                                    <small><?php echo esc_html($account->email); ?></small>
                                    <span class="rgz-account-meta">
                                        <span class="rgz-pill orange"><?php echo esc_html((string) (int) $account->design_count); ?> designs</span>
                                        <span class="rgz-pill blue"><?php echo esc_html(size_format((int) $account->storage_bytes)); ?></span>
                                    </span>
                                    <small>Last design: <?php echo esc_html($account->last_design ?: '—'); ?></small>
                                </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="rgz-panel-admin">
                    <div class="rgz-panel-head">
                        <h2><?php echo $selected_account ? 'Designs for ' . esc_html($selected_account->name) : 'Stored Designs'; ?></h2>
                        <?php if ($selected_account) :
                            $delete_account_url = wp_nonce_url(admin_url('admin-post.php?action=rgz_hydraulic_delete_account&id=' . (int) $selected_account->id), 'rgz_delete_account_' . (int) $selected_account->id);
                            ?>
                            <div class="rgz-actions-row"><a class="button button-small" href="mailto:<?php echo esc_attr($selected_account->email); ?>">Email</a><a class="button button-small rgz-danger-link" href="<?php echo esc_url($delete_account_url); ?>" onclick="return confirm('Delete this RGZ account and all its stored designs?');">Delete account</a></div>
                        <?php endif; ?>
                    </div>
                    <div class="rgz-panel-body">
                        <?php if ($selected_account) : ?>
                            <div class="rgz-selected-account">
                                <h3><?php echo esc_html($selected_account->name); ?></h3>
                                <div class="rgz-muted"><?php echo esc_html($selected_account->email); ?> · Created: <?php echo esc_html($selected_account->created_at); ?> · Last login: <?php echo esc_html($selected_account->last_login ?: '—'); ?></div>
                            </div>
                        <?php endif; ?>
                        <form method="get" class="rgz-filter-bar">
                            <input type="hidden" name="page" value="rgz-hydraulics" />
                            <?php if ($selected_account_id) : ?><input type="hidden" name="account_id" value="<?php echo esc_attr((string) $selected_account_id); ?>" /><?php endif; ?>
                            <input type="search" name="design_s" value="<?php echo esc_attr($design_search); ?>" placeholder="Search files, emails, names or hints…" />
                            <button class="button button-primary" type="submit">Filter designs</button>
                            <a class="button" href="<?php echo esc_url($selected_account_id ? add_query_arg(['page' => 'rgz-hydraulics', 'account_id' => $selected_account_id], admin_url('admin.php')) : admin_url('admin.php?page=rgz-hydraulics')); ?>">Reset</a>
                        </form>
                    </div>
                    <div class="rgz-panel-body rgz-table-wrap">
                        <?php if (empty($rows)) : ?>
                            <div class="rgz-empty">No designs found for this filter.</div>
                        <?php else : ?>
                            <table class="rgz-modern-table">
                                <thead><tr><th>File</th><th>Student</th><th>Size</th><th>Password</th><th>Date</th><th>Actions</th></tr></thead>
                                <tbody>
                                <?php foreach ($rows as $row) :
                                    $download_url = wp_nonce_url(admin_url('admin-post.php?action=rgz_hydraulic_download_design&id=' . (int) $row->id), 'rgz_download_' . (int) $row->id);
                                    $delete_url = wp_nonce_url(admin_url('admin-post.php?action=rgz_hydraulic_delete_design&id=' . (int) $row->id), 'rgz_delete_' . (int) $row->id);
                                    $account_url = $row->account_id ? add_query_arg(['page' => 'rgz-hydraulics', 'account_id' => (int) $row->account_id], admin_url('admin.php')) : '';
                                    $design_password = self::decrypt_design_password($row->design_password_enc);
                                    ?>
                                    <tr>
                                        <td><div class="rgz-file-name"><?php echo esc_html($row->file_name); ?></div><div class="rgz-muted">ID #<?php echo esc_html((string) $row->id); ?> · Account <?php echo $account_url ? '<a href="' . esc_url($account_url) . '">#' . esc_html((string) $row->account_id) . '</a>' : '—'; ?></div></td>
                                        <td><strong><?php echo esc_html($row->name); ?></strong><div class="rgz-muted"><a href="mailto:<?php echo esc_attr($row->email); ?>"><?php echo esc_html($row->email); ?></a></div></td>
                                        <td><?php echo esc_html(size_format((int) $row->file_size)); ?></td>
                                        <td class="rgz-password-box"><div class="rgz-muted">Hint: <?php echo esc_html($row->password_hint ?: '—'); ?></div><?php if ($design_password !== '') : ?><details><summary>Reveal password</summary><code><?php echo esc_html($design_password); ?></code></details><?php else : ?>—<?php endif; ?></td>
                                        <td><?php echo esc_html($row->created_at); ?></td>
                                        <td><div class="rgz-actions-row"><a class="button button-small" href="<?php echo esc_url($download_url); ?>">Download</a><a class="button button-small rgz-danger-link" href="<?php echo esc_url($delete_url); ?>" onclick="return confirm('Delete this stored design?');">Delete</a></div></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    public static function download_design() {
        if (!current_user_can('manage_options')) {
            wp_die('Permission denied.');
        }
        $id = isset($_GET['id']) ? absint($_GET['id']) : 0;
        check_admin_referer('rgz_download_' . $id);
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare('SELECT file_name, file_data, file_size FROM ' . self::submissions_table() . ' WHERE id = %d', $id));
        if (!$row) {
            wp_die('Design not found.');
        }
        nocache_headers();
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . sanitize_file_name($row->file_name ?: 'hydraulic-project.rgz') . '"');
        header('Content-Length: ' . (int) $row->file_size);
        echo $row->file_data; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        exit;
    }

    public static function delete_design() {
        if (!current_user_can('manage_options')) {
            wp_die('Permission denied.');
        }
        $id = isset($_GET['id']) ? absint($_GET['id']) : 0;
        check_admin_referer('rgz_delete_' . $id);
        global $wpdb;
        $wpdb->delete(self::submissions_table(), ['id' => $id], ['%d']);
        wp_safe_redirect(admin_url('admin.php?page=rgz-hydraulics'));
        exit;
    }

    public static function delete_account() {
        if (!current_user_can('manage_options')) {
            wp_die('Permission denied.');
        }
        $id = isset($_GET['id']) ? absint($_GET['id']) : 0;
        check_admin_referer('rgz_delete_account_' . $id);
        global $wpdb;
        $wpdb->delete(self::submissions_table(), ['account_id' => $id], ['%d']);
        $wpdb->delete(self::accounts_table(), ['id' => $id], ['%d']);
        wp_safe_redirect(admin_url('admin.php?page=rgz-hydraulics'));
        exit;
    }
}

final class RGZ_Pneumatic_Studio_Plugin {
    const VERSION = '1.0.0';
    const SHORTCODE = 'rgz_pneumatic_studio';
    const MAX_FILE_BYTES = 524288; // 512 KB
    const DB_OPTION = 'rgz_pneumatic_studio_db_schema';
    const DB_SCHEMA = 'custom_accounts_1';

    public static function init() {
        add_shortcode(self::SHORTCODE, [__CLASS__, 'render_shortcode']);
        add_action('init', [__CLASS__, 'maybe_install']);
        add_action('init', [__CLASS__, 'cleanup_public_source']);
        add_action('admin_menu', [__CLASS__, 'admin_menu']);

        // Custom RGZ account AJAX. These are independent from WordPress user accounts.
        foreach (['wp_ajax_', 'wp_ajax_nopriv_'] as $prefix) {
            add_action($prefix . 'rgz_pneumatic_me', [__CLASS__, 'ajax_me']);
            add_action($prefix . 'rgz_pneumatic_login', [__CLASS__, 'ajax_login']);
            add_action($prefix . 'rgz_pneumatic_register', [__CLASS__, 'ajax_register']);
            add_action($prefix . 'rgz_pneumatic_logout', [__CLASS__, 'ajax_logout']);
            add_action($prefix . 'rgz_pneumatic_save_design', [__CLASS__, 'ajax_save_design']);
            add_action($prefix . 'rgz_pneumatic_my_designs', [__CLASS__, 'ajax_my_designs']);
            add_action($prefix . 'rgz_pneumatic_get_design', [__CLASS__, 'ajax_get_design']);
        }

        add_action('wp_ajax_rgz_pneumatic_save_example', [__CLASS__, 'ajax_save_example']);
        add_action('wp_ajax_rgz_pneumatic_add_example', [__CLASS__, 'ajax_add_example']);
        add_action('wp_ajax_rgz_pneumatic_delete_custom_example', [__CLASS__, 'ajax_delete_custom_example']);
        add_action('wp_ajax_rgz_pneumatic_reset_example', [__CLASS__, 'ajax_reset_example']);

        add_action('admin_post_rgz_pneumatic_download_design', [__CLASS__, 'download_design']);
        add_action('admin_post_rgz_pneumatic_delete_design', [__CLASS__, 'delete_design']);
        add_action('admin_post_rgz_pneumatic_delete_account', [__CLASS__, 'delete_account']);
    }

    public static function accounts_table() {
        global $wpdb;
        return $wpdb->prefix . 'rgz_pneumatic_accounts';
    }

    public static function submissions_table() {
        global $wpdb;
        return $wpdb->prefix . 'rgz_pneumatic_submissions';
    }

    public static function thumb_option() {
        return 'rgz_pneumatic_design_thumbs';
    }

    // Backward-compatible alias used by older admin/download code.
    public static function table_name() {
        return self::submissions_table();
    }

    public static function maybe_install() {
        if (get_option(self::DB_OPTION) === self::DB_SCHEMA) {
            return;
        }
        self::install();
        update_option(self::DB_OPTION, self::DB_SCHEMA, false);
    }

    public static function cleanup_public_source() {
        $minified = plugin_dir_path(__FILE__) . 'assets/app.min.js';
        $source = plugin_dir_path(__FILE__) . 'assets/app.js';
        if (file_exists($minified) && file_exists($source)) {
            @unlink($source);
        }
    }

    public static function install() {
        global $wpdb;
        $accounts = self::accounts_table();
        $submissions = self::submissions_table();
        $charset_collate = $wpdb->get_charset_collate();

        $sql_accounts = "CREATE TABLE {$accounts} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(190) NOT NULL,
            email VARCHAR(190) NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            created_at DATETIME NOT NULL,
            last_login DATETIME NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY email (email),
            KEY created_at (created_at)
        ) {$charset_collate};";

        $sql_submissions = "CREATE TABLE {$submissions} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            account_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            name VARCHAR(190) NOT NULL,
            email VARCHAR(190) NOT NULL,
            file_name VARCHAR(190) NOT NULL,
            file_size INT UNSIGNED NOT NULL DEFAULT 0,
            file_data LONGBLOB NOT NULL,
            password_hint VARCHAR(255) NULL,
            design_password_enc TEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY account_id (account_id),
            KEY user_id (user_id),
            KEY email (email),
            KEY created_at (created_at)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql_accounts);
        dbDelta($sql_submissions);
    }

    private static function b64url_encode($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    private static function b64url_decode($data) {
        $pad = strlen($data) % 4;
        if ($pad) {
            $data .= str_repeat('=', 4 - $pad);
        }
        return base64_decode(strtr($data, '-_', '+/'), true);
    }

    private static function token_secret() {
        return wp_salt('auth') . '|rgz-pneumatic-account-token';
    }

    private static function create_token($account) {
        $payload = [
            'id'    => (int) $account->id,
            'email' => (string) $account->email,
            'exp'   => time() + 30 * DAY_IN_SECONDS,
            'rnd'   => bin2hex(random_bytes(8)),
        ];
        $body = self::b64url_encode(wp_json_encode($payload));
        $sig = self::b64url_encode(hash_hmac('sha256', $body, self::token_secret(), true));
        return $body . '.' . $sig;
    }

    private static function verify_token($token) {
        global $wpdb;
        $token = is_string($token) ? trim($token) : '';
        if ($token === '' || strpos($token, '.') === false) {
            return null;
        }
        [$body, $sig] = explode('.', $token, 2);
        $expected = self::b64url_encode(hash_hmac('sha256', $body, self::token_secret(), true));
        if (!hash_equals($expected, $sig)) {
            return null;
        }
        $json = self::b64url_decode($body);
        $payload = json_decode($json, true);
        if (!is_array($payload) || empty($payload['id']) || empty($payload['email']) || empty($payload['exp']) || (int) $payload['exp'] < time()) {
            return null;
        }
        $account = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::accounts_table() . ' WHERE id = %d AND email = %s', (int) $payload['id'], sanitize_email($payload['email'])));
        return $account ?: null;
    }

    private static function request_token() {
        if (isset($_POST['token'])) {
            return sanitize_text_field(wp_unslash($_POST['token']));
        }
        $header = isset($_SERVER['HTTP_AUTHORIZATION']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_AUTHORIZATION'])) : '';
        if (stripos($header, 'Bearer ') === 0) {
            return trim(substr($header, 7));
        }
        return '';
    }

    private static function auth_account() {
        return self::verify_token(self::request_token());
    }

    private static function account_payload($account) {
        if (!$account) {
            return null;
        }
        return [
            'id'    => (int) $account->id,
            'name'  => (string) $account->name,
            'email' => (string) $account->email,
        ];
    }

    private static function password_key() {
        $auth_key = defined('AUTH_KEY') ? AUTH_KEY : wp_salt('auth');
        return hash('sha256', wp_salt('auth') . '|' . $auth_key . '|rgz-pneumatic-design-password', true);
    }

    private static function encrypt_design_password($password) {
        $password = (string) $password;
        if ($password === '' || !function_exists('openssl_encrypt')) {
            return '';
        }
        $iv = random_bytes(16);
        $cipher = openssl_encrypt($password, 'AES-256-CBC', self::password_key(), OPENSSL_RAW_DATA, $iv);
        if ($cipher === false) {
            return '';
        }
        return base64_encode($iv . $cipher);
    }

    private static function decrypt_design_password($encoded) {
        $encoded = (string) $encoded;
        if ($encoded === '' || !function_exists('openssl_decrypt')) {
            return '';
        }
        $raw = base64_decode($encoded, true);
        if ($raw === false || strlen($raw) <= 16) {
            return '';
        }
        $iv = substr($raw, 0, 16);
        $cipher = substr($raw, 16);
        $plain = openssl_decrypt($cipher, 'AES-256-CBC', self::password_key(), OPENSSL_RAW_DATA, $iv);
        return $plain === false ? '' : $plain;
    }

    public static function studio_url() {
        $pages = get_posts([
            'post_type' => 'page',
            'post_status' => 'publish',
            'posts_per_page' => 20,
            's' => '[rgz_pneumatic_studio',
        ]);
        foreach ($pages as $page) {
            if (has_shortcode($page->post_content, self::SHORTCODE)) {
                return get_permalink($page);
            }
        }
        return home_url('/pneumatic-studio/');
    }

    public static function render_shortcode($atts = []) {
        $plugin_url = plugin_dir_url(__FILE__);

        $css_file = plugin_dir_path(__FILE__) . 'assets/app.css';
        $js_file = plugin_dir_path(__FILE__) . 'assets/app.min.js';
        $js_asset = 'assets/app.min.js';
        if (!file_exists($js_file)) {
            $js_file = plugin_dir_path(__FILE__) . 'assets/app.js';
            $js_asset = 'assets/app.js';
        }
        $css_version = self::VERSION . '-' . (file_exists($css_file) ? filemtime($css_file) : time());
        $js_version = self::VERSION . '-' . (file_exists($js_file) ? filemtime($js_file) : time());

        wp_enqueue_style('rgz-engineering-studio', $plugin_url . 'assets/app.css', [], $css_version);
        wp_enqueue_script('rgz-engineering-studio', $plugin_url . $js_asset, [], $js_version, true);

        wp_localize_script('rgz-engineering-studio', 'RGZPneumaticStudioConfig', [
            'siteUrl'        => home_url('/'),
            'websiteLabel'   => 'https://houmanrgz.ir',
            'assetBase'      => $plugin_url . 'assets/',
            'version'        => self::VERSION,
            'ajaxUrl'        => admin_url('admin-ajax.php'),
            'authNonce'      => wp_create_nonce('rgz_pneumatic_public'),
            'saveNonce'      => wp_create_nonce('rgz_pneumatic_public'),
            'maxUploadBytes'    => self::MAX_FILE_BYTES,
            'user'              => null,
            'canManageExamples' => current_user_can('manage_options'),
            'exampleOverrides'  => get_option('rgz_pneumatic_example_overrides', []),
            'customExamples'    => get_option('rgz_pneumatic_custom_examples', []),
            'tutorial'          => class_exists('RGZ_Mechanical_Deck') ? RGZ_Mechanical_Deck::tour_enabled('pneumatic') : true,
            'tourText'          => class_exists('RGZ_Mechanical_Deck') ? RGZ_Mechanical_Deck::tour_text('pneumatic') : '',
        ]);

        return '<div id="rgz-pneumatic-studio" class="rgz-pneumatic-studio-root" data-rgz-version="' . esc_attr(self::VERSION) . '"></div>';
    }

    public static function ajax_me() {
        $account = self::auth_account();
        wp_send_json_success(['user' => self::account_payload($account), 'token' => $account ? self::request_token() : '']);
    }

    public static function ajax_register() {
        global $wpdb;
        $name = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
        $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
        $password = isset($_POST['password']) ? (string) wp_unslash($_POST['password']) : '';

        if ($name === '' || !is_email($email) || strlen($password) < 6) {
            wp_send_json_error(['message' => 'Name, valid email, and password with at least 6 characters are required.'], 400);
        }

        $exists = $wpdb->get_var($wpdb->prepare('SELECT id FROM ' . self::accounts_table() . ' WHERE email = %s', $email));
        if ($exists) {
            wp_send_json_error(['message' => 'This email is already registered. Please sign in.'], 409);
        }

        $inserted = $wpdb->insert(
            self::accounts_table(),
            [
                'name'          => $name,
                'email'         => $email,
                'password_hash' => wp_hash_password($password),
                'created_at'    => current_time('mysql'),
                'last_login'    => current_time('mysql'),
            ],
            ['%s', '%s', '%s', '%s', '%s']
        );

        if (!$inserted) {
            wp_send_json_error(['message' => 'Could not create the RGZ Pneumatics account.'], 500);
        }

        $account = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::accounts_table() . ' WHERE id = %d', (int) $wpdb->insert_id));
        $token = self::create_token($account);
        wp_send_json_success(['user' => self::account_payload($account), 'token' => $token]);
    }

    public static function ajax_login() {
        global $wpdb;
        $login = isset($_POST['login']) ? sanitize_text_field(wp_unslash($_POST['login'])) : '';
        $password = isset($_POST['password']) ? (string) wp_unslash($_POST['password']) : '';
        if ($login === '' || $password === '') {
            wp_send_json_error(['message' => 'Email and password are required.'], 400);
        }
        $email = is_email($login) ? sanitize_email($login) : '';
        if (!$email) {
            wp_send_json_error(['message' => 'Please sign in with your email address.'], 400);
        }
        $account = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::accounts_table() . ' WHERE email = %s', $email));
        if (!$account || !wp_check_password($password, $account->password_hash)) {
            wp_send_json_error(['message' => 'Sign in failed. Please check your email and password.'], 401);
        }
        $wpdb->update(self::accounts_table(), ['last_login' => current_time('mysql')], ['id' => (int) $account->id], ['%s'], ['%d']);
        $token = self::create_token($account);
        wp_send_json_success(['user' => self::account_payload($account), 'token' => $token]);
    }

    public static function ajax_logout() {
        wp_send_json_success(['user' => null, 'token' => '']);
    }

    public static function ajax_save_design() {
        $account = self::auth_account();
        if (!$account) {
            wp_send_json_error(['message' => 'Please sign in before saving designs.', 'auth_required' => true], 401);
        }

        $file_name = isset($_POST['file_name']) ? sanitize_file_name(wp_unslash($_POST['file_name'])) : 'pneumatic-project.rgz';
        $password_hint = isset($_POST['password_hint']) ? sanitize_text_field(wp_unslash($_POST['password_hint'])) : '';
        $design_password = isset($_POST['design_password']) ? (string) wp_unslash($_POST['design_password']) : '';
        $file_base64 = isset($_POST['file_base64']) ? wp_unslash($_POST['file_base64']) : '';

        $file_base64 = preg_replace('/^data:.*?;base64,/', '', $file_base64);
        $binary = base64_decode($file_base64, true);
        if ($binary === false || strlen($binary) === 0) {
            wp_send_json_error(['message' => 'Invalid RGZ file payload.'], 400);
        }
        if (strlen($binary) > self::MAX_FILE_BYTES) {
            wp_send_json_error(['message' => 'The design file is larger than 512 KB and was not stored.'], 413);
        }

        global $wpdb;
        $inserted = $wpdb->insert(
            self::submissions_table(),
            [
                'account_id'          => (int) $account->id,
                'user_id'             => 0,
                'name'                => $account->name,
                'email'               => $account->email,
                'file_name'           => $file_name ?: 'pneumatic-project.rgz',
                'file_size'           => strlen($binary),
                'file_data'           => $binary,
                'password_hint'       => $password_hint,
                'design_password_enc' => self::encrypt_design_password($design_password),
                'created_at'          => current_time('mysql'),
            ],
            ['%d', '%d', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s']
        );

        if (!$inserted) {
            wp_send_json_error(['message' => 'Could not store the design.'], 500);
        }

        /* Blueprint thumbnail geometry for the Mechanical Deck "My designs"
           overview — a tiny JSON geometry model (positions + line endpoints
           only, no circuit data), sent by the app along with the design. */
        $thumb = isset($_POST['thumb']) ? (string) wp_unslash($_POST['thumb']) : '';
        if ('' !== $thumb && strlen($thumb) <= 60000) {
            $thumb_decoded = json_decode($thumb, true);
            if (is_array($thumb_decoded) && isset($thumb_decoded['comps']) && isset($thumb_decoded['conns'])) {
                $map = get_option(self::thumb_option(), []);
                if (!is_array($map)) { $map = []; }
                $map[(int) $wpdb->insert_id] = wp_json_encode($thumb_decoded);
                while (count($map) > 200) { array_shift($map); }
                update_option(self::thumb_option(), $map, false);
            }
        }

        wp_send_json_success(['message' => 'Design stored in your RGZ Pneumatics account.', 'id' => (int) $wpdb->insert_id]);
    }

    public static function ajax_my_designs() {
        $account = self::auth_account();
        if (!$account) {
            wp_send_json_error(['message' => 'Please sign in first.', 'auth_required' => true], 401);
        }
        global $wpdb;
        $rows = $wpdb->get_results($wpdb->prepare(
            'SELECT id, file_name, file_size, password_hint, created_at FROM ' . self::submissions_table() . ' WHERE account_id = %d ORDER BY created_at DESC LIMIT 100',
            (int) $account->id
        ));
        wp_send_json_success(['designs' => $rows]);
    }

    public static function ajax_get_design() {
        $account = self::auth_account();
        if (!$account) {
            wp_send_json_error(['message' => 'Please sign in first.', 'auth_required' => true], 401);
        }
        $id = isset($_POST['id']) ? absint($_POST['id']) : 0;
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare(
            'SELECT id, file_name, file_size, file_data, created_at FROM ' . self::submissions_table() . ' WHERE id = %d AND account_id = %d',
            $id,
            (int) $account->id
        ));
        if (!$row) {
            wp_send_json_error(['message' => 'Design not found.'], 404);
        }
        wp_send_json_success([
            'design' => [
                'id'          => (int) $row->id,
                'file_name'   => $row->file_name,
                'file_size'   => (int) $row->file_size,
                'created_at'  => $row->created_at,
                'file_base64' => base64_encode($row->file_data),
            ],
        ]);
    }

    public static function ajax_save_example() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Only the site owner can save pre-designed circuits.'], 403);
        }
        $index = isset($_POST['index']) ? absint($_POST['index']) : 0;
        $project_json = isset($_POST['project_json']) ? wp_unslash($_POST['project_json']) : '';
        if ($index < 0 || $index > 44 || $project_json === '') {
            wp_send_json_error(['message' => 'Invalid pre-designed circuit data.'], 400);
        }
        $project = json_decode($project_json, true);
        if (!is_array($project) || empty($project['components']) || !isset($project['connections'])) {
            wp_send_json_error(['message' => 'The current drawing is not a valid RGZ project.'], 400);
        }
        if (strlen($project_json) > 1200000) {
            wp_send_json_error(['message' => 'This template is too large to store as a pre-designed circuit.'], 413);
        }
        $overrides = get_option('rgz_pneumatic_example_overrides', []);
        if (!is_array($overrides)) {
            $overrides = [];
        }
        $project['savedAsPredesignedAt'] = current_time('mysql');
        $overrides[(string) $index] = $project;
        update_option('rgz_pneumatic_example_overrides', $overrides, false);
        wp_send_json_success(['message' => 'Pre-designed circuit saved for all users.', 'index' => $index, 'project' => $project]);
    }

    public static function ajax_add_example() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Only the site owner can add pre-designed circuits.'], 403);
        }
        $level = isset($_POST['level']) ? sanitize_text_field(wp_unslash($_POST['level'])) : 'Owner custom circuits';
        $name = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
        $project_json = isset($_POST['project_json']) ? wp_unslash($_POST['project_json']) : '';
        if ($name === '' || $project_json === '') {
            wp_send_json_error(['message' => 'Circuit title and project data are required.'], 400);
        }
        $project = json_decode($project_json, true);
        if (!is_array($project) || !isset($project['components']) || !isset($project['connections'])) {
            wp_send_json_error(['message' => 'The current drawing is not a valid RGZ project.'], 400);
        }
        if (strlen($project_json) > 1200000) {
            wp_send_json_error(['message' => 'This circuit is too large to store as a pre-designed circuit.'], 413);
        }
        $items = get_option('rgz_pneumatic_custom_examples', []);
        if (!is_array($items)) {
            $items = [];
        }
        $item = [
            'id' => 'custom-' . time() . '-' . wp_generate_password(6, false, false),
            'level' => $level ?: 'Owner custom circuits',
            'name' => $name,
            'project' => $project,
            'created_at' => current_time('mysql'),
        ];
        $items[] = $item;
        update_option('rgz_pneumatic_custom_examples', $items, false);
        wp_send_json_success(['message' => 'Circuit added to the pre-designed library.', 'item' => $item]);
    }

    public static function ajax_delete_custom_example() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Only the site owner can delete custom pre-designed circuits.'], 403);
        }
        $id = isset($_POST['id']) ? sanitize_text_field(wp_unslash($_POST['id'])) : '';
        if ($id === '') {
            wp_send_json_error(['message' => 'Missing custom circuit id.'], 400);
        }
        $items = get_option('rgz_pneumatic_custom_examples', []);
        if (!is_array($items)) {
            $items = [];
        }
        $before = count($items);
        $items = array_values(array_filter($items, static function($item) use ($id) {
            return !is_array($item) || (($item['id'] ?? '') !== $id);
        }));
        update_option('rgz_pneumatic_custom_examples', $items, false);
        wp_send_json_success(['message' => $before === count($items) ? 'No matching custom circuit found.' : 'Custom circuit deleted.', 'id' => $id]);
    }

    public static function ajax_reset_example() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Only the site owner can reset pre-designed circuits.'], 403);
        }
        $index = isset($_POST['index']) ? absint($_POST['index']) : 0;
        $overrides = get_option('rgz_pneumatic_example_overrides', []);
        if (!is_array($overrides)) {
            $overrides = [];
        }
        unset($overrides[(string) $index]);
        update_option('rgz_pneumatic_example_overrides', $overrides, false);
        wp_send_json_success(['message' => 'Pre-designed circuit reset to the built-in version.', 'index' => $index]);
    }

    public static function admin_menu() {
        add_submenu_page('rgz-engineering-studio','Pneumatics','Pneumatics','manage_options','rgz-pneumatics',[__CLASS__, 'render_admin_page']);
    }

    public static function render_admin_page() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to access this page.', 'rgz-pneumatic-studio'));
        }
        global $wpdb;
        $accounts_table = self::accounts_table();
        $submissions_table = self::submissions_table();

        $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
        $selected_account_id = isset($_GET['account_id']) ? absint($_GET['account_id']) : 0;
        $design_search = isset($_GET['design_s']) ? sanitize_text_field(wp_unslash($_GET['design_s'])) : '';

        $total_accounts = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$accounts_table}");
        $total_designs = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$submissions_table}");
        $total_storage = (int) $wpdb->get_var("SELECT COALESCE(SUM(file_size),0) FROM {$submissions_table}");
        $latest_design = $wpdb->get_var("SELECT MAX(created_at) FROM {$submissions_table}");

        $account_where = '1=1';
        $account_args = [];
        if ($search !== '') {
            $like = '%' . $wpdb->esc_like($search) . '%';
            $account_where .= ' AND (a.name LIKE %s OR a.email LIKE %s)';
            $account_args[] = $like;
            $account_args[] = $like;
        }
        $account_sql = "SELECT a.*, COUNT(s.id) AS design_count, COALESCE(SUM(s.file_size),0) AS storage_bytes, MAX(s.created_at) AS last_design
            FROM {$accounts_table} a
            LEFT JOIN {$submissions_table} s ON s.account_id = a.id
            WHERE {$account_where}
            GROUP BY a.id
            ORDER BY last_design DESC, a.created_at DESC
            LIMIT 250";
        $accounts = $account_args ? $wpdb->get_results($wpdb->prepare($account_sql, $account_args)) : $wpdb->get_results($account_sql);

        $selected_account = null;
        if ($selected_account_id) {
            $selected_account = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$accounts_table} WHERE id = %d", $selected_account_id));
        }

        $design_where = '1=1';
        $design_args = [];
        if ($selected_account_id) {
            $design_where .= ' AND account_id = %d';
            $design_args[] = $selected_account_id;
        }
        if ($design_search !== '') {
            $like = '%' . $wpdb->esc_like($design_search) . '%';
            $design_where .= ' AND (file_name LIKE %s OR name LIKE %s OR email LIKE %s OR password_hint LIKE %s)';
            $design_args = array_merge($design_args, [$like, $like, $like, $like]);
        }
        $design_sql = "SELECT id, account_id, user_id, name, email, file_name, file_size, password_hint, design_password_enc, created_at
            FROM {$submissions_table}
            WHERE {$design_where}
            ORDER BY created_at DESC
            LIMIT 300";
        $rows = $design_args ? $wpdb->get_results($wpdb->prepare($design_sql, $design_args)) : $wpdb->get_results($design_sql);
        ?>
        <div class="wrap rgz-admin-wrap">
            <style>
                .rgz-admin-wrap{--rgz-bg:#0f172a;--rgz-card:#fff;--rgz-border:#e5e7eb;--rgz-muted:#64748b;--rgz-accent:#e8793c;--rgz-blue:#2563eb;}
                .rgz-admin-hero{background:linear-gradient(135deg,#0f172a,#1e293b);color:#fff;border-radius:18px;padding:22px 24px;margin:18px 0;display:flex;justify-content:space-between;gap:18px;align-items:center;box-shadow:0 16px 40px rgba(15,23,42,.18)}
                .rgz-admin-hero h1{color:#fff;margin:0 0 6px;font-size:28px;font-weight:800}.rgz-admin-hero p{margin:0;color:#cbd5e1;max-width:780px}.rgz-admin-hero .button{border-color:rgba(255,255,255,.25);color:#fff;background:rgba(255,255,255,.08)}
                .rgz-stats{display:grid;grid-template-columns:repeat(4,minmax(160px,1fr));gap:14px;margin:16px 0}.rgz-stat{background:#fff;border:1px solid var(--rgz-border);border-radius:16px;padding:16px;box-shadow:0 8px 24px rgba(15,23,42,.05)}.rgz-stat span{display:block;color:var(--rgz-muted);font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.06em}.rgz-stat strong{display:block;margin-top:8px;font-size:24px;color:#0f172a}
                .rgz-admin-grid{display:grid;grid-template-columns:minmax(280px,360px) minmax(0,1fr);gap:16px;align-items:start}.rgz-panel-admin{background:#fff;border:1px solid var(--rgz-border);border-radius:18px;box-shadow:0 8px 24px rgba(15,23,42,.05);overflow:hidden}.rgz-panel-head{padding:15px 16px;border-bottom:1px solid var(--rgz-border);display:flex;justify-content:space-between;gap:10px;align-items:center}.rgz-panel-head h2{font-size:15px;margin:0;color:#0f172a}.rgz-panel-body{padding:14px 16px}.rgz-search-form{display:grid;gap:8px}.rgz-search-form input{width:100%;border-radius:10px;border:1px solid #cbd5e1;padding:8px 10px}.rgz-account-list{display:grid;gap:8px;max-height:620px;overflow:auto;padding:12px}.rgz-account-card{display:block;text-decoration:none;border:1px solid #e5e7eb;border-radius:14px;padding:12px;background:#fff;color:#0f172a;transition:.15s}.rgz-account-card:hover{border-color:#fb923c;box-shadow:0 8px 24px rgba(232,121,60,.12)}.rgz-account-card.active{border-color:#e8793c;background:#fff7ed}.rgz-account-card strong{display:block;font-size:14px;color:#0f172a}.rgz-account-card small{display:block;color:#64748b;overflow-wrap:anywhere;margin-top:3px}.rgz-account-meta{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}.rgz-pill{display:inline-flex;border-radius:999px;background:#f1f5f9;color:#334155;font-size:11px;font-weight:700;padding:4px 8px}.rgz-pill.orange{background:#ffedd5;color:#9a3412}.rgz-pill.blue{background:#dbeafe;color:#1d4ed8}.rgz-selected-account{background:#f8fafc;border:1px solid #e2e8f0;border-radius:14px;padding:12px;margin-bottom:12px}.rgz-selected-account h3{margin:0 0 4px}.rgz-actions-row{display:flex;gap:8px;flex-wrap:wrap}.rgz-table-wrap{overflow:auto}.rgz-modern-table{width:100%;border-collapse:separate;border-spacing:0 8px}.rgz-modern-table th{text-align:left;color:#64748b;font-size:11px;text-transform:uppercase;letter-spacing:.06em;padding:0 10px}.rgz-modern-table td{background:#fff;border-top:1px solid #e5e7eb;border-bottom:1px solid #e5e7eb;padding:12px 10px;vertical-align:top}.rgz-modern-table td:first-child{border-left:1px solid #e5e7eb;border-radius:12px 0 0 12px}.rgz-modern-table td:last-child{border-right:1px solid #e5e7eb;border-radius:0 12px 12px 0}.rgz-file-name{font-weight:800;color:#0f172a;overflow-wrap:anywhere}.rgz-muted{color:#64748b;font-size:12px}.rgz-password-box details{max-width:220px}.rgz-password-box code{display:block;margin-top:6px;white-space:normal;overflow-wrap:anywhere;background:#f8fafc;border:1px solid #e2e8f0;padding:6px;border-radius:8px}.rgz-empty{padding:28px;text-align:center;color:#64748b;background:#f8fafc;border-radius:14px}.rgz-filter-bar{display:grid;grid-template-columns:minmax(220px,1fr) auto auto;gap:8px;align-items:center}.rgz-filter-bar input{border-radius:10px;border:1px solid #cbd5e1;padding:8px 10px}.rgz-danger-link{color:#b91c1c!important;border-color:#fecaca!important;background:#fff1f2!important}
                @media(max-width:1100px){.rgz-stats{grid-template-columns:repeat(2,1fr)}.rgz-admin-grid{grid-template-columns:1fr}.rgz-filter-bar{grid-template-columns:1fr}}
            </style>

            <div class="rgz-admin-hero">
                <div>
                    <h1>RGZ Pneumatics</h1>
                    <p>Modern account-based management for Pneumatic Studio students, encrypted RGZ files, support passwords, search, filtering and per-account design history.</p>
                </div>
                <a class="button" href="<?php echo esc_url(self::studio_url()); ?>" target="_blank">Open Studio</a>
            </div>

            <div class="rgz-stats">
                <div class="rgz-stat"><span>Accounts</span><strong><?php echo esc_html((string) $total_accounts); ?></strong></div>
                <div class="rgz-stat"><span>Stored designs</span><strong><?php echo esc_html((string) $total_designs); ?></strong></div>
                <div class="rgz-stat"><span>Total storage</span><strong><?php echo esc_html(size_format($total_storage)); ?></strong></div>
                <div class="rgz-stat"><span>Latest design</span><strong style="font-size:14px"><?php echo esc_html($latest_design ?: '—'); ?></strong></div>
            </div>

            <div class="rgz-admin-grid">
                <div class="rgz-panel-admin">
                    <div class="rgz-panel-head"><h2>Accounts</h2><a class="button button-small" href="<?php echo esc_url(admin_url('admin.php?page=rgz-pneumatics')); ?>">All</a></div>
                    <div class="rgz-panel-body">
                        <form method="get" class="rgz-search-form">
                            <input type="hidden" name="page" value="rgz-pneumatics" />
                            <input type="search" name="s" value="<?php echo esc_attr($search); ?>" placeholder="Search name or email…" />
                            <button class="button button-primary" type="submit">Search accounts</button>
                        </form>
                    </div>
                    <div class="rgz-account-list">
                        <?php if (empty($accounts)) : ?>
                            <div class="rgz-empty">No accounts found.</div>
                        <?php else : ?>
                            <?php foreach ($accounts as $account) :
                                $url = add_query_arg(['page' => 'rgz-pneumatics', 'account_id' => (int) $account->id, 's' => $search], admin_url('admin.php'));
                                $delete_account_url = wp_nonce_url(admin_url('admin-post.php?action=rgz_pneumatic_delete_account&id=' . (int) $account->id), 'rgz_delete_account_' . (int) $account->id);
                                ?>
                                <a class="rgz-account-card <?php echo $selected_account_id === (int) $account->id ? 'active' : ''; ?>" href="<?php echo esc_url($url); ?>">
                                    <strong><?php echo esc_html($account->name); ?></strong>
                                    <small><?php echo esc_html($account->email); ?></small>
                                    <span class="rgz-account-meta">
                                        <span class="rgz-pill orange"><?php echo esc_html((string) (int) $account->design_count); ?> designs</span>
                                        <span class="rgz-pill blue"><?php echo esc_html(size_format((int) $account->storage_bytes)); ?></span>
                                    </span>
                                    <small>Last design: <?php echo esc_html($account->last_design ?: '—'); ?></small>
                                </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="rgz-panel-admin">
                    <div class="rgz-panel-head">
                        <h2><?php echo $selected_account ? 'Designs for ' . esc_html($selected_account->name) : 'Stored Designs'; ?></h2>
                        <?php if ($selected_account) :
                            $delete_account_url = wp_nonce_url(admin_url('admin-post.php?action=rgz_pneumatic_delete_account&id=' . (int) $selected_account->id), 'rgz_delete_account_' . (int) $selected_account->id);
                            ?>
                            <div class="rgz-actions-row"><a class="button button-small" href="mailto:<?php echo esc_attr($selected_account->email); ?>">Email</a><a class="button button-small rgz-danger-link" href="<?php echo esc_url($delete_account_url); ?>" onclick="return confirm('Delete this RGZ account and all its stored designs?');">Delete account</a></div>
                        <?php endif; ?>
                    </div>
                    <div class="rgz-panel-body">
                        <?php if ($selected_account) : ?>
                            <div class="rgz-selected-account">
                                <h3><?php echo esc_html($selected_account->name); ?></h3>
                                <div class="rgz-muted"><?php echo esc_html($selected_account->email); ?> · Created: <?php echo esc_html($selected_account->created_at); ?> · Last login: <?php echo esc_html($selected_account->last_login ?: '—'); ?></div>
                            </div>
                        <?php endif; ?>
                        <form method="get" class="rgz-filter-bar">
                            <input type="hidden" name="page" value="rgz-pneumatics" />
                            <?php if ($selected_account_id) : ?><input type="hidden" name="account_id" value="<?php echo esc_attr((string) $selected_account_id); ?>" /><?php endif; ?>
                            <input type="search" name="design_s" value="<?php echo esc_attr($design_search); ?>" placeholder="Search files, emails, names or hints…" />
                            <button class="button button-primary" type="submit">Filter designs</button>
                            <a class="button" href="<?php echo esc_url($selected_account_id ? add_query_arg(['page' => 'rgz-pneumatics', 'account_id' => $selected_account_id], admin_url('admin.php')) : admin_url('admin.php?page=rgz-pneumatics')); ?>">Reset</a>
                        </form>
                    </div>
                    <div class="rgz-panel-body rgz-table-wrap">
                        <?php if (empty($rows)) : ?>
                            <div class="rgz-empty">No designs found for this filter.</div>
                        <?php else : ?>
                            <table class="rgz-modern-table">
                                <thead><tr><th>File</th><th>Student</th><th>Size</th><th>Password</th><th>Date</th><th>Actions</th></tr></thead>
                                <tbody>
                                <?php foreach ($rows as $row) :
                                    $download_url = wp_nonce_url(admin_url('admin-post.php?action=rgz_pneumatic_download_design&id=' . (int) $row->id), 'rgz_download_' . (int) $row->id);
                                    $delete_url = wp_nonce_url(admin_url('admin-post.php?action=rgz_pneumatic_delete_design&id=' . (int) $row->id), 'rgz_delete_' . (int) $row->id);
                                    $account_url = $row->account_id ? add_query_arg(['page' => 'rgz-pneumatics', 'account_id' => (int) $row->account_id], admin_url('admin.php')) : '';
                                    $design_password = self::decrypt_design_password($row->design_password_enc);
                                    ?>
                                    <tr>
                                        <td><div class="rgz-file-name"><?php echo esc_html($row->file_name); ?></div><div class="rgz-muted">ID #<?php echo esc_html((string) $row->id); ?> · Account <?php echo $account_url ? '<a href="' . esc_url($account_url) . '">#' . esc_html((string) $row->account_id) . '</a>' : '—'; ?></div></td>
                                        <td><strong><?php echo esc_html($row->name); ?></strong><div class="rgz-muted"><a href="mailto:<?php echo esc_attr($row->email); ?>"><?php echo esc_html($row->email); ?></a></div></td>
                                        <td><?php echo esc_html(size_format((int) $row->file_size)); ?></td>
                                        <td class="rgz-password-box"><div class="rgz-muted">Hint: <?php echo esc_html($row->password_hint ?: '—'); ?></div><?php if ($design_password !== '') : ?><details><summary>Reveal password</summary><code><?php echo esc_html($design_password); ?></code></details><?php else : ?>—<?php endif; ?></td>
                                        <td><?php echo esc_html($row->created_at); ?></td>
                                        <td><div class="rgz-actions-row"><a class="button button-small" href="<?php echo esc_url($download_url); ?>">Download</a><a class="button button-small rgz-danger-link" href="<?php echo esc_url($delete_url); ?>" onclick="return confirm('Delete this stored design?');">Delete</a></div></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    public static function download_design() {
        if (!current_user_can('manage_options')) {
            wp_die('Permission denied.');
        }
        $id = isset($_GET['id']) ? absint($_GET['id']) : 0;
        check_admin_referer('rgz_download_' . $id);
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare('SELECT file_name, file_data, file_size FROM ' . self::submissions_table() . ' WHERE id = %d', $id));
        if (!$row) {
            wp_die('Design not found.');
        }
        nocache_headers();
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . sanitize_file_name($row->file_name ?: 'pneumatic-project.rgz') . '"');
        header('Content-Length: ' . (int) $row->file_size);
        echo $row->file_data; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        exit;
    }

    public static function delete_design() {
        if (!current_user_can('manage_options')) {
            wp_die('Permission denied.');
        }
        $id = isset($_GET['id']) ? absint($_GET['id']) : 0;
        check_admin_referer('rgz_delete_' . $id);
        global $wpdb;
        $wpdb->delete(self::submissions_table(), ['id' => $id], ['%d']);
        wp_safe_redirect(admin_url('admin.php?page=rgz-pneumatics'));
        exit;
    }

    public static function delete_account() {
        if (!current_user_can('manage_options')) {
            wp_die('Permission denied.');
        }
        $id = isset($_GET['id']) ? absint($_GET['id']) : 0;
        check_admin_referer('rgz_delete_account_' . $id);
        global $wpdb;
        $wpdb->delete(self::submissions_table(), ['account_id' => $id], ['%d']);
        $wpdb->delete(self::accounts_table(), ['id' => $id], ['%d']);
        wp_safe_redirect(admin_url('admin.php?page=rgz-pneumatics'));
        exit;
    }
}


require_once __DIR__ . '/rgz-mechanical-deck.php';
require_once __DIR__ . '/rgz-app-packages.php';
require_once __DIR__ . '/rgz-cad-studio.php';
require_once __DIR__ . '/rgz-elec-studio.php';
register_activation_hook(__FILE__, ['RGZ_Hydraulic_Studio_Plugin', 'install']);
register_activation_hook(__FILE__, ['RGZ_Pneumatic_Studio_Plugin', 'install']);
register_activation_hook(__FILE__, ['RGZ_CAD_Studio_Plugin', 'install']);
register_activation_hook(__FILE__, ['RGZ_Elec_Studio_Plugin', 'maybe_install']);
RGZ_Engineering_Studio_Plugin::init();
RGZ_Hydraulic_Studio_Plugin::init();
RGZ_Pneumatic_Studio_Plugin::init();
RGZ_CAD_Studio_Plugin::init();
RGZ_Elec_Studio_Plugin::init();
RGZ_Mechanical_Deck::init();
RGZ_Mech_App_Packages::boot();
