<?php
/**
 * RGZ Electrical Circuits Studio — backend module & shortcode loader.
 * Mirrors RGZ Hydraulic / Pneumatic / CAD Studio architectures:
 *   - RGZ account sign-in integration (shared HMAC tokens, table rgz_elec_accounts)
 *   - per-account design storage (rgz_elec_designs, plain JSON circuit sketches)
 *   - admin submenu "RGZ Electrical" (stats, accounts, designs, delete/download)
 *   - Learning Hub topic "Electrical" + deck "My designs" merge
 */
if (!defined('ABSPATH')) { exit; }

final class RGZ_Elec_Studio_Plugin {
    const VERSION        = '1.0.0';
    const SHORTCODE      = 'rgz_electrical_circuits_studio';
    const MAX_JSON_BYTES = 131072; /* 128 KB per electrical circuit design */
    const DB_OPTION      = 'rgz_elec_studio_db_schema';
    const DB_SCHEMA      = 'elec_tables_1';

    public static function init() {
        add_shortcode(self::SHORTCODE, [__CLASS__, 'render_shortcode']);
        add_action('init', [__CLASS__, 'maybe_install']);
        add_action('admin_menu', [__CLASS__, 'admin_menu']);

        foreach (['wp_ajax_', 'wp_ajax_nopriv_'] as $prefix) {
            add_action($prefix . 'rgz_elec_me',            [__CLASS__, 'ajax_me']);
            add_action($prefix . 'rgz_elec_login',         [__CLASS__, 'ajax_login']);
            add_action($prefix . 'rgz_elec_register',      [__CLASS__, 'ajax_register']);
            add_action($prefix . 'rgz_elec_logout',        [__CLASS__, 'ajax_logout']);
            add_action($prefix . 'rgz_elec_save_design',   [__CLASS__, 'ajax_save_design']);
            add_action($prefix . 'rgz_elec_my_designs',    [__CLASS__, 'ajax_my_designs']);
            add_action($prefix . 'rgz_elec_get_design',    [__CLASS__, 'ajax_get_design']);
            add_action($prefix . 'rgz_elec_delete_design', [__CLASS__, 'ajax_delete_design']);
        }
        add_action('admin_post_rgz_elec_download_design', [__CLASS__, 'download_design']);
        add_action('admin_post_rgz_elec_delete_design',   [__CLASS__, 'delete_design']);

        /* Deck connectors */
        add_filter('rgz_deck_learn_topics',     [__CLASS__, 'learn_topics']);
        add_filter('rgz_deck_topic_accents',    [__CLASS__, 'topic_accents']);
        add_filter('rgz_deck_profile_designs',  [__CLASS__, 'deck_profile_designs'], 10, 3);
    }

    public static function accounts_table() { global $wpdb; return $wpdb->prefix . 'rgz_elec_accounts'; }
    public static function designs_table()  { global $wpdb; return $wpdb->prefix . 'rgz_elec_designs'; }

    public static function maybe_install() {
        if (get_option(self::DB_OPTION) === self::DB_SCHEMA) { return; }
        self::install();
        update_option(self::DB_OPTION, self::DB_SCHEMA, false);
    }

    public static function install() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        dbDelta("CREATE TABLE " . self::accounts_table() . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(190) NOT NULL,
            email VARCHAR(190) NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            created_at DATETIME NOT NULL,
            last_login DATETIME NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY email (email),
            KEY created_at (created_at)
        ) {$charset_collate};");

        dbDelta("CREATE TABLE " . self::designs_table() . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            account_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            design_name VARCHAR(190) NOT NULL,
            file_size INT UNSIGNED NOT NULL DEFAULT 0,
            design_json LONGTEXT NOT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY account_id (account_id),
            KEY created_at (created_at)
        ) {$charset_collate};");
    }

    private static function b64url_encode($data) { return rtrim(strtr(base64_encode($data), '+/', '-_'), '='); }
    private static function b64url_decode($data) {
        $pad = strlen($data) % 4;
        if ($pad) { $data .= str_repeat('=', 4 - $pad); }
        return base64_decode(strtr($data, '-_', '+/'));
    }
    private static function token_secret() { return wp_salt('auth') . '|rgz-elec-account-token'; }

    public static function encode_token($account_id, $email) {
        $payload = json_encode(['sub' => (int) $account_id, 'email' => (string) $email, 'exp' => time() + 2592000]);
        $b64 = self::b64url_encode($payload);
        $sig = self::b64url_encode(hash_hmac('sha256', $b64, self::token_secret(), true));
        return $b64 . '.' . $sig;
    }

    public static function decode_token($token) {
        $parts = explode('.', $token);
        if (count($parts) !== 2) { return null; }
        list($b64, $sig) = $parts;
        $expected = self::b64url_encode(hash_hmac('sha256', $b64, self::token_secret(), true));
        if (!hash_equals($expected, $sig)) { return null; }
        $payload = json_decode(self::b64url_decode($b64), true);
        if (!is_array($payload) || empty($payload['sub']) || isset($payload['exp']) && time() > (int) $payload['exp']) {
            return null;
        }
        return $payload;
    }

    private static function verify_nonce() {
        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
        return (bool) wp_verify_nonce($nonce, 'rgz_elec_public');
    }

    public static function ajax_me() {
        if (!self::verify_nonce()) { wp_send_json_error(['message' => 'Invalid nonce']); }
        $token = isset($_POST['token']) ? sanitize_text_field(wp_unslash($_POST['token'])) : '';
        $data = self::decode_token($token);
        if (!$data) { wp_send_json_error(['message' => 'Unauthorized']); }
        global $wpdb;
        $acc = $wpdb->get_row($wpdb->prepare("SELECT id, name, email FROM " . self::accounts_table() . " WHERE id = %d", $data['sub']));
        if (!$acc) { wp_send_json_error(['message' => 'Account not found']); }
        wp_send_json_success(['account' => ['id' => (int) $acc->id, 'name' => $acc->name, 'email' => $acc->email]]);
    }

    public static function ajax_login() {
        if (!self::verify_nonce()) { wp_send_json_error(['message' => 'Invalid nonce']); }
        $email = sanitize_email(isset($_POST['email']) ? wp_unslash($_POST['email']) : '');
        $pass  = isset($_POST['password']) ? wp_unslash($_POST['password']) : '';
        if (!$email || !$pass) { wp_send_json_error(['message' => 'Email and password required']); }
        global $wpdb;
        $acc = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::accounts_table() . " WHERE email = %s", $email));
        if (!$acc || !wp_check_password($pass, $acc->password_hash)) {
            wp_send_json_error(['message' => 'Invalid email or password']);
        }
        $wpdb->update(self::accounts_table(), ['last_login' => current_time('mysql')], ['id' => $acc->id]);
        $token = self::encode_token($acc->id, $acc->email);
        wp_send_json_success(['token' => $token, 'account' => ['id' => (int) $acc->id, 'name' => $acc->name, 'email' => $acc->email]]);
    }

    public static function ajax_register() {
        if (!self::verify_nonce()) { wp_send_json_error(['message' => 'Invalid nonce']); }
        $name  = sanitize_text_field(isset($_POST['name']) ? wp_unslash($_POST['name']) : '');
        $email = sanitize_email(isset($_POST['email']) ? wp_unslash($_POST['email']) : '');
        $pass  = isset($_POST['password']) ? wp_unslash($_POST['password']) : '';
        if (!$name || !$email || !$pass) { wp_send_json_error(['message' => 'All fields required']); }
        global $wpdb;
        $existing = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . self::accounts_table() . " WHERE email = %s", $email));
        if ($existing) {
            // Fall back to login if account exists
            $acc = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::accounts_table() . " WHERE email = %s", $email));
            if ($acc && wp_check_password($pass, $acc->password_hash)) {
                $token = self::encode_token($acc->id, $acc->email);
                wp_send_json_success(['token' => $token, 'account' => ['id' => (int) $acc->id, 'name' => $acc->name, 'email' => $acc->email]]);
            }
            wp_send_json_error(['message' => 'Email already registered']);
        }
        $hash = wp_hash_password($pass);
        $wpdb->insert(self::accounts_table(), [
            'name' => $name, 'email' => $email, 'password_hash' => $hash, 'created_at' => current_time('mysql'), 'last_login' => current_time('mysql')
        ]);
        $acc_id = $wpdb->insert_id;
        $token = self::encode_token($acc_id, $email);
        wp_send_json_success(['token' => $token, 'account' => ['id' => (int) $acc_id, 'name' => $name, 'email' => $email]]);
    }

    public static function ajax_logout() {
        wp_send_json_success();
    }

    public static function ajax_save_design() {
        if (!self::verify_nonce()) { wp_send_json_error(['message' => 'Invalid nonce']); }
        $token = isset($_POST['token']) ? sanitize_text_field(wp_unslash($_POST['token'])) : '';
        $data = self::decode_token($token);
        if (!$data) { wp_send_json_error(['message' => 'Unauthorized']); }
        $name = sanitize_text_field(isset($_POST['design_name']) ? wp_unslash($_POST['design_name']) : 'Untitled Circuit');
        $json = isset($_POST['design_json']) ? wp_unslash($_POST['design_json']) : '';
        if (strlen($json) > self::MAX_JSON_BYTES) { wp_send_json_error(['message' => 'Design JSON too large']); }
        global $wpdb;
        $account_id = (int) $data['sub'];
        $wpdb->insert(self::designs_table(), [
            'account_id' => $account_id, 'design_name' => $name, 'file_size' => strlen($json), 'design_json' => $json, 'created_at' => current_time('mysql')
        ]);
        wp_send_json_success(['id' => (int) $wpdb->insert_id]);
    }

    public static function ajax_my_designs() {
        if (!self::verify_nonce()) { wp_send_json_error(['message' => 'Invalid nonce']); }
        $token = isset($_POST['token']) ? sanitize_text_field(wp_unslash($_POST['token'])) : '';
        $data = self::decode_token($token);
        if (!$data) { wp_send_json_error(['message' => 'Unauthorized']); }
        global $wpdb;
        $rows = $wpdb->get_results($wpdb->prepare("SELECT id, design_name, file_size, created_at FROM " . self::designs_table() . " WHERE account_id = %d ORDER BY id DESC", $data['sub']));
        $designs = [];
        foreach ($rows as $r) {
            $designs[] = ['id' => (int) $r->id, 'design_name' => $r->design_name, 'file_size' => (int) $r->file_size, 'created_at' => $r->created_at];
        }
        wp_send_json_success(['designs' => $designs]);
    }

    public static function ajax_get_design() {
        if (!self::verify_nonce()) { wp_send_json_error(['message' => 'Invalid nonce']); }
        $token = isset($_POST['token']) ? sanitize_text_field(wp_unslash($_POST['token'])) : '';
        $data = self::decode_token($token);
        if (!$data) { wp_send_json_error(['message' => 'Unauthorized']); }
        $id = absint(isset($_POST['id']) ? $_POST['id'] : 0);
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::designs_table() . " WHERE id = %d AND account_id = %d", $id, $data['sub']));
        if (!$row) { wp_send_json_error(['message' => 'Design not found']); }
        wp_send_json_success(['design' => [
            'id' => (int) $row->id, 'design_name' => $row->design_name, 'file_size' => (int) $row->file_size, 'created_at' => $row->created_at, 'design_json' => $row->design_json
        ]]);
    }

    public static function ajax_delete_design() {
        if (!self::verify_nonce()) { wp_send_json_error(['message' => 'Invalid nonce']); }
        $token = isset($_POST['token']) ? sanitize_text_field(wp_unslash($_POST['token'])) : '';
        $data = self::decode_token($token);
        if (!$data) { wp_send_json_error(['message' => 'Unauthorized']); }
        $id = absint(isset($_POST['id']) ? $_POST['id'] : 0);
        global $wpdb;
        $wpdb->delete(self::designs_table(), ['id' => $id, 'account_id' => $data['sub']]);
        wp_send_json_success();
    }

    public static function learn_topics($topics) {
        if (!isset($topics['electrical'])) { $topics['electrical'] = 'Electrical Circuits'; }
        return $topics;
    }
    public static function topic_accents($accents) {
        if (!isset($accents['electrical'])) { $accents['electrical'] = '#3b82f6'; }
        return $accents;
    }
    public static function deck_profile_designs($designs, $identity, $with_thumbs) {
        if (!is_array($identity) || empty($identity['email'])) { return $designs; }
        global $wpdb;
        $acc = $wpdb->get_row($wpdb->prepare("SELECT id FROM " . self::accounts_table() . " WHERE email = %s", $identity['email']));
        if (!$acc) { return $designs; }
        $rows = $wpdb->get_results($wpdb->prepare("SELECT id, design_name, file_size, created_at FROM " . self::designs_table() . " WHERE account_id = %d ORDER BY id DESC", $acc->id));
        $items = [];
        foreach ($rows as $r) {
            $items[] = [
                'id' => (int) $r->id,
                'name' => (string) $r->design_name,
                'size' => (int) $r->file_size,
                'date' => $r->created_at,
                'open' => self::studio_url() . '#rgz-open=' . (int) $r->id
            ];
        }
        $designs['electrical'] = $items;
        return $designs;
    }

    public static function studio_url() {
        $pages = get_posts(['post_type' => 'page', 'post_status' => 'publish', 'posts_per_page' => 20, 's' => '[' . self::SHORTCODE]);
        foreach ($pages as $page) {
            if (has_shortcode($page->post_content, self::SHORTCODE)) { return get_permalink($page); }
        }
        return home_url();
    }

    public static function admin_menu() {
        add_submenu_page('rgz-engineering-studio', 'RGZ Electrical', 'RGZ Electrical', 'manage_options', 'rgz-electrical', [__CLASS__, 'render_admin_page']);
    }

    public static function download_design() {
        if (!current_user_can('manage_options')) { wp_die('Denied.'); }
        check_admin_referer('rgz_elec_download_design');
        $id = absint(isset($_GET['id']) ? $_GET['id'] : 0);
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::designs_table() . " WHERE id = %d", $id));
        if (!$row) { wp_die('Design not found.'); }
        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . sanitize_file_name(strtolower(preg_replace('/[^a-zA-Z0-9]+/', '-', $row->design_name)) . '-elec-design.json') . '"');
        echo $row->design_json;
        exit;
    }

    public static function delete_design() {
        if (!current_user_can('manage_options')) { wp_die('Denied.'); }
        check_admin_referer('rgz_elec_delete_design');
        $id = absint(isset($_GET['id']) ? $_GET['id'] : 0);
        global $wpdb;
        $wpdb->delete(self::designs_table(), ['id' => $id]);
        wp_safe_redirect(add_query_arg(['page' => 'rgz-electrical', 'deleted' => $id], admin_url('admin.php')));
        exit;
    }

    public static function render_admin_page() {
        if (!current_user_can('manage_options')) { wp_die('Permission denied.'); }
        global $wpdb;
        $acc_table = self::accounts_table();
        $des_table = self::designs_table();
        $account_id = isset($_GET['account_id']) ? absint($_GET['account_id']) : 0;

        $accounts = $wpdb->get_results("SELECT * FROM {$acc_table} ORDER BY id DESC LIMIT 50");
        $query = "SELECT d.*, a.email as user_email FROM {$des_table} d LEFT JOIN {$acc_table} a ON d.account_id = a.id";
        if ($account_id) { $query .= $wpdb->prepare(" WHERE d.account_id = %d", $account_id); }
        $query .= " ORDER BY d.id DESC LIMIT 100";
        $designs = $wpdb->get_results($query);
        ?>
        <div class="wrap rgz-admin-wrap">
            <h1>RGZ Electrical Circuits Studio</h1>
            <p>Backend management center for Electrical Circuits Studio — accounts, schematic design storage, and export tools.</p>
            <div class="rgz-admin-grid" style="display:grid; grid-template-columns: 280px 1fr; gap: 20px; margin-top:20px;">
                <div class="rgz-card" style="background:#fff; padding:15px; border:1px solid #ccd0d7; border-radius:4px;">
                    <h3>Registered Accounts</h3>
                    <?php if (empty($accounts)) : ?>
                        <p style="color:#666;">No accounts signed up yet.</p>
                    <?php else : ?>
                        <ul style="margin:0; padding-left:15px;">
                        <?php foreach ($accounts as $a) : ?>
                            <li style="margin-bottom:8px;">
                                <a href="<?php echo esc_url(admin_url('admin.php?page=rgz-electrical&account_id=' . (int) $a->id)); ?>" <?php echo $account_id === (int) $a->id ? 'style="font-weight:bold;"' : ''; ?>>
                                    <?php echo esc_html($a->name); ?>
                                </a>
                                <br><small style="color:#666;"><?php echo esc_html($a->email); ?></small>
                            </li>
                        <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
                <div class="rgz-card" style="background:#fff; padding:15px; border:1px solid #ccd0d7; border-radius:4px;">
                    <h3>Stored Circuit Designs <?php if ($account_id) : ?>— <a href="<?php echo esc_url(admin_url('admin.php?page=rgz-electrical')); ?>">clear filter</a><?php endif; ?></h3>
                    <?php if (empty($designs)) : ?>
                        <p style="color:#666;">No circuit designs saved yet.</p>
                    <?php else : ?>
                        <table class="wp-list-table widefat fixed striped" style="margin-top:10px;">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Circuit Name</th>
                                    <th>Author Email</th>
                                    <th>Size</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($designs as $d) : ?>
                                <tr>
                                    <td><?php echo (int) $d->id; ?></td>
                                    <td><strong><?php echo esc_html($d->design_name); ?></strong></td>
                                    <td><?php echo esc_html($d->user_email ? $d->user_email : 'Guest / #'.$d->account_id); ?></td>
                                    <td><?php echo size_format($d->file_size); ?></td>
                                    <td><?php echo esc_html($d->created_at); ?></td>
                                    <td>
                                        <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=rgz_elec_download_design&id=' . (int) $d->id), 'rgz_elec_download_design')); ?>">Download JSON</a> | 
                                        <a style="color:#a00;" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=rgz_elec_delete_design&id=' . (int) $d->id), 'rgz_elec_delete_design')); ?>" onclick="return confirm('Delete this circuit permanently?');">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }

    public static function render_shortcode($atts = []) {
        $path = plugin_dir_path(__FILE__);
        $url  = plugin_dir_url(__FILE__);

        if (file_exists($path . 'app.css')) {
            wp_enqueue_style('rgz-elec-app-css', $url . 'app.css', [], self::VERSION . '-' . filemtime($path . 'app.css'));
        }
        if (file_exists($path . 'app.js')) {
            wp_enqueue_script('rgz-elec-app-js', $url . 'app.js', [], self::VERSION . '-' . filemtime($path . 'app.js'), true);
        }

        // Pass ajax URL & nonce to JS
        wp_localize_script('rgz-elec-app-js', 'RGZElecConfig', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('rgz_elec_public')
        ]);

        ob_start();
        ?>
        <div id="rgz-electrical-studio-app" class="rgzd rgzm-studio-wrap">
            <div style="padding: 50px; text-align: center; color: #64748b; font-size: 15px;">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#3b82f6" stroke-width="2" style="margin-bottom: 15px; animation: spin 2s linear infinite;"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
                <div style="font-weight: 700; color: #1e293b; margin-bottom: 5px;">Loading Electrical Circuits Studio...</div>
                <div>Initializing IEC schematic engine and Kirchhoff's MNA solver.</div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
RGZ_Elec_Studio_Plugin::init();
