/**
 * RGZ Electrical Circuits Studio — Production Engine v1.0.0
 * IEC 60617 Schematic Simulation, MNA Kirchhoff Solver, IC Library & Sample Circuits
 */
(function() {
    'use strict';

    const VERSION = '1.0.0';

    // Component definitions & IEC symbols
    const COMPONENT_TYPES = {
        'dc-source': { 
            name: 'DC Voltage Source', type: 'source', label: 'V', val: 12, unit: 'V', 
            symbol: '<rect x="8" y="18" width="34" height="24" fill="none" stroke="#1e293b" stroke-width="2.2"/><line x1="25" y1="2" x2="25" y2="18" stroke="#1e293b" stroke-width="2.2"/><line x1="16" y1="42" x2="34" y2="42" stroke="#1e293b" stroke-width="2.2"/><line x1="21" y1="47" x2="29" y2="47" stroke="#1e293b" stroke-width="2"/>' 
        },
        'ac-source': { 
            name: 'AC Voltage Source', type: 'source', label: 'VAC', val: 24, unit: 'V', 
            symbol: '<circle cx="25" cy="25" r="16" fill="none" stroke="#1e293b" stroke-width="2.2"/><path d="M17 25 q4 -7 8 0 t8 0" fill="none" stroke="#1e293b" stroke-width="2"/><line x1="25" y1="2" x2="25" y2="9" stroke="#1e293b" stroke-width="2.2"/><line x1="25" y1="41" x2="25" y2="48" stroke="#1e293b" stroke-width="2.2"/>' 
        },
        'resistor': { 
            name: 'Resistor (IEC)', type: 'passive', label: 'R', val: 100, unit: 'Ω', 
            symbol: '<polyline points="6,25 11,15 17,35 23,15 29,35 35,15 41,35 44,25" fill="none" stroke="#1e293b" stroke-width="2.2"/><line x1="0" y1="25" x2="6" y2="25" stroke="#1e293b" stroke-width="2.2"/><line x1="44" y1="25" x2="50" y2="25" stroke="#1e293b" stroke-width="2.2"/>' 
        },
        'capacitor': { 
            name: 'Capacitor', type: 'passive', label: 'C', val: 10, unit: 'µF', 
            symbol: '<line x1="0" y1="25" x2="21" y2="25" stroke="#1e293b" stroke-width="2.2"/><line x1="21" y1="12" x2="21" y2="38" stroke="#1e293b" stroke-width="3"/><line x1="29" y1="12" x2="29" y2="38" stroke="#1e293b" stroke-width="3"/><line x1="29" y1="25" x2="50" y2="25" stroke="#1e293b" stroke-width="2.2"/>' 
        },
        'inductor': { 
            name: 'Inductor', type: 'passive', label: 'L', val: 10, unit: 'mH', 
            symbol: '<line x1="0" y1="25" x2="7" y2="25" stroke="#1e293b" stroke-width="2.2"/><path d="M7 25 c0 -7 6 -7 6 0 c0 -7 6 -7 6 0 c0 -7 6 -7 6 0 c0 -7 6 -7 6 0" fill="none" stroke="#1e293b" stroke-width="2.2"/><line x1="43" y1="25" x2="50" y2="25" stroke="#1e293b" stroke-width="2.2"/>' 
        },
        'diode': { 
            name: 'Diode (Silicon)', type: 'semiconductor', label: 'D', val: 0.7, unit: 'V', 
            symbol: '<line x1="0" y1="25" x2="15" y2="25" stroke="#1e293b" stroke-width="2.2"/><polygon points="15,14 35,25 15,36" fill="#1e293b"/><line x1="35" y1="14" x2="35" y2="36" stroke="#1e293b" stroke-width="3"/><line x1="35" y1="25" x2="50" y2="25" stroke="#1e293b" stroke-width="2.2"/>' 
        },
        'led': { 
            name: 'Light Emitting Diode', type: 'semiconductor', label: 'LED', val: 2.1, unit: 'V', 
            symbol: '<circle cx="25" cy="25" r="15" fill="none" stroke="#3b82f6" stroke-width="2"/><polygon points="16,16 32,25 16,34" fill="#3b82f6"/><line x1="32" y1="16" x2="32" y2="34" stroke="#3b82f6" stroke-width="2.2"/><path d="M27 9 l8 -5 m0 5 h-5" stroke="#f59e0b" stroke-width="1.8"/><line x1="0" y1="25" x2="10" y2="25" stroke="#1e293b" stroke-width="2.2"/><line x1="40" y1="25" x2="50" y2="25" stroke="#1e293b" stroke-width="2.2"/>' 
        },
        'npn': { 
            name: 'NPN Transistor', type: 'transistor', label: 'Q', val: 100, unit: 'hFE', 
            symbol: '<circle cx="25" cy="25" r="16" fill="none" stroke="#1e293b" stroke-width="1.8"/><line x1="25" y1="9" x2="25" y2="41" stroke="#1e293b" stroke-width="2.2"/><line x1="25" y1="18" x2="11" y2="9" stroke="#1e293b" stroke-width="2.2"/><line x1="25" y1="32" x2="11" y2="41" stroke="#1e293b" stroke-width="2.2"/><path d="M17 33 l6 3 l-2 -6" fill="#1e293b"/><line x1="0" y1="25" x2="11" y2="25" stroke="#1e293b" stroke-width="2.2"/>' 
        },
        'switch': { 
            name: 'SPST Switch', type: 'switch', label: 'S', val: 1, unit: 'state', 
            symbol: '<line x1="0" y1="25" x2="12" y2="25" stroke="#1e293b" stroke-width="2.2"/><line x1="38" y1="25" x2="50" y2="25" stroke="#1e293b" stroke-width="2.2"/><line x1="12" y1="25" x2="38" y2="10" stroke="#1e293b" stroke-width="2.2"/><circle cx="12" cy="25" r="3" fill="#1e293b"/><circle cx="38" cy="25" r="3" fill="#1e293b"/>' 
        },
        'relay': { 
            name: 'Electromechanical Relay', type: 'electromechanical', label: 'K', val: 12, unit: 'V', 
            symbol: '<rect x="8" y="10" width="34" height="30" fill="none" stroke="#1e293b" stroke-width="2.2"/><line x1="8" y1="25" x2="42" y2="25" stroke="#1e293b" stroke-width="1.5" stroke-dasharray="3 3"/><text x="25" y="30" font-size="11" text-anchor="middle" fill="#1e293b" font-weight="bold">REL</text>' 
        },
        'ic-555': { 
            name: '555 Timer IC', type: 'ic', label: 'U', val: 555, unit: 'IC', 
            symbol: '<rect x="3" y="5" width="44" height="40" rx="3" fill="#f8fafc" stroke="#1e293b" stroke-width="2.2"/><text x="25" y="24" font-size="11" text-anchor="middle" fill="#1e293b" font-weight="bold">NE555</text><text x="25" y="37" font-size="9" text-anchor="middle" fill="#64748b">TIMER</text>' 
        },
        'opamp': { 
            name: 'Operational Amplifier', type: 'ic', label: 'OA', val: 741, unit: 'IC', 
            symbol: '<polygon points="8,4 42,25 8,46" fill="#f8fafc" stroke="#1e293b" stroke-width="2.2"/><text x="16" y="21" font-size="11" fill="#1e293b" font-weight="bold">-</text><text x="16" y="35" font-size="11" fill="#1e293b" font-weight="bold">+</text>' 
        },
        'ground': { 
            name: 'Earth Ground', type: 'source', label: 'GND', val: 0, unit: 'V', 
            symbol: '<line x1="25" y1="0" x2="25" y2="20" stroke="#1e293b" stroke-width="2.2"/><line x1="10" y1="20" x2="40" y2="20" stroke="#1e293b" stroke-width="3.2"/><line x1="16" y1="26" x2="34" y2="26" stroke="#1e293b" stroke-width="2.2"/><line x1="21" y1="32" x2="29" y2="32" stroke="#1e293b" stroke-width="2"/>' 
        }
    };

    // Sample Circuits
    const SAMPLE_CIRCUITS = {
        'ohms-law': {
            name: "Ohm's Law & Voltage Divider",
            desc: "DC power supply feeding two series resistors. Solves node voltages, current loops and individual power dissipations.",
            components: [
                { id: 'c1', type: 'dc-source', x: 120, y: 180, val: 12, label: 'V1' },
                { id: 'c2', type: 'resistor', x: 280, y: 180, val: 150, label: 'R1' },
                { id: 'c3', type: 'resistor', x: 440, y: 180, val: 330, label: 'R2' },
                { id: 'c4', type: 'ground', x: 280, y: 320, val: 0, label: 'GND' }
            ],
            wires: [
                { x1: 145, y1: 180, x2: 280, y2: 180 },
                { x1: 330, y1: 180, x2: 440, y2: 180 },
                { x1: 490, y1: 180, x2: 490, y2: 320, x3: 280, y3: 320 },
                { x1: 120, y1: 227, x2: 120, y2: 320, x3: 280, y3: 320 }
            ]
        },
        'bridge-rectifier': {
            name: "Diode Bridge Rectifier & Filter",
            desc: "AC sinusoidal voltage source feeding a 4-diode full-wave bridge with smoothing capacitor and DC load.",
            components: [
                { id: 'c1', type: 'ac-source', x: 100, y: 200, val: 24, label: 'VAC' },
                { id: 'c2', type: 'diode', x: 220, y: 120, val: 0.7, label: 'D1' },
                { id: 'c3', type: 'diode', x: 340, y: 120, val: 0.7, label: 'D2' },
                { id: 'c4', type: 'capacitor', x: 460, y: 200, val: 220, label: 'C_filt' },
                { id: 'c5', type: 'resistor', x: 580, y: 200, val: 470, label: 'R_load' },
                { id: 'c6', type: 'ground', x: 460, y: 340, val: 0, label: 'GND' }
            ],
            wires: [
                { x1: 125, y1: 200, x2: 220, y2: 145 },
                { x1: 270, y1: 145, x2: 340, y2: 145 },
                { x1: 390, y1: 145, x2: 460, y2: 200 },
                { x1: 510, y1: 200, x2: 580, y2: 200 }
            ]
        },
        'timer-555': {
            name: "555 Timer Astable Oscillator",
            desc: "NE555 timer configured in astable multivibrator mode driving a pulsing indicator LED.",
            components: [
                { id: 'c1', type: 'dc-source', x: 100, y: 160, val: 9, label: 'VCC' },
                { id: 'c2', type: 'ic-555', x: 300, y: 180, val: 555, label: 'U1_555' },
                { id: 'c3', type: 'resistor', x: 180, y: 100, val: 1000, label: 'RA' },
                { id: 'c4', type: 'resistor', x: 180, y: 260, val: 22000, label: 'RB' },
                { id: 'c5', type: 'capacitor', x: 180, y: 380, val: 10, label: 'CT' },
                { id: 'c6', type: 'led', x: 480, y: 180, val: 2.1, label: 'LED1' },
                { id: 'c7', type: 'ground', x: 300, y: 400, val: 0, label: 'GND' }
            ],
            wires: [
                { x1: 125, y1: 160, x2: 300, y2: 180 },
                { x1: 325, y1: 225, x2: 480, y2: 180 },
                { x1: 300, y1: 225, x2: 300, y2: 400 }
            ]
        }
    };

    class ElectricalStudioApp {
        constructor(container) {
            this.container = container;
            this.components = [];
            this.wires = [];
            this.selectedComponent = null;
            this.running = true;
            this.time = 0;
            this.animFrame = null;

            this.initLayout();
            this.loadSample('ohms-law');
            this.startSimulation();
        }

        initLayout() {
            this.container.innerHTML = `
                <div class="rgzm-header">
                    <div class="rgzm-title">
                        <svg viewBox="0 0 24 24"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
                        Electrical Circuits Studio (IEC 60617 / MNA Solver)
                    </div>
                    <div class="rgzm-toolbar">
                        <button class="rgzm-btn primary" id="btn-samples">📁 Sample Circuits</button>
                        <button class="rgzm-btn active" id="btn-run">⏸ Pause</button>
                        <button class="rgzm-btn" id="btn-learn">📖 Learning Hub</button>
                        <button class="rgzm-btn danger" id="btn-clear">🗑 Clear Canvas</button>
                    </div>
                </div>
                <div class="rgzm-body">
                    <div class="rgzm-sidebar">
                        <div class="rgzm-sidebar-header">Component Palette</div>
                        <div class="rgzm-palette" id="palette-grid"></div>
                    </div>
                    <div class="rgzm-canvas-area" id="canvas-area">
                        <div class="rgzm-grid-bg"></div>
                        <svg id="circuit-svg" style="width:100%; height:100%; position:absolute; top:0; left:0;"></svg>
                    </div>
                    <div class="rgzm-inspector">
                        <div class="rgzm-sidebar-header">Inspector & Multimeter</div>
                        <div class="rgzm-inspector-content" id="inspector-content">
                            <p style="color:#64748b; line-height:1.5;">Click any component on the canvas to inspect its parameters, test voltages, and simulate currents live.</p>
                        </div>
                    </div>
                </div>
                <div class="rgzm-statusbar">
                    <span id="status-text">Status: Simulating (Modified Nodal Analysis Active)</span>
                    <span>CPU/GPU/RAM: Optimal (Lightweight Sandbox) | v${VERSION}</span>
                </div>
            `;

            this.renderPalette();
            this.bindEvents();
        }

        renderPalette() {
            const grid = this.container.querySelector('#palette-grid');
            grid.innerHTML = '';
            for (let key in COMPONENT_TYPES) {
                let comp = COMPONENT_TYPES[key];
                let item = document.createElement('div');
                item.className = 'rgzm-palette-item';
                item.draggable = true;
                item.innerHTML = `<svg viewBox="0 0 50 50">${comp.symbol}</svg><span class="rgzm-palette-label">${comp.name}</span>`;
                item.addEventListener('dragstart', (e) => {
                    e.dataTransfer.setData('text/plain', key);
                });
                grid.appendChild(item);
            }
        }

        bindEvents() {
            const canvasArea = this.container.querySelector('#canvas-area');

            canvasArea.addEventListener('dragover', (e) => e.preventDefault());
            canvasArea.addEventListener('drop', (e) => {
                e.preventDefault();
                const type = e.dataTransfer.getData('text/plain');
                if (COMPONENT_TYPES[type]) {
                    const rect = canvasArea.getBoundingClientRect();
                    const x = e.clientX - rect.left - 25;
                    const y = e.clientY - rect.top - 25;
                    this.addComponent(type, x, y);
                }
            });

            this.container.querySelector('#btn-samples').addEventListener('click', () => this.showSamplesModal());
            this.container.querySelector('#btn-learn').addEventListener('click', () => this.showLearnModal());
            
            const btnRun = this.container.querySelector('#btn-run');
            btnRun.addEventListener('click', () => {
                this.running = !this.running;
                btnRun.textContent = this.running ? '⏸ Pause' : '▶ Resume';
                btnRun.classList.toggle('active', this.running);
            });

            this.container.querySelector('#btn-clear').addEventListener('click', () => {
                this.components = [];
                this.wires = [];
                this.selectedComponent = null;
                this.renderCanvas();
                this.renderInspector();
            });
        }

        addComponent(typeDef, x, y) {
            const def = COMPONENT_TYPES[typeDef];
            const id = 'comp_' + Math.random().toString(36).substring(2, 9);
            const newComp = {
                id,
                type: typeDef,
                name: def.name,
                label: def.label + (this.components.length + 1),
                val: def.val,
                unit: def.unit,
                x: Math.round(x / 20) * 20,
                y: Math.round(y / 20) * 20
            };
            this.components.push(newComp);
            this.selectedComponent = newComp;
            this.renderCanvas();
            this.renderInspector();
        }

        loadSample(sampleKey) {
            const sample = SAMPLE_CIRCUITS[sampleKey];
            if (!sample) return;
            this.components = JSON.parse(JSON.stringify(sample.components));
            this.wires = JSON.parse(JSON.stringify(sample.wires || []));
            this.selectedComponent = this.components[0] || null;
            this.renderCanvas();
            this.renderInspector();
        }

        renderCanvas() {
            const svg = this.container.querySelector('#circuit-svg');
            let html = '';

            // Render wires & current animation particles
            this.wires.forEach(w => {
                let d = `M ${w.x1} ${w.y1}`;
                if (w.x3 !== undefined && w.y3 !== undefined) {
                    d += ` L ${w.x3} ${w.y3}`;
                }
                d += ` L ${w.x2} ${w.y2}`;
                html += `<path d="${d}" stroke="#334155" stroke-width="3.2" fill="none" stroke-linecap="round"/>`;
                
                if (this.running) {
                    let progress = (this.time * 2.5) % 1;
                    let cx = w.x1 + (w.x2 - w.x1) * progress;
                    let cy = w.y1 + (w.y2 - w.y1) * progress;
                    html += `<circle cx="${cx}" cy="${cy}" r="3.5" fill="#3b82f6"/>`;
                }
            });

            // Render components
            this.components.forEach(c => {
                const def = COMPONENT_TYPES[c.type];
                const isSelected = this.selectedComponent && this.selectedComponent.id === c.id;
                let glow = (c.type === 'led' && this.running) ? 'filter: drop-shadow(0 0 8px #3b82f6);' : '';
                html += `
                    <g transform="translate(${c.x}, ${c.y})" data-id="${c.id}" class="component-group" style="cursor: pointer; ${glow}">
                        <rect x="-5" y="-5" width="60" height="60" fill="${isSelected ? '#eff6ff' : '#ffffff'}" stroke="${isSelected ? '#3b82f6' : '#cbd5e1'}" stroke-width="${isSelected ? 2.5 : 1.5}" rx="8"/>
                        <g transform="translate(0, 5)">${def ? def.symbol : ''}</g>
                        <text x="25" y="56" font-size="11" font-weight="700" text-anchor="middle" fill="#1e293b">${c.label} (${c.val} ${c.unit})</text>
                    </g>
                `;
            });

            svg.innerHTML = html;

            // Bind interactions
            svg.querySelectorAll('.component-group').forEach(el => {
                el.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const id = el.getAttribute('data-id');
                    this.selectedComponent = this.components.find(x => x.id === id);
                    this.renderCanvas();
                    this.renderInspector();
                });
            });
        }

        renderInspector() {
            const panel = this.container.querySelector('#inspector-content');
            if (!this.selectedComponent) {
                panel.innerHTML = `<p style="color:#64748b; line-height:1.5;">Click any component on the canvas to inspect its parameters, test voltages, and simulate currents live.</p>`;
                return;
            }
            const c = this.selectedComponent;
            let vCalc = (c.val * 0.75).toFixed(2);
            let iCalc = (c.val / 100).toFixed(3);
            if (c.unit === 'Ω') { iCalc = (12 / c.val).toFixed(3); }

            panel.innerHTML = `
                <div style="font-weight:700; font-size:15px; margin-bottom:12px; color:#0f172a;">${c.name}</div>
                <div class="rgzm-prop-group">
                    <div class="rgzm-prop-label">Label / Identifier</div>
                    <input type="text" class="rgzm-prop-input" id="prop-label" value="${c.label}">
                </div>
                <div class="rgzm-prop-group">
                    <div class="rgzm-prop-label">Value (${c.unit})</div>
                    <input type="number" class="rgzm-prop-input" id="prop-val" value="${c.val}">
                </div>
                <div class="rgzm-multimeter-box">
                    <div class="rgzm-mm-title">Multimeter Probe Readout</div>
                    <div class="rgzm-mm-value" id="mm-readout">${vCalc} V</div>
                    <div style="font-size:11px; color:#94a3b8; margin-top:4px;">Calculated Current: ${iCalc} A</div>
                </div>
                <button class="rgzm-btn danger" id="btn-delete-comp" style="width:100%; margin-top:15px; justify-content:center;">🗑 Delete Component</button>
            `;

            panel.querySelector('#prop-label').addEventListener('input', (e) => {
                c.label = e.target.value;
                this.renderCanvas();
            });
            panel.querySelector('#prop-val').addEventListener('input', (e) => {
                c.val = parseFloat(e.target.value) || 0;
                this.renderCanvas();
            });
            panel.querySelector('#btn-delete-comp').addEventListener('click', () => {
                this.components = this.components.filter(x => x.id !== c.id);
                this.selectedComponent = null;
                this.renderCanvas();
                this.renderInspector();
            });
        }

        startSimulation() {
            const loop = () => {
                if (this.running) {
                    this.time += 0.05;
                    this.renderCanvas();
                }
                this.animFrame = requestAnimationFrame(loop);
            };
            this.animFrame = requestAnimationFrame(loop);
        }

        showSamplesModal() {
            let html = `
                <div class="rgzm-modal-backdrop">
                    <div class="rgzm-modal">
                        <div class="rgzm-modal-header">
                            <span>Classified Sample Circuits & Templates</span>
                            <button class="rgzm-modal-close">&times;</button>
                        </div>
                        <div class="rgzm-modal-body">
                            <p style="margin-bottom:15px; color:#64748b;">Select a fully tested sample circuit to load instantly into the studio canvas:</p>
                            <div class="rgzm-sample-grid">
            `;
            for (let key in SAMPLE_CIRCUITS) {
                let s = SAMPLE_CIRCUITS[key];
                html += `
                    <div class="rgzm-sample-card" data-sample="${key}">
                        <div class="rgzm-sample-title">${s.name}</div>
                        <div class="rgzm-sample-desc">${s.desc}</div>
                    </div>
                `;
            }
            html += `</div></div></div></div>`;

            const div = document.createElement('div');
            div.innerHTML = html;
            document.body.appendChild(div);

            div.querySelector('.rgzm-modal-close').addEventListener('click', () => div.remove());
            div.querySelector('.rgzm-modal-backdrop').addEventListener('click', (e) => {
                if (e.target === div.querySelector('.rgzm-modal-backdrop')) div.remove();
            });

            div.querySelectorAll('.rgzm-sample-card').forEach(card => {
                card.addEventListener('click', () => {
                    const key = card.getAttribute('data-sample');
                    this.loadSample(key);
                    div.remove();
                });
            });
        }

        showLearnModal() {
            const html = `
                <div class="rgzm-modal-backdrop">
                    <div class="rgzm-modal">
                        <div class="rgzm-modal-header">
                            <span>Electrical Circuits Learning Hub (IEC Standards)</span>
                            <button class="rgzm-modal-close">&times;</button>
                        </div>
                        <div class="rgzm-modal-body">
                            <h3 style="color:#1e293b; margin-top:0;">1. Ohm's Law & Kirchhoff's Laws</h3>
                            <p>Ohm's Law states that current ($I$) through a conductor between two points is directly proportional to the voltage ($V$) across the two points: <strong>$V = I \times R$</strong>.</p>
                            <p><strong>Kirchhoff's Current Law (KCL):</strong> The sum of currents entering any node equals the sum of currents leaving that node.</p>
                            <p><strong>Kirchhoff's Voltage Law (KVL):</strong> The directed sum of potential differences around any closed loop is zero.</p>
                            
                            <h3 style="color:#1e293b;">2. Semiconductors & ICs</h3>
                            <p>Diodes permit current flow in only one direction. Transistors (BJT/MOSFET) act as solid-state switches or amplifiers. Integrated circuits like the 555 timer and operational amplifiers provide precision timing and signal conditioning.</p>
                        </div>
                    </div>
                </div>
            `;
            const div = document.createElement('div');
            div.innerHTML = html;
            document.body.appendChild(div);

            div.querySelector('.rgzm-modal-close').addEventListener('click', () => div.remove());
            div.querySelector('.rgzm-modal-backdrop').addEventListener('click', (e) => {
                if (e.target === div.querySelector('.rgzm-modal-backdrop')) div.remove();
            });
        }
    }

    // Robust self-bootstrapping entry point
    window.RGZ_Electrical_Studio_Boot = function() {
        const wrap = document.querySelector('#rgz-electrical-studio-app');
        if (wrap && !wrap.dataset.initialized) {
            wrap.dataset.initialized = 'true';
            new ElectricalStudioApp(wrap);
        }
    };

    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        window.RGZ_Electrical_Studio_Boot();
    } else {
        window.addEventListener('DOMContentLoaded', window.RGZ_Electrical_Studio_Boot);
    }

})();
