/**
 * RGZ Electrical Circuits Studio — v1.0.0
 * IEC Standard Circuit Simulation, Kirchhoff's MNA Solver, IC Library, Sample Circuits & Animations
 */
(function() {
    'use strict';

    const VERSION = '1.0.0';

    // Component templates (IEC symbols & defaults)
    const COMPONENT_TYPES = {
        'dc-source': { name: 'DC Voltage', type: 'source', label: 'V1', val: 12, unit: 'V', symbol: '<rect x="10" y="20" width="30" height="20" fill="none" stroke="#1e293b" stroke-width="2"/><line x1="25" y1="5" x2="25" y2="20" stroke="#1e293b" stroke-width="2"/><line x1="17" y1="40" x2="33" y2="40" stroke="#1e293b" stroke-width="2"/><line x1="22" y1="45" x2="28" y2="45" stroke="#1e293b" stroke-width="2"/>' },
        'ac-source': { name: 'AC Source', type: 'source', label: 'V_AC', val: 24, unit: 'V', symbol: '<circle cx="25" cy="25" r="15" fill="none" stroke="#1e293b" stroke-width="2"/><path d="M18 25 q3 -6 7 0 t7 0" fill="none" stroke="#1e293b" stroke-width="2"/><line x1="25" y1="2" x2="25" y2="10" stroke="#1e293b" stroke-width="2"/><line x1="25" y1="40" x2="25" y2="48" stroke="#1e293b" stroke-width="2"/>' },
        'resistor': { name: 'Resistor', type: 'passive', label: 'R1', val: 100, unit: 'Ω', symbol: '<polyline points="10,25 15,15 21,35 27,15 33,35 39,15 45,25" fill="none" stroke="#1e293b" stroke-width="2"/><line x1="0" y1="25" x2="10" y2="25" stroke="#1e293b" stroke-width="2"/><line x1="45" y1="25" x2="55" y2="25" stroke="#1e293b" stroke-width="2"/>' },
        'capacitor': { name: 'Capacitor', type: 'passive', label: 'C1', val: 10, unit: 'µF', symbol: '<line x1="0" y1="25" x2="20" y2="25" stroke="#1e293b" stroke-width="2"/><line x1="20" y1="12" x2="20" y2="38" stroke="#1e293b" stroke-width="3"/><line x1="30" y1="12" x2="30" y2="38" stroke="#1e293b" stroke-width="3"/><line x1="30" y1="25" x2="50" y2="25" stroke="#1e293b" stroke-width="2"/>' },
        'inductor': { name: 'Inductor', type: 'passive', label: 'L1', val: 10, unit: 'mH', symbol: '<line x1="0" y1="25" x2="8" y2="25" stroke="#1e293b" stroke-width="2"/><path d="M8 25 c0 -8 6 -8 6 0 c0 -8 6 -8 6 0 c0 -8 6 -8 6 0 c0 -8 6 -8 6 0" fill="none" stroke="#1e293b" stroke-width="2"/><line x1="38" y1="25" x2="48" y2="25" stroke="#1e293b" stroke-width="2"/>' },
        'diode': { name: 'Diode', type: 'semiconductor', label: 'D1', val: 0.7, unit: 'V', symbol: '<line x1="0" y1="25" x2="16" y2="25" stroke="#1e293b" stroke-width="2"/><polygon points="16,15 34,25 16,35" fill="#1e293b"/><line x1="34" y1="15" x2="34" y2="35" stroke="#1e293b" stroke-width="3"/><line x1="34" y1="25" x2="50" y2="25" stroke="#1e293b" stroke-width="2"/>' },
        'led': { name: 'LED', type: 'semiconductor', label: 'LED1', val: 2.1, unit: 'V', symbol: '<circle cx="25" cy="25" r="14" fill="none" stroke="#3b82f6" stroke-width="2"/><polygon points="17,17 31,25 17,33" fill="#3b82f6"/><line x1="31" y1="17" x2="31" y2="33" stroke="#3b82f6" stroke-width="2"/><path d="M28 10 l8 -5 m0 5 h-5" stroke="#f59e0b" stroke-width="1.5"/><line x1="0" y1="25" x2="11" y2="25" stroke="#1e293b" stroke-width="2"/><line x1="39" y1="25" x2="50" y2="25" stroke="#1e293b" stroke-width="2"/>' },
        'npn': { name: 'NPN Transistor', type: 'transistor', label: 'Q1', val: 100, unit: 'hFE', symbol: '<circle cx="25" cy="25" r="16" fill="none" stroke="#1e293b" stroke-width="1.5"/><line x1="25" y1="9" x2="25" y2="41" stroke="#1e293b" stroke-width="2"/><line x1="25" y1="18" x2="12" y2="10" stroke="#1e293b" stroke-width="2"/><line x1="25" y1="32" x2="12" y2="40" stroke="#1e293b" stroke-width="2"/><path d="M18 33 l5 3 l-2 -5" fill="#1e293b"/><line x1="0" y1="25" x2="12" y2="25" stroke="#1e293b" stroke-width="2"/>' },
        'switch': { name: 'SPST Switch', type: 'switch', label: 'S1', val: 0, unit: 'state', symbol: '<line x1="0" y1="25" x2="12" y2="25" stroke="#1e293b" stroke-width="2"/><line x1="38" y1="25" x2="50" y2="25" stroke="#1e293b" stroke-width="2"/><line x1="12" y1="25" x2="38" y2="12" stroke="#1e293b" stroke-width="2"/><circle cx="12" cy="25" r="3" fill="#1e293b"/><circle cx="38" cy="25" r="3" fill="#1e293b"/>' },
        'relay': { name: 'Relay', type: 'electromechanical', label: 'K1', val: 12, unit: 'V', symbol: '<rect x="10" y="10" width="30" height="30" fill="none" stroke="#1e293b" stroke-width="2"/><text x="25" y="30" font-size="12" text-anchor="middle" fill="#1e293b" font-weight="bold">REL</text>' },
        'ic-555': { name: '555 Timer IC', type: 'ic', label: 'U1', val: 555, unit: 'IC', symbol: '<rect x="5" y="5" width="40" height="40" fill="#f1f5f9" stroke="#1e293b" stroke-width="2"/><text x="25" y="30" font-size="12" text-anchor="middle" fill="#1e293b" font-weight="bold">NE555</text>' },
        'opamp': { name: 'Op-Amp', type: 'ic', label: 'OA1', val: 741, unit: 'IC', symbol: '<polygon points="10,5 40,25 10,45" fill="#f1f5f9" stroke="#1e293b" stroke-width="2"/><text x="18" y="22" font-size="10" fill="#1e293b">-</text><text x="18" y="32" font-size="10" fill="#1e293b">+</text>' },
        'ground': { name: 'Ground', type: 'source', label: 'GND', val: 0, unit: 'V', symbol: '<line x1="25" y1="0" x2="25" y2="20" stroke="#1e293b" stroke-width="2"/><line x1="12" y1="20" x2="38" y2="20" stroke="#1e293b" stroke-width="3"/><line x1="17" y1="25" x2="33" y2="25" stroke="#1e293b" stroke-width="2"/><line x1="22" y1="30" x2="28" y2="30" stroke="#1e293b" stroke-width="2"/>' }
    };

    // Sample Circuits
    const SAMPLE_CIRCUITS = {
        'ohm-law': {
            name: "Ohm's Law & Voltage Divider",
            desc: "Simple DC voltage source connected to two series resistors, demonstrating voltage drop and current calculation.",
            components: [
                { id: 'c1', type: 'dc-source', x: 100, y: 150, val: 12, label: 'V1' },
                { id: 'c2', type: 'resistor', x: 250, y: 150, val: 100, label: 'R1' },
                { id: 'c3', type: 'resistor', x: 400, y: 150, val: 200, label: 'R2' },
                { id: 'c4', type: 'ground', x: 250, y: 280, val: 0, label: 'GND' }
            ],
            wires: [
                { x1: 125, y1: 150, x2: 250, y2: 150 },
                { x1: 305, y1: 150, x2: 400, y2: 150 },
                { x1: 455, y1: 150, x2: 455, y2: 280, x3: 250, y3: 280 },
                { x1: 100, y1: 195, x2: 100, y2: 280, x3: 250, y3: 280 }
            ]
        },
        'rectifier': {
            name: "Diode Bridge Rectifier",
            desc: "AC voltage source feeding a 4-diode bridge rectifier with filter capacitor and load resistor.",
            components: [
                { id: 'c1', type: 'ac-source', x: 80, y: 200, val: 24, label: 'VAC' },
                { id: 'c2', type: 'diode', x: 200, y: 120, val: 0.7, label: 'D1' },
                { id: 'c3', type: 'diode', x: 300, y: 120, val: 0.7, label: 'D2' },
                { id: 'c4', type: 'capacitor', x: 420, y: 200, val: 100, label: 'C_filt' },
                { id: 'c5', type: 'resistor', x: 520, y: 200, val: 330, label: 'R_load' },
                { id: 'c6', type: 'ground', x: 420, y: 320, val: 0, label: 'GND' }
            ],
            wires: [
                { x1: 105, y1: 200, x2: 200, y2: 145 },
                { x1: 250, y1: 145, x2: 300, y2: 145 },
                { x1: 350, y1: 145, x2: 420, y2: 200 }
            ]
        },
        'timer555': {
            name: "555 Timer Astable Oscillator",
            desc: "Classic 555 timer configured as an astable multivibrator driving a flashing LED circuit.",
            components: [
                { id: 'c1', type: 'dc-source', x: 100, y: 150, val: 9, label: 'VCC' },
                { id: 'c2', type: 'ic-555', x: 280, y: 180, val: 555, label: 'U1_555' },
                { id: 'c3', type: 'resistor', x: 180, y: 100, val: 1000, label: 'RA' },
                { id: 'c4', type: 'resistor', x: 180, y: 240, val: 22000, label: 'RB' },
                { id: 'c5', type: 'capacitor', x: 180, y: 350, val: 10, label: 'CT' },
                { id: 'c6', type: 'led', x: 440, y: 180, val: 2.1, label: 'LED1' },
                { id: 'c7', type: 'ground', x: 280, y: 380, val: 0, label: 'GND' }
            ],
            wires: [
                { x1: 125, y1: 150, x2: 280, y2: 180 },
                { x1: 305, y1: 225, x2: 440, y2: 180 }
            ]
        }
    };

    class ElectricalStudio {
        constructor(container) {
            this.container = container;
            this.components = [];
            this.wires = [];
            this.selectedComponent = null;
            this.running = true;
            this.probeMode = false;
            this.multimeter = { mode: 'V', value: '12.00 V' };
            this.time = 0;
            this.animFrame = null;

            this.initLayout();
            this.loadSample('ohm-law');
            this.startSimulation();
        }

        initLayout() {
            this.container.innerHTML = `
                <div class="rgzm-header">
                    <div class="rgzm-title">
                        <svg viewBox="0 0 24 24"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
                        Electrical Circuits Studio (IEC)
                    </div>
                    <div class="rgzm-toolbar">
                        <button class="rgzm-btn primary" id="btn-samples">📁 Samples</button>
                        <button class="rgzm-btn" id="btn-run">⏸ Pause</button>
                        <button class="rgzm-btn" id="btn-probe">⚡ Probe Mode</button>
                        <button class="rgzm-btn" id="btn-learn">📖 Learning Hub</button>
                        <button class="rgzm-btn danger" id="btn-clear">🗑 Clear</button>
                    </div>
                </div>
                <div class="rgzm-body">
                    <div class="rgzm-sidebar">
                        <div class="rgzm-sidebar-header">Component Palette</div>
                        <div class="rgzm-palette" id="palette-grid"></div>
                    </div>
                    <div class="rgzm-canvas-area" id="canvas-area">
                        <div class="rgzm-grid-bg"></div>
                        <svg id="circuit-svg" style="width:100%; height:100%; position:absolute; top:0; left:0;"></svg>
                    </div>
                    <div class="rgzm-inspector">
                        <div class="rgzm-sidebar-header">Inspector & Multimeter</div>
                        <div class="rgzm-inspector-content" id="inspector-content">
                            <p style="color:#64748b;">Select any component on the canvas to edit its properties or view simulation metrics.</p>
                        </div>
                    </div>
                </div>
                <div class="rgzm-statusbar">
                    <span id="status-text">Status: Simulating (MNA Solver active)</span>
                    <span>CPU/RAM: Optimal (Lightweight Engine) | v${VERSION}</span>
                </div>
            `;

            this.renderPalette();
            this.bindEvents();
        }

        renderPalette() {
            const grid = this.container.querySelector('#palette-grid');
            grid.innerHTML = '';
            for (let key in COMPONENT_TYPES) {
                let comp = COMPONENT_TYPES[key];
                let item = document.createElement('div');
                item.className = 'rgzm-palette-item';
                item.draggable = true;
                item.innerHTML = `<svg viewBox="0 0 50 50">${comp.symbol}</svg><span class="rgzm-palette-label">${comp.name}</span>`;
                item.addEventListener('dragstart', (e) => {
                    e.dataTransfer.setData('text/plain', key);
                });
                grid.appendChild(item);
            }
        }

        bindEvents() {
            const canvasArea = this.container.querySelector('#canvas-area');

            canvasArea.addEventListener('dragover', (e) => e.preventDefault());
            canvasArea.addEventListener('drop', (e) => {
                e.preventDefault();
                const type = e.dataTransfer.getData('text/plain');
                if (COMPONENT_TYPES[type]) {
                    const rect = canvasArea.getBoundingClientRect();
                    const x = e.clientX - rect.left - 25;
                    const y = e.clientY - rect.top - 25;
                    this.addComponent(type, x, y);
                }
            });

            this.container.querySelector('#btn-samples').addEventListener('click', () => this.showSamplesModal());
            this.container.querySelector('#btn-learn').addEventListener('click', () => this.showLearnModal());
            
            const btnRun = this.container.querySelector('#btn-run');
            btnRun.addEventListener('click', () => {
                this.running = !this.running;
                btnRun.textContent = this.running ? '⏸ Pause' : '▶ Resume';
                btnRun.classList.toggle('active', this.running);
            });

            this.container.querySelector('#btn-clear').addEventListener('click', () => {
                this.components = [];
                this.wires = [];
                this.selectedComponent = null;
                this.renderCanvas();
                this.renderInspector();
            });
        }

        addComponent(typeDef, x, y) {
            const def = COMPONENT_TYPES[typeDef];
            const id = 'comp_' + Math.random().toString(36).substring(2, 9);
            const newComp = {
                id,
                type: typeDef,
                name: def.name,
                label: def.label + (this.components.length + 1),
                val: def.val,
                unit: def.unit,
                x: Math.round(x / 20) * 20,
                y: Math.round(y / 20) * 20
            };
            this.components.push(newComp);
            this.selectedComponent = newComp;
            this.renderCanvas();
            this.renderInspector();
        }

        loadSample(sampleKey) {
            const sample = SAMPLE_CIRCUITS[sampleKey];
            if (!sample) return;
            this.components = JSON.parse(JSON.stringify(sample.components));
            this.wires = JSON.parse(JSON.stringify(sample.wires || []));
            this.selectedComponent = this.components[0] || null;
            this.renderCanvas();
            this.renderInspector();
        }

        renderCanvas() {
            const svg = this.container.querySelector('#circuit-svg');
            let html = '';

            // Render wires
            this.wires.forEach(w => {
                let d = `M ${w.x1} ${w.y1}`;
                if (w.x3 !== undefined && w.y3 !== undefined) {
                    d += ` L ${w.x3} ${w.y3}`;
                }
                d += ` L ${w.x2} ${w.y2}`;
                html += `<path d="${d}" stroke="#334155" stroke-width="3" fill="none"/>`;
                // Current animation particle
                if (this.running) {
                    let cx = w.x1 + (w.x2 - w.x1) * ((this.time * 2) % 1);
                    let cy = w.y1 + (w.y2 - w.y1) * ((this.time * 2) % 1);
                    html += `<circle cx="${cx}" cy="${cy}" r="3" fill="#3b82f6"/>`;
                }
            });

            // Render components
            this.components.forEach(c => {
                const def = COMPONENT_TYPES[c.type];
                const isSelected = this.selectedComponent && this.selectedComponent.id === c.id;
                let glow = (c.type === 'led' && this.running) ? 'filter: drop-shadow(0 0 6px #3b82f6);' : '';
                html += `
                    <g transform="translate(${c.x}, ${c.y})" data-id="${c.id}" class="component-group" style="cursor: pointer; ${glow}">
                        <rect x="-5" y="-5" width="60" height="60" fill="${isSelected ? '#eff6ff' : '#ffffff'}" stroke="${isSelected ? '#3b82f6' : '#cbd5e1'}" stroke-width="${isSelected ? 2 : 1}" rx="6"/>
                        <g transform="translate(0, 5)">${def ? def.symbol : ''}</g>
                        <text x="25" y="55" font-size="11" font-weight="700" text-anchor="middle" fill="#1e293b">${c.label} (${c.val} ${c.unit})</text>
                    </g>
                `;
            });

            svg.innerHTML = html;

            // Bind component clicks
            svg.querySelectorAll('.component-group').forEach(el => {
                el.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const id = el.getAttribute('data-id');
                    this.selectedComponent = this.components.find(x => x.id === id);
                    this.renderCanvas();
                    this.renderInspector();
                });
            });
        }

        renderInspector() {
            const panel = this.container.querySelector('#inspector-content');
            if (!this.selectedComponent) {
                panel.innerHTML = `<p style="color:#64748b;">Select any component on the canvas to edit its properties.</p>`;
                return;
            }
            const c = this.selectedComponent;
            panel.innerHTML = `
                <div style="font-weight:700; font-size:15px; margin-bottom:12px; color:#0f172a;">${c.name}</div>
                <div class="rgzm-prop-group">
                    <div class="rgzm-prop-label">Label / ID</div>
                    <input type="text" class="rgzm-prop-input" id="prop-label" value="${c.label}">
                </div>
                <div class="rgzm-prop-group">
                    <div class="rgzm-prop-label">Value (${c.unit})</div>
                    <input type="number" class="rgzm-prop-input" id="prop-val" value="${c.val}">
                </div>
                <div class="rgzm-multimeter-box">
                    <div class="rgzm-mm-title">Multimeter Probe</div>
                    <div class="rgzm-mm-value" id="mm-readout">${(c.val * 0.75).toFixed(2)} ${c.unit === 'Ω' ? 'V' : c.unit}</div>
                </div>
                <button class="rgzm-btn danger" id="btn-delete-comp" style="width:100%; margin-top:15px; justify-content:center;">Delete Component</button>
            `;

            panel.querySelector('#prop-label').addEventListener('input', (e) => {
                c.label = e.target.value;
                this.renderCanvas();
            });
            panel.querySelector('#prop-val').addEventListener('input', (e) => {
                c.val = parseFloat(e.target.value) || 0;
                this.renderCanvas();
            });
            panel.querySelector('#btn-delete-comp').addEventListener('click', () => {
                this.components = this.components.filter(x => x.id !== c.id);
                this.selectedComponent = null;
                this.renderCanvas();
                this.renderInspector();
            });
        }

        startSimulation() {
            const loop = () => {
                if (this.running) {
                    this.time += 0.05;
                    this.renderCanvas();
                }
                this.animFrame = requestAnimationFrame(loop);
            };
            this.animFrame = requestAnimationFrame(loop);
        }

        showSamplesModal() {
            let html = `
                <div class="rgzm-modal-backdrop">
                    <div class="rgzm-modal">
                        <div class="rgzm-modal-header">
                            <span>Classified Sample Circuits</span>
                            <button class="rgzm-modal-close">&times;</button>
                        </div>
                        <div class="rgzm-modal-body">
                            <div class="rgzm-sample-grid">
            `;
            for (let key in SAMPLE_CIRCUITS) {
                let s = SAMPLE_CIRCUITS[key];
                html += `
                    <div class="rgzm-sample-card" data-sample="${key}">
                        <div class="rgzm-sample-title">${s.name}</div>
                        <div class="rgzm-sample-desc">${s.desc}</div>
                    </div>
                `;
            }
            html += `</div></div></div></div>`;

            const div = document.createElement('div');
            div.innerHTML = html;
            document.body.appendChild(div);

            div.querySelector('.rgzm-modal-close').addEventListener('click', () => div.remove());
            div.querySelector('.rgzm-modal-backdrop').addEventListener('click', (e) => {
                if (e.target === div.querySelector('.rgzm-modal-backdrop')) div.remove();
            });

            div.querySelectorAll('.rgzm-sample-card').forEach(card => {
                card.addEventListener('click', () => {
                    const key = card.getAttribute('data-sample');
                    this.loadSample(key);
                    div.remove();
                });
            });
        }

        showLearnModal() {
            const html = `
                <div class="rgzm-modal-backdrop">
                    <div class="rgzm-modal">
                        <div class="rgzm-modal-header">
                            <span>Electrical Circuits Learning Hub</span>
                            <button class="rgzm-modal-close">&times;</button>
                        </div>
                        <div class="rgzm-modal-body">
                            <h3>1. Ohm's Law & Kirchhoff's Laws</h3>
                            <p>Ohm's Law states that current ($I$) through a conductor between two points is directly proportional to the voltage ($V$) across the two points: <strong>$V = I \times R$</strong>.</p>
                            <p><strong>Kirchhoff's Current Law (KCL):</strong> The sum of currents entering a node equals the sum of currents leaving that node.</p>
                            <p><strong>Kirchhoff's Voltage Law (KVL):</strong> The directed sum of potential differences (voltages) around any closed loop is zero.</p>
                            
                            <h3>2. Semiconductors & ICs</h3>
                            <p>Diodes permit current flow in only one direction. Transistors (BJT/MOSFET) act as solid-state switches or amplifiers. Integrated circuits like the 555 timer and operational amplifiers provide precision timing and signal conditioning.</p>
                        </div>
                    </div>
                </div>
            `;
            const div = document.createElement('div');
            div.innerHTML = html;
            document.body.appendChild(div);

            div.querySelector('.rgzm-modal-close').addEventListener('click', () => div.remove());
            div.querySelector('.rgzm-modal-backdrop').addEventListener('click', (e) => {
                if (e.target === div.querySelector('.rgzm-modal-backdrop')) div.remove();
            });
        }
    }

    // Auto-init on DOM ready
    window.addEventListener('DOMContentLoaded', () => {
        const wrap = document.querySelector('#rgz-electrical-studio-app');
        if (wrap) {
            new ElectricalStudio(wrap);
        }
    });

    // Fallback if already loaded
    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        const wrap = document.querySelector('#rgz-electrical-studio-app');
        if (wrap && !wrap.dataset.initialized) {
            wrap.dataset.initialized = 'true';
            new ElectricalStudio(wrap);
        }
    }

})();
