<?php
if (!defined('ABSPATH')) { exit; }

final class RGZ_Electrical_Circuits_Studio {
    const VERSION = '1.0.0';

    public static function render_shortcode($atts = []) {
        $path = plugin_dir_path(__FILE__);
        $url  = plugin_dir_url(__FILE__);

        if (file_exists($path . 'app.css')) {
            wp_enqueue_style('rgz-elec-app-css', $url . 'app.css', [], self::VERSION . '-' . filemtime($path . 'app.css'));
        }
        if (file_exists($path . 'app.js')) {
            wp_enqueue_script('rgz-elec-app-js', $url . 'app.js', [], self::VERSION . '-' . filemtime($path . 'app.js'), true);
        }

        ob_start();
        ?>
        <div id="rgz-electrical-studio-app" class="rgzd rgzm-studio-wrap">
            <div style="padding: 40px; text-align: center; color: #64748b; font-size: 15px;">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#3b82f6" stroke-width="2" style="margin-bottom: 15px; animation: spin 2s linear infinite;"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
                <div style="font-weight: 700; color: #1e293b; margin-bottom: 5px;">Loading Electrical Circuits Studio...</div>
                <div>Initializing IEC schematic engine and Kirchhoff's MNA solver.</div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
