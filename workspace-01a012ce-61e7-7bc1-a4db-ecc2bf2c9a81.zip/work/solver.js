/*! RGZ Fluid Power Solver - nodal network engine (oil + air), production version.
    Self-contained single function so it can be embedded into the Web Worker blob
    via Function#toString and also run on the main thread as fallback.

    Model summary
    - Nodes = connected fluid ports (non-electrical lines). Lines are resistive
      edges (tube ID + length). Tanks/exhausts are ground anchors.
    - Valves are (possibly state-dependent, nonlinear) conductances: directional
      valves incl. all center types, check/pilot-check, relief (with override),
      reducing (downstream regulating), sequence, counterbalance, flow controls
      (needle characteristic + optional pressure compensation), shuttles
      (OR/AND), quick-exhaust, shut-offs, cartridge variants, servo/proportional.
    - Pumps/compressors are flow sources (variable units destroke at their
      compensator setting). Accumulators are gas-charged pressure offsets whose
      charge integrates over time (simChargeL prop).
    - Cylinders are motion boundary conditions: force balance from chamber
      pressures decides direction, flow availability sets the speed; cavitation
      floor and end-stops included. Position integrates on the main thread.
    API: rgzFluidSolve({fluid:'oil'|'air', components, connections, dt, time}) */
function rgzFluidSolve(opts) {
  "use strict";
  opts = opts || {};
  var FLUID = opts.fluid === "air" ? "air" : "oil";
  var comps = opts.components || [];
  var conns = opts.connections || [];
  var TIME = num(opts.time, 0), DT = num(opts.dt, 0);

  function num(v, f) { var n = Number(v); return Number.isFinite(n) ? n : f; }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  /* Load profiles — two syntaxes:
     1) Point table: "x, load" per line/semicolon — x = seconds (time-based) or
        stroke fraction 0..1 / rev fraction (position-based), load in kg (cyl)
        or N·m (motor). Linear interpolation, clamped ends.
     2) Formula: any math in t (sim seconds) and/or x (stroke or rev fraction
        0..1), evaluated fresh every tick — e.g. "800 + 400*sin(2*pi*t)",
        "min(2500, 3000*x^2)", "if(t<1, 200, 900)". Both variables are bound
        at the same time, so mixed laws like "sin(t) + 800*x" work. */
  var EXPR_CACHE = rgzFluidSolve._expr || (rgzFluidSolve._expr = {});
  var EXPR_FUNS = {
    abs: Math.abs, sqrt: Math.sqrt, cbrt: Math.cbrt, exp: Math.exp, ln: Math.log,
    log: Math.log10, pow: Math.pow, min: Math.min, max: Math.max,
    sin: Math.sin, cos: Math.cos, tan: Math.tan, asin: Math.asin, acos: Math.acos,
    atan: Math.atan, atan2: Math.atan2, sinh: Math.sinh, cosh: Math.cosh, tanh: Math.tanh,
    floor: Math.floor, ceil: Math.ceil, round: Math.round, sign: Math.sign,
    fract: function (v) { return v - Math.floor(v); },
    clamp: function (v, a, b) { return v < a ? a : v > b ? b : v; },
    step: function (edge, v) { return v >= edge ? 1 : 0; },
    pulse: function (v, a, b) { return v >= a && v < b ? 1 : 0; },
    ramp: function (v, a, b) { return b === a ? (v >= a ? 1 : 0) : clamp((v - a) / (b - a), 0, 1); },
    hypot: Math.hypot, deg: function (r) { return r * 180 / Math.PI; }, rad: function (dg) { return dg * Math.PI / 180; },
  };
  function exprTokens(src) {
    var re = /\s*(?:((?:[0-9]*\.[0-9]+|[0-9]+\.?[0-9]*)(?:[eE][+-]?[0-9]+)?)|([A-Za-z_][A-Za-z0-9_]*)|(<=|>=|==|!=|[-+*/%^(),<>]))/y;
    var out = [], m, guard = 0;
    re.lastIndex = 0;
    while (re.lastIndex < src.length) {
      var i0 = re.lastIndex;
      m = re.exec(src);
      if (!m) throw new Error("token");
      if (m[1] !== undefined) out.push({ n: parseFloat(m[1]) });
      else if (m[2] !== undefined) out.push({ f: m[2].toLowerCase() });
      else if (m[3] !== undefined) out.push({ o: m[3] });
      if (re.lastIndex === i0 || ++guard > 4000) throw new Error("token");
    }
    return out;
  }
  function compileExpr(src) {
    var key = String(src);
    if (key in EXPR_CACHE) return EXPR_CACHE[key];
    var fn = null;
    try {
      var toks = exprTokens(key), pos = 0;
      function peek() { return toks[pos] || null; }
      function err() { throw new Error("parse"); }
      function parseCmp() {
        var l = parseAdd(), k = peek();
        if (k && k.o && (k.o === "<" || k.o === ">" || k.o === "<=" || k.o === ">=" || k.o === "==" || k.o === "!=")) {
          pos++;
          var r = parseAdd();
          if (k.o === "<") return function (t, x) { return l(t, x) < r(t, x) ? 1 : 0; };
          if (k.o === ">") return function (t, x) { return l(t, x) > r(t, x) ? 1 : 0; };
          if (k.o === "<=") return function (t, x) { return l(t, x) <= r(t, x) ? 1 : 0; };
          if (k.o === ">=") return function (t, x) { return l(t, x) >= r(t, x) ? 1 : 0; };
          if (k.o === "==") return function (t, x) { return l(t, x) === r(t, x) ? 1 : 0; };
          return function (t, x) { return l(t, x) !== r(t, x) ? 1 : 0; };
        }
        return l;
      }
      function parseAdd() {
        var l = parseMul(), k;
        while ((k = peek()) && k.o && (k.o === "+" || k.o === "-")) {
          pos++;
          var r = parseMul();
          if (k.o === "+") (function (a, b) { l = function (t, x) { return a(t, x) + b(t, x); }; })(l, r);
          else (function (a, b) { l = function (t, x) { return a(t, x) - b(t, x); }; })(l, r);
        }
        return l;
      }
      function parseMul() {
        var l = parseUnary(), k;
        while ((k = peek()) && k.o && (k.o === "*" || k.o === "/" || k.o === "%")) {
          pos++;
          var r = parseUnary();
          if (k.o === "*") (function (a, b) { l = function (t, x) { return a(t, x) * b(t, x); }; })(l, r);
          else if (k.o === "/") (function (a, b) { l = function (t, x) { return b(t, x) === 0 ? 0 : a(t, x) / b(t, x); }; })(l, r);
          else (function (a, b) { l = function (t, x) { var m = b(t, x); return m === 0 ? 0 : a(t, x) % m; }; })(l, r);
        }
        return l;
      }
      function parseUnary() {
        var k = peek();
        if (k && k.o === "-") { pos++; var u = parseUnary(); return function (t, x) { return -u(t, x); }; }
        if (k && k.o === "+") { pos++; return parseUnary(); }
        return parsePow();
      }
      function parsePow() {
        var base = parseAtom(), k = peek();
        if (k && k.o === "^") {
          pos++;
          var ex = parseUnary(); // right-assoc, binds tighter than unary minus
          return function (t, x) { var v = Math.pow(base(t, x), ex(t, x)); return Number.isFinite(v) ? v : 0; };
        }
        return base;
      }
      function parseAtom() {
        var k = peek();
        if (!k) err();
        if (k.n !== undefined) { pos++; var v = k.n; return function () { return v; }; }
        if (k.o === "(") {
          pos++;
          var e0 = parseCmp();
          var c = peek(); if (!c || c.o !== ")") err();
          pos++;
          return e0;
        }
        if (k.f !== undefined) {
          pos++;
          var name = k.f;
          if (name === "t") return function (t) { return t; };
          if (name === "x") return function (t2, x) { return x; };
          if (name === "pi") return function () { return Math.PI; };
          if (name === "tau") return function () { return 2 * Math.PI; };
          if (name === "e") return function () { return Math.E; };
          {
            var fnk = k.f === "if" ? function (c2, a2, b2) { return c2 ? a2 : b2; } : EXPR_FUNS[k.f];
            if (!fnk) err();
            var p0 = peek(); if (!p0 || p0.o !== "(") err();
            pos++;
            var args = [];
            if (!(peek() && peek().o === ")")) {
              args.push(parseCmp());
              while (peek() && peek().o === ",") { pos++; args.push(parseCmp()); }
            }
            var p1 = peek(); if (!p1 || p1.o !== ")") err();
            pos++;
            return function (t, x) {
              var vals = new Array(args.length);
              for (var iA = 0; iA < args.length; iA++) vals[iA] = args[iA](t, x);
              var rv = fnk.apply(null, vals);
              return Number.isFinite(rv) ? rv : 0;
            };
          }
          err();
        }
        err();
      }
      var parsed = parseCmp();
      if (pos !== toks.length) err();
      fn = function (t, x) {
        var v = parsed(num(t, 0), num(x, 0));
        return Number.isFinite(v) ? v : null;
      };
    } catch (eParse) { fn = null; }
    EXPR_CACHE[key] = fn;
    return fn;
  }
  function profileVal(str, axis, t, x) {
    if (!str) return null;
    var rows, pts = [], i, pair, a, b;
    var s = String(str).trim();
    if (!s) return null;
    var tableLike = /^[-0-9eE,;.\s+]+$/.test(s) && s.indexOf(",") >= 0;
    if (tableLike) {
      rows = s.split(/[;\n]+/);
      for (i = 0; i < rows.length; i++) {
        pair = rows[i].split(",");
        a = parseFloat(pair[0]); b = parseFloat(pair[1]);
        if (Number.isFinite(a) && Number.isFinite(b)) pts.push([a, b]);
      }
      if (pts.length) {
        pts.sort(function (p1, p2) { return p1[0] - p2[0]; });
        var xv = num(axis, 0);
        if (xv <= pts[0][0]) return pts[0][1];
        if (xv >= pts[pts.length - 1][0]) return pts[pts.length - 1][1];
        for (i = 1; i < pts.length; i++) {
          if (xv <= pts[i][0]) {
            var x0 = pts[i - 1][0], x1 = pts[i][0], y0 = pts[i - 1][1], y1 = pts[i][1];
            return y0 + (y1 - y0) * (x1 === x0 ? 0 : (xv - x0) / (x1 - x0));
          }
        }
        return pts[pts.length - 1][1];
      }
    }
    var f = compileExpr(s);
    return f ? f(num(t, 0), num(x, 0)) : null;
  }
  function warnProfileOnce(key, label, isMotor) {
    var bag = DYN.warnProf || (DYN.warnProf = {});
    if (bag[key]) return;
    bag[key] = 1;
    warnings.push((label || (isMotor ? "Motor" : "Cylinder")) + ": load profile could not be parsed — using the constant " +
      (isMotor ? "torque" : "load") + ". Use 'value, load' points or a formula in t and x, e.g. 800 + 400*sin(2*pi*t).");
  }
  /* current load (kg) for a cylinder component at this tick */
  function cylLoadKg(P, pos, comp) {
    var mode = String(P.loadMode || "constant");
    if (mode === "time-based" || mode === "position-based" || mode.indexOf("formula") === 0) {
      var axis = mode === "position-based" ? pos : TIME;
      var pv = profileVal(P.loadProfile, axis, TIME, pos);
      if (pv != null) return Math.max(0, pv);
      if (String(P.loadProfile || "").trim()){
        var t0 = compileExpr(String(P.loadProfile).trim());
        // wrong syntax path only — nothing more to do here
        if (!t0) warnProfileOnce(comp ? comp.id : "cyl", comp && comp.label, false);
      }
    }
    return Math.max(0, num(P.loadKg, 0));
  }
  /* current torque load (N·m) for a motor component at this tick */
  function motorLoadNm(P, comp) {
    var mode = String(P.loadMode || "constant");
    if (mode === "time-based" || mode === "position-based" || mode.indexOf("formula") === 0) {
      var ang = num(P.simAngle, 0) / (2 * Math.PI);
      ang = ang - Math.floor(ang);
      var pv = profileVal(P.loadProfile, mode === "position-based" ? ang : TIME, TIME, ang);
      if (pv != null) return pv;
      if (String(P.loadProfile || "").trim() && !compileExpr(String(P.loadProfile).trim())) {
        warnProfileOnce(comp ? comp.id : "mot", comp && comp.label, true);
      }
    }
    return Math.max(0, num(P.loadNm, 0));
  }

  // ---- persistent per-run state (spool timers, cylinder motion, pressure memory)
  var DYN = rgzFluidSolve._dyn;
  if (!DYN || num(TIME, 0) < num(DYN.tNow, 0) - 1e-9) {
    DYN = rgzFluidSolve._dyn = { t: {}, cyl: {}, p: {}, tNow: 0 };
  }
  DYN.tNow = TIME;

  var FLOOR = FLUID === "air" ? -1.0 : -0.9;       // cavitation / vacuum floor, bar
  var LEAK = FLUID === "air" ? 6e-4 : 1.2e-4;      // parasitic leak, L/min/bar
  var PATM = 1.01325;
  var warnings = [];

  var intensPairs = [], vacPairs = [], accumEdges = [], regulators = [], dividers = [];

  // ---------- node registry: one node per referenced port ----------
  var compById = {};
  comps.forEach(function (c) { compById[c.id] = c; });
  var nodeIdx = {}, nodeKeys = [], nodeComp = [], nodePort = [];
  function nodeId(cid, pid, create) {
    var k = cid + "." + pid;
    if (k in nodeIdx) return nodeIdx[k];
    if (!create) return -1;
    nodeIdx[k] = nodeKeys.length; nodeKeys.push(k); nodeComp.push(cid); nodePort.push(pid);
    return nodeIdx[k];
  }
  function pOf(cid, pid) { return nodeId(cid, pid, false); }

  var fluidLines = [];
  conns.forEach(function (c) {
    if (!c || c.lineType === "electrical") return;
    var a = compById[c.from && c.from.componentId], b = compById[c.to && c.to.componentId];
    if (!a || !b) return;
    if (a.type === "textLabel" || b.type === "textLabel") return;
    nodeId(c.from.componentId, c.from.portId, true);
    nodeId(c.to.componentId, c.to.portId, true);
    fluidLines.push(c);
  });
  var N = nodeKeys.length;
  var portConnCount = {};
  fluidLines.forEach(function (c) {
    var k1 = c.from.componentId + "." + c.from.portId, k2 = c.to.componentId + "." + c.to.portId;
    portConnCount[k1] = (portConnCount[k1] || 0) + 1;
    portConnCount[k2] = (portConnCount[k2] || 0) + 1;
  });
  function wired(cid, pid) { return (portConnCount[cid + "." + pid] || 0) > 0; }

  // ---------- edge / source containers ----------
  var edges = [], injections = [];
  function addG(a, b, g, tag, cid) {
    if (a < 0 || b < 0 || !(g > 0)) return null;
    var e = { a: a, b: b, g: g, dyn: null, tag: tag || "", compId: cid || null, flow: 0 };
    edges.push(e); return e;
  }
  function addDynG(a, b, fn, tag, cid) { // fn(pA,pB,edge,pAll) -> conductance L/min/bar
    if (a < 0) return null;
    var e = { a: a, b: (b == null ? -2 : b), g: 0, dyn: fn, tag: tag || "", compId: cid || null, flow: 0 };
    edges.push(e); return e;
  }
  function addGnd(a, g, tag, cid) {
    if (a < 0 || !(g > 0)) return null;
    var e = { a: a, b: -1, g: g, dyn: null, tag: tag || "", compId: cid || null, flow: 0 };
    edges.push(e); return e;
  }
  function addSrc(node, q, tag, cid) {
    if (node < 0) return null;
    var s = { node: node, q: q, qNow: q, dynQ: null, tag: tag || "", compId: cid || null };
    injections.push(s); return s;
  }

  // ---------- conductance law helpers ----------
  function sqrt0(v) { return Math.sqrt(Math.max(v, 0)); }
  function orificeG(kv, dp) { return kv / Math.max(sqrt0(Math.abs(dp)), 0.05); }
  function airOrificeG(kv, pUp, dp) { return kv * sqrt0(Math.max(pUp, 0) + PATM) / Math.max(sqrt0(Math.abs(dp)), 0.05); }
  function kvFromRated(qRated, dpRated, fluidOverride) {
    var air = fluidOverride ? fluidOverride === "air" : FLUID === "air";
    if (air) return qRated / Math.max(sqrt0(7.013) * sqrt0(dpRated || 0.3), 0.05);
    return qRated / Math.max(sqrt0(dpRated || 5), 0.25);
  }
  function lineG(c) {
    var pr = (c && c.properties) || {};
    var d = Math.max(1.5, num(pr.tubeIdMm, FLUID === "air" ? 6 : 12));
    var L = clamp(num(pr.lengthM, 1), 0.05, 400);
    var q0, dp;
    if (FLUID === "air") {
      q0 = 250;
      dp = (0.0105 * L / Math.pow(d, 5.07)) * Math.pow(q0, 1.85) / 4.0;
      return Math.min(q0 / Math.max(dp, 0.002), 3000);
    }
    q0 = 25;
    dp = (0.1847 * L / Math.pow(d, 4)) * q0 + (0.068 * L / Math.pow(d, 4.75)) * Math.pow(q0, 1.75);
    return Math.min(q0 / Math.max(dp, 0.004), 350);
  }
  function reliefG(pUp, setB, qRated, e) { // clamp: Q = g*(p - setB) above setting, plain leak below
    var band = Math.max(2, 0.04 * setB);
    var frac = clamp((pUp - (setB - 0.6)) / band, 0, 1);
    if (e) e.off = frac > 0 ? setB - 0.6 : 0;
    var gFull = Math.max(num(qRated, 60) / 8, 2); // ~8 bar override at rated flow
    return LEAK * 0.02 + (gFull - LEAK * 0.02) * frac; // below crack: sealed-leak class
  }

  var BIGG = FLUID === "air" ? 4000 : 400;         // wide-open path, L/min/bar
  var G_GND = 1e6;

  // ---------- classify ----------
  var pumps = [], reliefs = [], cylinders = [], motors = [], accums = [], gauges = [], flowmeters = [], motorRecs = [];
  comps.forEach(function (c) {
    var t = c.type;
    if (t === "pumpFixed" || t === "pumpVariable" || t === "compressorFixed" || t === "compressorVariable" || t === "powerPack") pumps.push(c);
    if (t === "reliefValve" || t === "cartridgeReliefValve" || t === "powerPack") reliefs.push(c);
    if (t === "cylinderDA" || t === "cylinderSA") cylinders.push(c);
    if (t === "hydraulicMotor" || t === "pneumaticMotor") motors.push(c);
    if (t === "accumulator") accums.push(c);
    if (t === "pressureGauge" || t === "pressureSwitch" || t === "pressureTransducer" || t === "testPoint") gauges.push(c);
    if (t === "flowMeter" || t === "flowSwitch") flowmeters.push(c);
  });
  var reliefSetting = reliefs.length
    ? Math.min.apply(null, reliefs.map(function (c) { return num(c.props.settingBar != null ? c.props.settingBar : c.props.reliefSettingBar, 160); }))
    : (FLUID === "air" ? 8 : 160);

  // ---------- component models ----------
  comps.forEach(function (c) {
    var t = c.type, P = c.props || {};

    if (t === "powerPack") {
      var q = Math.max(0, num(P.flowLpm, 25));
      var iP = pOf(c.id, "P"), iT = pOf(c.id, "T");
      if (iT >= 0) addGnd(iT, G_GND, "tank", c.id);
      if (iP >= 0 && q > 0) addSrc(iP, q, "pump", c.id);
      var setB = num(P.reliefSettingBar, 160);
      if (iP >= 0) addDynG(iP, iT, function (pA, pB, e) { return reliefG(pA, setB, q, e); }, "relief", c.id);
      return;
    }
    if (t === "tank" || t === "exhaust" || t === "breatherFiller") {
      var iTk = pOf(c.id, "T"); if (iTk >= 0) addGnd(iTk, G_GND, "tank", c.id);
      return;
    }
    if (t === "silencer") {
      var iSi = pOf(c.id, "E");
      if (iSi >= 0) addGnd(iSi, Math.max(1400 / (1 + num(P.noiseReductionDb, 20) / 10), 15), "silencer", c.id);
      return;
    }
    if (t === "pumpFixed" || t === "compressorFixed") {
      var q2 = Math.max(0, num(P.flowLpm, 25)), iS = pOf(c.id, "S"), iP2 = pOf(c.id, "P");
      if (iS >= 0) addGnd(iS, G_GND, "suction", c.id);
      if (iP2 >= 0 && q2 > 0) {
        var mx = num(P.maxPressureBar, 180);
        var bandCut = Math.max(1.5, 0.05 * mx);
        var s0 = addSrc(iP2, q2, "pump", c.id);
        var cutOn = mx + bandCut * 0.4 - bandCut; // full flow below this
        s0.dynQ = function (pN) { return pN >= cutOn ? 0 : q2; };
        s0.dynS = function (pN) { return pN >= cutOn ? -q2 / bandCut : 0; };
        s0.qRef = cutOn + bandCut; // anchor: q = (q2/bandCut)*(qRef - p)
      }
      return;
    }
    if (t === "pumpVariable" || t === "compressorVariable") {
      var q3 = Math.max(0, num(P.flowLpm, 32)), iS2 = pOf(c.id, "S"), iP3 = pOf(c.id, "P");
      if (iS2 >= 0) addGnd(iS2, G_GND, "suction", c.id);
      if (iP3 >= 0 && q3 > 0) {
        var cp3 = num(P.compensatorBar, 160);
        var bandV = Math.max(0.06 * cp3, 2);
        var s1 = addSrc(iP3, q3, "pump", c.id);
        s1.dynQ = function (pN) { return pN >= cp3 - bandV ? 0 : q3; };
        s1.dynS = function (pN) { return pN >= cp3 - bandV ? -q3 / bandV : 0; };
        s1.qRef = cp3; // pressure-compensated: holds qRef when stroke drops to 0
      }
      return;
    }
    if (t === "reliefValve" || t === "cartridgeReliefValve") {
      var set2 = num(P.settingBar, 160);
      if (pOf(c.id, "P") >= 0) addDynG(pOf(c.id, "P"), pOf(c.id, "T"), function (pA, pB, e) { return reliefG(pA, set2, num(P.maxFlowLpm, 120), e); }, "relief", c.id);
      return;
    }
    if (t === "cartridgeUnloadingValve") {
      var setU = num(P.unloadBar, 120), iXU = pOf(c.id, "X");
      addDynG(pOf(c.id, "P"), pOf(c.id, "T"), function (pA, pB, e, p) {
        var px = iXU >= 0 ? p[iXU] : 0;
        return reliefG(Math.max(pA, px), setU, num(P.maxFlowLpm, 100), e);
      }, "relief", c.id);
      return;
    }
    if (t === "directionalValve" || t === "pneumaticMemoryValve") { modelDirectional(c); return; }
    if (t === "servoValve") { modelServo(c); return; }
    if (t === "checkValve" || t === "cartridgeCheckValve") {
      var cr = num(P.crackingBar, 0.5);
      var cidH = c.id;
      // Hysteresis (Schmitt trigger): a hard on/off edge flips when the opened valve
      // equalises its ports, and the relaxation then freezes it half-shut (phantom
      // trapped pressure in bypass branches -> e.g. 269 bar behind a stalled check).
      // Open at pA > pB + cr, close at pA < pB + 0.2*cr, hold state in between.
      addDynG(pOf(c.id, "A"), pOf(c.id, "B"), function (pA, pB) {
        var S = DYN.checkHyst || (DYN.checkHyst = {});
        var st = S[cidH] ? 1 : 0;
        if (pA > pB + cr) st = 1;
        else if (pA < pB + 0.2 * cr) st = 0;
        S[cidH] = st;
        return st ? BIGG * 0.5 : LEAK * 0.02;
      }, "check", c.id);
      return;
    }
    if (t === "pilotCheckValve") {
      var cr2 = num(P.crackingBar, 1), ratio = Math.max(1, num(P.pilotRatio, 3));
      var iX2 = pOf(c.id, "X");
      // Pilot piston mechanically unseats the poppet: no pB > pA guard — a real PO
      // check releases even against a fully depressurised load line (the old guard
      // locked the valve shut whenever the held pressure had leaked down, so the
      // return stroke stalled with the pump at relief).
      addDynG(pOf(c.id, "A"), pOf(c.id, "B"), function (pA, pB, e, p) {
        if (pA > pB + cr2) return BIGG * 0.5;
        var px = iX2 >= 0 ? p[iX2] : 0;
        if (px > 0.5 && px * ratio > pB - pA + cr2) return BIGG * 0.25;
        return LEAK * 0.02;
      }, "pcheck", c.id);
      return;
    }
    if (t === "counterbalanceValve" || t === "cartridgeCounterbalanceValve") {
      var set3 = num(P.settingBar, 120), r3 = Math.max(1, num(P.pilotRatio, 3)), iX3 = pOf(c.id, "X");
      addDynG(pOf(c.id, "A"), pOf(c.id, "B"), function (pA, pB, e, p) {
        if (pA > pB) return BIGG * 0.4;
        var px = iX3 >= 0 ? p[iX3] : 0;
        var frac = clamp((pB - (set3 - r3 * px)) / Math.max(2, 0.04 * set3) + 0.5, 0, 1);
        return LEAK * 0.02 + (BIGG * 0.2 - LEAK * 0.02) * frac;
      }, "cb", c.id);
      return;
    }
    if (t === "flowControl" || t === "cartridgeNeedleFlowValve") { modelFlowControl(c); return; }
    if (t === "reducingValve" || t === "cartridgeReducingValve") {
      var iPr = pOf(c.id, "P"), iAr = pOf(c.id, "A"), iTr = pOf(c.id, "T");
      if (iAr >= 0) regulators.push({
        cid: c.id, kind: "red", iP: iPr, iA: iAr, ventTo: iTr,
        set: num(P.outletBar, 45), gC: FLUID === "air" ? 60 : 25,
        gSup: BIGG * 0.5, gV: FLUID === "air" ? 8 : 1.5, qNow: 0,
      });
      return;
    }
    if (t === "sequenceValve" || t === "cartridgeSequenceValve") {
      var set4 = t === "cartridgeSequenceValve" ? num(P.sequenceBar, 70) : num(P.settingBar, 70);
      addDynG(pOf(c.id, "P"), pOf(c.id, "A"), function (pA) {
        return LEAK + (BIGG * 0.3 - LEAK) * clamp((pA - set4) / Math.max(2, 0.05 * set4) + 0.5, 0, 1);
      }, "seq", c.id);
      var iT4 = pOf(c.id, "T"); if (iT4 >= 0) addGnd(iT4, LEAK * 5, "drain", c.id);
      return;
    }
    if (t === "pressureCompensator") {
      var dpc = num(P.deltaPBar, 8), iXc = pOf(c.id, "X");
      addDynG(pOf(c.id, "P"), pOf(c.id, "A"), function (pA, pB, e, p) {
        var px = iXc >= 0 ? p[iXc] : pB;
        return BIGG * 0.3 * clamp((px + dpc - pB) / 2, 0, 1) + LEAK;
      }, "pc", c.id);
      return;
    }
    if (t === "logicCartridgeValve") {
      var iXl = pOf(c.id, "X");
      var ratio3 = Math.max(1, num(P.pilotRatio, 2));
      var cidL = c.id;
      // DIN 24342 slip-in poppet with control cover: the spring-side (cover) area
      // exceeds the ported areas, so X pressurised such that px*(area ratio)
      // exceeds the line pressure clamps the poppet shut; a vented/weak X leaves
      // it free to lift (opens from either port). Schmitt trigger on
      // px*ratio vs max(pA,pB,0) with a 0.3 bar band: a hard un-hysteresised law
      // (old "px + 0.3 > max*0.6") closed the valve at its own ~zero pressure
      // drop, and the geometric-mean relaxation then froze it half-shut, leaving
      // phantom back-pressure (258 bar) on an open leg — plus a wide close margin
      // let the piloted legs leak at low pilot pressure and short the bridge.
      addDynG(pOf(c.id, "A"), pOf(c.id, "B"), function (pA, pB, e, p) {
        var S = DYN.logicHyst || (DYN.logicHyst = {});
        var st = S[cidL] == null ? 1 : S[cidL];   // at rest (X vented) the poppet is free to lift
        var px = iXl >= 0 ? p[iXl] : 0;
        var pMax = Math.max(0, pA, pB);
        if (px * ratio3 > pMax + 0.15) st = 0;
        else if (px * ratio3 < pMax - 0.15) st = 1;
        S[cidL] = st;
        return st ? BIGG * 0.6 : LEAK * 0.02;
      }, "logic", c.id);
      return;
    }
    if (t === "shutoffValve") {
      addG(pOf(c.id, "A"), pOf(c.id, "B"), P.open === false ? LEAK * 0.02 : BIGG * 0.8, "shutoff", c.id);
      return;
    }
    if (t === "cartridgeSolenoidValve22") {
      var open22 = P.energized ? !P.normallyOpen : !!P.normallyOpen;
      addG(pOf(c.id, "P"), pOf(c.id, "A"), open22 ? BIGG * 0.5 : LEAK * 0.02, "cart22", c.id);
      return;
    }
    if (t === "shuttleValve" || t === "cartridgeShuttleValve" || t === "twoPressureValve") {
      var isAnd = t === "twoPressureValve";
      var iAs = pOf(c.id, "A"), iBs = pOf(c.id, "B"), iXs = pOf(c.id, "X");
      if (iXs >= 0) {
        if (iAs >= 0) addDynG(iAs, iXs, function (pA, pX, e, p) {
          var pb = iBs >= 0 ? p[iBs] : 0;
          return LEAK + (BIGG - LEAK) * (isAnd ? clamp((pb - pA) / 0.4 + 0.5, 0, 1) : clamp((pA - pb) / 0.4 + 0.5, 0, 1));
        }, isAnd ? "and" : "or", c.id);
        if (iBs >= 0) addDynG(iBs, iXs, function (pB, pX, e, p) {
          var pa = iAs >= 0 ? p[iAs] : 0;
          return LEAK + (BIGG - LEAK) * (isAnd ? clamp((pa - pB) / 0.4 + 0.5, 0, 1) : clamp((pB - pa) / 0.4 + 0.5, 0, 1));
        }, isAnd ? "and" : "or", c.id);
      }
      return;
    }
    if (t === "quickExhaustValve") {
      var iPq = pOf(c.id, "P"), iAq = pOf(c.id, "A"), iRq = pOf(c.id, "R");
      addDynG(iPq, iAq, function (pA, pB) { return pA >= pB - 0.05 ? BIGG * 0.7 : LEAK; }, "qe-in", c.id);
      if (iRq >= 0) {
        addDynG(iAq, iRq, function (pA, pB, e, p) { return pA > (iPq >= 0 ? p[iPq] : 0) - 0.05 ? BIGG * 1.2 : LEAK; }, "qe-out", c.id);
        addGnd(iRq, BIGG * 0.9, "qe-atm", c.id);
      } else {
        addDynG(iAq, -1, function (pA, pB, e, p) { return pA > (iPq >= 0 ? p[iPq] : 0) - 0.05 ? BIGG * 1.2 : LEAK; }, "qe-out", c.id);
      }
      return;
    }
    if (t === "softStartValve") {
      var iPs = pOf(c.id, "P"), iAs2 = pOf(c.id, "A"), iRs = pOf(c.id, "R"), keySs = "ss." + c.id;
      addDynG(iPs, iAs2, function (pA) {
        if (pA > 1) { if (!(keySs in DYN.t)) DYN.t[keySs] = TIME; } else delete DYN.t[keySs];
        var on = keySs in DYN.t ? clamp((TIME - DYN.t[keySs]) / Math.max(0.1, num(c.props.rampTimeS, 1.5)), 0, 1) : 0;
        return LEAK + BIGG * 0.6 * clamp(on, 0.04, 1);
      }, "softstart", c.id);
      if (iRs >= 0) {
        addDynG(iAs2, iRs, function (pA, pB, e, p) { return (iPs >= 0 ? p[iPs] : 0) < 0.5 ? BIGG * 0.8 : LEAK; }, "softdump", c.id);
        addGnd(iRs, BIGG * 0.5, "ss-atm", c.id);
      } else {
        addDynG(iAs2, -1, function (pA, pB, e, p) { return (iPs >= 0 ? p[iPs] : 0) < 0.5 ? BIGG * 0.8 : LEAK; }, "softdump", c.id);
      }
      return;
    }
    if (t === "pneumaticTimeDelayValve") {
      var iPt = pOf(c.id, "P"), iAt = pOf(c.id, "A"), iRt = pOf(c.id, "R"), keyTd = "td." + c.id;
      var tdElapsed = function (pIn) {
        if (pIn > 1) { if (!(keyTd in DYN.t)) DYN.t[keyTd] = TIME; }
        else { delete DYN.t[keyTd]; }
        return pIn > 1 && (TIME - DYN.t[keyTd] >= num(c.props.delayS, 1));
      };
      addDynG(iPt, iAt, function (pA) { return tdElapsed(pA) ? BIGG * 0.5 : LEAK * 2; }, "tdelay", c.id);
      if (iRt >= 0) {
        addDynG(iAt, iRt, function (pA, pB, e, p) { return !tdElapsed(iPt >= 0 ? p[iPt] : 0) ? BIGG * 0.6 : LEAK; }, "td-ex", c.id);
        addGnd(iRt, BIGG * 0.5, "td-atm", c.id);
      } else {
        addDynG(iAt, -1, function (pA, pB, e, p) { return !tdElapsed(iPt >= 0 ? p[iPt] : 0) ? BIGG * 0.6 : LEAK; }, "td-ex", c.id); // unwired R = open exhaust
      }
      return;
    }
    if (t === "flowDivider") {
      // Positive-displacement / spool flow divider-combiner: the branch carrying
      // MORE than its share must see extra resistance so the other branch gets
      // fed (a plain conductance ratio evaluates flows only once per solve call
      // — stale — so the first cylinder simply grabbed the whole pump and the
      // second never started). The ratio law below reads the live branch flows
      // directly from the current iterate (p[] x gNow) every assemble, and the
      // built-in geometric-mean damping of dynamic edges provides the
      // under-relaxation, giving a stable equalising fixed point: branch above
      // its share is throttled up to 10x, branch below up to 0.35x.
      // Positive-displacement / spool divider-combiner: it FORCES the flow that
      // arrives at the P port to split qA:qB = sA:(1-sA) whatever the two branch
      // loads are (the reason it exists: cylinder synchronisation). In nodal
      // terms it is a current device, not a resistance — every conductance-only
      // model lets the first actuator own the whole pump, so the two stages ran
      // strictly sequentially. Here the divider sinks whatever flow actually
      // reaches P and re-issues exactly sA / (1-sA) of it into the branches as
      // flow sources (combiner direction handled by sign). The cylinder
      // root-solve reads the branch sources as sustained supply, so both
      // actuators move on their shares at the same time; the measured inlet
      // flow is refreshed and damped after every network solve, so choking the
      // inlet (valve centred, relief dumping) throttles the split too. A tiny
      // primer conductance per branch seeds the flow feedback on cold start.
      var sA = clamp(num(P.splitPercentA, 50), 5, 95) / 100;
      var iPd = pOf(c.id, "P"), iAd = pOf(c.id, "A"), iBd = pOf(c.id, "B");
      var gPrim = FLUID === "air" ? 12 : 1;
      var sIn = iPd >= 0 ? addSrc(iPd, 0, "div-in", c.id) : null, sA1 = iAd >= 0 ? addSrc(iAd, 0, "div-a", c.id) : null, sB1 = iBd >= 0 ? addSrc(iBd, 0, "div-b", c.id) : null;
      if (iPd >= 0 && iAd >= 0) addG(iPd, iAd, gPrim, "div-primer", c.id);
      if (iPd >= 0 && iBd >= 0) addG(iPd, iBd, gPrim, "div-primer", c.id);
      if (!DYN.div) DYN.div = {};
      dividers.push({
        cid: c.id, iP: iPd, iA: iAd, iB: iBd, sA: sA,
        sIn: sIn, sA1: sA1, sB1: sB1, qIn: DYN.div[c.id] || 0, qMax: 5,
        inc: null,
      });
      if (sIn) sIn.divTag = 1; if (sA1) sA1.divTag = 1; if (sB1) sB1.divTag = 1;
      return;
    }
    if (t === "filter" || t === "cooler" || t === "suctionStrainer" || t === "oilHeater" || t === "flowMeter" || t === "flowSwitch") {
      addG(pOf(c.id, "A"), pOf(c.id, "B"), FLUID === "air" ? 900 : 90, "passive", c.id);
      return;
    }
    if (t === "junction" || t === "compressedAirDistributor") {
      var prts = [];
      for (var u2 = 0; u2 < N; u2++) if (nodeComp[u2] === c.id) prts.push(u2);
      for (var u3 = 1; u3 < prts.length; u3++) addG(prts[0], prts[u3], 2e4, "junction", c.id);
      return;
    }
    if (t === "cartridgeManifoldBlock") {
      // HIC through-galleries: P -> A (supply), T -> B (return). NOT a common junction.
      var iPm = pOf(c.id, "P"), iAm = pOf(c.id, "A"), iTm = pOf(c.id, "T"), iBm = pOf(c.id, "B");
      if (iPm >= 0 && iAm >= 0) addG(iPm, iAm, BIGG * 0.8, "manifoldPA", c.id);
      if (iTm >= 0 && iBm >= 0) addG(iTm, iBm, BIGG * 0.8, "manifoldTB", c.id);
      return;
    }
    if (t === "valveTerminal") {
      // Manifold valve island: P feeds the station outlets A1..A4 (common supply gallery);
      // B ports and R share the exhaust gallery. Passive manifold (per-station switching
      // is by the electrical layer); ports that are unwired simply stay isolated.
      var iPvt = pOf(c.id, "P"), iRvt = pOf(c.id, "R");
      ["A1", "A2", "A3", "A4"].forEach(function (pa) {
        var ia = pOf(c.id, pa);
        if (iPvt >= 0 && ia >= 0) addG(iPvt, ia, BIGG * 0.5, "vt-supply", c.id);
      });
      ["B1", "B2", "B3", "B4"].forEach(function (pb) {
        var ib = pOf(c.id, pb);
        if (iRvt >= 0 && ib >= 0) addG(iRvt, ib, BIGG * 0.5, "vt-exhaust", c.id);
      });
      return;
    }
    if (t === "frlUnit") {
      var iPf = pOf(c.id, "P"), iAf = pOf(c.id, "A");
      if (iAf >= 0) regulators.push({
        cid: c.id, kind: "frl", iP: iPf, iA: iAf, ventTo: -1,
        set: num(P.regulatorBar, 6), gC: 80, gSup: 1500, gV: 12, qNow: 0,
      });
      return;
    }
    if (t === "accumulator") {
      var iAa2 = pOf(c.id, "A");
      if (iAa2 >= 0) {
        var V0 = Math.max(0.2, num(P.volumeL, 5));
        var pre = Math.max(0, num(P.prechargeBar, 70));
        var stored = clamp(num(P.simChargeL, 0), 0, V0 * 0.98);
        var pAcc = pre * (V0 / Math.max(V0 - stored, 0.05 * V0));
        accumEdges.push({ comp: c, iA: iAa2, g: FLUID === "air" ? 150 : 15, pAcc: pAcc, stored: stored, V0: V0 });
      }
      return;
    }
    if (t === "hydraulicIntensifier") {
      var rt = Math.max(1.1, num(P.ratio, 2));
      addG(pOf(c.id, "P"), pOf(c.id, "A"), BIGG * 0.04, "intens", c.id);
      intensPairs.push({ iP: pOf(c.id, "P"), iA: pOf(c.id, "A"), rt: rt });
      var iTi = pOf(c.id, "T"); if (iTi >= 0) addGnd(iTi, BIGG * 0.4, "intensT", c.id);
      return;
    }
    if (t === "vacuumEjector") {
      var iPv = pOf(c.id, "P"), iVv = pOf(c.id, "V"), iRv = pOf(c.id, "R");
      var qv = num(P.airConsumptionLpm, 90);
      addDynG(iPv, iRv, function (pA) { return airOrificeG(kvFromRated(qv, 5.5), Math.max(pA, 0), Math.abs(pA)); }, "eject", c.id);
      if (iRv >= 0) addGnd(iRv, BIGG * 0.6, "eject-atm", c.id);
      if (iVv >= 0) vacPairs.push({ iV: iVv, vac: num(P.vacuumKpa, -65) / 100, g: BIGG * 0.4 });
      return;
    }
    if (t === "suctionCup") {
      var iVc = pOf(c.id, "V"); if (iVc >= 0) addGnd(iVc, Math.max(LEAK * 60, 0.02), "cup-leak", c.id);
      return;
    }
    if (t === "airBlowNozzle") {
      var iPn = pOf(c.id, "P");
      if (iPn >= 0) addGnd(iPn, airOrificeG(kvFromRated(num(P.flowLpm, 120), 6), 6, 6), "nozzle", c.id);
      return;
    }
    if (t === "hydraulicMotor" || t === "pneumaticMotor") {
      var disp0 = Math.max(1, num(P.displacementCcRev, 25));
      var offT = FLUID === "air" ? 0 : Math.max(0, motorLoadNm(P, c)) * 20 * Math.PI / disp0;
      var mrec = { id: c.id, iA: pOf(c.id, "A"), iB: pOf(c.id, "B"), locked: false };
      motorRecs.push(mrec);
      if (mrec.iA < 0 || mrec.iB < 0) return;
      addDynG(mrec.iA, mrec.iB, function (pA, pB, e) {
        if (mrec.locked) { e.off = 0; return LEAK * 0.02; } // sealed both sides: no phantom circulation
        e.off = offT;
        return FLUID === "air" ? 500 : 30;
      }, "motor", c.id);
      return;
    }
    // measurement / electrical / annotation components: no fluid edges
  });

  function modelFlowControl(c) {
    var P = c.props || {};
    var o = clamp(num(P.openingPercent, 65), 0, 100) / 100;
    var qMax = num(P.maxFlowLpm, 0) || (FLUID === "air" ? 600 : 60);
    var iA = pOf(c.id, "A"), iB = pOf(c.id, "B");
    if (iA < 0 || iB < 0) return;
    var kvMax = FLUID === "air" ? qMax / sqrt0(7.013) : qMax; // ~1 bar drop at full opening
    var kv = kvMax * Math.pow(Math.max(o, 0.004), 1.6);
    if (!P.pressureCompensated) {
      addDynG(iA, iB, function (pA, pB) {
        var dp = Math.abs(pA - pB);
        return FLUID === "air" ? airOrificeG(kv, Math.max(pA, pB), dp) : orificeG(kv, dp);
      }, "fc", c.id);
      return;
    }
    var qSet = qMax * o; // pressure-compensated set point
    addDynG(iA, iB, function (pA, pB) {
      var dp = Math.abs(pA - pB);
      if (dp < 3) return FLUID === "air" ? airOrificeG(kv, Math.max(pA, pB), dp) : orificeG(kv, dp);
      return qSet / dp;
    }, "fc-pc", c.id);
  }

  function modelDirectional(c) {
    var P = c.props || {};
    var state = String(P.spoolState || "center");
    var ports = String(P.ports || "4");
    var kv = kvFromRated(num(P.ratedFlowLpm, 40), Math.max(0.1, num(P.pressureDropBar, 5)));
    var gOpen = FLUID === "air" ? airOrificeG(kv, 6, 0.3) : orificeG(kv, 1.5);
    var gBlocked = Math.max(gOpen * 2e-3, LEAK);
    var nP = pOf(c.id, "P"), nT = pOf(c.id, "T"), nA = pOf(c.id, "A"), nB = pOf(c.id, "B");
    var nR = pOf(c.id, "R"), nS = pOf(c.id, "S");
    // pneumatic valves with an unwired exhaust port exhaust straight to atmosphere
    function ex(n) { return n; }
    if (FLUID === "air") { // unwired exhaust ports vent to atmosphere; wired ones keep their plumbing
      if (nT >= 0 && !wired(c.id, "T")) addGnd(nT, gOpen * 1.5, "dcv-exh", c.id);
      if (nR >= 0 && !wired(c.id, "R")) addGnd(nR, gOpen * 1.5, "dcv-exh", c.id);
      if (nS >= 0 && !wired(c.id, "S")) addGnd(nS, gOpen * 1.5, "dcv-exh", c.id);
    }
    var isMem = c.type === "pneumaticMemoryValve";
    var pairs = [];
    if (isMem) {
      if (state === "left") pairs = [[nP, nA], [nB, nS >= 0 ? nS : nR]];
      else pairs = [[nP, nB], [nA, nR >= 0 ? nR : nS]];
    } else if (ports === "2") {
      if (state === "left") pairs = [[nP, nA]];
    } else if (ports === "3") {
      pairs = state === "left" ? [[nP, nA]] : [[nA, nT]];
    } else {
      // every envelope is user-selectable now: left/right blocks use the same
      // pattern vocabulary as the centre (legacy defaults: left = parallel
      // P->A/B->T, right = crossover P->B/A->T, so old projects are unchanged).
      var blockSet = function (name, dflt) {
        var b = String(name || dflt);
        if (b === "parallel") return [[nP, nA], [nB, nT]];
        if (b === "crossover") return [[nP, nB], [nA, nT]];
        if (b === "open") return [[nP, nT], [nA, nT], [nB, nT]];
        if (b === "tandem") return [[nP, nT]];
        if (b === "float") return [[nA, nT], [nB, nT]];
        if (b === "regenerative") return [[nP, nA], [nB, nA]];
        return [];
      };
      if (state === "left") pairs = blockSet(P.leftBlock, "parallel");
      else if (state === "right") pairs = blockSet(P.rightBlock, "crossover");
      else pairs = blockSet(P.center, "closed");
    }
    pairs.forEach(function (pr) {
      if (pr[0] >= 0 && pr[1] >= 0) {
        addDynG(pr[0], pr[1], function (pA2, pB2) {
          var dp = Math.abs(pA2 - pB2);
          return FLUID === "air" ? airOrificeG(kv, Math.max(pA2, pB2), dp) : orificeG(kv, dp);
        }, "dcv", c.id);
      } else if (FLUID === "air" && pr[0] >= 0 && pr[1] < 0) addGnd(pr[0], gOpen, "dcv-exh2", c.id); // missing exhaust port -> atmosphere
    });
    var nX = pOf(c.id, "X"), nY = pOf(c.id, "Y");
    if (nX >= 0) addGnd(nX, LEAK * 4, "pilotvent", c.id);
    if (nY >= 0) addGnd(nY, LEAK * 4, "pilotvent", c.id);
  }

  function modelServo(c) {
    var P = c.props || {};
    var cmd = clamp(num(P.commandPercent, 0), -100, 100);
    var nP = pOf(c.id, "P"), nT = pOf(c.id, "T"), nA = pOf(c.id, "A"), nB = pOf(c.id, "B");
    var kv = kvFromRated(num(P.ratedFlowLpm, 40), 5);
    var open = Math.abs(cmd) < 3 ? 0 : Math.abs(cmd) / 100;
    var g = FLUID === "air" ? airOrificeG(kv * open, 6, 0.3) : orificeG(kv * open, 1.5);
    var gB = Math.max(g * 2e-3, LEAK);
    if (open > 0) {
      var kvEff = kv * open;
      var sPairs = cmd > 0 ? [[nP, nA], [nB, nT]] : [[nP, nB], [nA, nT]];
      sPairs.forEach(function (pr) {
        if (pr[0] >= 0 && pr[1] >= 0) addDynG(pr[0], pr[1], function (pA2, pB2) {
          var dp = Math.abs(pA2 - pB2);
          return FLUID === "air" ? airOrificeG(kvEff, Math.max(pA2, pB2), dp) : orificeG(kvEff, dp);
        }, "servo", c.id);
      });
    }
  }

  // ---------- lines ----------
  var lineEdges = [];
  fluidLines.forEach(function (c) {
    var a = pOf(c.from.componentId, c.from.portId), b = pOf(c.to.componentId, c.to.portId);
    if (a < 0 || b < 0) return;
    var e = addG(a, b, lineG(c), "line", null);
    if (e) { e.lineId = c.id; e.lineProps = c.properties || {}; lineEdges.push(e); }
  });

  // ---------- cylinder boundary conditions ----------
  var cyls = cylinders.map(function (c) {
    var P = c.props || {};
    var bore = Math.max(8, num(P.boreMm, 50)) / 1000;
    var rod = c.type === "cylinderDA" ? clamp(num(P.rodMm, 36), 0, 0.95 * bore * 1000) / 1000 : 0;
    var Aa = Math.PI * bore * bore / 4;
    var Ab = c.type === "cylinderDA" ? Math.max(0.2 * Aa, Aa - Math.PI * rod * rod / 4) : 0;
    var stroke = Math.max(20, num(P.strokeMm, 300));
    var pos0 = clamp(num(P.simPosition, 0.2), 0, 1);
    var Fload = cylLoadKg(P, pos0, c) * 9.81;
    var st = DYN.cyl[c.id] || (DYN.cyl[c.id] = { q: 0 });
    return {
      comp: c, Aa: Aa, Ab: Ab, stroke: stroke, P: P,
      Fload: Fload,
      iA: pOf(c.id, "A"), iB: pOf(c.id, "B"),
      pos: pos0,
      st: st, q: st.q || 0, starving: false,
      v: 0, pA: 0, pB: 0, force: 0, qA: 0, qB: 0, dir: 0,
    };
  });
  (function () { var ids = {}; cyls.forEach(function (x) { ids[x.comp.id] = 1; }); for (var k in DYN.cyl) if (!(k in ids)) delete DYN.cyl[k]; })();


  // ---------- linear system ----------
  var p = new Float64Array(N);
  for (var si = 0; si < N; si++) p[si] = num(DYN.p[nodeKeys[si]], 0);
  var G = new Float64Array(N * N), bvec = new Float64Array(N), lastP = null;

  function assemble() {
    G.fill(0); bvec.fill(0);
    var i, e, g;
    for (i = 0; i < edges.length; i++) {
      e = edges[i];
      if (e.dyn) e.off = 0;
      g = e.dyn ? (e.dyn(p[e.a] || 0, e.b >= 0 ? p[e.b] : 0, e, p) || 0) : e.g;
      g = Math.max(g, 1e-12);
      if (e.dyn) { // damp state-dependent conductances to kill flip-flop cycles
        if (!(e.gD > 0)) e.gD = g;
        else e.gD = Math.sqrt(e.gD * g); // geometric mean relaxation
        g = e.gD;
      }
      e.gNow = g;
      if (e.b === -1) {
        G[e.a * N + e.a] += e.gNow;
        if (e.off) bvec[e.a] += e.gNow * e.off;
      } else if (e.b >= 0) {
        G[e.a * N + e.a] += e.gNow; G[e.b * N + e.b] += e.gNow;
        G[e.a * N + e.b] -= e.gNow; G[e.b * N + e.a] -= e.gNow;
        if (e.off) { bvec[e.a] += e.gNow * e.off; bvec[e.b] -= e.gNow * e.off; }
      }
    }
    for (i = 0; i < injections.length; i++) {
      var s = injections[i];
      var pn = p[s.node] || 0;
      var q = s.dynQ ? s.dynQ(pn) : s.q;
      s.qNow = q || 0;
      var slp = s.dynS ? s.dynS(pn) || 0 : 0;     // dq/dp (<=0) of the source characteristic
      if (Math.abs(slp) > 1e-9) {
        var qAnchor = s.qRef != null ? (-slp) * s.qRef : (s.qNow - slp * pn); // q = (-slp)*(qRef - p)
        G[s.node * N + s.node] += -slp;
        bvec[s.node] += qAnchor;
        s.qNow = Math.max((-slp) * ((s.qRef != null ? s.qRef : 0) - pn), 0);
      } else {
        bvec[s.node] += s.qNow;
      }
    }
    for (i = 0; i < accumEdges.length; i++) {
      var ac = accumEdges[i], pn = p[ac.iA] || 0;
      var active = pn > ac.pAcc || ac.stored > 0.005 * ac.V0 || (FLUID === "air" && ac.pAcc <= 0);
      var g2 = active ? ac.g : LEAK;
      G[ac.iA * N + ac.iA] += g2;
      bvec[ac.iA] += g2 * ac.pAcc;
      ac.gNow = g2;
    }
    for (i = 0; i < intensPairs.length; i++) {
      var it = intensPairs[i];
      if (it.iA < 0) continue;
      var gI = BIGG * 0.03, tgt = it.rt * (it.iP >= 0 ? p[it.iP] : 0);
      G[it.iA * N + it.iA] += gI; bvec[it.iA] += gI * tgt;
    }
    for (i = 0; i < vacPairs.length; i++) {
      var vq = vacPairs[i];
      var gV = (p[vq.iV] || 0) > vq.vac ? vq.g : LEAK;
      G[vq.iV * N + vq.iV] += gV; bvec[vq.iV] += gV * vq.vac;
    }
    for (i = 0; i < regulators.length; i++) {
      var rg = regulators[i];
      if (rg.iA < 0) continue;
      var pP = rg.iP >= 0 ? p[rg.iP] || 0 : 0, pA = p[rg.iA] || 0;
      var qC = rg.gC * (rg.set - pA);
      var supCap = rg.gSup * Math.max(pP - pA, 0);
      var ventCap = rg.gV * Math.max(pA, 0);
      // decide mode with hysteresis so the branch cannot flack between iterations
      var mode = rg.mode || "band";
      if (pA > pP + 0.5) {
        // downstream pressure exceeds inlet: reverse blocked, relieve via drain only
        if (mode !== "vent") mode = "vent";
      } else if (mode === "band") {
        if (qC > 1.25 * supCap) mode = "cap";
        else if (qC < -1.25 * ventCap) mode = "vent";
      } else if (mode === "cap") {
        if (qC < 0.8 * supCap) mode = "band";
      } else if (mode === "vent") {
        if (qC > -0.8 * ventCap) mode = "band";
      }
      rg.mode = mode;
      if (mode === "cap" && rg.iP >= 0) {
        G[rg.iA * N + rg.iA] += rg.gSup; G[rg.iP * N + rg.iP] += rg.gSup;
        G[rg.iA * N + rg.iP] -= rg.gSup; G[rg.iP * N + rg.iA] -= rg.gSup;
        rg.qNow = supCap;
      } else if (mode === "vent") {
        var setX = rg.set + 0.4;
        if (pA > setX - 0.6) { // poppet opens only above setting: Q = gV*(pA - pT - setX)
          G[rg.iA * N + rg.iA] += rg.gV; bvec[rg.iA] += rg.gV * setX;
          if (rg.ventTo >= 0) { G[rg.ventTo * N + rg.ventTo] += rg.gV; G[rg.iA * N + rg.ventTo] -= rg.gV; G[rg.ventTo * N + rg.iA] -= rg.gV; bvec[rg.ventTo] -= rg.gV * setX; }
          rg.qNow = -rg.gV * Math.max(pA - (rg.ventTo >= 0 ? p[rg.ventTo] || 0 : 0) - setX, 0);
        } else rg.qNow = 0;
      } else {
        G[rg.iA * N + rg.iA] += rg.gC; bvec[rg.iA] += rg.gC * rg.set;
        if (qC > 0 && rg.iP >= 0) { G[rg.iP * N + rg.iA] -= rg.gC; bvec[rg.iP] -= rg.gC * rg.set; }
        else if (qC < 0 && rg.ventTo >= 0) { G[rg.ventTo * N + rg.iA] -= rg.gC; bvec[rg.ventTo] -= rg.gC * rg.set; }
        rg.qNow = qC;
      }
    }
    for (i = 0; i < N; i++) G[i * N + i] += LEAK;
    for (i = 0; i < cyls.length; i++) {
      var cy = cyls[i];
      if (cy.iA >= 0) bvec[cy.iA] -= cy.qA || 0; // extraction from node into chamber
      if (cy.iB >= 0) bvec[cy.iB] -= cy.qB || 0;
    }
  }

  var dbgA = null, dbgB = null;
  function solveLin() {
    var n = N, A = G, b = bvec, i, j, k, f, t2;
    if (rgzFluidSolve._trace && !dbgA) { dbgA = Float64Array.from(G); dbgB = Float64Array.from(bvec); }
    for (k = 0; k < n; k++) {
      var piv = k, mx = Math.abs(A[k * n + k]);
      for (i = k + 1; i < n; i++) { var v2 = Math.abs(A[i * n + k]); if (v2 > mx) { mx = v2; piv = i; } }
      if (mx < 1e-12) { A[k * n + k] = 1e-12; mx = 1e-12; }
      if (piv !== k) {
        for (j = k; j < n; j++) { t2 = A[k * n + j]; A[k * n + j] = A[piv * n + j]; A[piv * n + j] = t2; }
        t2 = b[k]; b[k] = b[piv]; b[piv] = t2;
      }
      for (i = k + 1; i < n; i++) {
        f = A[i * n + k] / A[k * n + k];
        if (f !== 0) { for (j = k; j < n; j++) A[i * n + j] -= f * A[k * n + j]; b[i] -= f * b[k]; }
      }
    }
    for (i = n - 1; i >= 0; i--) {
      var acc = b[i];
      for (j = i + 1; j < n; j++) acc -= A[i * n + j] * p[j];
      p[i] = acc / A[i * n + i];
      if (!Number.isFinite(p[i])) p[i] = 0;
    }
    if (rgzFluidSolve._trace && dbgA) {
      var rmax = 0, ri = -1;
      for (i = 0; i < n; i++) {
        var acc2 = -dbgB[i];
        for (j = 0; j < n; j++) acc2 += dbgA[i * n + j] * p[j];
        if (Math.abs(acc2) > rmax) { rmax = Math.abs(acc2); ri = i; }
      }
      console.log("  solve residual max", rmax.toExponential(2), "at node", nodeKeys[ri], "p=", p[ri].toFixed(2));
      dbgA = null; dbgB = null;
    }
  }

  var pCap = FLUID === "air" ? 25 : 1000;
  (function () {
    var caps = [];
    if (reliefs.length) caps.push(reliefSetting + 20);
    pumps.forEach(function (cp) {
      var m1 = num(cp.props.maxPressureBar, 0), m2 = num(cp.props.compensatorBar, 0) || num(cp.props.reliefSettingBar, 0);
      var c2 = Math.max(m1, m2);
      if (c2 > 0) caps.push(c2 + 15);
    });
    if (caps.length) pCap = Math.min(pCap, Math.min.apply(null, caps));
    // Rod-side metering can intensify pressure ABOVE the pump ceiling by the
    // cylinder area ratio (pB ~ pA * Aa/Ab). If the clamp sits at the pump
    // ceiling, the back-pressure that makes meter-out speed control work can
    // never form and the cylinder runs at full speed — physically wrong.
    if (FLUID !== "air") {
      var ratio = 1;
      cyls.forEach(function (cy) { if (cy.Ab > 0) ratio = Math.max(ratio, Math.min(5, cy.Aa / cy.Ab)); });
      if (ratio > 1.01) pCap = Math.min(1200, Math.ceil(pCap * ratio * 1.05));
    }
  })();
  function applyFloor() {
    for (var i = 0; i < cyls.length; i++) {
      var cy = cyls[i];
      if (cy.iA >= 0 && (cy.qA || 0) > 0 && p[cy.iA] < FLOOR) p[cy.iA] = FLOOR;
      if (cy.iB >= 0 && (cy.qB || 0) > 0 && p[cy.iB] < FLOOR) p[cy.iB] = FLOOR;
    }
    for (i = 0; i < N; i++) {
      if (p[i] < FLOOR - 0.5) p[i] = FLOOR - 0.5;
      else if (p[i] > pCap) p[i] = pCap;
    }
  }

  function edgeFlows() {
    for (var i = 0; i < edges.length; i++) {
      var e = edges[i];
      var pa = p[e.a] || 0, pb = (e.b >= 0 ? p[e.b] : 0) + (e.off || 0);
      e.flow = e.gNow * (pa - pb);
    }
    for (i = 0; i < accumEdges.length; i++) {
      var ac = accumEdges[i];
      ac.flow = (ac.gNow || 0) * ((p[ac.iA] || 0) - ac.pAcc); // + into accumulator
    }
  }

  // ---------- network solve helper (damped nonlinear iteration)
  function solveNetwork(quick) {
    var K = quick ? 14 : 30, prev = null, k, md;
    for (k = 0; k < K; k++) {
      assemble();
      solveLin();
      applyFloor();
      if (prev) {
        md = 0;
        for (var i2 = 0; i2 < N; i2++) md = Math.max(md, Math.abs(p[i2] - prev[i2]));
        if (md < 0.005 && k >= 8) break;
      }
      prev = Float64Array.from(p);
    }
    edgeFlows();
  }

  // ---------- reference reachability (is this node hydraulically ventable?)
  var GMIN = 2e-5; // L/min/bar: below this a chamber cluster is sealed (closed valve paths sit at LEAK*0.02~2.4e-6; tight throttles stay orders of magnitude above)
  function reachesReference(start) {
    if (start < 0) return false;
    var seen = {}, stack = [start], guard = 0;
    while (stack.length && guard++ < 4 * (N + edges.length + 8)) {
      var n = stack.pop();
      if (n === -2) return true; // virtual reference node (accumulator battery)
      if (seen[n]) continue;
      seen[n] = 1;
      for (var i = 0; i < edges.length; i++) {
        var e = edges[i], g = e.gNow != null ? e.gNow : e.g;
        if (e.b === -1 && e.a === n && g > GMIN && e.tag !== "cyl-dem") return true; // ground anchor
        if (g <= GMIN) continue;
        if (e.a === n && e.b >= 0 && !seen[e.b]) stack.push(e.b);
        else if (e.b === n && e.a >= 0 && !seen[e.a]) stack.push(e.a);
      }
      for (var j = 0; j < injections.length; j++) if (injections[j].node === n && (injections[j].q || 0) > 0.01) return true; // real sources only (not chamber expulsion)
      for (var r = 0; r < regulators.length; r++) {                       // regulator transfer paths
        var rg = regulators[r];
        if (rg.iA === n) { if (rg.iP >= 0) stack.push(rg.iP); if (rg.ventTo >= 0) stack.push(rg.ventTo); }
        else if (rg.iP === n || rg.ventTo === n) stack.push(rg.iA);
      }
      for (var a2 = 0; a2 < accumEdges.length; a2++) if (accumEdges[a2].iA === n) stack.push(-2);
    }
    return false;
  }
  function cylLocked(cy) {
    var ra = cy.iA >= 0 ? reachesReference(cy.iA) : false;
    if (cy.Ab <= 0) return !ra;                 // single-acting: only A matters
    var rb = cy.iB >= 0 ? reachesReference(cy.iB) : false;
    return !(ra && rb);
  }

  // Sustained fill capacity of a chamber cluster [L/min]: what steady inflow can
  // reach it. Ground anchors (tank suction) and accumulators = unlimited; otherwise
  // the sum of pump deliveries reachable through open paths. If the opposite chamber
  // sits in the same cluster (regenerative loop), expelled flow feeds the fill, so
  // there is no external deficit.
  function supplyInfo(start, other) {
    var info = { ground: false, q: 0, both: false };
    if (start < 0) return info;
    var seen = {}, stack = [start], guard = 0, injSeen = {};
    while (stack.length && guard++ < 4 * (N + edges.length + 8)) {
      var n = stack.pop();
      if (n === -2) { info.ground = true; continue; }     // accumulator battery sustains flow
      if (n === other && other >= 0) { info.both = true; }
      if (seen[n]) continue;
      seen[n] = 1;
      for (var i = 0; i < edges.length; i++) {
        var e = edges[i], g = e.gNow != null ? e.gNow : e.g;
        if (e.b === -1 && e.a === n && g > GMIN && e.tag !== "cyl-dem") { info.ground = true; continue; }
        if (g <= GMIN) continue;
        // Flow-divider primer edges physically bridge the branches, but for FILL
        // CAPACITY they must not merge the three ports into one cluster: each
        // branch's sustained supply is exactly its own issued share (sA1/sB1),
        // otherwise both cylinders sum pump + both shares and the cap stops
        // enforcing the split (that was the "first cylinder grabs the pump" bug).
        if (e.tag === "div-primer") continue;
        if (e.a === n && e.b >= 0 && !seen[e.b]) stack.push(e.b);
        else if (e.b === n && e.a >= 0 && !seen[e.a]) stack.push(e.a);
      }
      for (var j = 0; j < injections.length; j++) {
        var s = injections[j];
        // capacity = nominal delivery (destroked/cutout pumps still deliver full
        // displacement once downstream pressure sags), so use s.q not s.qNow.
        if (s.node === n && !injSeen[j] && (s.q || 0) > 0.01) { injSeen[j] = 1; info.q += s.q; }
      }
      for (var r = 0; r < regulators.length; r++) {
        var rg = regulators[r];
        if (rg.iA === n) { if (rg.iP >= 0 && !seen[rg.iP]) stack.push(rg.iP); if (rg.ventTo >= 0 && !seen[rg.ventTo]) stack.push(rg.ventTo); }
        else if (rg.iP === n || rg.ventTo === n) { if (rg.iA >= 0 && !seen[rg.iA]) stack.push(rg.iA); }
      }
      for (var a2 = 0; a2 < accumEdges.length; a2++) if (accumEdges[a2].iA === n) stack.push(-2);
    }
    return info;
  }

  // ---------- cylinder steady-state roots (LCP via signed bisection on q)
  function forceNet(cy) {
    var pA = cy.iA >= 0 ? p[cy.iA] : 0, pB = cy.iB >= 0 ? p[cy.iB] : 0;
    cy.pA = pA; cy.pB = pB;
    var Fspring = cy.comp.type === "cylinderSA" && cy.P.springReturn !== false
      ? 250 + 700 * cy.pos * cy.stroke / 500 : 0;
    return 1e5 * (pA * cy.Aa - pB * cy.Ab) - cy.Fload - Fspring;
  }
  function setCylFlow(cy, q) {
    // signed cap-side flow [L/min at local conditions]; + = extend (extract from A, expel into B)
    var qA = q, qB = cy.Ab > 0 ? -q * (cy.Ab / cy.Aa) : 0;
    if (FLUID === "air") {
      qA *= Math.max(((cy.iA >= 0 ? p[cy.iA] : 0) + PATM) / PATM, 0.05);
      qB *= Math.max(((cy.iB >= 0 ? p[cy.iB] : 0) + PATM) / PATM, 0.05);
    }
    cy.qA = qA; cy.qB = qB; cy.q = q;
  }
  function cylRoot(cy) {
    if (cy.iA < 0 && cy.iB < 0) { setCylFlow(cy, 0); cy.v = 0; cy.force = 0; return; }
    setCylFlow(cy, 0); // clean state before force evaluation
    var pumpQtot = 0;
    injections.forEach(function (s) { if (s.tag === "pump") pumpQtot += Math.max(s.qNow || 0, 0); });
    var qCap = Math.max(FLUID === "air" ? 300 : 40, 3.2 * Math.max(pumpQtot, 1));
    // mass-conservation caps: the filling chamber cannot be fed faster than the
    // sustained supply reaching it (otherwise the network cheated with vacuum).
    var qCapE = qCap, qCapR = qCap;
    var sA = supplyInfo(cy.iA, cy.iB);
    if (!sA.ground && !sA.both) qCapE = Math.min(qCap, Math.max(sA.q, 0.05));
    if (cy.Ab > 0) {
      var sB = supplyInfo(cy.iB, cy.iA);
      if (!sB.ground && !sB.both) qCapR = Math.min(qCap, Math.max(sB.q * (cy.Aa / cy.Ab), 0.05));
    }
    // Flow divider in COMBINER direction meters the chamber it is wired to:
    // expulsion through that chamber cannot exceed the branch share. Wired to
    // A (the usual sync hookup) expulsion happens on retract (qCapR); wired to
    // B it happens on extend (cap-side q x Ab/Aa leaves the rod side).
    if (cy.divA && cy.divA.dv.qIn < -0.05) qCapR = Math.min(qCapR, Math.max(-cy.divA.dv.qIn * cy.divA.s, 0.05));
    if (cy.divB && cy.divB.dv.qIn < -0.05) qCapE = Math.min(qCapE, Math.max(-cy.divB.dv.qIn * cy.divB.s * (cy.Ab > 0 ? cy.Aa / cy.Ab : 1), 0.05));
    var atTop = cy.pos >= 0.999, atBot = cy.pos <= 0.001;
    solveNetwork();
    var f0 = forceNet(cy);
    var DEAD = Math.max(45, 0.02 * Math.max(cy.Fload, 1));
    var locked = cylLocked(cy);
    if (rgzFluidSolve._trace && cy.comp.id === rgzFluidSolve._trace) console.log(" root start f0=", f0.toFixed(0), "pA=", cy.pA.toFixed(2), "atTop", atTop, "pos", cy.pos, "locked", locked);
    if (locked || Math.abs(f0) <= DEAD || (f0 > DEAD && atTop) || (f0 < -DEAD && atBot && (cy.Ab > 0 || cy.comp.type === "cylinderSA"))) {
      setCylFlow(cy, 0);
      cy.v = 0; cy.dir = 0; cy.force = f0; cy.starving = false;
      solveNetwork();
      cy.force = forceNet(cy);
      return;
    }
    var lo, hi, flo, fhi;
    if (f0 > DEAD) { // wants to extend: bracket [0, +qCapE]
      lo = 0; hi = qCapE; flo = f0;
      setCylFlow(cy, hi); solveNetwork(); fhi = forceNet(cy);
      if (fhi > 0) { // even at cap it pushes (overrunning supply cap): use cap
        setCylFlow(cy, hi); solveNetwork(); cy.force = forceNet(cy);
        cy.v = (cy.q / 6e4 / cy.Aa) * 1000; cy.dir = 1; cy.starving = false; return;
      }
    } else { // wants to retract: bracket [-qCapR, 0]
      hi = 0; lo = -qCapR; fhi = f0;
      setCylFlow(cy, lo); solveNetwork(); flo = forceNet(cy);
      if (flo < 0) {
        setCylFlow(cy, lo); solveNetwork(); cy.force = forceNet(cy);
        cy.v = (cy.q / 6e4 / cy.Aa) * 1000; cy.dir = -1; cy.starving = false; return;
      }
    }
    for (var it = 0; it < 24; it++) {
      var mid = 0.5 * (lo + hi);
      setCylFlow(cy, mid); solveNetwork();
      var fm = forceNet(cy);
      if (rgzFluidSolve._trace && cy.comp.id === rgzFluidSolve._trace) console.log(" bisect it", it, "q=", mid.toFixed(2), "pA=", cy.pA.toFixed(2), "pB=", cy.pB.toFixed(2), "F=", fm.toFixed(0));
      if (Math.abs(fm) <= DEAD) break;
      if (fm > 0) lo = mid; else hi = mid;
      if (Math.abs(hi - lo) < 0.02) break;
    }
    solveNetwork();
    cy.force = forceNet(cy);
    var v = (cy.q / 6e4 / cy.Aa) * 1000;
    // derived physically: retract speed uses rod-side chamber volume
    if (cy.q < 0 && cy.Ab > 0) v = (cy.q * (cy.Ab / cy.Aa) / 6e4 / cy.Ab) * 1000;
    cy.v = v; cy.dir = cy.q > 0.02 ? 1 : (cy.q < -0.02 ? -1 : 0);
    var pDrive = cy.q > 0 ? cy.pA : cy.pB;
    cy.starving = Math.abs(cy.q) > 1 && pDrive <= FLOOR + 0.25;
    // persist demand for continuity (informational only)
    cy.st.q = cy.q;
  }

  // ---------- iterate: valve linearization rounds + per-cylinder roots
  // Flow dividers: now that every pump source exists, size the split capacity and
  // bootstrap a hot start (sink/source triplet primed to the pump delivery, so the
  // branch cylinders get meaningful flow caps on the very first tick; the measured
  // feedback then converges within a few ticks). qIn itself persists across ticks
  // via DYN.div; the bootstrap only fills a never-initialised entry.
  if (dividers.length) {
    var qPumpAll = 0;
    injections.forEach(function (s2) { if (!s2.divTag) qPumpAll += Math.max(s2.q || 0, 0); });
    for (var dv0 = 0; dv0 < dividers.length; dv0++) {
      var dvI = dividers[dv0];
      // combiner direction passes the full-bore expulsion, bigger than the pump
      // delivery by the area ratio -> 2.5x headroom.
      dvI.qMax = Math.max(2.5 * qPumpAll, 8);
      if (!(dvI.cid in (DYN.div || {})) || !dvI.qIn) dvI.qIn = clamp(Math.min(qPumpAll, 10), 0, dvI.qMax);
      if (dvI.sIn) dvI.sIn.q = -dvI.qIn;
      if (dvI.sA1) dvI.sA1.q = dvI.qIn * dvI.sA;
      if (dvI.sB1) dvI.sB1.q = dvI.qIn * (1 - dvI.sA);
      // branch -> chamber mapping (one line hop): in combiner direction the
      // divider meters the EXPELLED flow, which the cylinder root otherwise
      // never caps (only fill sides are supply-capped) -> the branches would
      // free-run unevenly through the primer paths on retract.
      for (var br = 0; br < 2; br++) {
        var iBr = br === 0 ? dvI.iA : dvI.iB, sBr = br === 0 ? dvI.sA : 1 - dvI.sA;
        if (iBr < 0) continue;
        for (var em = 0; em < edges.length; em++) {
          var emd = edges[em];
          var on = emd.a === iBr ? emd.b : emd.b === iBr ? emd.a : -1;
          if (on < 0 || nodeComp[on] === dvI.cid) continue;
          for (var cm = 0; cm < cyls.length; cm++) {
            var cym = cyls[cm];
            if (cym.comp.id !== nodeComp[on]) continue;
            var rec = { dv: dvI, s: sBr };
            if (cym.iA === on) {
              cym.divA = rec;
              // retract metering ceiling: rod-side fill per unit expulsion is
              // Ab/Aa < 1, so |qIn| may not exceed what the pump can FILL,
              // else the descending loads drive the fill side into cavitation.
              if (cym.Ab > 0) dvI.rMin = Math.min(dvI.rMin || 1, cym.Ab / cym.Aa);
            } else if (cym.iB === on) cym.divB = rec;
          }
        }
      }
      dvI.qMaxComb = dvI.rMin ? Math.min(dvI.qMax, 0.92 * qPumpAll / dvI.rMin) : dvI.qMax;
    }
  }

  solveNetwork(); // priming solve so dynamic conductances / injection qNow are real before lock checks
  var OUTER = cyls.length > 1 ? 3 : 2;
  for (var oi = 0; oi < OUTER; oi++) {
    if (rgzFluidSolve._trace) console.log(" -- outer round", oi);
    for (var mr = 0; mr < motorRecs.length; mr++) {
      var mrc = motorRecs[mr];
      mrc.locked = !(mrc.iA >= 0 && mrc.iB >= 0 && reachesReference(mrc.iA) && reachesReference(mrc.iB));
    }
    for (var ci2 = 0; ci2 < cyls.length; ci2++) cylRoot(cyls[ci2]);
  }
  solveNetwork();
  // Final unrelaxed reporting passes: the bisection probes inside cylRoot jog the
  // on/off dynamic conductances (check valves, reliefs at the crack point, etc.)
  // and the geometric-mean relaxation can freeze them halfway between states
  // (e.g. a bypass check valve stuck almost shut -> phantom trapped pressure).
  // Re-evaluate all dynamics exactly at the converged point so the reported
  // pressures/flows are the fresh fixed point of the final piston demands.
  for (var fi = 0; fi < 3; fi++) {
    for (var fe = 0; fe < edges.length; fe++) edges[fe].gD = 0;
    solveNetwork();
  }

  // Flow divider/combiner controller, exactly ONCE per tick on the converged
  // fixed point (updating inside edgeFlows let mid-bisection probe flows
  // halve qIn repeatedly within the same tick — a shrink-spiral). The divider
  // is a pass-through current device: it cannot create flow, so the split
  // sources re-issue what is OFFERED at P (pump delivery reachable through
  // genuinely open paths, LEAK-only paths don't count). The measured line
  // inflow is used as the shrink-limiter (throttled/relief-limited supply)
  // and as the direction witness (negative -> combiner direction); pure
  // consumption-following traps at the cold-start low fixed point, so while
  // the line delivers >=95% of the current demand the demand grows 1.5x/tick
  // toward the offered ceiling — reaching full delivery in a few ticks from
  // the bootstrap and re-arming after the valve re-opens.
  for (var fi2 = 0; fi2 < dividers.length; fi2++) {
    var dv = dividers[fi2];
    if (dv.iP < 0) continue;
    if (!dv.inc) {
      dv.inc = [];
      for (var ei = 0; ei < edges.length; ei++) {
        var ed = edges[ei];
        var other = ed.a === dv.iP ? ed.b : ed.b === dv.iP ? ed.a : -99;
        if (other > -99 && (other < 0 || nodeComp[other] !== dv.cid)) dv.inc.push(ed);
      }
    }
    var rin = 0;
    for (var di = 0; di < dv.inc.length; di++) {
      var ee = dv.inc[di];
      rin += ee.b === dv.iP ? ee.flow || 0 : -(ee.flow || 0);
    }
    if (Math.abs(rin) < 0.03) rin = 0;
    // offered flow toward P: BFS from P over edges with real conductance
    if (!dv.fwd || dv.qOffT !== TIME) {
      var off = 0, reachAcc = false, seen = {}, stack = [dv.iP], guard = 0, injSeen = {};
      while (stack.length && guard++ < 4 * (N + edges.length + 8)) {
        var n = stack.pop();
        if (n === -2) { reachAcc = true; continue; }
        if (seen[n]) continue;
        seen[n] = 1;
        for (var eo = 0; eo < edges.length; eo++) {
          var e2 = edges[eo], g2 = e2.gNow != null ? e2.gNow : e2.g;
          if (g2 < 0.001) continue;                       // LEAK-only paths are not supply paths
          if (e2.tag === "div-primer") continue;
          if (e2.a === n && e2.b >= 0 && !seen[e2.b]) stack.push(e2.b);
          else if (e2.b === n && e2.a >= 0 && !seen[e2.a]) stack.push(e2.a);
        }
        for (var jo = 0; jo < injections.length; jo++) {
          var s3 = injections[jo];
          if (s3.node === n && !injSeen[jo] && !s3.divTag && (s3.q || 0) > 0.01) { injSeen[jo] = 1; off += s3.q; }
        }
        for (var ro = 0; ro < regulators.length; ro++) {
          var rgo = regulators[ro];
          if (rgo.iA === n) { if (rgo.iP >= 0 && !seen[rgo.iP]) stack.push(rgo.iP); if (rgo.ventTo >= 0 && !seen[rgo.ventTo]) stack.push(rgo.ventTo); }
          else if (rgo.iP === n || rgo.ventTo === n) { if (rgo.iA >= 0 && !seen[rgo.iA]) stack.push(rgo.iA); }
        }
        for (var ao = 0; ao < accumEdges.length; ao++) if (accumEdges[ao].iA === n) stack.push(-2);
      }
      dv.qOff = reachAcc ? dv.qMax : off;
      dv.qOffT = TIME;
    }
    var target;
    if (rin < -1 && dv.qIn >= -0.05) dv.qIn = -Math.min(3, dv.qMax); // combiner snap-arm: primer-carried return detected
    if (dv.qIn < -0.05 || (Math.abs(dv.qIn) <= 0.05 && rin < -0.5)) {
      // combiner direction: follow the measured return flow, capped by what
      // the pump can FILL on the other side (meter-out cannot create oil).
      var capC = dv.qMaxComb || dv.qMax;
      target = rin;
      if (dv.qIn < -0.05 && -rin >= 0.95 * -dv.qIn) target = -Math.min(capC, Math.max(-rin, -dv.qIn * 1.5));
    } else {
      var up = Math.min(dv.qOff || 0, dv.qMax);
      if (up > 0.05) {
        target = rin >= 0.95 * dv.qIn ? Math.min(up, Math.max(rin, dv.qIn * 1.5)) : Math.max(rin, 0);
      } else target = 0;
    }
    dv.qIn = clamp(0.5 * dv.qIn + 0.5 * clamp(target, -dv.qMax, dv.qMax), -dv.qMax, dv.qMax);
    if (Math.abs(dv.qIn) < 0.2 && (dv.qOff || 0) > 1 && rin > -0.5) dv.qIn = Math.min(dv.qOff, dv.qMax, 1.5); // re-arm
    if (DYN.div) DYN.div[dv.cid] = dv.qIn;
    if (dv.sIn) dv.sIn.q = -dv.qIn;
    if (dv.sA1) dv.sA1.q = dv.qIn * dv.sA;
    if (dv.sB1) dv.sB1.q = dv.qIn * (1 - dv.sA);
  }
  for (var ci3 = 0; ci3 < cyls.length; ci3++) cyls[ci3].force = forceNet(cyls[ci3]);
  for (var mi = 0; mi < N; mi++) DYN.p[nodeKeys[mi]] = p[mi];

  // ---------- outputs ----------
  var compMap = {};
  gauges.forEach(function (c) {
    var iP = pOf(c.id, "P");
    compMap[c.id] = { pressureBar: iP >= 0 ? clamp(p[iP], FLOOR, pCap) : 0, flowLpm: 0 };
  });
  flowmeters.forEach(function (c) {
    var q = 0;
    for (var i = 0; i < edges.length; i++) { var e = edges[i]; if (e.compId === c.id && e.tag === "passive") q = Math.abs(e.flow); }
    var iA = pOf(c.id, "A");
    compMap[c.id] = { pressureBar: iA >= 0 ? clamp(p[iA], FLOOR, pCap) : 0, flowLpm: q };
  });
  reliefs.forEach(function (c) {
    if (c.type === "powerPack") return;
    var iP = pOf(c.id, "P");
    compMap[c.id] = { pressureBar: iP >= 0 ? clamp(p[iP], FLOOR, pCap) : 0, flowLpm: 0 };
  });
  comps.forEach(function (c) {
    var t = c.type;
    if (t === "powerPack" || t === "pumpFixed" || t === "pumpVariable" || t === "compressorFixed" || t === "compressorVariable") {
      var iP = pOf(c.id, "P"), qinj = 0;
      for (var j = 0; j < injections.length; j++) { var s = injections[j]; if (s.compId === c.id && s.tag === "pump") qinj = Math.max(s.qNow || 0, 0); }
      compMap[c.id] = { pressureBar: iP >= 0 ? clamp(p[iP], FLOOR, pCap) : 0, flowLpm: qinj };
    }
    if (t === "flowControl" || t === "cartridgeNeedleFlowValve" || t === "checkValve" || t === "cartridgeCheckValve" || t === "pilotCheckValve") {
      var q2 = 0, dp2 = 0;
      for (var i2 = 0; i2 < edges.length; i2++) { var e2 = edges[i2]; if (e2.compId === c.id && e2.b >= 0 && (e2.tag === "fc" || e2.tag === "fc-pc" || e2.tag === "check" || e2.tag === "pcheck")) { q2 = e2.flow; dp2 = Math.abs(p[e2.a] - p[e2.b]); } }
      var iA2 = pOf(c.id, "A");
      compMap[c.id] = { flowLpm: Math.abs(q2), deltaPBar: dp2, pressureBar: iA2 >= 0 ? clamp(p[iA2], FLOOR, pCap) : 0 };
    }
    if (t === "reducingValve" || t === "cartridgeReducingValve" || t === "frlUnit") {
      var iA3 = pOf(c.id, "A"), iP3 = pOf(c.id, "P");
      compMap[c.id] = { pressureBar: iA3 >= 0 ? clamp(p[iA3], FLOOR, pCap) : 0, inletBar: iP3 >= 0 ? clamp(p[iP3], FLOOR, pCap) : 0 };
    }
    if (t === "reliefValve" || t === "cartridgeReliefValve") {
      var q3 = 0;
      for (var i3 = 0; i3 < edges.length; i3++) { var e3 = edges[i3]; if (e3.compId === c.id && e3.tag === "relief") q3 = Math.max(e3.flow, 0); }
      if (compMap[c.id]) compMap[c.id].flowLpm = q3;
    }
    if (t === "directionalValve" || t === "servoValve" || t === "pneumaticMemoryValve") {
      var iA4 = pOf(c.id, "A"), iP4 = pOf(c.id, "P");
      compMap[c.id] = { pressureBar: iA4 >= 0 ? clamp(p[iA4], FLOOR, pCap) : 0, supplyBar: iP4 >= 0 ? clamp(p[iP4], FLOOR, pCap) : 0 };
    }
    if (t === "accumulator") {
      for (var j2 = 0; j2 < accumEdges.length; j2++) if (accumEdges[j2].comp.id === c.id) {
        compMap[c.id] = { pressureBar: clamp(p[accumEdges[j2].iA] || 0, FLOOR, pCap), flowLpm: accumEdges[j2].flow || 0 };
      }
    }
  });

  var cylOut = cyls.map(function (cy) {
    return {
      id: cy.comp.id, label: cy.comp.label || cy.comp.id,
      speedMmS: cy.v, forceKN: Math.abs(cy.force) / 1000,
      pressureBar: Math.max(cy.dir >= 0 ? cy.pA : cy.pB, 0),
      loadKg: cylLoadKg(cy.P, cy.pos, cy.comp),
    };
  });

  var motorOut = motors.map(function (m) {
    var iA = pOf(m.id, "A"), iB = pOf(m.id, "B"), q = 0;
    for (var i = 0; i < edges.length; i++) { var e = edges[i]; if (e.compId === m.id && e.tag === "motor") q = e.flow; }
    var disp = Math.max(1, num(m.props.displacementCcRev, 25));
    var pA = iA >= 0 ? p[iA] : 0, pB = iB >= 0 ? p[iB] : 0;
    var rpm = Math.abs(q) > 0.02 ? (1000 * Math.abs(q)) / disp : 0;
    var torque = Math.abs(pA - pB) * disp / 20 / Math.PI;
    var dirn = pA >= pB ? 1 : -1;
    var loadNmNow = motorLoadNm(m.props, m);
    compMap[m.id] = { pressureBar: clamp(pA - pB, -pCap, pCap), flowLpm: Math.abs(q), rpm: rpm, torqueNm: torque, loadNm: loadNmNow };
    return { id: m.id, label: m.label || m.id, flowLpm: Math.abs(q), rpm: dirn * rpm, torqueNm: torque, loadNm: loadNmNow };
  });

  var lineOut = lineEdges.map(function (e) {
    var qL = e.flow;
    var d = Math.max(1.5, num(e.lineProps.tubeIdMm, FLUID === "air" ? 6 : 12));
    var area = Math.PI * Math.pow(d / 1000, 2) / 4;
    var vel = area > 0 ? Math.abs(qL) / 6e4 / area : 0;
    var pn = Math.max(p[e.a], p[e.b]);
    var vmax = FLUID === "air" ? 25 : (num(e.lineProps.tubeIdMm, 12) < 8 ? 4.5 : 6);
    if (vel > vmax) warnings.push((e.lineId || "line") + " velocity is high (" + vel.toFixed(1) + " m/s).");
    return { id: e.lineId, velocityMps: vel, flowLpm: qL, active: Math.abs(qL) > 0.15, high: pn > 0.8 * reliefSetting, pressureBar: pn };
  });

  var totalQ = 0, pumpP = 0, pumpQreal = 0;
  pumps.forEach(function (cp) {
    totalQ += num(cp.props.flowLpm, 0);
    var iP = pOf(cp.id, "P");
    if (iP >= 0) {
      pumpP = Math.max(pumpP, p[iP]);
      for (var i = 0; i < injections.length; i++) { var s = injections[i]; if (s.compId === cp.id && s.tag === "pump") pumpQreal += Math.max(s.qNow || 0, 0); }
    }
  });
  var netMax = 0; for (var n2 = 0; n2 < N; n2++) netMax = Math.max(netMax, p[n2]);
  var pressureBar = pumpP > 0 ? pumpP : netMax;
  var powerKw = (pumpQreal * Math.max(pressureBar, 0)) / 600;

  var lossKw = 0;
  for (var i4 = 0; i4 < edges.length; i4++) { var e4 = edges[i4]; lossKw += Math.abs(e4.flow) * Math.abs((p[e4.a] || 0) - (e4.b >= 0 ? p[e4.b] : 0)) / 600; }
  var tanks = comps.filter(function (c) { return c.type === "tank" || c.type === "powerPack"; });
  var baseT = tanks.length ? tanks.reduce(function (a2e, c) { return a2e + num(c.props.oilTempC, 40); }, 0) / tanks.length : 40;
  var oilTempC = FLUID === "air" ? 20 : baseT + Math.min(25, 0.4 * lossKw + 0.01 * TIME * Math.min(1, lossKw));

  var activeQ = 0;
  cyls.forEach(function (cy) { activeQ += Math.abs(cy.qA || 0); });
  motorOut.forEach(function (mo) { activeQ += mo.flowLpm; });

  var reliefOpen = false;
  for (var i5 = 0; i5 < edges.length; i5++) { var e5 = edges[i5]; if (e5.tag === "relief" && e5.flow > 0.05) { reliefOpen = true; break; } }
  var anyMoving = cylOut.some(function (co) { return Math.abs(co.speedMmS) > 0.5; }) || motorOut.some(function (mo) { return Math.abs(mo.rpm) > 1; });
  if (reliefOpen && !anyMoving && totalQ > 0.1) warnings.push("Pump flow is going over the relief valve (circuit dead-headed or actuators idle).");
  if (!reliefs.length && pumps.some(function (cp) { return cp.type === "pumpFixed" || cp.type === "powerPack"; })) warnings.push("No pressure relief valve detected for a fixed-displacement source.");
  cyls.forEach(function (cy) {
    if (cy.starving) warnings.push((cy.comp.label || cy.comp.id) + ": supply starved (possible cavitation) — increase flow or opening.");
    if (Math.abs(cy.v) > 250) warnings.push((cy.comp.label || cy.comp.id) + " speed is very high; check flow and pipe size.");
  });
  for (var pj = 0; pj < pumps.length; pj++) {
    var cj = pumps[pj], iPj = pOf(cj.id, "P");
    if (iPj >= 0 && p[iPj] > num(cj.props.maxPressureBar, 320) + 5) { warnings.push((cj.label || cj.id) + ": maximum pressure exceeded — check relief protection."); break; }
  }

  if (opts.debug) {
    return { _dbg: true, N: N, nodeKeys: nodeKeys.slice(), p: Array.from(p),
      edges: edges.map(function(e){return {a:e.a,b:e.b,tag:e.tag,cid:e.compId,gNow:e.gNow,flow:e.flow};}),
      injections: injections.map(function(s){var r={n:s.node,tag:s.tag,cid:s.compId,qNow:s.qNow,q:s.q,hasDyn:!!s.dynQ}; try{r.dynAt0=s.dynQ?s.dynQ(0):null;}catch(e){r.err=String(e);} return r;}) };
  }
  return {
    totalFlowLpm: totalQ,
    activeFlowLpm: activeQ,
    pressureBar: pressureBar,
    reliefSetting: reliefSetting,
    powerKw: powerKw,
    oilTempC: oilTempC,
    time: TIME,
    cylinders: cylOut,
    motors: motorOut,
    lines: lineOut.map(function (l) { return { id: l.id, velocityMps: l.velocityMps, flowLpm: l.flowLpm, active: l.active, high: l.high, pressureBar: l.pressureBar }; }),
    warnings: warnings.slice(0, 40),
    comp: compMap,
    accumulators: accums.map(function (c) {
      var f = 0;
      for (var j = 0; j < accumEdges.length; j++) if (accumEdges[j].comp.id === c.id) f = accumEdges[j].flow || 0;
      return { id: c.id, flowLpm: f }; // + = charging
    }),
  };
}
rgzFluidSolve._dyn = null;
