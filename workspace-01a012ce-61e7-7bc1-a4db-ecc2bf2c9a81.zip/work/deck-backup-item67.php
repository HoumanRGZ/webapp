<?php
/**
 * RGZ Mechanical Deck — landing page ("deck") for all RGZ engineering apps,
 * backend app manager, guided-tour settings and the Learning Hub content.
 *
 * Part of the RGZ Engineering Studio plugin. Version 1.0.0.
 */
if (!defined('ABSPATH')) { exit; }

final class RGZ_Mechanical_Deck {
    const VERSION        = '1.0.0';
    const OPT_SETTINGS   = 'rgz_mech_deck_settings';
    const OPT_APPS       = 'rgz_mech_deck_apps';
    const OPT_LESSONS    = 'rgz_mech_deck_lessons';
    const SHORTCODE_DECK = 'rgz_mechanical_deck';
    const SHORTCODE_LEARN = 'rgz_learning_hub';

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'admin_menu'], 8);
        add_action('admin_init', [__CLASS__, 'handle_posts']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'admin_assets']);
        add_action('admin_post_rgz_mech_export', [__CLASS__, 'export_json']);
        add_action('admin_post_rgz_mech_import_file', [__CLASS__, 'import_json']);
        add_shortcode(self::SHORTCODE_DECK, [__CLASS__, 'render_deck']);
        add_shortcode(self::SHORTCODE_LEARN, [__CLASS__, 'render_learn']);
    }

    /* ============================================================ */
    /* Defaults & getters                                           */
    /* ============================================================ */

    public static function default_settings() {
        return [
            'heroTitle'    => 'Mechanical Engineering Deck',
            'heroSubtitle' => 'Interactive engineering simulators and learning tools. Pick an app, design the system, simulate its behaviour and learn the theory — all in the browser.',
            'accent'       => '#eb4e3c',
            'showSearch'   => true,
            'showFilters'  => true,
            'learnPageUrl' => '',
            'tourHydraulic'=> true,
            'tourPneumatic'=> true,
            'tourTextHydraulic' => 'Welcome to Hydraulic Studio! Design, validate and simulate real hydraulic circuits right here in your browser. New here? Take the 60-second guided tour — or jump straight into the app.',
            'tourTextPneumatic' => 'Welcome to Pneumatic Studio! Build and simulate pneumatic and electropneumatic circuits right here in your browser. New here? Take the 60-second guided tour — or jump straight into the app.',
        ];
    }

    public static function get_settings() {
        $saved = get_option(self::OPT_SETTINGS, []);
        if (!is_array($saved)) { $saved = []; }
        return array_merge(self::default_settings(), $saved);
    }

    public static function default_apps() {
        $hyd_url = '';
        $pne_url = '';
        if (class_exists('RGZ_Hydraulic_Studio_Plugin') && method_exists('RGZ_Hydraulic_Studio_Plugin', 'studio_url')) {
            $hyd_url = RGZ_Hydraulic_Studio_Plugin::studio_url();
        }
        if (class_exists('RGZ_Pneumatic_Studio_Plugin') && method_exists('RGZ_Pneumatic_Studio_Plugin', 'studio_url')) {
            $pne_url = RGZ_Pneumatic_Studio_Plugin::studio_url();
        }
        return [
            [
                'id' => 'hydraulic-studio',
                'title' => 'Hydraulic Studio',
                'desc' => 'Design, validate and simulate hydraulic circuits with ISO 1219 symbols. Includes a full power pack builder, cartridge and proportional valves, live pressure/flow computation and 60+ ready examples.',
                'category' => 'Fluid Power',
                'icon' => 'hydraulic',
                'accent' => '#38bdf8',
                'badge' => 'Simulator',
                'url' => $hyd_url,
                'learnTopic' => 'hydraulics',
                'enabled' => true,
            ],
            [
                'id' => 'pneumatic-studio',
                'title' => 'Pneumatic Studio',
                'desc' => 'Build pneumatic circuits with compressors, FRL units, 3/2–5/3 valves, cylinders and Festo-style electropneumatic control. Validate, simulate and animate the circuit in real time.',
                'category' => 'Fluid Power',
                'icon' => 'pneumatic',
                'accent' => '#e8793c',
                'badge' => 'Simulator',
                'url' => $pne_url,
                'learnTopic' => 'pneumatics',
                'enabled' => true,
            ],
        ];
    }

    public static function get_apps($only_enabled = false) {
        $apps = get_option(self::OPT_APPS, null);
        if (!is_array($apps)) { $apps = self::default_apps(); }
        $apps = array_values(array_filter($apps, 'is_array'));
        foreach ($apps as $i => $a) {
            if (isset($a['tourKey']) && !isset($a['learnTopic'])) {
                $a['learnTopic'] = 'hydraulic' === $a['tourKey'] ? 'hydraulics' : ('pneumatic' === $a['tourKey'] ? 'pneumatics' : '');
                unset($a['tourKey']);
            }
            if (isset($a['learnTopic']) && !in_array($a['learnTopic'], ['', 'hydraulics', 'pneumatics', 'general'], true)) {
                $a['learnTopic'] = '';
            }
            $apps[$i] = $a;
        }
        if ($only_enabled) {
            $apps = array_values(array_filter($apps, function ($a) { return !empty($a['enabled']); }));
        }
        return $apps;
    }

    public static function get_lessons($only_enabled = false) {
        $lessons = get_option(self::OPT_LESSONS, null);
        if (!is_array($lessons)) { $lessons = self::default_lessons(); }
        $lessons = array_values(array_filter($lessons, 'is_array'));
        if ($only_enabled) {
            $lessons = array_values(array_filter($lessons, function ($l) { return !empty($l['enabled']); }));
        }
        return $lessons;
    }

    public static function tour_enabled($app) {
        $s = self::get_settings();
        if ('hydraulic' === $app) { return !empty($s['tourHydraulic']); }
        if ('pneumatic' === $app) { return !empty($s['tourPneumatic']); }
        return false;
    }

    public static function tour_text($app) {
        $s = self::get_settings();
        if ('hydraulic' === $app) { return is_string($s['tourTextHydraulic'] ?? '') ? $s['tourTextHydraulic'] : ''; }
        if ('pneumatic' === $app) { return is_string($s['tourTextPneumatic'] ?? '') ? $s['tourTextPneumatic'] : ''; }
        return '';
    }

    public static function app_categories($apps) {
        $cats = ['Fluid Power', 'Drives & Motors', 'Electrical', 'Mechanics', 'Thermal', 'Measurements', 'CAD & Design'];
        foreach ((array) $apps as $a) {
            if (!empty($a['category']) && !in_array($a['category'], $cats, true)) { $cats[] = $a['category']; }
        }
        return $cats;
    }

    /* ============================================================ */
    /* Icon library (stroke SVG, currentColor)                      */
    /* ============================================================ */

    public static function icons() {
        $p = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">';
        return [
            'hydraulic' => $p . '<path d="M12 2.7s6.5 7.2 6.5 11.6a6.5 6.5 0 0 1-13 0C5.5 9.9 12 2.7 12 2.7Z"/><path d="M9 14.5a3.2 3.2 0 0 0 3 3"/></svg>',
            'pneumatic' => $p . '<path d="M3 11h9.5a3 3 0 1 0-3-3"/><path d="M3 15.5h13.5a3 3 0 1 1-3 3"/><path d="M3 19.5h5"/></svg>',
            'gear'     => $p . '<circle cx="12" cy="12" r="3.4"/><path d="M12 2.8v3M12 18.2v3M4.5 6.5l2.1 2.1M17.4 15.4l2.1 2.1M2.8 12h3M18.2 12h3M4.5 17.5l2.1-2.1M17.4 8.6l2.1-2.1"/></svg>',
            'electric' => $p . '<path d="M13 2.5 4.5 13.5H11l-1 8 8.5-11H12l1-8Z"/></svg>',
            'motor'    => $p . '<circle cx="12" cy="12" r="8.5"/><path d="M12 3.5v3M12 17.5v3M3.5 12h3M17.5 12h3"/><path d="M9.5 9.5h5v5h-5z"/></svg>',
            'pump'     => $p . '<circle cx="12" cy="12" r="6"/><path d="M12 2v4M12 18v4M4.2 15.5l2.8-2.8M19.8 8.5 17 11.3"/><path d="M10 8.5v7l6-3.5z" fill="currentColor" stroke="none"/></svg>',
            'valve'    => $p . '<rect x="3" y="8" width="18" height="8"/><path d="M9 8v8M15 8v8M5 12h2M17 12h2M12 4v4M12 16v4"/></svg>',
            'cylinder' => $p . '<rect x="2.5" y="9" width="13" height="6"/><path d="M15.5 12h6M7 4v5M7 20v-5"/></svg>',
            'gauge'    => $p . '<circle cx="12" cy="13" r="8.5"/><path d="M12 13l4-4.5M6.5 19.5h11"/></svg>',
            'robot'    => $p . '<rect x="5" y="8" width="14" height="10" rx="2"/><path d="M12 4v4M8.5 18v3M15.5 18v3"/><circle cx="9.3" cy="12.5" r="1.1" fill="currentColor" stroke="none"/><circle cx="14.7" cy="12.5" r="1.1" fill="currentColor" stroke="none"/></svg>',
            'thermal'  => $p . '<path d="M12 2.8s5 4.5 5 9a5 5 0 0 1-10 0c0-2 1-3.9 2.2-5.2.4 1.2 1.1 2 2 2.4-.1-2.1.2-4.3.8-6.2Z"/><path d="M12 21.2a3 3 0 0 0 3-3"/></svg>',
            'cad'      => $p . '<path d="M12 2.5 21 7.5v9l-9 5-9-5v-9l9-5Z"/><path d="M12 12 21 7.5M12 12v9.5M12 12 3 7.5"/></svg>',
            'wrench'   => $p . '<path d="M14.5 6.5a4 4 0 0 0-5.6 5L3 17.4V21h3.6l5.9-5.9a4 4 0 0 0 5-5.6L14 13l-3-3 3.5-3.5Z"/></svg>',
            'book'     => $p . '<path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v17.5H6.5A2.5 2.5 0 0 0 4 22V4.5Z"/><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M8 6.5h8M8 10h6"/></svg>',
            'flow'     => $p . '<path d="M3 6c4 0 5 3 9 3s5-3 9-3"/><path d="M3 12c4 0 5 3 9 3s5-3 9-3"/><path d="M3 18c4 0 5 3 9 3s5-3 9-3"/></svg>',
            'spring'   => $p . '<path d="M4 5h16M4 19h16"/><path d="M6 5c4 0-4 3.5 0 3.5S2 12 6 12s-4 3.5 0 3.5S2 19 6 19" transform="translate(3 0)"/></svg>',
            'generic'  => $p . '<rect x="3.5" y="3.5" width="17" height="17" rx="3"/><path d="M8.5 12h7M12 8.5v7"/></svg>',
        ];
    }

    public static function icon_svg($key) {
        $icons = self::icons();
        return isset($icons[$key]) ? $icons[$key] : $icons['generic'];
    }

    /* ============================================================ */
    /* Admin menus & assets                                         */
    /* ============================================================ */

    public static function admin_menu() {
        add_submenu_page(
            'rgz-engineering-studio',
            'Mechanical Deck',
            'Mechanical Deck',
            'manage_options',
            'rgz-mechanical-deck',
            [__CLASS__, 'render_deck_admin']
        );
        add_submenu_page(
            'rgz-engineering-studio',
            'Learning Hub',
            'Learning Hub',
            'manage_options',
            'rgz-learning-hub',
            [__CLASS__, 'render_learn_admin']
        );
    }

    public static function admin_assets($hook) {
        $pages = [
            'toplevel_page_rgz-engineering-studio',
            'rgz-engineering-studio_page_rgz-mechanical-deck',
            'rgz-engineering-studio_page_rgz-learning-hub',
        ];
        if (!in_array($hook, $pages, true)) { return; }
        $base = plugin_dir_url(__FILE__) . 'assets/';
        $css  = plugin_dir_path(__FILE__) . 'assets/admin-deck.css';
        $js   = plugin_dir_path(__FILE__) . 'assets/admin-deck.js';
        $ver  = self::VERSION . '-' . (file_exists($css) ? filemtime($css) : '1');
        wp_enqueue_style('rgz-admin-deck', $base . 'admin-deck.css', [], $ver);
        /* deck.css is reused for the live card preview inside the editor */
        $front_css = plugin_dir_path(__FILE__) . 'assets/deck.css';
        wp_enqueue_style('rgz-deck', $base . 'deck.css', [], self::VERSION . '-' . (file_exists($front_css) ? filemtime($front_css) : '1'));
        wp_enqueue_script('rgz-admin-deck', $base . 'admin-deck.js', [], self::VERSION . '-' . (file_exists($js) ? filemtime($js) : '1'), true);
        wp_localize_script('rgz-admin-deck', 'rgzaDeckEditor', [
            'icons'      => self::icons(),
            'categories' => self::app_categories(self::get_apps()),
            'learnTopics' => [
                ['key' => '', 'label' => '— No learning link'],
                ['key' => 'hydraulics', 'label' => 'Hydraulics topics'],
                ['key' => 'pneumatics', 'label' => 'Pneumatics topics'],
                ['key' => 'general', 'label' => 'General topics'],
            ],
        ]);
    }

    /* ============================================================ */
    /* POST handling (with PRG redirects)                           */
    /* ============================================================ */

    private static function go($page, $args = []) {
        wp_safe_redirect(add_query_arg(array_merge(['page' => $page], $args), admin_url('admin.php')));
        exit;
    }

    public static function handle_posts() {
        if (!empty($_POST['rgz_mech_settings_save'])) {
            if (!current_user_can('manage_options') || !check_admin_referer('rgz_mech_settings')) { return; }
            self::save_settings();
            self::go('rgz-mechanical-deck', ['saved' => 'settings', '_' => time()]);
        }
        if (!empty($_POST['rgz_mech_apps_save'])) {
            if (!current_user_can('manage_options') || !check_admin_referer('rgz_mech_apps')) { return; }
            $ok = self::save_apps();
            self::go('rgz-mechanical-deck', ['saved' => $ok ? 'apps' : 'apps_err', '_' => time()]);
        }
        if (!empty($_POST['rgz_mech_reset'])) {
            if (!current_user_can('manage_options') || !check_admin_referer('rgz_mech_reset')) { return; }
            delete_option(self::OPT_SETTINGS);
            delete_option(self::OPT_APPS);
            delete_option(self::OPT_LESSONS);
            self::go('rgz-mechanical-deck', ['saved' => 'reset', '_' => time()]);
        }
        if (!empty($_POST['rgz_mech_lesson_save'])) {
            if (!current_user_can('manage_options') || !check_admin_referer('rgz_mech_lesson')) { return; }
            self::save_lesson();
            self::go('rgz-learning-hub', ['saved' => 'lesson', '_' => time()]);
        }
        if (!empty($_POST['rgz_mech_lessons_seed'])) {
            if (!current_user_can('manage_options') || !check_admin_referer('rgz_mech_lessons_seed')) { return; }
            self::seed_default_lessons();
            self::go('rgz-learning-hub', ['saved' => 'seeded', '_' => time()]);
        }
        if (!empty($_POST['rgz_mech_lessons_refresh'])) {
            if (!current_user_can('manage_options') || !check_admin_referer('rgz_mech_lessons_refresh')) { return; }
            self::refresh_default_lessons();
            self::go('rgz-learning-hub', ['saved' => 'refreshed', '_' => time()]);
        }
        if (!empty($_POST['rgz_mech_lesson_delete'])) {
            if (!current_user_can('manage_options') || !check_admin_referer('rgz_mech_lesson_' . (isset($_POST['lesson_id']) ? sanitize_text_field(wp_unslash($_POST['lesson_id'])) : '0'))) { return; }
            self::delete_lesson();
            self::go('rgz-learning-hub', ['saved' => 'lesson_del', '_' => time()]);
        }
    }

    public static function save_settings() {
        $in = wp_unslash($_POST);
        $scope = isset($in['settings_scope']) ? sanitize_key($in['settings_scope']) : 'appearance';
        $s = self::get_settings();
        if ('tours' === $scope) {
            $s['tourHydraulic'] = !empty($in['tourHydraulic']);
            $s['tourPneumatic'] = !empty($in['tourPneumatic']);
            $s['tourTextHydraulic'] = isset($in['tourTextHydraulic']) ? sanitize_textarea_field($in['tourTextHydraulic']) : '';
            $s['tourTextPneumatic'] = isset($in['tourTextPneumatic']) ? sanitize_textarea_field($in['tourTextPneumatic']) : '';
        } else {
            $accent = isset($in['heroAccent']) ? sanitize_hex_color($in['heroAccent']) : '';
            $s['heroTitle']    = isset($in['heroTitle']) ? sanitize_text_field($in['heroTitle']) : '';
            $s['heroSubtitle'] = isset($in['heroSubtitle']) ? sanitize_textarea_field($in['heroSubtitle']) : '';
            $s['accent']       = $accent ? $accent : '#eb4e3c';
            $s['showSearch']   = !empty($in['showSearch']);
            $s['showFilters']  = !empty($in['showFilters']);
            $s['learnPageUrl'] = isset($in['learnPageUrl']) ? esc_url_raw($in['learnPageUrl']) : '';
        }
        update_option(self::OPT_SETTINGS, $s);
    }

    public static function save_apps() {
        $raw = isset($_POST['rgz_apps_json']) ? wp_unslash($_POST['rgz_apps_json']) : '';
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) { return false; }
        $icon_keys = array_keys(self::icons());
        $clean = [];
        foreach ($decoded as $a) {
            if (!is_array($a)) { continue; }
            $id = isset($a['id']) && '' !== $a['id'] ? sanitize_key($a['id']) : 'app-' . wp_generate_password(6, false, false);
            $icon = isset($a['icon']) ? sanitize_key($a['icon']) : 'generic';
            if (!in_array($icon, $icon_keys, true)) { $icon = 'generic'; }
            $accent = isset($a['accent']) ? sanitize_hex_color($a['accent']) : '';
            $tour = isset($a['learnTopic']) ? sanitize_key($a['learnTopic']) : (isset($a['tourKey']) ? sanitize_key($a['tourKey']) : '');
            if ('hydraulic' === $tour) { $tour = 'hydraulics'; }
            if ('pneumatic' === $tour) { $tour = 'pneumatics'; }
            if (!in_array($tour, ['', 'hydraulics', 'pneumatics', 'general'], true)) { $tour = ''; }
            $clean[] = [
                'id'       => $id,
                'title'    => isset($a['title']) ? sanitize_text_field($a['title']) : '',
                'desc'     => isset($a['desc']) ? sanitize_textarea_field($a['desc']) : '',
                'category' => isset($a['category']) ? sanitize_text_field($a['category']) : '',
                'icon'     => $icon,
                'accent'   => $accent ? $accent : '#38bdf8',
                'badge'    => isset($a['badge']) ? sanitize_text_field($a['badge']) : '',
                'url'      => isset($a['url']) ? esc_url_raw($a['url']) : '',
                'learnTopic' => $tour,
                'enabled'  => !empty($a['enabled']),
            ];
        }
        update_option(self::OPT_APPS, $clean);
        return true;
    }

    public static function sanitize_lesson($l, $fallback_id = '') {
        $topic = isset($l['topic']) ? sanitize_key($l['topic']) : 'general';
        if (!in_array($topic, ['hydraulics', 'pneumatics', 'general'], true)) { $topic = 'general'; }
        $level = isset($l['level']) ? sanitize_key($l['level']) : 'beginner';
        if (!in_array($level, ['beginner', 'intermediate', 'advanced'], true)) { $level = 'beginner'; }
        $id = isset($l['id']) && '' !== $l['id'] ? sanitize_key($l['id']) : ($fallback_id ? $fallback_id : 'les-' . wp_generate_password(6, false, false));
        return [
            'id'      => $id,
            'title'   => isset($l['title']) ? sanitize_text_field($l['title']) : '',
            'summary' => isset($l['summary']) ? sanitize_textarea_field($l['summary']) : '',
            'topic'   => $topic,
            'level'   => $level,
            'minutes' => max(1, min(180, isset($l['minutes']) ? absint($l['minutes']) : 5)),
            'content' => isset($l['content']) ? wp_kses_post($l['content']) : '',
            'cover'   => isset($l['cover']) ? esc_url_raw($l['cover']) : '',
            'enabled' => !empty($l['enabled']),
        ];
    }

    public static function save_lesson() {
        $in = wp_unslash($_POST);
        $in['enabled'] = !empty($in['enabled']);
        $lesson = self::sanitize_lesson($in);
        $lessons = self::get_lessons();
        $found = false;
        foreach ($lessons as $i => $l) {
            if ($l['id'] === $lesson['id']) { $lessons[$i] = $lesson; $found = true; break; }
        }
        if (!$found) { $lessons[] = $lesson; }
        update_option(self::OPT_LESSONS, $lessons);
    }

    public static function delete_lesson() {
        $id = isset($_POST['lesson_id']) ? sanitize_text_field(wp_unslash($_POST['lesson_id'])) : '';
        $lessons = array_values(array_filter(self::get_lessons(), function ($l) use ($id) { return $l['id'] !== $id; }));
        update_option(self::OPT_LESSONS, $lessons);
    }

    /* ============================================================ */
    /* Export / Import                                              */
    /* ============================================================ */

    public static function export_json() {
        if (!current_user_can('manage_options')) { wp_die('Permission denied.'); }
        check_admin_referer('rgz_mech_export');
        $payload = [
            'kind'     => 'rgz-mechanical-deck',
            'version'  => self::VERSION,
            'exported' => gmdate('c'),
            'settings' => self::get_settings(),
            'apps'     => self::get_apps(),
            'lessons'  => self::get_lessons(),
        ];
        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename=rgz-mechanical-deck-' . gmdate('Ymd-His') . '.json');
        echo wp_json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    public static function import_json() {
        if (!current_user_can('manage_options')) { wp_die('Permission denied.'); }
        check_admin_referer('rgz_mech_import');
        $err = '';
        if (empty($_FILES['rgz_import']['tmp_name']) || !is_uploaded_file($_FILES['rgz_import']['tmp_name'])) {
            $err = 'nofile';
        } else {
            $raw = file_get_contents($_FILES['rgz_import']['tmp_name']);
            $data = json_decode($raw, true);
            if (!is_array($data) || ($data['kind'] ?? '') !== 'rgz-mechanical-deck') {
                $err = 'badfile';
            } else {
                if (isset($data['settings']) && is_array($data['settings'])) {
                    $s = array_merge(self::default_settings(), array_intersect_key($data['settings'], self::default_settings()));
                    $accent = sanitize_hex_color($s['accent']);
                    $s['accent'] = $accent ? $accent : '#38bdf8';
                    $s['heroTitle'] = sanitize_text_field($s['heroTitle']);
                    $s['heroSubtitle'] = sanitize_textarea_field($s['heroSubtitle']);
                    $s['learnPageUrl'] = esc_url_raw($s['learnPageUrl']);
                    foreach (['showSearch','showFilters','tourHydraulic','tourPneumatic'] as $b) { $s[$b] = !empty($s[$b]); }
                    update_option(self::OPT_SETTINGS, $s);
                }
                if (isset($data['apps']) && is_array($data['apps'])) {
                    $_POST['rgz_apps_json'] = wp_json_encode($data['apps']);
                    self::save_apps();
                }
                if (isset($data['lessons']) && is_array($data['lessons'])) {
                    $clean = [];
                    foreach ($data['lessons'] as $l) {
                        if (is_array($l)) { $clean[] = self::sanitize_lesson($l); }
                    }
                    update_option(self::OPT_LESSONS, $clean);
                }
            }
        }
        self::go('rgz-mechanical-deck', array_merge(['saved' => $err ? 'import_err' : 'import', '_' => time()], $err ? ['err' => $err] : []));
    }

    /* ============================================================ */
    /* Admin: Overview (delegated from the parent menu)             */
    /* ============================================================ */

    public static function render_overview() {
        if (!current_user_can('manage_options')) { wp_die('Permission denied.'); }
        $s = self::get_settings();
        $apps = self::get_apps();
        $enabled = array_values(array_filter($apps, function ($a) { return !empty($a['enabled']); }));
        $lessons = self::get_lessons();
        $deck_page = self::find_page_with_shortcode(self::SHORTCODE_DECK);
        $learn_page = $s['learnPageUrl'] ? $s['learnPageUrl'] : self::find_page_with_shortcode(self::SHORTCODE_LEARN, true);
        ?>
        <div class="rgza">
          <div class="rgza-hero">
            <span class="ver">v<?php echo esc_html(self::VERSION); ?></span>
            <span class="kick">RGZ Engineering Studio</span>
            <h1>Control center</h1>
            <p>Manage your mechanical engineering deck: apps on the landing page, guided onboarding tours, learning content and the two fluid-power studios.</p>
          </div>

          <div class="rgza-stats">
            <div class="rgza-stat" style="--sc:#38bdf8"><b><?php echo count($enabled); ?></b><span>Apps on deck</span></div>
            <div class="rgza-stat" style="--sc:#a78bfa"><b><?php echo count($apps); ?></b><span>Total apps</span></div>
            <div class="rgza-stat" style="--sc:#e8793c"><b><?php echo count($lessons); ?></b><span>Lessons</span></div>
            <div class="rgza-stat" style="--sc:#16a34a"><b><?php echo (self::tour_enabled('hydraulic') ? 1 : 0) + (self::tour_enabled('pneumatic') ? 1 : 0); ?> / 2</b><span>Tours enabled</span></div>
          </div>

          <div class="rgza-card">
            <h2>Manage</h2>
            <p class="sub">Everything about the deck and its content lives in these two screens.</p>
            <div class="rgza-quick">
              <a href="<?php echo esc_url(admin_url('admin.php?page=rgz-mechanical-deck')); ?>"><b>⚙ Mechanical Deck</b><span>Apps on the landing page, hero, colors, guided tours, export/import.</span></a>
              <a href="<?php echo esc_url(admin_url('admin.php?page=rgz-learning-hub')); ?>"><b>📚 Learning Hub content</b><span>Theory articles about hydraulics and pneumatics shown to your users.</span></a>
              <a href="<?php echo esc_url(admin_url('admin.php?page=rgz-hydraulics')); ?>"><b>💧 Hydraulics admin</b><span>Designs, accounts and submissions of the Hydraulic Studio.</span></a>
              <a href="<?php echo esc_url(admin_url('admin.php?page=rgz-pneumatics')); ?>"><b>💨 Pneumatics admin</b><span>Designs, accounts and submissions of the Pneumatic Studio.</span></a>
              <?php if ($deck_page) : ?><a href="<?php echo esc_url($deck_page); ?>" target="_blank" rel="noopener"><b>↗ View deck page</b><span>Open the public landing page in a new tab.</span></a><?php endif; ?>
              <?php if ($learn_page) : ?><a href="<?php echo esc_url($learn_page); ?>" target="_blank" rel="noopener"><b>↗ View learning hub</b><span>Open the public learning page in a new tab.</span></a><?php endif; ?>
            </div>
          </div>

          <div class="rgza-card">
            <h2>Shortcodes</h2>
            <p class="sub">Paste these into any page to publish the apps, the deck or the learning hub.</p>
            <p>
              <span class="rgza-code">[rgz_mechanical_deck] <button type="button" data-copy="[rgz_mechanical_deck]">Copy</button></span>
              <span class="rgza-code">[rgz_learning_hub] <button type="button" data-copy="[rgz_learning_hub]">Copy</button></span>
              <span class="rgza-code">[rgz_hydraulic_studio] <button type="button" data-copy="[rgz_hydraulic_studio]">Copy</button></span>
              <span class="rgza-code">[rgz_pneumatic_studio] <button type="button" data-copy="[rgz_pneumatic_studio]">Copy</button></span>
            </p>
            <p class="hint" style="color:#64748b;font-size:12.5px;margin:10px 0 0">Tip: create one “Mechanical Deck” page with <code>[rgz_mechanical_deck]</code> and link your apps to the pages that contain each studio shortcode.</p>
          </div>
        </div>
        <?php
    }

    /* ============================================================ */
    /* Admin: Mechanical Deck                                       */
    /* ============================================================ */

    public static function render_deck_admin() {
        if (!current_user_can('manage_options')) { wp_die('Permission denied.'); }
        $s = self::get_settings();
        $apps = self::get_apps();
        $apps_json = wp_json_encode($apps, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $saved = isset($_GET['saved']) ? sanitize_key($_GET['saved']) : '';
        ?>
        <div class="rgza">
          <div class="rgza-hero">
            <span class="ver">v<?php echo esc_html(self::VERSION); ?></span>
            <span class="kick">Mechanical Engineering Deck</span>
            <h1>Deck manager</h1>
            <p>Design the landing page for all your engineering apps — reorder, brand and link every app, control the guided tutorials and back up the whole deck as JSON.</p>
          </div>

          <?php if ($saved) : ?>
            <div class="rgza-notice <?php echo in_array($saved, ['apps_err', 'import_err'], true) ? 'err' : 'ok'; ?>">
              <?php
              $msg = [
                  'settings' => 'Appearance & tutorial settings saved.',
                  'apps' => 'Apps saved. The deck page is updated.',
                  'apps_err' => 'Could not decode the apps payload — nothing was saved.',
                  'reset' => 'Deck reset to factory defaults.',
                  'import' => 'Deck imported successfully.',
                  'import_err' => 'Import failed — please upload a valid RGZ deck JSON file.',
              ];
              echo esc_html(isset($msg[$saved]) ? $msg[$saved] : 'Saved.');
              ?>
            </div>
          <?php endif; ?>

          <div class="rgza-tabs" data-rgza-tabs>
            <button type="button" class="rgza-tab on" data-tab="rgza-apps">Apps</button>
            <button type="button" class="rgza-tab" data-tab="rgza-look">Appearance</button>
            <button type="button" class="rgza-tab" data-tab="rgza-tours">Tutorials</button>
            <button type="button" class="rgza-tab" data-tab="rgza-data">Data</button>
          </div>

          <!-- ================= APPS ================= -->
          <div class="rgza-pane on" id="rgza-apps">
            <form method="post">
              <?php wp_nonce_field('rgz_mech_apps'); ?>
              <div class="rgza-card" data-rgza-apps>
                <h2>Apps on the deck</h2>
                <p class="sub">Drag rows to reorder, click a row to edit. Disabled apps stay here but are hidden from the public deck — perfect for preparing the next 10+ apps.</p>
                <input type="hidden" id="rgz-apps-json" name="rgz_apps_json" value="<?php echo esc_attr($apps_json); ?>">
                <div data-rows></div>
                <p style="margin:14px 0 0"><button type="button" class="rgza-btn ghost" data-add-app>＋ Add app</button></p>
              </div>
              <div class="rgza-card">
                <h2>Live preview</h2>
                <p class="sub">How the first cards will look on the public page.</p>
                <div class="rgza-preview" data-preview></div>
                <p style="margin:18px 0 0;display:flex;gap:10px;flex-wrap:wrap">
                  <button type="submit" class="rgza-btn primary" name="rgz_mech_apps_save" value="1">Save apps</button>
                  <a class="rgza-btn ghost" href="<?php echo esc_url(self::find_page_with_shortcode(self::SHORTCODE_DECK) ? self::find_page_with_shortcode(self::SHORTCODE_DECK) : '#'); ?>" target="_blank" rel="noopener">View page ↗</a>
                </p>
              </div>
            </form>
          </div>

          <!-- ================= APPEARANCE ================= -->
          <div class="rgza-pane" id="rgza-look">
            <form method="post">
              <?php wp_nonce_field('rgz_mech_settings'); ?>
              <input type="hidden" name="settings_scope" value="appearance">
              <div class="rgza-card">
                <h2>Landing page appearance</h2>
                <p class="sub">Hero section and behaviour of the <code>[rgz_mechanical_deck]</code> shortcode.</p>
                <div class="rgza-grid2">
                  <div class="fld">
                    <label class="lbl" for="rgzHeroTitle">Hero title</label>
                    <input type="text" id="rgzHeroTitle" name="heroTitle" value="<?php echo esc_attr($s['heroTitle']); ?>">
                  </div>
                  <div class="fld">
                    <label class="lbl" for="rgzHeroAccent">Accent color</label>
                    <input type="color" id="rgzHeroAccent" name="heroAccent" value="<?php echo esc_attr($s['accent']); ?>">
                  </div>
                </div>
                <div class="fld">
                  <label class="lbl" for="rgzHeroSub">Hero subtitle</label>
                  <input type="text" id="rgzHeroSub" name="heroSubtitle" value="<?php echo esc_attr($s['heroSubtitle']); ?>">
                </div>
                <div class="rgza-grid2">
                  <div class="fld"><label class="rgza-switch"><input type="checkbox" name="showSearch" <?php checked(!empty($s['showSearch'])); ?>><span class="tr"></span><span class="ts">Show search box</span></label></div>
                  <div class="fld"><label class="rgza-switch"><input type="checkbox" name="showFilters" <?php checked(!empty($s['showFilters'])); ?>><span class="tr"></span><span class="ts">Show category filter chips</span></label></div>
                  <div class="fld">
                    <label class="lbl" for="rgzLearnUrl">Learning hub URL (optional)</label>
                    <input type="url" id="rgzLearnUrl" name="learnPageUrl" value="<?php echo esc_attr($s['learnPageUrl']); ?>" placeholder="https://yoursite.tld/learn/">
                    <p class="hint">Leave empty to auto-detect the page that contains <code>[rgz_learning_hub]</code>.</p>
                  </div>
                </div>
                <p style="margin:6px 0 0"><button type="submit" class="rgza-btn primary" name="rgz_mech_settings_save" value="1">Save appearance</button></p>
              </div>
            </form>
          </div>

          <!-- ================= TOURS ================= -->
          <div class="rgza-pane" id="rgza-tours">
            <form method="post">
              <?php wp_nonce_field('rgz_mech_settings'); ?>
              <input type="hidden" name="settings_scope" value="tours">
              <div class="rgza-card">
                <h2>Guided tutorials (first-visit walkthroughs)</h2>
                <p class="sub">Each studio shows an interactive step-by-step tour the first time a visitor opens it. Visitors can skip at any time with the Skip button or Esc — and it never shows again afterwards.</p>
                <div class="rgza-grid2">
                  <div class="fld"><label class="rgza-switch"><input type="checkbox" name="tourHydraulic" <?php checked(!empty($s['tourHydraulic'])); ?>><span class="tr"></span><span class="ts">Hydraulic Studio welcome + tour</span></label></div>
                  <div class="fld"><label class="rgza-switch"><input type="checkbox" name="tourPneumatic" <?php checked(!empty($s['tourPneumatic'])); ?>><span class="tr"></span><span class="ts">Pneumatic Studio welcome + tour</span></label></div>
                </div>
                <div class="rgza-note">
                  <b>How it works:</b> on a visitor's first visit, a welcome popup appears in the studio with two buttons —
                  <b>“Go to {app}”</b> (dismisses) and <b>“▶ Start tutorial”</b> (launches the step-by-step tour). The visitor never sees it again.
                  You can test the tour any time by appending <code>?rgz_tour=1</code> to the studio page URL.
                </div>
                <div class="fld">
                  <label class="lbl" for="rgzTourHyd">Welcome popup text — Hydraulic Studio</label>
                  <input type="text" id="rgzTourHyd" name="tourTextHydraulic" value="<?php echo esc_attr($s['tourTextHydraulic']); ?>">
                </div>
                <div class="fld">
                  <label class="lbl" for="rgzTourPne">Welcome popup text — Pneumatic Studio</label>
                  <input type="text" id="rgzTourPne" name="tourTextPneumatic" value="<?php echo esc_attr($s['tourTextPneumatic']); ?>">
                </div>
                <div class="rgza-note">
                  <b>Need help choosing text?</b> Keep it one or two sentences: what the app does and the choice between starting the tour or exploring freely.
                </div>
                <p style="margin:0"><button type="submit" class="rgza-btn primary" name="rgz_mech_settings_save" value="1">Save tutorial settings</button></p>
              </div>
            </form>
          </div>

          <!-- ================= DATA ================= -->
          <div class="rgza-pane" id="rgza-data">
            <div class="rgza-grid2">
              <div class="rgza-card">
                <h2>Backup</h2>
                <p class="sub">Download the whole deck — settings, apps and lessons — as one JSON file.</p>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                  <input type="hidden" name="action" value="rgz_mech_export">
                  <?php wp_nonce_field('rgz_mech_export'); ?>
                  <button type="submit" class="rgza-btn primary">Export deck (JSON)</button>
                </form>
              </div>
              <div class="rgza-card">
                <h2>Restore</h2>
                <p class="sub">Import a previously exported deck JSON. Current content will be replaced.</p>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" enctype="multipart/form-data">
                  <input type="hidden" name="action" value="rgz_mech_import_file">
                  <?php wp_nonce_field('rgz_mech_import'); ?>
                  <div class="fld"><input type="file" name="rgz_import" accept="application/json,.json" required></div>
                  <button type="submit" class="rgza-btn accent" onclick="return confirm('Replace the current deck with the imported content?')">Import deck</button>
                </form>
              </div>
            </div>
            <div class="rgza-card">
              <h2>Reset</h2>
              <p class="sub">Restore factory defaults: the two studio apps, the seeded lesson library and default appearance.</p>
              <form method="post">
                <?php wp_nonce_field('rgz_mech_reset'); ?>
                <button type="submit" class="rgza-btn danger" name="rgz_mech_reset" value="1" onclick="return confirm('Reset deck settings, apps AND lessons to defaults? This cannot be undone.');">Reset to defaults</button>
              </form>
            </div>
          </div>
        </div>
        <?php
    }

    /* ============================================================ */
    /* Admin: Learning Hub                                          */
    /* ============================================================ */

    public static function render_learn_admin() {
        if (!current_user_can('manage_options')) { wp_die('Permission denied.'); }
        $action = isset($_GET['action']) ? sanitize_key($_GET['action']) : '';
        $saved = isset($_GET['saved']) ? sanitize_key($_GET['saved']) : '';
        echo '<div class="rgza">';
        echo '<div class="rgza-hero"><span class="ver">v' . esc_html(self::VERSION) . '</span><span class="kick">Learning Hub</span><h1>Learning content</h1><p>Theory articles that teach hydraulics and pneumatics to your users — shown by the <code>[rgz_learning_hub]</code> shortcode, with topic and level filters plus read progress.</p></div>';
        if ($saved) {
            $msg = ['lesson' => 'Lesson saved.', 'lesson_del' => 'Lesson deleted.', 'seeded' => 'Missing default lessons were added to your library.', 'refreshed' => 'Factory lessons were refreshed (texts + pictures updated, publish states kept).'];
            echo '<div class="rgza-notice ok">' . esc_html(isset($msg[$saved]) ? $msg[$saved] : 'Saved.') . '</div>';
        }
        if ('edit' === $action || 'new' === $action) {
            self::render_lesson_form();
        } else {
            self::render_lesson_list();
        }
        echo '</div>';
    }

    private static function render_lesson_list() {
        $lessons = self::get_lessons();
        ?>
        <div class="rgza-card">
          <h2>Lessons (<?php echo count($lessons); ?>)</h2>
          <p class="sub" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
            <a class="rgza-btn primary small" href="<?php echo esc_url(admin_url('admin.php?page=rgz-learning-hub&action=new')); ?>">＋ Add lesson</a>
            <form method="post" style="display:inline">
              <?php wp_nonce_field('rgz_mech_lessons_seed'); ?>
              <button type="submit" class="rgza-btn ghost small" name="rgz_mech_lessons_seed" value="1">↓ Load missing default lessons</button>
            </form>
            <form method="post" style="display:inline" onsubmit="return confirm('Refresh the text and pictures of all factory lessons to the latest factory version? Your custom lessons and publish states are kept.');" >
              <?php wp_nonce_field('rgz_mech_lessons_refresh'); ?>
              <button type="submit" class="rgza-btn ghost small" name="rgz_mech_lessons_refresh" value="1">⟳ Refresh factory lessons</button>
            </form>
          </p>
          <table class="rgza-table">
            <thead><tr><th>Title</th><th>Topic</th><th>Level</th><th>Length</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($lessons as $l) : ?>
              <tr>
                <td><b><?php echo esc_html($l['title']); ?></b><br><span style="color:#64748b;font-size:12px"><?php echo esc_html(wp_trim_words($l['summary'], 14)); ?></span></td>
                <td><span class="rgza-pill <?php echo esc_attr($l['topic']); ?>"><?php echo esc_html($l['topic']); ?></span></td>
                <td><span class="rgza-pill"><?php echo esc_html($l['level']); ?></span></td>
                <td><?php echo (int) $l['minutes']; ?> min</td>
                <td><span class="rgza-pill <?php echo !empty($l['enabled']) ? 'on' : 'off'; ?>"><?php echo !empty($l['enabled']) ? 'published' : 'hidden'; ?></span></td>
                <td><a class="rgza-btn ghost small" href="<?php echo esc_url(admin_url('admin.php?page=rgz-learning-hub&action=edit&id=' . rawurlencode($l['id']))); ?>">Edit</a></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <?php
    }

    private static function render_lesson_form() {
        $id = isset($_GET['id']) ? sanitize_key($_GET['id']) : '';
        $lesson = null;
        if ($id) {
            foreach (self::get_lessons() as $l) { if ($l['id'] === $id) { $lesson = $l; break; } }
        }
        if (!$lesson) {
            $lesson = ['id' => '', 'title' => '', 'summary' => '', 'topic' => 'hydraulics', 'level' => 'beginner', 'minutes' => 6, 'content' => '', 'enabled' => true];
        }
        ?>
        <div class="rgza-card">
          <h2><?php echo $id ? 'Edit lesson' : 'New lesson'; ?></h2>
          <p class="sub"><a class="rgza-btn ghost small" href="<?php echo esc_url(admin_url('admin.php?page=rgz-learning-hub')); ?>">← All lessons</a></p>
          <form method="post">
            <?php wp_nonce_field('rgz_mech_lesson'); ?>
            <input type="hidden" name="id" value="<?php echo esc_attr($lesson['id']); ?>">
            <div class="rgza-grid2">
              <div class="fld"><label class="lbl">Title</label><input type="text" name="title" value="<?php echo esc_attr($lesson['title']); ?>" required></div>
              <div class="fld"><label class="lbl">Reading time (min)</label><input type="number" name="minutes" min="1" max="180" value="<?php echo (int) $lesson['minutes']; ?>"></div>
              <div class="fld"><label class="lbl">Topic</label>
                <select name="topic">
                  <option value="hydraulics" <?php selected($lesson['topic'], 'hydraulics'); ?>>Hydraulics</option>
                  <option value="pneumatics" <?php selected($lesson['topic'], 'pneumatics'); ?>>Pneumatics</option>
                  <option value="general" <?php selected($lesson['topic'], 'general'); ?>>General</option>
                </select>
              </div>
              <div class="fld"><label class="lbl">Level</label>
                <select name="level">
                  <option value="beginner" <?php selected($lesson['level'], 'beginner'); ?>>Beginner</option>
                  <option value="intermediate" <?php selected($lesson['level'], 'intermediate'); ?>>Intermediate</option>
                  <option value="advanced" <?php selected($lesson['level'], 'advanced'); ?>>Advanced</option>
                </select>
              </div>
            </div>
            <div class="fld"><label class="lbl">Summary (shown on the card)</label><input type="text" name="summary" value="<?php echo esc_attr($lesson['summary']); ?>"></div>
            <div class="fld"><label class="lbl">Cover image URL (optional)</label><input type="url" name="cover" value="<?php echo esc_attr(isset($lesson['cover']) ? $lesson['cover'] : ''); ?>" placeholder="https://… — shown on the card and on top of the reader">
              <p class="hint">Pictures make lessons stick. The bundled figures live in <code>assets/learn/</code> (SVG drawings + photos); paste an external image URL here for your own photos.</p>
            </div>
            <div class="fld">
              <label class="lbl">Content (HTML allowed)</label>
              <textarea name="content" rows="16"><?php echo esc_textarea($lesson['content']); ?></textarea>
              <p class="hint">Useful blocks: <code>&lt;div class="rgzl-formula"&gt;p = F / A&lt;/div&gt;</code> for formulas, <code>&lt;div class="rgzl-tip"&gt;…&lt;/div&gt;</code> for tips, and
                <code>&lt;figure class="rgzl-fig"&gt;&lt;img src="…" alt="…"&gt;&lt;figcaption&gt;caption&lt;/figcaption&gt;&lt;/figure&gt;</code> for pictures inside the text.</p>
            </div>
            <div class="fld"><label class="rgza-switch"><input type="checkbox" name="enabled" <?php checked(!empty($lesson['enabled'])); ?>><span class="tr"></span><span class="ts">Published</span></label></div>
            <p style="display:flex;gap:10px;flex-wrap:wrap;margin:0">
              <button type="submit" class="rgza-btn primary" name="rgz_mech_lesson_save" value="1">Save lesson</button>
            </p>
          </form>
          <?php if ($lesson['id']) : ?>
          <form method="post" onsubmit="return confirm('Delete this lesson permanently?');" style="margin-top:16px">
            <?php wp_nonce_field('rgz_mech_lesson_' . $lesson['id']); ?>
            <input type="hidden" name="lesson_id" value="<?php echo esc_attr($lesson['id']); ?>">
            <button type="submit" class="rgza-btn danger small" name="rgz_mech_lesson_delete" value="1">Delete lesson</button>
          </form>
          <?php endif; ?>
        </div>
        <?php
    }

    /* ============================================================ */
    /* Helpers for frontend                                         */
    /* ============================================================ */

    public static function seed_default_lessons($refresh = false) {
        $lessons = self::get_lessons();
        if ($refresh) {
            /* Replace the content of factory lessons (keeping their publish state + position);
               custom lessons made by the user are never touched. */
            $by_id = [];
            foreach ($lessons as $i => $l) { $by_id[$l['id']] = $i; }
            foreach (self::default_lessons() as $d) {
                if (isset($by_id[$d['id']])) {
                    $keep_enabled = !empty($lessons[$by_id[$d['id']]]['enabled']);
                    $lessons[$by_id[$d['id']]] = $d;
                    $lessons[$by_id[$d['id']]]['enabled'] = $keep_enabled;
                } else {
                    $lessons[] = $d;
                }
            }
        } else {
            $have = array_map(function ($l) { return $l['id']; }, $lessons);
            foreach (self::default_lessons() as $d) {
                if (!in_array($d['id'], $have, true)) { $lessons[] = $d; }
            }
        }
        update_option(self::OPT_LESSONS, $lessons);
    }

    public static function refresh_default_lessons() {
        self::seed_default_lessons(true);
    }

    public static function find_page_with_shortcode($shortcode, $fallback_home = false) {
        $pages = get_posts([
            'post_type' => 'page',
            'post_status' => 'publish',
            'posts_per_page' => 20,
            's' => '[' . $shortcode,
        ]);
        foreach ((array) $pages as $page) {
            if (has_shortcode($page->post_content, $shortcode)) { return get_permalink($page); }
        }
        return $fallback_home ? home_url('/learn/') : '';
    }

    private static function front_assets() {
        $base = plugin_dir_url(__FILE__) . 'assets/';
        $css = plugin_dir_path(__FILE__) . 'assets/deck.css';
        $js  = plugin_dir_path(__FILE__) . 'assets/deck.js';
        wp_enqueue_style('rgz-deck', $base . 'deck.css', [], self::VERSION . '-' . (file_exists($css) ? filemtime($css) : '1'));
        wp_enqueue_script('rgz-deck', $base . 'deck.js', [], self::VERSION . '-' . (file_exists($js) ? filemtime($js) : '1'), true);
    }

    /* ============================================================ */
    /* Shortcode: Mechanical Deck                                  */
    /* ============================================================ */

    public static function render_deck($atts = []) {
        self::front_assets();
        $s = self::get_settings();
        $atts = shortcode_atts(['compact' => ''], $atts, self::SHORTCODE_DECK);
        $compact = !empty($atts['compact']);
        $apps = self::get_apps(true);
        $lessons = self::get_lessons(true);
        $lessons_count = count($lessons);
        $cats = [];
        foreach ($apps as $a) {
            if (!empty($a['category']) && !in_array($a['category'], $cats, true)) { $cats[] = $a['category']; }
        }
        ob_start();
        ?>
        <section class="rgzd" data-rgz-deck style="--rgzd-accent: <?php echo esc_attr($s['accent']); ?>">
          <?php if (!$compact) : ?>
          <div class="rgzd-hero">
            <span class="rgzd-hero-kicker">◆ RGZ Engineering</span>
            <h2><?php echo esc_html($s['heroTitle']); ?></h2>
            <p><?php echo esc_html($s['heroSubtitle']); ?></p>
            <div class="rgzd-hero-stats">
              <div class="rgzd-hero-stat"><b><?php echo count($apps); ?></b><span>Apps</span></div>
              <div class="rgzd-hero-stat"><b><?php echo (int) $lessons_count; ?></b><span>Lessons</span></div>
              <div class="rgzd-hero-stat"><b><?php echo count($cats); ?></b><span>Topics</span></div>
            </div>
          </div>
          <?php endif; ?>

          <div class="rgzd-tabsbar" role="tablist">
            <button type="button" class="rgzd-tabbtn on" data-deck-tab="apps" role="tab">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.5"/></svg>
              Apps
            </button>
            <button type="button" class="rgzd-tabbtn" data-deck-tab="learn" role="tab">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v17.5H6.5A2.5 2.5 0 0 0 4 22V4.5Z"/><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/></svg>
              Learning
              <span class="rgzd-tabcount"><?php echo (int) $lessons_count; ?></span>
            </button>
          </div>

          <div class="rgzd-pane on" data-deck-pane="apps">
            <?php if (!empty($s['showSearch']) || (!empty($s['showFilters']) && count($cats) > 1)) : ?>
            <div class="rgzd-toolbar">
              <?php if (!empty($s['showSearch'])) : ?>
              <label class="rgzd-search">
                <svg viewBox="0 0 24 24" fill="none" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.8-3.8"/></svg>
                <input type="search" placeholder="Search apps…" aria-label="Search apps">
              </label>
              <?php endif; ?>
              <?php if (!empty($s['showFilters']) && count($cats) > 1) : ?>
              <div class="rgzd-chips">
                <button type="button" class="rgzd-chip on" data-cat="all">All</button>
                <?php foreach ($cats as $c) : ?><button type="button" class="rgzd-chip" data-cat="<?php echo esc_attr($c); ?>"><?php echo esc_html($c); ?></button><?php endforeach; ?>
              </div>
              <?php endif; ?>
            </div>
            <?php endif; ?>

            <div class="rgzd-grid">
              <?php foreach ($apps as $a) :
                  $url = isset($a['url']) ? $a['url'] : '';
                  $topic = isset($a['learnTopic']) ? $a['learnTopic'] : '';
              ?>
              <article class="rgzd-card" data-cat="<?php echo esc_attr(isset($a['category']) ? $a['category'] : ''); ?>" style="--card-accent: <?php echo esc_attr(isset($a['accent']) ? $a['accent'] : '#38bdf8'); ?>">
                <div class="rgzd-card-top">
                  <div class="rgzd-icon"><?php echo self::icon_svg(isset($a['icon']) ? $a['icon'] : 'generic'); // phpcs:ignore ?></div>
                  <div class="rgzd-badges">
                    <?php if (!empty($a['category'])) : ?><span class="rgzd-badge cat"><?php echo esc_html($a['category']); ?></span><?php endif; ?>
                    <?php if (!empty($a['badge'])) : ?><span class="rgzd-badge"><?php echo esc_html($a['badge']); ?></span><?php endif; ?>
                  </div>
                </div>
                <h3><?php echo esc_html(isset($a['title']) ? $a['title'] : ''); ?></h3>
                <p><?php echo esc_html(isset($a['desc']) ? $a['desc'] : ''); ?></p>
                <div class="rgzd-card-foot">
                  <?php if ($url) : ?>
                    <a class="rgzd-btn primary" href="<?php echo esc_url($url); ?>">Open app →</a>
                  <?php else : ?>
                    <span class="rgzd-btn soon">Coming soon</span>
                  <?php endif; ?>
                  <?php if ('' !== $topic) : ?>
                    <a class="rgzd-btn ghost" href="#learn-<?php echo esc_attr($topic); ?>" data-learn-topic="<?php echo esc_attr($topic); ?>">📖 Learning</a>
                  <?php endif; ?>
                </div>
              </article>
              <?php endforeach; ?>
              <?php if (!$apps) : ?><div class="rgzd-empty">No apps published yet — check back soon.</div><?php endif; ?>
              <div class="rgzd-empty" style="display:none">Nothing matches your search.</div>
            </div>
          </div>

          <div class="rgzd-pane" data-deck-pane="learn">
            <?php echo self::render_learn_inner($lessons, 'all'); ?>
          </div>
        </section>
        <?php
        return ob_get_clean();
    }

    /* ============================================================ */
    /* Shortcode: Learning Hub                                      */
    /* ============================================================ */

    public static function render_learn($atts = []) {
        self::front_assets();
        $atts = shortcode_atts(['topic' => 'all'], $atts, self::SHORTCODE_LEARN);
        $default_topic = in_array($atts['topic'], ['hydraulics', 'pneumatics', 'general'], true) ? $atts['topic'] : 'all';
        return self::render_learn_inner(self::get_lessons(true), $default_topic);
    }

    private static function render_learn_inner($lessons, $default_topic = 'all') {
        $topic_accents = ['hydraulics' => '#38bdf8', 'pneumatics' => '#e8793c', 'general' => '#a78bfa'];
        ob_start();
        ?>
        <div class="rgzl" data-rgz-learn data-default-topic="<?php echo esc_attr($default_topic); ?>">
          <div class="rgzd-toolbar">
            <div class="rgzd-chips">
              <?php foreach ([['all', 'All topics'], ['hydraulics', 'Hydraulics'], ['pneumatics', 'Pneumatics'], ['general', 'General']] as $t) : ?>
                <button type="button" class="rgzd-chip <?php echo $default_topic === $t[0] ? 'on' : ''; ?>" data-topic-chip="<?php echo esc_attr($t[0]); ?>"><?php echo esc_html($t[1]); ?></button>
              <?php endforeach; ?>
            </div>
            <div class="rgzd-chips">
              <?php foreach ([['all', 'Any level'], ['beginner', 'Beginner'], ['intermediate', 'Intermediate'], ['advanced', 'Advanced']] as $l) : ?>
                <button type="button" class="rgzd-chip <?php echo 'all' === $l[0] ? 'on' : ''; ?>" data-level-chip="<?php echo esc_attr($l[0]); ?>"><?php echo esc_html($l[1]); ?></button>
              <?php endforeach; ?>
            </div>
            <label class="rgzd-search rgzl-search">
              <svg viewBox="0 0 24 24" fill="none" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.8-3.8"/></svg>
              <input type="search" placeholder="Search lessons…" aria-label="Search lessons">
            </label>
          </div>

          <div class="rgzl-grid">
            <?php foreach ($lessons as $l) : ?>
            <article class="rgzl-card" data-lesson="<?php echo esc_attr($l['id']); ?>" data-topic="<?php echo esc_attr($l['topic']); ?>" data-level="<?php echo esc_attr($l['level']); ?>" data-title="<?php echo esc_attr($l['title']); ?>"<?php if (!empty($l['cover'])) : ?> data-cover="<?php echo esc_url($l['cover']); ?>"<?php endif; ?> style="--topic-accent: <?php echo esc_attr($topic_accents[$l['topic']]); ?>">
              <?php if (!empty($l['cover'])) : ?><div class="rgzl-cover"><img src="<?php echo esc_url($l['cover']); ?>" alt="<?php echo esc_attr($l['title']); ?>" loading="lazy"></div><?php endif; ?>
              <div class="rgzl-card-top">
                <span class="rgzl-pill topic-<?php echo esc_attr($l['topic']); ?>"><?php echo esc_html($l['topic']); ?></span>
                <span class="rgzl-pill level"><?php echo esc_html($l['level']); ?></span>
                <span class="rgzl-read-flag">✓ read</span>
              </div>
              <h3><?php echo esc_html($l['title']); ?></h3>
              <p><?php echo esc_html($l['summary']); ?></p>
              <div class="rgzl-card-foot">
                <span class="rgzl-minutes">≈ <?php echo (int) $l['minutes']; ?> min read</span>
                <button type="button" class="rgzd-btn ghost" data-read-lesson>Read →</button>
              </div>
            </article>
            <template data-content="<?php echo esc_attr($l['id']); ?>"><?php echo wp_kses_post($l['content']); ?></template>
            <?php endforeach; ?>
            <?php if (!$lessons) : ?><div class="rgzd-empty">No lessons published yet.</div><?php endif; ?>
            <div class="rgzd-empty rgzl-empty" style="display:none">Nothing matches your filters.</div>
          </div>

          <div class="rgzl-modal-backdrop" role="dialog" aria-modal="true">
            <div class="rgzl-modal">
              <div class="rgzl-modal-head">
                <div style="flex:1 1 auto"><h2></h2><div class="rgzl-modal-meta"></div></div>
                <button type="button" class="rgzl-close" aria-label="Close">×</button>
              </div>
              <div class="rgzl-modal-body"></div>
              <div class="rgzl-modal-foot">
                <span class="rgzl-minutes"></span>
                <button type="button" class="rgzd-btn primary" data-mark-read>Mark as read</button>
              </div>
            </div>
          </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /* ============================================================ */
    /* Default lessons                                              */
    /* ============================================================ */

    public static function default_lessons() {
        $L = [];
        /* Bundled lesson artwork: technical drawings (.svg) and realistic photos (.jpg/.png).
           URLs are built at runtime so they always point at the installed plugin. */
        $A = plugin_dir_url(__FILE__) . 'assets/learn/';
        $L[] = [
            'id' => 'hyd-pascal',
            'cover' => $A . 'fig-hyd-pascal.svg',
            'title' => 'Fluid power and Pascal\'s law',
            'summary' => 'Why a small force can lift tons: pressure in a confined fluid and the force-multiplying piston principle.',
            'topic' => 'hydraulics', 'level' => 'beginner', 'minutes' => 5, 'enabled' => true,
            'content' => <<< 'HTML'
<p>Hydraulics transmits force and motion through a confined, nearly incompressible fluid — usually mineral oil. The whole technology rests on <strong>Pascal's law</strong> (1653): pressure applied to a confined fluid is transmitted undiminished in all directions and acts with equal force on equal areas, at right angles to them.</p>
<div class="rgzl-formula">p = F / A &nbsp;&nbsp;→&nbsp;&nbsp; F = p · A</div>
<p>If pressure <em>p</em> acts on two pistons of different area, the forces are proportional to the areas. A hand pump of 1 cm² pushing on 100 bar (10 MPa) produces 1 kN; the same pressure on a 100 cm² press plunger produces <strong>100 kN ≈ 10 tonnes of force</strong>. That is the hydraulic lever — but energy is conserved: the small piston moves 100× further than the large one.</p>
<h3>Units you will use constantly</h3>
<ul>
<li>Pressure: 1 bar = 0.1 MPa = 10⁵ Pa ≈ 14.5 psi. Mobile hydraulics typically 160–350 bar.</li>
<li>Flow: litres per minute (l/min). Power: P(kW) = p(bar) × Q(l/min) / 600.</li>
</ul>
<div class="rgzl-tip">Try it in the Hydraulic Studio: put a pressure gauge on the piston side of a lifting cylinder and watch p rise exactly to p = (load force) / (piston area) before the cylinder starts to move.</div>
HTML,
        ];
        $L[] = [
            'id' => 'hyd-pumps',
            'cover' => $A . 'fig-hyd-pumps.svg',
            'title' => 'Pumps, displacement and flow rate',
            'summary' => 'How pumps create flow (not pressure!), displacement volume, and why pressure only appears against resistance.',
            'topic' => 'hydraulics', 'level' => 'beginner', 'minutes' => 6, 'enabled' => true,
            'content' => <<< 'HTML'
<p>A hydraulic pump converts mechanical rotation into flow. The key spec is the <strong>displacement volume</strong> V<sub>g</sub> (cm³/rev) — the volume pushed per revolution:</p>
<div class="rgzl-formula">Q (l/min) = V<sub>g</sub> (cm³/rev) × n (rpm) × η<sub>vol</sub> / 1000</div>
<h3>Pumps produce flow — resistance produces pressure</h3>
<p>The pump does not "make" 200 bar. It pushes oil; pressure rises only because the flow meets resistance (a load, a restriction). With no resistance the outlet stays near zero. This is why every system needs a <strong>pressure relief valve</strong>: with the cylinder at its end stop, flow has nowhere to go and pressure would rise until something breaks — the relief opens and returns oil to tank.</p>
<h3>Common pump types</h3>
<ul>
<li><strong>Gear pumps</strong> — simple, cheap, robust; fixed displacement; typical ≤ 250 bar.</li>
<li><strong>Vane pumps</strong> — quiet, medium pressure; often variable displacement.</li>
<li><strong>Axial piston pumps</strong> — high pressure (≤ 450 bar), variable displacement, pressure compensation and load-sensing control.</li>
</ul>
<div class="rgzl-tip">In the Studio, the power pack combines motor + pump + relief + tank. The pump flow (l/min) drives every speed calculation in the simulation.</div>
HTML,
        ];
        $L[] = [
            'id' => 'hyd-cylinders',
            'cover' => $A . 'fig-hyd-cylinders.svg',
            'title' => 'Cylinders: force, speed and area ratio',
            'summary' => 'Push and pull forces, extension speed from flow, the annulus area effect and regenerative (differential) circuits.',
            'topic' => 'hydraulics', 'level' => 'beginner', 'minutes' => 7, 'enabled' => true,
            'content' => <<< 'HTML'
<p>A double-acting cylinder converts pressure back into linear force. Two sides, two areas: the full piston area A<sub>K</sub> and the much smaller <strong>annulus</strong> A<sub>R</sub> on the rod side.</p>
<div class="rgzl-formula">F<sub>out</sub> = p · A<sub>K</sub> &nbsp;&nbsp;|&nbsp;&nbsp; F<sub>in</sub> = p · A<sub>R</sub><br>v = Q / A</div>
<h3>Worked example</h3>
<p>Piston Ø 80 mm, rod Ø 45 mm → A<sub>K</sub> = 50.3 cm², A<sub>R</sub> = 34.4 cm². At 160 bar: push force ≈ 80.4 kN, pull force ≈ 55 kN. Feeding 40 l/min: extend speed ≈ 0.13 m/s, retract ≈ 0.19 m/s — the cylinder retracts <em>faster</em> on the same flow because the annulus is smaller.</p>
<h3>Regenerative (differential) circuit</h3>
<p>Connect P to the cap end <em>and</em> the rod side simultaneously: oil from the rod side joins the pump flow into the cap end. The result is a much faster extension at reduced force — perfect for rapid approach before a working stroke. The Studio's intermediate examples include this circuit with electric changeover.</p>
<div class="rgzl-tip">Cylinder cushioning slows the piston over the last ~20 mm by throttling the outflow — it protects the end caps from repeated impact at speed.</div>
HTML,
        ];
        $L[] = [
            'id' => 'hyd-pressure',
            'cover' => $A . 'fig-hyd-pressure-valves.svg',
            'title' => 'Pressure control: relief, reducing, sequence',
            'summary' => 'The three classic pressure valves — what each one protects, regulates or triggers, and how to tell their ISO symbols apart.',
            'topic' => 'hydraulics', 'level' => 'intermediate', 'minutes' => 7, 'enabled' => true,
            'content' => <<< 'HTML'
<p>Pressure valves all compare line pressure with an adjustable spring, but they answer three different questions.</p>
<h3>Relief valve — "how high may it go?"</h3>
<p>Normally closed, piloted from its <strong>inlet</strong>, opens to tank at the setting. It limits maximum system pressure and protects the pump. It does not regulate during operation — it just caps peaks (and dumps all pump flow at setting at end of stroke).</p>
<h3>Pressure reducing valve — "how low must it stay?"</h3>
<p>Normally <em>open</em>, piloted from its <strong>outlet</strong>: it starts closing when outlet pressure exceeds the setting, holding the downstream branch at reduced pressure. Used when one branch (e.g. a clamp) needs less force than the main system.</p>
<h3>Sequence valve — "when may the next step start?"</h3>
<p>Normally closed, piloted from inlet like a relief, but its outlet feeds another actuator instead of tank: step 2 starts only after step 1 reached the pressure that proves it finished (e.g. clamp → drill). It needs an external drain because its outlet is pressurised.</p>
<div class="rgzl-tip">Simulate a sequence in the Studio: put a sequence valve before a second cylinder and watch the messages report cylinder 1 completing before cylinder 2 moves.</div>
HTML,
        ];
        $L[] = [
            'id' => 'hyd-dcv',
            'cover' => $A . 'fig-hyd-dcv.svg',
            'title' => 'Directional valves & ISO 1219 symbols',
            'summary' => 'Positions and ways (4/3, 4/2…), center spool types, actuation methods — and how the square-box ISO symbol encodes all of it.',
            'topic' => 'hydraulics', 'level' => 'intermediate', 'minutes' => 8, 'enabled' => true,
            'content' => <<< 'HTML'
<p>A directional control valve (DCV) routes flow between ports. "4/3" means <strong>4 ports × 3 positions</strong>. Ports: P (pressure), T (tank), A and B (actuator). Each square box shows one spool position with the internal connections drawn inside it.</p>
<h3>Reading the symbol</h3>
<ul>
<li>Arrows inside a box = open flow paths; ⟂-ends = blocked ports in that position.</li>
<li>When a solenoid is energised, the <em>adjacent box</em> becomes active — in the Studio the boxes literally slide across the ports during simulation.</li>
<li>Springs push the spool back (spring-return) or hold it centered (spring-centered).</li>
</ul>
<h3>Center positions (4/3 valves)</h3>
<ul>
<li><strong>Closed center</strong> — all ports blocked: cylinder locks, pump must unload through the relief.</li>
<li><strong>Tandem center (P→T)</strong> — pump idles unloaded while the cylinder stays locked. Energy saving.</li>
<li><strong>Float center (A,B→T)</strong> — the actuator can be pushed freely (e.g. for manual positioning).</li>
</ul>
<h3>Actuation</h3>
<p>Manual lever, push-button, roller (limit), spring, pneumatic pilot (triangle) and solenoid (rectangle with diagonal). Detents hold a manually shifted spool.</p>
HTML,
        ];
        $L[] = [
            'id' => 'hyd-flow',
            'cover' => $A . 'fig-hyd-flow-valves.svg',
            'title' => 'Flow control: meter-in, meter-out, PC valves',
            'summary' => 'Controlling actuator speed with throttle valves — why placement matters, and when you need pressure compensation.',
            'topic' => 'hydraulics', 'level' => 'advanced', 'minutes' => 7, 'enabled' => true,
            'content' => <<< 'HTML'
<p>Speed follows v = Q/A, so controlling flow controls speed. A simple throttle (needle valve) creates a pressure drop that depends on flow — hence its control is <em>load dependent</em>.</p>
<h3>Meter-in vs meter-out</h3>
<ul>
<li><strong>Meter-in</strong>: throttle on the supply line. Simple, but with overrunning (pulling) loads the cylinder can run away — pressure collapses on the cap side.</li>
<li><strong>Meter-out</strong>: throttle on the return line. The trapped oil on the rod side is pressurised by the load, giving stiffness and safe control of lowering/overrunning loads. The rule of thumb for vertical cylinders: control the outflow.</li>
</ul>
<h3>Check-valve bypass</h3>
<p>Pair the throttle with an antiparallel check valve and you get one-way speed control: throttled extend, free retract (or vice versa) — the classic "Flow control valve with bypass" in the Studio palette.</p>
<h3>Pressure-compensated (2-way) flow control</h3>
<p>A compensator spool keeps a constant Δp (≈ 5–10 bar) across the adjustable orifice, so the set flow stays constant regardless of load. That is what guarantees identical speeds under varying force.</p>
HTML,
        ];
        $L[] = [
            'id' => 'hyd-oil',
            'cover' => $A . 'fig-hyd-oil.svg',
            'title' => 'Oil, filtration and thermal management',
            'summary' => 'Viscosity and ISO VG, why 70 % of failures are dirt, cleanliness codes, and when a system needs a cooler.',
            'topic' => 'hydraulics', 'level' => 'advanced', 'minutes' => 6, 'enabled' => true,
            'content' => <<< 'HTML'
<h3>The fluid is a machine element</h3>
<p>Hydraulic oil transfers power, lubricates, seals gaps and carries heat away. Its most important property is <strong>viscosity</strong>, specified as ISO VG (mm²/s at 40 °C). Typical choice: VG 32–46; too thin → internal leakage and wear, too thick → cavitation and sluggish response at cold start.</p>
<h3>Contamination — failure driver #1</h3>
<p>Roughly 70–80 % of hydraulic failures trace back to contaminated oil. Cleanliness is coded by ISO 4406 (e.g. 19/17/14 particles >4/6/14 µm). Servo valves need ~2 classes cleaner than gear pumps. Filters are rated by the β-ratio: β<sub>10</sub> = 200 means 99.5 % of 10 µm particles are captured.</p>
<h3>Heat</h3>
<p>Every pressure drop becomes heat: P<sub>loss</sub> = Δp × Q / 600 kW. Relief-valve throttling at end of stroke is a frequent heater. If the tank cannot dissipate it (~0.6–1.0 kW per 100 l tank by natural convection), add a return-line <strong>cooler</strong> — in the Studio you can place oil coolers and a heater with temperature sensors.</p>
<div class="rgzl-tip">Watch the simulated oil temperature in the Hydraulic Studio metrics as relief flow heats the tank over time.</div>
HTML,
        ];
        $L[] = [
            'id' => 'pne-air',
            'cover' => $A . 'fig-pne-service.svg',
            'title' => 'Compressed air: production and properties',
            'summary' => 'Why pneumatics, compressor types, the bar/psi units, and why dry air matters (pressure dew point).',
            'topic' => 'pneumatics', 'level' => 'beginner', 'minutes' => 6, 'enabled' => true,
            'content' => <<< 'HTML'
<p>Pneumatics uses <strong>compressed air</strong> — clean, fast, overload-safe and available everywhere in a factory. Typical working pressure is <strong>6 bar</strong>. Air is compressible: that makes pneumatics springy (great for clamping and end-stop cushioning) but less precise than hydraulics for exact positioning.</p>
<h3>Production chain</h3>
<ul>
<li><strong>Compressor</strong>: piston (small/intermittent) or screw (continuous, quiet). It draws in free air and compresses ~7:1.</li>
<li><strong>Cooler & dryer</strong>: hot compressed air holds water vapour; cooling makes it condense. A refrigerated dryer brings the pressure dew point to +3 °C; adsorption dryers reach −40 °C for instruments and outdoors lines.</li>
<li><strong>Receiver</strong>: the tank levels consumption peaks and lets the compressor cycle less often.</li>
</ul>
<h3>Units</h3>
<div class="rgzl-formula">1 bar = 100 kPa ≈ 14.5 psi &nbsp;|&nbsp; "NL/min" = normal litres per minute (free air)</div>
<div class="rgzl-tip">A pressure gauge in pneumatics shows <em>relative</em> pressure (bar gauge); absolute pressure = gauge + 1.013 bar — that matters for air consumption calculations.</div>
HTML,
        ];
        $L[] = [
            'id' => 'pne-frl',
            'cover' => $A . 'photo-pne-frl.jpg',
            'title' => 'Air preparation: the FRL service unit',
            'summary' => 'Filter, regulator, lubricator — what each stage does, ISO 8573-1 air classes, and condensate handling.',
            'topic' => 'pneumatics', 'level' => 'beginner', 'minutes' => 6, 'enabled' => true,
            'content' => <<< 'HTML'
<p>Between network and machine sits the <strong>service unit</strong> — in the Studio it is one symbol combining all stages (insert it with "Service unit").</p>
<h3>F — Filter</h3>
<p>Separates water droplets and particles (typ. 5–40 µm) in a cyclone chamber; condensate collects in the bowl and drains manually or automatically. Air quality classes follow ISO 8573-1 (particles / dew point / oil), e.g. class 7.4.4 for standard shop air.</p>
<h3>R — Pressure regulator</h3>
<p>A diaphragm poppet holds the <em>secondary</em> pressure constant even when the primary side fluctuates, and vents overpressure (relieving type). This is the knob the operator sets — usually 6 bar.</p>
<h3>L — Lubricator</h3>
<p>Adds a fine oil mist for old-style cylinders and tools. Modern machinery is designed <strong>lubrication-free</strong> (special seals and materials); if a lubricator is installed, it must never run dry — once oiled, always oiled.</p>
<div class="rgzl-tip">Order matters: filter first, then regulator, then (optionally) lubricator — never reversed. In the Studio the service unit already wires filter → regulator correctly.</div>
HTML,
        ];
        $L[] = [
            'id' => 'pne-actuators',
            'cover' => $A . 'fig-pne-actuators.svg',
            'title' => 'Pneumatic cylinders and speed control',
            'summary' => 'Single vs double acting, force at 6 bar, cushioning — and why air exhaust throttling is the standard speed control.',
            'topic' => 'pneumatics', 'level' => 'beginner', 'minutes' => 6, 'enabled' => true,
            'content' => <<< 'HTML'
<h3>Single-acting (SA)</h3>
<p>One port; air extends the piston and a return spring retracts it when vented. Used for short strokes, clamps, ejectors. Force is reduced by the spring.</p>
<h3>Double-acting (DA)</h3>
<p>Air drives both directions. Force at 6 bar (0.6 MPa):</p>
<div class="rgzl-formula">F = p · A &nbsp;→&nbsp; Ø 50 mm cylinder: F ≈ 6 · 10⁵ · 1.96 · 10⁻³ ≈ 1180 N</div>
<p>End-position <strong>cushioning</strong> throttles the exhaust over the last millimetres so heavy loads do not slam into the end caps.</p>
<h3>Speed control: throttle the exhaust</h3>
<p>With compressible air, meter-in throttling causes stick-slip: the piston hesitates, pressure builds, then it jumps. The standard is <strong>meter-out</strong> (exhaust-air) flow control at each cylinder port — the trapped air cushions and stiffens the motion. A quick-exhaust valve does the opposite: it vents directly at the cylinder for maximum return speed.</p>
<h3>Beyond the classic cylinder</h3>
<p>When space or stroke length rules the design: <strong>rodless cylinders</strong> (magnetic or band coupling between piston and outer carriage — stroke equals the unit length, not twice it), compact and short-stroke cylinders, guided drives, <strong>rotary actuators</strong> (vane or rack-and-pinion) for swivelling, and bellows/actuated grippers. All follow the same force formula on their effective area.</p>
<div class="rgzl-tip">In the Pneumatic Studio, each flow control with bypass acts as the exhaust throttle; simulate and watch the cylinder speed follow your screw setting.</div>
HTML,
        ];
        $L[] = [
            'id' => 'pne-valves',
            'cover' => $A . 'fig-pne-valves.svg',
            'title' => 'Pneumatic valves: 3/2, 5/2, 5/3 & piloting',
            'summary' => 'Port numbering (1, 2, 3, 4, 5 — ISO 5599), monostable vs bistable, air-piloted control and center functions.',
            'topic' => 'pneumatics', 'level' => 'intermediate', 'minutes' => 7, 'enabled' => true,
            'content' => <<< 'HTML'
<p>Pneumatic valve ports follow ISO 5599: <strong>1</strong> = supply, <strong>2 & 4</strong> = working lines, <strong>3 & 5</strong> = exhausts, <strong>12/14</strong> = pilot lines. So a 5/2 valve has 5 ports and 2 positions.</p>
<h3>3/2 valve — the basic switch</h3>
<p>Controls single-acting cylinders or acts as a signal element: NC (normally closed, supply blocked at rest) or NO. Push-button, roller lever (limit switch), or air-pilot actuation.</p>
<h3>5/2 valve — the cylinder driver</h3>
<ul>
<li><strong>Monostable</strong> (single pilot + spring return): returns to rest when the pilot disappears — predictable fail state.</li>
<li><strong>Bistable</strong> (double pilot): a pulse switches it and it <em>stays</em> (memory) until the opposite pilot arrives — ideal for sequence control.</li>
</ul>
<h3>5/3 center functions</h3>
<p>Mid position with all ports closed (holds cylinder), both chambers exhausted (free movement), or both pressurised (approximate stop in position).</p>
<div class="rgzl-tip">Watch the Pneumatic Studio: during simulation the 5/2 boxes slide to the energized side exactly like the real spool shifts.</div>
HTML,
        ];
        $L[] = [
            'id' => 'pne-logic',
            'cover' => $A . 'fig-pne-logic.svg',
            'title' => 'Logic elements and sequence circuits',
            'summary' => 'AND (two-pressure valve), OR (shuttle valve), time delays — and how classic sequences like A+ B+ B− A− are built.',
            'topic' => 'pneumatics', 'level' => 'advanced', 'minutes' => 8, 'enabled' => true,
            'content' => <<< 'HTML'
<h3>OR — shuttle valve</h3>
<p>Two inlets, one outlet; an internal ball connects the pressurised inlet to the outlet. Either push-button OR the other starts the cylinder (e.g. control from two positions).</p>
<h3>AND — two-pressure valve</h3>
<p>Output only when <em>both</em> inlets are pressurised (it passes the lower pressure). Used for two-hand safety/start conditions: start only when button AND end position are present.</p>
<h3>Time delay valve</h3>
<p>A 3/2 valve + flow control + small air reservoir: after the pilot arrives, the chamber fills through the throttle until switching pressure is reached — an adjustable pneumatic timer (0…30 s typical).</p>
<h3>Sequence example: A+ B+ B− A−</h3>
<p>Cylinder A extends (clamp), then B extends (work), B retracts, A retracts. Realised with roller valves at each end position reporting "step done" to the next valve, or with a cascade/stepper module that only enables the active step — eliminating trapped opposing signals, the classic trap in pneumatic sequencing.</p>
<div class="rgzl-tip">Recreate this in the Studio's advanced examples — the messages panel reports every switch event as the sequence runs.</div>
HTML,
        ];
        $L[] = [
            'id' => 'pne-sizing',
            'cover' => $A . 'fig-pne-sizing.svg',
            'title' => 'Air consumption, sizing and leakage',
            'summary' => 'Free-air consumption of cylinders, Cv/Kv sizing of valves, tube sizing, and the hidden cost of leaks.',
            'topic' => 'pneumatics', 'level' => 'advanced', 'minutes' => 7, 'enabled' => true,
            'content' => <<< 'HTML'
<h3>How much air does a cylinder use?</h3>
<p>Per stroke, the cylinder volume is filled from (p<sub>gauge</sub>+1) atmospheres down to 1 — consumption in normal litres:</p>
<div class="rgzl-formula">V<sub>NL</sub> = A · s · (p<sub>abs</sub>) ≈ A · s · (p<sub>bar,g</sub> + 1)</div>
<p>Example: Ø 63 mm × 400 mm stroke DA at 6 bar: ≈ 1.25 l chamber × 7 ≈ 8.7 NL per extend, plus rod-side ~7.9 NL — about 16 NL per full cycle. Multiply by cycles/min for compressor sizing.</p>
<h3>Sizing valves and tubing</h3>
<p>Valve flow capacity is given as nominal flow (NL/min) or C V / K V; undersized valves starve the cylinder and slow it down. Main lines are typically sized for ≤ 6–8 m/s mean velocity, drops and pressure loss ≤ 0.3 bar to the farthest consumer.</p>
<h3>Leaks are expensive</h3>
<div class="rgzl-tip">A single 1 mm hole at 6 bar loses ≈ 75 NL/min — continuously, even when machines are off. At typical electricity prices that is several hundred euros per year per hole. Leak audits pay for themselves in weeks.</div>
HTML,
        ];
        $L[] = [
            'id' => 'iso-1219',
            'cover' => $A . 'fig-iso-symbols.svg',
            'title' => 'Reading ISO 1219-1 circuit symbols',
            'summary' => 'The grammar of fluid-power schematics: boxes, circles, triangles, solid vs dashed lines, and composite symbols.',
            'topic' => 'general', 'level' => 'beginner', 'minutes' => 6, 'enabled' => true,
            'content' => <<< 'HTML'
<p>ISO 1219-1 defines the graphic symbols for fluid-power circuits — the "alphabet" every schematic in the RGZ studios follows.</p>
<h3>Basic shapes</h3>
<ul>
<li><strong>Circle</strong> — energy conversion: pump, motor, compressor, measuring device. A <em>filled triangle</em> inside shows flow direction (out = pump, in = motor).</li>
<li><strong>Square/rectangle</strong> — valves. One square per position; arrows inside = open paths, ⟂ ends = blocked.</li>
<li><strong>Diamond</strong> — conditioning equipment: filter, cooler, heater, dryer.</li>
<li><strong>Long rectangle</strong> — cylinders (single or double rod).</li>
</ul>
<h3>Lines</h3>
<ul>
<li>Solid = main/working line; long-dashed = pilot/control line; short-dashed = drain; dash-dot = enclosure (assembly frame).</li>
<li>A crossing dot means connected; a small arc (or nothing) means not connected.</li>
</ul>
<h3>Energy & control</h3>
<p>Triangles on the symbol edge mark flow direction of energy converters. Actuation glyphs attach to valve boxes: springs (zigzag), solenoids (rectangle with diagonal), manual, roller, pneumatic pilot (outline triangle), detents (notches).</p>
<div class="rgzl-tip">Open the circuit library in either studio and read a schematic: every symbol you see — from power pack to sequence valve — follows these exact rules.</div>
HTML,
        ];
        $L[] = [
            'id' => 'hyd-powerpack',
            'cover' => $A . 'photo-hyd-powerpack.jpg',
            'title' => 'Anatomy of a hydraulic power unit',
            'summary' => 'Tank, motor, pump, coupling, relief and breather — how the component groups of a power pack work together and how the Studio models it.',
            'topic' => 'hydraulics', 'level' => 'beginner', 'minutes' => 7, 'enabled' => true,
            'content' => <<< 'HTML'
<p>The <strong>hydraulic power unit (HPU)</strong> is the heart of every system. In the Studio you place it with one click ("Power pack"), but inside that symbol lives a complete component group — worth knowing part by part.</p>
<h3>Component groups</h3>
<ul>
<li><strong>Tank (reservoir)</strong> — stores oil, lets it cool and de-aerate, and settles dirt and water. Rules of thumb: 2–4× pump l/min for industrial units. Includes the <em>breather filter</em>, level gauge, and baffle plate separating suction and return zones.</li>
<li><strong>Electric motor + pump</strong> — typically a 4-pole motor (≈ 1450 rpm at 50 Hz) driving a gear, vane or piston pump through a bellhousing and flexible coupling.</li>
<li><strong>Pressure relief valve</strong> — mounted right after the pump, returns to tank; sets the maximum system pressure.</li>
<li><strong>Suction line</strong> — generously sized (0.5–1.5 m/s) with a strainer; starving the suction line is the #1 cause of cavitation.</li>
<li>Optional: return-line filter and oil cooler, accumulator station, level/temperature switches.</li>
</ul>
<div class="rgzl-tip">In the Studio, the power pack exposes P (pressure) and T (tank) ports plus its pump flow, relief setting and motor power — everything the simulation needs to compute live pressure, flow and temperature.</div>
HTML,
        ];
        $L[] = [
            'id' => 'hyd-accumulators',
            'cover' => $A . 'photo-hyd-accumulator.jpg',
            'title' => 'Hydraulic accumulators: energy storage',
            'summary' => 'Bladder, piston and diaphragm types, the pre-charge rule, and the four classic jobs of an accumulator station.',
            'topic' => 'hydraulics', 'level' => 'intermediate', 'minutes' => 6, 'enabled' => true,
            'content' => <<< 'HTML'
<p>A <strong>hydro-pneumatic accumulator</strong> stores oil against compressed nitrogen. Types: <em>bladder</em> (fast response, most common), <em>piston</em> (large volumes, high pressure), <em>diaphragm</em> (small sizes).</p>
<h3>Pre-charge pressure p₀</h3>
<p>The nitrogen pre-charge defines the working window. Filling must never drop below p₀ (bladder damage) and the system must never compress the gas to its limit. Common rule: p₀ ≈ 0.6–0.8× minimum working pressure (0.9× for damping tasks). Usable volume follows the gas law:</p>
<div class="rgzl-formula">V<sub>usable</sub> = V₀ · p₀ · ( 1/p₁ − 1/p₂ ) &nbsp;&nbsp;(isothermal)</div>
<h3>The four classic jobs</h3>
<ul>
<li><strong>Energy storage</strong> — cover peak flows so the pump can be sized smaller.</li>
<li><strong>Emergency reserve</strong> — complete a safety movement after power/pump failure.</li>
<li><strong>Pulsation and shock damping</strong> — absorb pump ripple and water hammer.</li>
<li><strong>Leakage compensation / clamping</strong> — hold pressure in a closed circuit against small leaks.</li>
</ul>
<div class="rgzl-tip">Safety: accumulators store pressure even with the machine off. Lock out and verify depressurisation on the gauge block before opening any line — a charged accumulator is a real hazard.</div>
HTML,
        ];
        $L[] = [
            'id' => 'hyd-cavitation',
            'cover' => $A . 'fig-hyd-cavitation.svg',
            'title' => 'Cavitation, aeration and micro-dieseling',
            'summary' => 'Why pumps scream and die young: vapor bubbles at the suction, implosion damage, and how to prevent them by design.',
            'topic' => 'hydraulics', 'level' => 'intermediate', 'minutes' => 6, 'enabled' => true,
            'content' => <<< 'HTML'
<h3>Cavitation</h3>
<p>If absolute pressure in the suction line falls near the oil's vapor pressure, vapor <strong>bubbles form</strong>. Carried to the pressure side, they <strong>implode</strong> in microseconds, creating micro-jets up to ~1000 bar that erode nearby metal (pitting). Symptoms: the pump gets loud (gravel rattling), flow falls, and the suction elements wear fast.</p>
<h3>Typical causes</h3>
<ul>
<li>Suction line too long / too narrow / clogged strainer (keep 0.5–1.5 m/s velocity).</li>
<li>Cold start with too-viscous oil; tank below the pump with too much lift.</li>
<li>Oil too hot → higher vapor pressure.</li>
</ul>
<h3>Aeration vs cavitation</h3>
<p>Aeration = <em>air</em> entering (leaky suction fitting, foaming return above oil level). It makes oil spongy and can cause <strong>micro-dieseling</strong>: compressed air bubbles ignite the oil-air mixture locally like a diesel engine — scorching seals and degrading the oil.</p>
<div class="rgzl-tip">Design defense: short, generous suction; pump below oil level where possible; return lines always below the surface; bleed air after commissioning; check strainers on schedule.</div>
HTML,
        ];
        $L[] = [
            'id' => 'hyd-pressuredrop',
            'cover' => $A . 'fig-hyd-pressuredrop.svg',
            'title' => 'Pressure drop in lines and fittings',
            'summary' => 'Where the pressure goes: line friction, velocity classes for suction/pressure/return, and picking hose and tube diameters.',
            'topic' => 'hydraulics', 'level' => 'intermediate', 'minutes' => 8, 'enabled' => true,
            'content' => <<< 'HTML'
<p>Every restriction converts pressure to heat. Line losses follow Darcy–Weisbach:</p>
<div class="rgzl-formula">Δp = λ · (L / d) · ρ v² / 2 &nbsp;&nbsp;with&nbsp; v = Q / A</div>
<p>Note the brutal exponent: loss rises with <strong>velocity²</strong> — and halving the diameter multiplies the loss ~32×. Fittings, elbows, valves and filters add their own resistances (Σζ).</p>
<h3>Velocity classes (rules of thumb)</h3>
<ul>
<li><strong>Suction</strong>: 0.5 – 1.5 m/s (cavitation-safe)</li>
<li><strong>Return</strong>: 2 – 4 m/s</li>
<li><strong>Pressure lines</strong>: 3 – 6 m/s (up to ~100 bar), 5 – 7 m/s at higher pressure</li>
</ul>
<h3>Choosing hose bore</h3>
<p>From the target velocity: d = √(4Q / πv). Example: 60 l/min in a pressure line at 5 m/s → d ≈ 16 mm inner bore — the next standard size up wins. Hoses also age faster at temperature peaks and must meet the pressure rating with a safety factor ≥ 4:1 against burst.</p>
<div class="rgzl-tip">The Studio's pipe sizing tool computes inner diameter, velocity and Δp for each line in your schematic during simulation — watch red warnings when a line is undersized.</div>
HTML,
        ];
        $L[] = [
            'id' => 'hyd-hoses',
            'cover' => $A . 'fig-hyd-hoses.svg',
            'title' => 'Hose routing and piping practice',
            'summary' => 'Minimum bend radius, torsion, slack, clamps and cleanliness — the installation rules that decide a hose assembly\'s lifetime.',
            'topic' => 'hydraulics', 'level' => 'beginner', 'minutes' => 6, 'enabled' => true,
            'content' => <<< 'HTML'
<p>Most premature hose failures are <em>installation</em> failures. The rules come straight from EN 853/856 and manufacturer practice:</p>
<h3>Routing rules</h3>
<ul>
<li><strong>Respect minimum bend radius</strong> — bending tighter crushes the wire reinforcement; allow the radius printed on the hose layline.</li>
<li><strong>Never torsion a hose</strong> — twist during installation or operation destroys it fast. Route so the flexing plane contains both fittings (compensate with elbows, not twist).</li>
<li><strong>Add slack for pressure growth</strong> — hoses shorten up to 4 % under pressure; a dead-straight, tight hose rips its fittings out.</li>
<li><strong>Clamp correctly</strong> — support long runs with proper clamps (vibration-safe), but never clamp at the bend.</li>
<li><strong>Protect</strong> — against abrasion (sleeves/separation), heat sources, and sharp edges.</li>
</ul>
<h3>Cleanliness at assembly</h3>
<p>Flush new pipes, cap open ends immediately, and clean hose assemblies after cutting/crimping — rubber and metal residue from assembly is a classic early-failure cause for valves and pumps downstream.</p>
<div class="rgzl-tip">Use the layline as a sight line: one continuous printed line = no twist; a spiral layline = the hose is torsioned.</div>
HTML,
        ];
        $L[] = [
            'id' => 'hyd-valve-mounting',
            'cover' => $A . 'fig-hyd-manifold.svg',
            'title' => 'ISO 4401 patterns, stack & manifold design',
            'summary' => 'NG6/NG10 porting patterns, subplates and sandwich valves — how industrial valve stations are physically assembled.',
            'topic' => 'hydraulics', 'level' => 'advanced', 'minutes' => 7, 'enabled' => true,
            'content' => <<< 'HTML'
<p>Industrial DCVs bolt onto standardized interfaces defined by <strong>ISO 4401</strong> (DIN 24340): size 03 = NG6 (¼"), 05 = NG10 (⅜"), 07 = NG16, 08 = NG25, 10 = NG32. The pattern fixes exactly where P, T, A, B (and X, Y, L) ports sit, with locating pin and bolt holes — so any brand's valve fits any pattern-correct plate.</p>
<h3>Three ways to build a station</h3>
<ul>
<li><strong>Subplates</strong> — one valve per plate, piped externally. Simple, flexible, but many fittings and leak points.</li>
<li><strong>Sandwich (modular/stack) valves</strong> — same-pattern plates stacked <em>between</em> DCV and subplate: relief, throttle, check or reducing functions added with zero piping. Two valves are 8–14 bolts and one O-ring set.</li>
<li><strong>Manifold blocks (HIC)</strong> — a drilled steel/aluminium block carrying many valves with internal galleries: few fittings, compact, clean. Design rules: keep galleries generous (low Δp!), avoid intersecting drillings, provide test points M16×2, and allow future expansion plugs.</li>
</ul>
<div class="rgzl-tip">In the Studio, the cartridge manifold/HIC boundary symbol lets you group screw-in and logic cartridge valves exactly like a real manifold — with the dash-dot enclosure line of ISO 1219.</div>
HTML,
        ];
        $L[] = [
            'id' => 'hyd-cylinder-select',
            'cover' => $A . 'fig-hyd-buckling.svg',
            'title' => 'Selecting a hydraulic cylinder',
            'summary' => 'Bore from force, check the load with reserve, then verify the piston rod against buckling on long strokes.',
            'topic' => 'hydraulics', 'level' => 'intermediate', 'minutes' => 6, 'enabled' => true,
            'content' => <<< 'HTML'
<h3>Step 1 — Bore from the required force</h3>
<div class="rgzl-formula">A ≥ F / (p · η<sub>hm</sub>) &nbsp;&nbsp;with η<sub>hm</sub> ≈ 0.85–0.95</div>
<p>Round up to the next ISO bore (25, 32, 40, 50, 63, 80, 100, 125, 160 mm…). Then check the <em>retraction</em> force too when it drives the load. Speeds follow from flow: v = Q/A — consider whether the annulus-side retraction speed suits the process.</p>
<h3>Step 2 — Buckling (Euler) on push strokes</h3>
<p>A long, slender piston rod in compression can buckle — the governing case for presses and lift cylinders with free stroke. Effective buckling length depends on the mounting (guided/fixed ends), and manufacturers publish permissible load vs. stroke tables per rod diameter. Reduce the risk with: a thicker rod, guides/trunnion or clevis mounting nearer the load line, or reduced pressure.</p>
<h3>Step 3 — Details that matter</h3>
<ul>
<li>Cushioning for kinetic energy at end of stroke; stop tubes for long strokes and side loads.</li>
<li>Seal selection vs temperature, speed and fluid.</li>
<li>Mounting style: avoid side loads on the rod (self-aligning couplings).</li>
</ul>
<div class="rgzl-tip">In the Studio, the cylinder inspector computes diameter, velocity and buckling checks live from your bore, stroke and mounting selection.</div>
HTML,
        ];
        $L[] = [
            'id' => 'hyd-troubleshooting',
            'cover' => $A . 'photo-hyd-troubleshooting.jpg',
            'title' => 'Systematic hydraulic troubleshooting',
            'summary' => 'A field-proven sequence: pressure first, then flow — plus how to find internal leakage and test cylinders for drift.',
            'topic' => 'hydraulics', 'level' => 'advanced', 'minutes' => 8, 'enabled' => true,
            'content' => <<< 'HTML'
<h3>The golden order: pressure first, then flow</h3>
<ol>
<li><strong>Measure pressure</strong> at the pump outlet against relief setting. No pressure → check the prime mover, coupling, pump priming, relief stuck open.</li>
<li><strong>Measure flow</strong> (or judge by actuator speed). Pressure OK but slow → pump worn, suction starved, or something bypassing.</li>
<li><strong>Localize internal leakage</strong>: with the relief closed-end test (deadhead a cylinder; flow over relief should be pump flow if valves seal) — rising temperature over a valve or cylinder seals often reveals the leak.</li>
</ol>
<h3>Cylinder-specific checks</h3>
<ul>
<li><strong>Drift test</strong>: load the cylinder, close both ports; external creep = seals/piston leak (feel for heat on the barrel).</li>
<li>Jerky motion → air in oil, sticky seals, or meter-in control on an overrunning load.</li>
<li>Rod seal leak → inspect rod surface for scoring first; a new seal on a damaged rod fails in days.</li>
</ol>
<h3>Instrument smart</h3>
<p>Permanent test points (M16×2) at pump, relief, valve P/A/B make a 2-minute pressure reading possible without spilled oil. The Studio's test-point and gauge components mirror exactly that practice.</p>
<div class="rgzl-tip">Write down the machine's <em>healthy</em> values (pressures, cycle times, temperatures). "Different from the logbook" is the fastest diagnostic signal that exists.</div>
HTML,
        ];
        $L[] = [
            'id' => 'hyd-proportional',
            'cover' => $A . 'photo-hyd-propvalve.jpg',
            'title' => 'Proportional valves & amplifier basics',
            'summary' => 'How proportional spools differ from on/off valves, and the amplifier parameters gain, ramp, deadband and dither.',
            'topic' => 'hydraulics', 'level' => 'advanced', 'minutes' => 8, 'enabled' => true,
            'content' => <<< 'HTML'
<p>On/off valves know two states; <strong>proportional valves</strong> position the spool <em>continuously</em> against a spring in proportion to the command current (typ. 4–20 mA or 0–10 V), metering flow (and thus direction <em>and</em> speed) in one valve. Servo valves go further: nozzle-flapper or jet-pipe pilot stages with micron-grade spools — maximum dynamics, but they demand very clean oil.</p>
<h3>Amplifier parameters you'll meet on the card</h3>
<ul>
<li><strong>Gain</strong> — maps command voltage to output current; sets full flow at full command.</li>
<li><strong>Ramp (up/down)</strong> — slews the command to eliminate pressure shocks: soft start/stop of heavy cylinders.</li>
<li><strong>Deadband / deadzone</strong> — the overlap region near zero; compensated to get faster response around center.</li>
<li><strong>Dither</strong> — small high-frequency overlay (e.g. 100–200 Hz) that keeps the spool micro-moving, killing static friction (hysteresis).</li>
<li><strong>Enable, wire-break detection, and LVDT feedback</strong> for closed spool-position loops.</li>
</ul>
<div class="rgzl-tip">Simulate a proportional axis in the Studio: amplifier, setpoint potentiometer and ramp generator components model command shaping, while the valve's spool slides progressively during simulation.</div>
HTML,
        ];
        $L[] = [
            'id' => 'hyd-fluids-advanced',
            'cover' => $A . 'fig-hyd-fluids.svg',
            'title' => 'Oil properties, additives & fire-resistant fluids',
            'summary' => 'What a hydraulic fluid must do, how additives deliver it, and when to choose HFA/HFC/HFD fire-resistant fluids.',
            'topic' => 'hydraulics', 'level' => 'advanced', 'minutes' => 7, 'enabled' => true,
            'content' => <<< 'HTML'
<h3>The job description of a hydraulic oil</h3>
<ul>
<li>Transmit power with minimal compressibility and foaming.</li>
<li>Lubricate pumps/valves under mixed-film conditions (AW/EP additives form protective layers).</li>
<li>Keep viscosity stable: high <strong>viscosity index (VI)</strong> = less thinning when hot; typical HVLP oils reach VI > 100.</li>
<li>Protect against oxidation (long life), corrosion, and separate from water (demulsibility).</li>
</ul>
<h3>Fire-resistant fluids (ISO 12922)</h3>
<ul>
<li><strong>HFA-E/HFA-S</strong> — oil-in-water emulsions/solutions (~95 % water):钢厂/press lines near ignition sources; corrosion and narrow temperature window are the trade-offs.</li>
<li><strong>HFC (water glycol)</strong> — good fire resistance with decent lubricity up to ~50–60 °C; watch seal and paint compatibility.</li>
<li><strong>HFD (HFD-U esters / HFD-R phosphate ester)</strong> — lubricity near mineral oil; phosphate ester needs special seals (FPM/FKM, EPDM).</li>
</ul>
<p>Never mix fluid types; changing types requires full flushing and filter/seal review.</p>
<div class="rgzl-tip">Fire-resistant is not "no maintenance": HFC water content must be checked regularly, or viscosity and lubricity drift out of spec.</div>
HTML,
        ];
        $L[] = [
            'id' => 'hyd-mobile',
            'cover' => $A . 'photo-hyd-mobile.jpg',
            'title' => 'Mobile vs industrial hydraulics',
            'summary' => 'Excavator or injection molding machine? Why mobile systems look different: load-sensing, DCV blocks, and 24 V control.',
            'topic' => 'hydraulics', 'level' => 'beginner', 'minutes' => 5, 'enabled' => true,
            'content' => <<< 'HTML'
<p>The physics is identical — but priorities differ sharply between a factory power unit and a mobile machine.</p>
<h3>Industrial (stationary) hydraulics</h3>
<ul>
<li>Grid-powered, generous tanks, fixed speeds, quiet operation, long continuous duty.</li>
<li>Modular ISO 4401 valve stations, central hydraulic supply, 230/400 V solenoids, PLC control with relays/PLC outputs.</li>
</ul>
<h3>Mobile hydraulics</h3>
<ul>
<li>Engine-driven, weight- and space-critical, wide temperature/dirt/vibration exposure.</li>
<li><strong>Load-sensing (LS)</strong> variable pumps: the pump follows demand, saving fuel; constant-pressure or power-regulated alternatives.</li>
<li>Monoblock/stacked mobile DCVs with manual levers or 12/24 V proportional actuation; often multiple functions simultaneously.</li>
<li>Fan-driven oil coolers are the norm; filtration works harder (dust ingress on rods!).</li>
</ul>
<div class="rgzl-tip">Same ISO 1219 symbols everywhere — a load-sensing pump in the Studio is just a variable pump with its compensator; practice reading both applications with the circuit library.</div>
HTML,
        ];
        $L[] = [
            'id' => 'pne-compressors',
            'cover' => $A . 'photo-pne-compressor.jpg',
            'title' => 'Compressors and air receivers',
            'summary' => 'Piston vs screw vs scroll, duty-cycle thinking, and how receivers buffer consumption and let the compressor rest.',
            'topic' => 'pneumatics', 'level' => 'beginner', 'minutes' => 6, 'enabled' => true,
            'content' => <<< 'HTML'
<h3>Compressor types</h3>
<ul>
<li><strong>Piston (reciprocating)</strong> — economical for small/intermittent duty (workshop); watch the duty cycle (often 50–60 %) and oil carry-over unless oil-free.</li>
<li><strong>Screw</strong> — continuous duty, efficient and quiet above ~10 m³/min; the industrial default, often with integrated dryer and VSD drive.</li>
<li><strong>Scroll</strong> — compact, oil-free, quiet for labs and dental; limited capacity.</li>
</ul>
<h3>Discharge quality</h3>
<p>Compressed air leaves hot and wet. An aftercooler drops most water immediately; a refrigerated dryer then sets the +3 °C pressure dew point typical for general industry (adsorption dryers for −20…−70 °C).</p>
<h3>The receiver</h3>
<div class="rgzl-formula">V<sub>rec</sub> ≈ ΔV<sub>consumption</sub> · p<sub>atm</sub> / Δp<sub>allowed</sub></div>
<p>The tank buffers demand spikes so the compressor cycles less: a machine drawing 60 NL once per minute can run a much smaller compressor behind a correctly sized receiver. Keep the pressure band (load/unload settings) as narrow as hysteresis allows — every extra bar of band is wasted energy (~7 % more energy per bar).</p>
<div class="rgzl-tip">The Pneumatic Studio's power unit combines compressor, dryer and receiver into one symbol like the hydraulic power pack — with a working pressure you set for the whole circuit.</div>
HTML,
        ];
        $L[] = [
            'id' => 'pne-vacuum',
            'cover' => $A . 'photo-pne-vacuum-gripper.jpg',
            'title' => 'Vacuum technology & grippers',
            'summary' => 'Ejectors, vacuum level vs flow, suction-cup holding force, and pneumatic grippers for handling.',
            'topic' => 'pneumatics', 'level' => 'intermediate', 'minutes' => 6, 'enabled' => true,
            'content' => <<< 'HTML'
<h3>Vacuum from compressed air</h3>
<p>A <strong>venturi ejector</strong> accelerates supply air through a nozzle; the jet entrains air from the vacuum port and exhausts both through a silencer — simple, moving-part-free vacuum to about 85–95 % of atmospheric pressure. Multi-stage ejectors reach the same level with less air.</p>
<h3>Suction cups: the physics</h3>
<div class="rgzl-formula">F<sub>hold</sub> = Δp · A<sub>cup</sub> · (1/S) &nbsp;&nbsp;(S = safety factor 2–4)</div>
<p>Holding force comes from ambient pressure pushing the cup against the part — at −0.6 bar relative, a Ø 40 mm cup holds theoretically ≈ 75 N. For shear loads on vertical surfaces use <em>double</em> safety and bellows/oval cups on textures. Porous workpieces (cardboard, chipboard) need high-flow ejectors — leak rate, not vacuum level, governs.</p>
<h3>Pneumatic grippers</h3>
<ul>
<li><strong>Angular</strong> — hinged jaws, compact; closing force drops with jaw angle.</li>
<li><strong>Parallel</strong> — constant geometry, precise; symmetric gripping.</li>
<li><strong>Rod-lock/clamp cylinders and rotary grippers</strong> for heavier fixtures.</li>
</ul>
<div class="rgzl-tip">Check cup sizing with the compressor-off emergency case: a vacuum switch gauges the level before lifting, and a non-return valve holds the cup if air fails.</div>
HTML,
        ];
        $L[] = [
            'id' => 'pne-electro',
            'cover' => $A . 'fig-pne-elehp-circuit.svg',
            'title' => 'Electropneumatics: relays, sensors & PLC',
            'summary' => 'Solenoids, reed switches, latching circuits and seal-in logic — the bridge from pure pneumatics to real machine control.',
            'topic' => 'pneumatics', 'level' => 'intermediate', 'minutes' => 8, 'enabled' => true,
            'content' => <<< 'HTML'
<h3>Signal → solenoid → cylinder</h3>
<p>An electrical push-button energizes the valve's solenoid coil (typically 24 V DC): the valve shifts, the cylinder moves. At the end position a <strong>reed switch</strong> on the barrel (or an inductive proximity sensor for parts) reports the position back — closing the loop for the next step.</p>
<h3>Seal-in (self-holding) — the memory relay</h3>
<p>Detail you will use constantly: wire the relay's own NO contact in parallel with the start button. A pulse latches the relay ON ("seal-in"); the stop button (NC, in series) breaks it. That is exactly how the Studio's intermediate electropneumatic examples hold the cycle between start and stop.</p>
<h3>Classic building blocks</h3>
<ul>
<li>AND/OR in relays = series/parallel contacts; in pneumatics = two-pressure/shuttle valves.</li>
<li>On-delay timer relays = the electrical counterpart of pneumatic time-delay valves.</li>
<li>Emergency stop (NC, safety category per ISO 13849) must cut power to the solenoids — and in critical cases, exhaust the air (soft-start/dump valve).</li>
</ul>
<div class="rgzl-tip">Combine both worlds in the Pneumatic Studio: buttons, relays, timer relays and PLC elements sit in the Control category and animate together with the air circuit during simulation.</div>
HTML,
        ];
        $L[] = [
            'id' => 'pne-maintenance',
            'cover' => $A . 'photo-pne-maintenance.jpg',
            'title' => 'Pneumatic maintenance & troubleshooting',
            'summary' => 'The three enemies — dirty air, moisture, leaks — and a quick diagnostic sequence for sluggish cylinders.',
            'topic' => 'pneumatics', 'level' => 'beginner', 'minutes' => 6, 'enabled' => true,
            'content' => <<< 'HTML'
<h3>The three enemies of pneumatics</h3>
<ul>
<li><strong>Dirty air</strong> — wears seals and sticks valve spools; a 5 µm filter protects standard valves, lubricators (where present) must never run dry.</li>
<li><strong>Moisture</strong> — condensate corrodes and washes grease from cylinders; drain filters and the dryer on schedule; tubes sloped to drain points.</li>
<li><strong>Leaks</strong> — up to 25–30 % of generated air is lost in typical plants; hissing fittings, perished PU tubing, and leaky cylinder rod seals are the usual suspects. An ultrasonic detector finds inaudible leaks.</li>
</ul>
<h3>Sluggish cylinder? Quick sequence</h3>
<ol>
<li>Check <strong>supply pressure</strong> at the regulator (6 bar?) — a kinked tube or clogged filter upstream is common.</li>
<li>Listen at the valve exhaust — a choked <strong>silencer</strong> slows everything invisibly.</li>
<li>Check the flow-control (exhaust throttle) settings — they may simply be closed.</li>
<li>Verify the valve pilot reaches the coil (LED on the connector) — electrical before mechanical.</li>
<li>Disconnect and push the cylinder by hand to separate mechanical stickiness from pneumatics.</li>
</ol>
<div class="rgzl-tip">Track the service unit: a simple weekly glance at filter bowl + gauge prevents most pneumatic downtime. Pressure switch and gauge components in the Studio model precisely this instrumentation habit.</div>
HTML,
        ];
        $L[] = [
            'id' => 'gen-formulas',
            'cover' => $A . 'fig-gen-formulas.svg',
            'title' => 'Formula cheat sheet: hydraulics & pneumatics',
            'summary' => 'The twelve formulas that solve 90 % of fluid-power engineering tasks — from force and flow to power and air consumption.',
            'topic' => 'general', 'level' => 'intermediate', 'minutes' => 9, 'enabled' => true,
            'content' => <<< 'HTML'
<h3>Fluid power fundamentals</h3>
<div class="rgzl-formula">p = F / A &nbsp;&nbsp;|&nbsp;&nbsp; Q = v · A &nbsp;&nbsp;|&nbsp;&nbsp; v = Q / A</div>
<div class="rgzl-formula">P (kW) = p (bar) × Q (l/min) / 600</div>
<h3>Pumps & motors</h3>
<div class="rgzl-formula">Q = V<sub>g</sub> (cm³/rev) × n (rpm) × η<sub>vol</sub> / 1000<br>M (Nm) ≈ Δp (bar) × V<sub>g</sub> (cm³/rev) / (20π · η<sub>hm</sub>)</div>
<h3>Cylinders</h3>
<div class="rgzl-formula">A = π d² / 4 &nbsp;&nbsp;|&nbsp;&nbsp; A<sub>ring</sub> = π (d² − d<sub>rod</sub>²) / 4<br>F<sub>push</sub> = p · A &nbsp;· η<sub>hm</sub> &nbsp;&nbsp;|&nbsp;&nbsp; t = V / Q</div>
<h3>Lines</h3>
<div class="rgzl-formula">Δp = λ (L/d) ρv²/2 &nbsp;&nbsp;|&nbsp;&nbsp; d = √( 4Q / πv )</div>
<h3>Pneumatics</h3>
<div class="rgzl-formula">V<sub>NL</sub> ≈ A · s · (p<sub>bar,g</sub> + 1) &nbsp;per stroke<br>F<sub>cup</sub> = Δp · A<sub>cup</sub> / S</div>
<h3>Accumulator</h3>
<div class="rgzl-formula">V<sub>usable</sub> = V₀ p₀ (1/p₁ − 1/p₂)</div>
<div class="rgzl-tip">Bookmark this lesson: it collects every formula the RGZ studios use internally for validation and simulation — the same numbers you read in the metrics panels.</div>
HTML,
        ];
        $L[] = [
            'id' => 'elec-fundamentals',
            'cover' => $A . 'fig-elec-fundamentals.svg',
            'title' => 'Electricity basics for fluid-power technicians',
            'summary' => 'DC control circuits, Ohm\'s law, what a solenoid coil actually does with 24 V, and how to measure correctly with a multimeter.',
            'topic' => 'general', 'level' => 'beginner', 'minutes' => 7, 'enabled' => true,
            'content' => <<< HTML
<p>Every electro-hydraulic and electro-pneumatic machine is two systems in one: a <strong>power section</strong> (oil or air) and a <strong>signal section</strong> (electricity). The signal side almost always runs on <strong>24 V DC</strong> — safe to touch, short-circuit tolerant and standard for industrial sensors and valves.</p>
<figure class="rgzl-fig"><img src="{$A}fig-elec-fundamentals.svg" alt="A simple 24 V DC control circuit with switch, solenoid coil and multimeter"><figcaption>The simplest control circuit: supply → switch → solenoid → back to 0 V.</figcaption></figure>
<h3>The three quantities</h3>
<div class="rgzl-formula">U = R · I &nbsp;&nbsp;|&nbsp;&nbsp; P = U · I</div>
<p>Voltage U (volts) pushes, current I (amperes) flows, resistance R (ohms) opposes. A typical valve coil: 24 V, 30 Ω → it draws 0.8 A and converts ≈ 19 W into the magnetic force that strokes the spool (plus heat — a coil is rated for 100 % duty and gets warm in service, that is normal).</p>
<h3>What the coil does</h3>
<p>Current through the winding builds a magnetic field that pulls an iron <strong>armature</strong> a few millimetres. That armature strokes the valve pilot or spool. No current → the return spring drives the valve home. This crisp ON/OFF behaviour is what makes solenoid valves the standard "muscle switch" of fluid power.</p>
<h3>Measuring without guessing</h3>
<ul>
<li><strong>Voltage</strong> — parallel to the load, circuit live (black probe 0 V rail, red at the coil terminal).</li>
<li><strong>Current</strong> — the meter goes <em>in series</em>; measure at the coil supply wire.</li>
<li><strong>Resistance / continuity</strong> — only with the circuit <em>dead</em>: a healthy 24 V coil reads 15–100 Ω, never 0 nor ∞.</li>
</ul>
<div class="rgzl-tip">Most "valve does not shift" faults are electrical: check the connector LED, then voltage at the coil pins — before touching a single wrench.</div>
HTML,
        ];
        $L[] = [
            'id' => 'elec-switches-sensors',
            'cover' => $A . 'fig-elec-sensors.svg',
            'title' => 'Pushbuttons, switches and industrial sensors',
            'summary' => 'NO vs NC contacts, reed switches on cylinders, inductive / capacitive / optical proximity sensors and electro-pneumatic pressure switches.',
            'topic' => 'general', 'level' => 'beginner', 'minutes' => 6, 'enabled' => true,
            'content' => <<< HTML
<p>Control starts with information: <strong>input devices</strong> delivered by people (pushbuttons, selector switches) and <strong>sensors</strong> delivered by the machine (positions, pressure, presence).</p>
<h3>Mechanical contacts</h3>
<p>A pushbutton has one of two resting states: <strong>NO</strong> (normally open — closes when pressed) and <strong>NC</strong> (normally closed — opens when pressed, used for STOP and safety chains). Contacts are numbered per standard: function digit first (1 = NC, 2 = NO), then the pole index — so <em>13–14</em> is the classic NO pair.</p>
<figure class="rgzl-fig"><img src="{$A}fig-elec-sensors.svg" alt="Reed switch, inductive, optical and pressure sensors"><figcaption>Four everyday sensor families of fluid-power automation.</figcaption></figure>
<h3>Sensors you will meet</h3>
<ul>
<li><strong>Reed switch</strong> — clamps on the cylinder barrel; the piston magnet closes the contact at its position. The standard end-position report on pneumatic cylinders (PNP outputs on modern models).</li>
<li><strong>Inductive proximity</strong> — detects metal at 1–15 mm without contact; the workhorse for cylinder positions and parts presence.</li>
<li><strong>Capacitive</strong> — also senses non-metals (water, oil level, granulate).</li>
<li><strong>Optical</strong> — through-beam or reflex; long ranges, exact edges.</li>
<li><strong>Pressure switch</strong> — converts an air/oil pressure threshold into a contact; e.g. "clamp pressure reached → drilling may start".</li>
</ul>
<p>Output styles: <strong>PNP</strong> (switches +24 V to the input — European standard) and NPN (switches 0 V). Three wires: brown +24 V, blue 0 V, black signal.</p>
<div class="rgzl-tip">A failing reed switch shows as a sequence that simply stops at one step — the system never "hears" the cylinder arrived. Check the sensor LED first.</div>
HTML,
        ];
        $L[] = [
            'id' => 'elec-relays',
            'cover' => $A . 'photo-elec-cabinet.jpg',
            'title' => 'Relays, contactors and the self-latching rung',
            'summary' => 'How a small signal switches a big load, contact numbering, pick-up vs drop-out delay, and the three-wire latching pattern every classic control is built from.',
            'topic' => 'general', 'level' => 'intermediate', 'minutes' => 7, 'enabled' => true,
            'content' => <<< HTML
<p>A <strong>relay</strong> is an electrically operated switch: a small coil (24 V, &lt;1 W) pulls an armature that moves isolated contacts. It separates control from load, multiplies one signal into many contacts, and stores information. A <strong>contactor</strong> is the same idea scaled for power loads (motors, pumps).</p>
<figure class="rgzl-fig"><img src="{$A}fig-elec-relay.svg" alt="Relay self-latching ladder rung"><figcaption>Self-latching: brief press on S1 energises K1; its own contact keeps K1 alive until S0 breaks the rung.</figcaption></figure>
<h3>Self-latching (memory) in one rung</h3>
<p>Put the relay's own NO contact <em>in parallel</em> with the START button. Press once → the coil energises and seals itself in through its contact. A NC STOP in series releases it. Exactly the same pattern appears everywhere: as ladder logic in a PLC, or as a double-solenoid valve's two coils (SET / RESET).</p>
<h3>Reading relay data</h3>
<ul>
<li><strong>Contacts</strong> numbered like switches: 13–14 (NO), 21–22 (NC), 31–32…; the coil is A1/A2.</li>
<li><strong>Pick-up vs drop-out</strong> — a relay pulls in within ~10 ms and falls out when the coil drops below roughly 10 % of nominal; undervoltage makes contacts chatter.</li>
<li><strong>Timing relays</strong> add on-delay / off-delay to the same housing — the electrical counterpart of the pneumatic time-delay valve.</li>
</ul>
<div class="rgzl-tip">Modern machines replace relay walls with a PLC, but the <em>logic</em> is identical: school yourself on relay ladders and PLC programs become trivial to read.</div>
HTML,
        ];
        $L[] = [
            'id' => 'pne-elehp-circuits',
            'cover' => $A . 'fig-pne-elehp-circuit.svg',
            'title' => 'Electro-pneumatics I: solenoid valve control',
            'summary' => 'The 5/2 solenoid valve as the interface between electricity and air: direct vs control-side actuation, coil ratings, overrides and a complete press example.',
            'topic' => 'pneumatics', 'level' => 'intermediate', 'minutes' => 8, 'enabled' => true,
            'content' => <<< HTML
<p>Gate between the worlds: the <strong>solenoid directional valve</strong>. Its coil moves a small pilot; the pilot air strokes the main spool (on larger valves) or the coil drives the spool directly (small 3/2, 5/2 valves).</p>
<figure class="rgzl-fig"><img src="{$A}fig-pne-elehp-circuit.svg" alt="Electro-pneumatic control: 5/2 single-solenoid valve, cylinder and electrical ladder"><figcaption>Pneumatic power section + electrical signal section of the same machine.</figcaption></figure>
<h3>Two control philosophies</h3>
<ul>
<li><strong>Direct</strong> — the pushbutton feeds the valve coil. One wire, immediate, but the button carries the coil current.</li>
<li><strong>Via relay / PLC output</strong> — the button only informs the logic; a protected output drives the coil. This is how every real machine is built.</li>
</ul>
<h3>Choosing and reading a coil</h3>
<ul>
<li>Voltage: 24 V DC (standard), sometimes 110/230 V AC — AC coils hum when the armature cannot seat.</li>
<li>Power 3–30 W; duty 100 %; <strong>manual override</strong> (blue/red pin) for commissioning.</li>
<li>Connector standard (EN 175301) with LED — the first diagnostic light of every fitter.</li>
</ul>
<h3>Complete example: forming press</h3>
<p>Press S1 → relay K1 energises → its contact drives coil Y1 → the 5/2 switches → the cylinder extends against the part. Release S1 → Y1 drops out → spring return on valve and cylinder. Add a NC guard-door contact in the rung and you have the skeleton of a safe press control.</p>
<div class="rgzl-tip">In the Pneumatic Studio, build exactly this circuit: power pack → 5/2 single-solenoid → double-acting cylinder, then simulate and watch the coil, spool and piston act together.</div>
HTML,
        ];
        $L[] = [
            'id' => 'pne-elehp-sequences',
            'cover' => $A . 'fig-pne-elehp-sequence.svg',
            'title' => 'Electro-pneumatics II: relay sequences, timers and counters',
            'summary' => 'Building a controlled A+ B+ B− A− cycle with reed contacts and relays: step guards, signal storage and on-delay timing — the ladder logic of classic machines.',
            'topic' => 'pneumatics', 'level' => 'advanced', 'minutes' => 9, 'enabled' => true,
            'content' => <<< HTML
<p>A <strong>sequence control</strong> executes steps in a fixed order — each step is only allowed when the previous one reports completion. That report comes from reed switches (positions) or pressure switches, and the "brain" is a small set of relays.</p>
<figure class="rgzl-fig"><img src="{$A}fig-pne-elehp-sequence.svg" alt="Relay ladder for the sequence A+ B+ B− A−"><figcaption>Four rungs, four steps: each relay is guarded by the end-position sensors of the previous step.</figcaption></figure>
<h3>Step chain, rung by rung</h3>
<p>Exercise classic A+ B+ B− A− (clamp, feed, retract, unclamp): relay K1 runs when START <em>and</em> home signals a0 AND b1 are true; K1's contacts drive coil Y1 (A extends). Sensor a1 fires K2 → B extends; b1 fires K3 → B retracts; b0 fires K4 → A retracts. Every rung is a tiny AND: <em>condition</em> from the sensors, <em>permission</em> from the previous relay.</p>
<h3>Signal storage techniques</h3>
<ul>
<li><strong>Relay latching</strong> — one pulse stores a state until RESET (previous lesson).</li>
<li><strong>Double-solenoid valve</strong> — the valve itself is the memory: a short pulse on "a" sets it, on "b" resets it; no continuous coil current needed.</li>
<li><strong>On-delay timer</strong> — "hold 2 s at the end position, then retract" (dwell for quality, glue, welding…).</li>
<li><strong>Counter/preset relay</strong> — repeat the cycle N times, then stop and signal.</li>
</ul>
<div class="rgzl-tip">Design rule from the Festo exercises: draw the <em>displacement-step diagram</em> first, then name every sensor, then write the rungs. Never wire "from memory".</div>
HTML,
        ];
        $L[] = [
            'id' => 'pne-timed-pressure',
            'cover' => $A . 'fig-pne-timed-pressure.svg',
            'title' => 'Time-delay, pressure-sequence and quick-exhaust circuits',
            'summary' => 'Three classic pure-pneumatic specials: dwell timers from restrictor + volume + 3/2, pressure-triggered next steps, and the little valve that makes cylinders fast.',
            'topic' => 'pneumatics', 'level' => 'intermediate', 'minutes' => 7, 'enabled' => true,
            'content' => <<< HTML
<p>Not everything needs a PLC. Three small components deliver timing, pressure logic and speed directly in the air lines.</p>
<h3>Time-delay valve</h3>
<p>A <strong>restrictor + small air volume + 3/2 valve</strong>: the signal slowly fills the volume; when threshold pilot pressure is reached, the 3/2 switches. Adjustable 0–30 s. Connect it normal-closed for an <em>on-delay</em>, reversed for <em>off-delay</em>. Typical job: clamp dwell, filtered start signals (ignore bounces), end-position acknowledge.</p>
<figure class="rgzl-fig"><img src="{$A}fig-pne-timed-pressure.svg" alt="Time-delay valve, timing curve and pressure sequence valve"><figcaption>Time as a signal: fill a volume; pressure as a trigger: switch at the threshold.</figcaption></figure>
<h3>Pressure-sequence valve</h3>
<p>A 3/2 that switches when <em>line</em> pressure exceeds its setting — the pneumatic pressure switch without electricity. Circuit pattern: "drill down until the counter-pressure from the block signals part-contact, then advance slowly".</p>
<h3>Quick-exhaust valve</h3>
<p>A tiny disc valve mounted <em>directly</em> on the cylinder port: flow goes in normally through the small throttle, but exhaust dumps to atmosphere <em>at the port</em> instead of traveling back through the metre of tube to the valve. The classic way to retract a cylinder at full speed.</p>
<div class="rgzl-tip">The Pneumatic Studio includes all three — place a time-delay valve in a circuit and watch its pilot pressure climb in slow motion during simulation.</div>
HTML,
        ];
        $L[] = [
            'id' => 'pne-multi-actuator',
            'cover' => $A . 'fig-pne-multi.svg',
            'title' => 'Multi-actuator circuits: signal overlap and the cascade',
            'summary' => 'Why A+ B+ B− A− jams a naive control, how to split a sequence into groups that never collide, and how reversing valves clear blocked pilot signals.',
            'topic' => 'pneumatics', 'level' => 'advanced', 'minutes' => 8, 'enabled' => true,
            'content' => <<< HTML
<p>Single-actuator controls are forgiving — every sensor signal has exactly one meaning. With two or more cylinders the same signal can be needed twice, and the classic problem appears: <strong>signal overlap</strong>.</p>
<h3>The overlap problem</h3>
<p>Sequence A+ B+ B− A− with limit valves wired straight to the 5/2 pilots: when B leaves b0, its signal arrives at the "extend B" pilot — but B still stands still, so its own limit signal b0 is <em>still pressed</em> and holds the "retract B" pilot. The valve now feels both pilots at once: nothing moves, the machine hangs.</p>
<figure class="rgzl-fig"><img src="{$A}fig-pne-multi.svg" alt="Cascade grouping of a two-cylinder sequence"><figcaption>Cascade method: the sequence is split into groups; supply air is switched group by group.</figcaption></figure>
<h3>Cascade division</h3>
<p>Solution of the Festo course: split the motion chain into groups that contain no cylinder twice. A+ | B+ B− | A− → three groups (or two in smarter splits). A cascade of supply-switching 4/2 valves feeds pilot air to <em>one group at a time</em> — signals of inactive groups are simply dead, so nothing can block.</p>
<h3>Reversing valves</h3>
<p>The lighter alternative: a roller-lever <strong>reversing valve</strong> on the offending signal line, flipped by the cylinder itself. It exists exactly to chop the long signal that would otherwise overlap. Co-ordinated motion (feed + clamp + eject) is designed the same way: draw the displacement-step diagram, mark every signal, resolve every overlap on paper.</p>
<div class="rgzl-tip">This is pneumatic programming without a single wire — the same group-splitting logic you later meet in PLC step-chains (SFC/GRAPH).</div>
HTML,
        ];
        $L[] = [
            'id' => 'pne-distribution',
            'cover' => $A . 'fig-pne-distribution.svg',
            'title' => 'Compressed-air networks: ring mains, drops and drains',
            'summary' => 'How air travels from the compressor room to the machine without losing pressure or carrying condensate — pipe sizing, slope, drop engineering.',
            'topic' => 'pneumatics', 'level' => 'intermediate', 'minutes' => 6, 'enabled' => true,
            'content' => <<< HTML
<p>The cleanest compressor cannot help a badly piped plant: undersized lines eat pressure (and money), and condensate follows the air straight into the valves.</p>
<figure class="rgzl-fig"><img src="{$A}fig-pne-distribution.svg" alt="Ring main with top-off drops and low-point drains"><figcaption>Layout discipline: slope, top drops, bottom drains.</figcaption></figure>
<h3>Network layout rules</h3>
<ul>
<li><strong>Ring main</strong> around the building — every point is fed from two sides, pressure stays even, sections can be isolated for service.</li>
<li><strong>Slope 1–2 %</strong> in the flow direction of the main: condensate runs with the airflow to the low points, never upstream against it.</li>
<li><strong>Drops from the TOP</strong> of the main, curving down to the machine — gravity keeps water in the main; at the bottom of each main leg sits an automatic <strong>drain</strong>.</li>
<li>Machine-side service unit (filter + regulator) per station — as in the FRL lesson.</li>
</ul>
<h3>Sizing</h3>
<p>Size by total consumption plus simultaneity and growth. As orientation: 6–10 m/s in mains; every bar of Δp at the tool is ≈ 7 % wasted compressor energy. Materials: galvanised steel, stainless, aluminium profile systems or PE grid lines — modern aluminium nets assemble without threading and never rust.</p>
<div class="rgzl-tip">A plant that "loses pressure at shift start" usually has an undersized ring or a bottleneck fitting — log pressure at the FRL BEFORE blaming the compressor.</div>
HTML,
        ];
        $L[] = [
            'id' => 'hyd-elehh-circuits',
            'cover' => $A . 'fig-hyd-elehh-circuit.svg',
            'title' => 'Electro-hydraulics I: solenoid valves and logic control',
            'summary' => 'Power section meets signal section: direct and relay-switched solenoid DCVs on single- and double-acting cylinders, with the Boolean view of the classic exercises.',
            'topic' => 'hydraulics', 'level' => 'intermediate', 'minutes' => 8, 'enabled' => true,
            'content' => <<< HTML
<p>Electro-hydraulics pairs oil's force with electricity's logic. System structure (Festo model): <strong>power section</strong> (pump, valves, cylinder), <strong>signal section</strong> (sensors, relays/PLC), and the <strong>interface</strong> — the solenoid on the valve.</p>
<figure class="rgzl-fig"><img src="{$A}fig-hyd-elehh-circuit.svg" alt="Electro-hydraulic control: cylinder, 4/3 solenoid valve, pump and pressure switch"><figcaption>The pressure switch B1 is the ear of the electrical side: it reports the oil side's state.</figcaption></figure>
<h3>Basic switching exercises, generalised</h3>
<ul>
<li><strong>Direct control</strong> — button drives coil Y1 of a 3/2 (single-acting) or 4/2 (double-acting): press = move, release = return. Simple and perfectly valid for one-shot operations.</li>
<li><strong>Via relay</strong> — button drives K1, K1 drives Y1: contacts multiply, voltage drops disappear over distance, and logic can be inserted.</li>
<li><strong>Signal reversal</strong> — use the NC contact / spring-centered 4/3: the cylinder is only driven as long as commanded, then positively stops holding mid-travel.</li>
</ul>
<h3>The Boolean view</h3>
<p>Contacts in <strong>series = AND</strong> (guard AND start), in <strong>parallel = OR</strong> (jog from panel OR remote). NC gives NOT. The XOR circuit (two stations, exactly one active) from the assembly-line exercise is two AND-NOT branches — worth drawing once by hand.</p>
<div class="rgzl-tip">Rule of thumb from the Festo exercises: one relay per state, one solenoid per motion command. Extra cleverness in contacts — never in coils.</div>
HTML,
        ];
        $L[] = [
            'id' => 'hyd-elehh-sequences',
            'cover' => $A . 'fig-hyd-elehh-sequence.svg',
            'title' => 'Electro-hydraulics II: latching and sequence control',
            'summary' => 'Clamp → press → release without a PLC: signal storage with double-solenoid valves, electrical set/reset, speed stages and pressure- or path-dependent sequences.',
            'topic' => 'hydraulics', 'level' => 'advanced', 'minutes' => 9, 'enabled' => true,
            'content' => <<< HTML
<p>Real machines chain motions: clamp the part, feed the tool, retract, unclamp. Two families of memory solve it.</p>
<h3>Storage on the fluid side vs the electrical side</h3>
<ul>
<li><strong>Double-solenoid DCV</strong> — pulse "a" strokes the spool; it stays (detent/friction) until "b" pushes back. The valve IS the memory — secure against power loss, tolerant to contact bounce.</li>
<li><strong>Relay latching</strong> — coils switch cleanly NO/NC; the latched rung drives a single-solenoid spring-return valve. Clearer to extend, watch power-loss reset behaviour.</li>
</ul>
<figure class="rgzl-fig"><img src="{$A}fig-hyd-elehh-sequence.svg" alt="Electrical ladder of a clamp-press-release sequence"><figcaption>Five rungs from clamping to release — guarded by the pressure switch and timers.</figcaption></figure>
<h3>Sequence by pressure or by position</h3>
<p>Clamp → press is typically <strong>pressure-dependent</strong>: pressure switch B1 closes only when clamp pressure is truly reached (part present, no slip) — then Y2 feeds the press. Retraction is <strong>path-dependent</strong>: an inductive sensor at the end position starts the return. Add a throttle check for a controlled working feed and an on-delay for dwell at depth; add a counter and an AUTO latch for continuous cycling until N parts are done.</p>
<div class="rgzl-tip">Debugging order on such machines: mechanical pressure first (gauge!), then the fluid state (valve position), only then the ladder page by page.</div>
HTML,
        ];
        $L[] = [
            'id' => 'hyd-motors',
            'cover' => $A . 'fig-hyd-motors.svg',
            'title' => 'Hydraulic motors: continuous rotary power',
            'summary' => 'Gear, vane and piston motors, torque from Δp and displacement, speed from flow — and where rotary actuators beat cylinders.',
            'topic' => 'hydraulics', 'level' => 'intermediate', 'minutes' => 6, 'enabled' => true,
            'content' => <<< HTML
<p>A hydraulic motor is a pump run backwards: pressurised oil in → shaft torque out. Same families, same physics — the displacement V<sub>g</sub> is again the master spec:</p>
<div class="rgzl-formula">M (Nm) ≈ Δp (bar) × V<sub>g</sub> (cm³/r) / (20π · η<sub>hm</sub>) &nbsp;&nbsp;|&nbsp;&nbsp; n (rpm) = Q × 1000 / V<sub>g</sub></div>
<figure class="rgzl-fig"><img src="{$A}fig-hyd-motors.svg" alt="Hydraulic motor symbol and gear motor pictogram"><figcaption>Circle with inward triangle: energy conversion INTO the system.</figcaption></figure>
<h3>Types</h3>
<ul>
<li><strong>Gear motors</strong> — simple, robust, cheap; up to ~250 bar, modest startup torque; winches, conveyors, fans.</li>
<li><strong>Vane motors</strong> — smooth at low speed, medium pressure.</li>
<li><strong>Axial/radial piston</strong> — the heavyweights: high pressure, high start-up torque, precise low-speed control (crawler drives, rotary heads).</li>
</ul>
<h3>Working with motors</h3>
<p>Pressure rises only with the <em>load torque</em> — an unloaded motor spins at nearly zero pressure. Leakage oil (case drain — the third small line!) must run directly to tank unpressurised, or the shaft seal dies. For reversing drives use a 4/3 with closed centre plus cross-line reliefs protecting both legs against overrunning-load pressure spikes.</p>
<div class="rgzl-tip">Need rotation within an angle (clamping, tilting)? Use a rotary actuator (vane or rack-pinion "scotch yoke") — the cylinder's rotary sibling.</div>
HTML,
        ];
        $L[] = [
            'id' => 'hyd-measurement',
            'cover' => $A . 'fig-hyd-measurement.svg',
            'title' => 'Gauges, sensors and test points: measuring in hydraulics',
            'summary' => 'Bourdon-tube gauges, electronic pressure and flow sensors, temperature monitoring — the instruments that turn troubleshooting from guessing into reading.',
            'topic' => 'hydraulics', 'level' => 'beginner', 'minutes' => 6, 'enabled' => true,
            'content' => <<< HTML
<p>Everything you have calculated in the previous lessons (p, Q, v, force) is only verifiable if you can <strong>measure</strong> it — that is why professional power units have test points at every critical leg.</p>
<figure class="rgzl-fig"><img src="{$A}fig-hyd-measurement.svg" alt="Bourdon gauge, electronic pressure sensor and flow meter"><figcaption>Mechanical or electronic — the question is the same: p, Q, θ?</figcaption></figure>
<h3>The toolkit</h3>
<ul>
<li><strong>Bourdon-tube pressure gauge</strong> — coiled flat tube straightens with pressure; robust, glycerine-filled for pulsating lines. Choose the scale so working pressure sits at ~75 % of full scale.</li>
<li><strong>Pressure sensor / switch</strong> — 4–20 mA or 0–10 V to the PLC; a switch gives a contact at a setpoint (the B1 of the electro-hydraulic lessons).</li>
<li><strong>Flow meter</strong> — turbine, gear or oval-wheel; indispensable when comparing pump delivery across operating points.</li>
<li><strong>Temperature</strong> — level/temperature switches in the tank guard oil life: sustained &gt;80 °C halves oil and seal service life rapidly.</li>
</ul>
<h3>Test-point discipline</h3>
<p>Measure at defined points in a defined operating state, write the values down, compare against commissioning values. A relief drifting 20 bar down or a pump losing 30 % flow is visible months before failure — if you measured.</p>
<div class="rgzl-tip">The studios' gauge and pressure-switch components exist exactly to build this habit: instrument first, conclude second.</div>
HTML,
        ];
        $L[] = [
            'id' => 'hyd-prop-curves',
            'cover' => $A . 'fig-hyd-prop-curves.svg',
            'title' => 'Proportional valves: characteristic curves and dynamics',
            'summary' => 'Hysteresis, inversion range, response threshold, pressure curves and step response — reading a proportional valve the way its designer does.',
            'topic' => 'hydraulics', 'level' => 'advanced', 'minutes' => 8, 'enabled' => true,
            'content' => <<< HTML
<p>A proportional valve is fully described by its <strong>characteristic curves</strong>. Learn to read them and selection + commissioning become engineering instead of mystery.</p>
<figure class="rgzl-fig"><img src="{$A}fig-hyd-prop-curves.svg" alt="Hysteresis loop and dither ripple of proportional valves"><figcaption>Left: up-command ≠ down-command (hysteresis). Right: dither keeps the spool slippery.</figcaption></figure>
<h3>Static curves</h3>
<ul>
<li><strong>Pressure valves</strong>: output pressure vs command — nearly linear; the slope is the gain (bar per % / per mA).</li>
<li><strong>Flow/directional valves</strong>: flow vs command at constant Δp — starts at the <strong>deadband</strong> (positive overlap, often 10–30 % of command; crossed with feedback spools to near zero).</li>
<li><strong>Hysteresis</strong> — friction + magnetic remanence: the up-branch differs from the down-branch by a few %; better valves ≤ 1–3 %.</li>
<li><strong>Response threshold / inversion range</strong> — the smallest command change the valve answers to (≈ 0.1–1 %); the floor of your positioning accuracy.</li>
</ul>
<h3>Dynamics</h3>
<p>Step-response time to 90 % and the −3 dB (or −90°) frequency tell how fast the valve follows: typical direct-acting 20–80 ms, piloted faster stages exist for demanding axes. Bode plots in datasheets pair amplitude and phase — for loop tuning, phase margin is the interesting one.</p>
<h3>Application limits</h3>
<p>Max flow grows with √Δp over the metering edge — doubling rated Δp gives only ~40 % more authority. Overspeed conditions and pressure shocks need their own protections (counterbalance, reliefs) — proportional spools are metering edges, not safety valves.</p>
<div class="rgzl-tip">In the Hydraulic Studio, the proportional valve and amplifier components expose gain, ramp and deadband directly — watch the step response change as you edit them.</div>
HTML,
        ];
        $L[] = [
            'id' => 'hyd-prop-closedloop',
            'cover' => $A . 'fig-hyd-closedloop.svg',
            'title' => 'Proportional control in practice: open and closed loops',
            'summary' => 'From the manually switched feed drive to closed-loop positioning: the signal chain, speed profiles, and when closed loop is worth its sensor.',
            'topic' => 'hydraulics', 'level' => 'advanced', 'minutes' => 9, 'enabled' => true,
            'content' => <<< HTML
<p>The Festo training path builds the same feed drive three times: manual hand lever → switching solenoid valves with limit switches → proportional. The proportional version wins on smoothness, programmability and reproducible speed profiles.</p>
<h3>The signal chain</h3>
<p>Setpoint (potentiometer, PLC analog output) → <strong>amplifier</strong> (ramps, gains, dither) → proportional valve → cylinder/motor speed. Open loop: the machine trusts the chain. Closed loop: a position or speed sensor reports the truth back to a <strong>controller</strong> that compares, computes error Δe and corrects the command continuously.</p>
<figure class="rgzl-fig"><img src="{$A}fig-hyd-closedloop.svg" alt="Closed-loop block diagram: setpoint, controller, amplifier, valve, hydraulics, feedback sensor"><figcaption>The loop: only the measured truth decides the final motion.</figcaption></figure>
<h3>Open loop vs closed loop</h3>
<ul>
<li><strong>Open</strong> — cheaper, stable by nature; accuracy limited by oil temperature, load and valve hysteresis (think ±1–3 % of stroke).</li>
<li><strong>Closed</strong> — position accuracy into the 0.1–0.5 % range with repeatability independent of load; needs sensor, controller, tuned gains, and respects the axis's natural frequency (valve must be ~4× faster).</li>
</ul>
<h3>Practical patterns</h3>
<p>Speed profiles with ramps avoid jerking loads and compressive shocks; a slowdown point before every end position (taught via PLC cams) gives soft, fast cycles. Watch energy: proportional metering throttles → heat; over-centre loads need counterbalance valves; minimal leakage circuits protect warm-up accuracy. Modern axes move the whole loop INTO the valve (on-board electronics, digital fields).</p>
<div class="rgzl-tip">Studio exercise: build a feed axis with the proportional valve, set a pure P-gain amplifier, then observe overshoot as you raise gain — the exact trade-off of a real loop.</div>
HTML,
        ];
        $L[] = [
            'id' => 'gen-function-diagrams',
            'cover' => $A . 'fig-gen-fundiagram.svg',
            'title' => 'Function diagrams and control documentation',
            'summary' => 'Displacement-step diagrams, function charts, circuit and terminal diagrams — the paper trail that makes machines designable, testable and repairable.',
            'topic' => 'general', 'level' => 'intermediate', 'minutes' => 7, 'enabled' => true,
            'content' => <<< HTML
<p>A machine that exists only in someone's head is unrepairable. The Festo documentation set has four views — each answers a different question.</p>
<h3>1. Displacement–step diagram (function diagram)</h3>
<p>One line per actuator, steps on the x-axis, path/stroke on the y-axis: WHO moves WHEN. Drawn <em>before</em> any component is chosen — it is the contract of the control design, and reveals signal overlap at a glance.</p>
<figure class="rgzl-fig"><img src="{$A}fig-gen-fundiagram.svg" alt="Displacement-step diagram of clamp and press cylinders"><figcaption>Clamp (A) must arrive and hold before press (B) runs — the diagram says it without a word of code.</figcaption></figure>
<h3>2. Function chart</h3>
<p>The ladder-friendly tabulation: steps down, actuators and sensors across, X marks active elements per step; the direct bridge into relay/PLC programming (SFC-style).</p>
<h3>3. Circuit diagrams</h3>
<p>The ISO symbol schematic (fluid) and the electrical ladder diagram (control). Elements numbered by circuit groups: 0 = supply, 1 = first drive, 2 = second…; every element's mark in the drawing = its mark in the machine.</p>
<h3>4. Terminal and wire diagrams</h3>
<p>For the cabinet builder: every wire numbered, every terminal labelled; the solenoid in rung 3, wire 14, terminal X2:7 — one identity from drawing to screwdriver.</p>
<div class="rgzl-tip">Adopt the discipline on small jobs: sketch the displacement-step diagram on paper before opening a studio app — the circuit almost designs itself afterwards.</div>
HTML,
        ];
        $L[] = [
            'id' => 'gen-safety',
            'cover' => $A . 'fig-gen-safety.svg',
            'title' => 'Safety first: stored energy, jets and electricity',
            'summary' => 'The non-negotiable rules of fluid-power and electrical maintenance: depressurise, lock out, verify — and respect the pinhole jet.',
            'topic' => 'general', 'level' => 'beginner', 'minutes' => 6, 'enabled' => true,
            'content' => <<< HTML
<figure class="rgzl-fig"><img src="{$A}fig-gen-safety.svg" alt="Safety pictograms: stored energy, high-pressure jets, electricity"><figcaption>The three hazard families of fluid-power work.</figcaption></figure>
<h3>Stored energy stays on duty</h3>
<p>Switched off ≠ de-energised. <strong>Accumulators</strong> hold hundreds of bar for hours; compressed-air receivers too; suspended cylinder loads can descend on their own. The ritual before any intervention: <em>Lock out</em> the start → <em>release</em> pressure at the designed bleed point → <em>verify zero</em> on the gauge → only then work (LOTO — lock-out, tag-out).</p>
<h3>The invisible cutter</h3>
<p>A pinhole-leak jet at 200 bar penetrates skin without pain at first and injects oil under it — a surgical emergency, not a band-aid case. Never trace a leak with the hand; use cardboard, gauge checks, or the shut-down method.</p>
<h3>Electricity: respect, not fear</h3>
<p>Control circuits at 24 V DC are body-safe; their <em>knowledge risk</em> remains (a 24 V mistake still drops a press). Machine mains, transformers and large capacitor banks belong to qualified hands. Effects of current on the body are current-path and time dependent — the professional rule-set (isolation, covers, RCDs, color-of-cables discipline) exists in every plant for a reason.</p>
<h3>House rules that prevent 90 % of incidents</h3>
<ul>
<li>Never tighten or loosen a fitting under pressure; never vent the gas side of an accumulator uncontrolled — connect the charging rig.</li>
<li>Nitrogen ONLY for accumulator pre-charge — oxygen/oil-air compressed mixtures are explosive.</li>
<li>After work: function-test against the checklist, at low pressure first, guards back on.</li>
</ul>
<div class="rgzl-tip">Make it culture: the slowest safe repair beats the fastest unsafe one — every time, without exception.</div>
HTML,
        ];

        return $L;

    }
}
