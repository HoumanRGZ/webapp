import fs from "fs";
function rgzFluidSolve(Z){"use strict";Z=Z||{};var Ce=Z.fluid==="air"?"air":"oil",De=Z.components||[],te=Z.connections||[],at=W(Z.time,0),Qe=W(Z.dt,0);function W(c,f){var k=Number(c);return Number.isFinite(k)?k:f}function ce(c,f,k){return c<f?f:c>k?k:c}var Fe=rgzFluidSolve._expr||(rgzFluidSolve._expr={}),dt={abs:Math.abs,sqrt:Math.sqrt,cbrt:Math.cbrt,exp:Math.exp,ln:Math.log,log:Math.log10,pow:Math.pow,min:Math.min,max:Math.max,sin:Math.sin,cos:Math.cos,tan:Math.tan,asin:Math.asin,acos:Math.acos,atan:Math.atan,atan2:Math.atan2,sinh:Math.sinh,cosh:Math.cosh,tanh:Math.tanh,floor:Math.floor,ceil:Math.ceil,round:Math.round,sign:Math.sign,fract:function(c){return c-Math.floor(c)},clamp:function(c,f,k){return c<f?f:c>k?k:c},step:function(c,f){return f>=c?1:0},pulse:function(c,f,k){return c>=f&&c<k?1:0},ramp:function(c,f,k){return k===f?c>=f?1:0:ce((c-f)/(k-f),0,1)},hypot:Math.hypot,deg:function(c){return c*180/Math.PI},rad:function(c){return c*Math.PI/180}};function ct(c){var f=/\s*(?:((?:[0-9]*\.[0-9]+|[0-9]+\.?[0-9]*)(?:[eE][+-]?[0-9]+)?)|([A-Za-z_][A-Za-z0-9_]*)|(<=|>=|==|!=|[-+*/%^(),<>]))/y,k=[],z,P=0;for(f.lastIndex=0;f.lastIndex<c.length;){var N=f.lastIndex;if(z=f.exec(c),!z)throw new Error("token");if(z[1]!==void 0?k.push({n:parseFloat(z[1])}):z[2]!==void 0?k.push({f:z[2].toLowerCase()}):z[3]!==void 0&&k.push({o:z[3]}),f.lastIndex===N||++P>4e3)throw new Error("token")}return k}function M(c){var f=String(c);if(f in Fe)return Fe[f];var k=null;try{let K=function(){return z[P]||null},ee=function(){throw new Error("parse")},ae=function(){var G=H(),le=K();if(le&&le.o&&(le.o==="<"||le.o===">"||le.o==="<="||le.o===">="||le.o==="=="||le.o==="!=")){P++;var I=H();return le.o==="<"?function(ie,Q){return G(ie,Q)<I(ie,Q)?1:0}:le.o===">"?function(ie,Q){return G(ie,Q)>I(ie,Q)?1:0}:le.o==="<="?function(ie,Q){return G(ie,Q)<=I(ie,Q)?1:0}:le.o===">="?function(ie,Q){return G(ie,Q)>=I(ie,Q)?1:0}:le.o==="=="?function(ie,Q){return G(ie,Q)===I(ie,Q)?1:0}:function(ie,Q){return G(ie,Q)!==I(ie,Q)?1:0}}return G},H=function(){for(var G=Y(),le;(le=K())&&le.o&&(le.o==="+"||le.o==="-");){P++;var I=Y();le.o==="+"?function(ie,Q){G=function(J,qe){return ie(J,qe)+Q(J,qe)}}(G,I):function(ie,Q){G=function(J,qe){return ie(J,qe)-Q(J,qe)}}(G,I)}return G},Y=function(){for(var G=me(),le;(le=K())&&le.o&&(le.o==="*"||le.o==="/"||le.o==="%");){P++;var I=me();le.o==="*"?function(ie,Q){G=function(J,qe){return ie(J,qe)*Q(J,qe)}}(G,I):le.o==="/"?function(ie,Q){G=function(J,qe){return Q(J,qe)===0?0:ie(J,qe)/Q(J,qe)}}(G,I):function(ie,Q){G=function(J,qe){var Je=Q(J,qe);return Je===0?0:ie(J,qe)%Je}}(G,I)}return G},me=function(){var G=K();if(G&&G.o==="-"){P++;var le=me();return function(I,ie){return-le(I,ie)}}return G&&G.o==="+"?(P++,me()):Se()},Se=function(){var G=Le(),le=K();if(le&&le.o==="^"){P++;var I=me();return function(ie,Q){var J=Math.pow(G(ie,Q),I(ie,Q));return Number.isFinite(J)?J:0}}return G},Le=function(){var G=K();if(G||ee(),G.n!==void 0){P++;var le=G.n;return function(){return le}}if(G.o==="("){P++;var I=ae(),ie=K();return(!ie||ie.o!==")")&&ee(),P++,I}if(G.f!==void 0){P++;var Q=G.f;if(Q==="t")return function(Nt){return Nt};if(Q==="x")return function(Nt,Vt){return Vt};if(Q==="pi")return function(){return Math.PI};if(Q==="tau")return function(){return 2*Math.PI};if(Q==="e")return function(){return Math.E};{var J=G.f==="if"?function(Nt,Vt,Ar){return Nt?Vt:Ar}:dt[G.f];J||ee();var qe=K();(!qe||qe.o!=="(")&&ee(),P++;var Je=[];if(!(K()&&K().o===")"))for(Je.push(ae());K()&&K().o===",";)P++,Je.push(ae());var yt=K();return(!yt||yt.o!==")")&&ee(),P++,function(Nt,Vt){for(var Ar=new Array(Je.length),Sr=0;Sr<Je.length;Sr++)Ar[Sr]=Je[Sr](Nt,Vt);var Cr=J.apply(null,Ar);return Number.isFinite(Cr)?Cr:0}}ee()}ee()};var z=ct(f),P=0,N=ae();P!==z.length&&ee(),k=function(G,le){var I=N(W(G,0),W(le,0));return Number.isFinite(I)?I:null}}catch{k=null}return Fe[f]=k,k}function b(c,f,k,z){if(!c)return null;var P,N=[],K,ee,ae,H,Y=String(c).trim();if(!Y)return null;var me=/^[-0-9eE,;.\s+]+$/.test(Y)&&Y.indexOf(",")>=0;if(me){for(P=Y.split(/[;\n]+/),K=0;K<P.length;K++)ee=P[K].split(","),ae=parseFloat(ee[0]),H=parseFloat(ee[1]),Number.isFinite(ae)&&Number.isFinite(H)&&N.push([ae,H]);if(N.length){N.sort(function(Q,J){return Q[0]-J[0]});var Se=W(f,0);if(Se<=N[0][0])return N[0][1];if(Se>=N[N.length-1][0])return N[N.length-1][1];for(K=1;K<N.length;K++)if(Se<=N[K][0]){var Le=N[K-1][0],G=N[K][0],le=N[K-1][1],I=N[K][1];return le+(I-le)*(G===Le?0:(Se-Le)/(G-Le))}return N[N.length-1][1]}}var ie=M(Y);return ie?ie(W(k,0),W(z,0)):null}function $e(c,f,k){var z=X.warnProf||(X.warnProf={});z[c]||(z[c]=1,ht.push((f||(k?"Motor":"Cylinder"))+": load profile could not be parsed \u2014 using the constant "+(k?"torque":"load")+". Use 'value, load' points or a formula in t and x, e.g. 800 + 400*sin(2*pi*t)."))}function Ye(c,f,k){var z=String(c.loadMode||"constant");if(z==="time-based"||z==="position-based"||z.indexOf("formula")===0){var P=z==="position-based"?f:at,N=b(c.loadProfile,P,at,f);if(N!=null)return Math.max(0,N);if(String(c.loadProfile||"").trim()){var K=M(String(c.loadProfile).trim());K||$e(k?k.id:"cyl",k&&k.label,!1)}}return Math.max(0,W(c.loadKg,0))}function ge(c,f){var k=String(c.loadMode||"constant");if(k==="time-based"||k==="position-based"||k.indexOf("formula")===0){var z=W(c.simAngle,0)/(2*Math.PI);z=z-Math.floor(z);var P=b(c.loadProfile,k==="position-based"?z:at,at,z);if(P!=null)return P;String(c.loadProfile||"").trim()&&!M(String(c.loadProfile).trim())&&$e(f?f.id:"mot",f&&f.label,!0)}return Math.max(0,W(c.loadNm,0))}var X=rgzFluidSolve._dyn;(!X||W(at,0)<W(X.tNow,0)-1e-9)&&(X=rgzFluidSolve._dyn={t:{},cyl:{},p:{},tNow:0}),X.tNow=at;var Pe=Ce==="air"?-1:-.9,we=Ce==="air"?6e-4:12e-5,pt=1.01325,ht=[],wt=[],Oe=[],D=[],F=[],de=[],E={};De.forEach(function(c){E[c.id]=c});var v={},w=[],ne=[],ve=[];function j(c,f,k){var z=c+"."+f;return z in v?v[z]:k?(v[z]=w.length,w.push(z),ne.push(c),ve.push(f),v[z]):-1}function C(c,f){return j(c,f,!1)}var ue=[];te.forEach(function(c){if(!(!c||c.lineType==="electrical")){var f=E[c.from&&c.from.componentId],k=E[c.to&&c.to.componentId];!f||!k||f.type==="textLabel"||k.type==="textLabel"||(j(c.from.componentId,c.from.portId,!0),j(c.to.componentId,c.to.portId,!0),ue.push(c))}});var O=w.length,oe={};ue.forEach(function(c){var f=c.from.componentId+"."+c.from.portId,k=c.to.componentId+"."+c.to.portId;oe[f]=(oe[f]||0)+1,oe[k]=(oe[k]||0)+1});function Te(c,f){return(oe[c+"."+f]||0)>0}var re=[],U=[];function Me(c,f,k,z,P){if(c<0||f<0||!(k>0))return null;var N={a:c,b:f,g:k,dyn:null,tag:z||"",compId:P||null,flow:0};return re.push(N),N}function se(c,f,k,z,P){if(c<0)return null;var N={a:c,b:f==null?-2:f,g:0,dyn:k,tag:z||"",compId:P||null,flow:0};return re.push(N),N}function Ge(c,f,k,z){if(c<0||!(f>0))return null;var P={a:c,b:-1,g:f,dyn:null,tag:k||"",compId:z||null,flow:0};return re.push(P),P}function tt(c,f,k,z){if(c<0)return null;var P={node:c,q:f,qNow:f,dynQ:null,tag:k||"",compId:z||null};return U.push(P),P}function rt(c){return Math.sqrt(Math.max(c,0))}function ke(c,f){return c/Math.max(rt(Math.abs(f)),.05)}function Ae(c,f,k){return c*rt(Math.max(f,0)+pt)/Math.max(rt(Math.abs(k)),.05)}function Mt(c,f,k){var z=k?k==="air":Ce==="air";return z?c/Math.max(rt(7.013)*rt(f||.3),.05):c/Math.max(rt(f||5),.25)}function Dt(c){var f=c&&c.properties||{},k=Math.max(1.5,W(f.tubeIdMm,Ce==="air"?6:12)),z=ce(W(f.lengthM,1),.05,400),P,N;return Ce==="air"?(P=250,N=.0105*z/Math.pow(k,5.07)*Math.pow(P,1.85)/4,Math.min(P/Math.max(N,.002),3e3)):(P=25,N=.1847*z/Math.pow(k,4)*P+.068*z/Math.pow(k,4.75)*Math.pow(P,1.75),Math.min(P/Math.max(N,.004),350))}function Et(c,f,k,z){var P=Math.max(2,.04*f),N=ce((c-(f-.6))/P,0,1);z&&(z.off=N>0?f-.6:0);var K=Math.max(W(k,60)/8,2);return we*.02+(K-we*.02)*N}var he=Ce==="air"?4e3:400,fe=1e6,et=[],kt=[],Ft=[],He=[],je=[],Be=[],Re=[],xe=[];De.forEach(function(c){var f=c.type;(f==="pumpFixed"||f==="pumpVariable"||f==="compressorFixed"||f==="compressorVariable"||f==="powerPack")&&et.push(c),(f==="reliefValve"||f==="cartridgeReliefValve"||f==="powerPack")&&kt.push(c),(f==="cylinderDA"||f==="cylinderSA")&&Ft.push(c),(f==="hydraulicMotor"||f==="pneumaticMotor")&&He.push(c),f==="accumulator"&&je.push(c),(f==="pressureGauge"||f==="pressureSwitch"||f==="pressureTransducer"||f==="testPoint")&&Be.push(c),(f==="flowMeter"||f==="flowSwitch")&&Re.push(c)});var ot=kt.length?Math.min.apply(null,kt.map(function(c){return W(c.props.settingBar!=null?c.props.settingBar:c.props.reliefSettingBar,160)})):Ce==="air"?8:160;De.forEach(function(c){var f=c.type,k=c.props||{};if(f==="powerPack"){var z=Math.max(0,W(k.flowLpm,25)),P=C(c.id,"P"),N=C(c.id,"T");N>=0&&Ge(N,fe,"tank",c.id),P>=0&&z>0&&tt(P,z,"pump",c.id);var K=W(k.reliefSettingBar,160);P>=0&&se(P,N,function(be,We,mt){return Et(be,K,z,mt)},"relief",c.id);return}if(f==="tank"||f==="exhaust"||f==="breatherFiller"){var ee=C(c.id,"T");ee>=0&&Ge(ee,fe,"tank",c.id);return}if(f==="silencer"){var ae=C(c.id,"E");ae>=0&&Ge(ae,Math.max(1400/(1+W(k.noiseReductionDb,20)/10),15),"silencer",c.id);return}if(f==="pumpFixed"||f==="compressorFixed"){var H=Math.max(0,W(k.flowLpm,25)),Y=C(c.id,"S"),me=C(c.id,"P");if(Y>=0&&Ge(Y,fe,"suction",c.id),me>=0&&H>0){var Se=W(k.maxPressureBar,180),Le=Math.max(1.5,.05*Se),G=tt(me,H,"pump",c.id),le=Se+Le*.4-Le;G.dynQ=function(be){return be>=le?0:H},G.dynS=function(be){return be>=le?-H/Le:0},G.qRef=le+Le}return}if(f==="pumpVariable"||f==="compressorVariable"){var I=Math.max(0,W(k.flowLpm,32)),ie=C(c.id,"S"),Q=C(c.id,"P");if(ie>=0&&Ge(ie,fe,"suction",c.id),Q>=0&&I>0){var J=W(k.compensatorBar,160),qe=Math.max(.06*J,2),Je=tt(Q,I,"pump",c.id);Je.dynQ=function(be){return be>=J-qe?0:I},Je.dynS=function(be){return be>=J-qe?-I/qe:0},Je.qRef=J}return}if(f==="reliefValve"||f==="cartridgeReliefValve"){var yt=W(k.settingBar,160);C(c.id,"P")>=0&&se(C(c.id,"P"),C(c.id,"T"),function(be,We,mt){return Et(be,yt,W(k.maxFlowLpm,120),mt)},"relief",c.id);return}if(f==="cartridgeUnloadingValve"){var Nt=W(k.unloadBar,120),Vt=C(c.id,"X");se(C(c.id,"P"),C(c.id,"T"),function(be,We,mt,nt){var xt=Vt>=0?nt[Vt]:0;return Et(Math.max(be,xt),Nt,W(k.maxFlowLpm,100),mt)},"relief",c.id);return}if(f==="directionalValve"||f==="pneumaticMemoryValve"){Bt(c);return}if(f==="servoValve"){Zt(c);return}if(f==="checkValve"||f==="cartridgeCheckValve"){var Ar=W(k.crackingBar,.5),Sr=c.id;se(C(c.id,"A"),C(c.id,"B"),function(be,We){var mt=X.checkHyst||(X.checkHyst={}),nt=mt[Sr]?1:0;return be>We+Ar?nt=1:be<We+.2*Ar&&(nt=0),mt[Sr]=nt,nt?he*.5:we*.02},"check",c.id);return}if(f==="pilotCheckValve"){var Cr=W(k.crackingBar,1),Cn=Math.max(1,W(k.pilotRatio,3)),an=C(c.id,"X");se(C(c.id,"A"),C(c.id,"B"),function(be,We,mt,nt){if(be>We+Cr)return he*.5;var xt=an>=0?nt[an]:0;return xt>.5&&xt*Cn>We-be+Cr?he*.25:we*.02},"pcheck",c.id);return}if(f==="counterbalanceValve"||f==="cartridgeCounterbalanceValve"){var on=W(k.settingBar,120),$n=Math.max(1,W(k.pilotRatio,3)),sn=C(c.id,"X");se(C(c.id,"A"),C(c.id,"B"),function(be,We,mt,nt){if(be>We)return he*.4;var xt=sn>=0?nt[sn]:0,Pr=ce((We-(on-$n*xt))/Math.max(2,.04*on)+.5,0,1);return we*.02+(he*.2-we*.02)*Pr},"cb",c.id);return}if(f==="flowControl"||f==="cartridgeNeedleFlowValve"){Gt(c);return}if(f==="reducingValve"||f==="cartridgeReducingValve"){var Vn=C(c.id,"P"),ln=C(c.id,"A"),Tn=C(c.id,"T");ln>=0&&F.push({cid:c.id,kind:"red",iP:Vn,iA:ln,ventTo:Tn,set:W(k.outletBar,45),gC:Ce==="air"?60:25,gSup:he*.5,gV:Ce==="air"?8:1.5,qNow:0});return}if(f==="sequenceValve"||f==="cartridgeSequenceValve"){var cn=W(f==="cartridgeSequenceValve"?k.sequenceBar:k.settingBar,70);se(C(c.id,"P"),C(c.id,"A"),function(be){return we+(he*.3-we)*ce((be-cn)/Math.max(2,.05*cn)+.5,0,1)},"seq",c.id);var dn=C(c.id,"T");dn>=0&&Ge(dn,we*5,"drain",c.id);return}if(f==="pressureCompensator"){var En=W(k.deltaPBar,8),pn=C(c.id,"X");se(C(c.id,"P"),C(c.id,"A"),function(be,We,mt,nt){var xt=pn>=0?nt[pn]:We;return he*.3*ce((xt+En-We)/2,0,1)+we},"pc",c.id);return}if(f==="logicCartridgeValve"){var un=C(c.id,"X"),mn=Math.max(1,W(k.pilotRatio,2)),Ur=c.id;se(C(c.id,"A"),C(c.id,"B"),function(be,We,mt,nt){var xt=X.logicHyst||(X.logicHyst={}),Pr=xt[Ur]==null?1:xt[Ur],Pn=un>=0?nt[un]:0,Bn=Math.max(0,be,We);return Pn*mn>Bn+.15?Pr=0:Pn*mn<Bn-.15&&(Pr=1),xt[Ur]=Pr,Pr?he*.6:we*.02},"logic",c.id);return}if(f==="shutoffValve"){Me(C(c.id,"A"),C(c.id,"B"),k.open===!1?we*.02:he*.8,"shutoff",c.id);return}if(f==="cartridgeSolenoidValve22"){var qn=k.energized?!k.normallyOpen:!!k.normallyOpen;Me(C(c.id,"P"),C(c.id,"A"),qn?he*.5:we*.02,"cart22",c.id);return}if(f==="shuttleValve"||f==="cartridgeShuttleValve"||f==="twoPressureValve"){var Nr=f==="twoPressureValve",Dr=C(c.id,"A"),Fr=C(c.id,"B"),Gr=C(c.id,"X");Gr>=0&&(Dr>=0&&se(Dr,Gr,function(be,We,mt,nt){var xt=Fr>=0?nt[Fr]:0;return we+(he-we)*ce(Nr?(xt-be)/.4+.5:(be-xt)/.4+.5,0,1)},Nr?"and":"or",c.id),Fr>=0&&se(Fr,Gr,function(be,We,mt,nt){var xt=Dr>=0?nt[Dr]:0;return we+(he-we)*ce(Nr?(xt-be)/.4+.5:(be-xt)/.4+.5,0,1)},Nr?"and":"or",c.id));return}if(f==="quickExhaustValve"){var $r=C(c.id,"P"),Zr=C(c.id,"A"),Kr=C(c.id,"R");se($r,Zr,function(be,We){return be>=We-.05?he*.7:we},"qe-in",c.id),Kr>=0?(se(Zr,Kr,function(be,We,mt,nt){return be>($r>=0?nt[$r]:0)-.05?he*1.2:we},"qe-out",c.id),Ge(Kr,he*.9,"qe-atm",c.id)):se(Zr,-1,function(be,We,mt,nt){return be>($r>=0?nt[$r]:0)-.05?he*1.2:we},"qe-out",c.id);return}if(f==="softStartValve"){var Vr=C(c.id,"P"),_r=C(c.id,"A"),Qr=C(c.id,"R"),Tr="ss."+c.id;se(Vr,_r,function(be){be>1?Tr in X.t||(X.t[Tr]=at):delete X.t[Tr];var We=Tr in X.t?ce((at-X.t[Tr])/Math.max(.1,W(c.props.rampTimeS,1.5)),0,1):0;return we+he*.6*ce(We,.04,1)},"softstart",c.id),Qr>=0?(se(_r,Qr,function(be,We,mt,nt){return(Vr>=0?nt[Vr]:0)<.5?he*.8:we},"softdump",c.id),Ge(Qr,he*.5,"ss-atm",c.id)):se(_r,-1,function(be,We,mt,nt){return(Vr>=0?nt[Vr]:0)<.5?he*.8:we},"softdump",c.id);return}if(f==="pneumaticTimeDelayValve"){var Er=C(c.id,"P"),Xr=C(c.id,"A"),Wr=C(c.id,"R"),Or="td."+c.id,Yr=function(be){return be>1?Or in X.t||(X.t[Or]=at):delete X.t[Or],be>1&&at-X.t[Or]>=W(c.props.delayS,1)};se(Er,Xr,function(be){return Yr(be)?he*.5:we*2},"tdelay",c.id),Wr>=0?(se(Xr,Wr,function(be,We,mt,nt){return Yr(Er>=0?nt[Er]:0)?we:he*.6},"td-ex",c.id),Ge(Wr,he*.5,"td-atm",c.id)):se(Xr,-1,function(be,We,mt,nt){return Yr(Er>=0?nt[Er]:0)?we:he*.6},"td-ex",c.id);return}if(f==="flowDivider"){var In=ce(W(k.splitPercentA,50),5,95)/100,zr=C(c.id,"P"),qr=C(c.id,"A"),Ir=C(c.id,"B"),hn=Ce==="air"?12:1,Jr=zr>=0?tt(zr,0,"div-in",c.id):null,en=qr>=0?tt(qr,0,"div-a",c.id):null,tn=Ir>=0?tt(Ir,0,"div-b",c.id):null;zr>=0&&qr>=0&&Me(zr,qr,hn,"div-primer",c.id),zr>=0&&Ir>=0&&Me(zr,Ir,hn,"div-primer",c.id),X.div||(X.div={}),de.push({cid:c.id,iP:zr,iA:qr,iB:Ir,sA:In,sIn:Jr,sA1:en,sB1:tn,qIn:X.div[c.id]||0,qMax:5,inc:null}),Jr&&(Jr.divTag=1),en&&(en.divTag=1),tn&&(tn.divTag=1);return}if(f==="filter"||f==="cooler"||f==="suctionStrainer"||f==="oilHeater"||f==="flowMeter"||f==="flowSwitch"){Me(C(c.id,"A"),C(c.id,"B"),Ce==="air"?900:90,"passive",c.id);return}if(f==="junction"||f==="compressedAirDistributor"){for(var Hr=[],jr=0;jr<O;jr++)ne[jr]===c.id&&Hr.push(jr);for(var rn=1;rn<Hr.length;rn++)Me(Hr[0],Hr[rn],2e4,"junction",c.id);return}if(f==="cartridgeManifoldBlock"){var fn=C(c.id,"P"),vn=C(c.id,"A"),gn=C(c.id,"T"),yn=C(c.id,"B");fn>=0&&vn>=0&&Me(fn,vn,he*.8,"manifoldPA",c.id),gn>=0&&yn>=0&&Me(gn,yn,he*.8,"manifoldTB",c.id);return}if(f==="valveTerminal"){var bn=C(c.id,"P"),Mn=C(c.id,"R");["A1","A2","A3","A4"].forEach(function(be){var We=C(c.id,be);bn>=0&&We>=0&&Me(bn,We,he*.5,"vt-supply",c.id)}),["B1","B2","B3","B4"].forEach(function(be){var We=C(c.id,be);Mn>=0&&We>=0&&Me(Mn,We,he*.5,"vt-exhaust",c.id)});return}if(f==="frlUnit"){var Rn=C(c.id,"P"),xn=C(c.id,"A");xn>=0&&F.push({cid:c.id,kind:"frl",iP:Rn,iA:xn,ventTo:-1,set:W(k.regulatorBar,6),gC:80,gSup:1500,gV:12,qNow:0});return}if(f==="accumulator"){var wn=C(c.id,"A");if(wn>=0){var Rr=Math.max(.2,W(k.volumeL,5)),Nn=Math.max(0,W(k.prechargeBar,70)),kn=ce(W(k.simChargeL,0),0,Rr*.98),Dn=Nn*(Rr/Math.max(Rr-kn,.05*Rr));D.push({comp:c,iA:wn,g:Ce==="air"?150:15,pAcc:Dn,stored:kn,V0:Rr})}return}if(f==="hydraulicIntensifier"){var Fn=Math.max(1.1,W(k.ratio,2));Me(C(c.id,"P"),C(c.id,"A"),he*.04,"intens",c.id),wt.push({iP:C(c.id,"P"),iA:C(c.id,"A"),rt:Fn});var An=C(c.id,"T");An>=0&&Ge(An,he*.4,"intensT",c.id);return}if(f==="vacuumEjector"){var On=C(c.id,"P"),Sn=C(c.id,"V"),nn=C(c.id,"R"),Hn=W(k.airConsumptionLpm,90);se(On,nn,function(be){return Ae(Mt(Hn,5.5),Math.max(be,0),Math.abs(be))},"eject",c.id),nn>=0&&Ge(nn,he*.6,"eject-atm",c.id),Sn>=0&&Oe.push({iV:Sn,vac:W(k.vacuumKpa,-65)/100,g:he*.4});return}if(f==="suctionCup"){var zn=C(c.id,"V");zn>=0&&Ge(zn,Math.max(we*60,.02),"cup-leak",c.id);return}if(f==="airBlowNozzle"){var Ln=C(c.id,"P");Ln>=0&&Ge(Ln,Ae(Mt(W(k.flowLpm,120),6),6,6),"nozzle",c.id);return}if(f==="hydraulicMotor"||f==="pneumaticMotor"){var jn=Math.max(1,W(k.displacementCcRev,25)),Un=Ce==="air"?0:Math.max(0,ge(k,c))*20*Math.PI/jn,Lr={id:c.id,iA:C(c.id,"A"),iB:C(c.id,"B"),locked:!1};if(xe.push(Lr),Lr.iA<0||Lr.iB<0)return;se(Lr.iA,Lr.iB,function(be,We,mt){return Lr.locked?(mt.off=0,we*.02):(mt.off=Un,Ce==="air"?500:30)},"motor",c.id);return}});function Gt(c){var f=c.props||{},k=ce(W(f.openingPercent,65),0,100)/100,z=W(f.maxFlowLpm,0)||(Ce==="air"?600:60),P=C(c.id,"A"),N=C(c.id,"B");if(!(P<0||N<0)){var K=Ce==="air"?z/rt(7.013):z,ee=K*Math.pow(Math.max(k,.004),1.6);if(!f.pressureCompensated){se(P,N,function(H,Y){var me=Math.abs(H-Y);return Ce==="air"?Ae(ee,Math.max(H,Y),me):ke(ee,me)},"fc",c.id);return}var ae=z*k;se(P,N,function(H,Y){var me=Math.abs(H-Y);return me<3?Ce==="air"?Ae(ee,Math.max(H,Y),me):ke(ee,me):ae/me},"fc-pc",c.id)}}function Bt(c){var f=c.props||{},k=String(f.spoolState||"center"),z=String(f.ports||"4"),P=Mt(W(f.ratedFlowLpm,40),Math.max(.1,W(f.pressureDropBar,5))),N=Ce==="air"?Ae(P,6,.3):ke(P,1.5),K=Math.max(N*.002,we),ee=C(c.id,"P"),ae=C(c.id,"T"),H=C(c.id,"A"),Y=C(c.id,"B"),me=C(c.id,"R"),Se=C(c.id,"S");function Le(J){return J}Ce==="air"&&(ae>=0&&!Te(c.id,"T")&&Ge(ae,N*1.5,"dcv-exh",c.id),me>=0&&!Te(c.id,"R")&&Ge(me,N*1.5,"dcv-exh",c.id),Se>=0&&!Te(c.id,"S")&&Ge(Se,N*1.5,"dcv-exh",c.id));var G=c.type==="pneumaticMemoryValve",le=[];if(G)k==="left"?le=[[ee,H],[Y,Se>=0?Se:me]]:le=[[ee,Y],[H,me>=0?me:Se]];else if(z==="2")k==="left"&&(le=[[ee,H]]);else if(z==="3")le=k==="left"?[[ee,H]]:[[H,ae]];else{var I=function(J,qe){var Je=String(J||qe);return Je==="parallel"?[[ee,H],[Y,ae]]:Je==="crossover"?[[ee,Y],[H,ae]]:Je==="open"?[[ee,ae],[H,ae],[Y,ae]]:Je==="tandem"?[[ee,ae]]:Je==="float"?[[H,ae],[Y,ae]]:Je==="regenerative"?[[ee,H],[Y,H]]:[]};k==="left"?le=I(f.leftBlock,"parallel"):k==="right"?le=I(f.rightBlock,"crossover"):le=I(f.center,"closed")}le.forEach(function(J){J[0]>=0&&J[1]>=0?se(J[0],J[1],function(qe,Je){var yt=Math.abs(qe-Je);return Ce==="air"?Ae(P,Math.max(qe,Je),yt):ke(P,yt)},"dcv",c.id):Ce==="air"&&J[0]>=0&&J[1]<0&&Ge(J[0],N,"dcv-exh2",c.id)});var ie=C(c.id,"X"),Q=C(c.id,"Y");ie>=0&&Ge(ie,we*4,"pilotvent",c.id),Q>=0&&Ge(Q,we*4,"pilotvent",c.id)}function Zt(c){var f=c.props||{},k=ce(W(f.commandPercent,0),-100,100),z=C(c.id,"P"),P=C(c.id,"T"),N=C(c.id,"A"),K=C(c.id,"B"),ee=Mt(W(f.ratedFlowLpm,40),5),ae=Math.abs(k)<3?0:Math.abs(k)/100,H=Ce==="air"?Ae(ee*ae,6,.3):ke(ee*ae,1.5),Y=Math.max(H*.002,we);if(ae>0){var me=ee*ae,Se=k>0?[[z,N],[K,P]]:[[z,K],[N,P]];Se.forEach(function(Le){Le[0]>=0&&Le[1]>=0&&se(Le[0],Le[1],function(G,le){var I=Math.abs(G-le);return Ce==="air"?Ae(me,Math.max(G,le),I):ke(me,I)},"servo",c.id)})}}var Ct=[];ue.forEach(function(c){var f=C(c.from.componentId,c.from.portId),k=C(c.to.componentId,c.to.portId);if(!(f<0||k<0)){var z=Me(f,k,Dt(c),"line",null);z&&(z.lineId=c.id,z.lineProps=c.properties||{},Ct.push(z))}});var it=Ft.map(function(c){var f=c.props||{},k=Math.max(8,W(f.boreMm,50))/1e3,z=c.type==="cylinderDA"?ce(W(f.rodMm,36),0,.95*k*1e3)/1e3:0,P=Math.PI*k*k/4,N=c.type==="cylinderDA"?Math.max(.2*P,P-Math.PI*z*z/4):0,K=Math.max(20,W(f.strokeMm,300)),ee=ce(W(f.simPosition,.2),0,1),ae=Ye(f,ee,c)*9.81,H=X.cyl[c.id]||(X.cyl[c.id]={q:0});return{comp:c,Aa:P,Ab:N,stroke:K,P:f,Fload:ae,iA:C(c.id,"A"),iB:C(c.id,"B"),pos:ee,st:H,q:H.q||0,starving:!1,v:0,pA:0,pB:0,force:0,qA:0,qB:0,dir:0}});(function(){var c={};it.forEach(function(k){c[k.comp.id]=1});for(var f in X.cyl)f in c||delete X.cyl[f]})();for(var pe=new Float64Array(O),qt=0;qt<O;qt++)pe[qt]=W(X.p[w[qt]],0);var Ze=new Float64Array(O*O),lt=new Float64Array(O),ar=null;function Kt(){Ze.fill(0),lt.fill(0);var c,f,k;for(c=0;c<re.length;c++)f=re[c],f.dyn&&(f.off=0),k=f.dyn?f.dyn(pe[f.a]||0,f.b>=0?pe[f.b]:0,f,pe)||0:f.g,k=Math.max(k,1e-12),f.dyn&&(f.gD>0?f.gD=Math.sqrt(f.gD*k):f.gD=k,k=f.gD),f.gNow=k,f.b===-1?(Ze[f.a*O+f.a]+=f.gNow,f.off&&(lt[f.a]+=f.gNow*f.off)):f.b>=0&&(Ze[f.a*O+f.a]+=f.gNow,Ze[f.b*O+f.b]+=f.gNow,Ze[f.a*O+f.b]-=f.gNow,Ze[f.b*O+f.a]-=f.gNow,f.off&&(lt[f.a]+=f.gNow*f.off,lt[f.b]-=f.gNow*f.off));for(c=0;c<U.length;c++){var z=U[c],P=pe[z.node]||0,N=z.dynQ?z.dynQ(P):z.q;z.qNow=N||0;var K=z.dynS&&z.dynS(P)||0;if(Math.abs(K)>1e-9){var ee=z.qRef!=null?-K*z.qRef:z.qNow-K*P;Ze[z.node*O+z.node]+=-K,lt[z.node]+=ee,z.qNow=Math.max(-K*((z.qRef!=null?z.qRef:0)-P),0)}else lt[z.node]+=z.qNow}for(c=0;c<D.length;c++){var ae=D[c],P=pe[ae.iA]||0,H=P>ae.pAcc||ae.stored>.005*ae.V0||Ce==="air"&&ae.pAcc<=0,Y=H?ae.g:we;Ze[ae.iA*O+ae.iA]+=Y,lt[ae.iA]+=Y*ae.pAcc,ae.gNow=Y}for(c=0;c<wt.length;c++){var me=wt[c];if(!(me.iA<0)){var Se=he*.03,Le=me.rt*(me.iP>=0?pe[me.iP]:0);Ze[me.iA*O+me.iA]+=Se,lt[me.iA]+=Se*Le}}for(c=0;c<Oe.length;c++){var G=Oe[c],le=(pe[G.iV]||0)>G.vac?G.g:we;Ze[G.iV*O+G.iV]+=le,lt[G.iV]+=le*G.vac}for(c=0;c<F.length;c++){var I=F[c];if(!(I.iA<0)){var ie=I.iP>=0&&pe[I.iP]||0,Q=pe[I.iA]||0,J=I.gC*(I.set-Q),qe=I.gSup*Math.max(ie-Q,0),Je=I.gV*Math.max(Q,0),yt=I.mode||"band";if(Q>ie+.5?yt!=="vent"&&(yt="vent"):yt==="band"?J>1.25*qe?yt="cap":J<-1.25*Je&&(yt="vent"):yt==="cap"?J<.8*qe&&(yt="band"):yt==="vent"&&J>-.8*Je&&(yt="band"),I.mode=yt,yt==="cap"&&I.iP>=0)Ze[I.iA*O+I.iA]+=I.gSup,Ze[I.iP*O+I.iP]+=I.gSup,Ze[I.iA*O+I.iP]-=I.gSup,Ze[I.iP*O+I.iA]-=I.gSup,I.qNow=qe;else if(yt==="vent"){var Nt=I.set+.4;Q>Nt-.6?(Ze[I.iA*O+I.iA]+=I.gV,lt[I.iA]+=I.gV*Nt,I.ventTo>=0&&(Ze[I.ventTo*O+I.ventTo]+=I.gV,Ze[I.iA*O+I.ventTo]-=I.gV,Ze[I.ventTo*O+I.iA]-=I.gV,lt[I.ventTo]-=I.gV*Nt),I.qNow=-I.gV*Math.max(Q-(I.ventTo>=0&&pe[I.ventTo]||0)-Nt,0)):I.qNow=0}else Ze[I.iA*O+I.iA]+=I.gC,lt[I.iA]+=I.gC*I.set,J>0&&I.iP>=0?(Ze[I.iP*O+I.iA]-=I.gC,lt[I.iP]-=I.gC*I.set):J<0&&I.ventTo>=0&&(Ze[I.ventTo*O+I.iA]-=I.gC,lt[I.ventTo]-=I.gC*I.set),I.qNow=J}}for(c=0;c<O;c++)Ze[c*O+c]+=we;for(c=0;c<it.length;c++){var Vt=it[c];Vt.iA>=0&&(lt[Vt.iA]-=Vt.qA||0),Vt.iB>=0&&(lt[Vt.iB]-=Vt.qB||0)}}var $t=null,Ie=null;function Ue(){var c=O,f=Ze,k=lt,z,P,N,K,ee;for(rgzFluidSolve._trace&&!$t&&($t=Float64Array.from(Ze),Ie=Float64Array.from(lt)),N=0;N<c;N++){var ae=N,H=Math.abs(f[N*c+N]);for(z=N+1;z<c;z++){var Y=Math.abs(f[z*c+N]);Y>H&&(H=Y,ae=z)}if(H<1e-12&&(f[N*c+N]=1e-12,H=1e-12),ae!==N){for(P=N;P<c;P++)ee=f[N*c+P],f[N*c+P]=f[ae*c+P],f[ae*c+P]=ee;ee=k[N],k[N]=k[ae],k[ae]=ee}for(z=N+1;z<c;z++)if(K=f[z*c+N]/f[N*c+N],K!==0){for(P=N;P<c;P++)f[z*c+P]-=K*f[N*c+P];k[z]-=K*k[N]}}for(z=c-1;z>=0;z--){var me=k[z];for(P=z+1;P<c;P++)me-=f[z*c+P]*pe[P];pe[z]=me/f[z*c+z],Number.isFinite(pe[z])||(pe[z]=0)}if(rgzFluidSolve._trace&&$t){var Se=0,Le=-1;for(z=0;z<c;z++){var G=-Ie[z];for(P=0;P<c;P++)G+=$t[z*c+P]*pe[P];Math.abs(G)>Se&&(Se=Math.abs(G),Le=z)}console.log("  solve residual max",Se.toExponential(2),"at node",w[Le],"p=",pe[Le].toFixed(2)),$t=null,Ie=null}}var Xe=Ce==="air"?25:1e3;(function(){var c=[];if(kt.length&&c.push(ot+20),et.forEach(function(k){var z=W(k.props.maxPressureBar,0),P=W(k.props.compensatorBar,0)||W(k.props.reliefSettingBar,0),N=Math.max(z,P);N>0&&c.push(N+15)}),c.length&&(Xe=Math.min(Xe,Math.min.apply(null,c))),Ce!=="air"){var f=1;it.forEach(function(k){k.Ab>0&&(f=Math.max(f,Math.min(5,k.Aa/k.Ab)))}),f>1.01&&(Xe=Math.min(1200,Math.ceil(Xe*f*1.05)))}})();function Ee(){for(var c=0;c<it.length;c++){var f=it[c];f.iA>=0&&(f.qA||0)>0&&pe[f.iA]<Pe&&(pe[f.iA]=Pe),f.iB>=0&&(f.qB||0)>0&&pe[f.iB]<Pe&&(pe[f.iB]=Pe)}for(c=0;c<O;c++)pe[c]<Pe-.5?pe[c]=Pe-.5:pe[c]>Xe&&(pe[c]=Xe)}function Ke(){for(var c=0;c<re.length;c++){var f=re[c],k=pe[f.a]||0,z=(f.b>=0?pe[f.b]:0)+(f.off||0);f.flow=f.gNow*(k-z)}for(c=0;c<D.length;c++){var P=D[c];P.flow=(P.gNow||0)*((pe[P.iA]||0)-P.pAcc)}}function st(c){var f=c?14:30,k=null,z,P;for(z=0;z<f;z++){if(Kt(),Ue(),Ee(),k){P=0;for(var N=0;N<O;N++)P=Math.max(P,Math.abs(pe[N]-k[N]));if(P<.005&&z>=8)break}k=Float64Array.from(pe)}Ke()}var Yt=2e-5;function Jt(c){if(c<0)return!1;for(var f={},k=[c],z=0;k.length&&z++<4*(O+re.length+8);){var P=k.pop();if(P===-2)return!0;if(!f[P]){f[P]=1;for(var N=0;N<re.length;N++){var K=re[N],ee=K.gNow!=null?K.gNow:K.g;if(K.b===-1&&K.a===P&&ee>Yt&&K.tag!=="cyl-dem")return!0;ee<=Yt||(K.a===P&&K.b>=0&&!f[K.b]?k.push(K.b):K.b===P&&K.a>=0&&!f[K.a]&&k.push(K.a))}for(var ae=0;ae<U.length;ae++)if(U[ae].node===P&&(U[ae].q||0)>.01)return!0;for(var H=0;H<F.length;H++){var Y=F[H];Y.iA===P?(Y.iP>=0&&k.push(Y.iP),Y.ventTo>=0&&k.push(Y.ventTo)):(Y.iP===P||Y.ventTo===P)&&k.push(Y.iA)}for(var me=0;me<D.length;me++)D[me].iA===P&&k.push(-2)}}return!1}function xr(c){var f=c.iA>=0?Jt(c.iA):!1;if(c.Ab<=0)return!f;var k=c.iB>=0?Jt(c.iB):!1;return!(f&&k)}function gr(c,f){var k={ground:!1,q:0,both:!1};if(c<0)return k;for(var z={},P=[c],N=0,K={};P.length&&N++<4*(O+re.length+8);){var ee=P.pop();if(ee===-2){k.ground=!0;continue}if(ee===f&&f>=0&&(k.both=!0),!z[ee]){z[ee]=1;for(var ae=0;ae<re.length;ae++){var H=re[ae],Y=H.gNow!=null?H.gNow:H.g;if(H.b===-1&&H.a===ee&&Y>Yt&&H.tag!=="cyl-dem"){k.ground=!0;continue}Y<=Yt||H.tag!=="div-primer"&&(H.a===ee&&H.b>=0&&!z[H.b]?P.push(H.b):H.b===ee&&H.a>=0&&!z[H.a]&&P.push(H.a))}for(var me=0;me<U.length;me++){var Se=U[me];Se.node===ee&&!K[me]&&(Se.q||0)>.01&&(K[me]=1,k.q+=Se.q)}for(var Le=0;Le<F.length;Le++){var G=F[Le];G.iA===ee?(G.iP>=0&&!z[G.iP]&&P.push(G.iP),G.ventTo>=0&&!z[G.ventTo]&&P.push(G.ventTo)):(G.iP===ee||G.ventTo===ee)&&G.iA>=0&&!z[G.iA]&&P.push(G.iA)}for(var le=0;le<D.length;le++)D[le].iA===ee&&P.push(-2)}}return k}function St(c){var f=c.iA>=0?pe[c.iA]:0,k=c.iB>=0?pe[c.iB]:0;c.pA=f,c.pB=k;var z=c.comp.type==="cylinderSA"&&c.P.springReturn!==!1?250+700*c.pos*c.stroke/500:0;return 1e5*(f*c.Aa-k*c.Ab)-c.Fload-z}function ft(c,f){var k=f,z=c.Ab>0?-f*(c.Ab/c.Aa):0;Ce==="air"&&(k*=Math.max(((c.iA>=0?pe[c.iA]:0)+pt)/pt,.05),z*=Math.max(((c.iB>=0?pe[c.iB]:0)+pt)/pt,.05)),c.qA=k,c.qB=z,c.q=f}function Ot(c){if(c.iA<0&&c.iB<0){ft(c,0),c.v=0,c.force=0;return}ft(c,0);var f=0;U.forEach(function(Je){Je.tag==="pump"&&(f+=Math.max(Je.qNow||0,0))});var k=Math.max(Ce==="air"?300:40,3.2*Math.max(f,1)),z=k,P=k,N=gr(c.iA,c.iB);if(!N.ground&&!N.both&&(z=Math.min(k,Math.max(N.q,.05))),c.Ab>0){var K=gr(c.iB,c.iA);!K.ground&&!K.both&&(P=Math.min(k,Math.max(K.q*(c.Aa/c.Ab),.05)))}c.divA&&c.divA.dv.qIn<-.05&&(P=Math.min(P,Math.max(-c.divA.dv.qIn*c.divA.s,.05))),c.divB&&c.divB.dv.qIn<-.05&&(z=Math.min(z,Math.max(-c.divB.dv.qIn*c.divB.s*(c.Ab>0?c.Aa/c.Ab:1),.05)));var ee=c.pos>=.999,ae=c.pos<=.001;st();var H=St(c),Y=Math.max(45,.02*Math.max(c.Fload,1)),me=xr(c);if(rgzFluidSolve._trace&&c.comp.id===rgzFluidSolve._trace&&console.log(" root start f0=",H.toFixed(0),"pA=",c.pA.toFixed(2),"atTop",ee,"pos",c.pos,"locked",me),me||Math.abs(H)<=Y||H>Y&&ee||H<-Y&&ae&&(c.Ab>0||c.comp.type==="cylinderSA")){ft(c,0),c.v=0,c.dir=0,c.force=H,c.starving=!1,st(),c.force=St(c);return}var Se,Le,G,le;if(H>Y){if(Se=0,Le=z,G=H,ft(c,Le),st(),le=St(c),le>0){ft(c,Le),st(),c.force=St(c),c.v=c.q/6e4/c.Aa*1e3,c.dir=1,c.starving=!1;return}}else if(Le=0,Se=-P,le=H,ft(c,Se),st(),G=St(c),G<0){ft(c,Se),st(),c.force=St(c),c.v=c.q/6e4/c.Aa*1e3,c.dir=-1,c.starving=!1;return}for(var I=0;I<24;I++){var ie=.5*(Se+Le);ft(c,ie),st();var Q=St(c);if(rgzFluidSolve._trace&&c.comp.id===rgzFluidSolve._trace&&console.log(" bisect it",I,"q=",ie.toFixed(2),"pA=",c.pA.toFixed(2),"pB=",c.pB.toFixed(2),"F=",Q.toFixed(0)),Math.abs(Q)<=Y||(Q>0?Se=ie:Le=ie,Math.abs(Le-Se)<.02))break}st(),c.force=St(c);var J=c.q/6e4/c.Aa*1e3;c.q<0&&c.Ab>0&&(J=c.q*(c.Ab/c.Aa)/6e4/c.Ab*1e3),c.v=J,c.dir=c.q>.02?1:c.q<-.02?-1:0;var qe=c.q>0?c.pA:c.pB;c.starving=Math.abs(c.q)>1&&qe<=Pe+.25,c.st.q=c.q}if(de.length){var Ht=0;U.forEach(function(c){c.divTag||(Ht+=Math.max(c.q||0,0))});for(var Tt=0;Tt<de.length;Tt++){var Ne=de[Tt];Ne.qMax=Math.max(2.5*Ht,8),(!(Ne.cid in(X.div||{}))||!Ne.qIn)&&(Ne.qIn=ce(Math.min(Ht,10),0,Ne.qMax)),Ne.sIn&&(Ne.sIn.q=-Ne.qIn),Ne.sA1&&(Ne.sA1.q=Ne.qIn*Ne.sA),Ne.sB1&&(Ne.sB1.q=Ne.qIn*(1-Ne.sA));for(var It=0;It<2;It++){var Rt=It===0?Ne.iA:Ne.iB,ir=It===0?Ne.sA:1-Ne.sA;if(!(Rt<0))for(var yr=0;yr<re.length;yr++){var or=re[yr],_t=or.a===Rt?or.b:or.b===Rt?or.a:-1;if(!(_t<0||ne[_t]===Ne.cid))for(var sr=0;sr<it.length;sr++){var zt=it[sr];if(zt.comp.id===ne[_t]){var er={dv:Ne,s:ir};zt.iA===_t?(zt.divA=er,zt.Ab>0&&(Ne.rMin=Math.min(Ne.rMin||1,zt.Ab/zt.Aa))):zt.iB===_t&&(zt.divB=er)}}}}Ne.qMaxComb=Ne.rMin?Math.min(Ne.qMax,.92*Ht/Ne.rMin):Ne.qMax}}st();for(var Br=it.length>1?3:2,lr=0;lr<Br;lr++){rgzFluidSolve._trace&&console.log(" -- outer round",lr);for(var cr=0;cr<xe.length;cr++){var Qt=xe[cr];Qt.locked=!(Qt.iA>=0&&Qt.iB>=0&&Jt(Qt.iA)&&Jt(Qt.iB))}for(var dr=0;dr<it.length;dr++)Ot(it[dr])}st();for(var tr=0;tr<3;tr++){for(var ut=0;ut<re.length;ut++)re[ut].gD=0;st()}for(var pr=0;pr<de.length;pr++){var ye=de[pr];if(!(ye.iP<0)){if(!ye.inc){ye.inc=[];for(var Xt=0;Xt<re.length;Xt++){var ur=re[Xt],Wt=ur.a===ye.iP?ur.b:ur.b===ye.iP?ur.a:-99;Wt>-99&&(Wt<0||ne[Wt]!==ye.cid)&&ye.inc.push(ur)}}for(var vt=0,mr=0;mr<ye.inc.length;mr++){var hr=ye.inc[mr];vt+=hr.b===ye.iP?hr.flow||0:-(hr.flow||0)}if(Math.abs(vt)<.03&&(vt=0),!ye.fwd||ye.qOffT!==at){for(var br=0,rr=!1,At={},gt=[ye.iP],wr=0,Mr={};gt.length&&wr++<4*(O+re.length+8);){var Lt=gt.pop();if(Lt===-2){rr=!0;continue}if(!At[Lt]){At[Lt]=1;for(var _=0;_<re.length;_++){var Pt=re[_],kr=Pt.gNow!=null?Pt.gNow:Pt.g;kr<.001||Pt.tag!=="div-primer"&&(Pt.a===Lt&&Pt.b>=0&&!At[Pt.b]?gt.push(Pt.b):Pt.b===Lt&&Pt.a>=0&&!At[Pt.a]&&gt.push(Pt.a))}for(var bt=0;bt<U.length;bt++){var jt=U[bt];jt.node===Lt&&!Mr[bt]&&!jt.divTag&&(jt.q||0)>.01&&(Mr[bt]=1,br+=jt.q)}for(var fr=0;fr<F.length;fr++){var _e=F[fr];_e.iA===Lt?(_e.iP>=0&&!At[_e.iP]&&gt.push(_e.iP),_e.ventTo>=0&&!At[_e.ventTo]&&gt.push(_e.ventTo)):(_e.iP===Lt||_e.ventTo===Lt)&&_e.iA>=0&&!At[_e.iA]&&gt.push(_e.iA)}for(var vr=0;vr<D.length;vr++)D[vr].iA===Lt&&gt.push(-2)}}ye.qOff=rr?ye.qMax:br,ye.qOffT=at}var ze;if(vt<-1&&ye.qIn>=-.05&&(ye.qIn=-Math.min(3,ye.qMax)),ye.qIn<-.05||Math.abs(ye.qIn)<=.05&&vt<-.5){var Ve=ye.qMaxComb||ye.qMax;ze=vt,ye.qIn<-.05&&-vt>=.95*-ye.qIn&&(ze=-Math.min(Ve,Math.max(-vt,-ye.qIn*1.5)))}else{var nr=Math.min(ye.qOff||0,ye.qMax);nr>.05?ze=vt>=.95*ye.qIn?Math.min(nr,Math.max(vt,ye.qIn*1.5)):Math.max(vt,0):ze=0}ye.qIn=ce(.5*ye.qIn+.5*ce(ze,-ye.qMax,ye.qMax),-ye.qMax,ye.qMax),Math.abs(ye.qIn)<.2&&(ye.qOff||0)>1&&vt>-.5&&(ye.qIn=Math.min(ye.qOff,ye.qMax,1.5)),X.div&&(X.div[ye.cid]=ye.qIn),ye.sIn&&(ye.sIn.q=-ye.qIn),ye.sA1&&(ye.sA1.q=ye.qIn*ye.sA),ye.sB1&&(ye.sB1.q=ye.qIn*(1-ye.sA))}}for(var Ut=0;Ut<it.length;Ut++)it[Ut].force=St(it[Ut]);for(var e=0;e<O;e++)X.p[w[e]]=pe[e];var t={};Be.forEach(function(c){var f=C(c.id,"P");t[c.id]={pressureBar:f>=0?ce(pe[f],Pe,Xe):0,flowLpm:0}}),Re.forEach(function(c){for(var f=0,k=0;k<re.length;k++){var z=re[k];z.compId===c.id&&z.tag==="passive"&&(f=Math.abs(z.flow))}var P=C(c.id,"A");t[c.id]={pressureBar:P>=0?ce(pe[P],Pe,Xe):0,flowLpm:f}}),kt.forEach(function(c){if(c.type!=="powerPack"){var f=C(c.id,"P");t[c.id]={pressureBar:f>=0?ce(pe[f],Pe,Xe):0,flowLpm:0}}}),De.forEach(function(c){var f=c.type;if(f==="powerPack"||f==="pumpFixed"||f==="pumpVariable"||f==="compressorFixed"||f==="compressorVariable"){for(var k=C(c.id,"P"),z=0,P=0;P<U.length;P++){var N=U[P];N.compId===c.id&&N.tag==="pump"&&(z=Math.max(N.qNow||0,0))}t[c.id]={pressureBar:k>=0?ce(pe[k],Pe,Xe):0,flowLpm:z}}if(f==="flowControl"||f==="cartridgeNeedleFlowValve"||f==="checkValve"||f==="cartridgeCheckValve"||f==="pilotCheckValve"){for(var K=0,ee=0,ae=0;ae<re.length;ae++){var H=re[ae];H.compId===c.id&&H.b>=0&&(H.tag==="fc"||H.tag==="fc-pc"||H.tag==="check"||H.tag==="pcheck")&&(K=H.flow,ee=Math.abs(pe[H.a]-pe[H.b]))}var Y=C(c.id,"A");t[c.id]={flowLpm:Math.abs(K),deltaPBar:ee,pressureBar:Y>=0?ce(pe[Y],Pe,Xe):0}}if(f==="reducingValve"||f==="cartridgeReducingValve"||f==="frlUnit"){var me=C(c.id,"A"),Se=C(c.id,"P");t[c.id]={pressureBar:me>=0?ce(pe[me],Pe,Xe):0,inletBar:Se>=0?ce(pe[Se],Pe,Xe):0}}if(f==="reliefValve"||f==="cartridgeReliefValve"){for(var Le=0,G=0;G<re.length;G++){var le=re[G];le.compId===c.id&&le.tag==="relief"&&(Le=Math.max(le.flow,0))}t[c.id]&&(t[c.id].flowLpm=Le)}if(f==="directionalValve"||f==="servoValve"||f==="pneumaticMemoryValve"){var I=C(c.id,"A"),ie=C(c.id,"P");t[c.id]={pressureBar:I>=0?ce(pe[I],Pe,Xe):0,supplyBar:ie>=0?ce(pe[ie],Pe,Xe):0}}if(f==="accumulator")for(var Q=0;Q<D.length;Q++)D[Q].comp.id===c.id&&(t[c.id]={pressureBar:ce(pe[D[Q].iA]||0,Pe,Xe),flowLpm:D[Q].flow||0})});var n=it.map(function(c){return{id:c.comp.id,label:c.comp.label||c.comp.id,speedMmS:c.v,forceKN:Math.abs(c.force)/1e3,pressureBar:Math.max(c.dir>=0?c.pA:c.pB,0),loadKg:Ye(c.P,c.pos,c.comp)}}),i=He.map(function(c){for(var f=C(c.id,"A"),k=C(c.id,"B"),z=0,P=0;P<re.length;P++){var N=re[P];N.compId===c.id&&N.tag==="motor"&&(z=N.flow)}var K=Math.max(1,W(c.props.displacementCcRev,25)),ee=f>=0?pe[f]:0,ae=k>=0?pe[k]:0,H=Math.abs(z)>.02?1e3*Math.abs(z)/K:0,Y=Math.abs(ee-ae)*K/20/Math.PI,me=ee>=ae?1:-1,Se=ge(c.props,c);return t[c.id]={pressureBar:ce(ee-ae,-Xe,Xe),flowLpm:Math.abs(z),rpm:H,torqueNm:Y,loadNm:Se},{id:c.id,label:c.label||c.id,flowLpm:Math.abs(z),rpm:me*H,torqueNm:Y,loadNm:Se}}),a=Ct.map(function(c){var f=c.flow,k=Math.max(1.5,W(c.lineProps.tubeIdMm,Ce==="air"?6:12)),z=Math.PI*Math.pow(k/1e3,2)/4,P=z>0?Math.abs(f)/6e4/z:0,N=Math.max(pe[c.a],pe[c.b]),K=Ce==="air"?25:W(c.lineProps.tubeIdMm,12)<8?4.5:6;return P>K&&ht.push((c.lineId||"line")+" velocity is high ("+P.toFixed(1)+" m/s)."),{id:c.lineId,velocityMps:P,flowLpm:f,active:Math.abs(f)>.15,high:N>.8*ot,pressureBar:N}}),l=0,r=0,d=0;et.forEach(function(c){l+=W(c.props.flowLpm,0);var f=C(c.id,"P");if(f>=0){r=Math.max(r,pe[f]);for(var k=0;k<U.length;k++){var z=U[k];z.compId===c.id&&z.tag==="pump"&&(d+=Math.max(z.qNow||0,0))}}});for(var p=0,y=0;y<O;y++)p=Math.max(p,pe[y]);for(var o=r>0?r:p,g=d*Math.max(o,0)/600,u=0,h=0;h<re.length;h++){var m=re[h];u+=Math.abs(m.flow)*Math.abs((pe[m.a]||0)-(m.b>=0?pe[m.b]:0))/600}var s=De.filter(function(c){return c.type==="tank"||c.type==="powerPack"}),L=s.length?s.reduce(function(c,f){return c+W(f.props.oilTempC,40)},0)/s.length:40,$=Ce==="air"?20:L+Math.min(25,.4*u+.01*at*Math.min(1,u)),V=0;it.forEach(function(c){V+=Math.abs(c.qA||0)}),i.forEach(function(c){V+=c.flowLpm});for(var S=!1,B=0;B<re.length;B++){var T=re[B];if(T.tag==="relief"&&T.flow>.05){S=!0;break}}var q=n.some(function(c){return Math.abs(c.speedMmS)>.5})||i.some(function(c){return Math.abs(c.rpm)>1});S&&!q&&l>.1&&ht.push("Pump flow is going over the relief valve (circuit dead-headed or actuators idle)."),!kt.length&&et.some(function(c){return c.type==="pumpFixed"||c.type==="powerPack"})&&ht.push("No pressure relief valve detected for a fixed-displacement source."),it.forEach(function(c){c.starving&&ht.push((c.comp.label||c.comp.id)+": supply starved (possible cavitation) \u2014 increase flow or opening."),Math.abs(c.v)>250&&ht.push((c.comp.label||c.comp.id)+" speed is very high; check flow and pipe size.")});for(var A=0;A<et.length;A++){var x=et[A],R=C(x.id,"P");if(R>=0&&pe[R]>W(x.props.maxPressureBar,320)+5){ht.push((x.label||x.id)+": maximum pressure exceeded \u2014 check relief protection.");break}}return Z.debug?{_dbg:!0,N:O,nodeKeys:w.slice(),p:Array.from(pe),edges:re.map(function(c){return{a:c.a,b:c.b,tag:c.tag,cid:c.compId,gNow:c.gNow,flow:c.flow}}),injections:U.map(function(c){var f={n:c.node,tag:c.tag,cid:c.compId,qNow:c.qNow,q:c.q,hasDyn:!!c.dynQ};try{f.dynAt0=c.dynQ?c.dynQ(0):null}catch(k){f.err=String(k)}return f})}:{totalFlowLpm:l,activeFlowLpm:V,pressureBar:o,reliefSetting:ot,powerKw:g,oilTempC:$,time:at,cylinders:n,motors:i,lines:a.map(function(c){return{id:c.id,velocityMps:c.velocityMps,flowLpm:c.flowLpm,active:c.active,high:c.high,pressureBar:c.pressureBar}}),warnings:ht.slice(0,40),comp:t,accumulators:je.map(function(c){for(var f=0,k=0;k<D.length;k++)D[k].comp.id===c.id&&(f=D[k].flow||0);return{id:c.id,flowLpm:f}})}}
globalThis.rgzFluidSolve = rgzFluidSolve;
let PASS = 0, FAIL = 0;
function ok(cond, name, detail) {
  if (cond) { PASS++; console.log("  PASS", name, detail ?? ""); }
  else { FAIL++; console.log("  FAIL", name, "=>", detail); }
}
const C = (id, type, props = {}, x = 0, y = 0) => ({ id, type, label: id, x, y, rotation: 0, props });
const L = (id, a, pa, b, pb, lt = "pressure", d = 12, len = 1) => ({ id, from: { componentId: a, portId: pa }, to: { componentId: b, portId: pb }, lineType: lt, properties: { tubeIdMm: d, lengthM: len } });
function run(fluid, comps, conns, ticks = 40, dt = 0.05, mutate = null) {
  globalThis.rgzFluidSolve._dyn = null;
  let m, t = 0;
  for (let i = 0; i < ticks; i++) {
    if (mutate) mutate(i, comps);
    m = globalThis.rgzFluidSolve({ fluid, components: comps, connections: conns, dt, time: t });
    t += dt;
  }
  return m;
}

console.log("\n== HYD 1: powerPack + 4/3 closed-center, LEFT = cylinder extends ==");
{
  const comps = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "left", ratedFlowLpm: 40, pressureDropBar: 5 }),
    C("CYL", "cylinderDA", { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 350, simPosition: 0.2 }),
    C("G_P", "pressureGauge", {}), C("G_A", "pressureGauge", {}),
  ];
  const conns = [
    L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"),
    L("l3", "V", "A", "CYL", "A"), L("l4", "V", "B", "CYL", "B"),
    L("l5", "HPU", "P", "G_P", "P"), L("l6", "V", "A", "G_A", "P"),
  ];
  const m = run("oil", comps, conns);
  const v = m.cylinders[0].speedMmS, pPump = m.comp.G_P.pressureBar, pA = m.comp.G_A.pressureBar;
  ok(v > 100 && v < 160, "cylinder extends ~134 mm/s", v.toFixed(1));
  ok(pA > 5 && pA < 40, "cap-end pressure near load pressure (11-25 bar)", pA.toFixed(1));
  ok(pPump >= pA, "pump pressure >= chamber pressure", pPump.toFixed(1) + " vs " + pA.toFixed(1));
}

console.log("\n== HYD 2: same circuit, valve CENTERED (closed center) ==");
{
  const comps = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "center", ratedFlowLpm: 40, pressureDropBar: 5 }),
    C("CYL", "cylinderDA", { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 350, simPosition: 0.2 }),
    C("G_P", "pressureGauge", {}), C("G_A", "pressureGauge", {}),
  ];
  const conns = [
    L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"),
    L("l3", "V", "A", "CYL", "A"), L("l4", "V", "B", "CYL", "B"),
    L("l5", "HPU", "P", "G_P", "P"), L("l6", "V", "A", "G_A", "P"),
  ];
  const m = run("oil", comps, conns);
  const pPump = m.comp.G_P.pressureBar, pA = m.comp.G_A.pressureBar, v = m.cylinders[0].speedMmS;
  ok(Math.abs(v) < 1, "cylinder stands still", v.toFixed(2));
  ok(pPump > 145 && pPump < 172, "pump deadheads at relief ~160 bar", pPump.toFixed(1));
  ok(pA < 1, "gauge downstream of CLOSED center reads ~0 (user bug #2)", pA.toFixed(2));
  ok(m.warnings.some(w => /relief/i.test(w)), "warns about relief deadhead", m.warnings.join(" | "));
}

console.log("\n== HYD 3: adjustable flow control (meter-in) changes speed ==");
{
  const build = (opening) => ([
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "left", ratedFlowLpm: 40, pressureDropBar: 5 }),
    C("FC", "flowControl", { openingPercent: opening, pressureCompensated: false, maxFlowLpm: 60 }),
    C("CYL", "cylinderDA", { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 350, simPosition: 0.2 }),
  ]);
  const conns = [
    L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"),
    L("l3", "V", "A", "FC", "A"), L("l4", "FC", "B", "CYL", "A"), L("l5", "V", "B", "CYL", "B"),
  ];
  const mOpen43 = run("oil", build(43), conns).cylinders[0].speedMmS;   // kv 17 -> passes 25 at ~2bar? (25/17)^2=2.2
  const mTiny = run("oil", build(6), conns);                            // kv 0.66 -> capacity at relief ~8 L/min
  const vTiny = mTiny.cylinders[0].speedMmS, pTiny = mTiny.pressureBar;
  ok(mOpen43 > 100, "43% opening ~full speed", mOpen43.toFixed(1));
  ok(vTiny < mOpen43 * 0.55, "6% opening much slower", vTiny.toFixed(1) + " vs " + mOpen43.toFixed(1));
  ok(pTiny > 120, "restrictive FC raises pump pressure toward relief", pTiny.toFixed(1));
}

console.log("\n== HYD 4: pressure reducing valve holds downstream pressure ==");
{
  const build = (outlet) => {
    const comps = [
      C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
      C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "left", ratedFlowLpm: 40, pressureDropBar: 5 }),
      C("RV", "reducingValve", { outletBar: outlet }),
      C("CYL", "cylinderDA", { boreMm: 100, rodMm: 55, strokeMm: 400, loadKg: 3000, simPosition: 0.2 }),
      C("G_A", "pressureGauge", {}),
    ];
    const conns = [
      L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"),
      L("l3", "V", "A", "RV", "P"), L("l4", "RV", "A", "CYL", "A"), L("l5", "RV", "T", "HPU", "T", "return"),
      L("l6", "V", "B", "CYL", "B"), L("l7", "RV", "A", "G_A", "P"),
    ];
    return [comps, conns];
  };
  // 3000 kg on 100mm bore needs 37.5 bar -> below setting 60: downstream ~ load pressure
  let [c1, x1] = build(60);
  const m1 = run("oil", c1, x1);
  const pA1 = m1.comp.G_A.pressureBar, v1 = m1.cylinders[0].speedMmS;
  ok(pA1 > 25 && pA1 < 62, "downstream pressure below setting (load-dictated)", pA1.toFixed(1));
  ok(v1 > 1, "cylinder can move", v1.toFixed(1));
  // heavy load stall test: 6000 kg needs 75 bar > setting 40 -> stalls, p_A ~= 40
  const heavy = () => {
    const comps = [
      C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
      C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "left", ratedFlowLpm: 40, pressureDropBar: 5 }),
      C("RV", "reducingValve", { outletBar: 40 }),
      C("CYL", "cylinderDA", { boreMm: 100, rodMm: 55, strokeMm: 400, loadKg: 6000, simPosition: 0.2 }),
      C("G_A", "pressureGauge", {}),
    ];
    const conns = [
      L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"),
      L("l3", "V", "A", "RV", "P"), L("l4", "RV", "A", "CYL", "A"), L("l5", "RV", "T", "HPU", "T", "return"),
      L("l6", "V", "B", "CYL", "B"), L("l7", "RV", "A", "G_A", "P"),
    ];
    return [comps, conns];
  };
  const [c2, x2] = heavy();
  const m2 = run("oil", c2, x2);
  const pA2 = m2.comp.G_A.pressureBar, v2 = m2.cylinders[0].speedMmS;
  ok(v2 < -1, "overpowering load yields downward (3-way valve relieves downstream)", v2.toFixed(2));
  ok(pA2 > 32 && pA2 < 48, "downstream clamped near 40 bar setting (user bug #1)", pA2.toFixed(1));
}

console.log("\n== HYD 5: variable pump destrokes at compensator ==");
{
  const comps = [
    C("T", "tank", {}), C("PU", "pumpVariable", { flowLpm: 32, compensatorBar: 120, maxPressureBar: 210 }),
    C("RV", "reliefValve", { settingBar: 160 }),
    C("SV", "shutoffValve", { open: false }),
    C("G", "pressureGauge", {}),
  ];
  const conns = [
    L("l1", "PU", "S", "T", "T", "suction"), L("l2", "PU", "P", "SV", "A"), L("l3", "SV", "B", "T", "T"),
    L("l4", "PU", "P", "RV", "P"), L("l5", "RV", "T", "T", "T", "return"), L("l6", "PU", "P", "G", "P"),
  ];
  const m = run("oil", comps, conns);
  const p = m.comp.G.pressureBar;
  ok(p > 105 && p < 135, "deadheaded at compensator ~120 bar", p.toFixed(1));
  ok(m.pressureBar > 105 && m.pressureBar < 135, "system pressure follows", m.pressureBar.toFixed(1));
}

console.log("\n== HYD 6: check valve blocks reverse ==");
{
  const comps = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("CV", "checkValve", { crackingBar: 0.5 }),
    C("G1", "pressureGauge", {}), C("G2", "pressureGauge", {}),
  ];
  // flow attempted B -> A (reverse): pump on B side
  const conns = [L("l1", "HPU", "P", "CV", "B"), L("l2", "HPU", "T", "CV", "A", "return"), L("l3", "HPU", "P", "G1", "P"), L("l4", "CV", "A", "G2", "P")];
  const m = run("oil", comps, conns);
  ok(m.comp.G1.pressureBar > 145, "upstream deadheads at relief", m.comp.G1.pressureBar.toFixed(1));
  ok(m.comp.G2.pressureBar < 1, "reverse side stays ~0", m.comp.G2.pressureBar.toFixed(2));
}

console.log("\n== HYD 7: regenerative center is faster than normal extend ==");
{
  const build = (center, state) => {
    const comps = [
      C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
      C("V", "directionalValve", { ports: "4", positions: "3", center, spoolState: state, ratedFlowLpm: 60, pressureDropBar: 3 }),
      C("CYL", "cylinderDA", { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 30, simPosition: 0.2 }),
    ];
    const conns = [L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"), L("l3", "V", "A", "CYL", "A"), L("l4", "V", "B", "CYL", "B")];
    return [comps, conns];
  };
  const [cn, xn] = build("closed", "left");
  const vNorm = run("oil", cn, xn).cylinders[0].speedMmS;
  const [cr, xr] = build("regenerative", "center");
  const vRegen = run("oil", cr, xr).cylinders[0].speedMmS;
  ok(vNorm > 80 && vNorm < 160, "normal extend plausible", vNorm.toFixed(1));
  ok(vRegen > vNorm * 1.15, "regen extend faster (diff area)", vRegen.toFixed(1) + " vs " + vNorm.toFixed(1));
}

console.log("\n== HYD 8: single-acting cylinder extends and spring-returns ==");
{
  const comps = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("V", "directionalValve", { ports: "3", positions: "2", center: "closed", spoolState: "left", ratedFlowLpm: 40, pressureDropBar: 5 }),
    C("CYL", "cylinderSA", { boreMm: 50, strokeMm: 300, loadKg: 20, springReturn: true, simPosition: 0.15 }),
  ];
  const conns = [L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"), L("l3", "V", "A", "CYL", "A")];
  const mExt = run("oil", comps.map(c => ({ ...c, props: { ...c.props } })), conns);
  ok(mExt.cylinders[0].speedMmS > 50, "SA extends", mExt.cylinders[0].speedMmS.toFixed(1));
  const mRet = run("oil", comps.map(c => (c.id === "V" ? { ...c, props: { ...c.props, spoolState: "right" } } : { ...c, props: { ...c.props } })), conns);
  ok(mRet.cylinders[0].speedMmS < -1, "SA spring retracts when valve vented", mRet.cylinders[0].speedMmS.toFixed(1));
}

console.log("\n== HYD 9: servo/proportional valve command scales speed ==");
{
  const build = (cmd) => ([
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("SV", "servoValve", { commandPercent: cmd, ratedFlowLpm: 16 }),
    C("CYL", "cylinderDA", { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 300, simPosition: 0.2 }),
  ]);
  const conns = [L("l1", "HPU", "P", "SV", "P"), L("l2", "SV", "T", "HPU", "T", "return"), L("l3", "SV", "A", "CYL", "A"), L("l4", "SV", "B", "CYL", "B")];
  const v100 = run("oil", build(100), conns).cylinders[0].speedMmS;
  const v25 = run("oil", build(14), conns).cylinders[0].speedMmS;
  const vRev = run("oil", build(-80), conns).cylinders[0].speedMmS;
  ok(v100 > 60, "100% command fast", v100.toFixed(1));
  ok(v25 > 1 && v25 < v100 * 0.65, "14% command slower (metering below pump flow)", v25.toFixed(1) + " vs " + v100.toFixed(1));
  ok(vRev < -20 && vRev > -400, "negative command retracts at bounded speed", vRev.toFixed(1));
}

console.log("\n== PNE A: FRL regulator clamps downstream pressure ==");
{
  const comps = [
    C("CP", "compressorFixed", { flowLpm: 500, maxPressureBar: 8 }),
    C("EX", "exhaust", {}),
    C("FRL", "frlUnit", { regulatorBar: 6, filterMicron: 5 }),
    C("G1", "pressureGauge", {}), C("G2", "pressureGauge", {}),
  ];
  const conns = [
    L("l1", "CP", "P", "FRL", "P", "pressure", 6), L("l2", "CP", "S", "EX", "T", "suction", 6),
    L("l3", "CP", "P", "G1", "P", "pressure", 6), L("l4", "FRL", "A", "G2", "P", "pressure", 6),
  ];
  const m = run("air", comps, conns);
  ok(m.comp.G1.pressureBar > 6.2, "upstream high (comp pushes to max)", m.comp.G1.pressureBar.toFixed(2));
  ok(Math.abs(m.comp.G2.pressureBar - 6) < 0.8, "downstream regulated ~6 bar", m.comp.G2.pressureBar.toFixed(2));
}

console.log("\n== PNE B: 5/2 + DA cylinder, exhaust restrictor slows motion ==");
{
  const build = (opening) => ([
    C("CP", "compressorFixed", { flowLpm: 500, maxPressureBar: 8 }),
    C("EX", "exhaust", {}),
    C("FRL", "frlUnit", { regulatorBar: 6 }),
    C("V", "directionalValve", { ports: "5", positions: "2", center: "closed", spoolState: "left", ratedFlowLpm: 600, pressureDropBar: 0.3 }),
    C("FC", "flowControl", { openingPercent: opening, maxFlowLpm: 400 }),
    C("CYL", "cylinderDA", { boreMm: 40, rodMm: 16, strokeMm: 400, loadKg: 20, simPosition: 0.1 }),
  ]);
  const conns = [
    L("l1", "CP", "P", "FRL", "P", "pressure", 6), L("l2", "CP", "S", "EX", "T", "suction", 6),
    L("l3", "FRL", "A", "V", "P", "pressure", 6), L("l4", "V", "T", "FC", "A", "pressure", 6),
    L("l5", "FC", "B", "EX", "T", "return", 6),
    L("l6", "V", "A", "CYL", "A", "pressure", 6), L("l7", "V", "B", "CYL", "B", "pressure", 6),
  ];
  const vOpen = run("air", build(100), conns).cylinders[0].speedMmS;
  const vSmall = run("air", build(8), conns).cylinders[0].speedMmS;
  ok(vOpen > 30, "open exhaust restrictor: moves", vOpen.toFixed(1));
  ok(vSmall < vOpen * 0.6, "80% closed restrictor: much slower", vSmall.toFixed(1) + " vs " + vOpen.toFixed(1));
}

console.log("\n== PNE C: shuttle OR vs two-pressure AND ==");
{
  const base = (mid) => ([
    C("CP", "compressorFixed", { flowLpm: 500, maxPressureBar: 8 }),
    C("EX", "exhaust", {}),
    C("V1", "directionalValve", { ports: "3", positions: "2", spoolState: "left", ratedFlowLpm: 600, pressureDropBar: 0.3 }),
    C("V2", "directionalValve", { ports: "3", positions: "2", spoolState: "right", ratedFlowLpm: 600, pressureDropBar: 0.3 }),
    C(mid, mid === "shuttleValve" ? "shuttleValve" : "twoPressureValve", {}),
    C("G", "pressureGauge", {}),
  ]);
  const conns = [
    L("l1", "CP", "P", "V1", "P", "pressure", 6), L("l2", "CP", "P", "V2", "P", "pressure", 6), L("l3", "CP", "S", "EX", "T", "suction", 6),
    L("l4", "V1", "A", "V1X", "A", "pressure", 6),
  ];
  // shuttle: V1 pressurised -> out high
  const compsS = base("shuttleValve"), connsS = [
    L("l1", "CP", "P", "V1", "P", "pressure", 6), L("l2", "CP", "P", "V2", "P", "pressure", 6), L("l3", "CP", "S", "EX", "T", "suction", 6),
    L("l4", "V1", "A", "shuttleValve", "A", "pressure", 6), L("l5", "V2", "A", "shuttleValve", "B", "pressure", 6), L("l6", "shuttleValve", "X", "G", "P", "pressure", 6),
  ];
  compsS.forEach(c => { if (c.type !== "directionalValve") return; });
  const mS = run("air", compsS, connsS);
  ok(mS.comp.G.pressureBar > 4, "OR: one signal is enough", mS.comp.G.pressureBar.toFixed(2));
  const compsA = base("twoPressureValve"), connsA = [
    L("l1", "CP", "P", "V1", "P", "pressure", 6), L("l2", "CP", "P", "V2", "P", "pressure", 6), L("l3", "CP", "S", "EX", "T", "suction", 6),
    L("l4", "V1", "A", "twoPressureValve", "A", "pressure", 6), L("l5", "V2", "A", "twoPressureValve", "B", "pressure", 6), L("l6", "twoPressureValve", "X", "G", "P", "pressure", 6),
  ];
  const mA = run("air", compsA, connsA);
  ok(mA.comp.G.pressureBar < 1.5, "AND: one signal missing -> ~0", mA.comp.G.pressureBar.toFixed(2));
  const both = compsA.map(c => c.id === "V2" ? { ...c, props: { ...c.props, spoolState: "left" } } : c);
  const mA2 = run("air", both, connsA);
  ok(mA2.comp.G.pressureBar > 4, "AND: both signals -> high", mA2.comp.G.pressureBar.toFixed(2));
}

console.log("\n== PNE D: time-delay valve opens after delay ==");
{
  const comps = [
    C("CP", "compressorFixed", { flowLpm: 500, maxPressureBar: 8 }),
    C("EX", "exhaust", {}),
    C("TD", "pneumaticTimeDelayValve", { delayS: 1, mode: "on-delay" }),
    C("G", "pressureGauge", {}),
  ];
  const conns = [
    L("l1", "CP", "P", "TD", "P", "pressure", 6), L("l2", "CP", "S", "EX", "T", "suction", 6), L("l3", "TD", "A", "G", "P", "pressure", 6),
  ];
  globalThis.rgzFluidSolve._dyn = null;
  const mEarly = globalThis.rgzFluidSolve({ fluid: "air", components: comps, connections: conns, dt: 0.05, time: 0.2 });
  let mLate = mEarly;
  for (let t = 0.25; t < 2.5; t += 0.1) mLate = globalThis.rgzFluidSolve({ fluid: "air", components: comps, connections: conns, dt: 0.1, time: t });
  ok(mEarly.comp.G.pressureBar < 1, "before delay: A ~0", mEarly.comp.G.pressureBar.toFixed(2));
  ok(mLate.comp.G.pressureBar > 4, "after 1 s: A pressurised", mLate.comp.G.pressureBar.toFixed(2));
}

console.log("\n== HYD 10: closed-center valve + stalled motor = 0 rpm, downstream gauge 0 (UI regression) ==");
{
  const comps = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "center", ratedFlowLpm: 40, pressureDropBar: 5 }),
    C("M", "hydraulicMotor", { displacementCcRev: 40, loadNm: 25 }),
    C("FS", "flowSwitch", { switchLpm: 15 }),
    C("G", "pressureGauge", {}),
  ];
  const conns = [
    L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"),
    L("l3", "V", "A", "FS", "A"), L("l4", "FS", "B", "M", "A"),
    L("l5", "M", "B", "V", "B", "return"), L("l6", "FS", "B", "G", "P"),
  ];
  const m = run("oil", comps, conns);
  const mot = m.motors[0];
  ok(Math.abs(mot.rpm) < 0.5 && mot.flowLpm < 0.5, "stalled motor: rpm & flow are 0", mot.rpm.toFixed(2) + "rpm " + mot.flowLpm.toFixed(2) + "lpm");
  ok(Math.abs(m.comp.FS.flowLpm) < 0.5, "flow switch sees 0 L/min", m.comp.FS.flowLpm.toFixed(2));
  ok(m.comp.G.pressureBar < 1, "gauge downstream of closed center reads ~0 (the reported bug)", m.comp.G.pressureBar.toFixed(2));
  ok(Math.abs(m.comp.HPU.pressureBar - 160) < 12, "pump deadheads at its relief setting", m.comp.HPU.pressureBar.toFixed(1));
  ok(m.pressureBar <= 200, "no phantom pressure explosions", m.pressureBar.toFixed(1));
}

console.log("\n== HYD 11: retract with load: pump-limited speed, no vacuum on the pump line (UI regression) ==");
{
  const comps = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "right", ratedFlowLpm: 40, pressureDropBar: 5 }),
    C("CYL", "cylinderDA", { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 350, simPosition: 0.5 }),
  ];
  const conns = [
    L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"),
    L("l3", "V", "A", "CYL", "A"), L("l4", "V", "B", "CYL", "B", "return"),
  ];
  const m = run("oil", comps, conns);
  const cy = m.cylinders[0];
  // rod side fills at 25 L/min -> v = 25 L/min / 20.99 cm^2 = -198.7 mm/s; mass conservation
  ok(cy.speedMmS < -150 && cy.speedMmS > -260, "retract speed is pump-fill limited (not a vacuum-powered runaway)", cy.speedMmS.toFixed(1));
  ok(m.comp.HPU.pressureBar > -0.5, "pump outlet is not dragged into vacuum", m.comp.HPU.pressureBar.toFixed(2));
  ok(m.comp.V.pressureBar > -1.2 && m.comp.V.supplyBar > -1.2, "valve ports stay out of deep vacuum",
    m.comp.V.pressureBar.toFixed(2) + "/" + m.comp.V.supplyBar.toFixed(2));
  ok(m.comp.HPU.pressureBar < 80, "retract against moderate load stays below relief", m.comp.HPU.pressureBar.toFixed(1));
}

console.log("\n== HYD 12: meter-OUT flow control slows the cylinder via rod-side back-pressure (needs intensification above relief) ==");
{
  const build = (opening, spool) => ([
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: spool || "left", ratedFlowLpm: 40, pressureDropBar: 5 }),
    C("FC", "flowControl", { openingPercent: opening, maxFlowLpm: 60, pressureCompensated: false }),
    C("CYL", "cylinderDA", { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 350, simPosition: 0.2 }),
  ]);
  const conns = [
    L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"),
    L("l3", "V", "A", "CYL", "A"), L("l4", "V", "B", "FC", "A", "return"), L("l5", "FC", "B", "CYL", "B", "return"),
  ];
  const vOpen = run("oil", build(100), conns).cylinders[0].speedMmS;
  const vMid = run("oil", build(20), conns).cylinders[0].speedMmS;
  const m6 = run("oil", build(6), conns);
  const v6 = m6.cylinders[0].speedMmS;
  const v3 = run("oil", build(3), conns).cylinders[0].speedMmS;
  // 43-100%: sustainable below relief -> full speed is PHYSICALLY correct for
  // meter-out with a fixed pump (back-pressure only adds load). At 6% the
  // intensified rod pressure needed (~630 bar) exceeds relief, so the cylinder
  // MUST slow; theory: pA=160 -> pB=236 -> qB=kv*sqrt(236)=10.2 -> v=81.
  ok(vOpen > 120 && Math.abs(vMid - vOpen) < 8, "open/mid openings: full speed with elevated back-pressure", vOpen.toFixed(1) + " / " + vMid.toFixed(1));
  ok(v6 > 55 && v6 < 105, "6% opening: slowed to the intensification-limited speed (theory ~81)", v6.toFixed(1));
  ok(v3 < v6 * 0.6, "3% opening: much slower still", v3.toFixed(1) + " vs " + v6.toFixed(1));
  ok(m6.comp.HPU.pressureBar > 145, "throttled meter-out deadheads the pump at relief", m6.comp.HPU.pressureBar.toFixed(1));
}

console.log("\n== Robustness: real example circuits (no crash, sane values) ==");
{
  const dir = new URL("./models/", import.meta.url).pathname;
  const files = fs.existsSync(dir) ? fs.readdirSync(dir).filter((f) => f.endsWith(".json")) : [];
  if (!files.length) { /* session-local dumps absent; scenario tests above are the gate */ }
  for (const f of files) {
    try {
      const model = JSON.parse(fs.readFileSync(dir + f, "utf8"));
      const m = run("oil", model.components, model.connections, 10);
      const sane = Number.isFinite(m.pressureBar) && m.pressureBar >= 0 && m.pressureBar < 1500;
      ok(sane, f, "p=" + m.pressureBar.toFixed(1) + " warn=" + m.warnings.length);
    } catch (e) { ok(false, f, e.message); }
  }
}

console.log("\n== HYD 13: cartridge manifold block = through-gallery, NOT a junction (P must NOT short to T) ==");
{
  const comps = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("HIC", "cartridgeManifoldBlock", {}),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "center" }),
  ];
  const conns = [
    L("l1", "HPU", "P", "HIC", "P"), L("l2", "HIC", "A", "V", "P"),
    L("l3", "V", "T", "HIC", "T"), L("l4", "HIC", "T", "HPU", "T", "return"),
  ];
  const m = run("oil", comps, conns);
  ok(m.pressureBar > 145 && m.pressureBar < 175, "pump deadheads at relief through manifold (no P-T short)", m.pressureBar.toFixed(1));
  const comps2 = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("HIC", "cartridgeManifoldBlock", {}),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "left" }),
    C("CYL", "cylinderDA", { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 350, simPosition: 0.2 }),
  ];
  const conns2 = [
    L("l1", "HPU", "P", "HIC", "P"), L("l2", "HIC", "A", "V", "P"),
    L("l3", "V", "T", "HIC", "T"), L("l4", "HIC", "T", "HPU", "T", "return"),
    L("l5", "V", "A", "CYL", "A"), L("l6", "V", "B", "CYL", "B"),
  ];
  const m2 = run("oil", comps2, conns2);
  ok(m2.cylinders[0].speedMmS > 100, "cylinder extends through manifold P->A gallery at ~134 mm/s", m2.cylinders[0].speedMmS.toFixed(1));
}

console.log("\n== HYD 14: sequence clamp-and-work retract (bypass check parallel to seq valve) ==");
{
  const build = (withCV) => ([
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "left" }),
    C("CL", "cylinderDA", { boreMm: 50, rodMm: 28, strokeMm: 250, loadKg: 150, simPosition: 0.1 }),
    C("SV", "sequenceValve", { settingBar: 55 }),
    C("WK", "cylinderDA", { boreMm: 80, rodMm: 45, strokeMm: 400, loadKg: 500, simPosition: 0.1 }),
    ...(withCV ? [C("CV", "checkValve", { crackingBar: 0.5 })] : []),
  ]);
  const connsOf = (withCV) => [
    L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"),
    L("l3", "V", "A", "CL", "A"), L("l4", "V", "A", "SV", "P"),
    L("l5", "SV", "A", "WK", "A"),
    L("l6", "CL", "B", "V", "B", "return"), L("l7", "WK", "B", "V", "B", "return"),
    L("l8", "SV", "T", "HPU", "T", "drain"),
    ...(withCV ? [L("l9", "WK", "A", "CV", "A"), L("l10", "CV", "B", "SV", "P")] : []),
  ];
  // extend order: clamp first, then work at full speed after sequence opens
  const order = (withCV, spool, secs) => {
    const comps = build(withCV), conns = connsOf(withCV);
    const V = comps.find(c => c.id === "V");
    globalThis.rgzFluidSolve._dyn = null;
    V.props.spoolState = spool; let m, t = 0, dt = 0.05, sawClampFirst = false, sawWorkAfter = false;
    const n = Math.round(secs / dt);
    for (let i = 0; i < n; i++) {
      m = globalThis.rgzFluidSolve({ fluid: "oil", components: comps, connections: conns, dt, time: t }); t += dt;
      for (const cy of m.cylinders) {
        const c = comps.find(x => x.id === cy.id);
        c.props.simPosition = Math.min(1, Math.max(0, c.props.simPosition + cy.speedMmS * dt / (c.props.strokeMm || 300)));
      }
      if (comps.find(c => c.id === "CL").props.simPosition > 0.95 && comps.find(c => c.id === "WK").props.simPosition < 0.2) sawClampFirst = true;
      if (sawClampFirst && comps.find(c => c.id === "WK").props.simPosition > 0.5) sawWorkAfter = true;
    }
    return { m, comps, conns, sawClampFirst, sawWorkAfter };
  };
  const ext = order(true, "left", 9);
  ok(ext.sawClampFirst && ext.sawWorkAfter, "extend sequence: clamp completes first, then work extends");
  // retract: without check the work cylinder is trapped (< 1 mm/s); with check it retracts fast
  const trap = order(false, "right", 8);
  ok(Math.abs(trap.m.cylinders.find(c => c.label === "WK").speedMmS) < 1, "WITHOUT bypass check: work cap oil trapped by seq valve (documents old bug)", trap.m.cylinders.find(c => c.label === "WK").speedMmS.toFixed(2));
  const free = order(true, "right", 8);
  const wkFree = free.m.cylinders.find(c => c.label === "WK");
  const wkHome = free.comps.find(c => c.id === "WK").props.simPosition;
  ok(wkFree.speedMmS < -40 || wkHome < 0.05, "WITH bypass check: work retracts fast", wkFree.speedMmS.toFixed(1) + " pos=" + (wkHome * 100).toFixed(0) + "%");
}

console.log("\n== HYD 15: check valve hysteresis — forward free, reverse blocked ==");
{
  // forward: pump -> CV -> cylinder extends at full speed
  const compsF = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("CV", "checkValve", { crackingBar: 0.5 }),
    C("CYL", "cylinderDA", { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 200, simPosition: 0.2 }),
    C("GA", "pressureGauge", {}),
  ];
  const connsF = [L("l1", "HPU", "P", "CV", "A"), L("l2", "CV", "B", "CYL", "A"), L("l3", "CYL", "B", "HPU", "T", "return"), L("l4", "CYL", "A", "GA", "P")];
  const mF = run("oil", compsF, connsF);
  ok(mF.cylinders[0].speedMmS > 100, "forward through check valve extends at ~134", mF.cylinders[0].speedMmS.toFixed(1));
  // reverse isolation: pressurized side must NOT drain back through the check valve
  // (accumulator at 80 bar downstream of the check, pump centered/dead)
  const compsR = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("CV", "checkValve", { crackingBar: 0.5 }),
    C("ACC", "accumulator", { prechargeBar: 60, volumeL: 5, simChargeL: 2 }),
    C("GA", "pressureGauge", {}),
  ];
  const connsR = [L("l1", "HPU", "P", "CV", "A"), L("l2", "CV", "B", "ACC", "A"), L("l3", "ACC", "A", "GA", "P")];
  let pHighAfter = 0;
  {
    globalThis.rgzFluidSolve._dyn = null; let m, t = 0;
    for (let i = 0; i < 40; i++) { m = globalThis.rgzFluidSolve({ fluid: "oil", components: compsR, connections: connsR, dt: 0.05, time: t }); t += 0.05; }
    pHighAfter = m.comp.GA.pressureBar;
  }
  ok(pHighAfter > 55, "reverse side holds pressure, no backward drain through check (acc ~80 bar)", pHighAfter.toFixed(1));
}

console.log("\n== HYD 16: pilot-operated check valve load holding — extend / hold / pilot-released retract ==");
{
  const model = JSON.parse(fs.readFileSync(new URL("./models/hyd-simple-11-pcheck.json", import.meta.url), "utf8"));
  const comps = model.components.filter(c => c.type !== "textLabel");
  [["GA", "C-4", "A"], ["GB", "C-4", "B"]].forEach(([g, ci, pi]) => {
    comps.push({ id: g, type: "pressureGauge", label: g, x: 0, y: 0, rotation: 0, props: {} });
    model.connections.push({ id: g, from: { componentId: ci, portId: pi }, to: { componentId: g, portId: "P" }, lineType: "pressure", properties: { tubeIdMm: 12, lengthM: 1 } });
  });
  const V = comps.find(c => c.type === "directionalValve");
  const CY = comps.find(c => c.type === "cylinderDA");
  CY.props.simPosition = 0.1;
  globalThis.rgzFluidSolve._dyn = null;
  let m, t = 0; const dt = 0.05;
  const step = (sec) => {
    for (let i = 0, n = Math.round(sec / dt); i < n; i++) {
      m = globalThis.rgzFluidSolve({ fluid: "oil", components: comps, connections: model.connections, dt, time: t }); t += dt;
      CY.props.simPosition = Math.min(1, Math.max(0, CY.props.simPosition + m.cylinders[0].speedMmS * dt / (CY.props.strokeMm || 300)));
    }
  };
  V.props.spoolState = "left"; step(3);
  ok(CY.props.simPosition > 0.6, "PO check example: cylinder extends through the check valve", (CY.props.simPosition * 100).toFixed(0) + "%");
  V.props.spoolState = "center";
  step(2); const posH = CY.props.simPosition;
  step(2);
  ok(Math.abs(CY.props.simPosition - posH) < 0.02, "load held in center (PO check traps the cap side)", ((CY.props.simPosition - posH) * 100).toFixed(2) + "% drift");
  V.props.spoolState = "right"; step(1);
  ok(m.comp.GB.pressureBar < 40, "during retract the rod side reads working pressure (pilot cracked the check valve open)", m.comp.GB.pressureBar.toFixed(1) + " bar");
  step(2);
  ok(CY.props.simPosition < 0.15, "retract: pilot opens the check valve return path (no stuck circuit)", (CY.props.simPosition * 100).toFixed(0) + "%");
}

console.log("\n== HYD 17: slip-in logic 4-way bridge — piloted poppet pressure levels ==");
{
  const model = JSON.parse(fs.readFileSync(new URL("./models/hyd-cart-3-bridge.json", import.meta.url), "utf8"));
  const comps = model.components.filter(c => c.type !== "textLabel");
  [["GA", "C-4", "A"], ["GB", "C-4", "B"]].forEach(([g, ci, pi]) => {
    comps.push({ id: g, type: "pressureGauge", label: g, x: 0, y: 0, rotation: 0, props: {} });
    model.connections.push({ id: g, from: { componentId: ci, portId: pi }, to: { componentId: g, portId: "P" }, lineType: "pressure", properties: { tubeIdMm: 12, lengthM: 1 } });
  });
  const V = comps.find(c => c.type === "directionalValve");
  const CY = comps.find(c => c.type === "cylinderDA");
  CY.props.simPosition = 0.05;
  globalThis.rgzFluidSolve._dyn = null;
  let m, t = 0; const dt = 0.05;
  const step = (sec) => {
    for (let i = 0, n = Math.round(sec / dt); i < n; i++) {
      m = globalThis.rgzFluidSolve({ fluid: "oil", components: comps, connections: model.connections, dt, time: t }); t += dt;
      CY.props.simPosition = Math.min(1, Math.max(0, CY.props.simPosition + m.cylinders[0].speedMmS * dt / (CY.props.strokeMm || 300)));
    }
  };
  V.props.spoolState = "left"; step(2);
  const capWork = m.comp.GA.pressureBar, rodWork = m.comp.GB.pressureBar;
  ok(m.cylinders[0].speedMmS > 60, "bridge extends the press cylinder", m.cylinders[0].speedMmS.toFixed(0) + " mm/s");
  ok(capWork > 30 && capWork < 80, "pump works at load pressure (~50 bar for 2.5 t), not relief", capWork.toFixed(1) + " bar");
  ok(rodWork < 10, "open B->T leg keeps rod side near tank (phantom back-pressure regression)", rodWork.toFixed(1) + " bar");
  step(2.5);
  ok(CY.props.simPosition > 0.95 && m.comp.GA.pressureBar > 195, "deadhead: full press force at relief (210 bar)", m.comp.GA.pressureBar.toFixed(1) + " bar @ " + (CY.props.simPosition * 100).toFixed(0) + "%");
  V.props.spoolState = "center"; step(1);
  ok(m.comp["PG-5"].pressureBar < 5, "float centre: bridge opens P->T, pump unloads (< 5 bar)", m.comp["PG-5"].pressureBar.toFixed(1) + " bar");
  CY.props.simPosition = 1; globalThis.rgzFluidSolve._dyn = null;
  V.props.spoolState = "right"; step(3);
  ok(CY.props.simPosition < 0.2, "retract via P->B / A->T logic legs", (CY.props.simPosition * 100).toFixed(0) + "%");
}

console.log("\n== HYD 18: flow divider enforces the 50:50 split (both actuators move together, any load) ==");
{
  const C = (id, type, props = {}) => ({ id, type, label: id, x: 0, y: 0, rotation: 0, props });
  const L = (id, a, pa, b, pb) => ({ id, from: { componentId: a, portId: pa }, to: { componentId: b, portId: pb }, lineType: "pressure", properties: { tubeIdMm: 12, lengthM: 1 } });
  const comps = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "center" }),
    C("FD", "flowDivider", { splitPercentA: 50 }),
    C("C1", "cylinderDA", { boreMm: 50, rodMm: 28, strokeMm: 400, loadKg: 320, simPosition: 0.05 }),
    C("C2", "cylinderDA", { boreMm: 50, rodMm: 28, strokeMm: 400, loadKg: 40, simPosition: 0.05 }),
  ];
  const conns = [
    L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T"),
    L("l3", "V", "A", "FD", "P"), L("l4", "FD", "A", "C1", "A"), L("l5", "FD", "B", "C2", "A"),
    L("l6", "C1", "B", "V", "B"), L("l7", "C2", "B", "V", "B"),
  ];
  globalThis.rgzFluidSolve._dyn = null;
  let m, t = 0; const dt = 0.05;
  const run = (sec) => { for (let i = 0, n = Math.round(sec / dt); i < n; i++) {
    m = globalThis.rgzFluidSolve({ fluid: "oil", components: comps, connections: conns, dt, time: t }); t += dt;
    comps.forEach(c => { if (c.type === "cylinderDA") { const cy = m.cylinders.find(x => x.id === c.id); c.props.simPosition = Math.min(1, Math.max(0, c.props.simPosition + cy.speedMmS * dt / 400)); } });
  } };
  const V = comps[1];
  V.props.spoolState = "left"; run(1.0);
  const p1 = comps[3].props.simPosition, p2 = comps[4].props.simPosition;
  ok(m.cylinders[0].speedMmS > 60 && m.cylinders[1].speedMmS > 60, "heavily unequal loads (320 vs 40 kg): BOTH cylinders move in the first second", m.cylinders.map(c=>c.speedMmS.toFixed(0)).join("/") + " mm/s");
  ok(Math.abs(m.cylinders[0].speedMmS - m.cylinders[1].speedMmS) < 12, "speeds matched (50:50 split)", m.cylinders.map(c=>c.speedMmS.toFixed(0)).join("/"));
  ok(Math.abs(p1 - p2) < 0.06, "positions track (sync error < 6%)", (p1*100).toFixed(1) + "%/" + (p2*100).toFixed(1) + "%");
  run(2.6);
  ok(comps[3].props.simPosition > 0.93 && comps[4].props.simPosition > 0.93, "both cylinders reach the end together", (comps[3].props.simPosition*100).toFixed(0) + "%/" + (comps[4].props.simPosition*100).toFixed(0) + "%");
  V.props.spoolState = "right"; run(2.0);
  ok(Math.abs(m.cylinders[0].speedMmS - m.cylinders[1].speedMmS) < 25 && m.cylinders[0].speedMmS < -60, "combiner direction (retract) also meters equally", m.cylinders.map(c=>c.speedMmS.toFixed(0)).join("/"));
  ok(!(m.warnings||[]).some(w => /starved|cavitation/i.test(w)), "no fill-side cavitation while metered out", (m.warnings||[]).length + " warnings");
}

console.log("\n== HYD 19: selectable left/right DCV blocks ==");
{
  const C = (id, type, props = {}) => ({ id, type, label: id, x: 0, y: 0, rotation: 0, props });
  const L = (id, a, pa, b, pb) => ({ id, from: { componentId: a, portId: pa }, to: { componentId: b, portId: pb }, lineType: "pressure", properties: { tubeIdMm: 12, lengthM: 1 } });
  const mk = (vprops) => {
    const comps = [
      C("HPU", "powerPack", { flowLpm: 20, reliefSettingBar: 160 }),
      C("V", "directionalValve", Object.assign({ ports: "4", positions: "3", center: "closed", spoolState: "center" }, vprops)),
      C("C1", "cylinderDA", { boreMm: 50, rodMm: 28, strokeMm: 400, loadKg: 150, simPosition: 0.4 }),
    ];
    const conns = [
      L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T"),
      L("l3", "V", "A", "C1", "A"), L("l4", "V", "B", "C1", "B"),
    ];
    return { comps, conns };
  };
  const runFor = (m0, comps, conns, sec) => {
    let m = m0, t = 0; const dt = 0.05;
    for (let i = 0, n = Math.round(sec / dt); i < n; i++) {
      m = globalThis.rgzFluidSolve({ fluid: "oil", components: comps, connections: conns, dt, time: t }); t += dt;
      comps.forEach(c => { if (c.type === "cylinderDA") { const cy = m.cylinders.find(x => x.id === c.id); c.props.simPosition = Math.min(1, Math.max(0, c.props.simPosition + cy.speedMmS * dt / 400)); } });
    }
    return comps[2].props.simPosition;
  };
  // right spool with rightBlock = parallel behaves like a left spool (extends)
  globalThis.rgzFluidSolve._dyn = null;
  let d = mk({ spoolState: "right", rightBlock: "parallel" });
  const p1 = runFor(null, d.comps, d.conns, 1.5);
  ok(p1 > 0.6, "right spool + rightBlock=parallel EXTENDS the cylinder", (p1 * 100).toFixed(0) + "%");
  // left spool with leftBlock = closed blocks all motion (both envelopes shut)
  globalThis.rgzFluidSolve._dyn = null;
  d = mk({ spoolState: "left", leftBlock: "closed" });
  const p2 = runFor(null, d.comps, d.conns, 1.2);
  ok(Math.abs(p2 - 0.4) < 0.03, "left spool + leftBlock=closed traps the cylinder", (p2 * 100).toFixed(1) + "%");
  // leftBlock = float vents both chambers: heavy load pulls the cylinder down-ish / no drive
  globalThis.rgzFluidSolve._dyn = null;
  d = mk({ spoolState: "left", leftBlock: "crossover" });
  const p3 = runFor(null, d.comps, d.conns, 1.5);
  ok(p3 < 0.2, "left spool + leftBlock=crossover RETRACTS", (p3 * 100).toFixed(0) + "%");
  // legacy default (no block props): right = crossover as before
  globalThis.rgzFluidSolve._dyn = null;
  d = mk({ spoolState: "right" });
  const p4 = runFor(null, d.comps, d.conns, 1.5);
  ok(p4 < 0.2, "legacy valve without block props keeps crossover right", (p4 * 100).toFixed(0) + "%");
}


console.log("\n== HYD 20: time-based load profile on cylinder ==");
// NOTE: below ~620 kg on a 63 mm bore the cylinder runs supply-limited
// (v = Q/A) and chamber pressure stays at the valve-drop ceiling (~19.5 bar);
// the net imbalance is then reported as forceKN. Force balance engages once
// the load needs more pressure, so the ramp test must cross that threshold:
// profile 200 kg -> 3000 kg.
{
  const comps = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "left", ratedFlowLpm: 40, pressureDropBar: 5 }),
    C("CYL", "cylinderDA", { boreMm: 63, rodMm: 36, strokeMm: 5000, loadKg: 200, loadMode: "time-based", loadProfile: "0, 200\n2, 3000", simPosition: 0.2 }),
    C("G_A", "pressureGauge", {}),
  ];
  const conns = [
    L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"),
    L("l3", "V", "A", "CYL", "A"), L("l4", "V", "B", "CYL", "B"),
    L("l5", "V", "A", "G_A", "P"),
  ];
  globalThis.rgzFluidSolve._dyn = null;
  let f1 = null, f2 = null, t = 0;
  for (let i = 0; i < 60; i++) {
    const m = globalThis.rgzFluidSolve({ fluid: "oil", components: comps, connections: conns, dt: 0.05, time: t });
    if (Math.abs(t - 0.45) < 0.026) { f1 = m.comp.G_A.pressureBar; }
    if (Math.abs(t - 2.45) < 0.026) { f2 = m.comp.G_A.pressureBar; }
    t += 0.05;
  }
  ok(f1 !== null && f1 < 30, "early chamber pressure at supply-limited ceiling (~19.5 bar @ 830 kg)", f1 && f1.toFixed(1));
  ok(f2 !== null && f2 > 80, "later chamber pressure force-engaged (~100 bar @ 3000 kg)", f2 && f2.toFixed(1));
  ok(f1 !== null && f2 !== null && f2 - f1 > 50, "time-based load ramps working pressure", f1 && f2 ? f2.toFixed(1) + " - " + f1.toFixed(1) : "n/a");
}

console.log("\n== HYD 21: position-based load profile on cylinder ==");
// Same supply-limited note as HYD 20: profile 200 kg -> 3000 kg over the stroke.
{
  const comps = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "left", ratedFlowLpm: 40, pressureDropBar: 5 }),
    C("CYL", "cylinderDA", { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 200, loadMode: "position-based", loadProfile: "0, 200\n1, 3000", simPosition: 0.1 }),
    C("G_A", "pressureGauge", {}),
  ];
  const conns = [
    L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"),
    L("l3", "V", "A", "CYL", "A"), L("l4", "V", "B", "CYL", "B"),
    L("l5", "V", "A", "G_A", "P"),
  ];
  globalThis.rgzFluidSolve._dyn = null;
  let fA = null, fB = null, t = 0;
  for (let i = 0; i < 40; i++) {
    comps[2].props.simPosition = 0.1; // hold near start: profile ≈ 480 kg
    const m1 = globalThis.rgzFluidSolve({ fluid: "oil", components: comps, connections: conns, dt: 0.05, time: t });
    t += 0.05;
    if (i === 39) fA = m1.comp.G_A.pressureBar;
  }
  for (let i = 0; i < 40; i++) {
    comps[2].props.simPosition = 0.9; // near end: profile ≈ 2720 kg
    const m2 = globalThis.rgzFluidSolve({ fluid: "oil", components: comps, connections: conns, dt: 0.05, time: t });
    t += 0.05;
    if (i === 39) fB = m2.comp.G_A.pressureBar;
  }
  ok(fA !== null && fA < 30, "start-of-stroke pressure at supply-limited ceiling (~19.5 bar @ 480 kg)", fA && fA.toFixed(1));
  ok(fB !== null && fB > 80, "end-of-stroke pressure force-engaged (~100 bar @ 2720 kg)", fB && fB.toFixed(1));
  ok(fA !== null && fB !== null && fB - fA > 50, "position-based load ramps pressure", fB && fA ? fB.toFixed(1) + " - " + fA.toFixed(1) : "n/a");
}

console.log("\n== HYD 22: time-based torque profile on hydraulic motor ==");
{
  const mk = () => ([
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 250 }),
    C("M", "hydraulicMotor", { displacementCcRev: 25, loadNm: 5, loadMode: "time-based", loadProfile: "0, 5\n2, 40" }),
    C("G", "pressureGauge", {}),
  ]);
  const conns = [
    L("l1", "HPU", "P", "M", "A"), L("l2", "M", "B", "HPU", "T", "return"),
    L("l3", "HPU", "P", "G", "P"),
  ];
  globalThis.rgzFluidSolve._dyn = null;
  let p1 = null, p2 = null, t = 0;
  const comps = mk();
  for (let i = 0; i < 60; i++) {
    const m = globalThis.rgzFluidSolve({ fluid: "oil", components: comps, connections: conns, dt: 0.05, time: t });
    if (Math.abs(t - 0.45) < 0.026) p1 = m.comp.G.pressureBar;
    if (Math.abs(t - 2.45) < 0.026) p2 = m.comp.G.pressureBar;
    t += 0.05;
  }
  ok(p1 !== null && p1 < 40, "early pump pressure low (5 N·m ≈ 13+ bar)", p1 && p1.toFixed(1));
  ok(p2 !== null && p2 > 70, "late pump pressure high (40 N·m ≈ 100+ bar)", p2 && p2.toFixed(1));
  ok(p1 !== null && p2 !== null && p2 - p1 > 55, "torque profile lifts pressure by ~88 bar of offset", (p2 - p1).toFixed(1));
}

console.log("\n== HYD 23: formula load profile sin(t) + x^2 (mixed variables) ==");
// load = 800 + 1200*sin(pi*t) + 2500*x^2  (kg) — uses t AND x together.
{
  const comps = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "left", ratedFlowLpm: 40, pressureDropBar: 5 }),
    C("CYL", "cylinderDA", { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 200, loadMode: "formula", loadProfile: "800 + 1200*sin(pi*t) + 2500*x^2", simPosition: 0.1 }),
    C("G_A", "pressureGauge", {}),
  ];
  const conns = [
    L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"),
    L("l3", "V", "A", "CYL", "A"), L("l4", "V", "B", "CYL", "B"),
    L("l5", "V", "A", "G_A", "P"),
  ];
  globalThis.rgzFluidSolve._dyn = null;
  globalThis.rgzFluidSolve._expr = {};
  // sample the reported applied load + chamber pressure at several (t, x) combos
  const probe = (tSim, pos) => {
    comps[2].props.simPosition = pos;
    let m = null;
    for (let i = 0; i < 3; i++) m = globalThis.rgzFluidSolve({ fluid: "oil", components: comps, connections: conns, dt: 0.05, time: tSim + i * 0.05 });
    return m;
  };
  const m1 = probe(0.5, 0.1);   // expect load ≈ 800 + 1200*sin(~0.5π..) + 25 ≈ +high
  const load1 = m1.cylinders[0].loadKg;
  const expect1 = 800 + 1200 * Math.sin(Math.PI * 0.55) + 2500 * 0.01;
  ok(Math.abs(load1 - expect1) < 90, "formula load ≈ 800+1200*sin(pi*0.55)+2500*0.1^2", load1.toFixed(0) + " vs " + expect1.toFixed(0));
  const m2 = probe(1.5, 0.9);   // sin(1.55π)≈-0.987 → 800-1184+2025 = 1641
  const load2 = m2.cylinders[0].loadKg;
  const expect2 = 800 + 1200 * Math.sin(Math.PI * 1.55) + 2500 * 0.81;
  ok(Math.abs(load2 - expect2) < 90, "formula tracks both t and x at (1.5 s, 0.9)", load2.toFixed(0) + " vs " + expect2.toFixed(0));
  const m3 = probe(2.5, 0.9);   // sin(2.55π)≈+0.987 → 800+1184+2025 ≈ 4009 → capped by nothing, higher than m2
  ok(m3.cylinders[0].loadKg > m2.cylinders[0].loadKg + 800, "sin branch swings load up half a cycle later", m3.cylinders[0].loadKg.toFixed(0));
  // pressure responds to the formula (not to the constant 200 kg fallback)
  ok(m1.comp.G_A.pressureBar > 60, "chamber pressure follows formula load, not the 200 kg fallback", m1.comp.G_A.pressureBar.toFixed(1));
}

console.log("\n== HYD 24: formula helpers + invalid profile warning ==");
{
  const comps = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("M", "hydraulicMotor", { displacementCcRev: 25, loadNm: 5, loadMode: "formula", loadProfile: "min(40, 5 + 35*ramp(t, 0, 2)) + 4*cos(t)" }),
    C("G", "pressureGauge", {}),
  ];
  const conns = [
    L("l1", "HPU", "P", "M", "A"), L("l2", "M", "B", "HPU", "T", "return"),
    L("l3", "HPU", "P", "G", "P"),
  ];
  globalThis.rgzFluidSolve._dyn = null;
  const m0 = globalThis.rgzFluidSolve({ fluid: "oil", components: comps, connections: conns, dt: 0.05, time: 0 });
  const m2s = globalThis.rgzFluidSolve({ fluid: "oil", components: comps, connections: conns, dt: 0.05, time: 2.5 });
  ok(Math.abs(m0.motors[0].loadNm - (5 + 4)) < 1.2, "ramp(t,0,2)=0 at t=0, cos(0)=1 → 9 N·m", m0.motors[0].loadNm.toFixed(2));
  ok(m2s.motors[0].loadNm > 30, "ramp saturates to 40 N·m cap (+cos) at t=2.5 s", m2s.motors[0].loadNm.toFixed(2));
  // invalid profile → warning once + fallback to constant
  const bad = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("M2", "hydraulicMotor", { displacementCcRev: 25, loadNm: 5, loadMode: "formula", loadProfile: "nonsense((" }),
  ];
  const conns2 = [L("l1", "HPU", "P", "M2", "A"), L("l2", "M2", "B", "HPU", "T", "return")];
  globalThis.rgzFluidSolve._dyn = null;
  const mb = globalThis.rgzFluidSolve({ fluid: "oil", components: bad, connections: conns2, dt: 0.05, time: 0 });
  ok(mb.motors[0].loadNm === 5, "unparseable formula falls back to the constant load", mb.motors[0].loadNm);
  ok((mb.warnings || []).some((w) => /load profile could not be parsed/i.test(w)), "parse failure surfaces a warning to the user", (mb.warnings || []).join(" | ").slice(0, 90));
  // legacy pure-number profile now acts as a constant expression (not silently ignored)
  const num1 = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("M3", "hydraulicMotor", { displacementCcRev: 25, loadNm: 5, loadMode: "formula", loadProfile: "42" }),
  ];
  globalThis.rgzFluidSolve._dyn = null;
  const mn = globalThis.rgzFluidSolve({ fluid: "oil", components: num1, connections: [L("l1", "HPU", "P", "M3", "A"), L("l2", "M3", "B", "HPU", "T")], dt: 0.05, time: 0 });
  ok(Math.abs(mn.motors[0].loadNm - 42) < 0.01, "bare number profile = constant formula", mn.motors[0].loadNm);
}

console.log(`\n==== RESULT: ${PASS} passed, ${FAIL} failed ====`);
process.exit(FAIL ? 1 : 0);
