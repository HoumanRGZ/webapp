// Standalone physics tests for rgzFluidSolve (run: node test-solver.mjs)
import fs from "fs";
const src = fs.readFileSync(new URL("./solver.js", import.meta.url), "utf8");
eval(src + "\nglobalThis.rgzFluidSolve = rgzFluidSolve;");

let PASS = 0, FAIL = 0;
function ok(cond, name, detail) {
  if (cond) { PASS++; console.log("  PASS", name, detail ?? ""); }
  else { FAIL++; console.log("  FAIL", name, "=>", detail); }
}
const C = (id, type, props = {}, x = 0, y = 0) => ({ id, type, label: id, x, y, rotation: 0, props });
const L = (id, a, pa, b, pb, lt = "pressure", d = 12, len = 1) => ({ id, from: { componentId: a, portId: pa }, to: { componentId: b, portId: pb }, lineType: lt, properties: { tubeIdMm: d, lengthM: len } });
function run(fluid, comps, conns, ticks = 40, dt = 0.05, mutate = null) {
  globalThis.rgzFluidSolve._dyn = null;
  let m, t = 0;
  for (let i = 0; i < ticks; i++) {
    if (mutate) mutate(i, comps);
    m = globalThis.rgzFluidSolve({ fluid, components: comps, connections: conns, dt, time: t });
    t += dt;
  }
  return m;
}

console.log("\n== HYD 1: powerPack + 4/3 closed-center, LEFT = cylinder extends ==");
{
  const comps = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "left", ratedFlowLpm: 40, pressureDropBar: 5 }),
    C("CYL", "cylinderDA", { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 350, simPosition: 0.2 }),
    C("G_P", "pressureGauge", {}), C("G_A", "pressureGauge", {}),
  ];
  const conns = [
    L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"),
    L("l3", "V", "A", "CYL", "A"), L("l4", "V", "B", "CYL", "B"),
    L("l5", "HPU", "P", "G_P", "P"), L("l6", "V", "A", "G_A", "P"),
  ];
  const m = run("oil", comps, conns);
  const v = m.cylinders[0].speedMmS, pPump = m.comp.G_P.pressureBar, pA = m.comp.G_A.pressureBar;
  ok(v > 100 && v < 160, "cylinder extends ~134 mm/s", v.toFixed(1));
  ok(pA > 5 && pA < 40, "cap-end pressure near load pressure (11-25 bar)", pA.toFixed(1));
  ok(pPump >= pA, "pump pressure >= chamber pressure", pPump.toFixed(1) + " vs " + pA.toFixed(1));
}

console.log("\n== HYD 2: same circuit, valve CENTERED (closed center) ==");
{
  const comps = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "center", ratedFlowLpm: 40, pressureDropBar: 5 }),
    C("CYL", "cylinderDA", { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 350, simPosition: 0.2 }),
    C("G_P", "pressureGauge", {}), C("G_A", "pressureGauge", {}),
  ];
  const conns = [
    L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"),
    L("l3", "V", "A", "CYL", "A"), L("l4", "V", "B", "CYL", "B"),
    L("l5", "HPU", "P", "G_P", "P"), L("l6", "V", "A", "G_A", "P"),
  ];
  const m = run("oil", comps, conns);
  const pPump = m.comp.G_P.pressureBar, pA = m.comp.G_A.pressureBar, v = m.cylinders[0].speedMmS;
  ok(Math.abs(v) < 1, "cylinder stands still", v.toFixed(2));
  ok(pPump > 145 && pPump < 172, "pump deadheads at relief ~160 bar", pPump.toFixed(1));
  ok(pA < 1, "gauge downstream of CLOSED center reads ~0 (user bug #2)", pA.toFixed(2));
  ok(m.warnings.some(w => /relief/i.test(w)), "warns about relief deadhead", m.warnings.join(" | "));
}

console.log("\n== HYD 3: adjustable flow control (meter-in) changes speed ==");
{
  const build = (opening) => ([
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "left", ratedFlowLpm: 40, pressureDropBar: 5 }),
    C("FC", "flowControl", { openingPercent: opening, pressureCompensated: false, maxFlowLpm: 60 }),
    C("CYL", "cylinderDA", { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 350, simPosition: 0.2 }),
  ]);
  const conns = [
    L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"),
    L("l3", "V", "A", "FC", "A"), L("l4", "FC", "B", "CYL", "A"), L("l5", "V", "B", "CYL", "B"),
  ];
  const mOpen43 = run("oil", build(43), conns).cylinders[0].speedMmS;   // kv 17 -> passes 25 at ~2bar? (25/17)^2=2.2
  const mTiny = run("oil", build(6), conns);                            // kv 0.66 -> capacity at relief ~8 L/min
  const vTiny = mTiny.cylinders[0].speedMmS, pTiny = mTiny.pressureBar;
  ok(mOpen43 > 100, "43% opening ~full speed", mOpen43.toFixed(1));
  ok(vTiny < mOpen43 * 0.55, "6% opening much slower", vTiny.toFixed(1) + " vs " + mOpen43.toFixed(1));
  ok(pTiny > 120, "restrictive FC raises pump pressure toward relief", pTiny.toFixed(1));
}

console.log("\n== HYD 4: pressure reducing valve holds downstream pressure ==");
{
  const build = (outlet) => {
    const comps = [
      C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
      C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "left", ratedFlowLpm: 40, pressureDropBar: 5 }),
      C("RV", "reducingValve", { outletBar: outlet }),
      C("CYL", "cylinderDA", { boreMm: 100, rodMm: 55, strokeMm: 400, loadKg: 3000, simPosition: 0.2 }),
      C("G_A", "pressureGauge", {}),
    ];
    const conns = [
      L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"),
      L("l3", "V", "A", "RV", "P"), L("l4", "RV", "A", "CYL", "A"), L("l5", "RV", "T", "HPU", "T", "return"),
      L("l6", "V", "B", "CYL", "B"), L("l7", "RV", "A", "G_A", "P"),
    ];
    return [comps, conns];
  };
  // 3000 kg on 100mm bore needs 37.5 bar -> below setting 60: downstream ~ load pressure
  let [c1, x1] = build(60);
  const m1 = run("oil", c1, x1);
  const pA1 = m1.comp.G_A.pressureBar, v1 = m1.cylinders[0].speedMmS;
  ok(pA1 > 25 && pA1 < 62, "downstream pressure below setting (load-dictated)", pA1.toFixed(1));
  ok(v1 > 1, "cylinder can move", v1.toFixed(1));
  // heavy load stall test: 6000 kg needs 75 bar > setting 40 -> stalls, p_A ~= 40
  const heavy = () => {
    const comps = [
      C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
      C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "left", ratedFlowLpm: 40, pressureDropBar: 5 }),
      C("RV", "reducingValve", { outletBar: 40 }),
      C("CYL", "cylinderDA", { boreMm: 100, rodMm: 55, strokeMm: 400, loadKg: 6000, simPosition: 0.2 }),
      C("G_A", "pressureGauge", {}),
    ];
    const conns = [
      L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"),
      L("l3", "V", "A", "RV", "P"), L("l4", "RV", "A", "CYL", "A"), L("l5", "RV", "T", "HPU", "T", "return"),
      L("l6", "V", "B", "CYL", "B"), L("l7", "RV", "A", "G_A", "P"),
    ];
    return [comps, conns];
  };
  const [c2, x2] = heavy();
  const m2 = run("oil", c2, x2);
  const pA2 = m2.comp.G_A.pressureBar, v2 = m2.cylinders[0].speedMmS;
  ok(v2 < -1, "overpowering load yields downward (3-way valve relieves downstream)", v2.toFixed(2));
  ok(pA2 > 32 && pA2 < 48, "downstream clamped near 40 bar setting (user bug #1)", pA2.toFixed(1));
}

console.log("\n== HYD 5: variable pump destrokes at compensator ==");
{
  const comps = [
    C("T", "tank", {}), C("PU", "pumpVariable", { flowLpm: 32, compensatorBar: 120, maxPressureBar: 210 }),
    C("RV", "reliefValve", { settingBar: 160 }),
    C("SV", "shutoffValve", { open: false }),
    C("G", "pressureGauge", {}),
  ];
  const conns = [
    L("l1", "PU", "S", "T", "T", "suction"), L("l2", "PU", "P", "SV", "A"), L("l3", "SV", "B", "T", "T"),
    L("l4", "PU", "P", "RV", "P"), L("l5", "RV", "T", "T", "T", "return"), L("l6", "PU", "P", "G", "P"),
  ];
  const m = run("oil", comps, conns);
  const p = m.comp.G.pressureBar;
  ok(p > 105 && p < 135, "deadheaded at compensator ~120 bar", p.toFixed(1));
  ok(m.pressureBar > 105 && m.pressureBar < 135, "system pressure follows", m.pressureBar.toFixed(1));
}

console.log("\n== HYD 6: check valve blocks reverse ==");
{
  const comps = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("CV", "checkValve", { crackingBar: 0.5 }),
    C("G1", "pressureGauge", {}), C("G2", "pressureGauge", {}),
  ];
  // flow attempted B -> A (reverse): pump on B side
  const conns = [L("l1", "HPU", "P", "CV", "B"), L("l2", "HPU", "T", "CV", "A", "return"), L("l3", "HPU", "P", "G1", "P"), L("l4", "CV", "A", "G2", "P")];
  const m = run("oil", comps, conns);
  ok(m.comp.G1.pressureBar > 145, "upstream deadheads at relief", m.comp.G1.pressureBar.toFixed(1));
  ok(m.comp.G2.pressureBar < 1, "reverse side stays ~0", m.comp.G2.pressureBar.toFixed(2));
}

console.log("\n== HYD 7: regenerative center is faster than normal extend ==");
{
  const build = (center, state) => {
    const comps = [
      C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
      C("V", "directionalValve", { ports: "4", positions: "3", center, spoolState: state, ratedFlowLpm: 60, pressureDropBar: 3 }),
      C("CYL", "cylinderDA", { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 30, simPosition: 0.2 }),
    ];
    const conns = [L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"), L("l3", "V", "A", "CYL", "A"), L("l4", "V", "B", "CYL", "B")];
    return [comps, conns];
  };
  const [cn, xn] = build("closed", "left");
  const vNorm = run("oil", cn, xn).cylinders[0].speedMmS;
  const [cr, xr] = build("regenerative", "center");
  const vRegen = run("oil", cr, xr).cylinders[0].speedMmS;
  ok(vNorm > 80 && vNorm < 160, "normal extend plausible", vNorm.toFixed(1));
  ok(vRegen > vNorm * 1.15, "regen extend faster (diff area)", vRegen.toFixed(1) + " vs " + vNorm.toFixed(1));
}

console.log("\n== HYD 8: single-acting cylinder extends and spring-returns ==");
{
  const comps = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("V", "directionalValve", { ports: "3", positions: "2", center: "closed", spoolState: "left", ratedFlowLpm: 40, pressureDropBar: 5 }),
    C("CYL", "cylinderSA", { boreMm: 50, strokeMm: 300, loadKg: 20, springReturn: true, simPosition: 0.15 }),
  ];
  const conns = [L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"), L("l3", "V", "A", "CYL", "A")];
  const mExt = run("oil", comps.map(c => ({ ...c, props: { ...c.props } })), conns);
  ok(mExt.cylinders[0].speedMmS > 50, "SA extends", mExt.cylinders[0].speedMmS.toFixed(1));
  const mRet = run("oil", comps.map(c => (c.id === "V" ? { ...c, props: { ...c.props, spoolState: "right" } } : { ...c, props: { ...c.props } })), conns);
  ok(mRet.cylinders[0].speedMmS < -1, "SA spring retracts when valve vented", mRet.cylinders[0].speedMmS.toFixed(1));
}

console.log("\n== HYD 9: servo/proportional valve command scales speed ==");
{
  const build = (cmd) => ([
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("SV", "servoValve", { commandPercent: cmd, ratedFlowLpm: 16 }),
    C("CYL", "cylinderDA", { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 300, simPosition: 0.2 }),
  ]);
  const conns = [L("l1", "HPU", "P", "SV", "P"), L("l2", "SV", "T", "HPU", "T", "return"), L("l3", "SV", "A", "CYL", "A"), L("l4", "SV", "B", "CYL", "B")];
  const v100 = run("oil", build(100), conns).cylinders[0].speedMmS;
  const v25 = run("oil", build(14), conns).cylinders[0].speedMmS;
  const vRev = run("oil", build(-80), conns).cylinders[0].speedMmS;
  ok(v100 > 60, "100% command fast", v100.toFixed(1));
  ok(v25 > 1 && v25 < v100 * 0.65, "14% command slower (metering below pump flow)", v25.toFixed(1) + " vs " + v100.toFixed(1));
  ok(vRev < -20 && vRev > -400, "negative command retracts at bounded speed", vRev.toFixed(1));
}

console.log("\n== PNE A: FRL regulator clamps downstream pressure ==");
{
  const comps = [
    C("CP", "compressorFixed", { flowLpm: 500, maxPressureBar: 8 }),
    C("EX", "exhaust", {}),
    C("FRL", "frlUnit", { regulatorBar: 6, filterMicron: 5 }),
    C("G1", "pressureGauge", {}), C("G2", "pressureGauge", {}),
  ];
  const conns = [
    L("l1", "CP", "P", "FRL", "P", "pressure", 6), L("l2", "CP", "S", "EX", "T", "suction", 6),
    L("l3", "CP", "P", "G1", "P", "pressure", 6), L("l4", "FRL", "A", "G2", "P", "pressure", 6),
  ];
  const m = run("air", comps, conns);
  ok(m.comp.G1.pressureBar > 6.2, "upstream high (comp pushes to max)", m.comp.G1.pressureBar.toFixed(2));
  ok(Math.abs(m.comp.G2.pressureBar - 6) < 0.8, "downstream regulated ~6 bar", m.comp.G2.pressureBar.toFixed(2));
}

console.log("\n== PNE B: 5/2 + DA cylinder, exhaust restrictor slows motion ==");
{
  const build = (opening) => ([
    C("CP", "compressorFixed", { flowLpm: 500, maxPressureBar: 8 }),
    C("EX", "exhaust", {}),
    C("FRL", "frlUnit", { regulatorBar: 6 }),
    C("V", "directionalValve", { ports: "5", positions: "2", center: "closed", spoolState: "left", ratedFlowLpm: 600, pressureDropBar: 0.3 }),
    C("FC", "flowControl", { openingPercent: opening, maxFlowLpm: 400 }),
    C("CYL", "cylinderDA", { boreMm: 40, rodMm: 16, strokeMm: 400, loadKg: 20, simPosition: 0.1 }),
  ]);
  const conns = [
    L("l1", "CP", "P", "FRL", "P", "pressure", 6), L("l2", "CP", "S", "EX", "T", "suction", 6),
    L("l3", "FRL", "A", "V", "P", "pressure", 6), L("l4", "V", "T", "FC", "A", "pressure", 6),
    L("l5", "FC", "B", "EX", "T", "return", 6),
    L("l6", "V", "A", "CYL", "A", "pressure", 6), L("l7", "V", "B", "CYL", "B", "pressure", 6),
  ];
  const vOpen = run("air", build(100), conns).cylinders[0].speedMmS;
  const vSmall = run("air", build(8), conns).cylinders[0].speedMmS;
  ok(vOpen > 30, "open exhaust restrictor: moves", vOpen.toFixed(1));
  ok(vSmall < vOpen * 0.6, "80% closed restrictor: much slower", vSmall.toFixed(1) + " vs " + vOpen.toFixed(1));
}

console.log("\n== PNE C: shuttle OR vs two-pressure AND ==");
{
  const base = (mid) => ([
    C("CP", "compressorFixed", { flowLpm: 500, maxPressureBar: 8 }),
    C("EX", "exhaust", {}),
    C("V1", "directionalValve", { ports: "3", positions: "2", spoolState: "left", ratedFlowLpm: 600, pressureDropBar: 0.3 }),
    C("V2", "directionalValve", { ports: "3", positions: "2", spoolState: "right", ratedFlowLpm: 600, pressureDropBar: 0.3 }),
    C(mid, mid === "shuttleValve" ? "shuttleValve" : "twoPressureValve", {}),
    C("G", "pressureGauge", {}),
  ]);
  const conns = [
    L("l1", "CP", "P", "V1", "P", "pressure", 6), L("l2", "CP", "P", "V2", "P", "pressure", 6), L("l3", "CP", "S", "EX", "T", "suction", 6),
    L("l4", "V1", "A", "V1X", "A", "pressure", 6),
  ];
  // shuttle: V1 pressurised -> out high
  const compsS = base("shuttleValve"), connsS = [
    L("l1", "CP", "P", "V1", "P", "pressure", 6), L("l2", "CP", "P", "V2", "P", "pressure", 6), L("l3", "CP", "S", "EX", "T", "suction", 6),
    L("l4", "V1", "A", "shuttleValve", "A", "pressure", 6), L("l5", "V2", "A", "shuttleValve", "B", "pressure", 6), L("l6", "shuttleValve", "X", "G", "P", "pressure", 6),
  ];
  compsS.forEach(c => { if (c.type !== "directionalValve") return; });
  const mS = run("air", compsS, connsS);
  ok(mS.comp.G.pressureBar > 4, "OR: one signal is enough", mS.comp.G.pressureBar.toFixed(2));
  const compsA = base("twoPressureValve"), connsA = [
    L("l1", "CP", "P", "V1", "P", "pressure", 6), L("l2", "CP", "P", "V2", "P", "pressure", 6), L("l3", "CP", "S", "EX", "T", "suction", 6),
    L("l4", "V1", "A", "twoPressureValve", "A", "pressure", 6), L("l5", "V2", "A", "twoPressureValve", "B", "pressure", 6), L("l6", "twoPressureValve", "X", "G", "P", "pressure", 6),
  ];
  const mA = run("air", compsA, connsA);
  ok(mA.comp.G.pressureBar < 1.5, "AND: one signal missing -> ~0", mA.comp.G.pressureBar.toFixed(2));
  const both = compsA.map(c => c.id === "V2" ? { ...c, props: { ...c.props, spoolState: "left" } } : c);
  const mA2 = run("air", both, connsA);
  ok(mA2.comp.G.pressureBar > 4, "AND: both signals -> high", mA2.comp.G.pressureBar.toFixed(2));
}

console.log("\n== PNE D: time-delay valve opens after delay ==");
{
  const comps = [
    C("CP", "compressorFixed", { flowLpm: 500, maxPressureBar: 8 }),
    C("EX", "exhaust", {}),
    C("TD", "pneumaticTimeDelayValve", { delayS: 1, mode: "on-delay" }),
    C("G", "pressureGauge", {}),
  ];
  const conns = [
    L("l1", "CP", "P", "TD", "P", "pressure", 6), L("l2", "CP", "S", "EX", "T", "suction", 6), L("l3", "TD", "A", "G", "P", "pressure", 6),
  ];
  globalThis.rgzFluidSolve._dyn = null;
  const mEarly = globalThis.rgzFluidSolve({ fluid: "air", components: comps, connections: conns, dt: 0.05, time: 0.2 });
  let mLate = mEarly;
  for (let t = 0.25; t < 2.5; t += 0.1) mLate = globalThis.rgzFluidSolve({ fluid: "air", components: comps, connections: conns, dt: 0.1, time: t });
  ok(mEarly.comp.G.pressureBar < 1, "before delay: A ~0", mEarly.comp.G.pressureBar.toFixed(2));
  ok(mLate.comp.G.pressureBar > 4, "after 1 s: A pressurised", mLate.comp.G.pressureBar.toFixed(2));
}

console.log("\n== HYD 10: closed-center valve + stalled motor = 0 rpm, downstream gauge 0 (UI regression) ==");
{
  const comps = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "center", ratedFlowLpm: 40, pressureDropBar: 5 }),
    C("M", "hydraulicMotor", { displacementCcRev: 40, loadNm: 25 }),
    C("FS", "flowSwitch", { switchLpm: 15 }),
    C("G", "pressureGauge", {}),
  ];
  const conns = [
    L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"),
    L("l3", "V", "A", "FS", "A"), L("l4", "FS", "B", "M", "A"),
    L("l5", "M", "B", "V", "B", "return"), L("l6", "FS", "B", "G", "P"),
  ];
  const m = run("oil", comps, conns);
  const mot = m.motors[0];
  ok(Math.abs(mot.rpm) < 0.5 && mot.flowLpm < 0.5, "stalled motor: rpm & flow are 0", mot.rpm.toFixed(2) + "rpm " + mot.flowLpm.toFixed(2) + "lpm");
  ok(Math.abs(m.comp.FS.flowLpm) < 0.5, "flow switch sees 0 L/min", m.comp.FS.flowLpm.toFixed(2));
  ok(m.comp.G.pressureBar < 1, "gauge downstream of closed center reads ~0 (the reported bug)", m.comp.G.pressureBar.toFixed(2));
  ok(Math.abs(m.comp.HPU.pressureBar - 160) < 12, "pump deadheads at its relief setting", m.comp.HPU.pressureBar.toFixed(1));
  ok(m.pressureBar <= 200, "no phantom pressure explosions", m.pressureBar.toFixed(1));
}

console.log("\n== HYD 11: retract with load: pump-limited speed, no vacuum on the pump line (UI regression) ==");
{
  const comps = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "right", ratedFlowLpm: 40, pressureDropBar: 5 }),
    C("CYL", "cylinderDA", { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 350, simPosition: 0.5 }),
  ];
  const conns = [
    L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"),
    L("l3", "V", "A", "CYL", "A"), L("l4", "V", "B", "CYL", "B", "return"),
  ];
  const m = run("oil", comps, conns);
  const cy = m.cylinders[0];
  // rod side fills at 25 L/min -> v = 25 L/min / 20.99 cm^2 = -198.7 mm/s; mass conservation
  ok(cy.speedMmS < -150 && cy.speedMmS > -260, "retract speed is pump-fill limited (not a vacuum-powered runaway)", cy.speedMmS.toFixed(1));
  ok(m.comp.HPU.pressureBar > -0.5, "pump outlet is not dragged into vacuum", m.comp.HPU.pressureBar.toFixed(2));
  ok(m.comp.V.pressureBar > -1.2 && m.comp.V.supplyBar > -1.2, "valve ports stay out of deep vacuum",
    m.comp.V.pressureBar.toFixed(2) + "/" + m.comp.V.supplyBar.toFixed(2));
  ok(m.comp.HPU.pressureBar < 80, "retract against moderate load stays below relief", m.comp.HPU.pressureBar.toFixed(1));
}

console.log("\n== HYD 12: meter-OUT flow control slows the cylinder via rod-side back-pressure (needs intensification above relief) ==");
{
  const build = (opening, spool) => ([
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: spool || "left", ratedFlowLpm: 40, pressureDropBar: 5 }),
    C("FC", "flowControl", { openingPercent: opening, maxFlowLpm: 60, pressureCompensated: false }),
    C("CYL", "cylinderDA", { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 350, simPosition: 0.2 }),
  ]);
  const conns = [
    L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"),
    L("l3", "V", "A", "CYL", "A"), L("l4", "V", "B", "FC", "A", "return"), L("l5", "FC", "B", "CYL", "B", "return"),
  ];
  const vOpen = run("oil", build(100), conns).cylinders[0].speedMmS;
  const vMid = run("oil", build(20), conns).cylinders[0].speedMmS;
  const m6 = run("oil", build(6), conns);
  const v6 = m6.cylinders[0].speedMmS;
  const v3 = run("oil", build(3), conns).cylinders[0].speedMmS;
  // 43-100%: sustainable below relief -> full speed is PHYSICALLY correct for
  // meter-out with a fixed pump (back-pressure only adds load). At 6% the
  // intensified rod pressure needed (~630 bar) exceeds relief, so the cylinder
  // MUST slow; theory: pA=160 -> pB=236 -> qB=kv*sqrt(236)=10.2 -> v=81.
  ok(vOpen > 120 && Math.abs(vMid - vOpen) < 8, "open/mid openings: full speed with elevated back-pressure", vOpen.toFixed(1) + " / " + vMid.toFixed(1));
  ok(v6 > 55 && v6 < 105, "6% opening: slowed to the intensification-limited speed (theory ~81)", v6.toFixed(1));
  ok(v3 < v6 * 0.6, "3% opening: much slower still", v3.toFixed(1) + " vs " + v6.toFixed(1));
  ok(m6.comp.HPU.pressureBar > 145, "throttled meter-out deadheads the pump at relief", m6.comp.HPU.pressureBar.toFixed(1));
}

console.log("\n== Robustness: real example circuits (no crash, sane values) ==");
{
  const dir = new URL("./models/", import.meta.url).pathname;
  const files = fs.existsSync(dir) ? fs.readdirSync(dir).filter((f) => f.endsWith(".json")) : [];
  if (!files.length) { /* session-local dumps absent; scenario tests above are the gate */ }
  for (const f of files) {
    try {
      const model = JSON.parse(fs.readFileSync(dir + f, "utf8"));
      const m = run("oil", model.components, model.connections, 10);
      const sane = Number.isFinite(m.pressureBar) && m.pressureBar >= 0 && m.pressureBar < 1500;
      ok(sane, f, "p=" + m.pressureBar.toFixed(1) + " warn=" + m.warnings.length);
    } catch (e) { ok(false, f, e.message); }
  }
}

console.log("\n== HYD 13: cartridge manifold block = through-gallery, NOT a junction (P must NOT short to T) ==");
{
  const comps = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("HIC", "cartridgeManifoldBlock", {}),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "center" }),
  ];
  const conns = [
    L("l1", "HPU", "P", "HIC", "P"), L("l2", "HIC", "A", "V", "P"),
    L("l3", "V", "T", "HIC", "T"), L("l4", "HIC", "T", "HPU", "T", "return"),
  ];
  const m = run("oil", comps, conns);
  ok(m.pressureBar > 145 && m.pressureBar < 175, "pump deadheads at relief through manifold (no P-T short)", m.pressureBar.toFixed(1));
  const comps2 = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("HIC", "cartridgeManifoldBlock", {}),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "left" }),
    C("CYL", "cylinderDA", { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 350, simPosition: 0.2 }),
  ];
  const conns2 = [
    L("l1", "HPU", "P", "HIC", "P"), L("l2", "HIC", "A", "V", "P"),
    L("l3", "V", "T", "HIC", "T"), L("l4", "HIC", "T", "HPU", "T", "return"),
    L("l5", "V", "A", "CYL", "A"), L("l6", "V", "B", "CYL", "B"),
  ];
  const m2 = run("oil", comps2, conns2);
  ok(m2.cylinders[0].speedMmS > 100, "cylinder extends through manifold P->A gallery at ~134 mm/s", m2.cylinders[0].speedMmS.toFixed(1));
}

console.log("\n== HYD 14: sequence clamp-and-work retract (bypass check parallel to seq valve) ==");
{
  const build = (withCV) => ([
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "left" }),
    C("CL", "cylinderDA", { boreMm: 50, rodMm: 28, strokeMm: 250, loadKg: 150, simPosition: 0.1 }),
    C("SV", "sequenceValve", { settingBar: 55 }),
    C("WK", "cylinderDA", { boreMm: 80, rodMm: 45, strokeMm: 400, loadKg: 500, simPosition: 0.1 }),
    ...(withCV ? [C("CV", "checkValve", { crackingBar: 0.5 })] : []),
  ]);
  const connsOf = (withCV) => [
    L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"),
    L("l3", "V", "A", "CL", "A"), L("l4", "V", "A", "SV", "P"),
    L("l5", "SV", "A", "WK", "A"),
    L("l6", "CL", "B", "V", "B", "return"), L("l7", "WK", "B", "V", "B", "return"),
    L("l8", "SV", "T", "HPU", "T", "drain"),
    ...(withCV ? [L("l9", "WK", "A", "CV", "A"), L("l10", "CV", "B", "SV", "P")] : []),
  ];
  // extend order: clamp first, then work at full speed after sequence opens
  const order = (withCV, spool, secs) => {
    const comps = build(withCV), conns = connsOf(withCV);
    const V = comps.find(c => c.id === "V");
    globalThis.rgzFluidSolve._dyn = null;
    V.props.spoolState = spool; let m, t = 0, dt = 0.05, sawClampFirst = false, sawWorkAfter = false;
    const n = Math.round(secs / dt);
    for (let i = 0; i < n; i++) {
      m = globalThis.rgzFluidSolve({ fluid: "oil", components: comps, connections: conns, dt, time: t }); t += dt;
      for (const cy of m.cylinders) {
        const c = comps.find(x => x.id === cy.id);
        c.props.simPosition = Math.min(1, Math.max(0, c.props.simPosition + cy.speedMmS * dt / (c.props.strokeMm || 300)));
      }
      if (comps.find(c => c.id === "CL").props.simPosition > 0.95 && comps.find(c => c.id === "WK").props.simPosition < 0.2) sawClampFirst = true;
      if (sawClampFirst && comps.find(c => c.id === "WK").props.simPosition > 0.5) sawWorkAfter = true;
    }
    return { m, comps, conns, sawClampFirst, sawWorkAfter };
  };
  const ext = order(true, "left", 9);
  ok(ext.sawClampFirst && ext.sawWorkAfter, "extend sequence: clamp completes first, then work extends");
  // retract: without check the work cylinder is trapped (< 1 mm/s); with check it retracts fast
  const trap = order(false, "right", 8);
  ok(Math.abs(trap.m.cylinders.find(c => c.label === "WK").speedMmS) < 1, "WITHOUT bypass check: work cap oil trapped by seq valve (documents old bug)", trap.m.cylinders.find(c => c.label === "WK").speedMmS.toFixed(2));
  const free = order(true, "right", 8);
  const wkFree = free.m.cylinders.find(c => c.label === "WK");
  const wkHome = free.comps.find(c => c.id === "WK").props.simPosition;
  ok(wkFree.speedMmS < -40 || wkHome < 0.05, "WITH bypass check: work retracts fast", wkFree.speedMmS.toFixed(1) + " pos=" + (wkHome * 100).toFixed(0) + "%");
}

console.log("\n== HYD 15: check valve hysteresis — forward free, reverse blocked ==");
{
  // forward: pump -> CV -> cylinder extends at full speed
  const compsF = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("CV", "checkValve", { crackingBar: 0.5 }),
    C("CYL", "cylinderDA", { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 200, simPosition: 0.2 }),
    C("GA", "pressureGauge", {}),
  ];
  const connsF = [L("l1", "HPU", "P", "CV", "A"), L("l2", "CV", "B", "CYL", "A"), L("l3", "CYL", "B", "HPU", "T", "return"), L("l4", "CYL", "A", "GA", "P")];
  const mF = run("oil", compsF, connsF);
  ok(mF.cylinders[0].speedMmS > 100, "forward through check valve extends at ~134", mF.cylinders[0].speedMmS.toFixed(1));
  // reverse isolation: pressurized side must NOT drain back through the check valve
  // (accumulator at 80 bar downstream of the check, pump centered/dead)
  const compsR = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("CV", "checkValve", { crackingBar: 0.5 }),
    C("ACC", "accumulator", { prechargeBar: 60, volumeL: 5, simChargeL: 2 }),
    C("GA", "pressureGauge", {}),
  ];
  const connsR = [L("l1", "HPU", "P", "CV", "A"), L("l2", "CV", "B", "ACC", "A"), L("l3", "ACC", "A", "GA", "P")];
  let pHighAfter = 0;
  {
    globalThis.rgzFluidSolve._dyn = null; let m, t = 0;
    for (let i = 0; i < 40; i++) { m = globalThis.rgzFluidSolve({ fluid: "oil", components: compsR, connections: connsR, dt: 0.05, time: t }); t += 0.05; }
    pHighAfter = m.comp.GA.pressureBar;
  }
  ok(pHighAfter > 55, "reverse side holds pressure, no backward drain through check (acc ~80 bar)", pHighAfter.toFixed(1));
}

console.log("\n== HYD 16: pilot-operated check valve load holding — extend / hold / pilot-released retract ==");
{
  const model = JSON.parse(fs.readFileSync(new URL("./models/hyd-simple-11-pcheck.json", import.meta.url), "utf8"));
  const comps = model.components.filter(c => c.type !== "textLabel");
  [["GA", "C-4", "A"], ["GB", "C-4", "B"]].forEach(([g, ci, pi]) => {
    comps.push({ id: g, type: "pressureGauge", label: g, x: 0, y: 0, rotation: 0, props: {} });
    model.connections.push({ id: g, from: { componentId: ci, portId: pi }, to: { componentId: g, portId: "P" }, lineType: "pressure", properties: { tubeIdMm: 12, lengthM: 1 } });
  });
  const V = comps.find(c => c.type === "directionalValve");
  const CY = comps.find(c => c.type === "cylinderDA");
  CY.props.simPosition = 0.1;
  globalThis.rgzFluidSolve._dyn = null;
  let m, t = 0; const dt = 0.05;
  const step = (sec) => {
    for (let i = 0, n = Math.round(sec / dt); i < n; i++) {
      m = globalThis.rgzFluidSolve({ fluid: "oil", components: comps, connections: model.connections, dt, time: t }); t += dt;
      CY.props.simPosition = Math.min(1, Math.max(0, CY.props.simPosition + m.cylinders[0].speedMmS * dt / (CY.props.strokeMm || 300)));
    }
  };
  V.props.spoolState = "left"; step(3);
  ok(CY.props.simPosition > 0.6, "PO check example: cylinder extends through the check valve", (CY.props.simPosition * 100).toFixed(0) + "%");
  V.props.spoolState = "center";
  step(2); const posH = CY.props.simPosition;
  step(2);
  ok(Math.abs(CY.props.simPosition - posH) < 0.02, "load held in center (PO check traps the cap side)", ((CY.props.simPosition - posH) * 100).toFixed(2) + "% drift");
  V.props.spoolState = "right"; step(1);
  ok(m.comp.GB.pressureBar < 40, "during retract the rod side reads working pressure (pilot cracked the check valve open)", m.comp.GB.pressureBar.toFixed(1) + " bar");
  step(2);
  ok(CY.props.simPosition < 0.15, "retract: pilot opens the check valve return path (no stuck circuit)", (CY.props.simPosition * 100).toFixed(0) + "%");
}

console.log("\n== HYD 17: slip-in logic 4-way bridge — piloted poppet pressure levels ==");
{
  const model = JSON.parse(fs.readFileSync(new URL("./models/hyd-cart-3-bridge.json", import.meta.url), "utf8"));
  const comps = model.components.filter(c => c.type !== "textLabel");
  [["GA", "C-4", "A"], ["GB", "C-4", "B"]].forEach(([g, ci, pi]) => {
    comps.push({ id: g, type: "pressureGauge", label: g, x: 0, y: 0, rotation: 0, props: {} });
    model.connections.push({ id: g, from: { componentId: ci, portId: pi }, to: { componentId: g, portId: "P" }, lineType: "pressure", properties: { tubeIdMm: 12, lengthM: 1 } });
  });
  const V = comps.find(c => c.type === "directionalValve");
  const CY = comps.find(c => c.type === "cylinderDA");
  CY.props.simPosition = 0.05;
  globalThis.rgzFluidSolve._dyn = null;
  let m, t = 0; const dt = 0.05;
  const step = (sec) => {
    for (let i = 0, n = Math.round(sec / dt); i < n; i++) {
      m = globalThis.rgzFluidSolve({ fluid: "oil", components: comps, connections: model.connections, dt, time: t }); t += dt;
      CY.props.simPosition = Math.min(1, Math.max(0, CY.props.simPosition + m.cylinders[0].speedMmS * dt / (CY.props.strokeMm || 300)));
    }
  };
  V.props.spoolState = "left"; step(2);
  const capWork = m.comp.GA.pressureBar, rodWork = m.comp.GB.pressureBar;
  ok(m.cylinders[0].speedMmS > 60, "bridge extends the press cylinder", m.cylinders[0].speedMmS.toFixed(0) + " mm/s");
  ok(capWork > 30 && capWork < 80, "pump works at load pressure (~50 bar for 2.5 t), not relief", capWork.toFixed(1) + " bar");
  ok(rodWork < 10, "open B->T leg keeps rod side near tank (phantom back-pressure regression)", rodWork.toFixed(1) + " bar");
  step(2.5);
  ok(CY.props.simPosition > 0.95 && m.comp.GA.pressureBar > 195, "deadhead: full press force at relief (210 bar)", m.comp.GA.pressureBar.toFixed(1) + " bar @ " + (CY.props.simPosition * 100).toFixed(0) + "%");
  V.props.spoolState = "center"; step(1);
  ok(m.comp["PG-5"].pressureBar < 5, "float centre: bridge opens P->T, pump unloads (< 5 bar)", m.comp["PG-5"].pressureBar.toFixed(1) + " bar");
  CY.props.simPosition = 1; globalThis.rgzFluidSolve._dyn = null;
  V.props.spoolState = "right"; step(3);
  ok(CY.props.simPosition < 0.2, "retract via P->B / A->T logic legs", (CY.props.simPosition * 100).toFixed(0) + "%");
}

console.log("\n== HYD 18: flow divider enforces the 50:50 split (both actuators move together, any load) ==");
{
  const C = (id, type, props = {}) => ({ id, type, label: id, x: 0, y: 0, rotation: 0, props });
  const L = (id, a, pa, b, pb) => ({ id, from: { componentId: a, portId: pa }, to: { componentId: b, portId: pb }, lineType: "pressure", properties: { tubeIdMm: 12, lengthM: 1 } });
  const comps = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "center" }),
    C("FD", "flowDivider", { splitPercentA: 50 }),
    C("C1", "cylinderDA", { boreMm: 50, rodMm: 28, strokeMm: 400, loadKg: 320, simPosition: 0.05 }),
    C("C2", "cylinderDA", { boreMm: 50, rodMm: 28, strokeMm: 400, loadKg: 40, simPosition: 0.05 }),
  ];
  const conns = [
    L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T"),
    L("l3", "V", "A", "FD", "P"), L("l4", "FD", "A", "C1", "A"), L("l5", "FD", "B", "C2", "A"),
    L("l6", "C1", "B", "V", "B"), L("l7", "C2", "B", "V", "B"),
  ];
  globalThis.rgzFluidSolve._dyn = null;
  let m, t = 0; const dt = 0.05;
  const run = (sec) => { for (let i = 0, n = Math.round(sec / dt); i < n; i++) {
    m = globalThis.rgzFluidSolve({ fluid: "oil", components: comps, connections: conns, dt, time: t }); t += dt;
    comps.forEach(c => { if (c.type === "cylinderDA") { const cy = m.cylinders.find(x => x.id === c.id); c.props.simPosition = Math.min(1, Math.max(0, c.props.simPosition + cy.speedMmS * dt / 400)); } });
  } };
  const V = comps[1];
  V.props.spoolState = "left"; run(1.0);
  const p1 = comps[3].props.simPosition, p2 = comps[4].props.simPosition;
  ok(m.cylinders[0].speedMmS > 60 && m.cylinders[1].speedMmS > 60, "heavily unequal loads (320 vs 40 kg): BOTH cylinders move in the first second", m.cylinders.map(c=>c.speedMmS.toFixed(0)).join("/") + " mm/s");
  ok(Math.abs(m.cylinders[0].speedMmS - m.cylinders[1].speedMmS) < 12, "speeds matched (50:50 split)", m.cylinders.map(c=>c.speedMmS.toFixed(0)).join("/"));
  ok(Math.abs(p1 - p2) < 0.06, "positions track (sync error < 6%)", (p1*100).toFixed(1) + "%/" + (p2*100).toFixed(1) + "%");
  run(2.6);
  ok(comps[3].props.simPosition > 0.93 && comps[4].props.simPosition > 0.93, "both cylinders reach the end together", (comps[3].props.simPosition*100).toFixed(0) + "%/" + (comps[4].props.simPosition*100).toFixed(0) + "%");
  V.props.spoolState = "right"; run(2.0);
  ok(Math.abs(m.cylinders[0].speedMmS - m.cylinders[1].speedMmS) < 25 && m.cylinders[0].speedMmS < -60, "combiner direction (retract) also meters equally", m.cylinders.map(c=>c.speedMmS.toFixed(0)).join("/"));
  ok(!(m.warnings||[]).some(w => /starved|cavitation/i.test(w)), "no fill-side cavitation while metered out", (m.warnings||[]).length + " warnings");
}

console.log("\n== HYD 19: selectable left/right DCV blocks ==");
{
  const C = (id, type, props = {}) => ({ id, type, label: id, x: 0, y: 0, rotation: 0, props });
  const L = (id, a, pa, b, pb) => ({ id, from: { componentId: a, portId: pa }, to: { componentId: b, portId: pb }, lineType: "pressure", properties: { tubeIdMm: 12, lengthM: 1 } });
  const mk = (vprops) => {
    const comps = [
      C("HPU", "powerPack", { flowLpm: 20, reliefSettingBar: 160 }),
      C("V", "directionalValve", Object.assign({ ports: "4", positions: "3", center: "closed", spoolState: "center" }, vprops)),
      C("C1", "cylinderDA", { boreMm: 50, rodMm: 28, strokeMm: 400, loadKg: 150, simPosition: 0.4 }),
    ];
    const conns = [
      L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T"),
      L("l3", "V", "A", "C1", "A"), L("l4", "V", "B", "C1", "B"),
    ];
    return { comps, conns };
  };
  const runFor = (m0, comps, conns, sec) => {
    let m = m0, t = 0; const dt = 0.05;
    for (let i = 0, n = Math.round(sec / dt); i < n; i++) {
      m = globalThis.rgzFluidSolve({ fluid: "oil", components: comps, connections: conns, dt, time: t }); t += dt;
      comps.forEach(c => { if (c.type === "cylinderDA") { const cy = m.cylinders.find(x => x.id === c.id); c.props.simPosition = Math.min(1, Math.max(0, c.props.simPosition + cy.speedMmS * dt / 400)); } });
    }
    return comps[2].props.simPosition;
  };
  // right spool with rightBlock = parallel behaves like a left spool (extends)
  globalThis.rgzFluidSolve._dyn = null;
  let d = mk({ spoolState: "right", rightBlock: "parallel" });
  const p1 = runFor(null, d.comps, d.conns, 1.5);
  ok(p1 > 0.6, "right spool + rightBlock=parallel EXTENDS the cylinder", (p1 * 100).toFixed(0) + "%");
  // left spool with leftBlock = closed blocks all motion (both envelopes shut)
  globalThis.rgzFluidSolve._dyn = null;
  d = mk({ spoolState: "left", leftBlock: "closed" });
  const p2 = runFor(null, d.comps, d.conns, 1.2);
  ok(Math.abs(p2 - 0.4) < 0.03, "left spool + leftBlock=closed traps the cylinder", (p2 * 100).toFixed(1) + "%");
  // leftBlock = float vents both chambers: heavy load pulls the cylinder down-ish / no drive
  globalThis.rgzFluidSolve._dyn = null;
  d = mk({ spoolState: "left", leftBlock: "crossover" });
  const p3 = runFor(null, d.comps, d.conns, 1.5);
  ok(p3 < 0.2, "left spool + leftBlock=crossover RETRACTS", (p3 * 100).toFixed(0) + "%");
  // legacy default (no block props): right = crossover as before
  globalThis.rgzFluidSolve._dyn = null;
  d = mk({ spoolState: "right" });
  const p4 = runFor(null, d.comps, d.conns, 1.5);
  ok(p4 < 0.2, "legacy valve without block props keeps crossover right", (p4 * 100).toFixed(0) + "%");
}


console.log("\n== HYD 20: time-based load profile on cylinder ==");
// NOTE: below ~620 kg on a 63 mm bore the cylinder runs supply-limited
// (v = Q/A) and chamber pressure stays at the valve-drop ceiling (~19.5 bar);
// the net imbalance is then reported as forceKN. Force balance engages once
// the load needs more pressure, so the ramp test must cross that threshold:
// profile 200 kg -> 3000 kg.
{
  const comps = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "left", ratedFlowLpm: 40, pressureDropBar: 5 }),
    C("CYL", "cylinderDA", { boreMm: 63, rodMm: 36, strokeMm: 5000, loadKg: 200, loadMode: "time-based", loadProfile: "0, 200\n2, 3000", simPosition: 0.2 }),
    C("G_A", "pressureGauge", {}),
  ];
  const conns = [
    L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"),
    L("l3", "V", "A", "CYL", "A"), L("l4", "V", "B", "CYL", "B"),
    L("l5", "V", "A", "G_A", "P"),
  ];
  globalThis.rgzFluidSolve._dyn = null;
  let f1 = null, f2 = null, t = 0;
  for (let i = 0; i < 60; i++) {
    const m = globalThis.rgzFluidSolve({ fluid: "oil", components: comps, connections: conns, dt: 0.05, time: t });
    if (Math.abs(t - 0.45) < 0.026) { f1 = m.comp.G_A.pressureBar; }
    if (Math.abs(t - 2.45) < 0.026) { f2 = m.comp.G_A.pressureBar; }
    t += 0.05;
  }
  ok(f1 !== null && f1 < 30, "early chamber pressure at supply-limited ceiling (~19.5 bar @ 830 kg)", f1 && f1.toFixed(1));
  ok(f2 !== null && f2 > 80, "later chamber pressure force-engaged (~100 bar @ 3000 kg)", f2 && f2.toFixed(1));
  ok(f1 !== null && f2 !== null && f2 - f1 > 50, "time-based load ramps working pressure", f1 && f2 ? f2.toFixed(1) + " - " + f1.toFixed(1) : "n/a");
}

console.log("\n== HYD 21: position-based load profile on cylinder ==");
// Same supply-limited note as HYD 20: profile 200 kg -> 3000 kg over the stroke.
{
  const comps = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "left", ratedFlowLpm: 40, pressureDropBar: 5 }),
    C("CYL", "cylinderDA", { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 200, loadMode: "position-based", loadProfile: "0, 200\n1, 3000", simPosition: 0.1 }),
    C("G_A", "pressureGauge", {}),
  ];
  const conns = [
    L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"),
    L("l3", "V", "A", "CYL", "A"), L("l4", "V", "B", "CYL", "B"),
    L("l5", "V", "A", "G_A", "P"),
  ];
  globalThis.rgzFluidSolve._dyn = null;
  let fA = null, fB = null, t = 0;
  for (let i = 0; i < 40; i++) {
    comps[2].props.simPosition = 0.1; // hold near start: profile ≈ 480 kg
    const m1 = globalThis.rgzFluidSolve({ fluid: "oil", components: comps, connections: conns, dt: 0.05, time: t });
    t += 0.05;
    if (i === 39) fA = m1.comp.G_A.pressureBar;
  }
  for (let i = 0; i < 40; i++) {
    comps[2].props.simPosition = 0.9; // near end: profile ≈ 2720 kg
    const m2 = globalThis.rgzFluidSolve({ fluid: "oil", components: comps, connections: conns, dt: 0.05, time: t });
    t += 0.05;
    if (i === 39) fB = m2.comp.G_A.pressureBar;
  }
  ok(fA !== null && fA < 30, "start-of-stroke pressure at supply-limited ceiling (~19.5 bar @ 480 kg)", fA && fA.toFixed(1));
  ok(fB !== null && fB > 80, "end-of-stroke pressure force-engaged (~100 bar @ 2720 kg)", fB && fB.toFixed(1));
  ok(fA !== null && fB !== null && fB - fA > 50, "position-based load ramps pressure", fB && fA ? fB.toFixed(1) + " - " + fA.toFixed(1) : "n/a");
}

console.log("\n== HYD 22: time-based torque profile on hydraulic motor ==");
{
  const mk = () => ([
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 250 }),
    C("M", "hydraulicMotor", { displacementCcRev: 25, loadNm: 5, loadMode: "time-based", loadProfile: "0, 5\n2, 40" }),
    C("G", "pressureGauge", {}),
  ]);
  const conns = [
    L("l1", "HPU", "P", "M", "A"), L("l2", "M", "B", "HPU", "T", "return"),
    L("l3", "HPU", "P", "G", "P"),
  ];
  globalThis.rgzFluidSolve._dyn = null;
  let p1 = null, p2 = null, t = 0;
  const comps = mk();
  for (let i = 0; i < 60; i++) {
    const m = globalThis.rgzFluidSolve({ fluid: "oil", components: comps, connections: conns, dt: 0.05, time: t });
    if (Math.abs(t - 0.45) < 0.026) p1 = m.comp.G.pressureBar;
    if (Math.abs(t - 2.45) < 0.026) p2 = m.comp.G.pressureBar;
    t += 0.05;
  }
  ok(p1 !== null && p1 < 40, "early pump pressure low (5 N·m ≈ 13+ bar)", p1 && p1.toFixed(1));
  ok(p2 !== null && p2 > 70, "late pump pressure high (40 N·m ≈ 100+ bar)", p2 && p2.toFixed(1));
  ok(p1 !== null && p2 !== null && p2 - p1 > 55, "torque profile lifts pressure by ~88 bar of offset", (p2 - p1).toFixed(1));
}

console.log("\n== HYD 23: formula load profile sin(t) + x^2 (mixed variables) ==");
// load = 800 + 1200*sin(pi*t) + 2500*x^2  (kg) — uses t AND x together.
{
  const comps = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("V", "directionalValve", { ports: "4", positions: "3", center: "closed", spoolState: "left", ratedFlowLpm: 40, pressureDropBar: 5 }),
    C("CYL", "cylinderDA", { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 200, loadMode: "formula", loadProfile: "800 + 1200*sin(pi*t) + 2500*x^2", simPosition: 0.1 }),
    C("G_A", "pressureGauge", {}),
  ];
  const conns = [
    L("l1", "HPU", "P", "V", "P"), L("l2", "V", "T", "HPU", "T", "return"),
    L("l3", "V", "A", "CYL", "A"), L("l4", "V", "B", "CYL", "B"),
    L("l5", "V", "A", "G_A", "P"),
  ];
  globalThis.rgzFluidSolve._dyn = null;
  globalThis.rgzFluidSolve._expr = {};
  // sample the reported applied load + chamber pressure at several (t, x) combos
  const probe = (tSim, pos) => {
    comps[2].props.simPosition = pos;
    let m = null;
    for (let i = 0; i < 3; i++) m = globalThis.rgzFluidSolve({ fluid: "oil", components: comps, connections: conns, dt: 0.05, time: tSim + i * 0.05 });
    return m;
  };
  const m1 = probe(0.5, 0.1);   // expect load ≈ 800 + 1200*sin(~0.5π..) + 25 ≈ +high
  const load1 = m1.cylinders[0].loadKg;
  const expect1 = 800 + 1200 * Math.sin(Math.PI * 0.55) + 2500 * 0.01;
  ok(Math.abs(load1 - expect1) < 90, "formula load ≈ 800+1200*sin(pi*0.55)+2500*0.1^2", load1.toFixed(0) + " vs " + expect1.toFixed(0));
  const m2 = probe(1.5, 0.9);   // sin(1.55π)≈-0.987 → 800-1184+2025 = 1641
  const load2 = m2.cylinders[0].loadKg;
  const expect2 = 800 + 1200 * Math.sin(Math.PI * 1.55) + 2500 * 0.81;
  ok(Math.abs(load2 - expect2) < 90, "formula tracks both t and x at (1.5 s, 0.9)", load2.toFixed(0) + " vs " + expect2.toFixed(0));
  const m3 = probe(2.5, 0.9);   // sin(2.55π)≈+0.987 → 800+1184+2025 ≈ 4009 → capped by nothing, higher than m2
  ok(m3.cylinders[0].loadKg > m2.cylinders[0].loadKg + 800, "sin branch swings load up half a cycle later", m3.cylinders[0].loadKg.toFixed(0));
  // pressure responds to the formula (not to the constant 200 kg fallback)
  ok(m1.comp.G_A.pressureBar > 60, "chamber pressure follows formula load, not the 200 kg fallback", m1.comp.G_A.pressureBar.toFixed(1));
}

console.log("\n== HYD 24: formula helpers + invalid profile warning ==");
{
  const comps = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("M", "hydraulicMotor", { displacementCcRev: 25, loadNm: 5, loadMode: "formula", loadProfile: "min(40, 5 + 35*ramp(t, 0, 2)) + 4*cos(t)" }),
    C("G", "pressureGauge", {}),
  ];
  const conns = [
    L("l1", "HPU", "P", "M", "A"), L("l2", "M", "B", "HPU", "T", "return"),
    L("l3", "HPU", "P", "G", "P"),
  ];
  globalThis.rgzFluidSolve._dyn = null;
  const m0 = globalThis.rgzFluidSolve({ fluid: "oil", components: comps, connections: conns, dt: 0.05, time: 0 });
  const m2s = globalThis.rgzFluidSolve({ fluid: "oil", components: comps, connections: conns, dt: 0.05, time: 2.5 });
  ok(Math.abs(m0.motors[0].loadNm - (5 + 4)) < 1.2, "ramp(t,0,2)=0 at t=0, cos(0)=1 → 9 N·m", m0.motors[0].loadNm.toFixed(2));
  ok(m2s.motors[0].loadNm > 30, "ramp saturates to 40 N·m cap (+cos) at t=2.5 s", m2s.motors[0].loadNm.toFixed(2));
  // invalid profile → warning once + fallback to constant
  const bad = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("M2", "hydraulicMotor", { displacementCcRev: 25, loadNm: 5, loadMode: "formula", loadProfile: "nonsense((" }),
  ];
  const conns2 = [L("l1", "HPU", "P", "M2", "A"), L("l2", "M2", "B", "HPU", "T", "return")];
  globalThis.rgzFluidSolve._dyn = null;
  const mb = globalThis.rgzFluidSolve({ fluid: "oil", components: bad, connections: conns2, dt: 0.05, time: 0 });
  ok(mb.motors[0].loadNm === 5, "unparseable formula falls back to the constant load", mb.motors[0].loadNm);
  ok((mb.warnings || []).some((w) => /load profile could not be parsed/i.test(w)), "parse failure surfaces a warning to the user", (mb.warnings || []).join(" | ").slice(0, 90));
  // legacy pure-number profile now acts as a constant expression (not silently ignored)
  const num1 = [
    C("HPU", "powerPack", { flowLpm: 25, reliefSettingBar: 160 }),
    C("M3", "hydraulicMotor", { displacementCcRev: 25, loadNm: 5, loadMode: "formula", loadProfile: "42" }),
  ];
  globalThis.rgzFluidSolve._dyn = null;
  const mn = globalThis.rgzFluidSolve({ fluid: "oil", components: num1, connections: [L("l1", "HPU", "P", "M3", "A"), L("l2", "M3", "B", "HPU", "T")], dt: 0.05, time: 0 });
  ok(Math.abs(mn.motors[0].loadNm - 42) < 0.01, "bare number profile = constant formula", mn.motors[0].loadNm);
}

console.log(`\n==== RESULT: ${PASS} passed, ${FAIL} failed ====`);
process.exit(FAIL ? 1 : 0);
