/* Part 2: electro-hydraulic + pneumatic ISO figures. */
"use strict";
const S = require("./isolib.js");
const { figs, frame, wire, W, H } = require("./gen-figs.js");
const { INK, SOFT, ACC, BLUE, PILOT, line, path, rect, circle, txt, arrow, spring, solenoid, solidTri, adjArrow, g, dcv,
  pump, pumpWithMotor, hydMotor, compressor, airMotor, pressureGauge, tank, pneExhaust, cylDA, cylSA, telescopic, rodless,
  reliefValve, reducingValve, checkValve, shuttleValve, andValve, throttle, oneWayFlowControl, filter, coolerSym, accumulator,
  ejector, airService, muffler, quickExhaust, esc, n } = S;

/* ---------- electric ladder rail helper ---------- */
function ladder(x1, x2, y, rows, o = {}) {
  let out = line(x1, y, x1, y + rows.length * 34, { w: 2.6 }) + line(x2, y, x2, y + rows.length * 34, { w: 2.6 });
  out += txt(x1, y - 8, o.top || "+24 V", { size: 11, weight: 800, c: INK });
  out += txt(x2, y - 8, "0 V", { size: 11, weight: 800, c: INK });
  rows.forEach((r, i) => { out += r(x1 + 2, x2 - 2, y + 18 + i * 34); });
  return out;
}
function contactNO(x1, x2, y, label) {
  const cx = (x1 + x2) / 2;
  return line(x1, y, cx - 10, y, { w: 2 }) + line(cx + 10, y, x2, y, { w: 2 }) +
    line(cx - 8, y + 7, cx - 2, y - 8, { w: 2 }) + line(cx + 4, y + 7, cx + 10, y - 8, { w: 2 }) +
    txt(cx, y - 12, label, { size: 10.5, c: BLUE, weight: 700 });
}
function contactNC(x1, x2, y, label) {
  const cx = (x1 + x2) / 2;
  return contactNO(cx - 46, cx + 46, y, label).replace(new RegExp(`x1="${cx - 46}"`, "g"), `x1="${cx - 46}"`) ;
}
function coil(x2, y, label) {
  return line(x2 - 74, y, x2 - 24, y, { w: 2 }) + circle(x2 - 14, y, 10, { w: 2 }) + txt(x2 - 14, y + 4, label, { size: 9.5, weight: 800, c: ACC });
}

/* ------------------------------------------------------------------ */
figs["fig-hyd-elehh-circuit.svg"] = () => {
  const f = frame("Electro-hydraulic single-cylinder drive", "electric relay switches the solenoids — hydraulics does the heavy lifting");
  /* hydraulic side (left) */
  f.add(g(90, 330, 0.9, tank({ w: 38 })));
  f.add(wire([[90, 316], [90, 268], [140, 268]]));
  f.add(g(140, 244, 0.88, pumpWithMotor({}), null));
  f.add(wire([[140, 201], [140, 150], [240, 150]]));
  f.add(g(255, 150, 1.35, dcv({
    boxes: [
      { arrows: [[20, 82, 26, 18], [76, 18, 80, 82]] },
      { closed: [[20, 18], [80, 18], [20, 82], [80, 82]] },
      { arrows: [[20, 82, 76, 18], [80, 82, 26, 18]] },
    ],
    solL: "Y1", solR: "Y2", springL: true, springR: true,
  }), null));
  f.add(txt(255, 150 + 44, "4/3 closed centre", { size: 9.5, style: "italic" }));
  /* relief branch */
  f.add(wire([[170, 201], [170, 186], [60, 186], [60, 240]], { w: 2 }));
  f.add(g(74, 266, 0.95, reliefValve({}), null));
  f.add(wire([[74, 234], [74, 210]]));
  f.add(g(74, 320, 0.85, tank({ w: 30 })));
  /* cylinder above valve */
  f.add(wire([[239, 125], [239, 84], [330, 84]]));
  f.add(wire([[272, 125], [272, 60], [360, 60]]));
  f.add(g(394, 72, 1.15, `<g transform="rotate(90)">${cylDA({})}</g>`, null));
  /* rotate cylinder vertical: rotate produces A top port; simpler: draw vertical cylinder manually */
  f.add(txt(394 + 40, 76, "C1", { size: 11, weight: 800, anchor: "start" }));
  /* gauge on A line */
  f.add(wire([[300, 84], [300, 120]]));
  f.add(g(300, 134, 0.9, pressureGauge({ stub: 0 })));
  f.add(txt(318, 138, "G1", { size: 10, weight: 800, c: ACC, anchor: "start" }));
  /* electric side (right): simple ladder S1 -> K1 -> Y1, K1 holding */
  f.add(rect(470, 60, 262, 250, { rx: 12, fill: "#fff", c: "#D6DEEC", w: 1.4 }));
  f.add(txt(600, 84, "control side — 24 V relay logic", { size: 11.5, weight: 800 }));
  f.add(ladder(510, 690, 108, [
    (a, b, y) => contactNO(a, b, y, "S1 start") + coil(b, y, "K1"),
    (a, b, y) => contactNC(a, b, y, "S2 stop") + coil(b, y, "K1"),
    (a, b, y) => contactNO(a, b, y, "K1") + coil(b, y, "Y1"),
  ]));
  f.add(txt(600, 236, "K1 seals itself in until S2 breaks the hold", { size: 10, style: "italic" }));
  f.add(line(430, 268, 470, 268, { w: 1.4, dash: "4 4", c: SOFT }));
  f.add(txt(490, 300, "Y1 → extend · Y2 → retract", { size: 10.5, weight: 700, c: ACC }));
  return f.end();
};

/* ------------------------------------------------------------------ */
figs["fig-hyd-elehh-sequence.svg"] = () => {
  const f = frame("Two-cylinder sequence A+ B+ B− A− — electric side", "each rung starts the next step; end-of-stroke feedback (pressure switch or sensor) gates it");
  /* displacement-step diagram left */
  f.add(rect(40, 70, 250, 240, { rx: 12, fill: "#fff", c: "#D6DEEC", w: 1.4 }));
  f.add(txt(165, 94, "displacement–step", { size: 11, weight: 800 }));
  f.add(line(70, 130, 70, 280, { w: 1.8, c: SOFT }) + arrow(70, 126, -90, { l: 7, c: SOFT }));
  f.add(line(70, 280, 268, 280, { w: 1.8, c: SOFT }) + arrow(272, 280, 0, { l: 7, c: SOFT }));
  f.add(txt(104, 122, "stroke", { size: 9, c: SOFT }));
  f.add(txt(252, 294, "step", { size: 9, c: SOFT }));
  const px = (v) => 90 + v * 45, py = (v) => 280 - v * 130;
  let dA = `M${px(0)} ${py(0)}`;
  [[0, 1], [1, 1], [1, 1], [3, 1], [3, 0], [3.6, 0]].forEach((pt) => { dA += ` L${px(pt[0])} ${py(pt[1])}`; });
  f.add(path(dA, { w: 2.4, c: BLUE }));
  let dB = `M${px(0)} ${py(0)}`;
  [[1, 0], [1, 1], [2, 1], [2, 0], [3.6, 0]].forEach((pt) => { dB += ` L${px(pt[0])} ${py(pt[1])}`; });
  f.add(path(dB, { w: 2.4, c: ACC }));
  f.add(txt(px(0.5) - 4, 150, "A", { size: 11, weight: 800, c: BLUE }));
  f.add(txt(px(1.5) - 4, 150, "B", { size: 11, weight: 800, c: ACC }));
  ["1", "2", "3", "4"].forEach((s2, i) => f.add(txt(px(0.6 + i * 0.75), 302, "step " + s2, { size: 8.5, c: SOFT })));
  /* ladder right */
  f.add(ladder(360, 690, 90, [
    (a, b, y) => contactNO(a, b, y, "S1") + coil(b, y, "K1"),
    (a, b, y) => contactNO(a, b, y, "K1") + coil(b, y, "K1"),
    (a, b, y) => contactNO(a, b, y, "a1") + coil(b, y, "K2"),
    (a, b, y) => contactNO(a, b, y, "K2") + coil(b, y, "Y2"),
    (a, b, y) => contactNO(a, b, y, "b1") + coil(b, y, "K3"),
    (a, b, y) => contactNO(a, b, y, "K3") + coil(b, y, "Y3"),
    (a, b, y) => contactNO(a, b, y, "a0") + coil(b, y, "K4"),
  ]));
  f.add(txt(525, 108 + 7 * 34 + 16, "sensors a0/a1 (A back/out), b0/b1 (B back/out) gate each step", { size: 10, style: "italic" }));
  f.add(txt(525, 108 + 7 * 34 + 34, "same job the deck's sequence module does on the canvas", { size: 10, c: SOFT, style: "italic" }));
  return f.end();
};

/* ------------------------------------------------------------------ */
figs["fig-hyd-closedloop.svg"] = () => {
  const f = frame("Closed-loop control — the machine checks its own homework", "prop./servo valve + position or pressure feedback = accuracy a hand valve can't reach");
  const y = 150, bx = [70, 200, 330, 470, 610];
  const block = (x, w2, label, sub) => rect(x - w2 / 2, y - 22, w2, 44, { rx: 8, w: 2, fill: "#fff" }) +
    txt(x, y - 2, label, { size: 11.5, weight: 800 }) + txt(x, y + 13, sub, { size: 9, c: SOFT });
  f.add(block(bx[0], 104, "setpoint", "mm · bar · %"));
  f.add(block(bx[1], 104, "controller", "P / PI / PID"));
  f.add(block(bx[2], 104, "amplifier", "PWM current"));
  f.add(block(bx[3], 120, "prop. valve", "spool follows mA"));
  f.add(block(bx[4], 104, "hydraulics", "cylinder moves"));
  for (let i = 0; i < 4; i++) f.add(line(bx[i] + 54, y, bx[i + 1] - 54 - (i === 2 ? 10 : 0), y, { w: 2 }) + arrow(bx[i + 1] - 54 - (i === 2 ? 10 : 0), y, 0, { l: 8 }));
  /* summing point */
  f.add(circle(bx[0] - 88, y, 12, { w: 2.2 }) + txt(bx[0] - 88, y + 4, "Σ", { size: 13, weight: 800 }));
  f.add(line(bx[0] - 76, y, bx[0] - 54, y, { w: 2 }) + arrow(bx[0] - 54, y, 0, { l: 8 }));
  f.add(txt(bx[0] - 88, y - 20, "−", { size: 14, weight: 800, c: ACC }));
  /* feedback path */
  f.add(wire([[bx[4], y + 22], [bx[4], y + 78], [bx[0] - 88, y + 78], [bx[0] - 88, y + 12]], { w: 1.8, dash: "6 4", c: PILOT }));
  f.add(arrow(bx[0] - 88, y + 12, -90, { l: 8, c: PILOT }));
  f.add(rect(430, y + 60, 190, 36, { rx: 8, w: 1.6, fill: "#F1F5FB", c: "#D6DEEC" }));
  f.add(txt(525, y + 82, "position / pressure sensor", { size: 10, weight: 700, c: PILOT }));
  /* under: prop valve symbol + sine */
  f.add(line(60, 300, 700, 300, { w: 1.2, c: "#c7d2e3" }));
  f.add(g(170, 356, 1.0, dcv({
    boxes: [{ arrows: [[20, 82, 26, 18], [76, 18, 80, 82]] }, { arrows: [[20, 82, 76, 18], [80, 82, 26, 18]] }],
    solL: true, proportional: true,
    portTop: [{ x: 20, label: "A" }, { x: 80, label: "B" }],
    portBottom: [{ x: 20, label: "P" }, { x: 80, label: "T" }],
  }), null));
  f.add(txt(170, 408, "proportional — infinite positions, thin frame lines", { size: 10 }));
  f.add(txt(430, 348, "dither: tiny command ripple keeps the spool", { size: 10.5, style: "italic", anchor: "start" }));
  f.add(txt(430, 364, "micro-moving — no stiction jumps", { size: 10.5, style: "italic", anchor: "start" }));
  let dd = "M540 336";
  for (let i = 0; i <= 60; i++) dd += ` L${540 + i * 2.6} ${336 + (i % 4 < 2 ? -5 : 5) * 0.9}`;
  f.add(path(dd, { w: 1.8, c: ACC }));
  f.add(txt(620, 326, "dither", { size: 9.5, c: ACC }));
  return f.end();
};

/* ------------------------------------------------------------------ */
figs["fig-hyd-manifold.svg"] = () => {
  const f = frame("Subplates & manifolds — plumbing without pipes", "ISO 4401 / NG6 pattern: P T A B always in the same place — stack sandwich valves like Lego");
  /* interface top view */
  f.add(rect(70, 90, 220, 170, { rx: 14, w: 2.4, fill: "#fff" }));
  f.add(txt(180, 112, "ISO 4401 NG6 face", { size: 11.5, weight: 800 }));
  f.add(circle(130, 160, 9, { w: 2.2 }) + txt(130, 184, "P", { size: 11, weight: 800, c: ACC }));
  f.add(circle(230, 160, 9, { w: 2.2 }) + txt(230, 184, "T", { size: 11, weight: 800 }));
  f.add(circle(152, 220, 9, { w: 2.2 }) + txt(152, 244, "A", { size: 11, weight: 800, c: BLUE }));
  f.add(circle(208, 220, 9, { w: 2.2 }) + txt(208, 244, "B", { size: 11, weight: 800, c: BLUE }));
  f.add(circle(92, 130, 4, { w: 1.6 }) + circle(268, 130, 2 + 2, { w: 1.6 }) + circle(92, 222, 4, { w: 1.6 }) + circle(268, 222, 4, { w: 1.6 }));
  f.add(txt(180, 208, "4 × locating bores", { size: 9, c: SOFT }));
  /* sandwich stack */
  const sx = 430;
  f.add(rect(sx - 90, 80, 260, 36, { rx: 7, w: 2, fill: "#fff" }) + txt(sx + 40, 102, "4/3 valve on top", { size: 10.5, weight: 800 }));
  f.add(rect(sx - 90, 122, 260, 34, { rx: 7, w: 1.8, fill: "#F1F5FB" }) + txt(sx + 40, 144, "check / pilot-check slice", { size: 10 }));
  f.add(rect(sx - 90, 162, 260, 34, { rx: 7, w: 1.8, fill: "#F1F5FB" }) + txt(sx + 40, 184, "meter-out FCV slice", { size: 10 }));
  f.add(rect(sx - 90, 202, 260, 34, { rx: 7, w: 1.8, fill: "#F1F5FB" }) + txt(sx + 40, 224, "relief slice (P line)", { size: 10 }));
  f.add(rect(sx - 90, 242, 260, 40, { rx: 7, w: 2, fill: "#fff" }) + txt(sx + 40, 258, "manifold block", { size: 10.5, weight: 800 }) + txt(sx + 40, 274, "P rail + T feed the stack", { size: 9, c: SOFT }));
  f.add(txt(180, 300, "same P and T serve every station — only A/B are per-actuator", { size: 10.5, style: "italic" }));
  f.add(txt(180, 330, "torque the tie-rods crosswise; sandwich O-rings hate skew", { size: 10, style: "italic", c: SOFT }));
  f.add(txt(430, 330, "stacking beats hoses: fewer leak points, smaller footprint,", { size: 10.5 }));
  f.add(txt(430, 348, "and a failed slice swaps in minutes", { size: 10.5, style: "italic", c: SOFT }));
  return f.end();
};

/* ------------------------------------------------------------------ */
figs["fig-pne-valves.svg"] = () => {
  const f = frame("Pneumatic directional valves — 3/2 and 5/2", "port numbers: 1 = supply · 2/4 = working ports · 3/5 = exhausts");
  f.add(txt(200, 76, "3/2-way — single-acting loads, spring return", { size: 11.5, weight: 800 }));
  f.add(g(200, 160, 1.5, dcv({
    boxes: [
      { arrows: [[50, 82, 50, 18]] },
      { arrows: [[50, 18, 50, 82]] },
    ],
    solL: "12", springR: true,
    portTop: [{ x: 50, label: "2" }],
    portBottom: [{ x: 50, label: "1" }],
  }), null));
  f.add(g(200 + 62, 116, 1.0, muffler()));
  f.add(txt(276, 120, "3 ↯", { size: 11, anchor: "start", c: SOFT }));
  f.add(txt(200, 240, "rest: 2 → 3 exhausts · energised: 1 → 2 feeds", { size: 10.5, style: "italic" }));
  /* 5/2 */
  f.add(txt(520, 76, "5/2-way — double-acting cylinders", { size: 11.5, weight: 800 }));
  f.add(g(520, 160, 1.5, dcv({
    boxes: [
      { arrows: [[20, 82, 24, 18], [80, 18, 84, 82]] },
      { arrows: [[20, 82, 24 + 40, 18], [80, 18, 80 - 40, 82]] },
    ],
    solL: "14", solR: "12",
    portTop: [{ x: 20, label: "2" }, { x: 80, label: "4" }],
    portBottom: [{ x: 12, label: "1" }, { x: 50, label: "3" }, { x: 88, label: "5" }],
  }), null));
  f.add(txt(520, 240, "memory valve — detented, stays where you put it", { size: 10.5, style: "italic" }));
  f.add(txt(380, 320, "5/3 centres mirror hydraulics: closed · exhausted · pressurised;", { size: 11 }));
  f.add(txt(380, 342, "pick exhausted to drift a tool by hand, closed to park a position", { size: 10.5, style: "italic" }));
  return f.end();
};

/* ------------------------------------------------------------------ */
figs["fig-pne-actuators.svg"] = () => {
  const f = frame("Pneumatic actuators — simple, fast, forgiving", "stroke, cushioning and mounting are chosen per task — size with F = p · A · η");
  f.add(g(160, 110, 1.4, cylDA({ cushion: true }), null));
  f.add(txt(160, 158, "double-acting with end cushioning", { size: 10.5 }));
  f.add(txt(160 + 108, 106, "⛨ cushion", { size: 9, c: SOFT }));
  f.add(g(160, 250, 1.4, cylSA({}), null));
  f.add(txt(160, 292, "single-acting — air out, spring back", { size: 10.5 }));
  f.add(g(160, 370, 1.3, rodless(), null));
  f.add(txt(160, 404, "rodless for 1–6 m strokes", { size: 10.5 }));
  /* rotary */
  f.add(circle(480, 130, 26, { w: 2.6 }) + arrow(480 + 20, 130 - 20, -45, { l: 8 }));
  f.add(path(`M462 148 A26 26 0 0 1 506 148`, { w: 2, c: ACC }) + arrow(507, 150, 30, { l: 8, c: ACC }));
  f.add(txt(480, 196, "semi-rotary / vane — ≤ 270°", { size: 10.5 }));
  /* gripper substitute: two mini jaws cylinders */
  f.add(g(480, 260, 1.0, cylSA({}), null));
  f.add(g(480, 330, 1.0, cylSA({}), null));
  f.add(txt(480, 366, "grippers = paired short-stroke cylinders", { size: 10.5, style: "italic" }));
  f.add(rect(600, 90, 132, 116, { rx: 12, fill: "#fff", c: "#D6DEEC", w: 1.4 }));
  f.add(txt(666, 116, "sizing", { size: 11.5, weight: 800 }));
  f.add(txt(666, 140, "F = p · A · η", { size: 13, weight: 800, c: INK }));
  f.add(txt(666, 162, "η ≈ 0.6…0.8 friction", { size: 9.5 }));
  f.add(txt(666, 180, "Ø 40 @ 6 bar ≈ 754 N − η", { size: 9.5 }));
  return f.end();
};

module.exports = { figs };
