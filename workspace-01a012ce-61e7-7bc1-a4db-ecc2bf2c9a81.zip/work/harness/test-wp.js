// Integration test: run the plugin PHP inside php-wasm with WordPress stubs.
const fs = require("fs");
const { PHP } = require("@php-wasm/node");

const PLUGIN_DIR = "/home/user/work/extracted/rgz-engineering-studio";

const STUBS = `<?php
function add_action(...$a){ $GLOBALS['__hooks'][] = ['action',$a[0]]; }
function add_filter(...$a){ $GLOBALS['__filters'][$a[0]][] = $a[1]; }
function apply_filters(...$a){ $tag = $a[0]; $value = isset($a[1]) ? $a[1] : null; $extra = array_slice($a, 2); if (isset($GLOBALS['__filters'][$tag])) { foreach ($GLOBALS['__filters'][$tag] as $cb) { $value = call_user_func_array($cb, array_merge([$value], $extra)); } } return $value; }
function add_shortcode(...$a){ $GLOBALS['__shortcodes'][] = $a[0]; }
function add_menu_page(...$a){ return 'toplevel_page_' . $a[3]; }
function add_submenu_page(...$a){ return $a[0] . '_page_' . $a[4]; }
function register_activation_hook(...$a){ }
function register_deactivation_hook(...$a){ }
function admin_url($p=''){ return 'https://site.test/wp-admin/' . $p; }
function home_url($p='/'){ return 'https://site.test' . $p; }
function plugin_dir_url($f){ return 'https://site.test/wp-content/plugins/rgz-engineering-studio/'; }
function plugin_dir_path($f){ return dirname($f) . '/'; }
function get_option($k, $d=false){ return array_key_exists($k, $GLOBALS['__options_store']) ? $GLOBALS['__options_store'][$k] : $d; }
function update_option($k, $v){ $GLOBALS['__options_store'][$k] = $v; return true; }
function delete_option($k){ unset($GLOBALS['__options_store'][$k]); return true; }
function sanitize_text_field($s){ $s = (string)$s; $s = strip_tags($s); $s = preg_replace('/[\\x00-\\x1F\\x7F]/u', '', $s); return trim($s); }
function sanitize_textarea_field($s){ return trim(strip_tags((string)$s)); }
function sanitize_key($s){ return strtolower(preg_replace('/[^a-zA-Z0-9_\\-]/', '', (string)$s)); }
function sanitize_hex_color($s){ return preg_match('/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', (string)$s) ? $s : null; }
function sanitize_email($s){ return filter_var($s, FILTER_SANITIZE_EMAIL); }
function sanitize_file_name($n){ return preg_replace('/[^-a-zA-Z0-9_.]/', '-', (string)$n); }
function esc_url_raw($u){ $u = trim((string)$u); return ($u === '' || preg_match('#^https?://#i', $u)) ? $u : ''; }
function esc_url($u){ return (string)$u; }
function esc_html($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function esc_attr($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function esc_textarea($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
// Simulate production WordPress kses: the stock post allow-list has NO svg,
// so wp_kses_post strips inline svg tags (what hid the library figures live).
// NB: STUBS must contain no PHP close tag anywhere, bootstrap's replace
// (STUBS - close-tag) joins this string with the plugin sources.
function wp_kses_post($s){
  return preg_replace('#</?(svg|g|path|rect|circle|ellipse|line|polyline|polygon|text|tspan|defs|marker|use|title|desc|clippath|lineargradient|radialgradient|stop)[^>]*'.'>#i', '', (string)$s);
}
function wp_kses($s, $allowed){
  // honor the plugin's extended allow-list: svg stays when the caller allows it
  if (is_array($allowed) && array_key_exists('svg', $allowed)) { return (string)$s; }
  return wp_kses_post($s);
}
function wp_kses_allowed_html($ctx){
  return ['p'=>[],'h3'=>[],'h4'=>[],'ul'=>[],'li'=>[],'strong'=>[],'em'=>[],'div'=>[],'figure'=>[],'figcaption'=>[],'img'=>[],'sub'=>[],'br'=>[],'code'=>[]];
}
function wp_unslash($v){ return $v; }
function absint($v){ return abs((int)$v); }
function checked($a, $b=true, $e=true){ if($a==$b && $e) echo 'checked="checked"'; }
function selected($a, $b=true, $e=true){ if($a==$b && $e) echo 'selected="selected"'; }
function current_user_can($c){ return true; }
function wp_die($m=''){ throw new Exception('wp_die: '.$m); }
function wp_create_nonce($a){ return 'nonce_'.md5($a); }
function wp_nonce_field($a=-1, $n='_wpnonce', $referer=true, $echo=true){ $s = '<input type="hidden" name="'.$n.'" value="nonce_'.md5($a).'">'; if($echo) echo $s; return $s; }
function check_admin_referer($a=-1, $q=false){ return 1; }
function wp_verify_nonce($n, $a=-1){ return $n === 'nonce_'.md5($a) ? 1 : false; }
function wp_safe_redirect($url, $status=302){ $GLOBALS['__redirect'][] = $url; }
function add_query_arg($args, $val=null, $url=''){
  if (is_array($args)) { $q = http_build_query($args); $u = $val === null ? '' : $val; }
  else { $q = urlencode($args) . '=' . urlencode($val); $u = $url; }
  return $u . (strpos($u, '?') === false ? '?' : '&') . $q;
}
function nocache_headers(){ }
function get_posts($args=[]){ return []; }
function has_shortcode($c, $t){ return false; }
function get_permalink($p){ return 'https://site.test/page/'; }
function wp_enqueue_style(...$a){ $GLOBALS['__enqueue'][] = ['css', $a[0]]; }
function wp_enqueue_script(...$a){ $GLOBALS['__enqueue'][] = ['js', $a[0]]; }
function wp_localize_script($h, $var, $data){ $GLOBALS['__localize'][$var] = $data; }
function wp_generate_password($len=12, $a=false, $b=false){ return substr(str_replace(['/','+','='],'', base64_encode(random_bytes($len+4))), 0, $len); }
function wp_json_encode($v, $flags=0){ return json_encode($v, $flags); }
function shortcode_atts($pairs, $atts, $shortcode=''){ return array_merge($pairs, array_intersect_key((array)$atts, $pairs)); }
function wp_trim_words($t, $n=55){ $w = preg_split('/\\s+/', trim(strip_tags((string)$t))); return count($w) > $n ? implode(' ', array_slice($w, 0, $n)) . '…' : implode(' ', $w); }
function did_action($a){ return 0; }
function wp_upload_dir(){ return ['basedir'=>'/internal/uploads','baseurl'=>'https://site.test/wp-content/uploads','path'=>'/internal/uploads','url'=>'https://site.test/wp-content/uploads']; }
function shortcode_exists($s){ return in_array($s, isset($GLOBALS['__shortcodes']) ? $GLOBALS['__shortcodes'] : [], true); }
function wp_nonce_url($u, $a=-1){ return $u . (strpos($u,'?')===false?'?':'&') . '_wpnonce=nonce_' . md5($a); }
function current_time($t='mysql'){ return '2026-08-06 12:00:00'; }
if (!defined('DAY_IN_SECONDS')) define('DAY_IN_SECONDS', 86400);
function wp_salt($s='auth'){ return 'test-salt-' . $s; }
function is_email($e){ return (bool) filter_var($e, FILTER_VALIDATE_EMAIL); }
function wp_send_json_success($data=null, $code=200){ echo json_encode(['success'=>true,'data'=>$data]); throw new Exception('__JSON_END__'); }
function wp_send_json_error($data=null, $code=200){ echo json_encode(['success'=>false,'data'=>$data]); throw new Exception('__JSON_END__'); }
function wp_hash_password($p){ return 'h:' . md5($p); }
function wp_check_password($p, $h){ return $h === 'h:' . md5($p); }
function size_format($b, $d=1){ $b = (float)$b; if ($b >= 1048576) { return number_format($b/1048576, $d) . ' MB'; } if ($b >= 1024) { return number_format($b/1024, $d) . ' KB'; } return number_format($b, 0) . ' B'; }
function number_format_i18n($n, $d=0){ return number_format((float)$n, (int)$d); }
function esc_html__($s, $d=null){ return (string)$s; }
function esc_html_e($s, $d=null){ echo (string)$s; }
function dbDelta($sql){ $GLOBALS['__dbDelta'][] = $sql; return true; }
function get_current_user_id(){ return 0; }
if (!defined('ARRAY_A')) { define('ARRAY_A', 'ARRAY_A'); }
if (!defined('OBJECT')) { define('OBJECT', 'OBJECT'); }
/* In-memory wpdb good enough for the CAD studio tables + admin stats. */
class RGZ_Test_Wpdb {
  public $prefix = 'wp_';
  public $insert_id = 0;
  public function get_charset_collate(){ return ''; }
  public function esc_like($x){ return $x; }
  private function key($t){ return 'RGZ_TESTDB_' . $t; }
  private function rowsOf($t){ $k = $this->key($t); if (!isset($GLOBALS[$k])) { $GLOBALS[$k] = ['next' => 1, 'rows' => []]; } return $GLOBALS[$k]['rows']; }
  public function prepare(...$a){
    $sql = array_shift($a);
    if (isset($a[0]) && is_array($a[0])) { $a = $a[0]; }
    $bits = preg_split('/(%[ds])/', $sql, -1, PREG_SPLIT_DELIM_CAPTURE);
    $i = 0; $out = '';
    foreach ($bits as $b) {
      if ($b === '%d') { $v = isset($a[$i]) ? $a[$i] : 0; $i++; $out .= (string) (int) $v; }
      elseif ($b === '%s') { $v = isset($a[$i]) ? $a[$i] : ''; $i++; $out .= "'" . str_replace("'", "''", (string) $v) . "'"; }
      else { $out .= $b; }
    }
    return $out;
  }
  public function insert($t, $data, $fmt = null){
    $k = $this->key($t); if (!isset($GLOBALS[$k])) { $GLOBALS[$k] = ['next' => 1, 'rows' => []]; }
    $data['id'] = $GLOBALS[$k]['next']++; $GLOBALS[$k]['rows'][] = $data; $this->insert_id = $data['id']; return 1;
  }
  public function update($t, $data, $where, $f1 = null, $f2 = null){
    $k = $this->key($t); if (!isset($GLOBALS[$k])) { return 0; }
    foreach ($GLOBALS[$k]['rows'] as &$r) { if ((int) $r['id'] === (int) (isset($where['id']) ? $where['id'] : -1)) { $r = array_merge($r, $data); } }
    unset($r); return 1;
  }
  public function query($sql){
    $u = strtoupper($sql);
    if (strpos($u, 'DELETE FROM') !== false) {
      $t = $this->tableOf($sql); $k = $this->key($t); if (!isset($GLOBALS[$k])) { return 0; }
      $cond = $this->condsOf($sql); $n = 0;
      $GLOBALS[$k]['rows'] = array_values(array_filter($GLOBALS[$k]['rows'], function ($r) use ($cond, &$n) {
        foreach ($cond as $c => $v) { if ((string) (isset($r[$c]) ? $r[$c] : '') !== $v) { return true; } }
        $n++; return false;
      }));
      return $n;
    }
    return 0;
  }
  private function tableOf($sql){
    $p = stripos($sql, 'FROM');
    if ($p === false) { return ''; }
    $rest = trim(substr($sql, $p + 4));
    $sp = preg_split('/\\s+/', $rest);
    return $sp[0];
  }
  private function condsOf($where){
    $out = [];
    foreach (preg_split('/\\s+AND\\s+/i', $where) as $piece) {
      if (strpos($piece, '=') === false) { continue; }
      list($col, $val) = explode('=', $piece, 2);
      $col = trim($col); if (strpos($col, '.') !== false) { $col = substr($col, strrpos($col, '.') + 1); }
      if ($col === '' || !ctype_alpha(str_replace('_', '', $col))) { continue; } /* skips 1=1 */
      $val = trim($val);
      $val = trim(preg_split('/\\s+(GROUP BY|ORDER BY|LIMIT)\\b/i', $val)[0]);
      $out[$col] = trim($val, "'\\" ");
    }
    return $out;
  }
  private function select($sql){
    $t = $this->tableOf($sql);
    if ($t === '') { return []; }
    $wp = stripos($sql, 'WHERE');
    $cond = $wp !== false ? $this->condsOf(substr($sql, $wp + 5)) : [];
    if (stripos($sql, 'JOIN') !== false && stripos($sql, 'rgz_cad_') !== false) {
      $acct = $this->rowsOf($this->prefix . 'rgz_cad_accounts');
      $des  = $this->rowsOf($this->prefix . 'rgz_cad_designs');
      if (stripos($t, 'rgz_cad_designs') !== false) {
        /* deck profile merge: designs joined to accounts, filtered by a.email */
        $email = isset($cond['email']) ? $cond['email'] : '';
        $ids = [];
        foreach ($acct as $a) { if ($email === '' || (string) (isset($a['email']) ? $a['email'] : '') === $email) { $ids[(int) $a['id']] = true; } }
        $outJ = [];
        foreach ($des as $d) { if (isset($ids[(int) (isset($d['account_id']) ? $d['account_id'] : 0)])) { $outJ[] = $d; } }
        usort($outJ, function ($a, $b) { return strcmp((string) (isset($b['created_at']) ? $b['created_at'] : ''), (string) (isset($a['created_at']) ? $a['created_at'] : '')); });
        return $outJ;
      }
      /* admin: accounts enriched with design stats */
      $outA = [];
      foreach ($acct as $a) {
        $cnt = 0; $sum = 0; $last = null;
        foreach ($des as $d) {
          if ((int) (isset($d['account_id']) ? $d['account_id'] : 0) === (int) $a['id']) {
            $cnt++; $sum += (int) (isset($d['file_size']) ? $d['file_size'] : 0);
            $cd = (string) (isset($d['created_at']) ? $d['created_at'] : ''); if ($last === null || $cd > $last) { $last = $cd; }
          }
        }
        $a['design_count'] = $cnt; $a['storage_bytes'] = $sum; $a['last_design'] = $last;
        $outA[] = $a;
      }
      return $outA;
    }
    $rows = $this->rowsOf($t);
    if ($wp !== false) {
      $rows = array_values(array_filter($rows, function ($r) use ($cond) {
        foreach ($cond as $c => $v) { if ((string) (isset($r[$c]) ? $r[$c] : '') !== $v) { return false; } }
        return true;
      }));
    }
    return $rows;
  }
  public function get_row($sql, $out = OBJECT){ $rows = $this->select($sql); $r = $rows ? $rows[0] : null; if ($r === null) { return null; } return $out === ARRAY_A ? $r : (object) $r; }
  public function get_results($sql, $out = OBJECT){ return array_map(function ($r) use ($out) { return $out === ARRAY_A ? $r : (object) $r; }, $this->select($sql)); }
  public function get_var($sql){
    $rows = $this->select($sql);
    $u = strtoupper($sql);
    if (strpos($u, 'COUNT(*)') !== false) { return count($rows); }
    if (strpos($u, 'SUM(') !== false && preg_match('/SUM\\((\\w+)\\)/i', $sql, $sm)) { $s = 0; foreach ($rows as $r) { $s += (int) (isset($r[$sm[1]]) ? $r[$sm[1]] : 0); } return $s; }
    if (strpos($u, 'MAX(') !== false && preg_match('/MAX\\((\\w+)\\)/i', $sql, $mm)) { $mx = null; foreach ($rows as $r) { $v = (string) (isset($r[$mm[1]]) ? $r[$mm[1]] : ''); if ($mx === null || $v > $mx) { $mx = $v; } } return $mx; }
    if (preg_match('/SELECT\\s+(\\w+)\\s+FROM/i', $sql, $cm) && $cm[1] !== '*') { return $rows ? (isset($rows[0][$cm[1]]) ? $rows[0][$cm[1]] : null) : null; }
    return $rows ? reset($rows[0]) : null;
  }
}
$GLOBALS['wpdb'] = new RGZ_Test_Wpdb();
?>`;

function bootstrap(optionsStore, extra) {
  const hyd = fs.readFileSync(PLUGIN_DIR + "/rgz-engineering-studio.php", "utf8");
  const opts = JSON.stringify(optionsStore || {}).replace(/'/g, "\\'");
  return (
    STUBS.replace("?>", "") +
    "\ndefine('ABSPATH', '/wp/');\n" +
    "$GLOBALS['__options_store'] = json_decode('" + opts + "', true) ?: [];\n" +
    "$GLOBALS['__hooks'] = []; $GLOBALS['__enqueue'] = []; $GLOBALS['__localize'] = []; $GLOBALS['__redirect'] = []; $GLOBALS['__filters'] = [];\n" +
    "?>\n" +
    hyd +
    "\n" +
    extra
  );
}

let deckWritten = false;
async function run(php, label, optionsStore, extra, pick) {
  if (!deckWritten) {
    try { php.mkdir("/internal"); } catch (e) {}
    php.writeFile("/internal/rgz-mechanical-deck.php", fs.readFileSync(PLUGIN_DIR + "/rgz-mechanical-deck.php", "utf8"));
    php.writeFile("/internal/rgz-learning-library.php", fs.readFileSync(PLUGIN_DIR + "/rgz-learning-library.php", "utf8"));
    php.writeFile("/internal/rgz-app-packages.php", fs.readFileSync(PLUGIN_DIR + "/rgz-app-packages.php", "utf8"));
    php.writeFile("/internal/rgz-cad-studio.php", fs.readFileSync(PLUGIN_DIR + "/rgz-cad-studio.php", "utf8"));
    try { php.mkdir("/wp"); } catch (e) {}
    try { php.mkdir("/wp/wp-admin"); } catch (e) {}
    try { php.mkdir("/wp/wp-admin/includes"); } catch (e) {}
    php.writeFile("/wp/wp-admin/includes/upgrade.php", "<?php /* dbDelta stub is provided by STUBS */");
    deckWritten = true;
  }
  const code = bootstrap(optionsStore, `\nob_start();\ntry {\n${extra}\n} catch (Throwable $e) {\n  if ($e->getMessage() !== '__JSON_END__' && $e->getMessage() !== '__REDIRECT__') {\n    while (ob_get_level()) { ob_end_clean(); }\n    echo "FATAL: " . $e->getMessage() . "\\n";\n  }\n}\n$GLOBALS['__out'] = ob_get_clean();\necho "===OUT===\\n" . $GLOBALS['__out'] . "\\n===STATE===\\n" . json_encode([
  'options' => $GLOBALS['__options_store'],
  'localize' => $GLOBALS['__localize'],
  'enqueue' => $GLOBALS['__enqueue'],
  'shortcodes' => $GLOBALS['__shortcodes'],
]);\n`);
  const res = await php.run({ code });
  const text = res.text || "";
  const out = (text.split("===OUT===\n")[1] || "").split("\n===STATE===")[0];
  let state = {};
  try { state = JSON.parse(text.split("===STATE===\n")[1] || "{}"); } catch (e) { console.log(label, "STATE PARSE FAIL", text.slice(-800)); }
  const fatal = /FATAL:|Fatal error|Parse error|Uncaught/.test(out) || /FATAL:|Fatal error|Parse error|Uncaught/.test(text.split("===OUT===")[0] || "");
  console.log((fatal ? "FAIL ✗ " : "ok ✓ ") + label + (res.errors && res.errors.length ? "  [stderr: " + String(res.errors).slice(0, 160) + "]" : ""));
  if (fatal) { console.log(out.slice(0, 1000)); console.log((text.split("===OUT===")[0] || "").slice(-1000)); }
  return { out, state, fatal };
}

/* Minimal store-method ZIP writer (crafts entries ZipArchive would sanitize,
   e.g. '../evil.php' zip-slip names) to test the installer's path guard. */
function crc32(buf) {
  let t = crc32.t;
  if (!t) { t = crc32.t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } }
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) crc = t[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}
function mkZipRaw(entries) {
  const enc = new TextEncoder();
  const parts = [], cds = []; let off = 0;
  for (const e of entries) {
    const name = enc.encode(e.name), data = enc.encode(e.data), crc = crc32(data);
    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt32LE(crc, 14);
    lh.writeUInt32LE(data.length, 18); lh.writeUInt32LE(data.length, 22); lh.writeUInt16LE(name.length, 26);
    parts.push(lh, Buffer.from(name), Buffer.from(data));
    const ch = Buffer.alloc(46);
    ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt32LE(crc, 16);
    ch.writeUInt32LE(data.length, 20); ch.writeUInt32LE(data.length, 24); ch.writeUInt16LE(name.length, 28);
    ch.writeUInt32LE(off, 42);
    cds.push(ch, Buffer.from(name));
    off += 30 + name.length + data.length;
  }
  const cd = Buffer.concat(cds);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(entries.length, 8); end.writeUInt16LE(entries.length, 10);
  end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(off, 16);
  return Buffer.concat([...parts, cd, end]);
}

(async () => {
  const { loadNodeRuntime } = require("@php-wasm/node");
  /* loadNodeRuntime registers its runtime in @php-wasm/node's nested copy of universal —
     take PHP from that very copy so they share the registry. */
  const { PHP } = require("/home/user/work/harness/node_modules/@php-wasm/node/node_modules/@php-wasm/universal/index.cjs");
  const runtime = await loadNodeRuntime("8.2");
  const php = new PHP(runtime);
  let store = {};
  let fails = 0;
  const expect = (cond, msg) => { if (!cond) { console.log("   ✗ EXPECT: " + msg); fails++; } else { console.log("   ✓ " + msg); } };

  // 1) plugin loads, shortcodes registered
  let r = await run(php, "plugin load + shortcode registration", store, "RGZ_Mechanical_Deck::init(); RGZ_Engineering_Studio_Plugin::init(); RGZ_Hydraulic_Studio_Plugin::init(); RGZ_Pneumatic_Studio_Plugin::init();");
  fails += r.fatal ? 1 : 0;
  expect(r.state.shortcodes && r.state.shortcodes.includes("rgz_mechanical_deck"), "rgz_mechanical_deck registered");
  expect(r.state.shortcodes && r.state.shortcodes.includes("rgz_learning_hub"), "rgz_learning_hub registered");
  expect(r.state.shortcodes && r.state.shortcodes.includes("rgz_hydraulic_studio"), "hydraulic studio registered");

  // 2) deck shortcode render — two tabs (Apps / Learning) + Learning buttons
  r = await run(php, "render [rgz_mechanical_deck]", store, "echo RGZ_Mechanical_Deck::render_deck([]);");
  fails += r.fatal ? 1 : 0;
  console.log("DBG deck out len", r.out.length, JSON.stringify(r.out.slice(0,300)));
  if (process.env.DBG) console.log("DBG full", r.out.slice(0, 3000));
  expect(r.out.includes("Mechanical Engineering Deck"), "hero title in deck");
  expect((r.out.match(/rgzd-card\b/g) || []).length >= 2, "2 app cards rendered");
  expect(r.out.includes("Hydraulic Studio") && r.out.includes("Pneumatic Studio"), "both studios present");
  expect(r.out.includes('rgzd-tabsbar') && r.out.includes('data-deck-tab="apps"') && r.out.includes('data-deck-tab="learn"'), "deck has Apps + Learning tabs");
  expect(r.out.includes('data-deck-pane="apps"') && r.out.includes('data-deck-pane="learn"'), "deck has two tab panes");
  expect(r.out.includes('data-rgz-learn'), "Learning tab embeds the learning hub markup");
  expect(r.out.includes('rgzl-cover'), "lesson covers rendered on cards in the deck's Learning tab");
  expect(r.out.includes('assets/learn/'), "bundled artwork URLs point at plugin assets");
  expect(r.out.includes('#learn-hydraulics') && r.out.includes('data-learn-topic="hydraulics"'), "hydraulic card has 📖 Learning link pre-filtered to hydraulics");
  expect(r.out.includes('#learn-pneumatics') && r.out.includes('data-learn-topic="pneumatics"'), "pneumatic card has 📖 Learning link pre-filtered to pneumatics");
  expect(!/rgz_tour=/.test(r.out), "old guided-tour links gone from the deck");
  expect(!/Guided tour/.test(r.out), "old 'Guided tour' button label gone");
  expect(r.out.includes('--rgzd-accent: #eb4e3c'), "deck default accent matches site theme (#eb4e3c)");
  { const m = r.out.match(/rgzd-tabcount">\s*(\d+)\s*</); expect(!!m && parseInt(m[1]) >= 320, "learning tab bubble shows the extended library count (>=320): " + (m && m[1])); }
  store = r.state.options || store;

  // 3) learn hub render — extended library (30 default lessons)
  r = await run(php, "render [rgz_learning_hub]", store, "echo RGZ_Mechanical_Deck::render_learn([]);");
  expect(r.out.includes("<svg"), "hub display keeps inline svg figures through the kses allow-list (the wp_kses_post bug)");
  fails += r.fatal ? 1 : 0;
  expect((r.out.match(/rgzl-card\b/g) || []).length >= 320, "encyclopedia library rendered (>=320 cards)");
  expect(r.out.includes("Pascal"), "seeded Pascal lesson present");
  expect(r.out.includes("cavitation"), "new kian-informed lesson (cavitation) present");
  expect(r.out.includes("accumulator"), "kian-informed lesson (accumulators) present");
  expect(r.out.includes("Electro-pneumatics II"), "electro-pneumatics course from Festo TP201 present");
  expect(r.out.includes("Electro-hydraulics I"), "electro-hydraulics course present");
  expect(r.out.includes("characteristic curves"), "proportional-curves lesson from Festo TP701 present");
  expect(r.out.includes("vacuum") || r.out.includes("Vacuum"), "new pneumatics lesson (vacuum) present");
  expect(r.out.includes("rgzl-modal-backdrop"), "modal reader markup present");
  expect(r.out.includes("data-topic-chip"), "topic filter chips present");

  // 4) appearance save must NOT clobber tours
  store = store || {};
  store["rgz_mech_deck_settings"] = Object.assign({ tourHydraulic: true, tourPneumatic: true }, {});
  r = await run(php, "appearance save preserves tour flags", store,
    "$_POST = ['rgz_mech_settings_save'=>'1','settings_scope'=>'appearance','heroTitle'=>'My Deck','heroSubtitle'=>'Sub','heroAccent'=>'#ff0000','learnPageUrl'=>'https://site.test/learn/','showSearch'=>'1'];\n" +
    "RGZ_Mechanical_Deck::save_settings();\n echo json_encode(get_option('rgz_mech_deck_settings'));"
  );
  fails += r.fatal ? 1 : 0;
  let st = JSON.parse(r.out || "{}");
  expect(st.heroTitle === "My Deck", "hero title saved");
  expect(st.accent === "#ff0000", "accent saved");
  expect(st.tourHydraulic === true && st.tourPneumatic === true, "tour flags PRESERVED on appearance save");
  expect(st.showSearch === true && st.showFilters === false, "checkbox states saved");
  store = r.state.options || store;

  // 5) tours scope save preserves appearance
  r = await run(php, "tours save preserves appearance", store,
    "$_POST = ['settings_scope'=>'tours','tourPneumatic'=>'1','tourTextHydraulic'=>'Custom HY welcome','tourTextPneumatic'=>'Custom PN <script>alert(1)</script>text'];\n RGZ_Mechanical_Deck::save_settings();\n echo json_encode(get_option('rgz_mech_deck_settings'));"
  );
  st = JSON.parse(r.out || "{}");
  fails += r.fatal ? 1 : 0;
  expect(st.heroTitle === "My Deck", "appearance PRESERVED on tours save");
  expect(st.tourHydraulic === false && st.tourPneumatic === true, "tour flags updated (hyd off, pne on)");
  expect(st.tourTextHydraulic === "Custom HY welcome", "hydraulic welcome text saved");
  expect(st.tourTextPneumatic === "Custom PN alert(1)text", "pneumatic welcome text saved, <script> tags stripped");
  store = r.state.options || store;

  // 6) apps JSON save + sanitization
  r = await run(php, "apps save via JSON", store,
    "$_POST = ['rgz_apps_json' => json_encode([\n" +
    " ['id'=>'hydraulic-studio','title'=>'Hydraulic <b>X</b>','desc'=>'d','category'=>'Fluid Power','icon'=>'<script>','accent'=>'red','url'=>'javascript:alert(1)','tourKey'=>'hydraulic','enabled'=>true],\n" +
    " ['id'=>'new-app','title'=>'Robotics Lab','desc'=>'d2','category'=>'Robotics','icon'=>'robot','accent'=>'#00ff88','url'=>'https://site.test/robot/','learnTopic'=>'bogus','enabled'=>true]\n" +
    "])];\n RGZ_Mechanical_Deck::save_apps();\n echo json_encode(get_option('rgz_mech_deck_apps'));"
  );
  fails += r.fatal ? 1 : 0;
  let apps = JSON.parse(r.out || "[]");
  expect(apps.length === 2, "2 apps stored");
  expect(apps[0].title === "Hydraulic X", "app title sanitized (tags stripped)");
  expect(apps[0].icon === "generic", "invalid icon key rejected → generic");
  expect(apps[0].accent === "#38bdf8", "invalid color rejected → default");
  expect(apps[0].url === "", "javascript: URL rejected");
  expect(apps[0].learnTopic === "hydraulics", "legacy tourKey=hydraulic migrated to learnTopic=hydraulics");
  expect(apps[1].title === "Robotics Lab", "second app stored");
  expect(apps[1].learnTopic === "", "invalid learnTopic rejected to empty");
  store = r.state.options || store;

  // 6b) deck re-render after apps save: only valid learnTopics produce 📖 links
  r = await run(php, "deck render after apps save", store, "echo RGZ_Mechanical_Deck::render_deck([]);");
  fails += r.fatal ? 1 : 0;
  expect(r.out.includes('data-learn-topic="hydraulics"'), "📖 Learning link for hydraulics topic present");
  expect((r.out.match(/data-learn-topic=/g) || []).length === 1, "Robotics app (invalid topic) has NO learning link");

  // 7) lesson save + delete
  r = await run(php, "lesson save + delete", store,
    "$_POST = ['id'=>'', 'title'=>'Test Lesson', 'summary'=>'s', 'topic'=>'hydraulics', 'level'=>'beginner', 'minutes'=>9, 'content'=>'<p>hi</p>', 'cover'=>'https://site.test/x.png', 'enabled'=>'1'];\n RGZ_Mechanical_Deck::save_lesson();\n" +
    "$lessons = get_option('rgz_mech_deck_lessons', false);\n if (!is_array($lessons)) { $lessons = RGZ_Mechanical_Deck::default_lessons(); }\n" +
    "$new = end($lessons);\n echo count($lessons) . '|' . $new['title'] . '|';\n" +
    "$_POST = ['lesson_id'=>$new['id']];\n RGZ_Mechanical_Deck::delete_lesson();\n echo count(get_option('rgz_mech_deck_lessons')); "
  );
  fails += r.fatal ? 1 : 0;
  expect(/^\d+\|Test Lesson\|/.test(r.out), "lesson added");

  // 8) admin screens render without fatals
  r = await run(php, "admin: overview screen", store, "RGZ_Mechanical_Deck::render_overview();");
  fails += r.fatal ? 1 : 0;
  expect(r.out.includes("Control center") || r.out.includes("rgza-hero"), "overview hero rendered");
  expect(r.out.includes("[rgz_mechanical_deck]"), "shortcode reference shown");

  r = await run(php, "admin: deck manager screen", store, "RGZ_Mechanical_Deck::admin_assets('rgz-engineering-studio_page_rgz-mechanical-deck'); RGZ_Mechanical_Deck::render_deck_admin();");
  fails += r.fatal ? 1 : 0;
  expect(r.out.includes("rgza-pane"), "tabs + panes rendered");
  expect(r.out.includes('id="rgz-apps-json"'), "apps JSON hidden field present");
  expect(r.out.includes('name="settings_scope" value="tours"'), "tours scope present");
  expect(r.out.includes('name="tourTextHydraulic"') && r.out.includes('name="tourTextPneumatic"'), "welcome text inputs present in admin");
  expect(r.state.localize && r.state.localize.rgzaDeckEditor && (r.state.localize.rgzaDeckEditor.learnTopics || []).length === 5, "learnTopics localized for admin editor (base 4 + cad)");
  expect(r.out.includes('rgz_mech_lessons_seed') === false, "seed button only lives on the learning page (not here)");

  r = await run(php, "admin: learning hub list + edit form", store, "RGZ_Mechanical_Deck::render_learn_admin();");
  fails += r.fatal ? 1 : 0;
  expect(r.out.includes("rgza-table"), "lesson table rendered");
  expect(r.out.includes("rgz_mech_lessons_seed"), "seed-missing-lessons button present");

  r = await run(php, "admin: lesson edit form", store, "$_GET['action']='edit'; $_GET['id']='hyd-pascal'; RGZ_Mechanical_Deck::render_learn_admin();");
  fails += r.fatal ? 1 : 0;
  expect(r.out.includes("Pascal"), "edit form loads lesson");
  expect(r.out.includes('name="rgz_mech_lesson_delete"'), "delete form is separate");
  expect(r.out.includes('name="cover"'), "lesson form has a cover image field");

  // 9) studio shortcodes expose tutorial flag
  r = await run(php, "hydraulic shortcode config has tutorial flag", store, "echo RGZ_Hydraulic_Studio_Plugin::render_shortcode([]);");
  fails += r.fatal ? 1 : 0;
  expect(r.state.localize && r.state.localize.RGZHydraulicStudioConfig && r.state.localize.RGZHydraulicStudioConfig.tutorial === false, "hyd tutorial=false (tours off for hyd after step 5)");
  expect(r.state.localize.RGZHydraulicStudioConfig.tourText === "Custom HY welcome", "hyd welcome text exposed to frontend config");
  expect(r.out.includes('id="rgz-hydraulic-studio"'), "hydraulic root div rendered");
  r = await run(php, "pneumatic shortcode config has tutorial flag", store, "echo RGZ_Pneumatic_Studio_Plugin::render_shortcode([]);");
  fails += r.fatal ? 1 : 0;
  expect(r.state.localize && r.state.localize.RGZPneumaticStudioConfig && r.state.localize.RGZPneumaticStudioConfig.tutorial === true, "pne tutorial=true");
  expect(r.state.localize.RGZPneumaticStudioConfig.tourText === "Custom PN alert(1)text", "pne welcome text exposed to frontend config");
  expect(r.out.includes('id="rgz-pneumatic-studio"'), "pneumatic root div rendered");

  // 9c) default library = 30 lessons; seeding restores deleted defaults
  r = await run(php, "default lessons count + seed restore + refresh", store,
    "echo count(RGZ_Mechanical_Deck::default_lessons()) . '|';\n" +
    "$lessons = get_option('rgz_mech_deck_lessons', []);\n" +
    "$lessons = array_values(array_filter($lessons, function($l){ return $l['id'] !== 'hyd-cavitation' && $l['id'] !== 'hyd-pascal'; }));\n" +
    "update_option('rgz_mech_deck_lessons', $lessons);\n" +
    "RGZ_Mechanical_Deck::seed_default_lessons();\n" +
    "$after = get_option('rgz_mech_deck_lessons', []);\n" +
    "$ids = array_column($after, 'id');\n" +
    "echo count($after) . '|' . (in_array('hyd-cavitation', $ids) ? 'cav-ok' : 'cav-miss') . '|' . (in_array('hyd-pascal', $ids) ? 'pas-ok' : 'pas-miss');"
  );
  fails += r.fatal ? 1 : 0;
  expect(/^(3\d\d)\|/.test(r.out), "hundreds of default lessons (>=300): " + r.out.slice(0,20));
  {
    const m = r.out.match(/^(3\d\d)\|(\d+)\|(cav-ok|cav-miss)\|(pas-ok|pas-miss)/);
    expect(!!m, "seed output parseable: " + r.out.slice(0, 80));
    if (m) {
      expect(m[3] === "cav-ok" && m[4] === "pas-ok", "deleted default lessons restored by seeding");
    }
  }

  // 9d) refresh rewrites factory lesson texts (pictures included) but keeps publish state + custom lessons
  r = await run(php, "refresh factory lessons", store,
    "$lessons = get_option('rgz_mech_deck_lessons', []);\n" +
    "if (!is_array($lessons) || count($lessons) < 5) { $lessons = RGZ_Mechanical_Deck::default_lessons(); }\n" +
    "foreach ($lessons as $i=>$l) {\n" +
    "  if ($l['id']==='hyd-pascal') { $lessons[$i]['summary']='USER EDIT'; $lessons[$i]['enabled']=false; }\n" +
    "}\n" +
    "$lessons[] = ['id'=>'my-custom','title'=>'Mine','summary'=>'c','topic'=>'general','level'=>'beginner','minutes'=>3,'content'=>'x','enabled'=>true];\n" +
    "update_option('rgz_mech_deck_lessons', $lessons);\n" +
    "RGZ_Mechanical_Deck::refresh_default_lessons();\n" +
    "$after = get_option('rgz_mech_deck_lessons', []);\n" +
    "$byId = []; foreach ($after as $l) { $byId[$l['id']] = $l; }\n" +
    "echo ($byId['hyd-pascal']['summary']==='USER EDIT' ? 'kept' : 'rewritten') . '|' . " +
    "(empty($byId['hyd-pascal']['enabled']) ? 'hidden-kept' : 'lost-state') . '|' . " +
    "(isset($byId['hyd-pascal']['cover']) && strpos($byId['hyd-pascal']['cover'], 'fig-hyd-pascal.svg') !== false ? 'cover-ok' : 'cover-miss') . '|' . " +
    "(isset($byId['my-custom']) ? 'custom-kept' : 'custom-lost') . '|' . count($after);"
  );
  fails += r.fatal ? 1 : 0;
  { const m = r.out.trim().match(/^(rewritten)\|(hidden-kept)\|(cover-ok)\|(custom-kept)\|(\d+)$/); expect(!!m && parseInt(m[5]) >= 321, "factory texts+pictures refreshed, publish state & customs kept: " + r.out.trim()); }

  // 9e) designer-track lessons present in defaults + hub render
  r = await run(php, "designer track lessons", store, "echo RGZ_Mechanical_Deck::render_learn([]);");
  fails += r.fatal ? 1 : 0;
  expect(r.out.includes("Designer track H1"), "H1 load-to-bore lesson rendered");
  expect(r.out.includes("Designer track H6"), "H6 verification lesson rendered");
  expect(r.out.includes("Designer track P2"), "P2 sequence/PLC lesson rendered");
  expect(r.out.includes("🏗 Studio exercise"), "practical studio exercises present in track lessons");

  // 9e2) encyclopedia: >=150 lessons per subject + circuit-design content + auto-sync merge
  r = await run(php, "encyclopedia counts per topic", store,
    "$L = RGZ_Mechanical_Deck::default_lessons();\n" +
    "$c = ['hydraulics'=>0,'pneumatics'=>0,'general'=>0];\n" +
    "$pat = 0; $apps = 0; $ex = 0; $fig = 0; $cov = 0;\n" +
    "foreach ($L as $l) { if (isset($c[$l['topic']])) $c[$l['topic']]++; if (strpos($l['id'],'hl-ckt-')===0||strpos($l['id'],'pl-ckt-')===0) $pat++; if (strpos($l['content'],'Typical applications in circuits')!==false) $apps++; if (strpos($l['content'],'Studio exercise')!==false) $ex++; if (strpos($l['id'],'hl-')===0||strpos($l['id'],'pl-')===0) { if (strpos($l['content'],'rgzl-draw')!==false && strpos($l['content'],'<svg')!==false) $fig++; if (!empty($l['cover']) && strpos($l['cover'],'cov-')!==false) $cov++; } }\n" +
    "echo $c['hydraulics'].'|'.$c['pneumatics'].'|'.$c['general'].'|'.$pat.'|'.$apps.'|'.$ex.'|'.$fig.'|'.$cov;"
  );
  fails += r.fatal ? 1 : 0;
  {
    const m = r.out.trim().match(/^(\d+)\|(\d+)\|(\d+)\|(\d+)\|(\d+)\|(\d+)\|(\d+)\|(\d+)$/);
    expect(!!m, "encyclopedia counts parseable: " + r.out.slice(0, 60));
    if (m) {
      expect(parseInt(m[1]) >= 150, "hydraulics has >=150 lessons (got " + m[1] + ")");
      expect(parseInt(m[2]) >= 150, "pneumatics has >=150 lessons (got " + m[2] + ")");
      expect(parseInt(m[4]) >= 60, "dozens of circuit-design pattern lessons (got " + m[4] + ")");
      expect(parseInt(m[5]) >= 270, "element lessons describe their application in circuits (got " + m[5] + ")");
      expect(parseInt(m[6]) >= 270, "studio exercises attached to encyclopedia lessons (got " + m[6] + ")");
      expect(parseInt(m[7]) >= 275, "every encyclopedia lesson carries an SVG illustration (got " + m[7] + ")");
      expect(parseInt(m[8]) >= 275, "every encyclopedia lesson has a series cover (got " + m[8] + ")");
    }
  }
  r = await run(php, "encyclopedia auto-sync merges into stored lessons", store,
    "update_option('rgz_mech_deck_lessons', [['id'=>'my-custom','title'=>'Mine','summary'=>'c','topic'=>'general','level'=>'beginner','minutes'=>3,'content'=>'x','enabled'=>true]]);\n" +
    "update_option('rgz_mech_deck_lessons_ver', 1);\n" +
    "$L = RGZ_Mechanical_Deck::get_lessons(true);\n" +
    "$ids = array_column($L, 'id');\n" +
    "echo count($L).'|'.(in_array('my-custom',$ids)?'cust-ok':'cust-lost').'|'.(in_array('hl-powerpack',$ids)?'lib-ok':'lib-miss').'|'.(in_array('pl-ckt-cascade',$ids)?'pat-ok':'pat-miss').'|'.(int)get_option('rgz_mech_deck_lessons_ver',0);"
  );
  fails += r.fatal ? 1 : 0;
  {
    const m = r.out.trim().match(/^(\d+)\|(cust-ok|cust-lost)\|(lib-ok|lib-miss)\|(pat-ok|pat-miss)\|(\d+)$/);
    expect(!!m, "auto-sync output parseable: " + r.out.slice(0, 60));
    if (m) {
      expect(parseInt(m[1]) >= 320, "auto-sync merged encyclopedia into stored lessons (got " + m[1] + ")");
      expect(m[2] === "cust-ok" && m[3] === "lib-ok" && m[4] === "pat-ok", "custom lesson kept + library merged");
      expect(parseInt(m[5]) >= 7, "lessons version marker bumped");
    }
  }

  // 9e3) auto-sync REFRESH rebuilds artwork in stale lessons; publish state + customs kept (the live-DB fix)
  r = await run(php, "auto-sync refresh rebuilds artwork", store,
    "update_option('rgz_mech_deck_lessons', [" +
    "['id'=>'hl-powerpack','title'=>'STALE','summary'=>'STALE','topic'=>'hydraulics','level'=>'beginner','minutes'=>1,'content'=>'STALE','cover'=>'','enabled'=>false]," +
    "['id'=>'my-custom','title'=>'Mine','summary'=>'c','topic'=>'general','level'=>'beginner','minutes'=>3,'content'=>'x','enabled'=>true]]);\n" +
    "update_option('rgz_mech_deck_lessons_ver', 6);\n" +
    "$L = RGZ_Mechanical_Deck::get_lessons();\n" +
    "$byId = []; foreach ($L as $l) { $byId[$l['id']] = $l; }\n" +
    "$hp = $byId['hl-powerpack'];\n" +
    "echo (strpos($hp['content'], '<svg') !== false ? 'svg-ok' : 'svg-miss') . '|' . " +
    "(strpos($hp['cover'], 'cov-hyd-elements.svg') !== false ? 'cov-ok' : 'cov-miss') . '|' . " +
    "(empty($hp['enabled']) ? 'hidden-kept' : 'state-lost') . '|' . " +
    "($hp['title'] !== 'STALE' ? 'fresh-text' : 'stale-text') . '|' . " +
    "(isset($byId['my-custom']) ? 'custom-kept' : 'custom-lost') . '|' . (int) get_option('rgz_mech_deck_lessons_ver', 0);"
  );
  fails += r.fatal ? 1 : 0;
  {
    const m = r.out.trim().match(/^(svg-ok|svg-miss)\|(cov-ok|cov-miss)\|(hidden-kept|state-lost)\|(fresh-text|stale-text)\|(custom-kept|custom-lost)\|(\d+)$/);
    expect(!!m, "refresh output parseable: " + r.out.slice(0, 80));
    if (m) {
      expect(m[1] === "svg-ok", "stale lesson content refreshed WITH inline svg figure");
      expect(m[2] === "cov-ok", "stale lesson cover refreshed to cov-hyd-elements.svg");
      expect(m[3] === "hidden-kept" && m[5] === "custom-kept", "publish state + custom lessons preserved");
      expect(m[4] === "fresh-text" && parseInt(m[6]) === 10, "factory text refreshed + LESSONS_VER written as 10");
    }
  }

  // 9e4) animated GIFs attached to flagship factory lessons + library lessons
  r = await run(php, "animated lesson GIFs", store,
    "$L = RGZ_Mechanical_Deck::default_lessons();\n" +
    "$byId = []; foreach ($L as $l) { $byId[$l['id']] = $l['content']; }\n" +
    "echo (strpos($byId['hyd-dcv'], 'anim-hyd-dcv-spool.gif') !== false ? 'dcv-gif' : 'dcv-no') . '|' . " +
    "(strpos($byId['hyd-cylinders'], 'anim-hyd-cylinder-cycle.gif') !== false ? 'cyl-gif' : 'cyl-no') . '|' . " +
    "(strpos($byId['hyd-pressure'], 'anim-hyd-relief-pops.gif') !== false ? 'rv-gif' : 'rv-no') . '|' . " +
    "(strpos($byId['pne-elehp-sequences'], 'anim-pne-sequence.gif') !== false ? 'seq-gif' : 'seq-no') . '|' .\n" +
    "(function_exists('rgz_ll_anim_for') ? 'map-ok' : 'map-miss') . '|' . " +
    "implode(',', rgz_ll_anim_for('hl-dcv-43'));"
  );
  fails += r.fatal ? 1 : 0;
  {
    const p2 = r.out.split("|");
    expect(p2[0] === "dcv-gif" && p2[1] === "cyl-gif" && p2[2] === "rv-gif" && p2[3] === "seq-gif", "factory flagship lessons carry animated GIF figures: " + r.out.slice(0, 60));
    expect(p2[4] === "map-ok" && /anim-hyd-dcv-spool\.gif/.test(p2[5] || ""), "library anim map resolves hl-dcv-43 → spool gif");
  }

  // 9f) deck account top bar + modals + converter
  r = await run(php, "deck account top bar + modals", store, "echo RGZ_Mechanical_Deck::render_deck([]);");
  fails += r.fatal ? 1 : 0;
  expect(r.out.includes('data-rgz-user-chip') && r.out.includes('rgzd-topbar'), "account chip in top bar present");
  expect(r.out.includes('data-rgz-user-action="profile"') && r.out.includes('data-rgz-user-action="designs"') && r.out.includes('data-rgz-user-action="logout"'), "dropdown has Edit profile / My designs / Sign out");
  expect(r.out.includes('data-rgzpm="auth"') && r.out.includes('data-rgz-auth-go="signin"') && r.out.includes('data-rgz-auth-go="signup"'), "sign in / sign up modal present on the deck");
  expect(r.out.includes("<b>3</b><span>Topics</span>"), "hero Topics stat counts hydraulics + pneumatics + cad = 3 (was app categories = 1)");
  expect(r.out.includes('rgzpm-backdrop" style="--rgzd-accent:'), "every deck modal carries its own inline accent variable");
  {
    const sec = r.out.indexOf('<section class="rgzd"'), cls = r.out.indexOf("</section>", sec);
    const au = r.out.indexOf('data-rgzpm="auth"'), pf = r.out.indexOf('data-rgzpm="profile"'), ds = r.out.indexOf('data-rgzpm="designs"');
    expect(sec >= 0 && sec < au && au < cls && sec < pf && pf < cls && sec < ds && ds < cls, "auth/profile/designs modals live INSIDE the accent section");
  }
  expect(r.out.includes('data-rgzpm="profile"') && r.out.includes('data-rgzp-avatars'), "profile editor modal with avatar picker present");
  expect(r.out.includes('data-rgzpm="designs"') && r.out.includes('data-rgz-designs="hydraulic"') && r.out.includes('data-rgz-designs="pneumatic"'), "designs modal with per-studio grids present");
  expect(!r.out.includes('data-deck-tab="profile"'), "old Profile tab removed");
  expect(!r.out.includes('data-deck-tab="convert"'), "converter tab removed (converter is now always visible)");
  expect(r.out.includes('rgzd-hero-conv') && r.out.includes('data-rgz-conv') && r.out.includes('data-rgzc-qty') && r.out.includes('data-rgzc-swap'), "unit converter pinned into the hero");
  expect(r.out.includes('rgzd-convm') && (r.out.match(/data-rgz-conv/g) || []).length === 2, "mobile collapsible converter instance present after the tabs (2 instances total)");

  // 9g) profile endpoints: save → progress → read back (studio-token auth)
  const AUTH_SNIPPET =
    "function tok($email,$suffix){" +
    "  $payload=['id'=>1,'email'=>$email,'exp'=>time()+99999,'rnd'=>'0123456789abcdef'];" +
    "  $body=rtrim(strtr(base64_encode(json_encode($payload)),'+/','-_'),'=');" +
    "  $sig=rtrim(strtr(base64_encode(hash_hmac('sha256',$body,wp_salt('auth').$suffix,true)),'+/','-_'),'=');" +
    "  return $body.'.'.$sig;" +
    "} $_POST=['nonce'=>wp_create_nonce('rgz_deck_public')," +
    " 'htoken'=>tok('houman@test.de','|rgz-hydraulic-account-token')," +
    " 'ptoken'=>tok('houman@test.de','|rgz-pneumatic-account-token')];";
  r = await run(php, "profile save endpoint", store,
    AUTH_SNIPPET +
    "$_POST['first_name']='Houman'; $_POST['last_name']='RGZ'; $_POST['phone']='+49 170 000'; $_POST['company']='RGZ Eng';" +
    "RGZ_Mechanical_Deck::ajax_profile_save();");
  fails += r.fatal ? 1 : 0;
  {
    let j = {};
    try { j = JSON.parse(r.out); } catch (e) {}
    expect(j.success === true, "profile_save returns success: " + r.out.slice(0, 200));
    expect(j.data && j.data.profile && j.data.profile.first_name === "Houman" && j.data.profile.last_name === "RGZ", "first/last name persisted in profile");
    expect(j.data && j.data.profile && j.data.profile.phone === "+49 170 000", "phone persisted");
    expect(j.data && j.data.email === "houman@test.de", "identity email resolved from studio tokens");
    expect(j.data && Array.isArray(j.data.sources) && j.data.sources.length === 2, "both studios recognized as account sources");
  }
  store = r.state.options || store;
  expect(store.rgz_mech_deck_profiles && store.rgz_mech_deck_profiles[require("crypto").createHash("md5").update("houman@test.de").digest("hex")] !== undefined, "profile stored server-side keyed by md5(email)");

  r = await run(php, "progress save + read-back", store,
    AUTH_SNIPPET +
    "$_POST['lesson']='hyd-pascal'; $_POST['read']='1'; RGZ_Mechanical_Deck::ajax_progress_save();");
  fails += r.fatal ? 1 : 0;
  {
    let j = {};
    try { j = JSON.parse(r.out); } catch (e) {}
    expect(j.success === true && j.data && Array.isArray(j.data.progress) && j.data.progress.includes("hyd-pascal"), "progress_save stores lesson as read");
  }
  store = r.state.options || store;

  r = await run(php, "profile fetch merges saved data", store,
    AUTH_SNIPPET + "RGZ_Mechanical_Deck::ajax_profile();");
  fails += r.fatal ? 1 : 0;
  {
    let j = {};
    try { j = JSON.parse(r.out); } catch (e) {}
    expect(j.success === true && j.data && j.data.profile && j.data.profile.first_name === "Houman", "profile fetch returns saved contact data");
    expect(j.data && j.data.progress && j.data.progress.includes("hyd-pascal"), "profile fetch returns learning progress");
    expect(j.data && j.data.designs && Array.isArray(j.data.designs.hydraulic) && Array.isArray(j.data.designs.pneumatic), "designs object present for both apps");
  }

  // 9h) endpoint rejects bad nonce / bad token
  r = await run(php, "endpoint rejects forged token", store,
    "function tok2($email){ $body=rtrim(strtr(base64_encode(json_encode(['id'=>1,'email'=>$email,'exp'=>time()+99999])),'+/','-_'),'='); return $body.'.forged'; }" +
    "$_POST=['nonce'=>wp_create_nonce('rgz_deck_public'),'htoken'=>tok2('evil@test.de')]; RGZ_Mechanical_Deck::ajax_profile();");
  fails += r.fatal ? 1 : 0;
  {
    let j = {};
    try { j = JSON.parse(r.out); } catch (e) {}
    expect(j.success === false, "forged token is rejected: " + r.out.slice(0, 120));
  }
  r = await run(php, "endpoint rejects bad nonce", store,
    AUTH_SNIPPET + "$_POST['nonce']='wrong-nonce'; RGZ_Mechanical_Deck::ajax_profile();");
  fails += r.fatal ? 1 : 0;
  {
    let j = {};
    try { j = JSON.parse(r.out); } catch (e) {}
    expect(j.success === false, "bad nonce is rejected: " + r.out.slice(0, 120));
  }

  // 9i) lesson form has media library + template buttons
  r = await run(php, "lesson form media tooling", store, "$_GET['action']='new'; RGZ_Mechanical_Deck::render_learn_admin();");
  fails += r.fatal ? 1 : 0;
  expect(r.out.includes("data-media-cover"), "cover: media library button present");
  expect(r.out.includes("data-media-content"), "content: insert-image button present");
  expect(r.out.includes('data-tpl="formula"') && r.out.includes('data-tpl="steps"'), "HTML block template buttons present");
  expect(r.out.includes('style="color:#eb4e3c'), "HTML styling help text mentions inline styles");

  // 10) tour_enabled + version sanity
  r = await run(php, "version stays 1.0.0", store, "echo RGZ_Mechanical_Deck::VERSION . '|' . RGZ_Hydraulic_Studio_Plugin::VERSION . '|' . RGZ_Pneumatic_Studio_Plugin::VERSION;");
  fails += r.fatal ? 1 : 0;
  expect(/1\.0\.0\|1\.0\.0\|1\.0\.0/.test(r.out), "all classes report 1.0.0");

  // 11) EXT — app extensibility: hooks, guides tab, shipped docs & starter plugin
  {
    const deckSrc = fs.readFileSync(PLUGIN_DIR + "/rgz-mechanical-deck.php", "utf8");
    ["rgz_deck_apps","rgz_deck_app_categories","rgz_deck_icons","rgz_deck_learn_topics","rgz_deck_topic_accents","rgz_deck_tour_enabled","rgz_deck_tour_text","rgz_deck_profile_designs"].forEach(function (h) {
      expect(deckSrc.indexOf("apply_filters('" + h + "'") !== -1, "extension hook registered: " + h);
    });
    expect(deckSrc.indexOf('data-tab="rgza-help"') !== -1, "deck manager exposes a Guides tab");
    expect(deckSrc.indexOf("data-add-app-starter") !== -1, "Apps pane offers a starter-template button");
    expect(deckSrc.indexOf("docs/ADDING-AN-APP.md") !== -1 && deckSrc.indexOf("docs/APP-DEVELOPMENT-GUIDE.md") !== -1, "admin screens link the two guides");
    expect(fs.existsSync(PLUGIN_DIR + "/docs/ADDING-AN-APP.md"), "docs/ADDING-AN-APP.md ships in the plugin");
    expect(fs.existsSync(PLUGIN_DIR + "/docs/APP-DEVELOPMENT-GUIDE.md"), "docs/APP-DEVELOPMENT-GUIDE.md ships in the plugin");

    // A2) app packages: installer class, wiring, template, docs
    const pkg = PLUGIN_DIR + "/rgz-app-packages.php";
    expect(fs.existsSync(pkg), "rgz-app-packages.php ships in the plugin");
    const pkgSrc = fs.readFileSync(pkg, "utf8");
    expect(fs.readFileSync(PLUGIN_DIR + "/rgz-engineering-studio.php", "utf8").indexOf("require_once __DIR__ . '/rgz-app-packages.php'") !== -1, "bootstrap requires the packages file");
    expect(fs.readFileSync(PLUGIN_DIR + "/rgz-engineering-studio.php", "utf8").indexOf("RGZ_Mech_App_Packages::boot()") !== -1, "bootstrap boots the packages loader");
    ["validate_manifest", "load_apps", "deck_cards", "handle_upload", "handle_remove", "render_manager", "rgz_app_package_upload", "rgz-app.json", ".htaccess", "ZipArchive", "shortcode_available"].forEach(function (sym) {
      expect(pkgSrc.indexOf(sym) !== -1, "rgz-app-packages.php provides: " + sym);
    });
    const tplDir = PLUGIN_DIR + "/docs/app-package-template";
    expect(fs.existsSync(tplDir + "/rgz-app.json") && fs.existsSync(tplDir + "/app.php") && fs.existsSync(tplDir + "/README.md"), "template package folder ships (manifest + entry + readme)");
    expect(fs.existsSync(PLUGIN_DIR + "/docs/app-package-template.zip"), "ready-to-build app-package-template.zip ships");
    try {
      const man = JSON.parse(fs.readFileSync(tplDir + "/rgz-app.json", "utf8"));
      expect(/^[a-z0-9][a-z0-9\-]{1,48}$/.test(man.id) && /^[a-z0-9_]{3,40}$/.test(man.shortcode) && !!man.entry && !!man.class && !!man.render && man.card && !!man.card.title, "template manifest is complete and well-formed");
    } catch (e) { expect(false, "template manifest parses as JSON"); }
    const tplPhp = fs.readFileSync(tplDir + "/app.php", "utf8");
    expect(tplPhp.indexOf("if (!defined('ABSPATH')) { exit; }") !== -1, "template entry has the required ABSPATH guard");
    expect(deckSrc.indexOf("RGZ_Mech_App_Packages::deck_cards()") !== -1, "deck merges package cards in get_apps()");
    expect(deckSrc.indexOf("RGZ_Mech_App_Packages::render_manager()") !== -1, "deck admin renders the package manager");
    expect(deckSrc.indexOf("app-package-template.zip") !== -1 && deckSrc.indexOf("app_pkg_exists") !== -1, "deck admin offers the template + installer notices");
    expect(fs.readFileSync(PLUGIN_DIR + "/assets/admin-deck.js", "utf8").indexOf("data-add-app-starter") !== -1, "admin JS handles the starter-template button");
    const readme = fs.readFileSync(PLUGIN_DIR + "/README.md", "utf8");
    expect(readme.indexOf("APP-DEVELOPMENT-GUIDE.md") !== -1 && readme.indexOf("app-package-template.zip") !== -1, "README points to the guide + package template");
  }

  r = await run(php, "extensibility: rgz_deck_apps merge + id dedupe", store,
    "$before = RGZ_Mechanical_Deck::get_apps();\n" +
    "add_filter('rgz_deck_apps', function ($apps) { $apps[] = ['id'=>'mechatronics-studio','title'=>'Mechatronics Studio','desc'=>'d','category'=>'Mechanics','icon'=>'gear','accent'=>'#f59e0b','badge'=>'Beta','url'=>'https://site.test/m/','learnTopic'=>'','enabled'=>true]; return $apps; });\n" +
    "add_filter('rgz_deck_apps', function ($apps) { $apps[] = ['id'=>'hydraulic-studio','title'=>'DUP','enabled'=>true]; return $apps; });\n" +
    "$after = RGZ_Mechanical_Deck::get_apps();\n" +
    "$ids = array_map(function ($a) { return $a['id']; }, $after);\n" +
    "echo (count($after) - count($before)) . '|' . (in_array('mechatronics-studio', $ids, true) ? 'has-new' : 'missing') . '|' . (count(array_keys($ids, 'hydraulic-studio')) === 1 ? 'dedup-ok' : 'dedup-fail');");
  fails += r.fatal ? 1 : 0;
  expect(r.out.trim() === "1|has-new|dedup-ok", "code-registered app merges; existing ids win (got: " + r.out.trim().slice(0, 60) + ")");

  r = await run(php, "extensibility: custom topic + icon pass validation", store,
    "add_filter('rgz_deck_learn_topics', function ($t) { $t['mechatronics'] = 'Mechatronics'; return $t; });\n" +
    "add_filter('rgz_deck_icons', function ($i2) { $i2['robot-arm'] = '<svg></svg>'; return $i2; });\n" +
    "$L = RGZ_Mechanical_Deck::sanitize_lesson(['topic'=>'mechatronics','title'=>'T','minutes'=>5]);\n" +
    "$_POST = ['rgz_apps_json' => json_encode([['id'=>'x1','title'=>'X','icon'=>'robot-arm','learnTopic'=>'mechatronics','enabled'=>true]])];\n" +
    "RGZ_Mechanical_Deck::save_apps();\n" +
    "$saved = get_option('rgz_mech_deck_apps');\n" +
    "echo $L['topic'] . '|' . $saved[0]['icon'] . '|' . $saved[0]['learnTopic'];");
  fails += r.fatal ? 1 : 0;
  expect(r.out.trim() === "mechatronics|robot-arm|mechatronics", "custom learn topic + custom icon survive sanitize/save");

  r = await run(php, "extensibility: learn hub renders chip for registered topic", store,
    "add_filter('rgz_deck_learn_topics', function ($t) { $t['mechatronics'] = 'Mechatronics'; return $t; });\n" +
    "echo RGZ_Mechanical_Deck::render_learn([]);");
  fails += r.fatal ? 1 : 0;
  expect(r.out.indexOf('data-topic-chip="mechatronics"') !== -1, "hub topic chip appears for a registered topic");

  r = await run(php, "packages: validate_manifest accepts + cleans", store,
    "$e=''; $m = RGZ_Mech_App_Packages::validate_manifest(['id'=>'mech-demo','name'=>'Mech Demo','version'=>'2.0.1','shortcode'=>'rgz_mech_demo','entry'=>'app.php','class'=>'C_Demo','render'=>'go','card'=>['title'=>'T','accent'=>'#123456']], $e);\n" +
    "echo is_array($m) ? ($m['id'].'|'.$m['version'].'|'.$m['shortcode'].'|'.$m['class'].'|'.$m['render'].'|'.$m['card']['title']) : ('FAIL '.$e);");
  fails += r.fatal ? 1 : 0;
  expect(r.out.trim() === "mech-demo|2.0.1|rgz_mech_demo|C_Demo|go|T", "valid manifest accepted + fields cleaned (got: " + r.out.trim().slice(0,60) + ")");

  r = await run(php, "packages: validate_manifest rejects bad input", store,
    "$cases = [\n" +
    "  ['id'=>'X!', 'name'=>'n', 'shortcode'=>'rgz_x_ok_1'],\n" +
    "  ['id'=>'ok-id', 'name'=>'', 'shortcode'=>'rgz_x_ok_2'],\n" +
    "  ['id'=>'ok-id', 'name'=>'n', 'shortcode'=>'Bad Shortcode!'],\n" +
    "  ['id'=>'ok-id', 'name'=>'n', 'shortcode'=>'rgz_hydraulic_studio'],\n" +
    "  ['id'=>'ok-id', 'name'=>'n', 'shortcode'=>'rgz_x_ok_3', 'entry'=>'sub/app.php'],\n" +
    "  ['id'=>'ok-id', 'name'=>'n', 'shortcode'=>'rgz_x_ok_4', 'entry'=>'app.txt'],\n" +
    "];\n" +
    "$out = []; foreach ($cases as $c) { $e=''; $out[] = RGZ_Mech_App_Packages::validate_manifest($c, $e) ? 'ACCEPTED' : 'rejected'; }\n" +
    "echo implode('|', $out);");
  fails += r.fatal ? 1 : 0;
  expect(r.out.trim() === "rejected|rejected|rejected|rejected|rejected|rejected", "bad id / name / shortcode / reserved / entry traversal / non-php all rejected");

  r = await run(php, "packages: shortcode_available respects registry + core", store,
    "update_option('rgz_mech_deck_app_packages', ['a-pkg' => ['shortcode' => 'rgz_taken_x']]);\n" +
    "echo (RGZ_Mech_App_Packages::shortcode_available('rgz_hydraulic_studio') ? 'BAD1' : 'core-taken') . '|' .\n" +
    "     (RGZ_Mech_App_Packages::shortcode_available('rgz_totally_free_x') ? 'free-ok' : 'BAD2') . '|' .\n" +
    "     (RGZ_Mech_App_Packages::shortcode_available('rgz_taken_x') ? 'BAD3' : 'reg-taken') . '|' .\n" +
    "     (RGZ_Mech_App_Packages::shortcode_available('rgz_taken_x', 'a-pkg') ? 'self-ok' : 'BAD4');");
  fails += r.fatal ? 1 : 0;
  expect(r.out.trim() === "core-taken|free-ok|reg-taken|self-ok", "shortcode collisions detected (core, free, registry, self-overwrite)");

    r = await run(php, "packages: loader registers shortcode + reports broken entry", store,
    "$root = RGZ_Mech_App_Packages::apps_root();\n" +
    "@mkdir($root . 'demo-x', 0755, true); @mkdir($root . 'broken-z', 0755, true);\n" +
    "file_put_contents($root . 'demo-x/app.php', \"<?php if(!defined('ABSPATH')){exit;} class RGZ_Demo_X { public static function go(\\$atts){ return '<b>DEMO-X-RENDER</b>'; } }\");\n" +
    "file_put_contents($root . 'broken-z/app.php', \"<?php this is not php at all\");\n" +
    "file_put_contents($root . 'demo-x/rgz-app.json', '{}');\n" +
    "$reg = [];\n" +
    "$e=''; $reg['demo-x'] = RGZ_Mech_App_Packages::validate_manifest(['id'=>'demo-x','name'=>'Demo X','shortcode'=>'rgz_demo_x','entry'=>'app.php','class'=>'RGZ_Demo_X','render'=>'go','card'=>['title'=>'Demo X Card','category'=>'Mechanics']], $e);\n" +
    "$e=''; $reg['broken-z'] = RGZ_Mech_App_Packages::validate_manifest(['id'=>'broken-z','name'=>'Broken Z','shortcode'=>'rgz_broken_z','entry'=>'app.php','class'=>'Nope','render'=>'go'], $e);\n" +
    "update_option('rgz_mech_deck_app_packages', $reg);\n" +
    "RGZ_Mech_App_Packages::load_apps(true);\n" +
    "echo (shortcode_exists('rgz_demo_x') ? 'sc-ok' : 'sc-missing') . '|';\n" +
    "echo (shortcode_exists('rgz_broken_z') ? 'BAD' : 'blocked') . '|';\n" +
    "$st1 = RGZ_Mech_App_Packages::runtime_status('demo-x'); $st2 = RGZ_Mech_App_Packages::runtime_status('broken-z');\n" +
    "echo $st1['status'] . '|' . $st2['status'] . '|';\n" +
    "echo strpos(RGZ_Demo_X::go([]), 'DEMO-X-RENDER') !== false ? 'render-ok' : 'render-fail';");
  fails += r.fatal ? 1 : 0;
  expect(r.out.trim() === "sc-ok|blocked|ok|error|render-ok", "loader: good package works, broken one flagged without taking the site down (got: " + r.out.trim().slice(0,80) + ")");

    r = await run(php, "packages: deck cards merge + admin copy wins", store,
    "$root = RGZ_Mech_App_Packages::apps_root();\n" +
    "@mkdir($root . 'demo-x', 0755, true);\n" +
    "file_put_contents($root . 'demo-x/app.php', \"<?php if(!defined('ABSPATH')){exit;} class RGZ_Demo_X { public static function go(\\$atts){ return 'x'; } }\");\n" +
    "$e=''; $reg = ['demo-x' => RGZ_Mech_App_Packages::validate_manifest(['id'=>'demo-x','name'=>'Demo X','shortcode'=>'rgz_demo_x','entry'=>'app.php','class'=>'RGZ_Demo_X','render'=>'go','card'=>['title'=>'Package Title']], $e)];\n" +
    "update_option('rgz_mech_deck_app_packages', $reg);\n" +
    "RGZ_Mech_App_Packages::load_apps(true);\n" +
    "$apps = RGZ_Mechanical_Deck::get_apps();\n" +
    "$byId = []; foreach ($apps as $a) { $byId[$a['id']] = $a; }\n" +
    "echo (isset($byId['demo-x']) && $byId['demo-x']['title'] === 'Package Title' && $byId['demo-x']['enabled'] ? 'merged-ok' : 'merge-fail') . '|';\n" +
    "update_option('rgz_mech_deck_apps', array_merge(get_option('rgz_mech_deck_apps', []), [['id'=>'demo-x','title'=>'ADMIN TITLE','enabled'=>true]]));\n" +
    "$apps2 = RGZ_Mechanical_Deck::get_apps();\n" +
    "$cnt = 0; $title = ''; foreach ($apps2 as $a) { if ($a['id'] === 'demo-x') { $cnt++; $title = $a['title']; } }\n" +
    "echo ($cnt === 1 && $title === 'ADMIN TITLE') ? 'admin-wins' : 'dedupe-fail';");
  fails += r.fatal ? 1 : 0;
  expect(r.out.trim() === "merged-ok|admin-wins", "package card appears on the deck; admin-edited copy wins by id");

    r = await run(php, "packages: upload handler e2e (real zip)", store,
    "define('RGZ_PKG_TEST', 1);\n" +
    "$mk = function($over) {\n" +
    "  $z = '/internal/uploads/e2e.zip'; if (file_exists($z)) { unlink($z); }\n" +
    "  $zip = new ZipArchive(); $zip->open($z, ZipArchive::CREATE);\n" +
    "  $zip->addFromString('rgz-app.json', json_encode(['id'=>'e2e-app','name'=>'E2E App','shortcode'=>'rgz_e2e_app','entry'=>'app.php','class'=>'RGZ_E2E_App'.($over?'2':''),'render'=>'go','card'=>['title'=>'E2E']]));\n" +
    "  $zip->addFromString('app.php', \"<?php if(!defined('ABSPATH')){exit;} class RGZ_E2E_App\".($over?'2':'').\" { public static function go(\\$a){ return 'e2e-x'; } }\");\n" +
    "  $zip->close();\n" +
    "  $_FILES['rgz_app_package'] = ['name'=>'e2e.zip','tmp_name'=>$z,'error'=>0,'size'=>filesize($z)];\n" +
    "  $_POST['rgz_app_overwrite'] = $over ? '1' : '';\n" +
    "};\n" +
    "$tryUp = function() { try { RGZ_Mech_App_Packages::handle_upload(); return 'NO-REDIRECT'; } catch (\\Throwable $ex) { return $ex->getMessage() === '__REDIRECT__' ? end($GLOBALS['__redirect']) : 'THROW:' . $ex->getMessage(); } };\n" +
    "$mk(false); $red1 = $tryUp();\n" +
    "$r1 = RGZ_Mech_App_Packages::registry();\n" +
    "echo (strpos($red1, 'saved=app_pkg') !== false ? 'install-ok' : 'install-fail ' . $red1) . '|';\n" +
    "echo (isset($r1['e2e-app']) && file_exists(RGZ_Mech_App_Packages::apps_root('e2e-app') . 'app.php') ? 'files-ok' : 'files-missing') . '|';\n" +
    "$mk(false); $red2 = $tryUp();\n" +
    "echo (strpos($red2, 'saved=app_pkg_exists') !== false ? 'exists-guard-ok' : 'exists-fail ' . $red2) . '|';\n" +
    "$mk(true); $red3 = $tryUp();\n" +
    "echo (strpos($red3, 'saved=app_pkg') !== false && strpos($red3, 'exists') === false ? 'overwrite-ok' : 'overwrite-fail ' . $red3);");
  fails += r.fatal ? 1 : 0;
  expect(r.out.trim() === "install-ok|files-ok|exists-guard-ok|overwrite-ok", "zip upload: install, exists-guard, overwrite all behave (got: " + r.out.trim().slice(0,110) + ")");

    const SLIP_B64 = mkZipRaw([
    { name: "rgz-app.json", data: JSON.stringify({ id: "slip-app", name: "S", shortcode: "rgz_slip_app", entry: "app.php" }) },
    { name: "app.php", data: "<?php if(!defined('ABSPATH')){exit;}" },
    { name: "../evil.php", data: "<?php // no" },
  ]).toString("base64");

  r = await run(php, "packages: upload rejects bad manifest + zip-slip", store,
    "define('RGZ_PKG_TEST', 1); define('SLIP_B64', '" + SLIP_B64 + "');\n" +
    "$tryUp = function() { try { RGZ_Mech_App_Packages::handle_upload(); return 'NO-REDIRECT'; } catch (\\Throwable $ex) { return $ex->getMessage() === '__REDIRECT__' ? end($GLOBALS['__redirect']) : 'THROW:' . $ex->getMessage(); } };\n" +
    "$z = '/internal/uploads/bad1.zip'; if (file_exists($z)) { unlink($z); }\n" +
    "$zip = new ZipArchive(); $zip->open($z, ZipArchive::CREATE);\n" +
    "$zip->addFromString('rgz-app.json', json_encode(['id'=>'X!','name'=>'bad'])); $zip->close();\n" +
    "$_FILES['rgz_app_package'] = ['name'=>'bad1.zip','tmp_name'=>$z,'error'=>0,'size'=>filesize($z)];\n" +
    "$redA = $tryUp();\n" +
    "$z2 = '/internal/uploads/bad2.zip'; if (file_exists($z2)) { unlink($z2); }\n" +
    "file_put_contents($z2, base64_decode(SLIP_B64));\n" +
    "$_FILES['rgz_app_package'] = ['name'=>'bad2.zip','tmp_name'=>$z2,'error'=>0,'size'=>filesize($z2)];\n" +
    "$redB = $tryUp();\n" +
    "$rBad = RGZ_Mech_App_Packages::registry();\n" +
    "echo ((strpos($redA, 'saved=app_pkg_err') !== false && strpos(urldecode($redA), 'Invalid rgz-app.json') !== false) ? 'manifest-guard-ok' : 'A:' . $redA) . '|';\n" +
    "echo ((strpos($redB, 'saved=app_pkg_err') !== false && strpos(urldecode($redB), 'Unsafe path') !== false && !file_exists('/internal/uploads/rgz-apps/evil.php') && !isset($rBad['slip-app'])) ? 'slip-guard-ok' : 'B:' . urldecode($redB));");
  fails += r.fatal ? 1 : 0;
  expect(r.out.trim() === "manifest-guard-ok|slip-guard-ok", "bad manifest and zip-slip rejected with clear messages (GOT: [" + r.out.trim().slice(0,300) + "])");

  store["rgz_mech_deck_app_packages"] = {
    "mechatronics-demo": { id: "mechatronics-demo", name: "Mechatronics Demo", version: "1.0.0", shortcode: "rgz_mechatronics_demo", entry: "app.php", class: "Nope_Demo", render: "go", card: { title: "Mechatronics Demo", category: "Mechanics", icon: "gear", accent: "#f59e0b" }, installed: 1786000000 }
  };
  r = await run(php, "admin: deck manager Guides tab + docs links", store, "RGZ_Mechanical_Deck::render_deck_admin();");
  fails += r.fatal ? 1 : 0;
  expect(r.out.indexOf('data-tab="rgza-help"') !== -1 && r.out.indexOf('id="rgza-help"') !== -1, "Guides tab + pane render");
  expect(r.out.indexOf("docs/ADDING-AN-APP.md") !== -1 && r.out.indexOf("docs/APP-DEVELOPMENT-GUIDE.md") !== -1 && r.out.indexOf("docs/app-package-template.zip") !== -1, "Guides pane links both guides + package template");
  expect(r.out.indexOf("data-add-app-starter") !== -1, "starter-template button renders in Apps pane");
  expect(r.out.indexOf("rgz_deck_apps") !== -1 && r.out.indexOf("app-package-template.zip") !== -1, "Guides pane links hooks + package template");
  expect(r.out.indexOf('name="rgz_app_package"') !== -1 && r.out.indexOf("rgz_app_package_upload") !== -1, "installer upload form renders");
  expect(r.out.indexOf("Installed app packages") !== -1 && r.out.indexOf("rgz_mechatronics_demo") !== -1 && r.out.indexOf("Mechatronics Demo") !== -1, "installed packages table lists shortcode + name");
  expect(r.out.indexOf("create a page with [rgz_mechatronics_demo]") !== -1, "table prompts to create the app page when undetected");
  expect(r.out.indexOf("rgz_app_package_remove&amp;app=mechatronics-demo") !== -1 || r.out.indexOf("rgz_app_package_remove&app=mechatronics-demo") !== -1, "remove action wired per package");


  /* ---------- RGZ 3D CAD Studio backend module ---------- */
  r = await run(php, "cad: backend module boots, hooks + filters registered", store,
    "echo class_exists('RGZ_CAD_Studio_Plugin') ? 'cad-class|' : 'cad-missing|';\n" +
    "$hs = array_column($GLOBALS['__hooks'], 1);\n" +
    "echo (in_array('wp_ajax_nopriv_rgz_cad_save_design', $hs) && in_array('wp_ajax_nopriv_rgz_cad_login', $hs) && in_array('wp_ajax_nopriv_rgz_cad_my_designs', $hs) && in_array('wp_ajax_nopriv_rgz_cad_get_design', $hs) ? 'ajax-ok|' : 'ajax-missing|');\n" +
    "echo ((isset($GLOBALS['__filters']['rgz_deck_learn_topics']) && isset($GLOBALS['__filters']['rgz_deck_profile_designs']) && isset($GLOBALS['__filters']['rgz_deck_topic_accents'])) ? 'filters-ok' : 'filters-missing');");
  fails += r.fatal ? 1 : 0;
  expect(r.out.trim() === "cad-class|ajax-ok|filters-ok", "CAD module class + ajax endpoints + deck connectors registered (got: " + r.out.trim().slice(0,90) + ")");

  r = await run(php, "cad: tables + hub topic + 7 leveled lessons", store,
    "$GLOBALS['__dbDelta'] = [];\n" +
    "RGZ_CAD_Studio_Plugin::install();\n" +
    "echo (count($GLOBALS['__dbDelta']) >= 2 ? 'tables-ok' : 'tables-missing') . '|';\n" +
    "$topics = apply_filters('rgz_deck_learn_topics', []);\n" +
    "echo ((isset($topics['cad']) && $topics['cad'] === 'CAD & Design') ? 'topic-ok' : 'topic-missing') . '|';\n" +
    "$acc = apply_filters('rgz_deck_topic_accents', []);\n" +
    "echo ((isset($acc['cad']) && $acc['cad'] === '#eb4e3c') ? 'accent-ok' : 'accent-missing') . '|';\n" +
    "$L = RGZ_Mechanical_Deck::default_lessons();\n" +
    "$cadL = array_values(array_filter($L, function ($l) { return (isset($l['topic']) ? $l['topic'] : '') === 'cad'; }));\n" +
    "echo (count($cadL) === 7 ? 'lessons-ok' : 'lessons-' . count($cadL)) . '|';\n" +
    "$ids = array_column($cadL, 'id');\n" +
    "echo ((in_array('cad-f-sketch-lines', $ids) && in_array('cad-f-iso-1101', $ids)) ? 'lesson-ids-ok' : 'lesson-ids-missing') . '|';\n" +
    "$lv = array_unique(array_column($cadL, 'level'));\n" +
    "echo ((in_array('beginner', $lv) && in_array('intermediate', $lv) && in_array('advanced', $lv)) ? 'levels-ok' : 'levels-missing') . '|';\n" +
    "$cov = 0; foreach ($cadL as $cl) { if (strpos(isset($cl['cover']) ? $cl['cover'] : '', 'cov-cad-elements.svg') !== false) { $cov++; } }\n" +
    "echo ($cov === 7 ? 'covers-ok' : 'covers-' . $cov) . '|';\n" +
    "$srcD = file_get_contents('/internal/rgz-mechanical-deck.php');\n" +
    "echo (strpos($srcD, 'data-rgz-designs=' . chr(34) . 'cad' . chr(34)) !== false ? 'modal-ok' : 'modal-missing') . '|';\n" +
    "echo (strpos($srcD, '|rgz-cad-account-token') !== false ? 'token-bind-ok' : 'token-bind-missing');");
  fails += r.fatal ? 1 : 0;
  expect(r.out.trim() === "tables-ok|topic-ok|accent-ok|lessons-ok|lesson-ids-ok|levels-ok|covers-ok|modal-ok|token-bind-ok",
    "CAD installs tables, owns a hub topic w/ accent, seeds 7 leveled lessons w/ cover, deck modal merged (got: " + r.out.trim().slice(0,140) + ")");

  r = await run(php, "cad: account ajax e2e (register→save→list→get→update→delete)", store,
    "$call = function ($fn) { ob_start(); try { $fn(); } catch (Throwable $e) { if ($e->getMessage() !== '__JSON_END__') { throw $e; } } return json_decode(ob_get_clean(), true); };\n" +
    "$outW = [];\n" +
    "$_POST = ['name' => 'Houman', 'email' => 'h@x.ir', 'password' => 'secret1'];\n" +
    "$r1 = $call(function () { RGZ_CAD_Studio_Plugin::ajax_register(); });\n" +
    "$outW[] = ($r1['success'] && !empty($r1['data']['token']) ? 'reg' : 'reg-fail');\n" +
    "$tok = $r1['data']['token'];\n" +
    "$_POST = ['token' => $tok, 'nonce' => wp_create_nonce('rgz_cad_public'), 'design_name' => 'Bracket', 'design_json' => json_encode(['v' => 1, 'outer' => ['type' => 'rect'], 'holes' => []])];\n" +
    "$r2 = $call(function () { RGZ_CAD_Studio_Plugin::ajax_save_design(); });\n" +
    "$did = $r2['success'] ? (int) $r2['data']['id'] : 0;\n" +
    "$outW[] = ($did > 0 ? 'save' : 'save-fail');\n" +
    "$_POST = ['token' => $tok];\n" +
    "$r3 = $call(function () { RGZ_CAD_Studio_Plugin::ajax_my_designs(); });\n" +
    "$outW[] = ($r3['success'] && count($r3['data']['designs']) === 1 ? 'my1' : 'my-fail');\n" +
    "$_POST = ['token' => $tok, 'id' => $did];\n" +
    "$r4 = $call(function () { RGZ_CAD_Studio_Plugin::ajax_get_design(); });\n" +
    "$outW[] = ($r4['success'] && strpos($r4['data']['design']['design_json'], 'rect') !== false ? 'get' : 'get-fail');\n" +
    "$_POST = ['token' => $tok, 'nonce' => wp_create_nonce('rgz_cad_public'), 'design_name' => 'Bracket v2', 'design_id' => $did, 'design_json' => json_encode(['v' => 2, 'sketches' => [['id' => 'sk1', 'name' => 'Sketch.1', 'plane' => ['kind' => 'xy'], 'entities' => []]], 'features' => []])];\n" +
    "$r5 = $call(function () { RGZ_CAD_Studio_Plugin::ajax_save_design(); });\n" +
    "$outW[] = ($r5['success'] && (int) $r5['data']['id'] === $did ? 'v2ok' : 'v2ok-fail');\n" +
    "$_POST = ['token' => $tok, 'nonce' => wp_create_nonce('rgz_cad_public'), 'design_name' => 'Junk', 'design_json' => json_encode(['v' => 9, 'nope' => true])];\n" +
    "$rJ = $call(function () { RGZ_CAD_Studio_Plugin::ajax_save_design(); });\n" +
    "$outW[] = (!$rJ['success'] ? 'junk' : 'junk-fail');\n" +
    "$_POST = ['token' => $tok];\n" +
    "$r6 = $call(function () { RGZ_CAD_Studio_Plugin::ajax_my_designs(); });\n" +
    "$outW[] = (count($r6['data']['designs']) === 1 && $r6['data']['designs'][0]['design_name'] === 'Bracket v2' ? 'still1' : 'still1-fail');\n" +
    "$_POST = ['token' => $tok, 'id' => $did];\n" +
    "$r7 = $call(function () { RGZ_CAD_Studio_Plugin::ajax_delete_design(); });\n" +
    "$_POST = ['token' => $tok];\n" +
    "$r8 = $call(function () { RGZ_CAD_Studio_Plugin::ajax_my_designs(); });\n" +
    "$outW[] = ($r7['success'] && count($r8['data']['designs']) === 0 ? 'del' : 'del-fail');\n" +
    "$_POST = ['token' => 'bogus.token', 'nonce' => wp_create_nonce('rgz_cad_public'), 'design_name' => 'X', 'design_json' => json_encode(['v' => 1, 'outer' => []])];\n" +
    "$r9 = $call(function () { RGZ_CAD_Studio_Plugin::ajax_save_design(); });\n" +
    "$outW[] = (!$r9['success'] ? 'guard' : 'guard-fail');\n" +
    "$_POST = ['login' => 'h@x.ir', 'password' => 'secret1'];\n" +
    "$rA = $call(function () { RGZ_CAD_Studio_Plugin::ajax_login(); });\n" +
    "$outW[] = ($rA['success'] && !empty($rA['data']['token']) ? 'login' : 'login-fail');\n" +
    "$_POST = ['login' => 'h@x.ir', 'password' => 'wrong-1'];\n" +
    "$rB = $call(function () { RGZ_CAD_Studio_Plugin::ajax_login(); });\n" +
    "$outW[] = (!$rB['success'] ? 'badpass' : 'badpass-fail');\n" +
    "echo implode('|', $outW);");
  fails += r.fatal ? 1 : 0;
  expect(r.out.trim() === "reg|save|my1|get|v2ok|junk|still1|del|guard|login|badpass",
    "CAD ajax lifecycle: register, save, list, get, update-in-place, delete, token guard, login (+ wrong password) (got: " + r.out.trim().slice(0,140) + ")");

  r = await run(php, "cad: admin page renders stats, accounts, designs", store,
    "$call = function ($fn) { ob_start(); try { $fn(); } catch (Throwable $e) { if ($e->getMessage() !== '__JSON_END__') { throw $e; } } return json_decode(ob_get_clean(), true); };\n" +
    "$_POST = ['name' => 'Sara Ahmadi', 'email' => 'sara@x.ir', 'password' => 'secret1'];\n" +
    "$a = $call(function () { RGZ_CAD_Studio_Plugin::ajax_register(); });\n" +
    "$_POST = ['token' => $a['data']['token'], 'nonce' => wp_create_nonce('rgz_cad_public'), 'design_name' => 'Gear Cover', 'design_json' => json_encode(['v' => 1, 'outer' => ['type' => 'poly']])];\n" +
    "$call(function () { RGZ_CAD_Studio_Plugin::ajax_save_design(); });\n" +
    "RGZ_CAD_Studio_Plugin::render_admin_page();");
  fails += r.fatal ? 1 : 0;
  expect(r.out.indexOf("RGZ 3D CAD") !== -1 && r.out.indexOf("Gear Cover") !== -1 && r.out.indexOf("sara@x.ir") !== -1,
    "admin page shows the new module with account + design rows (got: " + (r.fatal ? "FATAL" : "rendered") + ")");
  expect(r.out.indexOf("rgz_cad_download_design") !== -1 && r.out.indexOf("rgz_cad_delete_design") !== -1, "admin download/delete actions wired");

  r = await run(php, "admin: overview docs card", store, "RGZ_Mechanical_Deck::render_overview();");
  fails += r.fatal ? 1 : 0;
  expect(r.out.indexOf("Guides &amp; developer docs") !== -1 && r.out.indexOf("docs/APP-DEVELOPMENT-GUIDE.md") !== -1, "overview links the two guides");
  expect(r.out.indexOf("app-package-template.zip") !== -1, "overview links the app package template");

  console.log(fails === 0 ? "\nALL PHP INTEGRATION TESTS PASSED" : "\n" + fails + " FAILURES");
  process.exit(fails === 0 ? 0 : 1);
})();
