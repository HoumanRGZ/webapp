const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const PKG = "/home/user/work/cad-pkg/rgz-3d-cad-studio";
const php = fs.readFileSync(PKG + "/app.php", "utf8");
const start = php.indexOf("?>", php.indexOf("ob_start();"));
const retAt = php.indexOf("return ob_get_clean();");
const end = php.lastIndexOf("<?php", retAt);
let html = php.slice(start + 2, end);
html = html.replace(/<\?php\s*echo\s*esc_url\(home_url\('([^']*)'\)\);?\s*\?>/g, (m, p) => "https://houmanrgz.ir" + p);
html = html.replace(/<\?php[^?]*\?>/g, "RGZ 3D CAD Studio");
const vc = new VirtualConsole(); vc.sendTo(console, { omitJSDOMErrors: true });
const dom = new JSDOM("<!DOCTYPE html><html><head></head><body>" + html + "</body></html>", {
  url: "https://houmanrgz.ir/cad/", runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc });
const win = dom.window, doc = win.document;
function ctx2d(cv) { return new Proxy({}, { get(t, k) {
  if (k === "canvas") return cv;
  if (k === "measureText") return s => ({ width: 7 * String(s).length });
  if (k === "getImageData") return (x, y, w, h) => ({ data: new Uint8ClampedArray(Math.max(4, w * h * 4)) });
  if (k === "createLinearGradient" || k === "createRadialGradient") return () => ({ addColorStop() {} });
  if (k === "isPointInPath") return () => false;
  return () => {}; }, set() { return true; } }); }
win.HTMLCanvasElement.prototype.getContext = function (k) { return k === "2d" ? ctx2d(this) : null; };
win.RGZCAD = { accent: "#eb4e3c", worker: "assets/cad-geometry-worker.js", version: "1.0.0", units: "mm", hubUrl: "https://houmanrgz.ir/mechanical-engineering-deck/#learn-cad" };
const t = doc.createElement("script"); t.textContent = fs.readFileSync(PKG + "/assets/three.min.js", "utf8"); doc.body.appendChild(t);
const c = doc.createElement("script"); c.textContent = fs.readFileSync(PKG + "/assets/cad.js", "utf8"); doc.body.appendChild(c);
setTimeout(() => {
  const U = win.__rgzcad1;
  U.S.design.name = "Manifold Block";
  const sk = U.startSketchOnDatum ? U.startSketchOnDatum("xy") : U.sketch();
  sk.entities.push(U.mkEnt("rect", { cx: 30, cy: 22.5, w: 60, h: 45 }));
  U.closeSketchToPad();
  const pad = U.S.design.features[0];
  pad.L = 16; pad.edge = { style: "chamfer", size: 1 };
  sk.entities.push(U.mkEnt("hole", { cx: 15, cy: 22.5, r: 5, hType: "cbore", depth: 0, cbd: 16, cbdDepth: 4, csAngle: 90 }));
  sk.entities.push(U.mkEnt("hole", { cx: 45, cy: 22.5, r: 5, hType: "through", depth: 0, cbd: 12, cbdDepth: 2, csAngle: 90 }));
  U.padSketch(sk.id);
  U.S.design.sketches.push({ id: "skQ", name: "Sketch.pocket", plane: { kind: "faceTop", topOf: pad.id, origin: [0, 0, 16], u: [1, 0, 0], v: [0, 1, 0], n: [0, 0, 1] }, host: pad.id, entities: [U.mkEnt("rect", { cx: 30, cy: 22.5, w: 30, h: 10 })] });
  U.pocketFromSketch("skQ");
  U.S.design.features[1].L = 6;
  // ---- diagnostics ----
  const pockF = U.S.design.features[1];
  console.log("pocket:", pockF.type, "sketchId:", pockF.sketchId, "host:", (U.S.design.sketches.find(s=>s.id===pockF.sketchId)||{}).host);
  const ws = win.__rgzcad2.worldSoup();
  console.log("worldSoup tris:", ws ? ws.positions.length / 9 : null);
  let onRim = 0, floorV = 0, topIn = 0;
  if (ws) { for (let i = 0; i < ws.positions.length; i += 3) {
    const x = ws.positions[i], y = ws.positions[i+1], z = ws.positions[i+2];
    if (Math.abs(z - 16) < 0.01 && ((Math.abs(y - 17.5) < 0.01 && x > 14.9 && x < 45.1) || (Math.abs(y - 27.5) < 0.01 && x > 14.9 && x < 45.1))) onRim++;
    if (Math.abs(z - 10) < 0.01 && x > 15.1 && x < 44.9 && y > 17.6 && y < 27.4) floorV++;
    if (Math.abs(z - 16) < 0.01 && x > 15.1 && x < 44.9 && y > 17.6 && y < 27.4) topIn++;
  } }
  console.log("world rim verts @z16:", onRim, "| floor verts @z10 inside:", floorV, "| top-cap verts INSIDE pocket (should be 0):", topIn);
  const pos = ws.positions, nor = ws.normals, nT = pos.length/9;
  function vkey(i3){ return Math.round(pos[i3]*4096)+"|"+Math.round(pos[i3+1]*4096)+"|"+Math.round(pos[i3+2]*4096); }
  const emap = {};
  for (let i=0;i<nT;i++) for (let j=0;j<3;j++){
    const ia=i*9+3*j, ib=i*9+3*((j+1)%3);
    const ka=vkey(ia), kb=vkey(ib), ek= ka<kb ? ka+"~"+kb : kb+"~"+ka;
    let r=emap[ek]; if(!r) r=emap[ek]={faces:[]};
    if(r.faces.indexOf(i)<0) r.faces.push(i);
  }
  const key = [ [15,17.5,16], [45,17.5,16] ].map(q=>q.map(v=>Math.round(v*4096)).join("|"));
  const ek = key[0]<key[1] ? key[0]+"~"+key[1] : key[1]+"~"+key[0];
  const rec = emap[ek];
  console.log("faces on long rim edge:", rec.faces.length);
  rec.faces.forEach(f => {
    const v=[]; for(let k=0;k<3;k++) v.push([pos[f*9+3*k],pos[f*9+3*k+1],pos[f*9+3*k+2]].map(n=>+n.toFixed(3)));
    console.log("  tri",f,"n=",[nor[f*9],nor[f*9+1],nor[f*9+2]].map(n=>+n.toFixed(2)), JSON.stringify(v));
  });
  process.exit(0);
}, 400);
