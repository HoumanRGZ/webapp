const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const PKG = "/home/user/work/cad-pkg/rgz-3d-cad-studio";
const vc = new VirtualConsole(); vc.sendTo(console, { omitJSDOMErrors: true });
const dom = new JSDOM("<!DOCTYPE html><html><body></body></html>", { url: "https://houmanrgz.ir/cad/", runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc });
const win = dom.window;
win.HTMLCanvasElement.prototype.getContext = function (k) { return null; };
const t = win.document.createElement("script"); t.textContent = fs.readFileSync(PKG + "/assets/three.min.js", "utf8"); win.document.body.appendChild(t);
const c = win.document.createElement("script"); c.textContent = fs.readFileSync(PKG + "/assets/cad.js", "utf8"); win.document.body.appendChild(c);
const res = win.__rgzcad2.tessLocal({ profiles: [[[0, 0], [60, 0], [60, 45], [0, 45]]], holes: [[15, 22.5, 5, 0, 20, 16, 4, 90], [45, 22.5, 5, 2, 20, 16, 4, 90]], cuts: [[[20, 20], [40, 20], [40, 30], [20, 30]]], cutDepth: 5, L: 20, bevel: { mode: 0, size: 0 } });
const pos = res.positions, nor = res.normals;
/* find all edges with one endpoint near the pocket rim Y=20 or 30 plane z≈20 (top rim) in WORLD z */
let n20 = 0;
for (let i = 0; i < pos.length; i += 3) {
  if (Math.abs(pos[i + 2] - 20) < 0.3 && (Math.abs(pos[i + 1] - 20) < 0.3 || Math.abs(pos[i + 1] - 30) < 0.3) && pos[i] > 19 && pos[i] < 41) { n20++; }
}
console.log("verts near top pocket rim long edges:", n20);
/* count tris on top slab */
console.log("tris total", pos.length / 9);
/* sample z range histogram of verts inside pocket rect */
let zIn = {};
for (let i = 0; i < pos.length; i += 3) {
  if (pos[i] > 20.2 && pos[i] < 39.8 && pos[i + 1] > 20.2 && pos[i + 1] < 29.8) {
    const z = Math.round(pos[i + 2]); zIn[z] = (zIn[z] || 0) + 1;
  }
}
console.log("z histogram inside pocket window:", JSON.stringify(zIn));
