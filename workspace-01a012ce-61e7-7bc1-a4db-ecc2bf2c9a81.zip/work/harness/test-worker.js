const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const code = fs.readFileSync(process.argv[2], "utf8");

async function test(rootId, label){
  const blobs = [];
  const dom = new JSDOM(`<!DOCTYPE html><body><div id="${rootId}"></div><script>${code}<\/script>`, {
    runScripts: "dangerously", pretendToBeVisual: true, url: "https://example.com/",
    virtualConsole: new VirtualConsole(),
    beforeParse(window) {
      window.matchMedia = () => ({ matches:false, addEventListener(){} });
      const OB = window.Blob;
      window.Blob = class extends OB {
        constructor(parts, opts){ super(parts, opts);
          const t = parts && parts.map(p=>typeof p==="string"?p:"").join("");
          if (/self\.onmessage/.test(t)) window.__blobTexts = window.__blobTexts||[], window.__blobTexts.push(t);
        }
      };
      window.URL.createObjectURL = () => "blob:fake";
      window.Worker = class {
        constructor(url){ this.url=url; window.__workerCreated=(window.__workerCreated||0)+1; blobs.push(window.__blobTexts[window.__blobTexts.length-1]); }
        postMessage(msg){ window.__lastWorkerMsg=msg; }
        set onmessage(f){} set onerror(f){} terminate(){}
      };
      window.confirm = () => true; window.alert = () => {};
      window.requestAnimationFrame = (cb)=>setTimeout(()=>cb(0),5);
      window.SVGElement.prototype.getBBox = () => ({x:0,y:0,width:40,height:12});
      window.console.warn = ()=>{};
    },
  });
  const { window } = dom;
  await new Promise(r=>setTimeout(r,900));
  // open first example via modal
  const doc = window.document;
  const btn = [...doc.querySelectorAll('[data-action="browse-examples"]')][0]; btn.click();
  await new Promise(r=>setTimeout(r,150));
  const lvl = doc.getElementById("rgz-level-selectbox"); lvl.value = lvl.options[0].value;
  lvl.dispatchEvent(new window.Event("change",{bubbles:true}));
  await new Promise(r=>setTimeout(r,250));
  const ex = doc.getElementById("rgz-example-selectbox"); ex.value = "0";
  ex.dispatchEvent(new window.Event("change",{bubbles:true}));
  await new Promise(r=>setTimeout(r,150));
  const ob = doc.querySelector("[data-modal-open-example]"); if(!ob){console.log("NO OPEN BUTTON");process.exit(1);} ob.dispatchEvent(new window.MouseEvent("click",{bubbles:true}));
  await new Promise(r=>setTimeout(r,600));
  // press Simulate
  [...doc.querySelectorAll('[data-action="simulate"]')].forEach(b=>b.click());
  await new Promise(r=>setTimeout(r,300));
  const btxt = window.__blobTexts && window.__blobTexts[0];
  if (!btxt) { console.log(label+": no worker blob created (sim start failed?)"); process.exit(1); }
  const self = { onmessage:null, postMessage(m){ self.__msg=m; } };
  try { new Function("self", btxt)(self); } catch(e){ console.log(label+": WORKER SCRIPT SYNTAX/LOAD FAILURE:", e.message); process.exit(1); }
  const model = window.__lastWorkerMsg || {components:[], connections:[], dt:0, time:0};
  try {
    self.onmessage({data:model});
    console.log(label+": worker OK — solver returned:", JSON.stringify(Object.keys(self.__msg||{})) , "| model comps:", model.components?.length ?? model);
  } catch(e){ console.log(label+": WORKER RUNTIME FAILURE:", e.message); process.exit(1); }
  // keep window alive to avoid rAF teardown noise
}
(async()=>{ await test("rgz-hydraulic-studio","HYD"); await test("rgz-pneumatic-studio","PNE"); })();
