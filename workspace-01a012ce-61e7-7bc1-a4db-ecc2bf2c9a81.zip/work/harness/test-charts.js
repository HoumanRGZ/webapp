// UI E2E: user-defined charts — channel catalogue, recorder, render, SVG/CSV export (both studios)
const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const code = fs.readFileSync(process.argv[2], "utf8");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const blobText = (window, blob) => new Promise((res, rej) => { const fr = new window.FileReader(); fr.onload = () => res(fr.result); fr.onerror = rej; fr.readAsText(blob); });
let pass = 0, fail = 0;
const ok = (c, n, d) => { if (c) { pass++; console.log("  PASS", n, d ?? ""); } else { fail++; console.log("  FAIL", n, "=>", d); } };

function boot(mountId) {
  return new JSDOM(`<!DOCTYPE html><body><div id="${mountId}"></div><script>${code}<\/script>`, {
    runScripts: "dangerously", pretendToBeVisual: true, url: "https://example.com/", virtualConsole: new VirtualConsole(),
    beforeParse(window) {
      window.matchMedia = () => ({ matches: false, addEventListener() {} });
      window.confirm = () => true; window.alert = () => {};
      window.requestAnimationFrame = (cb) => setTimeout(() => cb(performance.now()), 4);
      window.SVGElement.prototype.getBBox = () => ({ x: 0, y: 0, width: 40, height: 12 });
      window.SVGSVGElement.prototype.createSVGPoint = function () { const pt = { x: 0, y: 0 }; pt.matrixTransform = () => pt; return pt; };
      window.SVGSVGElement.prototype.getScreenCTM = window.SVGSVGElement.prototype.getCTM = () => ({ a: 1, b: 0, c: 0, d: 1, e: 0, f: 0, inverse() { return this; }, multiply() { return this; } });
      window.URL.createObjectURL = (blob) => { window.__lastBlob = blob; return "blob:mock-" + (window.__blobN = (window.__blobN || 0) + 1); };
      window.URL.revokeObjectURL = () => {};
      window.__downloads = [];
      window.HTMLAnchorElement.prototype.click = function () {
        if (this.download) window.__downloads.push({ name: this.download, href: this.href });
      };
      window.console.warn = () => {};
    },
  });
}

async function loadFirstExample(doc, window) {
  doc.querySelector('[data-action="browse-examples"]').click(); await sleep(150);
  const lvl = doc.getElementById("rgz-level-selectbox");
  lvl.value = lvl.options[0].value; lvl.dispatchEvent(new window.Event("change", { bubbles: true })); await sleep(200);
  const ex = doc.getElementById("rgz-example-selectbox");
  ex.value = ex.options[1] ? ex.options[1].value : ex.options[0].value;
  ex.dispatchEvent(new window.Event("change", { bubbles: true })); await sleep(100);
  doc.querySelector("[data-modal-open-example]").dispatchEvent(new window.MouseEvent("click", { bubbles: true }));
  await sleep(400);
}

(async () => {
  console.log("== CHARTS: hydraulic studio ==");
  const dom = boot("rgz-hydraulic-studio");
  const { window } = dom; const doc = window.document;
  await sleep(900);
  await loadFirstExample(doc, window);
  const nCyl = doc.querySelectorAll("g.rgz-component").length;
  ok(nCyl >= 3, "example circuit loaded", nCyl + " components");

  [...doc.querySelectorAll('[data-action="simulate"]')].forEach((b) => b.click());
  await sleep(2500);

  // charts button on toolbar
  const chBtn = doc.querySelector('[data-action="open-charts"]');
  ok(!!chBtn, "Charts button present in toolbar");
  chBtn.click(); await sleep(250);
  const modal = doc.querySelector(".rgz-chart-modal");
  ok(!!modal, "chart modal opens");
  const count0 = parseInt(modal.querySelector("[data-rgzch-count]").textContent, 10);
  ok(count0 > 20, "recorder captured samples while simulating (one per sim frame)", count0 + " rows");

  const yBoxes = [...modal.querySelectorAll("[data-rgzch-y]")];
  ok(yBoxes.length >= 8, "channel catalogue offers many series", yBoxes.length + " channels");
  const yIds = yBoxes.map((b) => b.getAttribute("data-rgzch-y"));
  ok(yIds.includes("sys.p"), "system pressure channel exists");
  ok(yIds.some((id) => /:pos$/.test(id)), "a cylinder position channel exists");
  ok(yIds.some((id) => /:p$/.test(id) && !/^sys\./.test(id)), "a component pressure channel exists");
  ok(yIds.includes("sys.temp"), "oil temperature channel offered in hydraulic studio");
  ok(yIds.some((id) => /:load$/.test(id)), "applied-load channel exists (variable-load telemetry)");

  // X axis options: Time + every channel
  const xSel = modal.querySelector("[data-rgzch-x]");
  ok(xSel.options.length === yIds.length + 1, "X axis lists Time plus all channels", xSel.options.length + " options");

  // default render (Time X, default checked Y)
  modal.querySelector("[data-rgzch-render]").click(); await sleep(150);
  let svg = modal.querySelector("[data-rgzch-view] svg");
  ok(!!svg, "chart renders an SVG");
  const pls = svg ? [...svg.querySelectorAll("polyline")] : [];
  ok(pls.length >= 1, "at least one series polyline", pls.length + " series");
  const nPts = pls.length ? pls[0].getAttribute("points").trim().split(/\s+/).length : 0;
  ok(nPts > 25, "series has many points", nPts + " pts");
  ok(svg && /Time \(s\)/.test(svg.innerHTML), "X axis labeled Time (s)");

  // user-defined X: cylinder position on X, system pressure on Y  (the user's own example, transposed)
  const posCh = yIds.find((id) => /:pos$/.test(id));
  xSel.value = posCh; xSel.dispatchEvent(new window.Event("change", { bubbles: true }));
  yBoxes.forEach((b) => { b.checked = b.getAttribute("data-rgzch-y") === "sys.p"; });
  // pressure on right axis too? keep left only here; also tick cylinder pressure for a second left series
  const cylP = yIds.find((id) => /:p$/.test(id) && !/^sys\./.test(id));
  if (cylP) yBoxes.find((b) => b.getAttribute("data-rgzch-y") === cylP).checked = true;
  modal.querySelector("[data-rgzch-render]").click(); await sleep(150);
  svg = modal.querySelector("[data-rgzch-view] svg");
  ok(svg && /position \(%\)/.test(svg.innerHTML), "custom X = cylinder position renders", svg ? "ok" : "no svg");
  ok(svg && (svg.querySelectorAll("polyline").length === 2), "two series on left axis", svg ? svg.querySelectorAll("polyline").length : 0);

  // right axis overlay
  const rSel = modal.querySelector("[data-rgzch-r]");
  rSel.value = "sys.kw"; rSel.dispatchEvent(new window.Event("change", { bubbles: true }));
  modal.querySelector("[data-rgzch-render]").click(); await sleep(150);
  svg = modal.querySelector("[data-rgzch-view] svg");
  ok(svg && /Power \(kW\)/.test(svg.innerHTML), "right axis rendered with its own scale (channel label default)");

  // ---- editable captions + live toggle + watermark (user-requested) ----
  ok(!!modal.querySelector('[data-rgzch-lab="title"]'), "chart title input present");
  ok(!!modal.querySelector('[data-rgzch-lab="x"]') && !!modal.querySelector('[data-rgzch-lab="left"]') && !!modal.querySelector('[data-rgzch-lab="right"]'), "axis caption inputs present");
  ok(!!modal.querySelector("[data-rgzch-live]"), "live preview toggle present");
  ok(svg && /houmanrgz\.ir · RGZ ENGINEERING/.test(svg.innerHTML), "watermark rendered into the chart");
  const titleInp = modal.querySelector('[data-rgzch-lab="title"]');
  titleInp.value = "Acceptance test — press cycle";
  titleInp.dispatchEvent(new window.Event("input", { bubbles: true })); await sleep(160);
  svg = modal.querySelector("[data-rgzch-view] svg");
  ok(svg && /Acceptance test — press cycle/.test(svg.innerHTML), "custom chart title renders after edit");
  ok((window.localStorage.getItem("rgz.chart.labels.hydraulic") || "").includes("Acceptance test"), "captions persist to localStorage");
  const leftInp = modal.querySelector('[data-rgzch-lab="left"]');
  leftInp.value = "Force [kN]";
  leftInp.dispatchEvent(new window.Event("input", { bubbles: true })); await sleep(160);
  svg = modal.querySelector("[data-rgzch-view] svg");
  ok(svg && /Force \[kN\]/.test(svg.innerHTML), "custom axis caption renders after edit");
  leftInp.value = ""; leftInp.dispatchEvent(new window.Event("input", { bubbles: true })); await sleep(160);

  // CSV export
  modal.querySelector("[data-rgzch-csv]").click(); await sleep(250);
  const csvDl = window.__downloads.find((d) => /\.csv$/.test(d.name));
  ok(!!csvDl && csvDl.name === "rgz-hydraulic-chart.csv", "CSV download fired", csvDl && csvDl.name);
  const csvText = await blobText(window, window.__lastBlob);
  ok(/position \[%\]/.test(csvText.split("\n")[0]), "CSV header carries labels+units", csvText.split("\n")[0]);
  ok(csvText.trim().split("\n").length > 40, "CSV holds the recorded rows", (csvText.trim().split("\n").length - 1) + " data rows");

  // SVG export
  const nDl = window.__downloads.length;
  modal.querySelector("[data-rgzch-svg]").click(); await sleep(250);
  const svgDl = window.__downloads.slice(nDl).find((d) => /\.svg$/.test(d.name));
  ok(!!svgDl && svgDl.name === "rgz-hydraulic-chart.svg", "SVG download fired", svgDl && svgDl.name);
  const svgText = await blobText(window, window.__lastBlob);
  ok(/^<\?xml version="1\.0"/.test(svgText) && svgText.includes("<svg"), "exported file is a standalone SVG");
  ok(/houmanrgz\.ir · RGZ ENGINEERING/.test(svgText), "watermark is baked into the SVG export");
  ok(/captured at t=/.test(svgText), "export footer stamps the capture instant");
  ok(/Acceptance test — press cycle/.test(svgText), "export carries the edited title");

  // clear data
  [...doc.querySelectorAll('[data-action="stop"]')].forEach((b) => { if (!b.disabled) b.click(); });
  await sleep(200);
  modal.querySelector("[data-rgzch-clear]").click(); await sleep(150);
  const count1 = parseInt(modal.querySelector("[data-rgzch-count]").textContent, 10);
  ok(count1 === 0, "Clear data empties the record (sim stopped first to avoid refill races)", count1 + " rows");

  // restart sim -> recorder refills (live)
  [...doc.querySelectorAll('[data-action="simulate"]')].forEach((b) => { if (!b.disabled) b.click(); });
  await sleep(900);
  const count2 = parseInt(modal.querySelector("[data-rgzch-count]").textContent, 10);
  ok(count2 > 5, "recorder keeps capturing after clear", count2 + " rows");

  [...doc.querySelectorAll('[data-action="stop"]')].forEach((b) => { if (!b.disabled) b.click(); });
  dom.window.close();

  console.log("\n== CHARTS: pneumatic studio ==");
  const dom2 = boot("rgz-pneumatic-studio");
  const doc2 = dom2.window.document;
  await sleep(900);
  await loadFirstExample(doc2, dom2.window);
  [...doc2.querySelectorAll('[data-action="simulate"]')].forEach((b) => b.click());
  await sleep(1800);
  const chBtn2 = doc2.querySelector('[data-action="open-charts"]');
  ok(!!chBtn2, "Charts button present in pneumatic toolbar");
  chBtn2.click(); await sleep(250);
  const modal2 = doc2.querySelector(".rgz-chart-modal");
  ok(!!modal2, "pneumatic chart modal opens");
  const yIds2 = [...modal2.querySelectorAll("[data-rgzch-y]")].map((b) => b.getAttribute("data-rgzch-y"));
  ok(yIds2.length >= 6 && yIds2.includes("sys.p"), "pneumatic channel catalogue built", yIds2.length + " channels");
  ok(!yIds2.includes("sys.temp"), "oil temperature channel hidden in pneumatic studio");
  modal2.querySelector("[data-rgzch-render]").click(); await sleep(150);
  const svg2 = modal2.querySelector("[data-rgzch-view] svg");
  ok(!!svg2 && svg2.querySelector("polyline"), "pneumatic chart renders");
  modal2.querySelector("[data-rgzch-csv]").click(); await sleep(250);
  const csvDl2 = dom2.window.__downloads.find((d) => /\.csv$/.test(d.name));
  ok(!!csvDl2 && csvDl2.name === "rgz-pneumatic-chart.csv", "pneumatic CSV download fired", csvDl2 && csvDl2.name);
  dom2.window.close();

  console.log("\n" + (fail ? "SOME FAILED" : "ALL CHART TESTS PASSED") + ` (${pass} passed, ${fail} failed)`);
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error("HARNESS ERROR", e); process.exit(1); });
