const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const PKG = "/home/user/work/cad-pkg/rgz-3d-cad-studio";
const vc = new VirtualConsole(); vc.sendTo(console, { omitJSDOMErrors: true });
const dom = new JSDOM("<!DOCTYPE html><html><body></body></html>", { url: "https://houmanrgz.ir/cad/", runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc });
const win = dom.window;
win.HTMLCanvasElement.prototype.getContext = function (k) { return null; };
const t = win.document.createElement("script"); t.textContent = fs.readFileSync(PKG + "/assets/three.min.js", "utf8"); win.document.body.appendChild(t);
const T = win.THREE;
function build(circles, holesExtra, depth) {
  const sh = new T.Shape();
  [[0,0],[60,0],[60,45],[0,45]].forEach((p,i)=> i?sh.lineTo(p[0],p[1]):sh.moveTo(p[0],p[1]));
  sh.closePath();
  circles.forEach(h => { const hp = new T.Path(); hp.absarc(h[0],h[1],h[2],0,Math.PI*2,true); sh.holes.push(hp); });
  (holesExtra||[]).forEach(poly => { const hp=new T.Path(); poly.forEach((p,i)=> i?hp.lineTo(p[0],p[1]):hp.moveTo(p[0],p[1])); hp.closePath(); sh.holes.push(hp); });
  const g = new T.ExtrudeGeometry([sh], { depth: depth, bevelEnabled: false, curveSegments: 24 });
  const pos = g.getAttribute("position"), nrm = g.getAttribute("normal");
  let bad = 0, first = -1;
  for (let i=0;i<nrm.count;i++){
    const l=Math.hypot(nrm.getX(i),nrm.getY(i),nrm.getZ(i));
    if (Math.abs(l-1)>0.01){ bad++; if(first<0) first=i; }
  }
  console.log("tris:", pos.count/3, "verts:", pos.count, "norms:", nrm.count, "| bad normals:", bad, first>=0?("first@"+first):"");
  if (first>=0){ const i=first-(first%3); console.log(" first bad vert n:",[nrm.getX(first),nrm.getY(first),nrm.getZ(first)].map(v=>+v.toFixed(3)),
    "tri pos:", [0,1,2].map(k=>[pos.getX(i+k),pos.getY(i+k),pos.getZ(i+k)].map(v=>+v.toFixed(2)))); }
}
console.log("A: rect hole only:"); build([], [[[15,17.5],[45,17.5],[45,27.5],[15,27.5]]], 10);
console.log("B: two circles only:"); build([[15,22.5,5],[45,22.5,5]], [], 10);
console.log("C: circles + rect:"); build([[15,22.5,5],[45,22.5,5]], [[[15,17.5],[45,17.5],[45,27.5],[15,27.5]]], 10);
