const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const PKG = "/home/user/work/cad-pkg/rgz-3d-cad-studio";
const vc = new VirtualConsole(); vc.sendTo(console, { omitJSDOMErrors: true });
const dom = new JSDOM("<!DOCTYPE html><html><body></body></html>", { url: "https://houmanrgz.ir/cad/", runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc });
const win = dom.window;
win.HTMLCanvasElement.prototype.getContext = function (k) { return null; };
const t = win.document.createElement("script"); t.textContent = fs.readFileSync(PKG + "/assets/three.min.js", "utf8"); win.document.body.appendChild(t);
const c = win.document.createElement("script"); c.textContent = fs.readFileSync(PKG + "/assets/cad.js", "utf8"); win.document.body.appendChild(c);
const X = win.__rgzcad2;
function probe(label, payload){
  const soup = X.tessLocal(payload);
  if(!soup || soup.error){ console.log(label, "ERROR", soup && soup.error); return; }
  const pos = soup.positions;
  let rim=0;
  for (let i=0;i<pos.length;i+=3){
    const x=pos[i],y=pos[i+1],z=pos[i+2];
    if (Math.abs(z-20)<0.01 && Math.abs(y-20)<0.01 && x>=19.99 && x<=40.01) rim++;
  }
  console.log(label, "tris:", pos.length/9, "vol:", soup.vol && soup.vol.toFixed ? soup.vol.toFixed(1) : soup.vol, "| rim verts (y=20,z=20,x 20..40):", rim);
}
probe("no holes:   ", { profiles: [[[0,0],[60,0],[60,45],[0,45]]], holes: [], cuts: [[[20,20],[40,20],[40,30],[20,30]]], cutDepth: 5, L: 20, bevel: {mode:0,size:0} });
probe("with holes: ", { profiles: [[[0,0],[60,0],[60,45],[0,45]]], holes: [[15,22.5,5,0,20,16,4,90],[45,22.5,5,2,20,16,4,90]], cuts: [[[20,20],[40,20],[40,30],[20,30]]], cutDepth: 5, L: 20, bevel: {mode:0,size:0} });
probe("hole far:   ", { profiles: [[[0,0],[60,0],[60,45],[0,45]]], holes: [[15,22.5,5,0,20,16,4,90]], cuts: [[[20,20],[40,20],[40,30],[20,30]]], cutDepth: 5, L: 20, bevel: {mode:0,size:0} });
probe("cbore near: ", { profiles: [[[0,0],[60,0],[60,45],[0,45]]], holes: [[45,22.5,5,2,20,16,4,90]], cuts: [[[20,20],[40,20],[40,30],[20,30]]], cutDepth: 5, L: 20, bevel: {mode:0,size:0} });
