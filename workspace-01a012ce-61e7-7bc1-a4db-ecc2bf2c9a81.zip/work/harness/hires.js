const fs = require("fs");
const { Resvg } = require("@resvg/resvg-js");
const svg = fs.readFileSync("/home/user/work/cad-pkg/qa-sheet.svg", "utf8");
const r = new Resvg(svg, { fitTo: { mode: "width", value: 2400 }, background: "white" });
fs.writeFileSync("/tmp/z-hires.png", r.render().asPng());
console.log("hires done");
