const fs=require("fs");const{JSDOM,VirtualConsole}=require("jsdom");
const code=fs.readFileSync(process.argv[2],"utf8");
(async()=>{
 const dom=new JSDOM(`<!DOCTYPE html><body><div id="rgz-hydraulic-studio"></div><script>${code}<\/script>`,{
  runScripts:"dangerously",pretendToBeVisual:true,url:"https://example.com/",
  virtualConsole:new VirtualConsole(),
  beforeParse(window){
   window.matchMedia=()=>({matches:false,addEventListener(){}});
   window.confirm=()=>true;window.alert=()=>{};
   window.requestAnimationFrame=cb=>setTimeout(()=>cb(0),4);
   window.SVGElement.prototype.getBBox=()=>({x:0,y:0,width:40,height:12});
   window.console.warn=()=>{};
  }});
 const {window}=dom;const doc=window.document;const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 await sleep(900);
 doc.querySelector('[data-action="browse-examples"]').click(); await sleep(150);
 const lvl=doc.getElementById("rgz-level-selectbox");
 console.log("levels:",[...lvl.options].map(o=>o.textContent).join(" | "));
 lvl.value=lvl.options[2].value; lvl.dispatchEvent(new window.Event("change",{bubbles:true})); await sleep(250);
 const ex=doc.getElementById("rgz-example-selectbox");
 console.log("advanced examples:",ex.options.length,[...ex.options].map(o=>o.textContent).join(" | "));
 ex.value=ex.options[6].value; ex.dispatchEvent(new window.Event("change",{bubbles:true})); await sleep(120);
 console.log("preview:",doc.getElementById("rgz-example-preview").textContent);
 doc.querySelector("[data-modal-open-example]").dispatchEvent(new window.MouseEvent("click",{bubbles:true}));
 await sleep(500);
 const ids=[...doc.querySelectorAll("circle.port")].map(c=>c.getAttribute("data-component-id"));
 console.log("comp ids from ports:",[...new Set(ids)].join(","));
 process.exit(0);
})();
