const fs = require("fs"), path = require("path");
const { Resvg } = require("@resvg/resvg-js");
const dir = "/home/user/work/genfigs";
const out = "/home/user/work/render/newfigs"; fs.mkdirSync(out, { recursive: true });
for (const f of fs.readdirSync(dir)) {
  const svg = fs.readFileSync(path.join(dir, f), "utf8");
  fs.writeFileSync(path.join(out, f.replace(".svg", ".png")), new Resvg(svg, { background: "white", fitTo: { mode: "width", value: 520 } }).render().asPng());
}
const files = fs.readdirSync(out).filter((f) => f.endsWith(".png") && !f.startsWith("sheet")).sort();
const per = 6;
for (let k = 0; k < Math.ceil(files.length / per); k++) {
  const chunk = files.slice(k * per, (k + 1) * per);
  const W2 = 1044, H2 = Math.ceil(chunk.length / 3) * 200;
  let cells = "";
  chunk.forEach((f, i) => {
    const data = fs.readFileSync(path.join(out, f)).toString("base64");
    const x = 6 + (i % 3) * 348, y = 6 + Math.floor(i / 3) * 200;
    cells += '<image href="data:image/png;base64,' + data + '" x="' + x + '" y="' + y + '" width="336" height="188" preserveAspectRatio="xMidYMid meet"/>' +
      '<text x="' + x + '" y="' + (y + 197) + '" font-size="11" font-family="monospace">' + f + "</text>";
  });
  const sheet = '<svg xmlns="http://www.w3.org/2000/svg" width="' + W2 + '" height="' + H2 + '" viewBox="0 0 ' + W2 + " " + H2 + '"><rect width="' + W2 + '" height="' + H2 + '" fill="#eee"/>' + cells + "</svg>";
  fs.writeFileSync(path.join(out, "sheet" + (k + 1) + ".png"), new Resvg(sheet).render().asPng());
}
console.log("sheets:", Math.ceil(files.length / per));
