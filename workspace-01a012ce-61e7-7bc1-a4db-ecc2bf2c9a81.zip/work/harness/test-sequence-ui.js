// UI E2E: Sequence valve clamp-and-work — extend order + retract after spool flip
const fs=require("fs");const{JSDOM,VirtualConsole}=require("jsdom");
const code=fs.readFileSync(process.argv[2],"utf8");
(async()=>{
 const dom=new JSDOM(`<!DOCTYPE html><body><div id="rgz-hydraulic-studio"></div><script>${code}<\/script>`,{
  runScripts:"dangerously",pretendToBeVisual:true,url:"https://example.com/",virtualConsole:new VirtualConsole(),
  beforeParse(window){
   window.matchMedia=()=>({matches:false,addEventListener(){}});
   window.confirm=()=>true;window.alert=()=>{};
   window.requestAnimationFrame=cb=>setTimeout(()=>cb(0),4);
   window.SVGElement.prototype.getBBox=()=>({x:0,y:0,width:40,height:12});
   window.SVGSVGElement.prototype.createSVGPoint=function(){const pt={x:0,y:0};pt.matrixTransform=()=>pt;return pt;};
   window.SVGSVGElement.prototype.getScreenCTM=window.SVGSVGElement.prototype.getCTM=()=>({a:1,b:0,c:0,d:1,e:0,f:0,inverse(){return this;},multiply(){return this;}});
   window.console.warn=()=>{};
  }});
 const{window}=dom;const doc=window.document;const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 let pass=0,fail=0;const ok=(c,n,d)=>{if(c){pass++;console.log("  PASS",n,d??"")}else{fail++;console.log("  FAIL",n,"=>",d)}};
 await sleep(900);
 doc.querySelector('[data-action="browse-examples"]').click();await sleep(150);
 const lvl=doc.getElementById("rgz-level-selectbox");
 lvl.value=lvl.options[0].value;lvl.dispatchEvent(new window.Event("change",{bubbles:true}));await sleep(200);
 const ex=doc.getElementById("rgz-example-selectbox");
 const idx=[...ex.options].findIndex(o=>/Sequence valve clamp-and-work/i.test(o.textContent));
 ok(idx>=0,"example found in Simple list",idx>=0?"idx="+idx:"not found");
 ex.value=ex.options[idx].value;ex.dispatchEvent(new window.Event("change",{bubbles:true}));await sleep(100);
 doc.querySelector("[data-modal-open-example]").dispatchEvent(new window.MouseEvent("click",{bubbles:true}));
 await sleep(400);
 const comps=[...doc.querySelectorAll("g.rgz-component")].map(g=>g.getAttribute("data-id"));
 ok(comps.some(c=>/^CV-/.test(c)),"bypass check valve CV1 present on canvas",comps.join(","));
 [...doc.querySelectorAll('[data-action="simulate"]')].forEach(b=>b.click());
 const read=()=>{
   const rows=[...doc.querySelectorAll("#rgz-inspector-panel .rgz-kv-row")].map(r=>[...r.querySelectorAll("span")].map(s=>s.textContent).join("=")).join(" | ");
   return rows;
 };
 const simTab=async()=>{const b=doc.querySelector('button.rgz-tab[data-tab="simulation"]');if(b)b.click();await sleep(120);};
 await sleep(1500);
 await simTab();
 let sawClampFast=false,sawWorkFast=false,sawClampStill=false;
 for(let i=0;i<5;i++){await sleep(1000);await simTab();
   const r=read();
   if(/Clamp=2\d\d\.\d mm\/s/.test(r))sawClampFast=true;
   if(/Work=(5\d|6\d|7\d|8\d|9\d)\.\d mm\/s/.test(r))sawWorkFast=true;
   if(/Work=-[3-9]\d\.\d mm\/s|Work=-1\d\d\.\d mm\/s/.test(r))sawClampStill=true;
   if(i===0||i===4)console.log("  EXT sample:",r);
 }
 ok(sawClampFast,"extend: clamp runs at ~212 mm/s",sawClampFast);
 // flip spool to right via properties tab
 const t=[...doc.querySelectorAll("text.component-label")].find(t=>t.textContent.trim()==="V1");
 const g=t.closest("g.rgz-component");
 const target=[...g.children].find(c=>!(c.classList&&c.classList.contains("port")))||g;
 target.dispatchEvent(new (window.PointerEvent||window.MouseEvent)("pointerdown",{bubbles:true,cancelable:true}));
 await sleep(300);
 const propTab=doc.querySelector('button.rgz-tab[data-tab="properties"]'); if(propTab) propTab.click();
 await sleep(150);
 const sel=doc.querySelector('[data-prop-field="spoolState"]');
 ok(!!sel,"spoolState editor found",sel?("value="+sel.value):"missing");
 if(sel){sel.value=[...sel.options].find(o=>/right/i.test(o.textContent)||o.value==="right")?.value??"right";sel.dispatchEvent(new window.Event("input",{bubbles:true}));sel.dispatchEvent(new window.Event("change",{bubbles:true}));}
 let sawRetract=false;
 for(let i=0;i<7;i++){await sleep(1000);await simTab();
   const r=read();
   if(/Work=-\d{2,3}\.\d mm\/s/.test(r))sawRetract=true;
   if(i===0||i===3||i===6)console.log("  RET sample:",r);
 }
 ok(sawRetract,"retract: work cylinder comes back fast (|v| >= 10 mm/s, no trapping)",sawRetract);
 console.log("\n"+(fail?"SOME FAILED":"ALL SEQUENCE UI TESTS PASSED"));
 process.exit(fail?1:0);
})();
