// Dump live badge texts + sim status for several examples (main-thread solver).
const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const code = fs.readFileSync(process.argv[2], "utf8");

(async () => {
  const dom = new JSDOM(
    `<!DOCTYPE html><body><div id="rgz-hydraulic-studio"></div><script>${code}<\/script>`,
    {
      runScripts: "dangerously", pretendToBeVisual: true, url: "https://example.com/",
      virtualConsole: new VirtualConsole(),
      beforeParse(window) {
        window.matchMedia = () => ({ matches: false, addEventListener() {} });
        window.confirm = () => true; window.alert = () => {};
        window.requestAnimationFrame = (cb) => setTimeout(() => cb(performance.now()), 4);
        window.SVGElement.prototype.getBBox = () => ({ x: 0, y: 0, width: 40, height: 12 });
        window.console.warn = () => {};
      },
    });
  const { window } = dom; const doc = window.document;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  await sleep(900);

  for (const [lvlIdx, exIdx] of [[2, 6], [1, 0], [1, 5], [2, 1], [0, 0]]) {
    // (re)open modal
    if (!doc.querySelector(".rgz-modal-backdrop")) {
      doc.querySelector('[data-action="browse-examples"]').click();
      await sleep(150);
    }
    const lvl = doc.getElementById("rgz-level-selectbox");
    lvl.value = lvl.options[lvlIdx].value;
    lvl.dispatchEvent(new window.Event("change", { bubbles: true }));
    await sleep(200);
    const ex = doc.getElementById("rgz-example-selectbox");
    ex.value = ex.options[exIdx].value;
    ex.dispatchEvent(new window.Event("change", { bubbles: true }));
    await sleep(100);
    const prev = doc.getElementById("rgz-example-preview").textContent;
    doc.querySelector("[data-modal-open-example]").dispatchEvent(new window.MouseEvent("click", { bubbles: true }));
    await sleep(400);
    [...doc.querySelectorAll('[data-action="simulate"]')].forEach((b) => { if (!b.disabled) b.click(); });
    await sleep(2500);
    const badges = [...doc.querySelectorAll(".rgz-readout-badge")].map((g) => {
      const host = g.parentElement;
      const circ = host && host.querySelector("circle.port");
      const t = g.querySelector(".rgz-readout-text");
      return (circ ? circ.getAttribute("data-component-id") : "?") + "=" + (t ? t.textContent : "");
    });
    const act = doc.querySelectorAll(".rgz-connection-path.sim-active").length;
    console.log(`\n=== lvl${lvlIdx} ex${exIdx}: ${prev}`);
    console.log("   badges:", badges.join("  ") || "(none)");
    console.log("   sim-active lines:", act, " status:", doc.getElementById("rgz-sim-status").textContent);
    [...doc.querySelectorAll('[data-action="stop"]')].forEach((b) => { if (!b.disabled) b.click(); });
    await sleep(300);
  }
  process.exit(0);
})();
