const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const PKG = "/home/user/work/cad-pkg/rgz-3d-cad-studio";
const vc = new VirtualConsole(); vc.sendTo(console, { omitJSDOMErrors: true });
const dom = new JSDOM("<!DOCTYPE html><html><body></body></html>", { url: "https://houmanrgz.ir/cad/", runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc });
const win = dom.window;
win.HTMLCanvasElement.prototype.getContext = function (k) { return null; };
const t = win.document.createElement("script"); t.textContent = fs.readFileSync(PKG + "/assets/three.min.js", "utf8"); win.document.body.appendChild(t);
let src = fs.readFileSync(PKG + "/assets/cad.js", "utf8");
// neutralize filterCaps calls (probe-only): replace the call expressions
src = src.split("filterCaps(P, N, m1, null);").join(";/*nofilter*/");
src = src.split("filterCaps(P, N, m2, cuts);").join(";/*nofilter*/");
src = src.split("filterCaps(P, N, m3, null);").join(";/*nofilter*/");
const c = win.document.createElement("script"); c.textContent = src; win.document.body.appendChild(c);
const X = win.__rgzcad2;
const s = X.tessLocal({ profiles: [[[0,0],[60,0],[60,45],[0,45]]], holes: [], cuts: [[[15,17.5],[45,17.5],[45,27.5],[15,27.5]]], cutDepth: 6, L: 16, bevel: {mode:0,size:0} });
const P = s.positions, N = s.normals;
let bad = 0;
for (let i = 0; i < P.length/9; i++){ const l = Math.hypot(N[i*9], N[i*9+1], N[i*9+2]); if (Math.abs(l-1) > 0.01) bad++; }
console.log("filterless tris:", P.length/9, "bad:", bad);
