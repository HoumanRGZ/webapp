const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const PKG = "/home/user/work/cad-pkg/rgz-3d-cad-studio";
const vc = new VirtualConsole(); vc.sendTo(console, { omitJSDOMErrors: true });
const dom = new JSDOM("<!DOCTYPE html><html><body></body></html>", { url: "https://houmanrgz.ir/cad/", runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc });
const win = dom.window;
win.HTMLCanvasElement.prototype.getContext = function (k) { return null; };
const t = win.document.createElement("script"); t.textContent = fs.readFileSync(PKG + "/assets/three.min.js", "utf8"); win.document.body.appendChild(t);
const T = win.THREE;
const sh = new T.Shape();
[[0,0],[60,0],[60,45],[0,45]].forEach((p,i)=> i?sh.lineTo(p[0],p[1]):sh.moveTo(p[0],p[1]));
sh.closePath();
const hp = new T.Path(); [[15,17.5],[45,17.5],[45,27.5],[15,27.5]].forEach((p,i)=> i?hp.lineTo(p[0],p[1]):hp.moveTo(p[0],p[1])); hp.closePath();
sh.holes.push(hp);
const g = new T.ExtrudeGeometry([sh], { depth: 6, bevelEnabled: false, curveSegments: 24 });
const pos = g.getAttribute("position"), nrm = g.getAttribute("normal");
console.log("position count:", pos && pos.count, "| normal count:", nrm && nrm.count, "| indexed:", !!g.getIndex());
if (nrm) {
  let zero=0, bad=0, slopeFlat=0;
  for (let i=0;i<nrm.count;i+=3){
    const nx=nrm.getX(i),ny=nrm.getY(i),nz=nrm.getZ(i);
    const l=Math.hypot(nx,ny,nz);
    if (l<0.5) zero++; else if (Math.abs(l-1)>0.01) bad++;
    const z1=pos.getZ(i),z2=pos.getZ(i+1),z3=pos.getZ(i+2);
    if (Math.abs(nz)<0.99 && Math.abs(z1-z2)<0.001 && Math.abs(z2-z3)<0.001) slopeFlat++;
  }
  console.log("tri normals: zero:", zero, "| non-unit:", bad, "| flat tri slope normal:", slopeFlat);
  // first 6 tris raw
  for (let i=0;i<18;i+=9){ console.log("tri",i/9,"p:",[pos.getX(i),pos.getY(i),pos.getZ(i)].map(v=>+v.toFixed(2)), "n:",[nrm.getX(i),nrm.getY(i),nrm.getZ(i)].map(v=>+v.toFixed(2))); }
}
