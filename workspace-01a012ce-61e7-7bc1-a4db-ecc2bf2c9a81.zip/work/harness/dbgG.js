const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const PKG = "/home/user/work/cad-pkg/rgz-3d-cad-studio";
const vc = new VirtualConsole(); vc.sendTo(console, { omitJSDOMErrors: true });
const dom = new JSDOM("<!DOCTYPE html><html><body></body></html>", { url: "https://houmanrgz.ir/cad/", runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc });
const win = dom.window;
win.HTMLCanvasElement.prototype.getContext = function (k) { return null; };
const t = win.document.createElement("script"); t.textContent = fs.readFileSync(PKG + "/assets/three.min.js", "utf8"); win.document.body.appendChild(t);
const c = win.document.createElement("script"); c.textContent = fs.readFileSync(PKG + "/assets/cad.js", "utf8"); win.document.body.appendChild(c);
const X = win.__rgzcad2;
function probe(label, payload){
  const s = X.tessLocal(payload);
  if (s.error) { console.log(label, "ERR", s.error); return; }
  const P = s.positions, N = s.normals;
  let bad = 0, first = -1;
  for (let i = 0; i < P.length/9; i++){
    const l = Math.hypot(N[i*9], N[i*9+1], N[i*9+2]);
    if (Math.abs(l-1) > 0.01){ bad++; if (first<0) first = i; }
  }
  console.log(label, "tris:", P.length/9, "bad normals:", bad, first>=0 ? "first@"+first : "");
}
probe("A holes only   ", { profiles: [[[0,0],[60,0],[60,45],[0,45]]], holes: [[15,22.5,5,2,0,16,4,90],[45,22.5,5,0,0,12,2,90]], cuts: [], cutDepth: 0, L: 16, bevel: {mode:0,size:0} });
probe("B cuts only    ", { profiles: [[[0,0],[60,0],[60,45],[0,45]]], holes: [], cuts: [[[15,17.5],[45,17.5],[45,27.5],[15,27.5]]], cutDepth: 6, L: 16, bevel: {mode:0,size:0} });
probe("C both         ", { profiles: [[[0,0],[60,0],[60,45],[0,45]]], holes: [[15,22.5,5,2,0,16,4,90],[45,22.5,5,0,0,12,2,90]], cuts: [[[15,17.5],[45,17.5],[45,27.5],[15,27.5]]], cutDepth: 6, L: 16, bevel: {mode:0,size:0} });
probe("D through only ", { profiles: [[[0,0],[60,0],[60,45],[0,45]]], holes: [[45,22.5,5,0,0,12,2,90]], cuts: [], cutDepth: 0, L: 16, bevel: {mode:0,size:0} });
probe("E cbore only   ", { profiles: [[[0,0],[60,0],[60,45],[0,45]]], holes: [[15,22.5,5,2,0,16,4,90]], cuts: [], cutDepth: 0, L: 16, bevel: {mode:0,size:0} });
