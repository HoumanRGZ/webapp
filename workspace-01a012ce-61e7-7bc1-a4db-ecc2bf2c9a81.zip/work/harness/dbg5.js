const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const PKG = "/home/user/work/cad-pkg/rgz-3d-cad-studio";
const vc = new VirtualConsole(); vc.sendTo(console, { omitJSDOMErrors: true });
const dom = new JSDOM("<!DOCTYPE html><html><body></body></html>", { url: "https://houmanrgz.ir/cad/", runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc });
const win = dom.window;
win.HTMLCanvasElement.prototype.getContext = function (k) { return null; };
const t = win.document.createElement("script"); t.textContent = fs.readFileSync(PKG + "/assets/three.min.js", "utf8"); win.document.body.appendChild(t);
const c = win.document.createElement("script"); c.textContent = fs.readFileSync(PKG + "/assets/cad.js", "utf8"); win.document.body.appendChild(c);
const X = win.__rgzcad2;
const payload = { profiles: [[[0,0],[60,0],[60,45],[0,45]]],
  holes: [[15,22.5,5,0,20,16,4,90],[45,22.5,5,2,20,16,4,90]],
  cuts: [[[20,20],[40,20],[40,30],[20,30]]], cutDepth: 5, L: 20, bevel: { mode: 0, size: 0 } };
const soup = X.tessLocal(payload);
const pos = soup.positions, nor = soup.normals, tris = pos.length / 9;
console.log("tris:", tris);
// 1) cap tris at z=20 whose centroid is INSIDE pocket window (should be none if hole cut)
let bad20 = 0;
for (let i = 0; i < tris; i++) {
  const z1 = pos[i*9+2], z2 = pos[i*9+5], z3 = pos[i*9+8];
  if (Math.abs(z1-20)<0.01 && Math.abs(z2-20)<0.01 && Math.abs(z3-20)<0.01) {
    const cx = (pos[i*9]+pos[i*9+3]+pos[i*9+6])/3, cy = (pos[i*9+1]+pos[i*9+4]+pos[i*9+7])/3;
    if (cx>20.05&&cx<39.95&&cy>20.05&&cy<29.95) bad20++;
  }
}
console.log("z=20 cap tris with centroid inside pocket (should be 0):", bad20);
// 2) verts exactly on rim segments
function onSeg(x,y,z, ax,ay,bx,by,zz){ if(Math.abs(z-zz)>0.01) return false;
  const dx=bx-ax, dy=by-ay, L2=dx*dx+dy*dy;
  const t=((x-ax)*dx+(y-ay)*dy)/L2; if(t<-0.02||t>1.02) return false;
  return Math.hypot(x-(ax+dx*t), y-(ay+dy*t))<0.01; }
const rims = [[20,20,40,20,20],[40,20,40,30,20],[40,30,20,30,20],[20,30,20,20,20],[20,20,40,20,15],[40,20,40,30,15],[40,30,20,30,15],[20,30,20,20,15]];
const cnt = rims.map(()=>0);
for (let i=0;i<pos.length;i+=3) rims.forEach((r,k)=>{ if(onSeg(pos[i],pos[i+1],pos[i+2],r[0],r[1],r[2],r[3],r[4])) cnt[k]++; });
console.log("verts ON rim segments (4@z20, 4@z15):", cnt.join(","));
// 3) what z planes exist inside the pocket window at all
const zs = {};
for (let i=0;i<pos.length;i+=3){ const x=pos[i],y=pos[i+1],z=pos[i+2];
  if(x>20.01&&x<39.99&&y>20.01&&y<29.99){ const k=Math.round(z*100)/100; zs[k]=(zs[k]||0)+1; } }
console.log("z values inside pocket window:", JSON.stringify(zs));
// 4) wall tris: any tri with normal |nz|<0.5 and a vert on a rim line?
let wall = 0;
for (let i=0;i<tris;i++){ const nx=nor[i*9],ny=nor[i*9+1],nz=nor[i*9+2];
  if (Math.abs(nz)<0.5){ for(let j=0;j<3;j++){ const x=pos[i*9+3*j],y=pos[i*9+3*j+1];
    if(x>19.99&&x<40.01&&((Math.abs(y-20)<0.01)||(Math.abs(y-30)<0.01))){ wall++; break; } } } }
console.log("vertical tris touching y=20/30 lines in x 20..40:", wall);
