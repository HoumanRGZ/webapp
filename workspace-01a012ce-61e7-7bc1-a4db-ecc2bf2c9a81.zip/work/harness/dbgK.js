const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const PKG = "/home/user/work/cad-pkg/rgz-3d-cad-studio";
const vc = new VirtualConsole(); vc.sendTo(console, { omitJSDOMErrors: true });
const dom = new JSDOM("<!DOCTYPE html><html><body></body></html>", { url: "https://houmanrgz.ir/cad/", runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc });
const win = dom.window;
win.HTMLCanvasElement.prototype.getContext = function (k) { return null; };
const t = win.document.createElement("script"); t.textContent = fs.readFileSync(PKG + "/assets/three.min.js", "utf8"); win.document.body.appendChild(t);
let src = fs.readFileSync(PKG + "/assets/cad.js", "utf8");
// wrap accum to snapshot pushed normals: log the first 3 tris of every accum call and array growth
const accAnchor = "function accum(geom, P, N, zOff) {";
console.log("acc anchor:", src.includes(accAnchor));
src = src.replace(accAnchor, accAnchor + "\n    globalThis.__acc=(globalThis.__acc||[]); var __pre=P.length;");
// after accum loop, before dispose:
const accEnd = "    geom.dispose();\n    if (g2 !== geom && g2.dispose) { g2.dispose(); }";
src = src.replace(accEnd, "    globalThis.__acc.push({pre:__pre, added:(P.length-__pre)/9, n0:[N[__pre],N[__pre+1],N[__pre+2]], p0:[P[__pre],P[__pre+1],P[__pre+2]], plen:P.length, nlen:N.length});\n" + accEnd);
const c = win.document.createElement("script"); c.textContent = src; win.document.body.appendChild(c);
const X = win.__rgzcad2;
const s = X.tessLocal({ profiles: [[[0,0],[60,0],[60,45],[0,45]]], holes: [], cuts: [[[15,17.5],[45,17.5],[45,27.5],[15,27.5]]], cutDepth: 6, L: 16, bevel: {mode:0,size:0} });
console.log("accum log:", JSON.stringify(win.__acc, null, 1));
const P=s.positions,N=s.normals;
console.log("final N[0..8]:", Array.from(N.slice(0,9)).map(v=>+v.toFixed(2)));
console.log("final P[0..8]:", Array.from(P.slice(0,9)).map(v=>+v.toFixed(2)));
