const fs=require("fs");const{JSDOM,VirtualConsole}=require("jsdom");
const code=fs.readFileSync(process.argv[2],"utf8");
(async()=>{
 const dom=new JSDOM(`<!DOCTYPE html><body><div id="rgz-hydraulic-studio"></div><script>${code}<\/script>`,{
  runScripts:"dangerously",pretendToBeVisual:true,url:"https://example.com/",virtualConsole:new VirtualConsole(),
  beforeParse(window){
   window.matchMedia=()=>({matches:false,addEventListener(){}});
   window.confirm=()=>true;window.alert=()=>{};
   window.requestAnimationFrame=cb=>setTimeout(()=>cb(0),4);
   window.SVGElement.prototype.getBBox=()=>({x:0,y:0,width:40,height:12});
   window.SVGSVGElement.prototype.createSVGPoint=function(){const pt={x:0,y:0};pt.matrixTransform=()=>pt;return pt;};
   window.SVGSVGElement.prototype.getScreenCTM=window.SVGSVGElement.prototype.getCTM=()=>({a:1,b:0,c:0,d:1,e:0,f:0,inverse(){return this;},multiply(){return this;}});
   window.console.warn=()=>{};
  }});
 const{window}=dom;const doc=window.document;const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 await sleep(900);
 doc.querySelector('[data-action="browse-examples"]').click();await sleep(150);
 const lvl=doc.getElementById("rgz-level-selectbox");
 lvl.value=lvl.options[0].value;lvl.dispatchEvent(new window.Event("change",{bubbles:true}));await sleep(200);
 const ex=doc.getElementById("rgz-example-selectbox");
 const idx=[...ex.options].findIndex(o=>/Meter-in/i.test(o.textContent));
 ex.value=ex.options[idx].value;ex.dispatchEvent(new window.Event("change",{bubbles:true}));await sleep(100);
 doc.querySelector("[data-modal-open-example]").dispatchEvent(new window.MouseEvent("click",{bubbles:true}));
 await sleep(400);
 [...doc.querySelectorAll('[data-action="simulate"]')].forEach(b=>b.click());
 await sleep(1500);
 const read=()=>{
   const panel=doc.getElementById("rgz-inspector-panel");
   const t=panel?panel.textContent.match(/Time<\/span><span>([\d.]+)/s):null;
   const rows=[...doc.querySelectorAll("#rgz-inspector-panel .rgz-kv-row")].map(r=>[...r.querySelectorAll("span")].map(s=>s.textContent).join("=")).join(" | ");
   return "time="+(t?t[1]:"?")+"  rows: "+rows;
 };
 const simTab=async()=>{const b=doc.querySelector('button.rgz-tab[data-tab="simulation"]');if(b)b.click();await sleep(120);};
 await simTab();
 console.log("BEFORE EDIT:", read());
 // select FC1 via pointerdown on its icon body
 const t=[...doc.querySelectorAll("text.component-label")].find(t=>t.textContent.trim()==="FC1");
 const g=t.closest("g.rgz-component");
 const target=[...g.children].find(c=>!(c.classList&&c.classList.contains("port")))||g;
 target.dispatchEvent(new (window.PointerEvent||window.MouseEvent)("pointerdown",{bubbles:true,cancelable:true}));
 await sleep(300);
 const propTab=doc.querySelector('button.rgz-tab[data-tab="properties"]'); if(propTab) propTab.click();
 await sleep(150);
 const input=doc.querySelector('[data-prop-field="openingPercent"]');
 console.log("prop input found:", !!input, "value:", input&&input.value);
 input.value="5";
 input.dispatchEvent(new window.Event("input",{bubbles:true}));
 input.dispatchEvent(new window.Event("change",{bubbles:true}));
 for(let i=0;i<3;i++){ await sleep(900); await simTab(); console.log("AFTER EDIT t+"+i+":", read()); }
 // spool state check: dump control console buttons state
 const consoleButtons=[...doc.querySelectorAll("#rgz-inspector-panel button")].map(b=>b.textContent.trim()+(b.className.includes("active")?"(A)":"")).join(", ");
 console.log("console buttons:", consoleButtons);
 process.exit(0);
})();
