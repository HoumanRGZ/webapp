const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const PKG = "/home/user/work/cad-pkg/rgz-3d-cad-studio";
const php = fs.readFileSync(PKG + "/app.php", "utf8");
const start = php.indexOf("?>", php.indexOf("ob_start();"));
const retAt = php.indexOf("return ob_get_clean();");
const end = php.lastIndexOf("<?php", retAt);
let html = php.slice(start + 2, end);
html = html.replace(/<\?php\s*echo\s*esc_url\(home_url\('([^']*)'\)\);?\s*\?>/g, (m, p) => "https://houmanrgz.ir" + p);
html = html.replace(/<\?php[^?]*\?>/g, "RGZ 3D CAD Studio");
const vc = new VirtualConsole(); vc.sendTo(console, { omitJSDOMErrors: true });
const dom = new JSDOM("<!DOCTYPE html><html><head></head><body>" + html + "</body></html>", {
  url: "https://houmanrgz.ir/cad/", runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc });
const win = dom.window, doc = win.document;
function ctx2d(cv) { return new Proxy({}, { get(t, k) {
  if (k === "canvas") return cv;
  if (k === "measureText") return s => ({ width: 7 * String(s).length });
  if (k === "getImageData") return (x, y, w, h) => ({ data: new Uint8ClampedArray(Math.max(4, w * h * 4)) });
  if (k === "createLinearGradient" || k === "createRadialGradient") return () => ({ addColorStop() {} });
  if (k === "isPointInPath") return () => false;
  return () => {}; }, set() { return true; } }); }
win.HTMLCanvasElement.prototype.getContext = function (k) { return k === "2d" ? ctx2d(this) : null; };
win.RGZCAD = { accent: "#eb4e3c", worker: "assets/cad-geometry-worker.js", version: "1.0.0", units: "mm", hubUrl: "x" };
const t = doc.createElement("script"); t.textContent = fs.readFileSync(PKG + "/assets/three.min.js", "utf8"); doc.body.appendChild(t);
const c = doc.createElement("script"); c.textContent = fs.readFileSync(PKG + "/assets/cad.js", "utf8"); doc.body.appendChild(c);
setTimeout(() => {
  const U = win.__rgzcad1;
  const H = win.__rgzcad3;
  U.S.design.name = "Manifold Block";
  const sk = U.startSketchOnDatum("xy");
  sk.entities.push(U.mkEnt("rect", { cx: 30, cy: 22.5, w: 60, h: 45 }));
  U.closeSketchToPad();
  const pad = U.S.design.features[0];
  pad.L = 16; pad.edge = { style: "chamfer", size: 1 };
  sk.entities.push(U.mkEnt("hole", { cx: 15, cy: 22.5, r: 5, hType: "cbore", depth: 0, cbd: 16, cbdDepth: 4, csAngle: 90 }));
  sk.entities.push(U.mkEnt("hole", { cx: 45, cy: 22.5, r: 5, hType: "through", depth: 0, cbd: 12, cbdDepth: 2, csAngle: 90 }));
  U.padSketch(sk.id);
  U.S.design.sketches.push({ id: "skQ", name: "Sketch.pocket", plane: { kind: "faceTop", topOf: pad.id, origin: [0, 0, 16], u: [1, 0, 0], v: [0, 1, 0], n: [0, 0, 1] }, host: pad.id, entities: [U.mkEnt("rect", { cx: 30, cy: 22.5, w: 30, h: 10 })] });
  U.pocketFromSketch("skQ");
  U.S.design.features[1].L = 6;
  const ws = win.__rgzcad2.worldSoup();
  const hv = H.hlrView(ws, H.VIEW_DEFS.front);
  console.log("iso runs:", hv.runs.length);
  // left hole center projected: u=-6.495, v(z)=15.3-0.816z
  const bands = [["z=16", 2.24], ["z=12", 5.51], ["z=10", 7.14], ["z=0", 15.30]];
  for (const [nm, vc0] of bands) {
    let umin = 1e9, umax = -1e9, nv = 0, nh = 0;
    for (const r of hv.runs) {
      const mu = (r.a[0] + r.b[0]) / 2, mv = (r.a[1] + r.b[1]) / 2;
      const len = Math.hypot(r.b[0]-r.a[0], r.b[1]-r.a[1]);
      if (len < 0.25) continue;
      if (Math.abs(mv - vc0) < 1.6 && mu > 4 && mu < 52) {
        umin = Math.min(umin, Math.min(r.a[0], r.b[0]));
        umax = Math.max(umax, Math.max(r.a[0], r.b[0]));
        if (r.vis) nv++; else nh++;
      }
    }
    console.log(nm.padEnd(5), "u-span:", umin === 1e9 ? "-" : umin.toFixed(2) + ".." + umax.toFixed(2), " width:", umin === 1e9 ? "-" : (umax - umin).toFixed(2), " vis runs:", nv, " hid runs:", nh);
  }
  // also: all long runs in left neighborhood, listed
  console.log("-- long runs (len>1.2) with u in [-19,9], any v --");
  const out = [];
  for (const r of hv.runs) {
    const len = Math.hypot(r.b[0]-r.a[0], r.b[1]-r.a[1]);
    if (len < 1.2) continue;
    const mu = (r.a[0]+r.b[0])/2, mv = (r.a[1]+r.b[1])/2;
    if (mu < 4 || mu > 52) continue;
    out.push((r.vis?"VIS":"HID") + " (" + r.a[0].toFixed(2) + "," + r.a[1].toFixed(2) + ")->(" + r.b[0].toFixed(2) + "," + r.b[1].toFixed(2) + ") len=" + len.toFixed(2));
  }
  console.log(out.sort().join("\n"));
}, 300);
