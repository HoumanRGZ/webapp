const S = require("./isolib.js");
const { Resvg } = require("@resvg/resvg-js");
const fs = require("fs");
let s = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 760 430"><rect width="760" height="430" fill="#FBFAF6"/>`;
s += S.g(110,110,1.3,S.dcv({boxes:[
  {arrows:[[20,20,24,80],[80,20,76,80]]},
  {closed:[[20,18],[80,18],[20,82],[80,82]]},
  {arrows:[[20,82,24,18],[80,82,76,18]]},
],solL:"Y1",solR:"Y2",springL:true,springR:true,portTop:[{x:20,label:"A"},{x:80,label:"B"}],portBottom:[{x:20,label:"P"},{x:80,label:"T"}]}));
s += S.g(300,110,1.3,S.reliefValve({}));
s += S.g(430,110,1.3,S.checkValve({piloted:true}));
s += S.g(560,110,1.3,S.shuttleValve({}));
s += S.g(680,110,1.3,S.andValve());
s += S.g(110,250,1.3,S.oneWayFlowControl({}));
s += S.g(250,250,1.3,S.airService({}));
s += S.g(430,250,1.3,S.quickExhaust({}));
s += S.g(560,250,1.3,S.dcv({boxes:[{arrows:[[50,15,50,85]]},{closed:[[50,15],[50,85]]}],solL:"Y1",springR:true,portTop:[{x:50,label:"2"}],portBottom:[{x:50,label:"1"}]}));
s += S.g(680,250,1.3,S.muffler());
s += "</svg>";
fs.writeFileSync("/home/user/work/render/proof2.png", new Resvg(s,{background:"white",fitTo:{mode:"width",value:1000}}).render().asPng());
console.log("ok");
