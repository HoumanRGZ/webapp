/* Regenerate the learning-figure SVGs with true ISO 1219-1 schematics. */
"use strict";
const S = require("./isolib.js");
const { INK, SOFT, ACC, BLUE, PILOT, line, path, rect, circle, txt, arrow, spring, solenoid, solidTri, adjArrow, g, dcv,
  pump, pumpWithMotor, hydMotor, compressor, airMotor, pressureGauge, tank, pneExhaust, cylDA, cylSA, telescopic, rodless,
  reliefValve, reducingValve, checkValve, shuttleValve, andValve, throttle, oneWayFlowControl, filter, coolerSym, accumulator,
  ejector, airService, muffler, quickExhaust, esc, n } = S;

const W = 760, H = 430;
function frame(title, note, o = {}) {
  const bg = o.bg || "#FBFAF6", panel = o.panel || "#E9EEF6";
  return {
    parts: [`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(title)}"><rect width="${W}" height="${H}" rx="16" fill="${bg}"/><rect x="8" y="8" width="${W - 16}" height="${H - 16}" rx="12" fill="${panel}" stroke="#E1E7F2" stroke-width="1.4"/>` +
      txt(W / 2, 34, title, { size: 15, c: INK, weight: 800, ls: "0.8" })],
    end() {
      this.parts.push(note ? txt(W / 2, H - 14, note, { size: 11, c: SOFT, style: "italic" }) : "", "</svg>");
      return this.parts.join("");
    },
    add(x) { this.parts.push(x); return this; },
  };
}
function wire(pts, o = {}) {
  let d = `M${n(pts[0][0])} ${n(pts[0][1])}`;
  for (let i = 1; i < pts.length; i++) d += ` L${n(pts[i][0])} ${n(pts[i][1])}`;
  return path(d, { w: o.w || 2.6, c: o.c || INK, dash: o.dash, fill: "none" });
}
const figs = {};

/* ------------------------------------------------------------------ */
figs["fig-iso-symbols.svg"] = () => {
  const f = frame("The alphabet of ISO 1219-1", "circle = energy conversion · square = valve · solid line = working · dashed = pilot · dotted = drain");
  /* energy converters: hydraulic (filled) vs pneumatic (hollow) */
  f.add(txt(120, 66, "energy conversion", { size: 12, weight: 800, c: SOFT }));
  f.add(g(90, 110, 0.95, pump({}), null));
  f.add(txt(90, 152, "pump (out)", { size: 11 }));
  f.add(g(180, 110, 0.95, hydMotor({}), null));
  f.add(txt(180, 152, "motor (in)", { size: 11 }));
  f.add(g(90, 225, 0.95, compressor({}), null));
  f.add(txt(180 + 0, 0, "", {}));
  f.add(txt(90, 267, "compressor", { size: 11 }));
  f.add(g(180, 225, 0.95, airMotor({}), null));
  f.add(txt(180, 267, "air motor", { size: 11 }));
  f.add(txt(135, 305, "filled ▲ = hydraulic  ·  hollow △ = pneumatic — apex shows energy flow", { size: 10.5, style: "italic" }));
  /* valve envelopes */
  f.add(txt(390, 66, "one square per position", { size: 12, weight: 800, c: SOFT }));
  f.add(g(390, 150, 1.05, dcv({
    boxes: [
      { arrows: [[20, 82, 26, 18], [76, 18, 80, 82]] },
      { closed: [[20, 18], [80, 18], [20, 82], [80, 82]] },
      { arrows: [[20, 82, 76, 18], [80, 82, 26, 18]] },
    ],
    solL: true, solR: true, springL: true, springR: true,
    portTop: [{ x: 20, label: "A" }, { x: 80, label: "B" }],
    portBottom: [{ x: 20, label: "P" }, { x: 80, label: "T" }],
  }), null));
  f.add(txt(390, 230, "ports sit on the rest position — boxes slide across them", { size: 10.5, style: "italic" }));
  f.add(txt(390, 300, "actuation: ▨ + diagonal = solenoid · zigzag = spring", { size: 10.5, style: "italic" }));
  /* line types + conditioning */
  f.add(txt(620, 66, "lines & conditioning", { size: 12, weight: 800, c: SOFT }));
  f.add(line(560, 100, 690, 100, { w: 2.8 }));
  f.add(txt(625, 90, "working", { size: 10.5 }));
  f.add(line(560, 140, 690, 140, { w: 2, dash: "7 5", c: PILOT }));
  f.add(txt(625, 130, "pilot", { size: 10.5 }));
  f.add(line(560, 180, 690, 180, { w: 2, dash: "2.5 5" }));
  f.add(txt(625, 170, "drain / leak", { size: 10.5 }));
  f.add(line(560, 220, 630, 220, { w: 2.4 }) + arrow(640, 220, 0, { l: 9 }));
  f.add(txt(630, 210, "flow direction", { size: 10.5 }));
  f.add(g(625, 300, 0.85, airService({}), null));
  f.add(txt(625, 342, "service unit = one dashed box", { size: 10.5, style: "italic" }));
  return f.end();
};

/* ------------------------------------------------------------------ */
figs["fig-hyd-pumps.svg"] = () => {
  const f = frame("Hydraulic pumps — flow source, pressure only against resistance", "Q = Vg × n / 1000 [L/min] · the relief valve protects the pump, never the pump itself");
  /* mini circuit: tank -> pump -> relief + gauge + flow arrow */
  f.add(g(105, 330, 1.0, tank({ w: 40 })));
  f.add(wire([[105, 312], [105, 250], [170, 250]]));
  f.add(g(170, 226, 0.98, pumpWithMotor({}), null));
  f.add(txt(120, 200, "M + fixed pump", { size: 10.5 }));
  f.add(wire([[170, 181], [170, 120], [560, 120]]));
  f.add(arrow(300, 120, 0, { l: 10 }));
  f.add(txt(330, 108, "Q = Vg · n / 1000", { size: 13, weight: 800, style: "italic", c: INK }));
  /* relief branch */
  f.add(wire([[330, 120], [330, 208]]));
  f.add(g(345, 234, 1.05, reliefValve({}), null));
  f.add(txt(300, 262, "relief valve", { size: 10.5, style: "italic", anchor: "end" }));
  f.add(wire([[345, 200], [345, 160]]));
  f.add(g(345, 300, 0.9, tank({ w: 32 })));
  f.add(txt(396, 236, "cracks at its setting →", { size: 10, c: PILOT, style: "italic", anchor: "start" }));
  /* gauge */
  f.add(wire([[470, 120], [470, 180]]));
  f.add(g(470, 196, 1.05, pressureGauge({ stub: 0 }), null));
  f.add(txt(505, 200, "p", { size: 13, weight: 800, c: ACC, anchor: "start" }));
  /* to load */
  f.add(g(640, 120, 1.0, checkValve({}), null));
  f.add(txt(640, 90, "valves decide where the flow goes —", { size: 10.5, style: "italic" }));
  f.add(txt(640, 156, "pressure only rises against LOAD", { size: 10.5, weight: 700, c: ACC }));
  /* bottom comparison: fixed / variable / two-direction */
  f.add(line(30, 305, 730, 305, { w: 1.2, c: "#c7d2e3" }));
  f.add(g(240, 360, 0.8, pump({}), null));
  f.add(txt(240, 404, "fixed — one direction", { size: 10.5 }));
  f.add(g(380, 360, 0.8, pump({ variable: true }), null));
  f.add(txt(380, 404, "variable displacement", { size: 10.5 }));
  f.add(g(520, 360, 0.8, pump({ twoDir: true }), null));
  f.add(txt(520, 404, "two flow directions", { size: 10.5 }));
  return f.end();
};

/* ------------------------------------------------------------------ */
figs["fig-hyd-motors.svg"] = () => {
  const f = frame("Hydraulic motors — pressure back into rotation", "same box as a pump, reversed: flow in, torque out — gear, vane and piston designs");
  f.add(g(150, 180, 1.5, hydMotor({}), null));
  f.add(txt(150, 260, "hydraulic motor (ISO 1219-1)", { size: 11.5 }));
  f.add(txt(150, 120, "△ apex points IN — flow does work", { size: 11, style: "italic" }));
  /* formulas */
  f.add(rect(300, 90, 420, 120, { rx: 12, fill: "#fff", c: "#D6DEEC", w: 1.4 }));
  f.add(txt(330, 122, "torque  M = Δp · Vg / (20π)  [N·m]   (Δp in bar, Vg in cm³)", { size: 13, weight: 800, anchor: "start", c: INK }));
  f.add(txt(330, 152, "speed  n = 1000 · Q / Vg  [rpm]   (Q in L/min)", { size: 13, weight: 800, anchor: "start", c: INK }));
  f.add(txt(330, 184, "more displacement = more torque, less speed — pick Vg by load", { size: 11, style: "italic", anchor: "start" }));
  f.add(txt(330, 204, "case-drain line (L) protects the shaft seal", { size: 11, style: "italic", anchor: "start", c: PILOT }));
  /* mini circuit: valve -> motor with crossover for 2 directions */
  f.add(line(30, 300, 730, 300, { w: 1.2, c: "#c7d2e3" }));
  f.add(txt(60, 330, "", {}));
  f.add(g(180, 356, 0.85, hydMotor({ twoDir: true }), null));
  f.add(txt(180, 404, "two direction ports", { size: 10.5 }));
  f.add(g(360, 356, 0.85, hydMotor({ variable: true }), null));
  f.add(txt(360, 404, "variable motor — speed range", { size: 10.5 }));
  f.add(g(560, 350, 1.1, dcv({
    boxes: [
      { arrows: [[20, 18, 24, 82], [80, 82, 76, 18]] },
      { closed: [[20, 18], [80, 18], [20, 82], [80, 82]] },
      { arrows: [[20, 18, 76, 82], [80, 18, 24, 82]] },
    ],
    solL: "Y1", solR: "Y2", springL: true, springR: true,
    portTop: [{ x: 20, label: "A" }, { x: 80, label: "B" }],
    portBottom: [{ x: 20, label: "P" }, { x: 80, label: "T" }],
  }), null));
  f.add(wire([[545, 332], [545, 320], [200, 320], [200, 340]], { dash: "5 4", c: SOFT }));
  f.add(wire([[575, 332], [575, 310], [230, 310], [230, 336]], { dash: "5 4", c: SOFT }));
  f.add(txt(560, 404, "4/3 DCV selects the direction", { size: 10.5 }));
  return f.end();
};

/* ------------------------------------------------------------------ */
figs["fig-hyd-cylinders.svg"] = () => {
  const f = frame("Cylinders — force from pressure × area", "F_push = p · A₁ · 10 [N] · F_pull = p · (A₁ − A₂) · 10 — retraction is faster AND weaker");
  f.add(g(150, 100, 1.5, cylDA({}), null));
  f.add(txt(150, 150, "double-acting — powered both ways", { size: 11 }));
  f.add(txt(150 + 112, 96, "rod", { size: 10, style: "italic" }));
  f.add(txt(96, 66, "cap end A₁ = π·d²/4", { size: 10, c: BLUE }));
  f.add(g(150, 250, 1.4, cylSA({}), null));
  f.add(txt(150, 290, "single-acting + spring return", { size: 11 }));
  f.add(g(150, 370, 1.3, rodless(), null));
  f.add(txt(150, 404, "rodless — long strokes, magnetic/band", { size: 11 }));
  /* right side: force sketch + formulas */
  const bx = 480;
  f.add(rect(bx - 150, 70, 300, 130, { rx: 12, fill: "#fff", c: "#D6DEEC", w: 1.4 }));
  f.add(txt(bx, 100, "push (extend):   F = p · A₁ · 10", { size: 13.5, weight: 800, c: INK }));
  f.add(txt(bx, 130, "pull (retract): F = p · (A₁ − A₂) · 10", { size: 13.5, weight: 800, c: ACC }));
  f.add(txt(bx, 160, "same flow → retract is quicker (smaller volume)", { size: 10.5, style: "italic" }));
  f.add(txt(bx, 182, "Ø63/36 mm @ 160 bar ≈ 49.9 kN push / 33.6 kN pull", { size: 10.5, style: "italic" }));
  f.add(g(bx, 300, 1.15, telescopic(), null));
  f.add(txt(bx, 350, "telescopic — big stroke from a short body,", { size: 10.5 }));
  f.add(txt(bx, 366, "but each stage loses area & force", { size: 10.5 }));
  f.add(txt(590, 96, "↔", { size: 18, c: SOFT }));
  return f.end();
};

/* ------------------------------------------------------------------ */
figs["fig-hyd-dcv.svg"] = () => {
  const f = frame("4/3-way spool valve — the muscle's steer", "boxes = spool positions · the centre box carries the ports · energise a solenoid = slide the boxes");
  f.add(g(300, 185, 1.75, dcv({
    boxes: [
      { arrows: [[20, 82, 26, 18], [76, 18, 80, 82]] },
      { closed: [[20, 18], [80, 18], [20, 82], [80, 82]] },
      { arrows: [[20, 82, 76, 18], [80, 82, 26, 18]] },
    ],
    solL: "a", solR: "b", springL: true, springR: true, detents: false,
    portTop: [{ x: 20, label: "A" }, { x: 80, label: "B" }],
    portBottom: [{ x: 20, label: "P" }, { x: 80, label: "T" }],
  }), null));
  f.add(txt(300, 290, "closed centre shown — all four ports locked at rest", { size: 11, style: "italic" }));
  f.add(txt(120, 120, "solenoid a → P→A, B→T (extend)", { size: 11, c: BLUE, weight: 700 }));
  f.add(txt(485, 120, "solenoid b → P→B, A→T (retract)", { size: 11, c: BLUE, weight: 700 }));
  /* centre variants row */
  f.add(line(40, 325, 720, 325, { w: 1.2, c: "#c7d2e3" }));
  f.add(txt(120, 352, "choose the centre for the job:", { size: 11.5, weight: 800 }));
  const cv = [
    ["closed — hold", { closed: [[20, 18], [80, 18], [20, 82], [80, 82]] }],
    ["tandem — pump unloads", { arrows: [[50, 82, 50, 18]], closed: [[20, 18], [80, 18]] }],
    ["float — cylinder free", { arrows: [[20, 18, 24, 82], [80, 18, 76, 82]], closed: [[50, 82]] }],
    ["open — all to tank", { arrows: [[20, 18, 80, 82]], closed: [[80, 18]] }],
  ];
  cv.forEach((c2, i) => {
    f.add(g(300 + i * 130, 378, 0.72, dcv({ boxes: [c2[1]] }), null));
    f.add(txt(300 + i * 130, 412, c2[0], { size: 9.5 }));
  });
  return f.end();
};

/* ------------------------------------------------------------------ */
figs["fig-hyd-pressure-valves.svg"] = () => {
  const f = frame("Pressure valves — relief limits, reducing holds down", "pilot dashed shows WHERE the valve reads: relief = inlet (NC) · reducing = outlet (NO)");
  /* relief */
  f.add(g(200, 170, 1.6, reliefValve({}), null));
  f.add(txt(200, 96, "system pressure P", { size: 10.5, style: "italic" }));
  f.add(g(200, 300, 0.95, tank({ w: 34 })));
  f.add(txt(200, 238, "", {}));
  f.add(txt(200, 330, "RELIEF — normally closed;", { size: 11, weight: 700 }));
  f.add(txt(200, 348, "opens at setting, dumps to tank", { size: 10.5, style: "italic" }));
  f.add(txt(146, 208, "pilot reads", { size: 9.5, c: PILOT }));
  f.add(txt(146, 220, "INLET side", { size: 9.5, c: PILOT }));
  /* reducing */
  f.add(g(520, 170, 1.6, reducingValve({}), null));
  f.add(txt(520, 96, "reduced branch A", { size: 10.5, style: "italic" }));
  f.add(txt(520, 330, "REDUCING — normally open;", { size: 11, weight: 700 }));
  f.add(txt(520, 348, "throttles to hold a lower branch pressure", { size: 10.5, style: "italic" }));
  f.add(txt(586, 236, "pilot reads", { size: 9.5, c: PILOT, anchor: "start" }));
  f.add(txt(586, 248, "OUTLET side", { size: 9.5, c: PILOT, anchor: "start" }));
  f.add(line(370, 90, 370, 380, { w: 1.2, dash: "4 5", c: "#b6c2d6" }));
  f.add(txt(370, 400, "sequence valve = relief body used as a pressure switch (next stage starts at setting)", { size: 10.5, style: "italic" }));
  return f.end();
};

/* ------------------------------------------------------------------ */
figs["fig-hyd-flow-valves.svg"] = () => {
  const f = frame("Flow valves — speed lives here", "meter-in vs meter-out decides stability · one-way FCV gives speed only in one direction");
  f.add(g(150, 130, 1.5, throttle({}), null));
  f.add(txt(150, 196, "restrictor / needle — plain Δp-dependent", { size: 10.5 }));
  f.add(g(400, 140, 1.4, oneWayFlowControl({}), null));
  f.add(txt(400, 220, "one-way flow control:", { size: 11, weight: 700 }));
  f.add(txt(400, 238, "restricted one way, free reverse", { size: 10.5, style: "italic" }));
  f.add(txt(400, 256, "the clamp-stack classic", { size: 10, style: "italic", c: SOFT }));
  /* 2-way compensated */
  f.add(g(640, 130, 1.4, throttle({}), null));
  f.add(rect(640 - 30, 130 - 40, 62, 84, { rx: 5, w: 1.6, fill: "none", c: SOFT, dash: "6 4" }));
  f.add(path(`M640 186 H700 V120`, { w: 1.7, dash: "5 4", c: PILOT }));
  f.add(txt(640, 240, "2-way flow control:", { size: 11, weight: 700 }));
  f.add(txt(640, 258, "Δp compensator keeps the drop", { size: 10.5, style: "italic" }));
  f.add(txt(640, 274, "constant ≈ 10 bar → speed stays put", { size: 10.5, style: "italic" }));
  /* meter-in vs meter-out sketch */
  f.add(line(40, 300, 720, 300, { w: 1.2, c: "#c7d2e3" }));
  f.add(txt(120, 330, "meter-IN: FCV on the P line — governing the INCOMING oil", { size: 11 }));
  f.add(txt(120, 352, "meter-OUT: FCV on the return — back-pressure brakes the load", { size: 11, weight: 700, c: ACC }));
  f.add(txt(120, 374, "pulling / overrunning load? choose meter-OUT for a stable rod", { size: 10.5, style: "italic" }));
  return f.end();
};

/* ------------------------------------------------------------------ */
figs["fig-hyd-accumulator.svg"] = () => {
  const f = frame("Hydropneumatic accumulator — stored pressure on tap", "gas pre-charge p₀ ≈ 0.6–0.8 · p_min · charge with NITROGEN ONLY — oxygen explodes with oil mist");
  f.add(g(150, 150, 1.8, accumulator({}), null));
  f.add(txt(150, 230, "bladder type: N₂ gas bubble over oil", { size: 11 }));
  /* circuit: pump node, shutoff to tank, relief */
  f.add(wire([[150, 196], [150, 300]]));
  f.add(wire([[150, 300], [330, 300]]));
  f.add(txt(240, 286, "from system P", { size: 10.5, style: "italic" }));
  f.add(g(420, 300, 1.0, checkValve({}), null));
  f.add(txt(420, 262, "isolates when pump stops", { size: 10, style: "italic" }));
  f.add(wire([[330, 300], [480, 300]]));
  f.add(txt(520, 292, "→ machine", { size: 11, weight: 700, anchor: "start" }));
  /* safety block */
  f.add(wire([[380, 300], [380, 360]]));
  f.add(g(395, 384, 0.9, reliefValve({}), null));
  f.add(txt(470, 390, "safety relief", { size: 10, style: "italic", anchor: "start" }));
  f.add(g(395 + 0, 430, 0.8, tank({ w: 30 })));
  /* right column notes */
  f.add(rect(560, 70, 170, 130, { rx: 12, fill: "#fff", c: "#D6DEEC", w: 1.4 }));
  f.add(txt(645, 100, "uses", { size: 12, weight: 800 }));
  f.add(txt(645, 124, "· emergency stop stroke", { size: 10.5 }));
  f.add(txt(645, 144, "· leak make-up / holding", { size: 10.5 }));
  f.add(txt(645, 164, "· pulsation damping", { size: 10.5 }));
  f.add(txt(645, 184, "· volume aid on peaks", { size: 10.5 }));
  f.add(txt(645, 240, "gas law: p₀·V₀ = p₁·V₁", { size: 11.5, weight: 800, c: INK }));
  f.add(txt(645, 262, "check p₀ before every service", { size: 10.5, style: "italic", c: ACC }));
  return f.end();
};

/* ------------------------------------------------------------------ */
figs["fig-hyd-measurement.svg"] = () => {
  const f = frame("Measurement — numbers first, wrenches second", "gauge = eyes · transducer = 4…20 mA or 0…10 V to the PLC · test points before/after the suspect valve");
  f.add(g(150, 150, 1.9, pressureGauge({ stub: 26 }), null));
  f.add(txt(150, 220, "Bourdon-tube gauge", { size: 11 }));
  f.add(txt(150, 240, "reading at a glance — glycerine-filled lives longer", { size: 10, style: "italic" }));
  /* transducer = instrument box with signal arrow */
  f.add(rect(360, 128, 56, 44, { rx: 8, w: 2.4, fill: "#fff" }));
  f.add(txt(388, 155, "p", { size: 15, weight: 800, c: INK }));
  f.add(line(388, 172, 388, 200, { w: 2.6 }));
  f.add(line(416, 140, 470, 140, { w: 1.8, dash: "5 4", c: PILOT }) + arrow(478, 140, 0, { l: 8, c: PILOT }));
  f.add(txt(388, 226, "pressure transducer", { size: 11 }));
  f.add(txt(455, 128, "4…20 mA", { size: 10, c: PILOT, anchor: "start" }));
  /* flow meter = circle with arrow through + scale ticks */
  f.add(circle(600, 150, 22, { w: 2.6 }) + arrow(600, 150, 0, { l: 13 }) + line(578, 150, 622, 150, { w: 1.6, c: SOFT }));
  f.add(line(600, 172, 600, 200, { w: 2.6 }));
  f.add(txt(600, 226, "flow meter", { size: 11 }));
  f.add(txt(600, 246, "L/min — catch a hungry pump early", { size: 10, style: "italic" }));
  /* hint bar */
  f.add(line(40, 290, 720, 290, { w: 1.2, c: "#c7d2e3" }));
  f.add(txt(120, 322, "diagnose by Δp: measure upstream and downstream of the suspect part —", { size: 11.5 }));
  f.add(txt(120, 344, "a clog eats bar, a healthy line barely drops any", { size: 11.5, weight: 700 }));
  f.add(txt(380, 386, "in the deck: gauges, transducers, test points and flow meters read the same solver live", { size: 10.5, style: "italic" }));
  return f.end();
};

module.exports = { figs, frame, wire, W, H };
