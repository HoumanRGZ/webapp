const fs = require("fs");
const src = fs.readFileSync("/home/user/work/harness/test-wp.js", "utf8");
const stubStart = src.indexOf("const STUBS");
const stubEnd = src.indexOf("`;\n\nfunction bootstrap", stubStart);
const STUBS = eval(src.slice(stubStart, stubEnd + 2) + "\n;STUBS;");

(async () => {
  const { loadNodeRuntime } = require("@php-wasm/node");
  const { PHP } = require("/home/user/work/harness/node_modules/@php-wasm/node/node_modules/@php-wasm/universal/index.cjs");
  const php = new PHP(await loadNodeRuntime("8.2"));
  const code = STUBS.replace("?>", "") + "\ndefine('ABSPATH','/wp/');\n$GLOBALS['__hooks']=[];\necho 'STUBS-OK';";
  const res = await php.run({ code }).catch(e => e);
  const t = res.text || "";
  console.log("RESULT:", t.slice(0, 200));
  if (res.errors) { console.log("ERRORS:", String(res.errors).slice(0, 300)); }
  if (t.indexOf("LINE:") === -1 && t.indexOf("STUBS-OK") === -1) {
    // pinpoint: run again line-marked
  }
})().catch(e => { console.log("CRASH", String(e).slice(0, 400)); });
