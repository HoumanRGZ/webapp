// Spool slide direction check: add a 4/3 DCV, set spoolState left/center/right, dump SVGs.
const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const code = fs.readFileSync(process.argv[2] || "/home/user/work/new.min.js", "utf8");
const outDir = process.argv[3] || "/home/user/work/render/din";
const vc = new VirtualConsole();
vc.on("jsdomError", (e) => console.log("ERR:", e.message));
const dom = new JSDOM(`<!DOCTYPE html><html><body><div id="rgz-hydraulic-studio"></div></body></html>`, {
  runScripts: "dangerously", pretendToBeVisual: true, url: "https://example.com/", virtualConsole: vc,
  beforeParse(window) {
    window.matchMedia = () => ({ matches: false, media: "", addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {} });
    window.confirm = () => true; window.alert = () => {};
    window.requestAnimationFrame = (cb) => setTimeout(cb, 0);
    window.SVGElement.prototype.getBBox = function () { return { x: 0, y: 0, width: 100, height: 100 }; };
  },
});
const { window } = dom;
const script = window.document.createElement("script");
script.textContent = code;
window.document.body.appendChild(script);

function setSpool(val) {
  const insp = window.document.getElementById("rgz-inspector");
  const labels = [...insp.querySelectorAll("label,.rgz-field")];
  for (const f of labels) {
    if (/spool state/i.test(f.textContent)) {
      const sel = f.querySelector("select");
      if (sel) { sel.value = val; sel.dispatchEvent(new window.Event("change", { bubbles: true })); return true; }
    }
  }
  // fallback: any select containing option with value val
  for (const sel of insp.querySelectorAll("select")) {
    if ([...sel.options].some((o) => o.value === val)) { sel.value = val; sel.dispatchEvent(new window.Event("change", { bubbles: true })); return true; }
  }
  return false;
}

setTimeout(() => {
  const root = window.document.getElementById("rgz-hydraulic-studio");
  const canvas = window.document.getElementById("rgz-canvas");
  const cards = [...root.querySelectorAll(".rgz-symbol-card")];
  const dcv = cards.find((c) => c.dataset.type === "directionalValve43" || /4\/3/.test(c.textContent));
  console.log("dcv type:", dcv && dcv.dataset.type);
  dcv.dispatchEvent(new window.MouseEvent("dblclick", { bubbles: true }));
  setTimeout(() => {
    for (const st of ["left", "center", "right"]) {
      const ok = setSpool(st);
      const groups = canvas.querySelectorAll("g.rgz-component");
      const g = groups[groups.length - 1];
      const clone = g.cloneNode(true);
      clone.querySelectorAll(".selection-box,.component-label,.port-hit,circle.port,text.port-label").forEach((n) => n.remove());
      clone.setAttribute("transform", "");
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="-150 -100 300 200" style="background:#0b1a33">${clone.outerHTML}</svg>`;
      fs.writeFileSync(`${outDir}/spool-${st}.svg`, svg);
      console.log("state", st, "set:", ok, "transform:", (clone.querySelector("g[transform]") || {}).getAttribute ? clone.querySelector("g[transform]").getAttribute("transform") : "?");
    }
  }, 400);
}, 1500);
