// Welcome popup + guided tour: first-visit popup with two buttons, persistence, force param, disabled flag, tour walkthrough.
const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const code = fs.readFileSync("/home/user/work/new.min.js", "utf8");
const STORE_KEY = "rgz.welcome.v2.hydraulic";

function boot(url, opts) {
  opts = opts || {};
  const vc = new VirtualConsole();
  const errors = [];
  vc.on("jsdomError", (e) => errors.push(e.message));
  const dom = new JSDOM(`<!DOCTYPE html><html><body><div id="rgz-hydraulic-studio"></div></body></html>`, {
    runScripts: "dangerously", pretendToBeVisual: true, url, virtualConsole: vc,
    beforeParse(window) {
      window.matchMedia = () => ({ matches: false, media: "", addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {} });
      window.confirm = () => true; window.alert = () => {};
      window.requestAnimationFrame = (cb) => setTimeout(cb, 0);
      window.SVGElement.prototype.getBBox = function () { return { x: 0, y: 0, width: 100, height: 100 }; };
      window.RGZHydraulicStudioConfig = {};
      if (opts.tutorial === false) window.RGZHydraulicStudioConfig.tutorial = false;
      if (opts.tourText) window.RGZHydraulicStudioConfig.tourText = opts.tourText;
      if (opts.preset) window.localStorage.setItem(STORE_KEY, "2026-07-01T00:00:00.000Z");
    },
  });
  const { window } = dom;
  const script = window.document.createElement("script");
  script.textContent = code;
  window.document.body.appendChild(script);
  return { window, errors };
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let fails = 0;
const expect = (c, m) => { if (c) console.log("   ✓ " + m); else { console.log("   ✗ " + m); fails++; } };

(async () => {
  // 1) first visit → welcome popup (NOT the tour) after ~450ms
  let ctx = boot("https://site.test/hydraulic-studio/");
  await sleep(400);
  expect(!ctx.window.document.querySelector(".rgz-welcome"), "popup not shown immediately (waits ~450ms)");
  await sleep(1100);
  let pop = ctx.window.document.querySelector(".rgz-welcome");
  expect(!!pop, "welcome popup appears on first visit");
  expect(!ctx.window.document.querySelector(".rgz-tour"), "tour does NOT auto-start anymore");
  if (pop) {
    expect(/Welcome to Hydraulic Studio/.test(pop.querySelector("h3").textContent), "heading names the app");
    const go = pop.querySelector(".rgz-welcome-go");
    const tourBtn = pop.querySelector(".rgz-welcome-tour");
    expect(!!go && /Go to Hydraulic Studio/.test(go.textContent), 'button 1: "Go to Hydraulic Studio"');
    expect(!!tourBtn && /Start tutorial/.test(tourBtn.textContent), 'button 2: "▶ Start tutorial"');
    // 2) "Go to app" closes + persists, no tour
    go.click();
    await sleep(120);
    expect(!ctx.window.document.querySelector(".rgz-welcome"), "Go-to-app button closes the popup");
    expect(!!ctx.window.localStorage.getItem(STORE_KEY), "first-visit flag persisted");
    await sleep(900);
    expect(!ctx.window.document.querySelector(".rgz-tour"), "no tour after Go-to-app");
  }
  expect(!ctx.errors.filter((e) => !/CSS|css/.test(e)).length, "no JS errors during popup flow");

  // 3) custom editable text from config
  ctx = boot("https://site.test/hydraulic-studio/", { tourText: "Salam! Custom admin text here." });
  await sleep(900);
  pop = ctx.window.document.querySelector(".rgz-welcome");
  expect(!!pop && /Custom admin text/.test(pop.querySelector("p").textContent), "admin-editable welcome text is used");

  // 4) Start tutorial → popup closes, tour starts
  let tourBtn = pop.querySelector(".rgz-welcome-tour");
  tourBtn.click();
  await sleep(2500);
  expect(!ctx.window.document.querySelector(".rgz-welcome"), "popup removed after Start tutorial");
  expect(!!ctx.window.localStorage.getItem(STORE_KEY), "flag saved on Start tutorial");
  let tour = ctx.window.document.querySelector(".rgz-tour");
  expect(!!tour, "tour starts from popup button");
  expect(!!tour && !!tour.querySelector(".rgz-tour-title"), "tour card has a title");

  // 5) walk the tour to the end with Next
  let stepsT = 0;
  for (let i = 0; i < 14 && ctx.window.document.querySelector(".rgz-tour"); i++) {
    ctx.window.document.querySelector(".rgz-tour-next").click();
    stepsT++;
    await sleep(140);
  }
  console.log("   (walked " + stepsT + " tour steps)");
  expect(stepsT >= 8, "tour walks through >= 8 steps until Finish");

  // 6) second visit (flag set) → no popup, no tour
  ctx = boot("https://site.test/hydraulic-studio/", { preset: true });
  await sleep(900);
  expect(!ctx.window.document.querySelector(".rgz-welcome"), "no popup when flag present");
  await sleep(1600);
  expect(!ctx.window.document.querySelector(".rgz-tour"), "no tour when flag present");

  // 7) forced launch ?rgz_tour=1 → tour directly, no popup (even with flag)
  ctx = boot("https://site.test/hydraulic-studio/?rgz_tour=1", { preset: true });
  await sleep(500);
  expect(!ctx.window.document.querySelector(".rgz-welcome"), "no popup on forced launch");
  await sleep(1800);
  tour = ctx.window.document.querySelector(".rgz-tour");
  expect(!!tour, "?rgz_tour=1 forces the tour directly");
  if (tour) {
    tour.querySelector(".rgz-tour-skip").click();
    await sleep(150);
    expect(!ctx.window.document.querySelector(".rgz-tour"), "Skip tour button closes the tour");
  }
  // ?rgz_tour=hydraulic also accepted
  ctx = boot("https://site.test/hydraulic-studio/?rgz_tour=hydraulic", {});
  await sleep(2200);
  expect(!!ctx.window.document.querySelector(".rgz-tour"), "?rgz_tour=hydraulic forces the tour too");
  ctx.window.document.dispatchEvent(new ctx.window.KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
  await sleep(150);
  expect(!ctx.window.document.querySelector(".rgz-tour"), "Esc closes the tour");

  // 8) tutorial:false → no popup at all
  ctx = boot("https://site.test/hydraulic-studio/", { tutorial: false });
  await sleep(900);
  expect(!ctx.window.document.querySelector(".rgz-welcome"), "tutorial:false suppresses the popup");
  await sleep(1600);
  expect(!ctx.window.document.querySelector(".rgz-tour"), "tutorial:false suppresses any auto tour");

  // 9) X close + backdrop click both mark as seen
  ctx = boot("https://site.test/hydraulic-studio/", {});
  await sleep(900);
  pop = ctx.window.document.querySelector(".rgz-welcome");
  pop.querySelector(".rgz-welcome-x").click();
  await sleep(120);
  expect(!ctx.window.document.querySelector(".rgz-welcome"), "X button closes the popup");
  expect(!!ctx.window.localStorage.getItem(STORE_KEY), "X button still marks the visit as seen");

  console.log(fails === 0 ? "\nALL WELCOME/TOUR TESTS PASSED" : "\n" + fails + " FAILURES");
  process.exit(0);
})();
