// UI E2E: PLC engine — electrohydraulic auto-return example runs its cycle from the
// PLC program; deleting PLC1 (the user's litmus) freezes the sequence mid-stroke.
const fs = require("fs"); const { JSDOM, VirtualConsole } = require("jsdom");
const code = fs.readFileSync(process.argv[2], "utf8");
(async () => {
  const mkDom = () => new JSDOM(`<!DOCTYPE html><body><div id="rgz-hydraulic-studio"></div><script>${code}<\/script>`, {
    runScripts: "dangerously", pretendToBeVisual: true, url: "https://example.com/", virtualConsole: new VirtualConsole(),
    beforeParse(window) {
      window.matchMedia = () => ({ matches: false, addEventListener() {} });
      window.confirm = () => true; window.alert = () => {};
      let __now = 0; window.requestAnimationFrame = cb => setTimeout(() => cb(__now += 16), 4);
      window.SVGElement.prototype.getBBox = () => ({ x: 0, y: 0, width: 40, height: 12 });
      window.SVGSVGElement.prototype.createSVGPoint = function () { const pt = { x: 0, y: 0 }; pt.matrixTransform = () => pt; return pt; };
      window.SVGSVGElement.prototype.getScreenCTM = window.SVGSVGElement.prototype.getCTM = () => ({ a: 1, b: 0, c: 0, d: 1, e: 0, f: 0, inverse() { return this; }, multiply() { return this; } });
      window.console.warn = () => {};
    }
  });
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  let pass = 0, fail = 0; const ok = (c, n, d) => { if (c) { pass++; console.log("  PASS", n, d ?? "") } else { fail++; console.log("  FAIL", n, "=>", d) } };

  async function loadAutoReturn(dom, deletePlc) {
    const { window } = dom; const doc = window.document;
    await sleep(900);
    doc.querySelector('[data-action="browse-examples"]').click(); await sleep(150);
    const lvl = doc.getElementById("rgz-level-selectbox");
    const li = [...lvl.options].findIndex(o => /^Intermediate$/i.test(o.textContent));
    if (li < 0) return { err: "intermediate level not found: " + [...lvl.options].map(o => o.textContent).join("|") };
    lvl.value = lvl.options[li].value; lvl.dispatchEvent(new window.Event("change", { bubbles: true })); await sleep(200);
    const ex = doc.getElementById("rgz-example-selectbox");
    const idx = [...ex.options].findIndex(o => /auto-return/i.test(o.textContent));
    if (idx < 0) return { err: "auto-return example not found" };
    ex.value = ex.options[idx].value; ex.dispatchEvent(new window.Event("change", { bubbles: true })); await sleep(100);
    doc.querySelector("[data-modal-open-example]").dispatchEvent(new window.MouseEvent("click", { bubbles: true }));
    await sleep(400);
    const compEls = [...doc.querySelectorAll("g.rgz-component")];
    let labels = compEls.map(g => { const t = g.querySelector("text.component-label"); return t ? t.textContent.trim() : "?"; });
    if (deletePlc) {
      const plcG = compEls.find(g => { const t = g.querySelector("text.component-label"); return t && t.textContent.trim() === "PLC1"; });
      if (!plcG) return { err: "PLC1 not on canvas: " + labels.join(",") };
      plcG.dispatchEvent(new (window.PointerEvent || window.MouseEvent)("pointerdown", { bubbles: true, cancelable: true }));
      await sleep(200);
      doc.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Delete", bubbles: true }));
      await sleep(300);
      labels = [...doc.querySelectorAll("g.rgz-component")].map(g => { const t = g.querySelector("text.component-label"); return t ? t.textContent.trim() : "?"; });
    }
    return { labels, window, doc };
  }

  async function sampleCylinder(dom, seconds) {
    const { window } = dom; const doc = window.document;
    [...doc.querySelectorAll('[data-action="simulate"]')].forEach(b => b.click());
    const simTab = async () => { const b = doc.querySelector('button.rgz-tab[data-tab="simulation"]'); if (b) b.click(); await sleep(80); };
    const read = () => [...doc.querySelectorAll("#rgz-inspector-panel .rgz-kv-row")]
      .map(r => [...r.querySelectorAll("span")].map(s => s.textContent).join("=")).join(" | ");
    const speeds = [];
    for (let i = 0; i < seconds; i++) { await sleep(1000); await simTab(); const m = /C1=(-?\d[\d.]*) mm\/s/.exec(read()); speeds.push(m ? parseFloat(m[1]) : null); }
    return speeds;
  }

  // ---------- 1) WITH PLC: full auto cycle ----------
  const d1 = mkDom();
  const l1 = await loadAutoReturn(d1, false);
  ok(!l1.err, "auto-return example loads (intermediate level)", l1.err || l1.labels.slice(0, 8).join(","));
  ok(l1.labels && l1.labels.includes("PLC1") && l1.labels.includes("B1") && l1.labels.includes("B2"), "PLC1 + reed sensors B1/B2 on canvas", (l1.labels || []).join(","));
  const s1 = await sampleCylinder(d1, 12);
  console.log("  speeds with PLC:", s1.map(v => v == null ? "?" : v.toFixed(0)).join(" "));
  ok(s1.some(v => v > 60), "cylinder extends under PLC control (Q-coil / valve rules)", s1.filter(v => v > 60).length + " samples");
  ok(s1.some(v => v < -60), "cylinder retracts after B1 (PLC reversed the valve)", s1.filter(v => v < -60).length + " samples");
  const firstRet = s1.findIndex(v => v < -60);
  ok(firstRet > 0 && s1.slice(firstRet + 1).some(v => v > 60), "cycle loops (extend again after returning home)", "firstRet=" + firstRet);

  // ---------- 2) WITHOUT PLC (user litmus: delete PLC1) ----------
  const d2 = mkDom();
  const l2 = await loadAutoReturn(d2, true);
  ok(!l2.err, "example reloads for litmus run", l2.err || "ok");
  ok(l2.labels && !l2.labels.includes("PLC1"), "PLC1 deleted from canvas", (l2.labels || []).join(","));
  const s2 = await sampleCylinder(d2, 10);
  console.log("  speeds PLC-deleted:", s2.map(v => v == null ? "?" : v.toFixed(0)).join(" "));
  ok(s2.some(v => v > 60), "valve starts left: cylinder still extends once (manual initial state)", s2.filter(v => v > 60).length + " samples");
  ok(!s2.some(v => v < -60), "LITMUS: no PLC -> nothing retracts the cylinder, sequence dead", s2.filter(v => v < -60).length + " retract samples");
  const tailZero = s2.slice(-3).every(v => Math.abs(v) < 5);
  ok(tailZero, "cylinder rests dead-headed at the end (no logic acting)", s2.slice(-3).join(","));

  console.log(`\n==== PLC TEST: ${pass} passed, ${fail} failed ====`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error("HARNESS ERROR", e); process.exit(2); });
