const fs=require("fs");const{JSDOM,VirtualConsole}=require("jsdom");
const code=fs.readFileSync(process.argv[2],"utf8");
(async()=>{
 const dom=new JSDOM(`<!DOCTYPE html><body><div id="rgz-hydraulic-studio"></div><script>${code}<\/script>`,{
  runScripts:"dangerously",pretendToBeVisual:true,url:"https://example.com/",virtualConsole:new VirtualConsole(),
  beforeParse(window){
   window.matchMedia=()=>({matches:false,addEventListener(){}});
   window.confirm=()=>true;window.alert=()=>{};
   window.requestAnimationFrame=cb=>setTimeout(()=>cb(0),4);
   window.SVGElement.prototype.getBBox=()=>({x:0,y:0,width:40,height:12});
   window.console.warn=()=>{};
  }});
 const{window}=dom;const doc=window.document;const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 await sleep(900);
 doc.querySelector('[data-action="browse-examples"]').click();await sleep(150);
 const lvl=doc.getElementById("rgz-level-selectbox");
 lvl.value=lvl.options[0].value;lvl.dispatchEvent(new window.Event("change",{bubbles:true}));await sleep(200);
 const ex=doc.getElementById("rgz-example-selectbox");
 const idx=[...ex.options].findIndex(o=>/Meter-out/i.test(o.textContent));
 ex.value=ex.options[idx].value;ex.dispatchEvent(new window.Event("change",{bubbles:true}));await sleep(100);
 doc.querySelector("[data-modal-open-example]").dispatchEvent(new window.MouseEvent("click",{bubbles:true}));
 await sleep(500);
 // find label elements
 const labels=[...doc.querySelectorAll("text")].filter(t=>/^(FC|C|V|HPU|P|R)/.test(t.textContent.trim())).slice(0,12);
 labels.forEach(t=>{
   const g=t.closest("g");
   const circ=g&&g.querySelector("circle.port");
   console.log("label",JSON.stringify(t.textContent.trim()),"class",t.getAttribute("class"),"compid",circ?circ.getAttribute("data-component-id"):"?", "gclass", g?g.getAttribute("class"):"?");
 });
 process.exit(0);
})();
