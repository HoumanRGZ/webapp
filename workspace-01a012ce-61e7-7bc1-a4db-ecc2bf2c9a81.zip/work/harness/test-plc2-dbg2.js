// UI E2E #2: two-hand clamp — PLC combinatorial Q -> wired coil -> valve bucket drive
const fs = require("fs"); const { JSDOM, VirtualConsole } = require("jsdom");
const code = fs.readFileSync(process.argv[2], "utf8");
(async () => {
  const dom = new JSDOM(`<!DOCTYPE html><body><div id="rgz-hydraulic-studio"></div><script>${code}<\/script>`, {
    runScripts: "dangerously", pretendToBeVisual: true, url: "https://example.com/", virtualConsole: new VirtualConsole(),
    beforeParse(window) {
      window.matchMedia = () => ({ matches: false, addEventListener() {} });
      window.confirm = () => true; window.alert = () => {};
      let __now = 0; window.requestAnimationFrame = cb => setTimeout(() => cb(__now += 16), 4);
      window.SVGElement.prototype.getBBox = () => ({ x: 0, y: 0, width: 40, height: 12 });
      window.SVGSVGElement.prototype.createSVGPoint = function () { const pt = { x: 0, y: 0 }; pt.matrixTransform = () => pt; return pt; };
      window.SVGSVGElement.prototype.getScreenCTM = window.SVGSVGElement.prototype.getCTM = () => ({ a: 1, b: 0, c: 0, d: 1, e: 0, f: 0, inverse() { return this; }, multiply() { return this; } });
      window.console.warn = () => {};
    }
  });
  const { window } = dom; const doc = window.document;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  let pass = 0, fail = 0; const ok = (c, n, d) => { if (c) { pass++; console.log("  PASS", n, d ?? "") } else { fail++; console.log("  FAIL", n, "=>", d) } };
  await sleep(900);
  doc.querySelector('[data-action="browse-examples"]').click(); await sleep(150);
  const lvl = doc.getElementById("rgz-level-selectbox");
  lvl.value = [...lvl.options].find(o => /^Intermediate$/i.test(o.textContent)).value;
  lvl.dispatchEvent(new window.Event("change", { bubbles: true })); await sleep(200);
  const ex = doc.getElementById("rgz-example-selectbox");
  const idx = [...ex.options].findIndex(o => /Two-hand/i.test(o.textContent));
  ok(idx >= 0, "two-hand example found", "idx=" + idx);
  ex.value = ex.options[idx].value; ex.dispatchEvent(new window.Event("change", { bubbles: true })); await sleep(100);
  doc.querySelector("[data-modal-open-example]").dispatchEvent(new window.MouseEvent("click", { bubbles: true }));
  await sleep(400);
  const labels = [...doc.querySelectorAll("g.rgz-component")].map(g => { const t = g.querySelector("text.component-label"); return t ? t.textContent.trim() : "?"; });
  ok(["PLC1", "PB1", "PB2", "Y1", "V1", "PS1", "B1"].every(x => labels.includes(x)), "all control components present", labels.join(","));

  const simTab = async () => { const b = doc.querySelector('button.rgz-tab[data-tab="simulation"]'); if (b) b.click(); await sleep(80); };
  const speeds = () => [...doc.querySelectorAll("#rgz-inspector-panel .rgz-kv-row")].map(r => [...r.querySelectorAll("span")].map(s => s.textContent).join("=")).join(" | ");
  const propsDump = async (label) => {
    await selectComp(label);
    const tb = doc.querySelector('button.rgz-tab[data-tab="properties"]'); if (tb) tb.click();
    await sleep(120);
    return [...doc.querySelectorAll("#rgz-inspector-panel [data-prop-field]")].map(el => el.getAttribute("data-prop-field") + "=" + el.value).join(" ");
  };
  const clampV = () => { const m = /Clamp=(-?\d[\d.]*) mm\/s/.exec(speeds()); return m ? parseFloat(m[1]) : null; };
  const selectComp = async (label) => {
    const g = [...doc.querySelectorAll("g.rgz-component")].find(g => { const t = g.querySelector("text.component-label"); return t && t.textContent.trim() === label; });
    if (!g) return false;
    const target = [...g.children].find(c => !(c.classList && c.classList.contains("port"))) || g;
    target.dispatchEvent(new (window.PointerEvent || window.MouseEvent)("pointerdown", { bubbles: true, cancelable: true }));
    await sleep(250);
    return g.getAttribute("data-id");
  };
  const pressButton = async (label) => {
    const id = await selectComp(label); await sleep(100);
    const btn = doc.querySelector(`[data-control-kind="pushButton"][data-id="${id}"]`) || doc.querySelector(`[data-control-kind="pushButton"]`);
    if (btn) {
      const before = btn.classList.contains("primary");
      btn.click(); await sleep(250);
      return !before;
    }
    return null;
  };
  const spoolOf = async () => {
    await selectComp("V1");
    const tb = doc.querySelector('button.rgz-tab[data-tab="properties"]'); if (tb) tb.click();
    await sleep(150);
    const sel = doc.querySelector('[data-prop-field="spoolState"]');
    return sel ? sel.value : "?";
  };

  [...doc.querySelectorAll('[data-action="simulate"]')].forEach(b => b.click());
  await sleep(600); await simTab();
  ok(Math.abs(clampV() ?? 99) < 5, "idle: nothing moves before the buttons", clampV());
  const p1 = await pressButton("PB1");
  const p2 = await pressButton("PB2");
  ok(p1 === true && p2 === true, "PB1 and PB2 both toggled to pressed", "PB1=" + p1 + " PB2=" + p2);
  await sleep(400);
  const sp1 = await spoolOf();
  ok(sp1 === "left", "PB1+PB2 -> PLC raises Q1 -> Y1 -> V1 LEFT via coil bucket", "spool=" + sp1);
  await simTab();
  let moved = null;
  for (let i = 0; i < 8 && !(moved > 40); i++) {
    await simTab(); moved = clampV();
    const spd = speeds();
    const tm = /Time=([\d.]+) s/.exec(spd);
    const sp = await spoolOf();
    console.log("  poll", i, "t=" + (tm && tm[1]), "clamp=" + moved + " mm/s", "spool=" + sp);
    await sleep(600);
  }
  console.log("  DBG Clamp:", await propsDump("Clamp"));
  ok(moved > 40, "clamp cylinder extends while both buttons held", moved && moved.toFixed(0) + " mm/s");
  await pressButton("PB1"); // release PB1 -> two-hand condition broken
  await sleep(700);
  const sp2 = await spoolOf();
  ok(sp2 === "center", "release PB1 -> Q1 drops, spring buckets V1 to CENTER (safety)", "spool=" + sp2);
  await simTab();
  const stopped = clampV();
  ok(Math.abs(stopped ?? 99) < 5, "clamp cylinder stopped after release", stopped);
  console.log(`\n==== PLC2 (two-hand) TEST: ${pass} passed, ${fail} failed ====`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error("HARNESS ERROR", e); process.exit(2); });
