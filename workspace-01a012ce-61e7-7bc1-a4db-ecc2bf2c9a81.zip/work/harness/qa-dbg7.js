const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const PKG = "/home/user/work/cad-pkg/rgz-3d-cad-studio";
const php = fs.readFileSync(PKG + "/app.php", "utf8");
const start = php.indexOf("?>", php.indexOf("ob_start();"));
const retAt = php.indexOf("return ob_get_clean();");
const end = php.lastIndexOf("<?php", retAt);
let html = php.slice(start + 2, end);
html = html.replace(/<\?php\s*echo\s*esc_url\(home_url\('([^']*)'\)\);?\s*\?>/g, (m, p) => "https://houmanrgz.ir" + p);
html = html.replace(/<\?php[^?]*\?>/g, "RGZ 3D CAD Studio");
const vc = new VirtualConsole(); vc.sendTo(console, { omitJSDOMErrors: true });
const dom = new JSDOM("<!DOCTYPE html><html><head></head><body>" + html + "</body></html>", {
  url: "https://houmanrgz.ir/cad/", runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc });
const win = dom.window, doc = win.document;
function ctx2d(cv) { return new Proxy({}, { get(t, k) {
  if (k === "canvas") return cv;
  if (k === "measureText") return s => ({ width: 7 * String(s).length });
  if (k === "getImageData") return (x, y, w, h) => ({ data: new Uint8ClampedArray(Math.max(4, w * h * 4)) });
  if (k === "createLinearGradient" || k === "createRadialGradient") return () => ({ addColorStop() {} });
  if (k === "isPointInPath") return () => false;
  return () => {}; }, set() { return true; } }); }
win.HTMLCanvasElement.prototype.getContext = function (k) { return k === "2d" ? ctx2d(this) : null; };
win.RGZCAD = { accent: "#eb4e3c", worker: "assets/cad-geometry-worker.js", version: "1.0.0", units: "mm", hubUrl: "https://houmanrgz.ir/mechanical-engineering-deck/#learn-cad" };
const t = doc.createElement("script"); t.textContent = fs.readFileSync(PKG + "/assets/three.min.js", "utf8"); doc.body.appendChild(t);
let src = fs.readFileSync(PKG + "/assets/cad.js", "utf8");
const anchor = "mergeHolePolys(holePolys.concat(circPolys)).forEach(function (mp2) {";
if (!src.includes(anchor)) { console.log("ANCHOR NOT FOUND"); process.exit(1); }
src = src.replace(anchor, "(function(G){ globalThis.__mh=(globalThis.__mh||[]).concat([{wc:withCuts,inp:holePolys.length,circ:circPolys.length,sm:smoothHoles.length,out:G.length,areas:G.map(function(g2){return Math.round(Math.abs(U.polyArea(g2))*10)/10;})}]); return G; })(mergeHolePolys(holePolys.concat(circPolys))).forEach(function (mp2) {");
const c = doc.createElement("script"); c.textContent = src; doc.body.appendChild(c);
setTimeout(() => {
  const U = win.__rgzcad1;
  const sk = U.startSketchOnDatum("xy");
  sk.entities.push(U.mkEnt("rect", { cx: 30, cy: 22.5, w: 60, h: 45 }));
  U.closeSketchToPad();
  const pad = U.S.design.features[0];
  pad.L = 16; pad.edge = { style: "chamfer", size: 1 };
  sk.entities.push(U.mkEnt("hole", { cx: 15, cy: 22.5, r: 5, hType: "cbore", depth: 0, cbd: 16, cbdDepth: 4, csAngle: 90 }));
  sk.entities.push(U.mkEnt("hole", { cx: 45, cy: 22.5, r: 5, hType: "through", depth: 0, cbd: 12, cbdDepth: 2, csAngle: 90 }));
  U.padSketch(sk.id);
  U.S.design.sketches.push({ id: "skQ", name: "Sketch.pocket", plane: { kind: "faceTop", topOf: pad.id, origin: [0, 0, 16], u: [1, 0, 0], v: [0, 1, 0], n: [0, 0, 1] }, host: pad.id, entities: [U.mkEnt("rect", { cx: 30, cy: 22.5, w: 30, h: 10 })] });
  U.pocketFromSketch("skQ");
  U.S.design.features[1].L = 6;
  const ws = win.__rgzcad2.worldSoup();
  console.log("merge log:", JSON.stringify(win.__mh, null, 1));
  console.log("tris:", ws.positions.length/9);
  process.exit(0);
}, 400);
