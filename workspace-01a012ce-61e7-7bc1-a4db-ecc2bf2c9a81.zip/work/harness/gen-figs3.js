/* Part 3: electro-pneumatics, logic, cascade, timing, service, vacuum + runner. */
"use strict";
const S = require("./isolib.js");
const { figs, frame, wire, W, H } = require("./gen-figs.js");
require("./gen-figs2.js");
const { INK, SOFT, ACC, BLUE, PILOT, line, path, rect, circle, txt, arrow, spring, solenoid, solidTri, adjArrow, g, dcv,
  pump, pumpWithMotor, hydMotor, compressor, airMotor, pressureGauge, tank, pneExhaust, cylDA, cylSA, telescopic, rodless,
  reliefValve, reducingValve, checkValve, shuttleValve, andValve, throttle, oneWayFlowControl, filter, coolerSym, accumulator,
  ejector, airService, muffler, quickExhaust, esc, n } = S;

function contactNO(x1, x2, y, label) {
  const cx = (x1 + x2) / 2;
  return line(x1, y, cx - 12, y, { w: 2 }) + line(cx + 12, y, x2, y, { w: 2 }) +
    line(cx - 10, y + 7, cx - 4, y - 8, { w: 2 }) + line(cx + 2, y + 7, cx + 8, y - 8, { w: 2 }) +
    txt(cx, y - 12, label, { size: 10, c: BLUE, weight: 700 });
}
function coil(x2, y, label) {
  return line(x2 - 66, y, x2 - 24, y, { w: 2 }) + circle(x2 - 14, y, 10, { w: 2 }) + txt(x2 - 14, y + 3.5, label, { size: 9, weight: 800, c: ACC });
}
function ladder(x1, x2, y, rows) {
  let out = line(x1, y, x1, y + rows.length * 32, { w: 2.6 }) + line(x2, y, x2, y + rows.length * 32, { w: 2.6 });
  out += txt(x1, y - 8, "+24 V", { size: 10.5, weight: 800, c: INK });
  out += txt(x2, y - 8, "0V", { size: 10.5, weight: 800, c: INK });
  rows.forEach((r, i) => { out += r(x1 + 2, x2 - 2, y + 18 + i * 32); });
  return out;
}

/* ------------------------------------------------------------------ */
figs["fig-pne-elehp-circuit.svg"] = () => {
  const f = frame("Electro-pneumatic cylinder drive — one button, full force", "S1 energises Y1; the 5/2 memory valve holds position until Y2 is pulsed");
  /* service unit top-left */
  f.add(g(120, 130, 0.85, airService({}), null));
  f.add(txt(120, 176, "service unit", { size: 9.5, style: "italic" }));
  /* 5/2 valve centre */
  f.add(g(330, 220, 1.5, dcv({
    boxes: [
      { arrows: [[20, 82, 24, 18], [80, 18, 84, 82]] },
      { arrows: [[20, 82, 60, 18], [80, 18, 44, 82]] },
    ],
    solL: "Y1", solR: "Y2",
    portTop: [{ x: 20, label: "2" }, { x: 80, label: "4" }],
    portBottom: [{ x: 12, label: "1" }, { x: 50, label: "3" }, { x: 88, label: "5" }],
  }), null));
  /* supply */
  f.add(wire([[160, 130], [160, 60], [316, 60], [316, 190]]));
  f.add(txt(240, 52, "6 bar", { size: 10, style: "italic" }));
  /* exhausts */
  f.add(g(348, 290, 0.9, muffler()));
  f.add(wire([[348, 264], [348, 282]]));
  f.add(g(372, 290, 0.9, muffler()));
  f.add(wire([[372, 264], [372, 282]]));
  /* cylinder right, vertical presentation horizontal */
  f.add(wire([[326, 190], [326, 84], [430, 84]]));
  f.add(wire([[338, 190], [338, 108], [430, 108]]));
  f.add(g(500, 96, 1.3, cylDA({}), null));
  f.add(txt(500, 150, "A1", { size: 11, weight: 800 }));
  /* reed switches on barrel */
  f.add(rect(560 - 96, 96 - 16, 10, 8, { w: 1.6, fill: "#F1F5FB" }) + txt(560 - 91, 88, "b0", { size: 8, c: BLUE }));
  f.add(rect(560 - 30, 96 - 16, 10, 8, { w: 1.6, fill: "#F1F5FB" }) + txt(560 - 25, 88, "b1", { size: 8, c: BLUE }));
  /* electrical ladder bottom */
  f.add(ladder(120, 620, 320, [
    (a, b, y) => contactNO(a, b, y, "S1 start") + coil(b, y, "Y1"),
    (a, b, y) => contactNO(a, b, y, "b1 · S2") + coil(b, y, "Y2"),
  ]));
  f.add(txt(620, 320 + 2 * 32 + 12, "rod out at b1 → auto-retract", { size: 10, style: "italic" }));
  return f.end();
};

/* ------------------------------------------------------------------ */
figs["fig-pne-elehp-sequence.svg"] = () => {
  const f = frame("Sequence A+ B+ B− A− — ladder wiring", "each rung hands over to the next; nothing starts before its feedback says 'done'");
  f.add(ladder(80, 660, 80, [
    (a, b, y) => contactNO(a, b, y, "S1") + coil(b, y, "K1"),
    (a, b, y) => contactNO(a, b, y, "K1 · a0") + coil(b, y, "Y A+"),
    (a, b, y) => contactNO(a, b, y, "a1") + coil(b, y, "K2"),
    (a, b, y) => contactNO(a, b, y, "K2") + coil(b, y, "Y B+"),
    (a, b, y) => contactNO(a, b, y, "b1") + coil(b, y, "K3"),
    (a, b, y) => contactNO(a, b, y, "K3") + coil(b, y, "Y B−"),
    (a, b, y) => contactNO(a, b, y, "b0") + coil(b, y, "K4"),
    (a, b, y) => contactNO(a, b, y, "K4") + coil(b, y, "Y A−"),
  ]));
  f.add(txt(370, 80 + 8 * 32 + 22, "a0/a1 = reed switches on cylinder A · b0/b1 on B — wires, not magic", { size: 10.5, style: "italic" }));
  f.add(txt(370, 80 + 8 * 32 + 46, "signal overlap (a pressed valve that never releases) blocks the chain —", { size: 10.5 }));
  f.add(txt(370, 80 + 8 * 32 + 64, "that is when the cascade method splits the sequence into groups", { size: 10.5, c: SOFT, style: "italic" }));
  return f.end();
};

/* ------------------------------------------------------------------ */
figs["fig-pne-logic.svg"] = () => {
  const f = frame("Pure-pneumatic logic — no electricity, still thinking", "shuttle = OR · dual-pressure = AND · throttle + volume + 3/2 = time delay");
  f.add(g(170, 140, 1.6, andValve(), null));
  f.add(txt(110, 132, "a", { size: 12, weight: 800, c: BLUE })); f.add(txt(232, 132, "b", { size: 12, weight: 800, c: BLUE }));
  f.add(txt(170, 196, "y", { size: 12, weight: 800, c: ACC }));
  f.add(txt(170, 240, "dual-pressure valve (AND)", { size: 11, weight: 700 }));
  f.add(txt(170, 258, "y = a ∧ b — out only when BOTH arrive", { size: 10, style: "italic" }));
  f.add(g(430, 140, 1.6, shuttleValve({}), null));
  f.add(txt(368, 132, "a", { size: 12, weight: 800, c: BLUE })); f.add(txt(492, 132, "b", { size: 12, weight: 800, c: BLUE }));
  f.add(txt(430, 196, "y", { size: 12, weight: 800, c: ACC }));
  f.add(txt(430, 240, "shuttle valve (OR)", { size: 11, weight: 700 }));
  f.add(txt(430, 258, "y = a ∨ b — either one passes along", { size: 10, style: "italic" }));
  /* time delay */
  f.add(g(640, 120, 1.15, dcv({ boxes: [{ arrows: [[50, 82, 50, 18]] }, { arrows: [[50, 18, 50, 82]] }], pilotL: true, springR: true, portBottom: [{ x: 50, label: "1" }], portTop: [{ x: 50, label: "2" }] }), null));
  f.add(g(640, 210, 1.0, throttle({}), null));
  f.add(circle(640, 268, 20, { w: 2.4 }) + txt(640, 272, "V", { size: 12, weight: 800 }));
  f.add(wire([[640, 186], [640, 190]]) + wire([[640, 190], [640, 248]]));
  f.add(txt(640, 320, "time-delay valve", { size: 11, weight: 700 }));
  f.add(txt(640, 338, "slow fill · then snap — a pneumatic ÷timer÷", { size: 9.5, style: "italic" }));
  f.add(txt(380, 390, "gates chain into full controllers: E-stop, two-hand start, cycling machines — all air", { size: 10.5, style: "italic" }));
  return f.end();
};

/* ------------------------------------------------------------------ */
figs["fig-pne-multi.svg"] = () => {
  const f = frame("Cascade method — taming signal overlap", "supply air is given to ONE group at a time; reversing valves clear the blocked signals");
  /* two groups */
  f.add(rect(80, 90, 260, 120, { rx: 14, w: 2, fill: "#EAF3EC", c: "#BFD8C6" }));
  f.add(txt(210, 116, "group 1", { size: 12, weight: 800, c: "#1f7a3d" }));
  f.add(txt(210, 150, "A+      A−", { size: 16, weight: 800, c: INK }));
  f.add(rect(420, 90, 260, 120, { rx: 14, w: 2, fill: "#FDF0EA", c: "#F0CDBE" }));
  f.add(txt(550, 116, "group 2", { size: 12, weight: 800, c: ACC }));
  f.add(txt(550, 150, "B+      B−", { size: 16, weight: 800, c: INK }));
  f.add(txt(380, 186, "sequence  A+  B+  B−  A−   →   groups  [A+ | B+ B− A−]", { size: 11, weight: 700 }));
  /* cascade valves */
  f.add(txt(160, 268, "supply P", { size: 10.5, style: "italic" }));
  f.add(wire([[80, 286], [80, 300], [220, 300]]));
  f.add(arrow(220, 300, 0, { l: 9 }));
  f.add(g(300, 300, 1.2, dcv({ boxes: [{ arrows: [[50, 82, 50, 18]] }, { arrows: [[50, 18, 50, 82]] }], solL: "g2", solR: "g1", portBottom: [{ x: 50, label: "P" }], portTop: [{ x: 50, label: "" }] }), null));
  f.add(wire([[300, 258], [300, 236]]) + arrow(300, 236, -90, { l: 8 }));
  f.add(txt(340, 250, "→ air to group 1 rail", { size: 10, anchor: "start" }));
  f.add(g(480, 300, 1.2, dcv({ boxes: [{ arrows: [[50, 82, 50, 18]] }, { arrows: [[50, 18, 50, 82]] }], solL: "g1", solR: "g2", portBottom: [{ x: 50, label: "P" }], portTop: [{ x: 50, label: "" }] }), null));
  f.add(wire([[480, 258], [480, 236]]) + arrow(480, 236, -90, { l: 8 }));
  f.add(txt(520, 250, "→ air to group 2 rail", { size: 10, anchor: "start" }));
  f.add(txt(380, 370, "a signal lives only while its group is powered — overlaps disappear by design,", { size: 10.5, style: "italic" }));
  f.add(txt(380, 390, "no extra memory valves needed", { size: 10.5, style: "italic" }));
  return f.end();
};

/* ------------------------------------------------------------------ */
figs["fig-pne-timed-pressure.svg"] = () => {
  const f = frame("Time & pressure sequencing without electronics", "time-delay valve = slow fill, fast switch · pressure sequence valve = clamp reached → next step");
  /* time delay */
  f.add(g(190, 150, 1.35, dcv({ boxes: [{ arrows: [[50, 82, 50, 18]] }, { arrows: [[50, 18, 50, 82]] }], pilotL: true, springR: true, portBottom: [{ x: 50, label: "1" }], portTop: [{ x: 50, label: "2" }] }), null));
  f.add(g(100, 236, 1.0, throttle({}), null));
  f.add(circle(100, 300, 22, { w: 2.4 }) + txt(100, 304, "V", { size: 12, weight: 800 }));
  f.add(wire([[100, 212], [100, 190], [148, 190], [148, 160]]) + arrow(148, 158, -90, { l: 7 }));
  f.add(wire([[100, 258], [100, 278]]));
  f.add(txt(100, 342, "resistor + volume + 3/2", { size: 10.5, weight: 700 }));
  /* step chart */
  f.add(rect(280, 100, 180, 110, { rx: 10, fill: "#fff", c: "#D6DEEC", w: 1.3 }));
  f.add(line(300, 180, 300, 120, { w: 1.4, c: SOFT }) + line(300, 180, 444, 180, { w: 1.4, c: SOFT }));
  f.add(path("M302 178 H360 V128 H442", { w: 2.2, c: ACC }));
  f.add(txt(372, 96, "switch point after the delay", { size: 9.5, style: "italic" }));
  f.add(txt(370, 196, "t", { size: 9, c: SOFT }));
  /* pressure sequence */
  f.add(g(580, 150, 1.5, reliefValve({ adjustable: true }), null));
  f.add(rect(660, 130, 50, 26, { rx: 5, w: 1.8, fill: "#F1F5FB" }) + txt(685, 147, "S1", { size: 10, weight: 800, c: BLUE }));
  f.add(wire([[606, 150], [630, 150], [630, 143], [660, 143]], { w: 1.8, dash: "5 4", c: PILOT }));
  f.add(txt(580, 240, "pressure sequence valve:", { size: 10.5, weight: 700 }));
  f.add(txt(580, 258, "clamp pressure reached → contact S1", { size: 9.5, style: "italic" }));
  f.add(txt(580, 274, "releases the next step", { size: 9.5, style: "italic" }));
  f.add(txt(380, 368, "typical pair in clamping: cylinder clamps → pressure rises → S1 starts", { size: 10.5, style: "italic" }));
  f.add(txt(380, 388, "the press — a timer then holds it for the cure time", { size: 10.5, style: "italic" }));
  return f.end();
};

/* ------------------------------------------------------------------ */
figs["fig-pne-service.svg"] = () => {
  const f = frame("Air preparation — clean, dry, right pressure, in that order", "compressor → separator → dryer → filter/regulator — machines die of wet dirty air, not of use");
  const xs = [110, 250, 390, 540];
  f.add(g(xs[0], 170, 1.15, compressor({}), null));
  f.add(txt(xs[0], 236, "compressor", { size: 11, weight: 700 }));
  f.add(g(xs[1], 170, 1.15, filter({}), null));
  f.add(txt(xs[1], 236, "separator / filter", { size: 11, weight: 700 }));
  f.add(txt(xs[1], 254, "water + particles out", { size: 9.5, style: "italic" }));
  f.add(g(xs[2], 170, 1.15, coolerSym(), null));
  f.add(txt(xs[2], 236, "dryer / cooler", { size: 11, weight: 700 }));
  f.add(txt(xs[2], 254, "dew point ↓", { size: 9.5, style: "italic" }));
  f.add(g(xs[3], 170, 0.95, airService({}), null));
  f.add(txt(xs[3], 236, "FRL at the machine", { size: 11, weight: 700 }));
  for (let i = 0; i < 3; i++) { f.add(line(xs[i] + 46, 170, xs[i + 1] - 60, 170, { w: 2.6 }) + arrow(xs[i + 1] - 60, 170, 0, { l: 9 })); }
  f.add(line(xs[3] + 62, 170, 700, 170, { w: 2.6 }) + arrow(704, 170, 0, { l: 9 }));
  f.add(txt(700, 196, "→ machine", { size: 10, weight: 700 }));
  /* rules */
  f.add(line(60, 300, 700, 300, { w: 1.2, c: "#c7d2e3" }));
  f.add(txt(150, 332, "· filter BEFORE regulator", { size: 11 }));
  f.add(txt(150, 354, "· drain the separator daily / auto", { size: 11 }));
  f.add(txt(150, 376, "· lubricator only if a component needs oil-mist (rare)", { size: 10.5, style: "italic" }));
  f.add(txt(500, 332, "wrong order = wet regulators, sticking spools,", { size: 10.5, c: SOFT }));
  f.add(txt(500, 350, "icing at the exhaust and phantom faults", { size: 10.5, c: SOFT }));
  return f.end();
};

/* ------------------------------------------------------------------ */
figs["fig-pne-vacuum.svg"] = () => {
  const f = frame("Vacuum handling — the ejector entreprise", "venturi makes vacuum from shop air; suction cups lift sheets without a single clamp");
  f.add(txt(560, 110, "compressed air in", { size: 10, style: "italic" }));
  f.add(wire([[640, 124], [560, 124]]));
  f.add(arrow(560, 124, 180, { l: 9 }));
  f.add(g(480, 124, 1.4, ejector(), null));
  f.add(g(430, 190, 1.0, muffler()));
  f.add(txt(430, 216, "exhaust", { size: 9, style: "italic" }));
  f.add(wire([[480, 148], [480, 210]]));
  f.add(txt(498, 180, "vacuum", { size: 10.5, weight: 800, c: ACC, anchor: "start" }));
  /* cups + plate */
  f.add(wire([[480, 210], [480, 240], [420, 240]]) + wire([[480, 240], [540, 240]]));
  f.add(path("M408 240 h24 l-4 12 h-16 Z", { w: 2.2 }) + path("M528 240 h24 l-4 12 h-16 Z", { w: 2.2 }));
  f.add(rect(380, 256, 200, 12, { w: 2, fill: "#E8EDF5" }) + txt(480, 266, "sheet stack", { size: 9.5, c: SOFT }));
  f.add(txt(480, 300, "many small cups share the load and forgive leaks", { size: 10, style: "italic" }));
  /* left column: formula + principles */
  f.add(rect(70, 80, 240, 130, { rx: 12, fill: "#fff", c: "#D6DEEC", w: 1.4 }));
  f.add(txt(190, 108, "holding force per cup", { size: 11, weight: 800 }));
  f.add(txt(190, 136, "F = Δp · A", { size: 15, weight: 900, c: INK }));
  f.add(txt(190, 160, "−60 kPa on Ø 40 cup ≈ 75 N", { size: 10 }));
  f.add(txt(190, 182, "safety × 2 vertical · × 4 shear", { size: 9.5, style: "italic", c: ACC }));
  f.add(txt(190, 260, "check valve holds vacuum after a power cut —", { size: 10.5 }));
  f.add(txt(190, 278, "the sheet doesn't become a frisbee", { size: 10.5, style: "italic" }));
  return f.end();
};

/* ============ write out ============ */
if (require.main === module) {
  const fs = require("fs");
  const outDir = process.argv[2] || "/home/user/work/genfigs";
  fs.mkdirSync(outDir, { recursive: true });
  const names = Object.keys(figs);
  names.forEach((name) => {
    let svg;
    try { svg = figs[name](); } catch (e) { console.error("FAIL", name, e.message); process.exitCode = 1; return; }
    fs.writeFileSync(outDir + "/" + name, svg);
  });
  console.log("wrote", names.length, "figures to", outDir);
}
module.exports = { figs };
