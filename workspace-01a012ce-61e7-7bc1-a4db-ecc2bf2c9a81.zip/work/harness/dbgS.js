const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const PKG = "/home/user/work/cad-pkg/rgz-3d-cad-studio";
const vc = new VirtualConsole(); vc.sendTo(console, { omitJSDOMErrors: true });
const dom = new JSDOM("<!DOCTYPE html><html><body></body></html>", { url: "https://houmanrgz.ir/cad/", runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc });
const win = dom.window;
win.HTMLCanvasElement.prototype.getContext = function (k) { return null; };
const t = win.document.createElement("script"); t.textContent = fs.readFileSync(PKG + "/assets/three.min.js", "utf8"); win.document.body.appendChild(t);
const c = win.document.createElement("script"); c.textContent = fs.readFileSync(PKG + "/assets/cad.js", "utf8"); win.document.body.appendChild(c);
const X = win.__rgzcad2;
const s = X.tessLocal({ profiles: [[[0,0],[60,0],[60,45],[0,45]]], holes: [[15,22.5,5,2,0,16,4,90],[45,22.5,5,0,0,12,2,90]], cuts: [[[15,17.5],[45,17.5],[45,27.5],[15,27.5]]], cutDepth: 6, L: 16, bevel: {mode:0,size:0} });
const P = s.positions, N = s.normals;
console.log("tris", P.length/9);
function near(cx, cy, r0, r1, tag){
  let zmin = 1e9, zmax = -1e9, cnt = 0;
  for (let i = 0; i < P.length/9; i++){
    for (let k = 0; k < 3; k++){
      const x = P[i*9+k*3], y = P[i*9+k*3+1], z = P[i*9+k*3+2];
      const rr = Math.hypot(x-cx, y-cy);
      if (rr >= r0 && rr <= r1){ zmin = Math.min(zmin,z); zmax = Math.max(zmax,z); cnt++; }
    }
  }
  console.log(tag, "verts:", cnt, "z range:", zmin.toFixed(3), "..", zmax.toFixed(3));
}
near(45, 22.5, 4.4, 5.6, "right hole wall r5 ");
near(15, 22.5, 4.4, 5.6, "left hole wall r5  ");
near(15, 22.5, 7.4, 8.6, "left cbore wall R8 ");
near(45, 22.5, 0, 5.6, "right hole incl cap ");
// global z extremes
let zmin=1e9,zmax=-1e9; for (let i=0;i<P.length;i+=3){ zmin=Math.min(zmin,P[i+2]); zmax=Math.max(zmax,P[i+2]); }
console.log("GLOBAL z:", zmin, "..", zmax, "(expect 0..16)");
// any verts above 16.01?
let over=0; for (let i=0;i<P.length;i+=3){ if (P[i+2] > 16.01) { over++; if (over<=8) console.log("  z>16 vert:", P[i].toFixed(2), P[i+1].toFixed(2), P[i+2].toFixed(2)); } }
console.log("verts above z=16:", over);
