/* Minimal GIF89a encoder (global palette, looped) — no dependencies. */
"use strict";

function lzwEncode(indices, minCodeSize) {
  const CLEAR = 1 << minCodeSize, EOI = CLEAR + 1;
  let codeSize = minCodeSize + 1, next = EOI + 1;
  let dict = new Map();
  const out = [];
  let cur = 0, curBits = 0;
  function emit(code) {
    cur |= code << curBits;
    curBits += codeSize;
    while (curBits >= 8) { out.push(cur & 0xff); cur >>= 8; curBits -= 8; }
  }
  emit(CLEAR);
  let prefix = indices[0];
  for (let i = 1; i < indices.length; i++) {
    const k = indices[i];
    const key = (prefix << 8) | k;
    if (dict.has(key)) { prefix = dict.get(key); continue; }
    emit(prefix);
    if (next === 4096) {
      emit(CLEAR);
      dict = new Map();
      next = EOI + 1;
      codeSize = minCodeSize + 1;
    } else {
      dict.set(key, next++);
      if (next - 1 === (1 << codeSize) && codeSize < 12) codeSize++;
    }
    prefix = k;
  }
  emit(prefix);
  emit(EOI);
  if (curBits > 0) { out.push(cur & 0xff); }
  return out;
}

/* frames: [{pixels: Uint8Array(w*h), delayCs}]  palette: [[r,g,b],...] */
function encodeGIF(w, h, palette, frames) {
  const palSize = Math.max(2, 1 << Math.ceil(Math.log2(palette.length)));
  const bitsPerPixel = Math.ceil(Math.log2(palSize));
  const minCodeSize = Math.max(2, bitsPerPixel);
  const bytes = [];
  const push = (...b) => bytes.push(...b);
  const push16 = (v) => push(v & 0xff, (v >> 8) & 0xff);
  /* header + LSD */
  push(0x47, 0x49, 0x46, 0x38, 0x39, 0x61); // GIF89a
  push16(w); push16(h);
  push(0x80 | ((bitsPerPixel - 1) << 4) | (bitsPerPixel - 1), 0, 0); // GCT follows
  for (let i = 0; i < palSize; i++) {
    const c = palette[i] || [0, 0, 0];
    push(c[0] & 0xff, c[1] & 0xff, c[2] & 0xff);
  }
  /* NETSCAPE loop */
  push(0x21, 0xff, 0x0b);
  "NETSCAPE2.0".split("").forEach((ch) => push(ch.charCodeAt(0)));
  push(0x03, 0x01, 0x00, 0x00, 0x00);
  /* frames */
  for (const fr of frames) {
    push(0x21, 0xf9, 0x04, 0x04 /* dispose-as-is, no transparency */, 0, 0, 0, 0);
    bytes[bytes.length - 5] = fr.delayCs & 0xff;
    bytes[bytes.length - 4] = (fr.delayCs >> 8) & 0xff;
    push(0x2c);
    push16(0); push16(0); push16(w); push16(h);
    push(0); // no LCT
    push(minCodeSize);
    const data = lzwEncode(fr.pixels, minCodeSize);
    for (let i = 0; i < data.length; i += 255) {
      const chunk = data.slice(i, i + 255);
      push(chunk.length, ...chunk);
    }
    push(0x00);
  }
  push(0x3b);
  return Buffer.from(bytes);
}

module.exports = { encodeGIF };
