// Custom left/right block icon dump
const fs = require("fs"); const { JSDOM, VirtualConsole } = require("jsdom");
const code = fs.readFileSync(process.argv[2], "utf8");
const { window } = new JSDOM(`<!DOCTYPE html><body><div id="rgz-hydraulic-studio"></div><script>${code}<\/script>`, {
  runScripts: "dangerously", pretendToBeVisual: true, url: "https://example.com/",
  virtualConsole: new VirtualConsole(),
  beforeParse(window) {
    window.matchMedia = () => ({ matches: false, addEventListener() {} });
    window.requestAnimationFrame = cb => setTimeout(() => cb(0), 4);
    window.SVGElement.prototype.getBBox = () => ({ x: 0, y: 0, width: 40, height: 12 });
    window.SVGSVGElement.prototype.createSVGPoint = function () { const pt = { x: 0, y: 0 }; pt.matrixTransform = () => pt; return pt; };
    window.SVGSVGElement.prototype.getScreenCTM = window.SVGSVGElement.prototype.getCTM = () => ({ a: 1, b: 0, c: 0, d: 1, e: 0, f: 0, inverse() { return this; }, multiply() { return this; } });
    window.console.warn = () => {};
  }
});
const doc = window.document;
function setProp(field, val) {
  const insp = doc.getElementById("rgz-inspector-panel") || doc;
  const sel = insp.querySelector(`[data-prop-field="${field}"].rgz-property-input`) || insp.querySelector(`[data-prop-field="${field}"]`);
  if (sel) { sel.value = val; sel.dispatchEvent(new window.Event("input", { bubbles: true })); sel.dispatchEvent(new window.Event("change", { bubbles: true })); return sel.value === val; }
  return false;
}
function dump(name) {
  const canvas = doc.getElementById("rgz-canvas");
  const groups = canvas.querySelectorAll("g.rgz-component");
  const g = groups[groups.length - 1];
  const clone = g.cloneNode(true);
  clone.querySelectorAll(".selection-box,.component-label,.port-hit,circle.port,text.port-label").forEach(n => n.remove());
  clone.setAttribute("transform", "");
  fs.writeFileSync(`/home/user/work/render/din/block-${name}.svg`, `<svg xmlns="http://www.w3.org/2000/svg" viewBox="-170 -100 340 200" style="background:#0b1a33">${clone.outerHTML}</svg>`);
  console.log("dumped block-" + name + ".svg");
}
setTimeout(() => {
  const root = doc.getElementById("rgz-hydraulic-studio");
  const cards = [...root.querySelectorAll(".rgz-symbol-card")];
  const dcv = cards.find(c => c.dataset.type === "directionalValve43" || /4\/3/.test(c.textContent));
  dcv.dispatchEvent(new window.MouseEvent("dblclick", { bubbles: true }));
  setTimeout(() => {
    console.log("leftBlock set:", setProp("leftBlock", "regenerative"), "rightBlock set:", setProp("rightBlock", "float"));
    dump("regen-float");
    console.log("leftBlock set:", setProp("leftBlock", "tandem"), "rightBlock set:", setProp("rightBlock", "closed"));
    dump("tandem-closed");
    console.log("leftBlock set:", setProp("leftBlock", "crossover"), "rightBlock set:", setProp("rightBlock", "parallel"));
    dump("cross-par");
    process.exit(0);
  }, 800);
}, 1200);
