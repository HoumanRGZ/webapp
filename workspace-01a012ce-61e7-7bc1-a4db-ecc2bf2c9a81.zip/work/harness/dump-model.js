const fs=require("fs");const{JSDOM,VirtualConsole}=require("jsdom");
const code=fs.readFileSync(process.argv[2],"utf8");
const rootId=process.argv[3]||"rgz-hydraulic-studio";
(async()=>{
 const dom=new JSDOM(`<!DOCTYPE html><body><div id="${rootId}"></div><script>${code}<\/script>`,{
  runScripts:"dangerously",pretendToBeVisual:true,url:"https://example.com/",
  virtualConsole:new VirtualConsole(),
  beforeParse(window){
   window.matchMedia=()=>({matches:false,addEventListener(){}});
   window.URL.createObjectURL=()=>"blob:fake";
   window.Worker=class{constructor(u){this.url=u}postMessage(m){window.__lastWorkerMsg=m}set onmessage(f){}set onerror(f){}terminate(){}};
   window.confirm=()=>true;window.alert=()=>{};window.requestAnimationFrame=cb=>setTimeout(()=>cb(0),5);
   window.SVGElement.prototype.getBBox=()=>({x:0,y:0,width:40,height:12});
   window.console.warn=()=>{};
  }});
 const {window}=dom;await new Promise(r=>setTimeout(r,900));
 const doc=window.document;
 const btn=[...doc.querySelectorAll('[data-action="browse-examples"]')][0];btn.click();
 await new Promise(r=>setTimeout(r,150));
 const lvl=doc.getElementById("rgz-level-selectbox");lvl.value=lvl.options[0].value;lvl.dispatchEvent(new window.Event("change",{bubbles:true}));
 await new Promise(r=>setTimeout(r,250));
 const ex=doc.getElementById("rgz-example-selectbox");ex.value=String(process.argv[4]||"0");ex.dispatchEvent(new window.Event("change",{bubbles:true}));
 await new Promise(r=>setTimeout(r,150));
 doc.querySelector("[data-modal-open-example]").dispatchEvent(new window.MouseEvent("click",{bubbles:true}));
 await new Promise(r=>setTimeout(r,600));
 [...doc.querySelectorAll('[data-action="simulate"]')].forEach(b=>b.click());
 await new Promise(r=>setTimeout(r,300));
 const m=window.__lastWorkerMsg;
 fs.writeFileSync(process.argv[5]||"/tmp/model.json",JSON.stringify(m,null,1));
 console.log("saved",m.components.length,"comps",m.connections.length,"conns; dt=",m.dt);
 process.exit(0);
})();
