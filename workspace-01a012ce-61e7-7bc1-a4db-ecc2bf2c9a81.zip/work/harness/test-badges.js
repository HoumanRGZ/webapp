// End-to-end UI test: per-point readouts from the network solver.
// Deterministic target: Intermediate "Motor start/stop with flow switch"
// example — solenoid off, 4/3 closed center CENTERED: pump deadheads at its
// relief (~160-170), motor stalled (0 rpm), flow meter 0 L/min.
// Regression: the old lumped "solver" showed phantom rpm/flow and every gauge
// in the circuit displayed the global power-pack pressure.
const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const code = fs.readFileSync(process.argv[2], "utf8");

(async () => {
  const vc = new VirtualConsole();
  const errors = [];
  vc.on("jsdomError", (e) => errors.push(String((e && e.detail) || e)));
  const dom = new JSDOM(
    `<!DOCTYPE html><body><div id="rgz-hydraulic-studio"></div><script>${code}<\/script>`,
    {
      runScripts: "dangerously", pretendToBeVisual: true, url: "https://example.com/",
      virtualConsole: vc,
      beforeParse(window) {
        window.matchMedia = () => ({ matches: false, addEventListener() {} });
        // NO window.Worker -> forces the main-thread solver path (also proves fallback)
        window.confirm = () => true; window.alert = () => {};
        window.requestAnimationFrame = (cb) => setTimeout(() => cb(performance.now()), 4);
        window.SVGElement.prototype.getBBox = () => ({ x: 0, y: 0, width: 40, height: 12 });
        window.console.warn = () => {};
      },
    });
  const { window } = dom; const doc = window.document;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  let failures = 0;
  const ok = (cond, name, detail) => {
    if (cond) console.log("  PASS", name, detail ?? "");
    else { failures++; console.log("  FAIL", name, "=>", detail); }
  };
  await sleep(900);

  doc.querySelector('[data-action="browse-examples"]').click();
  await sleep(150);
  const lvl = doc.getElementById("rgz-level-selectbox");
  lvl.value = lvl.options[1].value; // Intermediate
  lvl.dispatchEvent(new window.Event("change", { bubbles: true }));
  await sleep(250);
  const ex = doc.getElementById("rgz-example-selectbox");
  ex.value = ex.options[5].value; // 06 - Motor start/stop with flow switch feedback
  ex.dispatchEvent(new window.Event("change", { bubbles: true }));
  await sleep(100);
  doc.querySelector("[data-modal-open-example]").dispatchEvent(new window.MouseEvent("click", { bubbles: true }));
  await sleep(400);

  [...doc.querySelectorAll('[data-action="simulate"]')].forEach((b) => { if (!b.disabled) b.click(); });
  await sleep(2500);

  const badges = [...doc.querySelectorAll(".rgz-readout-badge")].map((g) => {
    const host = g.parentElement;
    const circ = host && host.querySelector("circle.port");
    const txt = g.querySelector(".rgz-readout-text");
    return { comp: circ ? circ.getAttribute("data-component-id") : "?", text: txt ? txt.textContent : "" };
  });
  ok(badges.length >= 3, "live readout badges rendered", badges.length);
  badges.forEach((b) => console.log("   badge", b.comp.padEnd(8), "=", b.text));
  const find = (id) => badges.find((b) => b.comp === id);
  const num = (s) => parseFloat(String(s).replace(/[^\d.-]/g, ""));

  const hpu = find("HPU-1"), mot = find("M-5"), fs6 = find("FS-6");
  ok(!!hpu && !!mot && !!fs6, "power pack, motor and flow switch badges present");
  if (hpu) ok(Math.abs(num(hpu.text) - 160) < 15, "HPU deadheads at its relief setting", hpu.text);
  if (mot) ok(Math.abs(num(mot.text)) < 0.5, "motor behind closed-center valve is stalled (0 rpm)", mot.text);
  if (fs6) ok(Math.abs(num(fs6.text)) < 0.5, "flow meter reads 0 L/min through the closed valve", fs6.text);

  ok(/running/i.test(doc.getElementById("rgz-sim-status").textContent), "sim status running");
  ok(errors.length === 0, "no jsdom errors during run", errors.join(" | ").slice(0, 200));

  console.log(failures ? `\n${failures} FAILURES` : "\nALL UI BADGE TESTS PASSED");
  process.exit(failures ? 1 : 0);
})();
