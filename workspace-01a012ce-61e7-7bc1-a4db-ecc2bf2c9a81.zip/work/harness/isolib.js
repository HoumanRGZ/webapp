/* ISO 1219-1 / DIN ISO 1219 symbol library → SVG fragments.
   Symbols draw centred at local (0,0) with port stubs included; place with g(x,y,s). */
"use strict";

const INK = "#1f2937", SOFT = "#475569", ACC = "#eb4e3c", BLUE = "#2563eb", FILL = "#ffffff", PILOT = "#7c3aed";

function esc(s) { return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;"); }
function n(v) { return Math.round(v * 100) / 100; }

function line(x1, y1, x2, y2, o = {}) {
  const dash = o.dash ? ` stroke-dasharray="${o.dash}"` : "";
  return `<line x1="${n(x1)}" y1="${n(y1)}" x2="${n(x2)}" y2="${n(y2)}" stroke="${o.c || INK}" stroke-width="${o.w || 2.4}" stroke-linecap="round"${dash}/>`;
}
function path(d, o = {}) {
  const dash = o.dash ? ` stroke-dasharray="${o.dash}"` : "";
  return `<path d="${d}" stroke="${o.c || INK}" stroke-width="${o.w || 2.4}" fill="${o.fill || "none"}" stroke-linecap="round" stroke-linejoin="round"${dash}/>`;
}
function rect(x, y, w, h, o = {}) {
  const dash = o.dash ? ` stroke-dasharray="${o.dash}"` : "";
  return `<rect x="${n(x)}" y="${n(y)}" width="${n(w)}" height="${n(h)}" rx="${o.rx || 0}" fill="${o.fill === undefined ? FILL : o.fill}" stroke="${o.c || INK}" stroke-width="${o.w === undefined ? 2.2 : o.w}"${dash}/>`;
}
function circle(cx, cy, r, o = {}) {
  return `<circle cx="${n(cx)}" cy="${n(cy)}" r="${n(r)}" fill="${o.fill === undefined ? FILL : o.fill}" stroke="${o.c || INK}" stroke-width="${o.w === undefined ? 2.2 : o.w}"/>`;
}
function txt(x, y, s, o = {}) {
  return `<text x="${n(x)}" y="${n(y)}" text-anchor="${o.anchor || "middle"}" font-family="${o.mono ? "Consolas,Menlo,monospace" : "system-ui,Segoe UI,Arial,sans-serif"}" font-size="${o.size || 12}" fill="${o.c || SOFT}" font-weight="${o.weight || 600}"${o.style ? ` font-style="${o.style}"` : ""}${o.ls ? ` letter-spacing="${o.ls}"` : ""}>${esc(s)}</text>`;
}
function arrow(x, y, angDeg, o = {}) {
  const a = (angDeg * Math.PI) / 180, L = o.l || 9, w = o.open == null ? 0.42 : o.open;
  const dx = Math.cos(a), dy = Math.sin(a);
  const p1 = [x, y], p2 = [x - L * dx - L * w * dy, y - L * dy + L * w * dx], p3 = [x - L * dx + L * w * dy, y - L * dy - L * w * dx];
  return `<path d="M${n(p1[0])} ${n(p1[1])} L${n(p2[0])} ${n(p2[1])} L${n(p3[0])} ${n(p3[1])} Z" fill="${o.c || INK}"/>`;
}
function spring(x1, y1, x2, y2, o = {}) {
  const dx = x2 - x1, dy = y2 - y1, len = Math.hypot(dx, dy) || 1;
  const ux = dx / len, uy = dy / len, px = -uy, py = ux;
  const lead = 4, amp = o.amp || 4, teeth = o.teeth || 4, usable = len - 2 * lead;
  let d = `M${n(x1)} ${n(y1)} L${n(x1 + ux * lead)} ${n(y1 + uy * lead)}`;
  for (let i = 0; i < teeth * 2 - 1; i++) {
    const t = lead + ((i + 0.5) / (teeth * 2 - 1)) * usable;
    const side = i % 2 === 0 ? 1 : -1;
    d += ` L${n(x1 + ux * t + px * amp * side)} ${n(y1 + uy * t + py * amp * side)}`;
  }
  d += ` L${n(x1 + ux * (lead + usable))} ${n(y1 + uy * (lead + usable))} L${n(x2)} ${n(y2)}`;
  return path(d, { w: o.w || 2, c: o.c || INK });
}
function solenoid(cx, cy, o = {}) {
  const w = o.w || 16, h = o.h || 11;
  return rect(cx - w / 2, cy - h / 2, w, h, { w: 2 }) + line(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2, { w: 1.5 });
}
function solidTri(cx, cy, size, angDeg, o = {}) {
  const a = (angDeg * Math.PI) / 180, s = size;
  const tip = [cx + (s / 2) * Math.cos(a), cy + (s / 2) * Math.sin(a)];
  const b1 = [cx - (s / 2) * Math.cos(a) - (s / 3) * Math.sin(a), cy - (s / 2) * Math.sin(a) + (s / 3) * Math.cos(a)];
  const b2 = [cx - (s / 2) * Math.cos(a) + (s / 3) * Math.sin(a), cy - (s / 2) * Math.sin(a) - (s / 3) * Math.cos(a)];
  return `<path d="M${n(tip[0])} ${n(tip[1])} L${n(b1[0])} ${n(b1[1])} L${n(b2[0])} ${n(b2[1])} Z" fill="${o.hollow ? "none" : o.fill || INK}" stroke="${o.c || INK}" stroke-width="${o.hollow ? 2 : 0}" stroke-linejoin="round"/>`;
}
function adjArrow(x1, y1, x2, y2, o = {}) {
  const dx = x2 - x1, dy = y2 - y1;
  return line(x1, y1, x2 - dx * 0.14, y2 - dy * 0.14, { w: 2.1, c: o.c || INK }) +
    arrow(x2, y2, (Math.atan2(dy, dx) * 180) / Math.PI, { l: 10, c: o.c || INK });
}

/* wrap: place symbol string at x,y with scale + optional caption */
function g(x, y, s, inner, caption, o = {}) {
  let out = `<g transform="translate(${n(x)} ${n(y)}) scale(${n(s || 1)})">${inner}</g>`;
  if (caption) out += txt(x, y + (o.capDy || 52), caption, { size: o.capSize || 12.5, c: o.capC || INK, weight: 700 });
  return out;
}

/* ============ symbols ============ */
/* circle machines: port stubs included (P top, T bottom for pumps) */
function pump(o = {}) {
  const r = o.r || 19;
  return circle(0, 0, r, { w: 3 }) +
    solidTri(0, -r * 0.42, r * 0.85, -90) +
    (o.twoDir ? solidTri(0, r * 0.42, r * 0.85, 90) : "") +
    (o.variable ? adjArrow(-r * 1.15, r * 1.05, r * 1.12, -r * 1.1) : "") +
    line(0, r, 0, r + 24, { w: 3 }) + line(0, -r, 0, -r - 24, { w: 3 });
}
function pumpWithMotor(o = {}) {
  const r = o.r || 18;
  return rect(-r - 54, -12, 36, 24, { rx: 3 }) + txt(-r - 36, 4, "M", { size: 13, weight: 800, c: INK }) +
    line(-r - 18, 0, -r, 0, { w: 3 }) +
    circle(0, 0, r, { w: 3 }) + solidTri(0, -r * 0.42, r * 0.85, -90) +
    (o.variable ? adjArrow(-r * 1.15, r * 1.05, r * 1.12, -r * 1.1) : "") +
    line(0, r, 0, r + 24, { w: 3 }) + line(0, -r, 0, -r - 24, { w: 3 });
}
function hydMotor(o = {}) {
  const r = o.r || 19;
  return circle(0, 0, r, { w: 3 }) +
    solidTri(0, -r * 0.42, r * 0.85, 90) +
    (o.twoDir ? solidTri(0, r * 0.42, r * 0.85, -90) : "") +
    (o.variable ? adjArrow(-r * 1.15, r * 1.05, r * 1.12, -r * 1.1) : "") +
    line(-r, 0, -r - 22, 0, { w: 3 }) + line(r, 0, r + 22, 0, { w: 3 }) +
    line(0, -r, 0, -r - 13, { w: 3 }) + line(-5, -r - 13, 5, -r - 13, { w: 3 });
}
function compressor(o = {}) {
  const r = o.r || 19;
  return circle(0, 0, r, { w: 3 }) + solidTri(0, -r * 0.42, r * 0.85, -90, { hollow: true }) +
    line(0, r, 0, r + 24, { w: 3 }) + line(0, -r, 0, -r - 24, { w: 3 });
}
function airMotor(o = {}) {
  const r = o.r || 19;
  return circle(0, 0, r, { w: 3 }) + solidTri(0, -r * 0.42, r * 0.85, 90, { hollow: true }) +
    (o.twoDir ? solidTri(0, r * 0.42, r * 0.85, -90, { hollow: true }) : "") +
    line(-r, 0, -r - 22, 0, { w: 3 }) + line(r, 0, r + 22, 0, { w: 3 }) +
    line(0, -r, 0, -r - 13, { w: 3 }) + line(-5, -r - 13, 5, -r - 13, { w: 3 });
}
function pressureGauge(o = {}) {
  const r = o.r || 13;
  return circle(0, 0, r, { w: 2.4 }) + line(0, 0, r * 0.52, -r * 0.6, { w: 2, c: ACC }) +
    circle(0, 0, 1.7, { fill: INK, w: 0 }) + line(0, r, 0, r + (o.stub == null ? 18 : o.stub), { w: 2.4 });
}
/* reservoir — open top; stub enters from above */
function tank(o = {}) {
  const w = o.w || 36, h = o.h || 16;
  return path(`M${-w / 2} 0 V${h} H${w / 2} V0`, { w: 2.6 }) + line(0, -18, 0, 0, { w: 3 });
}
function pneExhaust() { // silencer-ish exhaust triangle (outlet to atmosphere)
  return `<path d="M-9 8 H9 L0 -6 Z" fill="none" stroke="${INK}" stroke-width="2.2" stroke-linejoin="round"/>` + line(0, 8, 0, 20, { w: 0, c: "none" });
}

/* cylinders */
function cylDA(o = {}) {
  const W = o.W || 76, H = o.H || 30;
  let out = rect(-W / 2, -H / 2, W, H, { w: 3 });
  out += rect(-W / 2 + 15, -H / 2, 5, H, { fill: INK, w: 0 });
  out += line(-W / 2 + 20, 0, W / 2 + 28, 0, { w: 4 });
  out += line(-W / 2, -H / 4, -W / 2 - 20, -H / 4, { w: 3 });
  out += line(-W / 2, H / 4, -W / 2 - 20, H / 4, { w: 3 });
  if (o.cushion) out += rect(W / 2 - 16, -5, 7, 10, { w: 1.8, fill: "none" }) + rect(W / 2 - 4, -2.5, 4, 5, { w: 1.8, fill: "none" });
  return out;
}
function cylSA(o = {}) {
  const W = 68, H = 30;
  return rect(-W / 2, -H / 2, W, H, { w: 3 }) +
    rect(-W / 2 + 15, -H / 2, 5, H, { fill: INK, w: 0 }) +
    line(-W / 2 + 20, 0, W / 2 + 24, 0, { w: 4 }) +
    spring(-2, 0, 20, 0, { amp: 3.4, teeth: 3 }) +
    line(-W / 2, 0, -W / 2 - 20, 0, { w: 3 });
}
function telescopic() {
  return rect(-34, -16, 26, 32, { w: 2.6 }) + rect(-8, -11, 22, 22, { w: 2.6 }) +
    rect(14, -6, 18, 12, { w: 2.6 }) + line(32, 0, 46, 0, { w: 3.4 }) + line(-34, 4, -52, 4, { w: 3 });
}
function rodless() {
  return rect(-42, -9, 84, 18, { rx: 9, w: 3 }) + line(-30, 0, 30, 0, { w: 1.7, dash: "5 4" }) +
    rect(-8, -16, 16, 13, { w: 2.3 }) + line(-42, 4, -60, 4, { w: 3 }) + line(42, 4, 60, 4, { w: 3 });
}

/* generic spool-valve builder */
function dcv(spec) {
  const bw = spec.bw || 28, bh = spec.bh || 32, P = spec.boxes.length;
  const attach = spec.attach == null ? (P >= 3 ? 1 : 0) : spec.attach;   // ports on rest position
  const total = P * bw, x0 = -total / 2, yT = -bh / 2, yB = bh / 2;
  const ax0 = x0 + attach * bw;
  const py = (v) => yT + (v / 100) * bh;
  let out = "";
  for (let i = 0; i < P; i++) {
    const bx = x0 + i * bw;
    out += rect(bx, yT, bw, bh, { w: 2.4 });
    const b = spec.boxes[i] || {};
    (b.arrows || []).forEach((a) => {
      const x1 = bx + (a[0] / 100) * bw, y1 = py(a[1]), x2 = bx + (a[2] / 100) * bw, y2 = py(a[3]);
      out += line(x1, y1, x2 - Math.sign(x2 - x1 || 1) * 0, y2, { w: 2.1 }) + arrow(x2, y2, (Math.atan2(y2 - y1, x2 - x1) * 180) / Math.PI, { l: 8, open: 0.5 });
    });
    (b.closed || []).forEach((cp) => { out += line(bx + (cp[0] / 100) * bw - 4, py(cp[1]), bx + (cp[0] / 100) * bw + 4, py(cp[1]), { w: 2.6 }); });
  }
  if (spec.solL) { out += solenoid(x0 - 10, 0) + line(x0 - 2, 0, x0, 0, { w: 2 }); if (spec.solL !== true) out += txt(x0 - 20, 4, spec.solL, { size: 11, c: BLUE, weight: 800, anchor: "end" }); }
  if (spec.solR) { out += solenoid(x0 + total + 10, 0) + line(x0 + total, 0, x0 + total + 2, 0, { w: 2 }); if (spec.solR !== true) out += txt(x0 + total + 20, 4, spec.solR, { size: 11, c: BLUE, weight: 800, anchor: "start" }); }
  if (spec.springL) out += spring(x0 - (spec.solL ? 18 : 0) - 2, 0, x0 - (spec.solL ? 18 : 0) - 24, 0);
  if (spec.springR) out += spring(x0 + total + (spec.solR ? 18 : 0) + 2, 0, x0 + total + (spec.solR ? 18 : 0) + 24, 0);
  if (spec.pilotL) out += line(x0 - 2, -8, x0 - 2, 8, { w: 2 }) + `<path d="M${n(x0 - 2)} ${n(-8)} L${n(x0 - 14)} 0 L${n(x0 - 2)} 8 Z" fill="none" stroke="${INK}" stroke-width="1.8"/>`;
  if (spec.pilotR) out += line(x0 + total + 2, -8, x0 + total + 2, 8, { w: 2 }) + `<path d="M${n(x0 + total + 2)} ${n(-8)} L${n(x0 + total + 14)} 0 L${n(x0 + total + 2)} 8 Z" fill="none" stroke="${INK}" stroke-width="1.8"/>`;
  if (spec.proportional) { out += line(x0, yT - 6, x0 + total, yT - 6, { w: 1.5 }) + line(x0, yB + 6, x0 + total, yB + 6, { w: 1.5 }); }
  if (spec.detents) for (let i = 1; i < P; i++) out += `<path d="M${n(x0 + i * bw)} ${n(yB)} l-3 5 6 0 Z" fill="${INK}"/>`;
  (spec.portTop || []).forEach((pl) => {
    const px = ax0 + (pl.x / 100) * bw;
    out += line(px, yT, px, yT - (pl.len || 18), { w: 2.6 });
    if (pl.label) out += txt(px, yT - (pl.len || 18) - 6, pl.label, { size: pl.size || 12, c: INK, weight: 800 });
  });
  (spec.portBottom || []).forEach((pl) => {
    const px = ax0 + (pl.x / 100) * bw;
    out += line(px, yB, px, yB + (pl.len || 18), { w: 2.6 });
    if (pl.label) out += txt(px, yB + (pl.len || 18) + 13, pl.label, { size: pl.size || 12, c: INK, weight: 800 });
  });
  return out;
}

/* pressure valves */
function reliefValve(o = {}) {
  /* box with internal diagonal arrow (inlet→outlet), dashed pilot from inlet to left side,
     spring on right side (adjustable), ports: P in from left-bottom path, T out right */
  const bw = o.bw || 26, bh = o.bh || 26;
  let out = rect(-bw / 2, -bh / 2, bw, bh, { w: 2.4 });
  out += line(-7, 9, 3, -5, { w: 2.1 }) + arrow(6, -8, -45, { l: 8, open: 0.55 });  // internal arrow
  out += spring(bw / 2 + 2, 0, bw / 2 + 24, 0);
  if (o.adjustable !== false) out += adjArrow(bw / 2 + 18, 12, bw / 2 + 32, 0);
  /* dashed pilot taken from the inlet line (bottom), routed up the left side */
  out += path(`M${-bw / 2 - 10} ${bh / 2 + 16} H${-bw / 2 - 20} V0 H${-bw / 2}`, { w: 1.8, dash: "5 4", c: PILOT });
  out += line(0, -bh / 2, 0, -bh / 2 - 18, { w: 3 });          // outlet up (to tank)
  out += line(-bw / 2 - 10, bh / 2 + 16, 4, bh / 2 + 16, { w: 3 }); // inlet bottom
  out += line(0, bh / 2, 0, bh / 2 + 16, { w: 3 });
  return out;
}
function reducingValve(o = {}) {
  const bw = 26, bh = 26;
  let out = rect(-bw / 2, -bh / 2, bw, bh, { w: 2.4 });
  out += line(-7, 9, 3, -5, { w: 2.1 }) + arrow(6, -8, -45, { l: 8, open: 0.55 });
  out += spring(bw / 2 + 2, 0, bw / 2 + 24, 0);
  out += adjArrow(bw / 2 + 18, 12, bw / 2 + 32, 0);
  /* pilot taken from OUTLET (top) */
  out += path(`M${bw / 2 + 40} ${-bh / 2 - 14} V0 H${bw / 2}`, { w: 1.8, dash: "5 4", c: PILOT });
  out += line(0, -bh / 2, 0, -bh / 2 - 18, { w: 3 });
  out += line(0, bh / 2, 0, bh / 2 + 18, { w: 3 });
  return out;
}
function checkValve(o = {}) {
  let out = circle(-4, 0, 6, { w: 2.2 });
  out += path(`M4 -7 L4 7`, { w: 2.2 });
  out += line(-2, -4.5, 4, -7, { w: 2.2 }) + line(-2, 4.5, 4, 7, { w: 2.2 });
  out += line(-20, 0, -10, 0, { w: 3 }) + line(4, 0, 20, 0, { w: 3 });
  if (o.springLoaded) out += spring(4, 0, 14, 0, { amp: 2.6, teeth: 3, w: 1.6 });
  if (o.piloted) {
    out += line(-4, 8, -4, 22, { w: 1.8, dash: "5 4", c: PILOT });
    out += `<path d="M-10 22 h12" stroke="${PILOT}" stroke-width="1.8"/>`;
  }
  return out;
}
function shuttleValve(o = {}) { // OR — two seats, free ball, outlet down
  let out = path(`M-13 -7 Q-7 0 -13 7`, { w: 2.2 });
  out += path(`M13 -7 Q7 0 13 7`, { w: 2.2 });
  out += circle(0, 0, 4.6, { w: 2.2 });
  out += line(-24, 0, -13, 0, { w: 3 }) + line(24, 0, 13, 0, { w: 3 }) + line(0, 24, 0, 5, { w: 3 });
  return out;
}
function andValve() { // dual-pressure (AND): box with both input triangles meeting a poppet
  let out = rect(-14, -9, 28, 18, { w: 2.2, rx: 2 });
  out += `<path d="M-14 0 h7 M14 0 h-7" stroke="${INK}" stroke-width="2.2"/>`;
  out += `<path d="M7 -5 l-7 5 7 5 Z" fill="none" stroke="${INK}" stroke-width="2" stroke-linejoin="round"/>`;
  out += line(-24, 0, -14, 0, { w: 3 }) + line(24, 0, 14, 0, { w: 3 }) + line(0, 24, 0, 9, { w: 3 });
  return out;
}
function throttle(o = {}) { // adjustable throttle: two arcs facing each other
  let out = path(`M-10 -12 Q-2 0 -10 12`, { w: 2.4 }) + path(`M10 -12 Q2 0 10 12`, { w: 2.4 });
  out += line(-22, 0, -10, 0, { w: 3 }) + line(10, 0, 22, 0, { w: 3 });
  if (o.adjustable !== false) out += adjArrow(-16, 14, 14, -14);
  return out;
}
function oneWayFlowControl(o = {}) {
  /* adjustable throttle on the main line with a free-flow check branch below */
  let out = path(`M-9 -11 Q-2 0 -9 11`, { w: 2.2 }) + path(`M5 -11 Q-2 0 5 11`, { w: 2.2 });
  out += adjArrow(-16, 14, 11, -14);
  out += line(-26, 0, -9, 0, { w: 3 }) + line(5, 0, 26, 0, { w: 3 });
  out += line(-2, 0, -2, 21, { w: 2 }) + line(5, 0, 5, 21, { w: 2 });
  out += circle(1.5, 24, 4.4, { w: 1.9 });
  out += path(`M7.5 19.5 L7.5 28.5`, { w: 1.9 });
  out += line(-2, 24, 5, 24, { w: 0 });
  if (o.box !== false) out += rect(-22, -19, 50, 54, { rx: 4, w: 1.7, fill: "none", c: SOFT, dash: "6 4" });
  return out;
}
function filter(o = {}) {
  let out = `<path d="M0 -14 L16 10 H-16 Z" fill="${FILL}" stroke="${INK}" stroke-width="2.4" stroke-linejoin="round"/>`;
  out += line(-10, -1, 10, -1, { w: 1.8, dash: "3 3" });
  out += line(0, -14, 0, -30, { w: 3 }) + line(0, 10, 0, 24, { w: 3 });
  return out; // ISO filter = inverted triangle with dashed mesh line
}
function coolerSym() {
  return `<path d="M-15 -15 H15 V15 H-15 Z M-8 -8 L8 8 M8 -8 L-8 8" fill="${FILL}" stroke="${INK}" stroke-width="2.2"/>` +
    adjArrow(-20, 18, 20, -18) + line(0, -15, 0, -26, { w: 3 }) + line(0, 15, 0, 26, { w: 3 });
}
function accumulator(o = {}) {
  const r = 17;
  let out = circle(0, 0, r, { w: 2.6 });
  out += `<path d="M${-r + 2} ${-6} A14 14 0 0 0 ${-r + 2} 6" fill="none" stroke="${INK}" stroke-width="2.2"/>`;
  out += txt(5, -3, "N₂", { size: 10, c: SOFT, weight: 700 }) + txt(6, 8, "gas", { size: 8, c: SOFT });
  out += line(0, r, 0, r + 20, { w: 3 });
  return out;
}
function ejector() { // vacuum ejector (venturi)
  let out = `<path d="M-26 -8 L6 -8 L14 -2 L26 -2 L26 2 L14 2 L6 8 L-26 8 Z" fill="${FILL}" stroke="${INK}" stroke-width="2.2" stroke-linejoin="round"/>`;
  out += line(0, 8, 0, 22, { w: 3 }) + txt(9, 20, "vac", { size: 9, anchor: "start" });
  return out;
}

module.exports = {
  INK, SOFT, ACC, BLUE, FILL, PILOT,
  esc, n, line, path, rect, circle, txt, arrow, spring, solenoid, solidTri, adjArrow, g, dcv,
  pump, pumpWithMotor, hydMotor, compressor, airMotor, pressureGauge, tank, pneExhaust,
  cylDA, cylSA, telescopic, rodless, reliefValve, reducingValve, checkValve, shuttleValve, andValve,
  throttle, oneWayFlowControl, filter, coolerSym, accumulator, ejector,
};

/* --- pneumatic service-unit parts --- */
function airService(o = {}) {
  /* combined filter+regulator+lubricator (FRL) in one dashed box */
  let out = "";
  // filter (triangle) with water drain
  out += `<path d="M-34 -10 L-20 8 H-48 Z" fill="${FILL}" stroke="${INK}" stroke-width="2.2" stroke-linejoin="round"/>`;
  out += line(-40, -3, -28, -3, { w: 1.6, dash: "3 3" });
  out += line(-34, 8, -34, 14, { w: 2 });
  // pressure regulator: box with arrow + spring
  out += rect(-14, -10, 22, 20, { w: 2.2 });
  out += line(-10, 6, -1, -4, { w: 1.8 }) + arrow(0, -5, -60, { l: 6, open: 0.6 });
  out += spring(8, 0, 20, 0, { amp: 2.8, teeth: 3, w: 1.6 });
  if (o.lubricator !== false) {
    out += rect(26, -10, 20, 20, { rx: 3, w: 2.2 });
    out += `<path d="M36 -2 q-4 6 0 8 q4 -2 0 -8" fill="none" stroke="${INK}" stroke-width="1.8"/>`;
  }
  out += line(-52, 0, -48, 0, { w: 3 }) + line(-20, 0, -14, 0, { w: 3 }) + line(8, 0, 26, 0, { w: 3 }) + line(46, 0, 56, 0, { w: 3 });
  out += rect(-56, -18, 118, 40, { rx: 5, w: 1.6, fill: "none", c: SOFT, dash: "6 4" });
  return out;
}
function muffler() { // exhaust silencer triangle
  return `<path d="M-10 10 H10 L0 -6 Z" fill="none" stroke="${INK}" stroke-width="2.2" stroke-linejoin="round"/>` +
    `<path d="M-4 4 h2 M2 4 h2 M-1 0 h2" stroke="${SOFT}" stroke-width="1.4"/>`;
}
function quickExhaust(o = {}) {
  let out = rect(-15, -11, 30, 22, { rx: 3, w: 2.2 });
  out += `<path d="M-8 -4 L0 0 L8 -4 M-8 4 L0 8 L8 4" fill="none" stroke="${INK}" stroke-width="1.8"/>`;
  out += line(-25, 0, -15, 0, { w: 3 }) + line(0, 24, 0, 11, { w: 3 });
  out += `<path d="M18 -6 H32 L25 6 Z" fill="none" stroke="${INK}" stroke-width="2" stroke-linejoin="round"/>`;
  out += line(15, 0, 18, 0, { w: 2.4 });
  return out;
}
module.exports.airService = airService;
module.exports.muffler = muffler;
module.exports.quickExhaust = quickExhaust;
