const fs=require("fs");const{JSDOM,VirtualConsole}=require("jsdom");
const code=fs.readFileSync(process.argv[2],"utf8");
const rootId=process.argv[3]||"rgz-hydraulic-studio";
(async()=>{
 const dom=new JSDOM(`<!DOCTYPE html><body><div id="${rootId}"></div><script>${code}<\/script>`,{
  runScripts:"dangerously",pretendToBeVisual:true,url:"https://example.com/",
  virtualConsole:new VirtualConsole(),
  beforeParse(window){
   window.matchMedia=()=>({matches:false,addEventListener(){}});
   window.URL.createObjectURL=()=>"blob:fake";
   window.Worker=class{constructor(u){this.url=u}postMessage(m){window.__lastWorkerMsg=m}set onmessage(f){}set onerror(f){}terminate(){}};
   window.confirm=()=>true;window.alert=()=>{};window.requestAnimationFrame=cb=>setTimeout(()=>cb(0),5);
   window.SVGElement.prototype.getBBox=()=>({x:0,y:0,width:40,height:12});
   window.console.warn=()=>{};
  }});
 const {window}=dom;await new Promise(r=>setTimeout(r,900));
 const doc=window.document;
 const btn=[...doc.querySelectorAll('[data-action="browse-examples"]')][0];btn.click();
 await new Promise(r=>setTimeout(r,150));
 for(let li=0;li<3;li++){
  const lvl=doc.getElementById("rgz-level-selectbox");
  if(!lvl){console.log("no level selectbox");break}
  if(li>=lvl.options.length)break;
  lvl.value=lvl.options[li].value;lvl.dispatchEvent(new window.Event("change",{bubbles:true}));
  await new Promise(r=>setTimeout(r,250));
  const ex=doc.getElementById("rgz-example-selectbox");
  console.log("LEVEL",li,lvl.options[li].textContent);
  [...ex.options].forEach(o=>console.log("   ",o.value,o.textContent));
 }
 process.exit(0);
})();
