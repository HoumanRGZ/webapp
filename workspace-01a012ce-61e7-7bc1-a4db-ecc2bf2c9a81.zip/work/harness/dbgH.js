const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const PKG = "/home/user/work/cad-pkg/rgz-3d-cad-studio";
const vc = new VirtualConsole(); vc.sendTo(console, { omitJSDOMErrors: true });
const dom = new JSDOM("<!DOCTYPE html><html><body></body></html>", { url: "https://houmanrgz.ir/cad/", runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc });
const win = dom.window;
win.HTMLCanvasElement.prototype.getContext = function (k) { return null; };
const t = win.document.createElement("script"); t.textContent = fs.readFileSync(PKG + "/assets/three.min.js", "utf8"); win.document.body.appendChild(t);
const c = win.document.createElement("script"); c.textContent = fs.readFileSync(PKG + "/assets/cad.js", "utf8"); win.document.body.appendChild(c);
const X = win.__rgzcad2;
const s = X.tessLocal({ profiles: [[[0,0],[60,0],[60,45],[0,45]]], holes: [], cuts: [[[15,17.5],[45,17.5],[45,27.5],[15,27.5]]], cutDepth: 6, L: 16, bevel: {mode:0,size:0} });
const P = s.positions, N = s.normals;
for (let i = 0; i < P.length/9; i++){
  const l = Math.hypot(N[i*9], N[i*9+1], N[i*9+2]).toFixed(3);
  const v0 = [P[i*9],P[i*9+1],P[i*9+2]].map(v=>+v.toFixed(2));
  console.log(i, "len", l, "v0", JSON.stringify(v0), "n", [N[i*9],N[i*9+1],N[i*9+2]].map(v=>+v.toFixed(2)).join(","));
}
