// Renders an example circuit canvas to SVG+PNG: node render-example.js <bundle> <rootId> <exIdx> <out-prefix> <lvlIdx>
const fs=require("fs");const{JSDOM,VirtualConsole}=require("jsdom");
const {Resvg}=require("@resvg/resvg-js");
const code=fs.readFileSync(process.argv[2],"utf8");
const rootId=process.argv[3]||"rgz-hydraulic-studio";
(async()=>{
 const dom=new JSDOM(`<!DOCTYPE html><body><div id="${rootId}"></div><script>${code}<\/script>`,{
  runScripts:"dangerously",pretendToBeVisual:true,url:"https://example.com/",
  virtualConsole:new VirtualConsole(),
  beforeParse(window){
   window.matchMedia=()=>({matches:false,addEventListener(){}});
   window.URL.createObjectURL=()=>"blob:fake";
   window.Worker=class{constructor(u){this.url=u}postMessage(m){window.__lastWorkerMsg=m}set onmessage(f){}set onerror(f){}terminate(){}};
   window.confirm=()=>true;window.alert=()=>{};window.requestAnimationFrame=cb=>setTimeout(()=>cb(0),5);
   window.SVGElement.prototype.getBBox=()=>({x:0,y:0,width:40,height:12});
   window.console.warn=()=>{};
  }});
 const {window}=dom;await new Promise(r=>setTimeout(r,900));
 const doc=window.document;
 const btn=[...doc.querySelectorAll('[data-action="browse-examples"]')][0];btn.click();
 await new Promise(r=>setTimeout(r,150));
 const lvl=doc.getElementById("rgz-level-selectbox");lvl.value=lvl.options[Number(process.argv[6]||0)].value;lvl.dispatchEvent(new window.Event("change",{bubbles:true}));
 await new Promise(r=>setTimeout(r,250));
 const ex=doc.getElementById("rgz-example-selectbox");ex.value=String(process.argv[4]||"0");ex.dispatchEvent(new window.Event("change",{bubbles:true}));
 await new Promise(r=>setTimeout(r,150));
 doc.querySelector("[data-modal-open-example]").dispatchEvent(new window.MouseEvent("click",{bubbles:true}));
 await new Promise(r=>setTimeout(r,800));
 const svg=[...doc.querySelectorAll(`#${rootId} svg`)].sort((a,b)=>b.outerHTML.length-a.outerHTML.length)[0];
 if(!svg){console.log("NO SVG FOUND");process.exit(1)}
 svg.setAttribute("xmlns","http://www.w3.org/2000/svg");
 // plugin css with var() resolved
 let css=fs.readFileSync("/home/user/work/extracted/rgz-engineering-studio/assets/app.css","utf8");
 const vars={};
 const propRe=/--([A-Za-z0-9-]+)\s*:\s*([^;]+);/g;let pm;
 while((pm=propRe.exec(css))){vars["--"+pm[1]]=pm[2].trim()}
 for(let i=0;i<4;i++){css=css.replace(/var\(\s*(--[A-Za-z0-9-]+)\s*(?:,\s*([^)]*))?\)/g,(m,n,f)=>vars[n]||(f!==undefined?f:m))}
 const st=window.document.createElementNS("http://www.w3.org/2000/svg","style");
 st.textContent=css;
 svg.insertBefore(st,svg.firstChild);
 const bg=window.document.createElementNS("http://www.w3.org/2000/svg","rect");
 bg.setAttribute("x","-4000");bg.setAttribute("y","-4000");bg.setAttribute("width","9000");bg.setAttribute("height","9000");bg.setAttribute("fill","#0b1526");
 svg.insertBefore(bg,st.nextSibling);
 const prefix=process.argv[5]||"out/circuit";
 fs.writeFileSync(prefix+".svg",svg.outerHTML);
 const r=new Resvg(svg.outerHTML,{font:{fontFiles:[],loadSystemFonts:true,defaultFontFamily:"sans-serif"}});
 fs.writeFileSync(prefix+".png",r.render().asPng());
 const comps=[...svg.querySelectorAll("g.rgz-component")].map(g=>`${g.getAttribute("data-id")} @ ${g.getAttribute("transform")}`).join("; ");
 console.log("saved",prefix+".png","comps:",comps);
 process.exit(0);
})();
