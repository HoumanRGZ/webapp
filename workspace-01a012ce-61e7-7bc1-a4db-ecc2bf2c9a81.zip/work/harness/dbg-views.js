const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const PKG = "/home/user/work/cad-pkg/rgz-3d-cad-studio";
const vc = new VirtualConsole(); vc.sendTo(console, { omitJSDOMErrors: true });
const dom = new JSDOM("<!DOCTYPE html><html><body></body></html>", { url: "https://houmanrgz.ir/cad/", runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc });
const win = dom.window;
win.HTMLCanvasElement.prototype.getContext = function (k) { return null; };
const t = win.document.createElement("script"); t.textContent = fs.readFileSync(PKG + "/assets/three.min.js", "utf8"); win.document.body.appendChild(t);
const c = win.document.createElement("script"); c.textContent = fs.readFileSync(PKG + "/assets/cad.js", "utf8"); win.document.body.appendChild(c);
const U = win.__rgzcad1;
/* manifold-like: 60×45 plate, L=20, through Ø10 + cbore Ø10/16, pocket 20×10 depth 5 */
const cut = [[20, 20], [40, 20], [40, 30], [20, 30]];   /* pocket cut ring */
const payload = { profiles: [[[0, 0], [60, 0], [60, 45], [0, 45]]], holes: [[15, 22.5, 5, 0, 20, 16, 4, 90], [45, 22.5, 5, 2, 20, 16, 4, 90]], cuts: [cut], cutDepth: 5, L: 20, bevel: { mode: 0, size: 0 } };
const res = win.__rgzcad2.tessLocal(payload);
if (res.error) { console.log("ERR", res.error); process.exit(1); }
const soup = { positions: res.positions, normals: res.normals };
const VD = win.__rgzcad3.VIEW_DEFS;
const top = win.__rgzcad3.hlrView(soup, VD.top);
console.log("top bbox", top.bbox.x0.toFixed(1), top.bbox.y0.toFixed(1), top.bbox.x1.toFixed(1), top.bbox.y1.toFixed(1), "runs", top.runs.length);
/* pocket rim runs: near x 20/40 or y 20/30 within pocket zone */
top.runs.forEach(function (r) {
  const onRim = (Math.abs(r.a[0] - 20) < 0.3 || Math.abs(r.a[0] - 40) < 0.3 || Math.abs(r.a[1] + 20) < 0.3 || Math.abs(r.a[1] + 30) < 0.3) &&
    r.a[0] > 15 && r.a[0] < 45 && r.a[1] > -35 && r.a[1] < -15;
  if (onRim) console.log("rim-run", JSON.stringify(r.a.map(v=>+v.toFixed(1))), JSON.stringify(r.b.map(v=>+v.toFixed(1))), r.vis ? "VIS" : "HID");
});
const front = win.__rgzcad3.hlrView(soup, VD.front);
const hidF = front.runs.filter(r => !r.vis).length;
console.log("front runs", front.runs.length, "hidden", hidF);
