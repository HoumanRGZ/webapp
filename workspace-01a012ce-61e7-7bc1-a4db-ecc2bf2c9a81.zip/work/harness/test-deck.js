// Deck tabs + Learning deep-links + pane isolation (jsdom, real deck.js).
const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const deckJs = fs.readFileSync("/home/user/work/extracted/rgz-engineering-studio/assets/deck.js", "utf8");

const HTML = `<!DOCTYPE html><html><body>
<section class="rgzd" data-rgz-deck>
  <div class="rgzd-tabsbar" role="tablist">
    <button type="button" class="rgzd-tabbtn on" data-deck-tab="apps">Apps</button>
    <button type="button" class="rgzd-tabbtn" data-deck-tab="learn">Learning <span class="rgzd-tabcount">30</span></button>
  </div>
  <div class="rgzd-pane on" data-deck-pane="apps">
    <div class="rgzd-toolbar">
      <label class="rgzd-search"><input type="search"></label>
      <div class="rgzd-chips">
        <button type="button" class="rgzd-chip on" data-cat="all">All</button>
        <button type="button" class="rgzd-chip" data-cat="Fluid Power">Fluid Power</button>
      </div>
    </div>
    <div class="rgzd-grid">
      <article class="rgzd-card" data-cat="Fluid Power">
        <h3>Hydraulic Studio</h3>
        <div class="rgzd-card-foot">
          <a class="rgzd-btn primary" href="/hydraulic-studio/">Open app →</a>
          <a class="rgzd-btn ghost" href="#learn-hydraulics" data-learn-topic="hydraulics">📖 Learning</a>
        </div>
      </article>
      <article class="rgzd-card" data-cat="Fluid Power">
        <h3>Pneumatic Studio</h3>
        <div class="rgzd-card-foot">
          <a class="rgzd-btn primary" href="/pneumatic-studio/">Open app →</a>
          <a class="rgzd-btn ghost" href="#learn-pneumatics" data-learn-topic="pneumatics">📖 Learning</a>
        </div>
      </article>
      <div class="rgzd-empty" style="display:none">Nothing matches your search.</div>
    </div>
  </div>
  <div class="rgzd-pane" data-deck-pane="learn">
    <div class="rgzl" data-rgz-learn data-default-topic="all">
      <div class="rgzd-toolbar">
        <div class="rgzd-chips">
          <button type="button" class="rgzd-chip on" data-topic-chip="all">All topics</button>
          <button type="button" class="rgzd-chip" data-topic-chip="hydraulics">Hydraulics</button>
          <button type="button" class="rgzd-chip" data-topic-chip="pneumatics">Pneumatics</button>
        </div>
        <div class="rgzd-chips">
          <button type="button" class="rgzd-chip on" data-level-chip="all">Any level</button>
          <button type="button" class="rgzd-chip" data-level-chip="beginner">Beginner</button>
        </div>
        <label class="rgzd-search rgzl-search"><input type="search"></label>
      </div>
      <div class="rgzl-grid">
        <article class="rgzl-card" data-lesson="hyd-1" data-topic="hydraulics" data-level="beginner" data-title="Hyd lesson" data-cover="https://site.test/wp-content/plugins/rgz-engineering-studio/assets/learn/fig-hyd-pascal.svg">
          <div class="rgzl-cover"><img src="https://site.test/wp-content/plugins/rgz-engineering-studio/assets/learn/fig-hyd-pascal.svg" alt="Hyd lesson"></div>
          <div class="rgzl-card-top"><span class="rgzl-pill topic-hydraulics">hydraulics</span></div>
          <div class="rgzl-card-foot"><span class="rgzl-minutes">≈ 5 min read</span><button type="button" data-read-lesson>Read →</button></div>
        </article>
        <template data-content="hyd-1"><p>hyd content</p></template>
        <article class="rgzl-card" data-lesson="pne-1" data-topic="pneumatics" data-level="beginner" data-title="Pne lesson">
          <div class="rgzl-card-top"><span class="rgzl-pill topic-pneumatics">pneumatics</span></div>
          <div class="rgzl-card-foot"><span class="rgzl-minutes">≈ 5 min read</span><button type="button" data-read-lesson>Read →</button></div>
        </article>
        <template data-content="pne-1"><p>pne content</p></template>
        <div class="rgzd-empty rgzl-empty" style="display:none">Nothing matches your filters.</div>
      </div>
      <div class="rgzl-modal-backdrop" role="dialog"><div class="rgzl-modal">
        <div class="rgzl-modal-head"><div><h2></h2><div class="rgzl-modal-meta"></div></div><button type="button" class="rgzl-close">×</button></div>
        <div class="rgzl-modal-body"></div>
        <div class="rgzl-modal-foot"><span class="rgzl-minutes"></span><button type="button" data-mark-read>Mark as read</button></div>
      </div></div>
    </div>
  </div>
</section></body></html>`;

function boot(url) {
  const vc = new VirtualConsole();
  const errors = [];
  vc.on("jsdomError", (e) => errors.push(e.message));
  const dom = new JSDOM(HTML, { runScripts: "dangerously", url, virtualConsole: vc, pretendToBeVisual: true });
  const { window } = dom;
  window.HTMLElement.prototype.scrollIntoView = function () {};
  const s = window.document.createElement("script");
  s.textContent = deckJs;
  window.document.body.appendChild(s);
  return { window, errors };
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let fails = 0;
const expect = (c, m) => { if (c) console.log("   ✓ " + m); else { console.log("   ✗ " + m); fails++; } };

(async () => {
  // 1) default state: apps pane on, learn hidden
  let { window, errors } = boot("https://site.test/deck/");
  const $ = (sel) => window.document.querySelector(sel);
  const $$ = (sel) => Array.from(window.document.querySelectorAll(sel));
  expect($('[data-deck-pane="apps"]').classList.contains("on"), "apps pane visible initially");
  expect(!$('[data-deck-pane="learn"]').classList.contains("on"), "learn pane hidden initially");

  // 2) click Learning tab
  $('[data-deck-tab="learn"]').click();
  expect($('[data-deck-pane="learn"]').classList.contains("on"), "learn pane opens on tab click");
  expect(!$('[data-deck-pane="apps"]').classList.contains("on"), "apps pane hides");

  // 3) topic chip filters cards inside learn pane
  $('[data-topic-chip="hydraulics"]').click();
  let hyd = $('.rgzl-card[data-topic="hydraulics"]');
  let pne = $('.rgzl-card[data-topic="pneumatics"]');
  expect(hyd.style.display !== "none", "hydraulic lesson visible after hydraulics filter");
  expect(pne.style.display === "none", "pneumatic lesson hidden after hydraulics filter");
  expect($('.rgzd-chip.on[data-cat="all"]'), "apps pane chip untouched by learn chip click");

  // 4) back to apps: apps chip filtering works and learn chips stay
  $('[data-deck-tab="apps"]').click();
  $('[data-cat="Fluid Power"]').click();
  expect($('[data-deck-pane="apps"] .rgzd-card').style.display !== "none", "app cards shown for matching category");
  expect($('[data-topic-chip="hydraulics"]').classList.contains("on"), "learn topic chip selection preserved");
  expect(errors.filter((e) => !/CSS|css/.test(e)).length === 0, "no JS errors");

  // 5) 📖 Learning card button: opens learn tab pre-filtered (fresh load)
  ({ window } = boot("https://site.test/deck/"));
  window.HTMLElement.prototype.scrollIntoView = function () {};
  const q = (sel) => window.document.querySelector(sel);
  q('[data-learn-topic="pneumatics"]').click();
  await sleep(50);
  expect(q('[data-deck-pane="learn"]').classList.contains("on"), "📖 Learning opens the Learning tab");
  expect(q('[data-topic-chip="pneumatics"]').classList.contains("on"), "pneumatics topic chip pre-selected");
  expect(q('.rgzl-card[data-topic="pneumatics"]').style.display !== "none", "pneumatics lesson visible");
  expect(q('.rgzl-card[data-topic="hydraulics"]').style.display === "none", "hydraulics lesson hidden by pre-filter");
  expect(window.location.hash === "#learn-pneumatics", "URL hash reflects the filtered learning tab");

  // 6) deep-link on load: #learn-hydraulics
  ({ window } = boot("https://site.test/deck/#learn-hydraulics"));
  const q2 = (sel) => window.document.querySelector(sel);
  expect(q2('[data-deck-pane="learn"]').classList.contains("on"), "deep link opens Learning tab on load");
  expect(q2('[data-topic-chip="hydraulics"]').classList.contains("on"), "deep link pre-filters hydraulics");
  expect(q2('.rgzl-card[data-topic="hydraulics"]').style.display !== "none", "hydraulics lesson visible from deep link");

  // 7) lesson reader: cover image on the card AND shown in the modal reader
  ({ window } = boot("https://site.test/deck/"));
  const q4 = (sel) => window.document.querySelector(sel);
  const coverImg = q4('.rgzl-card .rgzl-cover img');
  expect(!!coverImg && /fig-hyd-pascal\.svg/.test(coverImg.getAttribute("src")), "lesson card shows its cover picture");
  q4('[data-deck-tab="learn"]').click();
  q4('.rgzl-card[data-lesson="hyd-1"] [data-read-lesson]').click();
  await sleep(60);
  expect(q4(".rgzl-modal-backdrop").classList.contains("open"), "reader modal opens");
  const mc = q4(".rgzl-modal-body .rgzl-modal-cover img");
  expect(!!mc && /fig-hyd-pascal\.svg/.test(mc.getAttribute("src")), "cover picture shown on top of the reader");

  // 8) plain #learn opens tab without touching filters
  ({ window } = boot("https://site.test/deck/#learn"));
  const q3 = (sel) => window.document.querySelector(sel);
  expect(q3('[data-deck-pane="learn"]').classList.contains("on"), "#learn opens the Learning tab");
  expect(q3('[data-topic-chip="all"]').classList.contains("on"), "plain #learn keeps All topics selected");

  console.log(fails === 0 ? "\nALL DECK TAB TESTS PASSED" : "\n" + fails + " FAILURES");
  process.exit(0);
})();
