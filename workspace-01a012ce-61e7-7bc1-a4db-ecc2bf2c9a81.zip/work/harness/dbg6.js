const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const PKG = "/home/user/work/cad-pkg/rgz-3d-cad-studio";
const vc = new VirtualConsole(); vc.sendTo(console, { omitJSDOMErrors: true });
const dom = new JSDOM("<!DOCTYPE html><html><body></body></html>", { url: "https://houmanrgz.ir/cad/", runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc });
const win = dom.window;
win.HTMLCanvasElement.prototype.getContext = function (k) { return null; };
const t = win.document.createElement("script"); t.textContent = fs.readFileSync(PKG + "/assets/three.min.js", "utf8"); win.document.body.appendChild(t);
const T = win.THREE;
// exactly buildShape(true) for our payload
const sh = new T.Shape();
[[0,0],[60,0],[60,45],[0,45]].forEach((p,i)=> i?sh.lineTo(p[0],p[1]):sh.moveTo(p[0],p[1]));
sh.closePath();
const h1 = new T.Path(); h1.absarc(15,22.5,5,0,Math.PI*2,true); sh.holes.push(h1);
const h2 = new T.Path(); h2.absarc(45,22.5,5,0,Math.PI*2,true); sh.holes.push(h2);
const hp = new T.Path(); [[20,20],[40,20],[40,30],[20,30]].forEach((p,i)=> i?hp.lineTo(p[0],p[1]):hp.moveTo(p[0],p[1])); hp.closePath();
sh.holes.push(hp);
const g = new T.ExtrudeGeometry([sh], { depth: 5, bevelEnabled: false, curveSegments: 24 });
const pos = g.getAttribute("position");
console.log("extrude verts:", pos.count, "indexed:", !!g.getIndex());
// verts on the pocket rim at top (z=5 in extrude space): edges along y=20 / y=30, x in [20,40]
let onRim = 0, inWin = 0;
const zs = {};
for (let i=0;i<pos.count;i++){
  const x=pos.getX(i), y=pos.getY(i), z=pos.getZ(i);
  const k=Math.round(z*100)/100; zs[k]=(zs[k]||0)+1;
  if (Math.abs(z-5)<0.01 && Math.abs(y-20)<0.01 && x>=19.99 && x<=40.01) onRim++;
  if (Math.abs(z-5)<0.01 && x>20.01 && x<39.99 && y>20.01 && y<29.99) inWin++;
}
console.log("keys z:", JSON.stringify(zs));
console.log("verts at z=5 ON y=20 rim x20..40:", onRim, "| cap verts INSIDE pocket window at z=5:", inWin);
