// Dump the sidebar mini icons for every library card as SVG files.
const fs = require("fs");
const path = require("path");
const { JSDOM, VirtualConsole } = require("jsdom");
const appJs = process.argv[2];
const outDir = process.argv[3];
fs.mkdirSync(outDir, { recursive: true });
const code = fs.readFileSync(appJs, "utf8");

function runApp(rootId, label) {
  return new Promise((resolve) => {
    const vc = new VirtualConsole();
    const html = `<!DOCTYPE html><html><body><div id="${rootId}"></div></body></html>`;
    const dom = new JSDOM(html, {
      runScripts: "dangerously", pretendToBeVisual: true, url: "https://example.com/", virtualConsole: vc,
      beforeParse(window) {
        window.matchMedia = () => ({ matches: false, media: "", addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {} });
        window.confirm = () => true; window.alert = () => {};
        window.requestAnimationFrame = (cb) => setTimeout(cb, 0);
      },
    });
    const { window } = dom;
    const script = window.document.createElement("script");
    script.textContent = code;
    window.document.body.appendChild(script);
    setTimeout(() => {
      const root = window.document.getElementById(rootId);
      const cards = root.querySelectorAll(".rgz-symbol-card");
      let n = 0;
      for (const card of cards) {
        const type = card.dataset.type;
        const icon = card.querySelector(".rgz-symbol-icon svg");
        if (!icon) continue;
        const svg = `<svg xmlns="http://www.w3.org/2000/svg" ${icon.getAttribute("viewBox") ? `viewBox="${icon.getAttribute("viewBox")}"` : ""} style="background:#0b1730">${icon.innerHTML}</svg>`;
        fs.writeFileSync(path.join(outDir, `${label}-${type}.svg`), svg);
        n++;
      }
      console.log(label, n);
      resolve(n);
    }, 1200);
  });
}
(async () => {
  await runApp("rgz-hydraulic-studio", "hyd");
  await runApp("rgz-pneumatic-studio", "pne");
  process.exit(0);
})();
