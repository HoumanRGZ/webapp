const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const PKG = "/home/user/work/cad-pkg/rgz-3d-cad-studio";
const vc = new VirtualConsole(); vc.sendTo(console, { omitJSDOMErrors: true });
const dom = new JSDOM("<!DOCTYPE html><html><body></body></html>", { url: "https://houmanrgz.ir/cad/", runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc });
const win = dom.window;
win.HTMLCanvasElement.prototype.getContext = function (k) { return null; };
const t = win.document.createElement("script"); t.textContent = fs.readFileSync(PKG + "/assets/three.min.js", "utf8"); win.document.body.appendChild(t);
const c = win.document.createElement("script"); c.textContent = fs.readFileSync(PKG + "/assets/cad.js", "utf8"); win.document.body.appendChild(c);
const X = win.__rgzcad2;
const design = { v:2, name: "dbg", material: "steel", activeSketch:null, mirror:null, draw:null,
  sketches: [{ id: "sk1", plane: { o: [0,0,0], u: [1,0,0], v: [0,1,0], n: [0,0,1] },
    items: [
      { id: "rc1", type: "rect", x1: 0, y1: 0, x2: 60, y2: 45 },
      { id: "c1", type: "hole", cx: 15, cy: 22.5, d: 10, mode: "through", depth: null, cbore: null, csink: null, thread: null },
      { id: "c2", type: "hole", cx: 45, cy: 22.5, d: 10, mode: "cbore", depth: 20, cbore: { d: 16, depth: 4 }, csink: null, thread: null }
    ],
    cuts: [[[20,20],[40,20],[40,30],[20,30]]] }],
  features: [
    { id: "f1", type: "pad", skid: "sk1", sel: "all", L: 20, dir: 1, draft: 0, cuts: [[[20,20],[40,20],[40,30],[20,30]]], cutDepth: 5 },
    { id: "f2", type: "pocket", skid: "sk1", sel: "cuts", L: 20, depth: 5, cutDepth: 5 }
  ] };
for (const f of design.features) {
  const p = X.payloadForFeature(design, f);
  console.log(f.type, "payload keys:", Object.keys(p).join(","), "| cuts:", p.cuts && p.cuts.length, "cutDepth:", p.cutDepth, "L:", p.L, "flatCut:", p.flatCut, "profiles:", p.profiles && p.profiles.length, "holes:", p.holes && p.holes.length);
  const m = X.tessLocal(p);
  const pos = m.positions || m.getAttribute && m.getAttribute("position");
  const n = (pos.length ? pos.length/9 : pos.count/3);
  console.log("   tris:", n);
  // count horizontal rim edges at pocket top: edges where both endpoints y in {20,30} and z=L
  const arr = pos.length ? pos : pos.array;
  let rim = 0, cap = 0, capIn = 0;
  for (let i = 0; i < arr.length; i += 3) {
    if (Math.abs(arr[i+2] - 20) < 0.05) { cap++; if (arr[i] > 20.2 && arr[i] < 39.8 && arr[i+1] > 20.2 && arr[i+1] < 29.8) capIn++; }
  }
  console.log("   verts on z=20:", cap, "strictly inside pocket window:", capIn);
}
