const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const PKG = "/home/user/work/cad-pkg/rgz-3d-cad-studio";
const php = fs.readFileSync(PKG + "/app.php", "utf8");
const start = php.indexOf("?>", php.indexOf("ob_start();"));
const retAt = php.indexOf("return ob_get_clean();");
const end = php.lastIndexOf("<?php", retAt);
let html = php.slice(start + 2, end);
html = html.replace(/<\?php\s*echo\s*esc_url\(home_url\('([^']*)'\)\);?\s*\?>/g, (m, p) => "https://houmanrgz.ir" + p);
html = html.replace(/<\?php[^?]*\?>/g, "RGZ 3D CAD Studio");
const vc = new VirtualConsole(); vc.sendTo(console, { omitJSDOMErrors: true });
const dom = new JSDOM("<!DOCTYPE html><html><head></head><body>" + html + "</body></html>", {
  url: "https://houmanrgz.ir/cad/", runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc });
const win = dom.window, doc = win.document;
function ctx2d(cv) { return new Proxy({}, { get(t, k) {
  if (k === "canvas") return cv;
  if (k === "measureText") return s => ({ width: 7 * String(s).length });
  if (k === "getImageData") return (x, y, w, h) => ({ data: new Uint8ClampedArray(Math.max(4, w * h * 4)) });
  if (k === "createLinearGradient" || k === "createRadialGradient") return () => ({ addColorStop() {} });
  if (k === "isPointInPath") return () => false;
  return () => {}; }, set() { return true; } }); }
win.HTMLCanvasElement.prototype.getContext = function (k) { return k === "2d" ? ctx2d(this) : null; };
win.RGZCAD = { accent: "#eb4e3c", worker: "assets/cad-geometry-worker.js", version: "1.0.0", units: "mm", hubUrl: "https://houmanrgz.ir/mechanical-engineering-deck/#learn-cad" };
const t = doc.createElement("script"); t.textContent = fs.readFileSync(PKG + "/assets/three.min.js", "utf8"); doc.body.appendChild(t);
const c = doc.createElement("script"); c.textContent = fs.readFileSync(PKG + "/assets/cad.js", "utf8"); doc.body.appendChild(c);
setTimeout(() => {
  const U = win.__rgzcad1;
  U.S.design.name = "Manifold Block";
  const sk = U.startSketchOnDatum ? U.startSketchOnDatum("xy") : U.sketch();
  sk.entities.push(U.mkEnt("rect", { cx: 30, cy: 22.5, w: 60, h: 45 }));
  U.closeSketchToPad();
  const pad = U.S.design.features[0];
  pad.L = 16; pad.edge = { style: "chamfer", size: 1 };
  sk.entities.push(U.mkEnt("hole", { cx: 15, cy: 22.5, r: 5, hType: "cbore", depth: 0, cbd: 16, cbdDepth: 4, csAngle: 90 }));
  sk.entities.push(U.mkEnt("hole", { cx: 45, cy: 22.5, r: 5, hType: "through", depth: 0, cbd: 12, cbdDepth: 2, csAngle: 90 }));
  U.padSketch(sk.id);
  U.S.design.sketches.push({ id: "skQ", name: "Sketch.pocket", plane: { kind: "faceTop", topOf: pad.id, origin: [0, 0, 16], u: [1, 0, 0], v: [0, 1, 0], n: [0, 0, 1] }, host: pad.id, entities: [U.mkEnt("rect", { cx: 30, cy: 22.5, w: 30, h: 10 })] });
  U.pocketFromSketch("skQ");
  U.S.design.features[1].L = 6;
  // ---- diagnostics ----
  const padF = U.S.design.features[0];
  // reach payloadForFeature via a tiny worldSoup intercept: copy from part2 exports? Not exported — replicate via worker RPC not available.
  const solo = win.__rgzcad2.tessLocal({ profiles: [[[0,0],[60,0],[60,45],[0,45]]],
    holes: [[15,22.5,5,2,0,16,4,90],[45,22.5,5,0,0,12,2,90]],
    cuts: [[[15,17.5],[45,17.5],[45,27.5],[15,27.5]]], cutDepth: 6, L: 16, bevel: { mode: 1, size: 1 } });
  const spp = solo.positions, snn = solo.normals;
  let slope = 0, zeroN = 0, badCap = 0;
  for (let i=0;i<spp.length/9;i++){
    const nx=snn[i*9],ny=snn[i*9+1],nz=snn[i*9+2];
    const z1=spp[i*9+2],z2=spp[i*9+5],z3=spp[i*9+8];
    if (Math.abs(nx*nx+ny*ny+nz*nz-1)>0.01){ zeroN++; }
    if (Math.abs(nz)<0.99 && Math.abs(nz)>0.01){ slope++; }
    if (Math.abs(nz)<0.99 && Math.abs(z1-z2)<0.001 && Math.abs(z2-z3)<0.001){ badCap++; }
  }
  console.log("lengths: P", spp.length, "N", snn.length, "| P/9:", spp.length/9, "N/9:", snn.length/9);
  let firstBad=-1, nBad=0;
  for (let i=0;i<spp.length/9;i++){
    const nx=snn[i*9],ny=snn[i*9+1],nz=snn[i*9+2];
    if (Math.abs(nx*nx+ny*ny+nz*nz-1)>0.01){ nBad++; if(firstBad<0) firstBad=i; }
  }
  console.log("norm fails:", nBad, "first bad tri:", firstBad, "of", spp.length/9);
  if (firstBad>=0){ const i=firstBad; console.log("firstBad raw normals:", [snn[i*9],snn[i*9+1],snn[i*9+2],snn[i*9+3],snn[i*9+8]]);
    const v=[]; for(let k=0;k<3;k++) v.push([spp[i*9+3*k],spp[i*9+3*k+1],spp[i*9+3*k+2]].map(n=>+n.toFixed(2)));
    console.log("firstBad pos:", JSON.stringify(v)); }
  console.log("solo tris:", spp.length/9, "| slope normals:", slope, "| degenerate normals:", zeroN, "| flat tri with slope normal:", badCap);
  // dump a few slope-normal flat tris
  let shown=0;
  for (let i=0;i<spp.length/9 && shown<6;i++){
    const nx=snn[i*9],ny=snn[i*9+1],nz=snn[i*9+2];
    const z1=spp[i*9+2],z2=spp[i*9+5],z3=spp[i*9+8];
    if (Math.abs(nz)<0.99 && Math.abs(z1-z2)<0.001 && Math.abs(z2-z3)<0.001){
      const v=[]; for(let k=0;k<3;k++) v.push([spp[i*9+3*k],spp[i*9+3*k+1],spp[i*9+3*k+2]].map(n=>+n.toFixed(2)));
      console.log("  badflat tri",i,"n=",[nx,ny,nz].map(n=>+n.toFixed(2)), JSON.stringify(v)); shown++;
    }
  }
  process.exit(0);

}, 400);
