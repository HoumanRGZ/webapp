// Render every built-in example circuit: save standalone SVG + validation messages + project summary.
const fs = require("fs");
const path = require("path");
const { JSDOM, VirtualConsole } = require("jsdom");

const appJs = process.argv[2];
const outDir = process.argv[3];
const appKind = process.argv[4] || "hyd"; // hyd | pne
fs.mkdirSync(outDir, { recursive: true });
const code = fs.readFileSync(appJs, "utf8");

const CSS = `
.rgz-component .symbol-stroke{stroke:#f8fafc;stroke-width:2.2;fill:none;stroke-linecap:round;stroke-linejoin:round}
.rgz-component .symbol-fill{fill:rgba(255,255,255,.07);stroke:#f8fafc;stroke-width:2.2}
.rgz-component .symbol-muted{stroke:#94a3b8;stroke-width:1.8;fill:none;stroke-linecap:round;stroke-linejoin:round}
.rgz-component .symbol-accent{stroke:#e8793c;stroke-width:2.3;fill:none;stroke-linecap:round;stroke-linejoin:round}
.rgz-component .symbol-solid{fill:#f8fafc;stroke:none}
.rgz-component .component-label{fill:#f8fafc;font-size:13px;font-weight:850;font-family:sans-serif}
.rgz-component .port-label{fill:#8ea2bd;font-size:12px;font-family:sans-serif}
.rgz-connection-path{fill:none;stroke:#d9e7ff;stroke-width:3;stroke-linecap:round;stroke-linejoin:round}
.rgz-connection-path.pressure{stroke:#93c5fd}
.rgz-connection-path.return{stroke:#a7f3d0}
.rgz-connection-path.pilot{stroke:#fbbf24;stroke-dasharray:8 8}
.rgz-connection-path.drain{stroke:#c4b5fd;stroke-dasharray:3 7}
.rgz-connection-path.electrical{stroke:#f0abfc;stroke-dasharray:10 6 2 6}
.rgz-grid-dot{fill:#22314f}
text{font-family:sans-serif}
.selection-box{display:none}
circle.port{fill:#0b1730;stroke:#7dd3fc;stroke-width:1.5}
.rgz-readout-badge{display:none}
`;

function run() {
  return new Promise((resolve) => {
    const vc = new VirtualConsole();
    const rootId = appKind === "hyd" ? "rgz-hydraulic-studio" : "rgz-pneumatic-studio";
    const html = `<!DOCTYPE html><html><body><div id="${rootId}"></div></body></html>`;
    const dom = new JSDOM(html, {
      runScripts: "dangerously", pretendToBeVisual: true, url: "https://example.com/", virtualConsole: vc,
      beforeParse(window) {
        window.matchMedia = () => ({ matches: false, media: "", addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {} });
        window.confirm = () => true; window.alert = () => {};
        window.requestAnimationFrame = (cb) => setTimeout(cb, 0);
        window.SVGElement.prototype.getBBox = function () { return { x: 0, y: 0, width: 100, height: 100 }; };
      },
    });
    const { window } = dom;
    const script = window.document.createElement("script");
    script.textContent = code;
    window.document.body.appendChild(script);

    const results = [];
    setTimeout(async () => {
      const doc = window.document;
      const root = doc.getElementById(rootId);
      const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

      // open modal once to learn levels
      root.querySelector('[data-action="browse-examples"]').dispatchEvent(new window.MouseEvent("click", { bubbles: true }));
      await sleep(120);
      const levelSel = doc.getElementById("rgz-level-selectbox");
      const levels = [...levelSel.options].map((o) => o.value);
      for (const level of levels) {
        levelSel.value = level;
        levelSel.dispatchEvent(new window.Event("change", { bubbles: true }));
        await sleep(60);
        const exSel = doc.getElementById("rgz-example-selectbox");
        const count = exSel.options.length;
        const lname = level.split(" ")[0].toLowerCase();
        for (let i = 0; i < count; i++) {
          exSel.value = String(i);
          exSel.dispatchEvent(new window.Event("change", { bubbles: true }));
          await sleep(40);
          const name = (doc.getElementById("rgz-example-preview") || {}).textContent || `ex${i}`;
          const openBtn = doc.querySelector("[data-modal-open-example]");
          openBtn.dispatchEvent(new window.MouseEvent("click", { bubbles: true }));
          await sleep(400);
          const canvas = doc.getElementById("rgz-canvas");
          // compute bbox of ALL rendered geometry
          let minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
          const comps = [];
          const addPt = (x, y) => { if (isFinite(x) && isFinite(y)) { minX = Math.min(minX, x); minY = Math.min(minY, y); maxX = Math.max(maxX, x); maxY = Math.max(maxY, y); } };
          canvas.querySelectorAll("g.rgz-component").forEach((g) => {
            const m = g.getAttribute("transform").match(/translate\(([-\d.]+)[ ,]([-\d.]+)\)/);
            if (m) { const x = +m[1], y = +m[2]; comps.push({ id: g.getAttribute("data-id"), x, y });
              let extraR = 130, extraL = 130;
              const ct = g.querySelector(".rgz-custom-text");
              if (ct) { const fs = +(ct.getAttribute("font-size") || 24); const len = (ct.textContent || "").length; extraR = Math.max(extraR, 30 + len * fs * 0.55); extraL = Math.max(extraL, 30 + len * fs * 0.55); }
              addPt(x - extraL, y - 100); addPt(x + extraR, y + 110); }
          });
          canvas.querySelectorAll("path.rgz-connection-path").forEach((el) => {
            const nums = (el.getAttribute("d").match(/-?\d+\.?\d*/g) || []).map(Number);
            for (let i = 0; i + 1 < nums.length; i += 2) addPt(nums[i], nums[i+1]);
          });
          minX -= 40; minY -= 40; maxX += 40; maxY += 40;
          canvas.setAttribute("viewBox", `${minX} ${minY} ${maxX - minX} ${maxY - minY}`);
          canvas.setAttribute("width", Math.min(2200, maxX - minX));
          canvas.removeAttribute("height");
          const svgTxt = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${minX} ${minY} ${maxX - minX} ${maxY - minY}" style="background:#0b1730"><style>${CSS}</style>${canvas.innerHTML}</svg>`;
          const fname = `${lname}-${String(i + 1).padStart(2, "0")}`;
          fs.writeFileSync(path.join(outDir, fname + ".svg"), svgTxt);

          // run circuit check
          root.querySelector('[data-action="check"]').dispatchEvent(new window.MouseEvent("click", { bubbles: true }));
          await sleep(400);
          const msgs = [...doc.querySelectorAll("#rgz-messages .rgz-message")].map((m) => m.textContent.trim().replace(/\s+/g, " "));
          results.push({ file: fname, level, index: i, name, components: comps.length, messages: msgs });
          // reopen modal for next (it closed after open)
          const modalStill = doc.getElementById("rgz-level-selectbox");
          if (!modalStill) {
            root.querySelector('[data-action="browse-examples"]').dispatchEvent(new window.MouseEvent("click", { bubbles: true }));
            await sleep(120);
            const ls2 = doc.getElementById("rgz-level-selectbox");
            ls2.value = level;
            ls2.dispatchEvent(new window.Event("change", { bubbles: true }));
            await sleep(50);
          }
        }
      }
      fs.writeFileSync(path.join(outDir, "report.json"), JSON.stringify(results, null, 1));
      console.log("circuits:", results.length);
      resolve();
    }, 1500);
  });
}
run().then(() => process.exit(0)).catch((e) => { console.error(e); process.exit(1); });
