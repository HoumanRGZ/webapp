// Acceptance test: RGZ 3D CAD Studio app package (zip) for RGZ Engineering Studio.
//   A  static contract checks (manifest, syntax, zip hygiene, design tokens)
//   B  geometry worker driven with real payloads in a vm sandbox (CPU proof)
//   C  php-wasm: install the REAL zip through the plugin's package installer,
//      then load + shortcode-register + render the app (server proof)
//   D  jsdom: boot the real cad.js in a DOM, drive sketch→pad→drawing,
//      assert the ISO drawing sheet, tolerance formatting, learn library,
//      and guided tour (browser proof)
const fs = require("fs");
const vm = require("vm");
const { execSync } = require("child_process");

const PKG_DIR = "/home/user/work/cad-pkg/rgz-3d-cad-studio";
const ZIP_PATH = "/home/user/rgz-3d-cad-studio.zip";
const PLUGIN_DIR = "/home/user/work/extracted/rgz-engineering-studio";

let pass = 0, failed = 0;
function expect(cond, label) {
  if (cond) { pass++; console.log("ok ✓ " + label); }
  else { failed++; console.log("FAIL ✗ " + label); }
}

/* =========================== Phase A — static =========================== */
function phaseA() {
  console.log("\n— A: package contract (static) —");
  const raw = fs.readFileSync(PKG_DIR + "/rgz-app.json", "utf8");
  let m = null;
  try { m = JSON.parse(raw); } catch (e) { /* handled below */ }
  expect(!!m, "rgz-app.json parses as JSON");
  if (!m) { return; }
  expect(/^[a-z0-9-]{2,49}$/.test(m.id), "manifest id is slug-safe (" + m.id + ")");
  expect(typeof m.name === "string" && m.name.length >= 3, "manifest has a name");
  expect(m.version === "1.0.0", "version stays at 1.0.0 (plugin convention)");
  const RESERVED = ["rgz_hydraulic_studio", "rgz_pneumatic_studio", "rgz_mechanical_deck", "rgz_learning_hub", "gallery", "caption", "embed", "video", "audio", "playlist", "code"];
  expect(/^[a-z0-9_]{3,40}$/.test(m.shortcode) && RESERVED.indexOf(m.shortcode) === -1, "shortcode valid + not reserved (" + m.shortcode + ")");
  expect(m.entry === "app.php" && fs.existsSync(PKG_DIR + "/" + m.entry), "entry file exists at package root");
  expect(m.class === "RGZ_CAD_Studio" && m.render === "render_shortcode", "class+render auto-registration contract");
  expect(m.card && m.card.accent && m.card.accent.toLowerCase() === "#eb4e3c", "card accent is the RGZ #EB4E3C");
  expect(m.card && m.card.title && m.card.category, "deck card carries title + category");
  expect(m.card && m.card.desc && !/\b(CPU|GPU|RAM|WebGL)\b/i.test(m.card.desc), "deck card copy is jargon-free (no CPU/GPU/RAM/WebGL)");
  expect(m.card && m.card.learnTopic === "cad", "card links into the CAD & Design learning topic");

  ["app.php"].forEach(function (f) {
    const src = fs.readFileSync(PKG_DIR + "/" + f, "utf8");
    expect(src.indexOf("if (!defined('ABSPATH'))") !== -1, f + " has the ABSPATH guard first");
  });
  {
    const php = fs.readFileSync(PKG_DIR + "/app.php", "utf8");
    expect(!/\b(CPU|GPU|RAM|WebGL)\b/.test(php), "app UI copy is jargon-free for end users");
    ["data-tool=\"arc\"", "data-tool=\"slot\"", "data-tool=\"ellipse\"", "data-tool=\"spline\"", "data-tool=\"ngon\"",
      "data-tool=\"rect\"", "data-tool=\"circle\"", "data-tool=\"poly\"", "data-tool=\"hole\"", "data-tool=\"cline\"",
      "data-mode=\"select\"", "data-undo", "data-redo",
      "data-opt=\"section\"", "data-opt=\"measure\"", "data-opt=\"ortho\"", "data-measure-tag", "data-facehint",
      "data-tree", "data-tool3d=\"facesketch\"", "data-tool3d=\"holeface\"",
      "data-featmk=\"pad\"", "data-featmk=\"pocket\"", "data-featmk=\"shaft\"", "data-featmk=\"groove\"", "data-featmk=\"rib\"",
      "data-tool=\"line\"", "data-tool=\"point\"", "data-op2=\"corner\"", "data-op2=\"chamfer\"", "data-op2=\"trim\"", "data-op2=\"qtrim\"", "data-op2=\"break\"", "data-op2=\"offset\"", "data-op2=\"cons\"",
      "data-geo=\"h\"", "data-geo=\"v\"", "data-geo=\"par\"", "data-geo=\"perp\"", "data-geo=\"eq\"", "data-geo=\"coin\"", "data-geo=\"con\"", "data-geo=\"tan\"", "data-geo=\"fix\"",
      "data-edgehint",
      "data-planehint",
      "data-dress=\"chamfer\"", "data-dress=\"fillet\"", "data-dress=\"draft\"", "data-dress=\"shell\"", "data-dress=\"pattern\"", "data-dress=\"mirror\"",
      "data-newdesign", "data-resume", "data-makebar",
      "data-fullscreen", "data-account-chip", "data-auth-modal", "data-designs-modal", "data-gl-retry"].forEach(function (hook) {
        expect(php.indexOf(hook) !== -1, "markup hook present: " + hook);
      });
    /* exactly the 3-step pipeline (Sketch -> 3D Features -> ISO Drawing) */
    const stepCount = (php.match(/data-step=/g) || []).length;
    expect(stepCount === 3 && php.indexOf('data-step=\"modify\"') === -1, "3-step pipeline (sketch / 3D features / drawing), no dead 'Modify' step (" + stepCount + " step buttons)");
  }
  {
    const css2 = fs.readFileSync(PKG_DIR + "/assets/cad.css", "utf8");
    ["rgzcad-fs", ":fullscreen", "[hidden]", "rgzcad-viewport-wrap", "rgzcad-modal-card", "rgzcad-webglnote", "rgzcad-measuretag", "data-sketch-canvas", "rgzcad-makebar", "rgzcad-chip", "rgzcad-edgehint"].forEach(function (sel) {
      expect(css2.indexOf(sel) !== -1, "stylesheet covers: " + sel);
    });
    /* tour overlay lives on <body>, outside the token scope: accent must be hardcoded */
    expect(/\.rgzcad-tour \.acts \.next\{[^}]*#eb4e3c/i.test(css2), "tour Next button has a hardcoded accent fill (was invisible white-on-white)");
    expect(!/\.rgzcad-tour[^{]*\{[^}]*var\(--rgzc-accent/.test(css2), "no tour rule reads the --rgzc-accent token (undefined outside the app root)");
    /* space usage: side columns share the full row height (no white gaps) */
    expect(/\.rgzcad-work\{[^}]*align-items:stretch/.test(css2), "work columns stretch to the viewport row (no dead space beside the stage)");
    expect(/\.rgzcad-treelist\{[^}]*flex:1/.test(css2), "tree list fills the column height");
  }
  ["assets/cad.js", "assets/cad-geometry-worker.js"].forEach(function (f) {
    try { new vm.Script(fs.readFileSync(PKG_DIR + "/" + f, "utf8"), { filename: f }); pass++; console.log("ok ✓ " + f + " compiles"); }
    catch (e) { failed++; console.log("FAIL ✗ " + f + " compiles — " + e.message); }
  });

  const three = fs.readFileSync(PKG_DIR + "/assets/three.min.js", "utf8");
  expect(three.indexOf('"149"') !== -1 && /REVISION=/.test(three) && three.indexOf("globalThis") !== -1, "three.js r149 vendored (UMD, works in workers)");
  expect(/MIT|mit\.org|opensource/i.test(three.slice(0, 2000)), "three.js MIT license banner preserved");

  const css = fs.readFileSync(PKG_DIR + "/assets/cad.css", "utf8");
  expect(css.toLowerCase().indexOf("#eb4e3c") !== -1, "stylesheet uses the site accent #EB4E3C");
  expect(css.indexOf("--rgzc-accent") !== -1, "stylesheet is tokenised like the Mechanical Deck");

  /* zip hygiene via the real archive */
  expect(fs.existsSync(ZIP_PATH), "zip exists at " + ZIP_PATH);
  const zsz = fs.statSync(ZIP_PATH).size;
  expect(zsz <= 5 * 1048576, "zip within 5 MB limit (" + (zsz / 1024).toFixed(0) + " KB)");
  const names = execSync("unzip -Z1 " + JSON.stringify(ZIP_PATH)).toString().split("\n").filter(Boolean);
  const files = names.filter(function (n) { return n.slice(-1) !== "/"; });
  expect(files.length <= 200, "file count within 200 (" + files.length + ")");
  expect(names.indexOf("rgz-app.json") !== -1 && names.indexOf("app.php") !== -1, "zip holds manifest + entry at root");
  ["assets/three.min.js", "assets/cad.css", "assets/cad.js", "assets/cad-geometry-worker.js"].forEach(function (n) {
    expect(names.indexOf(n) !== -1, "zip holds " + n);
  });
  expect(names.every(function (n) { return n.indexOf("..") === -1; }), "no '..' paths in the archive");
  const list = execSync("unzip -l " + JSON.stringify(ZIP_PATH)).toString();
  const mm = list.match(/(\d+)\s+\d+ files/);
  const unpacked = mm ? parseInt(mm[1], 10) : 0;
  expect(unpacked > 0 && unpacked <= 20 * 1048576, "unpacks under 20 MB (" + (unpacked / 1048576).toFixed(2) + " MB)");
}

/* ==================== Phase B — worker geometry (vm) ==================== */
function phaseB() {
  console.log("\n— B: geometry worker with real payloads —");
  const threeSrc = fs.readFileSync(PKG_DIR + "/assets/three.min.js", "utf8");
  const workerSrc = fs.readFileSync(PKG_DIR + "/assets/cad-geometry-worker.js", "utf8");
  const responses = [];
  const sandbox = { console: console };
  sandbox.self = sandbox;
  sandbox.importScripts = function () { vm.runInContext(threeSrc, ctx); };
  sandbox.postMessage = sandbox.self = sandbox;
  sandbox.self.postMessage = function (msg) { responses.push(msg); };
  const ctx = vm.createContext(sandbox);
  let ok = true;
  try { vm.runInContext(workerSrc, ctx); } catch (e) { ok = false; console.log("   worker boot threw: " + e.message); }
  expect(ok && typeof sandbox.onmessage === "function" && sandbox.RGZ_THREE_READY === true, "worker boots and loads three.js from its own folder");

  /* rect 60×40, pad 40, Ø10 hole, 1 mm chamfer (bevel mode 1) */
  sandbox.onmessage({ data: { id: 1, payload: { profiles: [[[0, 0], [60, 0], [60, 40], [0, 40]]], holes: [[30, 20, 5, 0, 0, 0, 0, 90]], cuts: [], cutDepth: 0, L: 40, bevel: { mode: 1, size: 1 } } } });
  const r1 = responses[0] || {};
  expect(!r1.error, "rect+hole+chamfer payload does not error" + (r1.error ? " (" + r1.error + ")" : ""));
  expect(r1.positions && r1.positions.length % 9 === 0 && r1.positions.length > 0, "returns a non-indexed triangle soup (" + (r1.positions ? r1.positions.length / 9 : 0) + " tris)");
  expect(r1.normals && r1.normals.length === r1.positions.length, "returns normals matching positions");
  /* analytic volume: box 96000 − hole π·25·40 ≈ 3141.6 − chamfer wedge ≈ 4·(1·1/2) removed along edges + bevel rings …
     generous window around the ideal 92.9 cm³ */
  expect(typeof r1.vol === "number" && r1.vol > 75 && r1.vol < 118, "volume is analytic & sane (" + (r1.vol || 0).toFixed(1) + " cm³, ideal ≈ 92.9)");
  expect(typeof r1.area === "number" && r1.area > 100 && r1.area < 400, "surface area is sane (" + (r1.area || 0).toFixed(0) + " cm²)");
  expect(r1.tris === ((r1.positions ? r1.positions.length : 0) / 9 | 0), "tris counter matches the soup");

  /* L-shaped polygon profile, no holes */
  sandbox.onmessage({ data: { id: 2, payload: { profiles: [[[0, 0], [80, 0], [80, 30], [40, 30], [40, 60], [0, 60]]], holes: [], cuts: [], cutDepth: 0, L: 20, bevel: { mode: 0, size: 0 } } } });
  const r2 = responses[1] || {};
  /* L-shape area = 80·30 + 40·30 = 3600 mm² → ·20 mm = 72 cm³ */
  expect(!r2.error && Math.abs(r2.vol - 72) < 6, "L-shaped polygon volume ≈ 72 cm³ (" + (r2.vol || 0).toFixed(1) + ")");

  /* invalid payload must report, not crash */
  sandbox.onmessage({ data: { id: 3, payload: { profiles: [[[0, 0], [10, 0]]], holes: [], cuts: [], cutDepth: 0, L: 10, bevel: { mode: 0, size: 0 } } } });
  const r3 = responses[2] || {};
  expect(r3 && typeof r3.error === "string", "invalid profile reports {error} so the page falls back safely");

  /* blind Ø10×20 in the same plate: exact analytic removal π·25·20 */
  const sq = [[0, 0], [60, 0], [60, 40], [0, 40]];
  sandbox.onmessage({ data: { id: 4, payload: { profiles: [sq], holes: [[30, 20, 5, 1, 20, 0, 0, 90]], cuts: [], cutDepth: 0, L: 40, bevel: { mode: 0, size: 0 } } } });
  const r4 = responses[3] || {};
  const exp4 = 96 - Math.PI * 25 * 20 / 1000;
  expect(!r4.error && Math.abs(r4.vol - exp4) < 0.35, "blind hole volume exact (" + (r4.vol || 0).toFixed(2) + " cm³, ideal " + exp4.toFixed(2) + ")");

  /* through Ø10 + counterbore Ø16×4 + pocket 20×10×5 */
  sandbox.onmessage({ data: { id: 5, payload: { profiles: [sq], holes: [[30, 20, 5, 2, 0, 16, 4, 90]], cuts: [[[2, 2], [22, 2], [22, 12], [2, 12]]], cutDepth: 5, L: 40, bevel: { mode: 0, size: 0 } } } });
  const r5 = responses[4] || {};
  const exp5 = 96 - Math.PI * 25 * 40 / 1000 - Math.PI * (64 - 25) * 4 / 1000 - 1.0;
  expect(!r5.error && Math.abs(r5.vol - exp5) < 0.4, "counterbore+pocket volume exact (" + (r5.vol || 0).toFixed(2) + " cm³, ideal " + exp5.toFixed(2) + ")");

  /* countersink Ø10/Ø16 × 90° */
  sandbox.onmessage({ data: { id: 6, payload: { profiles: [sq], holes: [[30, 20, 5, 3, 0, 16, 0, 90]], cuts: [], cutDepth: 0, L: 40, bevel: { mode: 0, size: 0 } } } });
  const r6 = responses[5] || {};
  const exp6 = 96 - Math.PI * 25 * 40 / 1000 - (Math.PI * 3 / 3 * (64 + 40 + 25) - Math.PI * 25 * 3) / 1000;
  expect(!r6.error && Math.abs(r6.vol - exp6) < 0.3, "countersink volume exact (" + (r6.vol || 0).toFixed(2) + " cm³, ideal " + exp6.toFixed(2) + ")");
  expect(r6.tris >= 260, "feature shells really tessellated (" + (r6.tris || 0) + " tris)");

  /* nested profiles: circle polygon inside the rectangle = void (hole); deeper nesting = island */
  function circleN(cx, cy, r, n) { const p = []; for (let i = 0; i < n; i++) { const a = i / n * 2 * Math.PI; p.push([cx + r * Math.cos(a), cy + r * Math.sin(a)]); } return p; }
  sandbox.onmessage({ data: { id: 7, payload: { profiles: [sq, circleN(30, 20, 10, 64)], holes: [], cuts: [], cutDepth: 0, L: 20, bevel: { mode: 0, size: 0 } } } });
  const r7 = responses[6] || {};
  const exp7 = (2400 - Math.PI * 100) * 20 / 1000;
  expect(!r7.error && Math.abs(r7.vol - exp7) < 0.6, "circle inside rectangle becomes a void (" + (r7.vol || 0).toFixed(2) + " cm³, ideal " + exp7.toFixed(2) + ")");
  expect(r7.tris > 60, "void profile really cut into the mesh (" + (r7.tris || 0) + " tris)");
  sandbox.onmessage({ data: { id: 8, payload: { profiles: [sq, circleN(30, 20, 10, 64), circleN(30, 20, 4, 48)], holes: [], cuts: [], cutDepth: 0, L: 20, bevel: { mode: 0, size: 0 } } } });
  const r8 = responses[7] || {};
  const exp8 = (2400 - Math.PI * 100 + Math.PI * 16) * 20 / 1000;
  expect(!r8.error && Math.abs(r8.vol - exp8) < 0.7, "profile inside the void becomes a solid island (" + (r8.vol || 0).toFixed(2) + " cm³, ideal " + exp8.toFixed(2) + ")");
  /* two disjoint profiles stay two bosses */
  sandbox.onmessage({ data: { id: 9, payload: { profiles: [sq, [[70, 5], [90, 5], [90, 25], [70, 25]]], holes: [], cuts: [], cutDepth: 0, L: 20, bevel: { mode: 0, size: 0 } } } });
  const r9 = responses[8] || {};
  expect(!r9.error && Math.abs(r9.vol - 56) < 0.5, "disjoint profiles union as separate bosses (" + (r9.vol || 0).toFixed(2) + " cm³, ideal 56.00)");

  /* Shaft (revolve): rect r∈[20,30], h 10, axis x=0, 360° → π(30²−20²)·10 */
  const rectRad = [[20, 0], [30, 0], [30, 10], [20, 10]];
  sandbox.onmessage({ data: { id: 10, payload: { profiles: [rectRad], holes: [], cuts: [], cutDepth: 0, L: 10, bevel: { mode: 0, size: 0 }, revol: { angle: 360, axisX: 0 } } } });
  const r10 = responses[9] || {};
  const exp10 = Math.PI * (900 - 400) * 10 / 1000;
  expect(!r10.error && Math.abs(r10.vol - exp10) < 0.05, "shaft revolve volume exact (" + (r10.vol || 0).toFixed(3) + " cm³, ideal " + exp10.toFixed(3) + ")");
  expect(r10.tris >= 700, "shaft really revolved to a solid of revolution (" + (r10.tris || 0) + " tris)");
  /* partial revolve 180° = exactly half */
  sandbox.onmessage({ data: { id: 11, payload: { profiles: [rectRad], holes: [], cuts: [], cutDepth: 0, L: 10, bevel: { mode: 0, size: 0 }, revol: { angle: 180, axisX: 0 } } } });
  const r11 = responses[10] || {};
  expect(!r11.error && Math.abs(r11.vol - exp10 / 2) < 0.05, "partial revolve is exactly half (" + (r11.vol || 0).toFixed(3) + " cm³, ideal " + (exp10 / 2).toFixed(3) + ")");
  /* profile crossing the axis → clean error, not garbage geometry */
  sandbox.onmessage({ data: { id: 12, payload: { profiles: [[[0, 0], [40, 0], [40, 20], [0, 20]]], holes: [], cuts: [], cutDepth: 0, L: 10, bevel: { mode: 0, size: 0 }, revol: { angle: 360, axisX: 10 } } } });
  expect(typeof (responses[11] || {}).error === "string", "profile crossing the revolve axis reports a clear error");
  /* draft 10° on 40×40, L 10 → Simpson ≈ 14.630 */
  sandbox.onmessage({ data: { id: 13, payload: { profiles: [[[0, 0], [40, 0], [40, 40], [0, 40]]], holes: [], cuts: [], cutDepth: 0, L: 10, bevel: { mode: 0, size: 0 }, draftDeg: 10 } } });
  const r13 = responses[12] || {};
  expect(!r13.error && Math.abs(r13.vol - 14.63) < 0.25, "draft angle leans the walls (" + (r13.vol || 0).toFixed(2) + " cm³, ideal ≈14.63)");
  /* draft too steep → clean error */
  sandbox.onmessage({ data: { id: 14, payload: { profiles: [[[0, 0], [10, 0], [10, 10], [0, 10]]], holes: [], cuts: [], cutDepth: 0, L: 40, bevel: { mode: 0, size: 0 }, draftDeg: 25 } } });
  expect(typeof (responses[13] || {}).error === "string", "impossibly steep draft reports a clear error");
  /* shell t=2 on 60×40×20 → 11.712 */
  sandbox.onmessage({ data: { id: 15, payload: { profiles: [sq], holes: [], cuts: [], cutDepth: 0, L: 20, bevel: { mode: 0, size: 0 }, shellT: 2 } } });
  const r15 = responses[14] || {};
  expect(!r15.error && Math.abs(r15.vol - 11.712) < 0.15, "shell hollows to walls (" + (r15.vol || 0).toFixed(2) + " cm³, ideal 11.712)");
  /* shell too thick → clean error */
  sandbox.onmessage({ data: { id: 16, payload: { profiles: [[[0, 0], [10, 0], [10, 10], [0, 10]]], holes: [], cuts: [], cutDepth: 0, L: 20, bevel: { mode: 0, size: 0 }, shellT: 6 } } });
  expect(typeof (responses[15] || {}).error === "string", "impossibly thick shell reports a clear error");
}

/* ============== Phase C — php-wasm: real zip through the installer ============== */
const STUBS = `<?php
function add_action(...$a){ $GLOBALS['__hooks'][] = ['action',$a[0]]; }
function add_filter(...$a){ $GLOBALS['__filters'][$a[0]][] = $a[1]; }
function apply_filters(...$a){ $tag = $a[0]; $value = isset($a[1]) ? $a[1] : null; $extra = array_slice($a, 2); if (isset($GLOBALS['__filters'][$tag])) { foreach ($GLOBALS['__filters'][$tag] as $cb) { $value = call_user_func_array($cb, array_merge([$value], $extra)); } } return $value; }
function add_shortcode(...$a){ $GLOBALS['__shortcodes'][] = $a[0]; }
function admin_url($p=''){ return 'https://site.test/wp-admin/' . $p; }
function home_url($p='/'){ return 'https://site.test' . $p; }
function plugin_dir_url($f){ return 'https://site.test/wp-content/plugins/rgz-engineering-studio/'; }
function plugin_dir_path($f){ return dirname($f) . '/'; }
function get_option($k, $d=false){ return array_key_exists($k, $GLOBALS['__options_store']) ? $GLOBALS['__options_store'][$k] : $d; }
function update_option($k, $v){ $GLOBALS['__options_store'][$k] = $v; return true; }
function delete_option($k){ unset($GLOBALS['__options_store'][$k]); return true; }
function sanitize_text_field($s){ $s = (string)$s; $s = strip_tags($s); $s = preg_replace('/[\\x00-\\x1F\\x7F]/u', '', $s); return trim($s); }
function sanitize_key($s){ return strtolower(preg_replace('/[^a-zA-Z0-9_\\-]/', '', (string)$s)); }
function sanitize_file_name($n){ return preg_replace('/[^-a-zA-Z0-9_.]/', '-', (string)$n); }
function esc_url_raw($u){ $u = trim((string)$u); return ($u === '' || preg_match('#^https?://#i', $u)) ? $u : ''; }
function esc_url($u){ return (string)$u; }
function esc_html($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function esc_attr($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function wp_kses_post($s){ return (string)$s; }
function wp_unslash($v){ return $v; }
function absint($v){ return abs((int)$v); }
function current_user_can($c){ return true; }
function wp_die($m=''){ throw new Exception('wp_die: '.$m); }
function wp_create_nonce($a){ return 'nonce_'.md5($a); }
function wp_verify_nonce($n, $a=-1){ return $n === 'nonce_'.md5($a) ? 1 : false; }
function check_admin_referer($a=-1, $q=false){ return 1; }
function wp_safe_redirect($url, $status=302){ $GLOBALS['__redirect'][] = $url; }
function add_query_arg($args, $val=null, $url=''){
  if (is_array($args)) { $q = http_build_query($args); $u = $val === null ? '' : $val; }
  else { $q = urlencode($args) . '=' . urlencode($val); $u = $url; }
  return $u . (strpos($u, '?') === false ? '?' : '&') . $q;
}
function wp_upload_dir(){ return ['basedir'=>'/internal/uploads','baseurl'=>'https://site.test/wp-content/uploads','path'=>'/internal/uploads','url'=>'https://site.test/wp-content/uploads']; }
function wp_generate_password($len=12, $a=false, $b=false){ return substr(str_replace(['/','+','='],'', base64_encode(random_bytes($len+4))), 0, $len); }
function wp_json_encode($v, $flags=0){ return json_encode($v, $flags); }
function shortcode_atts($pairs, $atts, $shortcode=''){ return array_merge($pairs, array_intersect_key((array)$atts, $pairs)); }
function wp_enqueue_style(...$a){ $GLOBALS['__enqueue'][] = ['css', $a[0]]; }
function wp_enqueue_script(...$a){ $GLOBALS['__enqueue'][] = ['js', $a[0]]; }
function wp_localize_script($h, $var, $data){ $GLOBALS['__localize'][$var] = $data; }
function shortcode_exists($s){ return in_array($s, isset($GLOBALS['__shortcodes']) ? $GLOBALS['__shortcodes'] : [], true); }
function wp_nonce_url($u, $a=-1){ return $u . (strpos($u,'?')===false?'?':'&') . '_wpnonce=nonce_' . md5($a); }
function get_posts($args=[]){ return []; }
function get_permalink($p){ return 'https://site.test/page/'; }
?>`;

function bootstrapPkg(optionsStore, extra) {
  const opts = JSON.stringify(optionsStore || {}).replace(/'/g, "\\'");
  return (
    STUBS.replace("?>", "") +
    "\ndefine('ABSPATH', '/wp/');\n" +
    "$GLOBALS['__options_store'] = json_decode('" + opts + "', true) ?: [];\n" +
    "$GLOBALS['__hooks'] = []; $GLOBALS['__enqueue'] = []; $GLOBALS['__localize'] = []; $GLOBALS['__redirect'] = []; $GLOBALS['__filters'] = []; $GLOBALS['__shortcodes'] = [];\n" +
    "require_once '/internal/rgz-app-packages.php';\n" +
    "ob_start();\ntry {\n" +
    extra +
    "\n} catch (\\Throwable $e) {\n  if ($e->getMessage() !== '__REDIRECT__') { while (ob_get_level()) { ob_end_clean(); } echo \"FATAL: \" . $e->getMessage() . \"\\n\"; }\n}\n" +
    "$GLOBALS['__out'] = ob_get_clean();\n" +
    "echo \"===OUT===\\n\" . $GLOBALS['__out'] . \"\\n===STATE===\\n\" . json_encode([\n" +
    "  'options' => $GLOBALS['__options_store'],\n" +
    "  'localize' => $GLOBALS['__localize'],\n" +
    "  'enqueue' => $GLOBALS['__enqueue'],\n" +
    "  'shortcodes' => $GLOBALS['__shortcodes'],\n" +
    "  'render' => isset($GLOBALS['__render']) ? $GLOBALS['__render'] : '',\n" +
    "]);\n"
  );
}

async function runPkg(php, label, optionsStore, extra) {
  const code = bootstrapPkg(optionsStore, extra);
  const res = await php.run({ code });
  const text = res.text || "";
  const out = (text.split("===OUT===\n")[1] || "").split("\n===STATE===")[0];
  let state = {};
  try { state = JSON.parse(text.split("===STATE===\n")[1] || "{}"); } catch (e) { console.log(label, "STATE PARSE FAIL", text.slice(-600)); }
  const fatal = /FATAL:|Fatal error|Parse error|Uncaught/.test(out) || /Fatal error|Parse error/.test(text.split("===OUT===")[0] || "");
  if (fatal) { failed++; console.log("FAIL ✗ " + label + " (php fatal)"); console.log(out.slice(0, 800)); }
  else { console.log("ok ✓ php request clean: " + label); pass++; }
  return { out, state, fatal };

  /* picked vertical edges: one R4 fillet + one 2 mm chamfer on the 60×40×40 box */
  sandbox.onmessage({ data: { id: 17, payload: { profiles: [sq], holes: [], cuts: [], cutDepth: 0, L: 40, bevel: { mode: 0, size: 0 }, edgeOps: [{ style: "fillet", ring: 0, vi: 1, r: 4, d: 2, ang: Math.PI / 2 }] } } });
  const r17 = responses[responses.length - 1] || {};
  const exp17 = 96 - (16 - 4 * Math.PI) * 40 / 1000;
  expect(!r17.error && Math.abs(r17.vol - exp17) < 0.05, "picked-edge fillet volume exact (" + (r17.vol || 0).toFixed(3) + " cm³, ideal " + exp17.toFixed(3) + ")");
  sandbox.onmessage({ data: { id: 18, payload: { profiles: [sq], holes: [], cuts: [], cutDepth: 0, L: 40, bevel: { mode: 0, size: 0 }, edgeOps: [{ style: "chamfer", ring: 0, vi: 0, r: 3, d: 2, ang: Math.PI / 2 }, { style: "chamfer", ring: 0, vi: 3, r: 3, d: 2, ang: Math.PI / 2 }] } } });
  const r18 = responses[responses.length - 1] || {};
  const exp18 = 96 - 2 * (0.5 * 2 * 2 * 1) * 40 / 1000;
  expect(!r18.error && Math.abs(r18.vol - exp18) < 0.05, "two picked-edge chamfers exact (" + (r18.vol || 0).toFixed(3) + " cm³, ideal " + exp18.toFixed(3) + ")");
  /* a hole outside the profile: mesh not cut AND volume unchanged (was silently over-subtracted) */
  sandbox.onmessage({ data: { id: 19, payload: { profiles: [sq], holes: [[200, 200, 5, 0, 0, 0, 0, 90]], cuts: [], cutDepth: 0, L: 40, bevel: { mode: 0, size: 0 } } } });
  const r19 = responses[responses.length - 1] || {};
  expect(!r19.error && Math.abs(r19.vol - 96) < 0.01, "hole outside the material removes nothing (" + (r19.vol || 0).toFixed(2) + " cm³, ideal 96.00)");
}

async function phaseC() {
  console.log("\n— C: real zip through the plugin installer (php-wasm) —");
  const { loadNodeRuntime } = require("@php-wasm/node");
  const { PHP } = require("/home/user/work/harness/node_modules/@php-wasm/node/node_modules/@php-wasm/universal/index.cjs");
  const php = new PHP(await loadNodeRuntime("8.2"));
  try { php.mkdir("/internal"); } catch (e) {}
  try { php.mkdir("/internal/uploads"); } catch (e) {}
  php.writeFile("/internal/rgz-app-packages.php", fs.readFileSync(PLUGIN_DIR + "/rgz-app-packages.php", "utf8"));
  php.writeFile("/internal/uploads/cad-real.zip", new Uint8Array(fs.readFileSync(ZIP_PATH)));

  /* run 1: install the real zip */
  let r = await runPkg(php, "install", {},
    "define('RGZ_PKG_TEST', 1);\n" +
    "$z = '/internal/uploads/cad-real.zip';\n" +
    "$_FILES['rgz_app_package'] = ['name' => 'rgz-3d-cad-studio.zip', 'tmp_name' => $z, 'error' => 0, 'size' => filesize($z)];\n" +
    "$red = 'NO-REDIRECT';\n" +
    "try { RGZ_Mech_App_Packages::handle_upload(); } catch (\\Throwable $ex) { $red = $ex->getMessage() === '__REDIRECT__' ? end($GLOBALS['__redirect']) : 'THROW:' . $ex->getMessage(); }\n" +
    "echo (strpos($red, 'saved=app_pkg') !== false ? 'install-ok' : 'install-fail: ' . $red) . '|';\n" +
    "$reg = RGZ_Mech_App_Packages::registry();\n" +
    "echo (isset($reg['3d-cad-studio']) && $reg['3d-cad-studio']['shortcode'] === 'rgz_3d_cad_studio' ? 'registry-ok' : 'registry-fail') . '|';\n" +
    "$root = RGZ_Mech_App_Packages::apps_root('3d-cad-studio');\n" +
    "$have = ['rgz-app.json','app.php','assets/three.min.js','assets/cad.css','assets/cad.js','assets/cad-geometry-worker.js'];\n" +
    "$miss = []; foreach ($have as $f) { if (!file_exists($root . $f)) { $miss[] = $f; } }\n" +
    "echo (empty($miss) ? 'extract-ok' : 'extract-missing: ' . implode(',', $miss)) . '|';\n" +
    "echo (class_exists('RGZ_CAD_Studio') ? 'testload-ok' : 'testload-fail');");
  const parts = r.out.trim().split("|");
  expect(parts[0] === "install-ok", "installer accepts the real zip (redirect: " + parts[0] + ")");
  expect(parts[1] === "registry-ok", "registry stores 3d-cad-studio with shortcode rgz_3d_cad_studio");
  expect(parts[2] === "extract-ok", "all assets extracted (manifest, app.php, three, css, js, worker)");
  expect(parts[3] === "testload-ok", "entry test-loaded at install time (class present)");

  /* run 2 (fresh request, seeded options): loader + shortcode + render */
  r = await runPkg(php, "load + render", r.state.options || {},
    "RGZ_Mech_App_Packages::load_apps(true);\n" +
    "echo (shortcode_exists('rgz_3d_cad_studio') ? 'shortcode-ok' : 'shortcode-missing') . '|';\n" +
    "$st = RGZ_Mech_App_Packages::runtime_status('3d-cad-studio');\n" +
    "echo $st['status'] . '|';\n" +
    "$html = RGZ_CAD_Studio::render_shortcode([]);\n" +
    "$GLOBALS['__render'] = $html;\n" +
    "echo (strpos($html, 'data-rgzcad') !== false ? 'markup-ok' : 'markup-missing') . '|';\n" +
    "echo (strpos($html, 'data-sketch-canvas') !== false && strpos($html, 'data-steps') !== false ? 'stages-ok' : 'stages-missing') . '|';\n" +
    "echo (strpos($html, 'data-learn') === false && strpos($html, '#learn-cad') !== false ? 'learn-ok' : 'learn-missing') . '|';\n" +
    "echo (strpos($html, '#eb4e3c') !== false || strpos($html, '#EB4E3C') !== false ? 'accent-ok' : 'accent-missing') . '|';\n" +
    "echo (isset($GLOBALS['__localize']['RGZCAD']) && strpos($GLOBALS['__localize']['RGZCAD']['worker'], 'assets/cad-geometry-worker.js') !== false ? 'localize-ok' : 'localize-fail') . '|';\n" +
    "echo (strpos($html, 'data-fullscreen') !== false ? 'fs-ok' : 'fs-missing') . '|';\n" +
    "echo (strpos($html, 'data-opt=\"section\"') !== false && strpos($html, 'data-measure-tag') !== false && strpos($html, 'data-opt=\"measure\"') !== false ? 'inspect-ok' : 'inspect-missing') . '|';\n" +
    "echo (strpos($html, 'data-account-chip') !== false && strpos($html, 'data-auth-modal') !== false && strpos($html, 'data-designs-modal') !== false ? 'account-ok' : 'account-missing') . '|';\n" +
    "echo ((strpos($html, 'CPU') !== false || strpos($html, 'GPU') !== false || strpos($html, 'RAM') !== false || strpos($html, 'WebGL') !== false) ? 'jargon-found' : 'jargon-clean') . '|';\n" +
    "echo (strpos($html, 'data-tree') !== false ? 'tree-ok' : 'tree-missing') . '|';\n" +
    "echo (strpos($html, 'data-tool3d=') !== false ? '3dtools-ok' : '3dtools-missing') . '|';\n" +
    "echo (isset($GLOBALS['__localize']['RGZCAD']['ajaxUrl']) && isset($GLOBALS['__localize']['RGZCAD']['nonce']) ? 'api-ok' : 'api-missing');");
  const p2 = r.out.trim().split("|");
  expect(p2[0] === "shortcode-ok", "loader auto-registers [rgz_3d_cad_studio]");
  expect(p2[1] === "ok" || p2[1] === "warning", "runtime status healthy (got: " + p2[1] + ")");
  expect(p2[2] === "markup-ok", "shortcode renders the app shell");
  expect(p2[3] === "stages-ok", "sketch canvas + 3-step flow present");
  expect(p2[4] === "learn-ok", "no in-app learning section; hub course linked instead");
  expect(p2[5] === "accent-ok", "accent color wired into the markup");
  expect(p2[6] === "localize-ok", "worker URL handed to the front-end");
  expect(p2[7] === "fs-ok", "fullscreen control rendered into the app");
  expect(p2[8] === "inspect-ok", "section + measure tools rendered");
  expect(p2[9] === "account-ok", "account chip + sign-in/designs modals rendered");
  expect(p2[10] === "jargon-clean", "rendered page carries no CPU/GPU/RAM/WebGL jargon for users");
  expect(p2[11] === "tree-ok", "specification tree rendered server-side");
  expect(p2[12] === "3dtools-ok", "sketch-on-face + drill-on-face tools rendered");
  expect(p2[13] === "api-ok", "ajax URL + save nonce handed to the front-end");
  return { html: r.state.render || "", localize: (r.state.localize || {}).RGZCAD || {} };
}

/* ================= Phase D — jsdom: drive the live app ================= */
function phaseD(html, localize) {
  return new Promise(function (resolve) {
    console.log("\n— D: live browser drive (jsdom) —");
    const { JSDOM, VirtualConsole } = require("jsdom");
    const vc = new VirtualConsole();
    const jsErrors = [];
    vc.on("jsdomError", function (e) { var m = String(e.message || e); if (!/WebGL context/i.test(m)) { jsErrors.push(m); } });
    vc.on("error", function (m) { m = String(m); if (!/WebGL context/i.test(m)) { jsErrors.push(m); } });
    const dom = new JSDOM("<!DOCTYPE html><html><head></head><body>" + html + "</body></html>", {
      url: "https://houmanrgz.ir/cad/",
      runScripts: "dangerously",
      pretendToBeVisual: true,
      virtualConsole: vc
    });
    const win = dom.window, doc = win.document;

    /* jsdom has no canvas raster: hand out a permissive 2D stub, null for WebGL
       (proves the app's graceful WebGL-fail + CPU-fallback paths) */
    function ctx2d(cv) {
      return new Proxy({}, {
        get: function (t, k) {
          if (k === "canvas") { return cv; }
          if (k === "measureText") { return function (s) { return { width: 7 * String(s).length }; }; }
          if (k === "getImageData") { return function (x, y, w, h) { return { data: new Uint8ClampedArray(Math.max(4, w * h * 4)) }; }; }
          if (k === "createLinearGradient" || k === "createRadialGradient") { return function () { return { addColorStop: function () {} }; }; }
          if (k === "isPointInPath") { return function () { return false; }; }
          return function () {};
        },
        set: function () { return true; }
      });
    }
    win.HTMLCanvasElement.prototype.getContext = function (kind) {
      if (kind === "2d") { return ctx2d(this); }
      return null;
    };

    win.RGZCAD = localize;
    /* regression seed: a stored design must NOT auto-load at boot (fresh start,
       "the app opens lightly") but must be offered as a one-click Resume */
    win.localStorage.setItem("rgzcad.design.v2", JSON.stringify({
      v: 2, name: "Stored Legacy Part", units: "mm", serverId: null,
      sketches: [{ id: "skOld", name: "Sketch.old", plane: { kind: "xy", origin: [0, 0, 0], u: [1, 0, 0], v: [0, 1, 0], n: [0, 0, 1] }, host: null, entities: [{ id: "eOld", type: "rect", cx: 10, cy: 8, w: 12, h: 9, role: "profile" }] }],
      features: [], activeSketch: "skOld", material: "alu",
      mirror: { on: false, plane: "yz" },
      draw: { hidden: true, center: true, tolOn: true, general: "mK", scale: "auto" }
    }));
    const t = doc.createElement("script"); t.textContent = fs.readFileSync(PKG_DIR + "/assets/three.min.js", "utf8"); doc.body.appendChild(t);
    const c = doc.createElement("script"); c.textContent = fs.readFileSync(PKG_DIR + "/assets/cad.js", "utf8"); doc.body.appendChild(c);

    setTimeout(function () {
      try {
        expect(jsErrors.length === 0, "no uncaught JS errors on boot" + (jsErrors.length ? " (" + jsErrors[0] + ")" : ""));
        expect(!!win.__rgzcad1 && !!win.__rgzcad2 && typeof win.__rgzcadRenderSheet === "function", "boot chain wired (parts 1–3 load and register)");
        const fail = doc.querySelector("[data-webgl-fail]");
        expect(fail && fail.hidden === false, "no WebGL (jsdom) → graceful [data-webgl-fail] notice shown");
        expect(fail && !/WebGL|CPU|GPU|RAM/.test(fail.textContent || ""), "fallback notice is plain language (no jargon)");
        expect(fail && /live 3D preview/i.test(fail.textContent || "") && !!fail.querySelector("[data-gl-retry]"), "fallback notice explains what still works + offers retry");

        const U = win.__rgzcad1;
        /* fresh boot & document actions (complaint: "no New button, does not open lightly") */
        expect(U.S.design.name === "Untitled part" && U.S.design.features.length === 0 && U.S.design.sketches.length === 0,
          "boots with a FRESH empty part — the stored design is not force-loaded");
        /* CATIA start: 3D view with datum planes, tree empty until a plane is picked */
        expect(U.S.step === "plane", "app STARTS in 3D mode with datum planes (step 'plane')");
        expect(doc.querySelector("[data-planehint]") && doc.querySelector("[data-planehint]").hidden === false, "plane-pick hint shown in the 3D view");
        expect(doc.querySelectorAll("[data-datum]").length >= 3, "datum-plane buttons offered (XY / XZ / YZ) in the empty tree");
        expect((doc.querySelector("[data-tree]").textContent || "").indexOf("No sketches yet") !== -1, "tree explains the empty start (no fake default sketch)");
        const resBtn = doc.querySelector("[data-resume]");
        expect(resBtn && resBtn.hidden === false, "the stored browser design is offered as a visible Resume action in the header");
        resBtn.dispatchEvent(new win.MouseEvent("click", { bubbles: true }));
        expect(U.S.design.name === "Stored Legacy Part" && U.sketch().entities.length === 1 && U.S.step === "sketch", "Resume restores the stored design on demand");
        expect(resBtn.hidden === true, "Resume hides after use");
        const newBtn = doc.querySelector(".rgzcad-hero [data-newdesign]");
        expect(!!newBtn, "a New part button lives in the header (always reachable)");
        win.confirm = function () { return true; };
        newBtn.dispatchEvent(new win.MouseEvent("click", { bubbles: true }));
        expect(U.S.design.name === "Untitled part" && U.S.design.sketches.length === 0 && U.S.step === "plane",
          "New part resets to an empty tree, back in the 3D plane-pick state");
        /* picking a datum plane adds Sketch.1 to the tree (the core flow) */
        doc.querySelector('[data-datum="xy"]').dispatchEvent(new win.MouseEvent("click", { bubbles: true }));
        expect(U.S.design.sketches.length === 1 && U.S.design.sketches[0].name === "Sketch.1" && U.S.step === "sketch",
          "picking the XY datum plane adds Sketch.1 to the tree and opens the 2D editor");
        expect((doc.querySelector("[data-tree]").textContent || "").indexOf("Sketch.1") !== -1, "tree lists the new sketch");

        expect(U.iso2768(60, "m") === 0.3 && U.iso2768(10, "f") === 0.1, "ISO 2768-1 auto-tolerance table correct (medium ±0.3 @ 60, fine ±0.1 @ 10)");
        expect(U.tolText({ on: true, plus: 0.1, minus: 0.1 }, 50) === "50 ±0.1", "ISO 406 symmetric format: 50 ±0.1");
        expect(U.tolText({ on: true, plus: 0.015, minus: 0 }, 10).indexOf("+0.015") !== -1, "ISO 406 bilateral format for the H7 hole");
        expect(U.tolText({ on: false, plus: 9, minus: 9 }, 50) === "50", "tolerance off → plain dimension");

        /* ---------- v3 flow: multi-entity sketch -> feature tree -> 3D -> drawing ---------- */
        const padBtn = doc.querySelector('[data-step="model"]');
        const drawBtn = doc.querySelector('[data-step="drawing"]');
        expect(padBtn && padBtn.disabled && drawBtn && drawBtn.disabled, "3D steps locked until a feature exists");
        expect(U.S.mode === "select", "plain-mouse Select tool is the default pointer");
        expect(!!doc.querySelector("[data-tree]"), "specification tree rendered");

        /* per-step layer switching — the 3D layer must not cover the sketch canvas
           (regression for "drawing rotates the 3D view") */
        function vis(el) { return el && !el.hidden; }
        const glWrap = doc.querySelector("[data-gl]"), glBar = doc.querySelector("[data-glbar]");
        const skCv = doc.querySelector("[data-sketch-canvas]"), modeBar = doc.querySelector("[data-modebar]");
        const makeBar = doc.querySelector("[data-makebar]");
        const sheetEl0 = doc.querySelector("[data-sheet]");
        expect(vis(skCv) && vis(modeBar) && vis(makeBar) && glWrap.hidden && glBar.hidden, "sketch step: 2D layer + feature rail on top, 3D layer + toolbar hidden");
        expect(sheetEl0 && sheetEl0.style.display !== "block", "sketch step: drawing sheet hidden");

        /* the famous case: "how is a rectangle not closed?" — drawn shapes are closed profiles by construction */
        U.S.design.name = "Harness Bracket";
        U.sketch().entities.push(U.mkEnt("rect", { cx: 30, cy: 20, w: 60, h: 40 }));
        expect(U.profilesOf(U.sketch()).length === 1, "a rectangle IS a closed profile by construction");

        /* feature rail: every PartDesign tool individually visible, always (complaint: "I could not find some of them") */
        const railPad = doc.querySelector('[data-featmk="pad"]'), railShaft = doc.querySelector('[data-featmk="shaft"]');
        expect(!!railPad && !!railShaft && !!doc.querySelector('[data-featmk="groove"]') && !!doc.querySelector('[data-featmk="rib"]') && !!doc.querySelector('[data-featmk="pocket"]'),
          "feature rail shows every 3D feature tool individually (pad, pocket, shaft, groove, rib)");
        railShaft.dispatchEvent(new win.MouseEvent("click", { bubbles: true }));
        expect(U.S.design.features.length === 0 && /centreline|centerline/i.test((doc.querySelector("[data-stagenote]") || {}).textContent || ""),
          "Shaft without a centreline explains itself in plain words instead of silently failing");
        railPad.dispatchEvent(new win.MouseEvent("click", { bubbles: true }));
        expect(U.S.design.features.length === 1 && U.S.design.features[0].type === "pad", "rail Pad turns the active sketch into Pad.1");
        U.closeSketchToPad();
        expect(U.S.design.features.length === 1 && U.S.design.features[0].type === "pad", "Close sketch -> Pad keeps Pad.1 on the tree (no duplicates)");
        expect(padBtn.disabled === false, "step 2 (3D Features) unlocked after the first pad");

        /* enter 3D: layers flip; come back: sketch layer returns */
        U.setStep("model");
        expect(!glWrap.hidden && !glBar.hidden && skCv.hidden && modeBar.hidden && makeBar.hidden, "model step: 3D layer + toolbar shown, sketch canvas + rail hidden");

        /* dress-up bar: individually visible, acts on the selected feature, editable after */
        const dressDraft = doc.querySelector('[data-dress="draft"]');
        expect(!!dressDraft && !!doc.querySelector('[data-dress="shell"]') && !!doc.querySelector('[data-dress="chamfer"]') && !!doc.querySelector('[data-dress="fillet"]') && !!doc.querySelector('[data-dress="pattern"]') && !!doc.querySelector('[data-dress="mirror"]'),
          "dress-up tools visible individually on the 3D toolbar (chamfer, fillet, draft, shell, pattern, mirror)");
        U.selectFeature(U.S.design.features[0].id);
        function modalOk() { const b = doc.querySelector('[data-cadmodal] [data-m-act="ok"]'); if (b) { b.dispatchEvent(new win.MouseEvent("click", { bubbles: true })); } }
        function modalBtn(id) { const b = doc.querySelector('[data-cadmodal] [data-m-act="' + id + '"]'); if (b) { b.dispatchEvent(new win.MouseEvent("click", { bubbles: true })); } }
        dressDraft.dispatchEvent(new win.MouseEvent("click", { bubbles: true }));
        const draftModal = doc.querySelector("[data-cadmodal]");
        expect(draftModal && !draftModal.hidden && draftModal.classList.contains("on"), "Draft opens its Definition popup first (CATIA rule: every 3D action gets a dialog)");
        modalOk();
        expect(U.S.design.features[0].draftDeg === 3, "Draft dialog applies 3° (defaults offered, exact angle editable)");
        doc.querySelector('[data-dress="shell"]').dispatchEvent(new win.MouseEvent("click", { bubbles: true }));
        modalOk();
        expect(U.S.design.features[0].shellT === 2 && U.S.design.features[0].draftDeg === 0, "Shell dialog applies 2 mm; draft & shell stay mutually exclusive");
        U.S.design.features[0].shellT = 0; U.S.design.features[0].draftDeg = 0;
        doc.querySelector('[data-dress="chamfer"]').dispatchEvent(new win.MouseEvent("click", { bubbles: true }));
        expect(!U.S.armed3d && !doc.querySelector("[data-cadmodal]").hidden, "Chamfer opens its Definition popup (radius + scope) before arming");
        modalBtn("pick");
        expect(U.S.armed3d && U.S.armed3d.kind === "chamfer" && U.S.selFeat === U.S.design.features[0].id,
          "Chamfer dialog's 'Pick edges…' arms CATIA edge-picking on the selected pad");
        doc.querySelector('[data-dress="chamfer"]').dispatchEvent(new win.MouseEvent("click", { bubbles: true }));
        expect(!U.S.armed3d && doc.querySelector("[data-cadmodal]").hidden, "second Chamfer click without marked edges disarms the picker (no popup reopen)");
        doc.querySelector('[data-dress="mirror"]').dispatchEvent(new win.MouseEvent("click", { bubbles: true }));
        doc.querySelector('[data-cadmodal] [data-m-chk="on"]').checked = true;
        modalOk();
        expect(U.S.design.mirror.on === true, "Mirror dialog switches the mirrored copy of the whole part ON");
        doc.querySelector('[data-dress="mirror"]').dispatchEvent(new win.MouseEvent("click", { bubbles: true }));
        doc.querySelector('[data-cadmodal] [data-m-chk="on"]').checked = false;
        modalOk();
        expect(U.S.design.mirror.on === false, "Mirror dialog switches it OFF again");
        /* Feature Definition popup: every 3D action re-editable from one dialog */
        const fD = U.S.design.features[0], prevDL = fD.L;
        U.openFeatureDialog(fD);
        const fmod = doc.querySelector("[data-cadmodal]");
        expect(fmod && !fmod.hidden && fmod.textContent.indexOf("Pad Definition") !== -1, "Pad Definition popup (⚙ in the tree / button on the card)");
        doc.querySelector('[data-m-num="L"]').value = "25";
        doc.querySelector('[data-m-sel="pmode"]').value = "rect";
        doc.querySelector('[data-m-num="pnx"]').value = "3";
        doc.querySelector('[data-m-num="pny"]').value = "1";
        doc.querySelector('[data-cadmodal] [data-m-act="ok"]').dispatchEvent(new win.MouseEvent("click", { bubbles: true }));
        expect(fD.L === 25 && fD.pattern.mode === "rect" && U.instCountOf(fD) === 3,
          "Pad Definition rewrites length + pattern — the model follows");
        fD.pattern.mode = "none"; fD.L = prevDL;
        U.renderAll();
        expect(!!doc.querySelector("[data-tree] [data-featdef]"), "specification tree carries the ⚙ Definition gear on every 3D feature");
        const f0r = U.S.design.features[0];
        f0r.draftDeg = 0; f0r.shellT = 0; f0r.edge = { style: "none", size: 1.5 };
        U.renderAll();
        U.setStep("sketch");
        expect(vis(skCv) && vis(modeBar) && glWrap.hidden && glBar.hidden, "back to sketch: 2D pointer layer restored (rectangle draws, not orbits)");

        /* ---- full sketcher tool-set (CATIA Profile + Operation + Sketch-tools bars) ---- */
        expect(!!doc.querySelector('[data-tool="line"]') && !!doc.querySelector('[data-tool="point"]') &&
          !!doc.querySelector('[data-op2="corner"]') && !!doc.querySelector('[data-op2="chamfer"]') && !!doc.querySelector('[data-op2="trim"]') && !!doc.querySelector('[data-op2="qtrim"]') && !!doc.querySelector('[data-op2="break"]') && !!doc.querySelector('[data-op2="offset"]') && !!doc.querySelector('[data-op2="cons"]') &&
          !!doc.querySelector('[data-geo="h"]') && !!doc.querySelector('[data-geo="v"]') && !!doc.querySelector('[data-geo="par"]') && !!doc.querySelector('[data-geo="perp"]') && !!doc.querySelector('[data-geo="eq"]') && !!doc.querySelector('[data-geo="coin"]') && !!doc.querySelector('[data-geo="con"]') && !!doc.querySelector('[data-geo="tan"]') && !!doc.querySelector('[data-geo="fix"]'),
          "full sketcher set on the bar: line+point, corner/chamfer/trim/quick-trim/break/offset/construction + 9 constraints");
        const skA = U.sketch();
        const baseN = skA.entities.length;
        /* Trim: two crossing lines square up to their intersection corner */
        skA.entities.push(U.mkEnt("line", { a: [200, 150], b: [240, 150] }));
        skA.entities.push(U.mkEnt("line", { a: [220, 140], b: [220, 158] }));
        const lA = skA.entities[baseN], lB = skA.entities[baseN + 1];
        expect(U.trimCorner(lA, lB, [230, 150], [220, 152]) === true && Math.abs(lA.a[0] - 220) < 1e-9 && Math.abs(lA.b[0] - 240) < 1e-9 && Math.abs(lB.a[1] - 150) < 1e-9 && Math.abs(lB.b[1] - 158) < 1e-9,
          "Trim cuts both lines at the intersection and KEEPS the clicked sides (CATIA Trim)");
        /* centerline is a fixed trimming boundary — never modified (CATIA) */
        const cRef = U.mkEnt("cline", { a: [250, 100], b: [250, 180] });
        skA.entities.push(cRef);
        const lRef = U.mkEnt("line", { a: [240, 130], b: [260, 130] });
        skA.entities.push(lRef);
        U.trimCorner(lRef, cRef, [245, 130], [250, 160]);
        expect(cRef.a[1] === 100 && cRef.b[1] === 180 && Math.abs(lRef.b[0] - 250) < 1e-9 && Math.abs(lRef.a[0] - 240) < 1e-9,
          "Trim against a centerline: the reference stays fixed, the line keeps its clicked side");
        skA.entities = skA.entities.filter(function (x) { return x !== cRef && x !== lRef; });
        expect(U.lineLineInt([0, 0], [10, 0], [0, 5], [10, 5]) === null, "parallel lines have no corner (guard)");
        /* Break: line splits at the click point */
        const nbLn = U.breakAtPoint([230, 150]);
        expect(!!nbLn && nbLn.a[0] === 230 && Math.abs(lA.b[0] - 230) < 1e-9, "Break splits a line at the clicked point");
        /* Break: closed ring opens into a chain starting/ending at the break */
        const ring = U.mkEnt("poly", { pts: [[300, 100], [320, 100], [320, 110], [300, 110]], closed: true, kind: "free" });
        skA.entities.push(ring);
        U.breakAtPoint([310, 110]);
        expect(ring.closed === false && ring.pts.length === 6, "Break opens a closed ring into an open polyline");
        /* Offset: inward click on a rectangle → parallel contour 5 mm inside */
        const oRect = U.mkEnt("rect", { cx: 400, cy: 200, w: 60, h: 40 });
        skA.entities.push(oRect);
        U.selectEntity(oRect.id);
        U.S.ui.offsetD = 5;
        const off1 = U.offsetAtPoint([400, 200]);
        expect(!!off1 && off1.type === "poly" && off1.closed &&
          Math.abs(Math.abs(U.polyArea(off1.pts)) - 1500) < 30, "Offset inside → parallel contour d inward (50×30 = 1500 mm²)");
        /* line offset chooses the clicked side */
        U.S.offEnt = null;
        U.selectEntity(lA.id);
        const offL = U.offsetAtPoint([225, 155]);
        expect(!!offL && Math.abs(offL.a[1] - 155) < 0.01 && Math.abs(offL.b[1] - 155) < 0.01, "Offset of a line lands on the clicked side (+5 mm)");
        /* Construction toggle: dashed reference, no longer part of the profile */
        const nProfBefore = U.profilesOf(skA).length;
        oRect.cons = true;
        expect(U.profilesOf(skA).length === nProfBefore - 1, "construction geometry is excluded from the solid profile");
        oRect.cons = false;
        /* Rotate & Scale about the entity center */
        const rRect = U.mkEnt("rect", { cx: 500, cy: 300, w: 20, h: 10 });
        skA.entities.push(rRect);
        U.selectEntity(rRect.id);
        U.S.ui.scaleK = 2; U.S.ui.rotDeg = 90;
        U.entityOp("scale");
        expect(rRect.w === 40 && rRect.h === 20, "Scale ×2 about center works on rects (stays typed)");
        U.entityOp("rotate");
        const rotE = U.entityById(skA, rRect.id);
        expect(rotE && rotE.type === "poly" && rotE.pts.length === 4 && Math.abs(Math.abs(U.polyArea(rotE.pts)) - 800) < 1,
          "Rotate 90° converts a rect into a free polygon, area preserved (800 mm²)");
        /* reference point marker */
        const nProfPt = U.profilesOf(skA).length;
        skA.entities.push(U.mkEnt("point", { cx: 700, cy: 700 }));
        const ptE = skA.entities[skA.entities.length - 1];
        expect(ptE.role === "constr" && U.profilesOf(skA).length === nProfPt, "points are reference markers, never profiles");
        /* tidy the sketch back to its single driving profile */
        const junk = [lA.id, lB.id, nbLn.id, ring.id, oRect.id, off1.id, offL ? offL.id : "x", rRect.id, ptE.id];
        skA.entities = skA.entities.filter(function (e2) { return junk.indexOf(e2.id) === -1; });
        U.S.offEnt = null;
        U.selectEntity(null);
        U.renderAll();
        expect(U.profilesOf(skA).length === 1, "test entities cleaned up (sketch back to its pad profile)");

        /* ==================== Update 17 — CATIA-class sketcher, deep tests ==================== */
        const skL = U.startSketchOnDatum("xy");
        /* (3) a square drawn with the LINE tool is a closed profile */
        [[[300, 300], [340, 300]], [[340, 300], [340, 330]], [[340, 330], [300, 330]], [[300, 330], [300, 300]]].forEach(function (sg) {
          skL.entities.push(U.mkEnt("line", { a: sg[0], b: sg[1] }));
        });
        expect(U.profilesOf(skL).length === 1, "a square of Line segments IS one closed profile (was: not a surface at all)");
        const loops1 = U.loopsFromChains(skL);
        expect(loops1.length === 1 && Math.abs(Math.abs(U.polyArea(loops1[0])) - 1200) < 1e-6, "chain face extraction exact: 40×30 → 1200 mm²");
        expect(U.sketchOpenProfile(skL) === null, "a fully connected line chain is not an 'open profile' (honest status)");
        U.padSketch(skL.id);
        const padL = U.S.design.features[U.S.design.features.length - 1];
        padL.L = 25;
        expect(Math.abs(U.featureVol(padL) - 30000) < 1e-6, "pad from a Line-drawn square: volume exact (1200 mm² × 25 mm)");
        /* a chord between real junction nodes splits the square into two exact faces
           (T-crossing a segment is not a junction in CATIA either — Break it first) */
        const chordIds = [];
        [[[600, 300], [615, 300]], [[615, 300], [630, 300]], [[630, 300], [630, 340]],
         [[630, 340], [615, 340]], [[615, 340], [600, 340]], [[600, 340], [600, 300]],
         [[615, 300], [615, 340]]].forEach(function (sg) {
          const ce = U.mkEnt("line", { a: sg[0], b: sg[1] });
          skL.entities.push(ce); chordIds.push(ce.id);
        });
        const loops2 = U.loopsFromChains(skL);
        const tot2 = loops2.reduce(function (a2, l2) { return a2 + Math.abs(U.polyArea(l2)); }, 0);
        expect(loops2.length === 3 && Math.abs(tot2 - 2400) < 1e-6, "a chord between real junctions splits a face in two (15×40 + 15×40 + the original square)");
        skL.entities = skL.entities.filter(function (e2) { return chordIds.indexOf(e2.id) === -1; });

        /* (4) pick ONE vertical edge in 3D for fillet/chamfer (CATIA edge selection) */
        const edgeCtx = U.profileEdgesFor(padL);
        expect(!!edgeCtx && edgeCtx.edges.length === 4, "each vertical edge of the pad is individually addressable (4 here)");
        padL.edgeSel = ["0:1"]; U.S.armed3d = { kind: "chamfer" }; U.S.selFeat = padL.id; U.S.ui.chamferD = 2;
        U.applyEdgeSelection(padL);
        expect(padL.edgeOps.length === 1 && padL.edgeOps[0].style === "chamfer" && padL.edgeOps[0].vi === 1 && !U.S.armed3d,
          "chamfer applies to exactly the ONE picked edge (not the whole part)");
        expect(Math.abs(U.featureVol(padL) - (30000 - 0.5 * 2 * 2 * 1 * 25)) < 0.01, "one-edge chamfer removes exactly ½d² × L (" + Math.round(U.featureVol(padL)) + " mm³)");
        padL.edgeSel = ["0:3"]; U.S.armed3d = { kind: "fillet" }; U.S.selFeat = padL.id; U.S.ui.filletR = 4;
        U.applyEdgeSelection(padL);
        const expMix = 30000 - 50 - (16 - 4 * Math.PI) * 25;
        expect(padL.edgeOps.length === 2 && Math.abs(U.featureVol(padL) - expMix) < 0.01, "picked-edge fillet + chamfer coexist on the same feature, volume exact");
        padL.edgeSel = ["0:1"]; U.S.armed3d = { kind: "fillet" }; U.S.selFeat = padL.id;
        U.applyEdgeSelection(padL);
        expect(padL.edgeOps.length === 2 && padL.edgeOps[1].style === "fillet" && padL.edgeOps[1].vi === 1, "re-dressing an edge replaces its op (no stacking)");
        const dRT = U.normalizeDesign(JSON.parse(JSON.stringify(U.S.design)));
        expect(dRT.features.some(function (f2) { return (f2.edgeOps || []).length === 2; }), "picked-edge dress-ups survive save/load normalisation");
        padL.edgeOps = [];

        /* (6) hole correctness — cuts only where there really is material */
        const vNoHole = U.featureVol(padL);
        expect(Math.abs(vNoHole - 30000) < 1e-6, "baseline clean after undressing edges");
        const hOut = U.mkEnt("hole", { cx: 950, cy: 950, r: 5, hType: "through", depth: 10, cbd: 14, cbdDepth: 3, csAngle: 90 });
        skL.entities.push(hOut);
        expect(Math.abs(U.featureVol(padL) - vNoHole) < 1e-9, "a hole OUTSIDE the solid removes nothing (was silently over-subtracted)");
        const hIn = U.mkEnt("hole", { cx: 320, cy: 315, r: 5, hType: "through", depth: 10, cbd: 14, cbdDepth: 3, csAngle: 90 });
        skL.entities.push(hIn);
        expect(Math.abs(U.featureVol(padL) - (vNoHole - Math.PI * 25 * 25)) < 1e-6, "a hole INSIDE cuts exactly π·r²·L through the pad");
        expect(U.holeHasMaterial(U.classifyContours(U.profilesOf(skL).map(function (p2) { return p2.pts; })), hIn) === true &&
          U.holeHasMaterial(U.classifyContours(U.profilesOf(skL).map(function (p2) { return p2.pts; })), hOut) === false,
          "hole placement is validated against real material (inside vs outside)");
        skL.entities = skL.entities.filter(function (e2) { return e2.id !== hIn.id; });

        /* (1) multi-select — Ctrl toggling + window/crossing rubber box */
        const m1 = U.mkEnt("line", { a: [400, 300], b: [430, 300] });
        const m2 = U.mkEnt("line", { a: [400, 310], b: [430, 312] });
        const m3 = U.mkEnt("line", { a: [450, 295], b: [460, 320] });
        [m1, m2, m3].forEach(function (e2) { skL.entities.push(e2); });
        U.selectEntity(m1.id); U.selectEntity(m2.id, true);
        expect(U.selEnts().length === 2 && U.isSel(m2.id), "Ctrl+click adds to the selection (multi-select on)");
        U.selectEntity(m2.id, true);
        expect(U.selEnts().length === 1 && U.isSel(m1.id), "Ctrl+click on a selected element toggles it back off");
        const winIds = U.entsInRect(skL, [398, 298, 432, 306], false);
        const crossIds = U.entsInRect(skL, [449, 298, 455, 305], true);
        expect(winIds.length === 1 && winIds[0] === m1.id, "window box (left→right) selects only fully-inside elements");
        expect(crossIds.length === 1 && crossIds[0] === m3.id, "crossing box (right→left) grabs merely-touched elements (CATIA)");
        skL.entities = skL.entities.filter(function (e2) { return [m1.id, m2.id, m3.id].indexOf(e2.id) === -1; });

        /* (2b) Quick Trim — one click erases the clicked piece */
        const q1 = U.mkEnt("line", { a: [500, 300], b: [540, 300] });
        const q2 = U.mkEnt("line", { a: [520, 290], b: [520, 310] });
        skL.entities.push(q1); skL.entities.push(q2);
        U.selectEntity(null);
        const qk = U.quickTrimAt([530, 300]);
        expect(qk === q1 && Math.abs(q1.b[0] - 520) < 1e-9, "Quick Trim: clicked end erased at the nearest crossing");
        U.quickTrimAt([505, 300]);
        expect(!skL.entities.some(function (e2) { return e2.id === q1.id; }), "Quick Trim with no remaining crossings deletes the element (CATIA)");
        /* middle piece between two crossings */
        const rLow = U.mkEnt("line", { a: [510, 295], b: [530, 295] });
        const rHigh = U.mkEnt("line", { a: [510, 305], b: [530, 305] });
        skL.entities.push(rLow); skL.entities.push(rHigh);
        U.quickTrimAt([520, 301]);
        const midPiece = skL.entities.some(function (e2) { return e2.type === "line" && Math.abs(e2.a[0] - 520) < 1e-9 && Math.abs(e2.a[1] - 305) < 1e-9 && Math.abs(e2.b[1] - 310) < 1e-9; });
        expect(Math.abs(q2.b[1] - 295) < 1e-9 && midPiece, "Quick Trim between two crossings erases the middle, keeping both end pieces");
        skL.entities = skL.entities.filter(function (e2) { return [q2.id, rLow.id, rHigh.id].indexOf(e2.id) === -1; });

        /* (5) geometric constraints — applied now, badged, remembered */
        const g1 = U.mkEnt("line", { a: [600, 300], b: [640, 306] });
        const g2 = U.mkEnt("line", { a: [600, 320], b: [630, 350] });
        skL.entities.push(g1); skL.entities.push(g2);
        U.selectEntity(g1.id);
        expect(U.applyGeo("h") === 1 && g1.b[1] === g1.a[1], "Horizontal constraint makes the line exactly horizontal");
        expect(g1.geo.length === 1 && g1.geo[0].t === "h", "constraint stored on the element (badge on canvas, chip in panel)");
        U.selectEntity(g1.id); U.selectEntity(g2.id, true);
        expect(U.applyGeo("par") === 1 && Math.abs(Math.atan2(g2.b[1] - g2.a[1], g2.b[0] - g2.a[0])) < 1e-9, "Parallel: second line takes the reference angle");
        expect(U.applyGeo("perp") === 1 && Math.abs(g2.b[0] - g2.a[0]) < 1e-9, "Perpendicular: second line now exactly vertical");
        const len1 = Math.hypot(g1.b[0] - g1.a[0], g1.b[1] - g1.a[1]);
        expect(U.applyGeo("eq") === 1 && Math.abs(Math.hypot(g2.b[0] - g2.a[0], g2.b[1] - g2.a[1]) - len1) < 1e-9, "Equal length applied to the second line");
        const g3 = U.mkEnt("line", { a: [700, 300], b: [740.4, 300] });
        const g4 = U.mkEnt("line", { a: [739.9, 300], b: [740, 330] });
        skL.entities.push(g3); skL.entities.push(g4);
        U.selectEntity(g3.id); U.selectEntity(g4.id, true);
        U.applyGeo("coin");
        expect(g4.a[0] === 740.4 && g4.a[1] === 300, "Coincident snaps nearest endpoints exactly together");
        const g5 = U.mkEnt("circle", { cx: 800, cy: 320, r: 15 });
        const g6 = U.mkEnt("line", { a: [780, 345], b: [830, 345] });
        skL.entities.push(g5); skL.entities.push(g6);
        U.selectEntity(g5.id); U.selectEntity(g6.id, true);
        U.applyGeo("tan");
        expect(Math.abs(Math.abs(g6.a[1] - g5.cy) - 15) < 1e-9, "Tangent: line sits exactly one radius from the center");
        const g7 = U.mkEnt("circle", { cx: 850, cy: 322, r: 8 });
        skL.entities.push(g7);
        U.selectEntity(g5.id); U.selectEntity(g7.id, true);
        U.applyGeo("con");
        expect(g7.cx === 800 && g7.cy === 320, "Concentric: second circle takes the reference center");
        U.selectEntity(g6.id); U.applyGeo("fix");
        expect(g6.locked === true, "Fix locks an element");
        U.selectEntity(g5.id); U.selectEntity(g6.id, true);
        expect(U.applyGeo("con") === 0, "locked elements ignore constraint edits");
        U.selectEntity(g6.id); U.applyGeo("fix");
        expect(g6.locked === false, "Fix toggles back off");
        const gids = [g1.id, g2.id, g3.id, g4.id, g5.id, g6.id, g7.id];
        skL.entities = skL.entities.filter(function (e2) { return gids.indexOf(e2.id) === -1; });
        U.selectEntity(null);

        /* ==================== Update 18 — Trim works against closed shapes, all elements ==================== */
        const skT = U.startSketchOnDatum("xy");
        /* (a) Trim: line × circle — the user's exact report */
        const cT = U.mkEnt("circle", { cx: 100, cy: 0, r: 20 });
        const lT = U.mkEnt("line", { a: [40, 0], b: [160, 0] });
        skT.entities.push(cT); skT.entities.push(lT);
        U.selectEntity(null);
        expect(U.trimCorner(lT, cT, [90, 0], [100, -18]) === true &&
          Math.abs(lT.a[0] - 80) < 1e-9 && Math.abs(lT.b[0] - 160) < 1e-9,
          "line × circle Trim cuts the line at the intersection (clicked side kept) — was: refused outright");
        expect(cT.type === "poly" && cT.closed === false && cT.pts.length > 10,
          "circle becomes an open arc chain after Trim (CATIA arc), still sketch geometry");
        /* the kept arc is the clicked (lower) side */
        const maxY = Math.max.apply(null, cT.pts.map(function (q) { return q[1]; }));
        expect(maxY < 16, "kept arc = clicked side of the circle (upper click-piece removed)");
        /* used-to-be-circle is no longer a closed profile; the chain CAN reclose */
        expect(U.profilesOf(skT).length === 0, "after modification, closed-shape status is re-evaluated honestly (arc chain is open)");
        /* (b) Trim line × rectangle edge — the rectangle's edge is a real curve */
        const rT = U.mkEnt("rect", { cx: 300, cy: 0, w: 40, h: 20 });
        const lT2 = U.mkEnt("line", { a: [240, 0], b: [360, 0] });
        skT.entities.push(rT); skT.entities.push(lT2);
        rT._trimEdge = 1;   /* the right vertical edge (what a user clicks) */
        expect(U.trimCorner(lT2, rT, [350, 0], [324, 4]) === true && Math.abs(lT2.a[0] - 320) < 1e-9 && Math.abs(lT2.b[0] - 360) < 1e-9,
          "line × rectangle-edge Trim cuts the line at the edge crossing, clicked side kept");
        expect(rT.type === "poly" && rT.closed === false && rT.pts.length === 6,
          "trimmed rectangle opens into a chain at the cut edge (CATIA consequence, not a failure)");
        /* (c) Quick Trim on a circle between two crossing lines */
        const cQ = U.mkEnt("circle", { cx: 500, cy: 0, r: 15 });
        const qA = U.mkEnt("line", { a: [490, -20], b: [490, 20] });
        const qB = U.mkEnt("line", { a: [510, -20], b: [510, 20] });
        skT.entities.push(cQ); skT.entities.push(qA); skT.entities.push(qB);
        U.quickTrimAt([500, 15]);   /* the top arc */
        expect(cQ.type === "poly" && cQ.closed === false && Math.max.apply(null, cQ.pts.map(function (q) { return q[1]; })) < 14.6,
          "Quick Trim on a circle erases the clicked arc (between both crossings), keeps the rest");
        skT.entities = skT.entities.filter(function (x) { return [cQ.id, qA.id, qB.id].indexOf(x.id) === -1; });
        /* (d) Quick Trim of a rectangle edge with no crossing on it: the edge is erased, ring opens */
        const rQ = U.mkEnt("rect", { cx: 700, cy: 0, w: 40, h: 20 });
        const qC = U.mkEnt("line", { a: [670, 0], b: [730, 0] });
        skT.entities.push(rQ); skT.entities.push(qC);
        expect(U.profilesOf(skT).some(function (p2) { return p2.ent === rQ; }), "rectangle is a closed profile before the edit");
        U.quickTrimAt([700, 10]);   /* the top edge has no crossing on it */
        expect(rQ.type === "poly" && rQ.closed === false && rQ.pts.length === 4 &&
          !U.profilesOf(skT).some(function (p2) { return p2.ent === rQ; }),
          "Quick Trim erases the clicked rectangle edge — the closed shape is honestly open now");
        /* (e) Break works on circles too — same principle for all elements */
        const cB = U.mkEnt("circle", { cx: 900, cy: 0, r: 10 });
        skT.entities.push(cB);
        expect(U.breakAtPoint([910, 0]) === cB && cB.type === "poly" && cB.closed === false && cB.pts.length > 40,
          "Break on a circle opens it at the click into an arc chain");
        /* (f) honest miss: a line that does NOT reach the circle does not fake a trim */
        const cM = U.mkEnt("circle", { cx: 1100, cy: 0, r: 10 });
        const lM = U.mkEnt("line", { a: [1050, 30], b: [1080, 30] });
        skT.entities.push(cM); skT.entities.push(lM);
        expect(U.trimCorner(lM, cM, [1060, 30], [1100, -9]) === false && lM.a[0] === 1050 && cM.type === "circle",
          "no intersection → clear message, geometry untouched (CATIA-honest)");
        U.deleteSketch(skT.id);
        U.selectSketch(skA.id);

        /* tidy: back to exactly the pre-block state (one sketch, one pad) */
        U.deleteFeature(padL.id);
        U.deleteSketch(skL.id);
        U.selectSketch(skA.id);
        expect(U.S.design.sketches.length === 1 && U.S.design.features.length === 1, "isolated Update-17 tests leave the studio exactly as before");

        /* ==================== Update 19 — full constraint engine (all pairings, solver, DOF, CATIA colors) ==================== */
        const skC = U.startSketchOnDatum("xy");
        /* tangency between a CIRCLE and the SIDE OF A RECTANGLE — the user's exact report */
        const rc1 = U.mkEnt("rect", { cx: 30, cy: 20, w: 60, h: 40 });        /* right side x = 60 */
        const cc1 = U.mkEnt("circle", { cx: 78, cy: 20, r: 8 });
        skC.entities.push(rc1); skC.entities.push(cc1);
        U.selectEntity(rc1.id); U.selectEntity(cc1.id, true);
        expect(U.applyGeo("tan") === 1 && Math.abs(cc1.cx - 68) < 1e-9 && Math.abs(cc1.cy - 20) < 1e-9,
          "Tangent: circle snaps onto the rectangle SIDE (first selection = fixed reference)");
        expect(cc1.geo.some(function (g) { return g.t === "tan" && g.ref === rc1.id; }), "tangency rule stored on the adapting circle");
        /* reverse roles: circle = reference, rectangle adapts */
        const rc2 = U.mkEnt("rect", { cx: 150, cy: 20, w: 20, h: 40 });       /* left side x = 140 */
        const cc2 = U.mkEnt("circle", { cx: 120, cy: 20, r: 10 });            /* rightmost x = 130 */
        skC.entities.push(rc2); skC.entities.push(cc2);
        U.selectEntity(cc2.id); U.selectEntity(rc2.id, true);
        U.applyGeo("tan");
        expect(Math.abs((rc2.cx - rc2.w / 2) - (cc2.cx + cc2.r)) < 1e-9, "Tangent with the circle as the reference: the rectangle side moves onto it");
        /* circle × circle — external tangency */
        const cc3 = U.mkEnt("circle", { cx: 0, cy: 0, r: 10 });
        const cc4 = U.mkEnt("circle", { cx: 30, cy: 0, r: 10 });
        skC.entities.push(cc3); skC.entities.push(cc4);
        U.selectEntity(cc3.id); U.selectEntity(cc4.id, true);
        U.applyGeo("tan");
        expect(Math.abs(cc4.cx - 20) < 1e-9 && Math.abs(cc4.cy) < 1e-9, "Tangent circle-to-circle: centres exactly r1 + r2 apart (external)");
        /* solver: rules HOLD when elements move afterwards ("move respective to those rules") */
        cc1.cy = 55; U.solveConstraints(skC);
        expect(Math.abs(cc1.cx - 68) < 1e-9 && Math.abs(cc1.cy - 55) < 1e-9,
          "solver: the tangent circle slides ALONG the side but cannot leave it (CATIA)");
        rc1.cx += 10; U.solveConstraints(skC);
        expect(Math.abs(cc1.cx - 62) < 1e-9 && cc1.geo[0].edge === 1,
          "solver: moving the reference side drags the tangent circle with it — locked to THAT side (CATIA)");
        expect(U.sizeLabelOf(rc1) === "60 × 40", "measured size label on the sketch (W × H)");
        /* DOF accounting: fully constrained state + over-constraint refusal */
        const dl = U.mkEnt("line", { a: [300, 100], b: [340, 100] });
        const rf1 = U.mkEnt("line", { a: [300, 130], b: [350, 132] });
        const rf2 = U.mkEnt("line", { a: [300, 160], b: [350, 162] });
        skC.entities.push(dl); skC.entities.push(rf1); skC.entities.push(rf2);
        U.selectEntity(dl.id); U.applyGeo("h");
        U.selectEntity(dl.id); U.applyGeo("v");
        U.selectEntity(rf1.id); U.selectEntity(dl.id, true); U.applyGeo("eq");
        U.selectEntity(rf2.id); U.selectEntity(dl.id, true); U.applyGeo("par");
        expect(U.dofLeft(skC, dl) === 0 && U.constraintState(skC, dl) === "full",
          "4 DOF consumed → element reports FULLY CONSTRAINED (green in the sketch, CATIA)");
        const dlAx = dl.a[0], dlAy = dl.a[1];
        U.selectEntity(rf1.id); U.selectEntity(dl.id, true);
        const overRC = U.applyGeo("coin");
        const overNote = (doc.querySelector("[data-stagenote]") || {}).textContent || "";
        expect(overRC === 0 && dl.a[0] === dlAx && dl.a[1] === dlAy && overNote.indexOf("Over-constraint") !== -1,
          "over-constraint is REFUSED with an explanation, nothing moves (CATIA-true)");
        U.selectEntity(dl.id);
        expect(U.applyGeo("h") === 0, "re-applying an existing rule is refused as redundant");
        dl.geo = dl.geo.filter(function (g) { return g.t !== "eq"; });
        expect(U.dofLeft(skC, dl) === 1 && U.constraintState(skC, dl) === "under", "removing a rule frees its DOF again");
        U.selectEntity(cc4.id); U.applyGeo("fix");
        expect(U.constraintState(skC, cc4) === "fix", "locked element reports the fixed state (violet in the sketch)");

        /* Hole Definition popup: ISO metric thread drives the tapping drill */
        U.selectSketch(skC.id);
        U.openHoleDialog(null, { sk: skC });
        const hmod = doc.querySelector("[data-cadmodal]");
        expect(hmod && !hmod.hidden && hmod.textContent.indexOf("Thread (ISO metric)") !== -1, "Hole Definition popup opens with the thread section");
        const thSel = doc.querySelector('[data-m-sel="mthread"]');
        thSel.value = "M8"; thSel.dispatchEvent(new win.Event("change"));
        const diaInp = doc.querySelector('[data-m-num="dia"]');
        expect(diaInp && diaInp.disabled && Math.abs(parseFloat(diaInp.value) - 6.8) < 1e-9,
          "choosing M8 locks the drill to the ISO tapping size Ø6.8");
        doc.querySelector('[data-cadmodal] [data-m-act="ok"]').dispatchEvent(new win.MouseEvent("click", { bubbles: true }));
        const newHole = skC.entities[skC.entities.length - 1];
        expect(newHole && newHole.type === "hole" && newHole.thread.on && newHole.thread.iso === "M8" &&
          Math.abs(newHole.r - 3.4) < 1e-9 && Math.abs(newHole.thread.pitch - 1.25) < 1e-9,
          "placed hole is a threaded M8 (tap drill Ø6.8, pitch 1.25)");
        expect(U.holeTypeLabel(newHole).indexOf("M8") !== -1, "tree/label carry the thread designation");
        U.openHoleDialog(newHole, { sk: skC });
        const tSel2 = doc.querySelector('[data-m-sel="mthread"]'); tSel2.value = ""; tSel2.dispatchEvent(new win.Event("change"));
        const hSel2 = doc.querySelector('[data-m-sel="hType"]'); hSel2.value = "blind"; hSel2.dispatchEvent(new win.Event("change"));
        doc.querySelector('[data-m-num="depth"]').value = "12";
        doc.querySelector('[data-m-num="dia"]').value = "7";
        doc.querySelector('[data-cadmodal] [data-m-act="ok"]').dispatchEvent(new win.MouseEvent("click", { bubbles: true }));
        expect(newHole.hType === "blind" && newHole.depth === 12 && Math.abs(newHole.r - 3.5) < 1e-9 && !newHole.thread.on,
          "the SAME hole re-edits through its Definition popup (type, depth, Ø, thread off)");
        expect(doc.querySelector("[data-cadmodal]").hidden, "modal closes after OK");

        U.deleteSketch(skC.id);
        U.selectSketch(skA.id);
        expect(U.S.design.sketches.length === 1, "Update-19 sketch tests leave the studio clean");

        /* datum planes are real carriers: a pad on the upright XZ plane behaves exactly like on XY */
        const skXZ = U.startSketchOnDatum("xz");
        expect(skXZ && skXZ.plane && skXZ.plane.kind === "xz" && skXZ.plane.n[1] === -1 && U.S.step === "sketch",
          "XZ datum creates an upright-plane sketch and adds it to the tree");
        skXZ.entities.push(U.mkEnt("rect", { cx: 15, cy: 10, w: 30, h: 20 }));
        U.padSketch(skXZ.id);
        const fXZ = U.S.design.features[U.S.design.features.length - 1];
        expect(Math.abs(U.featureVol(fXZ) - 12000) < 1, "pad on XZ extrudes along the plane normal (vol exact, 600 × 20)");
        U.deleteFeature(fXZ.id);
        U.deleteSketch(skXZ.id);
        U.selectSketch(skA.id);
        expect(U.S.design.sketches.length === 1, "sketches are deletable down to any count");
        /* deleting ALL sketches returns the app to the 3D plane-pick state */
        U.deleteSketch(skA.id);
        expect(U.S.design.sketches.length === 0 && U.S.step === "plane", "deleting the last sketch returns to the datum-plane start");
        const skRe = U.startSketchOnDatum("xy");
        skRe.entities.push(U.mkEnt("rect", { cx: 30, cy: 20, w: 60, h: 40 }));
        U.padSketch(skRe.id);
        U.setStep("sketch");

        /* 2D canvas backing store tracks the real pane size (no 300×150 default blur) */
        const vp0 = doc.querySelector("[data-viewport]");
        if (vp0) {
          Object.defineProperty(vp0, "clientWidth", { value: 800, configurable: true });
          Object.defineProperty(vp0, "clientHeight", { value: 600, configurable: true });
          U.skResize();
          expect(skCv.width === 800, "sketch canvas backing store matches the pane (crisp: " + skCv.width + "px, not the 300px canvas default)");
        }
        expect(doc.querySelector("[data-tree]").textContent.indexOf("Sketch.1") !== -1, "tree lists Sketch.1");

        /* multi-entity sketches: two independent closed profiles in ONE sketch */
        const sk1 = U.sketch();
        sk1.entities.push(U.mkEnt("rect", { cx: 80, cy: 60, w: 18, h: 12 }));
        expect(U.profilesOf(sk1).length === 2, "one sketch holds many separate profiles (2 profiles now)");

        /* free polygon stays open UNTIL closed — and Close->Pad auto-closes a 3+ point chain */
        sk1.entities = sk1.entities.filter(function (e2) { return e2.type !== "rect" || e2.w !== 18; });
        sk1.entities.push(U.mkEnt("poly", { pts: [[0, 0], [30, 0], [30, 20], [20, 20], [20, 30], [0, 30]], closed: false, kind: "free" }));
        expect(U.profilesOf(sk1).length === 1, "open polygon is not a profile yet (honest feedback)");
        U.closeSketchToPad();
        expect(sk1.entities.some(function (e2) { return e2.kind === "free" && e2.closed; }), "Close sketch -> Pad auto-closes open polygons of 3+ points");
        expect(U.S.design.features.length === 1, "same pad kept (no duplicate feature for the same sketch)");

        /* self-crossing contours are rejected with a clear message (complex-sketch guard) */
        const bad = U.mkEnt("poly", { pts: [[0, 0], [40, 0], [0, 30], [40, 30]], closed: false, kind: "free" });
        sk1.entities.push(bad);
        sk1.entities = sk1.entities.filter(function (e2) { return e2.id !== bad.id; });
        expect(U.selfIntersects(bad.pts) === true, "self-intersection detector catches bowtie contours");

        /* holes, counterbore */
        sk1.entities.push(U.mkEnt("hole", { cx: 15, cy: 10, r: 5, hType: "cbore", depth: 0, cbd: 16, cbdDepth: 4, csAngle: 90, tol: { d: { on: true, plus: 0.015, minus: 0 } } }));
        U.padSketch(sk1.id);

        /* sketch on a (top) face — arm the pick like the toolbar button, then feed the raycast hit */
        const beforeSk = U.S.design.sketches.length;
        U.armFacePick("facesketch");
        expect(U.S.armed3d === "facesketch", "face-pick mode armed from the toolbar");
        U.onFacePicked({
          host: U.S.design.features[0].id, flatTopBottom: true,
          plane: { kind: "faceTop", topOf: U.S.design.features[0].id, origin: [0, 0, 20], u: [1, 0, 0], v: [0, 1, 0], n: [0, 0, 1] },
          outline: [[0, 0], [30, 0], [30, 20], [20, 20], [20, 30], [0, 30]], label: "On Pad.1 (top face)"
        });
        expect(U.S.design.sketches.length === beforeSk + 1, "new sketch created on the picked face");
        expect(U.S.step === "sketch", "app jumps straight into the face sketch");
        const faceSk = U.sketch();
        faceSk.entities.push(U.mkEnt("circle", { cx: 10, cy: 10, r: 6 }));
        U.padSketch(faceSk.id);
        expect(U.S.design.features.length === 2, "face sketch padded -> Pad.2 on the tree");
        expect(U.S.design.features[1].sketchId === faceSk.id, "Pad.2 references the face sketch");

        /* pocket feature carves volume analytically */
        const volBefore = U.partVol();
        const sk3 = U.sketch();
        U.S.design.sketches.push({ id: "skP", name: "Sketch.pocket", plane: { kind: "faceTop", topOf: U.S.design.features[0].id, origin: [0, 0, 20], u: [1, 0, 0], v: [0, 1, 0], n: [0, 0, 1] }, host: U.S.design.features[0].id, entities: [U.mkEnt("rect", { cx: 5, cy: 5, w: 10, h: 8 })] });
        U.pocketFromSketch("skP");
        expect(U.S.design.features.length === 3 && U.S.design.features[2].type === "pocket", "pocket feature on the tree");
        expect(U.partVol() < volBefore, "pocket removes volume (" + Math.round(volBefore / 1000) + " -> " + Math.round(U.partVol() / 1000) + " cm3)");
        U.selectSketch(sk1.id);

        /* nested profile: a circle drawn inside a rectangle becomes a HOLE after pad (CATIA rule) */
        const skV = U.newSketchOnPlane(U.basePlane(), null, "Sketch.void");
        skV.entities.push(U.mkEnt("rect", { cx: 30, cy: 20, w: 60, h: 40 }));
        skV.entities.push(U.mkEnt("circle", { cx: 30, cy: 20, r: 10 }));
        U.closeSketchToPad();
        const voidFt = U.S.design.features[U.S.design.features.length - 1];
        const expV = (2400 - Math.PI * 100) * 20;
        expect(voidFt && Math.abs(U.featureVol(voidFt) - expV) < expV * 0.02, "circle inside rectangle = hole after pad (vol " + Math.round(U.featureVol(voidFt || {})) + " mm³, ideal " + Math.round(expV) + ")");

        /* sketches are fully user-controlled: deletable straight from the tree */
        const nSkBefore = U.S.design.sketches.length;
        const delBtn = doc.querySelector('[data-delsk="' + skV.id + '"]');
        expect(!!delBtn, "every sketch node in the tree carries a delete button");
        if (delBtn) { delBtn.dispatchEvent(new win.MouseEvent("click", { bubbles: true, cancelable: true })); }
        expect(U.S.design.sketches.length === nSkBefore - 1 && U.S.design.features.indexOf(voidFt) === -1, "tree × on a sketch removes the sketch AND its feature");

        /* wheel zoom on the sketch canvas, anchored to the cursor */
        U.setStep("sketch");
        const zBefore = U.S.cam.z;
        const wpBefore = U.s2w(100, 80);
        skCv.dispatchEvent(new win.WheelEvent("wheel", { deltaY: -240, clientX: 100, clientY: 80, bubbles: true, cancelable: true }));
        const wpAfter = U.s2w(100, 80);
        expect(U.S.cam.z > zBefore, "mouse wheel zooms the sketch view (z " + zBefore.toFixed(2) + " -> " + U.S.cam.z.toFixed(2) + ")");
        expect(Math.abs(wpBefore[0] - wpAfter[0]) < 0.6 && Math.abs(wpBefore[1] - wpAfter[1]) < 0.6, "wheel zoom stays anchored under the cursor");

        /* ---- CATIA PartDesign: shaft, groove, rib, draft, shell, patterns, mirror, thread ---- */
        /* shaft (revolve) from a profile + vertical centreline */
        const skS = U.newSketchOnPlane(U.basePlane(), null, "Sketch.shaft");
        skS.entities.push(U.mkEnt("cline", { a: [20, 0], b: [20, 30] }));
        skS.entities.push(U.mkEnt("rect", { cx: 25, cy: 5, w: 10, h: 10 }));
        expect(U.sketchAxisCline(skS) === 20, "revolve axis read from the vertical centreline");
        U.revolveSketch(skS.id, "shaft");
        const shaftF = U.S.design.features[U.S.design.features.length - 1];
        const expSh = 100 * 2 * Math.PI * 5;       /* A=100 mm² at dC=5 mm (Pappus) */
        expect(shaftF.type === "shaft" && Math.abs(U.featureVol(shaftF) - expSh) < expSh * 0.01, "Shaft: profile revolved about the axis (vol " + Math.round(U.featureVol(shaftF)) + " mm³, ideal " + Math.round(expSh) + ")");
        shaftF.angle = 180;
        expect(Math.abs(U.featureVol(shaftF) - expSh / 2) < expSh * 0.01, "shaft angle 180° halves the revolved volume");
        expect(Math.abs(U.featureVol(Object.assign({}, shaftF, { type: "groove" })) + expSh / 2) < 1, "groove is the negative revolve (cut)");

        /* rib from an open polyline */
        const skR = U.newSketchOnPlane(U.basePlane(), null, "Sketch.rib");
        skR.entities.push(U.mkEnt("poly", { pts: [[0, 0], [40, 0]], closed: false, kind: "free" }));
        U.ribFromSketch(skR.id);
        const ribF = U.S.design.features[U.S.design.features.length - 1];
        ribF.L = 10; ribF.t = 4;
        expect(ribF.type === "rib" && Math.abs(U.featureVol(ribF) - 1600) < 1600 * 0.03, "Rib: open polyline thickened to a web (vol " + Math.round(U.featureVol(ribF)) + " mm³, ideal 1600)");

        /* patterns multiply instances (rect + circular) */
        ribF.pattern = { mode: "rect", nx: 2, ny: 3, dx: 50, dy: 50, n: 6, ang: 360 };
        expect(U.instCountOf(ribF) === 6, "rectangular pattern counts nx·ny instances (2×3=6)");
        ribF.pattern = { mode: "circ", n: 6, ang: 360 };
        expect(U.instCountOf(ribF) === 6, "circular pattern counts n instances (6 about the origin)");
        U.renderAll();
        expect(doc.querySelector("[data-tree]").textContent.indexOf("×6") !== -1, "tree shows the ×6 pattern badge");

        /* draft + shell volume laws (analytic, pad card) */
        const skD = U.newSketchOnPlane(U.basePlane(), null, "Sketch.draft");
        skD.entities.push(U.mkEnt("rect", { cx: 20, cy: 20, w: 40, h: 40 }));
        U.closeSketchToPad();
        const draftF = U.S.design.features[U.S.design.features.length - 1];
        draftF.L = 10; draftF.draftDeg = 10;
        expect(Math.abs(U.featureVol(draftF) - 14630) < 14630 * 0.02, "draft angle volume law (Simpson over the leaning walls, ideal 14630)");
        draftF.draftDeg = 0; draftF.shellT = 2;
        /* 40×40×10, t=2: bottom 1600·2 + walls (1600−36²)·8 = 3200+2432 = 5632 */
        expect(Math.abs(U.featureVol(draftF) - 5632) < 5632 * 0.02, "shell volume law (walls t=2, ideal 5632)");

        /* mirror part */
        const pvBase = U.partVol();
        U.S.design.mirror = { on: true, plane: "yz" };
        expect(Math.abs(U.partVol() - 2 * pvBase) < Math.max(1, pvBase * 0.001), "mirror doubles the part volume");
        U.S.design.mirror.on = false;

        /* thread designation reaches the drawing callout */
        const thrHole = sk1.entities.find(function (e2) { return e2.type === "hole"; });
        if (thrHole) { thrHole.thread = { on: true, pitch: 1.5 }; }
        U.setStep("drawing");
        const stTh = doc.querySelector("[data-sheet]").innerHTML;
        expect(stTh.indexOf("M10 × 1.5") !== -1, "thread designation M10 × 1.5 on the drawing callout");
        if (thrHole) { thrHole.thread.on = false; }

        /* local fallback tessellator matches the worker (shaft case) */
        if (win.__rgzcad2 && win.__rgzcad2.tessLocal) {
          const lr = win.__rgzcad2.tessLocal({ profiles: [[[20, 0], [30, 0], [30, 10], [20, 10]]], holes: [], cuts: [], cutDepth: 0, L: 10, bevel: { mode: 0, size: 0 }, revol: { angle: 360, axisX: 0 } });
          expect(lr && !lr.error && Math.abs(lr.vol - Math.PI * (900 - 400) * 10 / 1000) < 0.05, "local fallback matches the worker (shaft " + (lr && lr.vol ? lr.vol.toFixed(3) : "?") + " cm³)");
        } else { expect(false, "local fallback tessellator exported"); }
        U.setStep("sketch");

        /* v1 -> v2 migration of old designs */
        const migrated = U.migrate1to2 ? U.normalizeDesign({ v: 1, name: "Old Part", outer: { type: "rect", cx: 30, cy: 20, w: 60, h: 40 }, holes: [{ cx: 30, cy: 20, r: 5, type: "through" }], pockets: [{ cx: 10, cy: 10, w: 12, h: 8, depth: 4 }], pad: { L: 16 }, chamfer: { on: true, t: 1 } }) : null;
        expect(migrated && migrated.v === 2 && migrated.sketches[0].entities.length === 2, "v1 design migrates: outer+hole become sketch entities");
        expect(migrated && migrated.features.length === 2 && migrated.features[1].type === "pocket", "v1 rectangular pockets become real pocket features");
        expect(migrated && migrated.features[0].edge.style === "chamfer", "v1 chamfer migrates to the pad edge");

        /* drawing sheet covers the whole tree */
        U.setStep("drawing");
        const sheet = doc.querySelector("[data-sheet]");
        const svgEl = sheet && sheet.querySelector("svg");
        expect(!!svgEl, "isometric ISO drawing sheet renders for the feature tree");
        expect(sheet.style.display === "block" && skCv.hidden && glWrap.hidden, "drawing step: sheet visible, canvas + 3D layer hidden");
        const st = sheet ? sheet.innerHTML : "";
        expect(st.indexOf("ISOMETRIC VIEW") !== -1 && st.indexOf("ISO 128") !== -1, "sheet carries the ISO 128 caption");
        expect(st.indexOf("ISO 7200") !== -1 || st.indexOf("RGZ ENGINEERING") !== -1, "title block present");
        expect(st.indexOf("Harness Bracket") !== -1, "part name in the title block");
        expect(st.indexOf("+0.015") !== -1, "hole tolerance in the drawing callout");
        expect(st.indexOf("\u2334") !== -1, "counterbore symbol drawn");

        /* ==================== Update 19 — ISO multi-view drafting with hidden-line removal ==================== */
        /* exact projection + HLR checks on a fresh analytic box: 60×40 plate, 20 thick, Ø10 through hole at the centre */
        const lr19 = win.__rgzcad2.tessLocal({ profiles: [[[0, 0], [60, 0], [60, 40], [0, 40]]], holes: [[30, 20, 5, 0, 20, 18, 4, 90]], cuts: [], cutDepth: 0, L: 20, bevel: { mode: 0, size: 0 } });
        expect(lr19 && !lr19.error && lr19.positions.length > 0, "box+hole tessellates for the view projection");
        const soup19 = { positions: lr19.positions, normals: lr19.normals };
        const VD = win.__rgzcad3.VIEW_DEFS, fv19 = win.__rgzcad3.hlrView(soup19, VD.front);
        expect(Math.abs(fv19.bbox.x1 - fv19.bbox.x0 - 60) < 0.6 && Math.abs(fv19.bbox.y1 - fv19.bbox.y0 - 20) < 0.6,
          "front view projects the true 3D outline (60 wide × 20 high)");
        const hid19 = fv19.runs.filter(function (r) { return !r.vis; });
        expect(hid19.some(function (r) { return Math.abs(r.a[0] - 25) < 0.8; }) && hid19.some(function (r) { return Math.abs(r.a[0] - 35) < 0.8; }),
          "hidden (dashed) hole walls land at exactly x = 25 and x = 35 in the front view");
        expect(fv19.runs.filter(function (r) { return r.vis; }).length >= 4, "visible outline edges detected (thick lines)");
        const tv19 = win.__rgzcad3.hlrView(soup19, VD.top);
        expect(Math.abs(tv19.bbox.x1 - tv19.bbox.x0 - 60) < 0.6 && Math.abs(tv19.bbox.y1 - tv19.bbox.y0 - 40) < 0.6,
          "top view spans 60 × 40 (ortho projection axes consistent)");
        const rv19 = win.__rgzcad3.hlrView(soup19, VD.right);
        expect(Math.abs(rv19.bbox.x1 - rv19.bbox.x0 - 40) < 0.6 && Math.abs(rv19.bbox.y1 - rv19.bbox.y0 - 20) < 0.6,
          "right view spans 40 × 20 (side projection)");
        /* user picks the views on the sheet */
        const viewsBefore = JSON.parse(JSON.stringify(U.S.design.draw.views));
        U.S.design.draw.views = { front: true, top: true, right: true, back: false, bottom: false, left: false, iso: false };
        win.__rgzcadRenderSheet();
        const stV = doc.querySelector("[data-sheet]").innerHTML;
        expect(stV.indexOf('data-view="front"') !== -1 && stV.indexOf('data-view="top"') !== -1 && stV.indexOf('data-view="right"') !== -1,
          "sheet renders exactly the picked views (front + top + right)");
        expect(stV.indexOf('data-view="iso"') === -1 && stV.indexOf('data-view="left"') === -1, "unpicked views stay off the sheet");
        expect(stV.indexOf("FRONT VIEW") !== -1 && stV.indexOf("TOP VIEW") !== -1 && stV.indexOf("first angle") !== -1,
          "views captioned; first-angle projection noted (ISO 128-30)");
        U.renderPanel();
        expect(doc.querySelectorAll('[data-bind^="design.draw.views."]').length === 7, "seven view checkboxes on the drawing panel (6 ortho + 3D)");
        U.S.design.draw.views = viewsBefore; win.__rgzcadRenderSheet();

        /* pocket actually carves its host slab (Vector2 point-in-poly regression) */
        const pk = win.__rgzcad2.tessLocal({ profiles: [[[0, 0], [60, 0], [60, 45], [0, 45]]], holes: [[15, 22.5, 5, 0, 20, 16, 4, 90]], cuts: [[[20, 20], [40, 20], [40, 30], [20, 30]]], cutDepth: 5, L: 20, bevel: { mode: 0, size: 0 } });
        expect(pk && !pk.error, "pad with pocket recess tessellates");
        let rimV = 0;
        for (let pi = 0; pi < pk.positions.length; pi += 3) {
          if (Math.abs(pk.positions[pi + 2] - 20) < 0.01 && Math.abs(pk.positions[pi + 1] - 20) < 0.01 && pk.positions[pi] > 19.9 && pk.positions[pi] < 40.1) { rimV++; }
        }
        expect(rimV > 0, "pocket opening rim exists in the carved slab (" + rimV + " verts on the rim line)");
        const pkTop = win.__rgzcad3.hlrView({ positions: pk.positions, normals: pk.normals }, win.__rgzcad3.VIEW_DEFS.top);
        const longRim = pkTop.runs.filter(function (r) { return r.vis && Math.abs(r.a[1] + 30) < 0.4 && Math.abs(r.b[1] + 30) < 0.4 && Math.abs(r.b[0] - r.a[0]) > 15; });
        expect(longRim.length > 0, "top view draws the pocket rim as solid lines");
        const pkFront = win.__rgzcad3.hlrView({ positions: pk.positions, normals: pk.normals }, win.__rgzcad3.VIEW_DEFS.front);
        const floorHid = pkFront.runs.filter(function (r) { return !r.vis && Math.abs(r.a[1] - 15) < 0.5 && Math.abs(r.b[1] - 15) < 0.5 && Math.abs(r.b[0] - r.a[0]) > 15; });
        expect(floorHid.length > 0, "front view shows the blind pocket floor as a dashed line");

        /* controls */
        ["[data-view=iso]", "[data-view=front]", "[data-view=top]", "[data-view=right]", "[data-opt=wire]", "[data-opt=shadows]", "[data-opt=grid]", "[data-fit]", "[data-opt=ortho]", "[data-opt=section]", "[data-opt=measure]", "[data-section-axis]", "[data-section-pos]", "[data-measure-tag]", "[data-zoom-fit]", "[data-snap]", "[data-tool3d=facesketch]", "[data-tool3d=holeface]"].forEach(function (sel) {
          expect(!!doc.querySelector(sel), "studio control present: " + sel);
        });
        expect(doc.querySelectorAll("[data-tool]").length === 12, "12 sketch draw tools on the bar (line, rect, circle, poly, ngon, arc, slot, ellipse, spline, point, hole, centerline)");
        expect(doc.querySelectorAll("[data-op2]").length === 7, "7 sketcher operation tools on the bar (corner, chamfer, trim, quick-trim, break, offset, construction)");
        expect(doc.querySelectorAll("[data-geo]").length === 9, "9 geometric constraint buttons (H, V, parallel, perpendicular, equal, coincident, concentric, tangent, fix)");
        expect(doc.querySelectorAll("[data-mode]").length === 1, "dedicated Select (plain mouse) mode button");

        /* fullscreen, toggle + exit */
        const fsBtns = doc.querySelectorAll("[data-fullscreen]");
        expect(fsBtns.length === 2, "fullscreen button on header AND 3D toolbar");
        const appRoot = doc.querySelector("[data-rgzcad]");
        fsBtns[0].click();
        expect(appRoot.classList.contains("rgzcad-fs"), "fullscreen falls back to the fixed full-window frame");
        fsBtns[0].click();
        expect(!appRoot.classList.contains("rgzcad-fs"), "second click exits the fallback fullscreen");

        /* account system (DOM level of the backend contract) */
        expect(typeof win.__rgzcadSaveAccount === "function" && typeof win.__rgzcadOpenDesigns === "function" && typeof win.__rgzcadAccountStatus === "function", "account API surface exported by the app");
        doc.querySelector("[data-account-chip]").click();
        const am = doc.querySelector("[data-auth-modal]");
        expect(am && am.hidden === false && !!am.querySelector("[data-auth-tab=login]") && !!am.querySelector("[data-auth-tab=register]"), "sign-in modal opens with login/register tabs");
        am.querySelector("[data-auth-close]").click();
        expect(am.hidden === true, "sign-in modal closes");

        /* no learning material inside the app anymore (it lives in the hub) */
        expect(!doc.querySelector("[data-learn]") && !doc.querySelector("[data-reader]"), "in-app learning section removed (course lives in the Learning Hub)");

        win.__rgzcad3.tourStart();
        expect(!!doc.querySelector(".rgzcad-tour"), "guided tour starts (spotlight overlay)");
      } catch (e) {
        failed++;
        console.log("FAIL ✗ phase D threw: " + (e && e.stack ? e.stack.split("\n").slice(0, 3).join(" | ") : e));
      }
      try { dom.window.close(); } catch (e) {}
      resolve();
    }, 350);
  });
}

(async function () {
  console.log("== RGZ 3D CAD Studio — package acceptance ==");
  phaseA();
  phaseB();
  const c = await phaseC();
  if (c.html && c.html.length > 500) { await phaseD(c.html, c.localize); }
  else { failed++; console.log("FAIL ✗ phase D skipped — no rendered markup from phase C"); }
  console.log("\n== summary: " + pass + " passed, " + failed + " failed ==");
  process.exit(failed ? 1 : 0);
})();
