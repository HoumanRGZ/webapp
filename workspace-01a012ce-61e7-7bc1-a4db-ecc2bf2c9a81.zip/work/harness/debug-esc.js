const fs = require("fs");
const src = fs.readFileSync("/home/user/work/harness/test-cad-pkg.js", "utf8");
const stubStart = src.indexOf("const STUBS");
const stubEnd = src.indexOf("`;", stubStart) + 2;
const STUBS = eval(src.slice(stubStart, stubEnd) + "\n;STUBS;");

(async () => {
  const { loadNodeRuntime } = require("@php-wasm/node");
  const { PHP } = require("/home/user/work/harness/node_modules/@php-wasm/node/node_modules/@php-wasm/universal/index.cjs");
  const php = new PHP(await loadNodeRuntime("8.2"));
  const $html = "<div data-fullscreen data-opt=\"section\"></div>";

  // A: old-style line ending — two backslashes + n in the JS source
  const lineOld = "echo 'one' . '|';\\n";
  // B: my new line — four backslashes + n
  const lineNew = "echo 'two' . '|';\\\\n";
  // C: real newline
  const lineC = "echo 'three' . '|';\n";

  for (const [name, line] of [["old(\\n)", lineOld], ["new(\\\\n)", lineNew], ["real-nl", lineC]]) {
    const code = STUBS.replace("?>", "") +
      "\ndefine('ABSPATH','/wp/');\n$GLOBALS['__options_store']=[];\n" +
      "ob_start();\ntry {\n" + line + " echo 'done';" +
      "\n} catch (\\Throwable $e) { echo ' FATAL: ' . $e->getMessage(); }\n" +
      "$GLOBALS['__out']=ob_get_clean(); echo '===OUT===' . $GLOBALS['__out'];";
    const res = await php.run({ code });
    const t = (res.text || "").replace(/\n/g, " ");
    console.log(name, ">>", t.slice(0, 160));
    if ((res.errors || "").trim()) { console.log(name, "errors>>", String(res.errors).slice(0, 200)); }
  }
})();
