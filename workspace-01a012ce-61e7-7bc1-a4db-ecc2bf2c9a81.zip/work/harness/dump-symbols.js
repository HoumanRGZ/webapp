// Dump every symbol drawn by each RGZ app as standalone SVG files (one jsdom instance per app).
const fs = require("fs");
const path = require("path");
const { JSDOM, VirtualConsole } = require("jsdom");

const appJs = process.argv[2] || "/home/user/work/extracted/rgz-engineering-studio/assets/app.min.js";
const outDir = process.argv[3] || "/home/user/work/render/orig";
const only = process.argv[4] || ""; // "hyd" | "pne" | ""
fs.mkdirSync(outDir, { recursive: true });
const code = fs.readFileSync(appJs, "utf8");

function runApp(rootId, label) {
  return new Promise((resolve) => {
    const vc = new VirtualConsole();
    vc.on("jsdomError", (e) => console.log(label, "JSDOM-ERR:", e.message));
    const html = `<!DOCTYPE html><html><body><div id="${rootId}"></div></body></html>`;
    const dom = new JSDOM(html, {
      runScripts: "dangerously",
      pretendToBeVisual: true,
      url: "https://example.com/",
      virtualConsole: vc,
      beforeParse(window) {
        window.matchMedia = () => ({ matches: false, media: "", addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {} });
        window.confirm = () => true;
        window.alert = () => {};
        window.requestAnimationFrame = (cb) => setTimeout(cb, 0);
        window.SVGElement.prototype.getBBox = function () { return { x: 0, y: 0, width: 100, height: 100 }; };
      },
    });
    const { window } = dom;
    const script = window.document.createElement("script");
    script.textContent = code;
    window.document.body.appendChild(script);

    setTimeout(() => {
      const root = window.document.getElementById(rootId);
      if (!root || root.innerHTML.length < 10000) { console.log(label, "NO APP (html", root ? root.innerHTML.length : 0, ")"); return resolve([]); }
      const cards = root.querySelectorAll(".rgz-symbol-card");
      console.log(label, "cards:", cards.length);
      const canvas = window.document.getElementById("rgz-canvas");
      const dumped = [];
      for (const card of cards) {
        const type = card.dataset.type;
        try {
          card.dispatchEvent(new window.MouseEvent("dblclick", { bubbles: true }));
          const groups = canvas.querySelectorAll("g.rgz-component");
          if (!groups.length) { console.log("  FAIL", type); continue; }
          const g = groups[groups.length - 1];
          g.querySelectorAll(".selection-box, .component-label, .port-hit, circle.port").forEach((n) => n.remove());
          g.setAttribute("transform", "");
          const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="-110 -90 220 180" style="background:#0b1730">${g.outerHTML}</svg>`;
          fs.writeFileSync(path.join(outDir, `${label}-${type}.svg`), svg);
          dumped.push(type);
          const newBtn = window.document.querySelector('[data-action="new"]');
          newBtn.dispatchEvent(new window.MouseEvent("click", { bubbles: true }));
        } catch (e) { console.log("  ERR", type, e.message); }
      }
      resolve(dumped);
    }, 1500);
  });
}

(async () => {
  const out = {};
  if (!only || only === "hyd") out.hyd = await runApp("rgz-hydraulic-studio", "hyd");
  if (!only || only === "pne") out.pne = await runApp("rgz-pneumatic-studio", "pne");
  fs.writeFileSync(path.join(outDir, "manifest.json"), JSON.stringify(out, null, 2));
  console.log("done", JSON.stringify(Object.fromEntries(Object.entries(out).map(([k, v]) => [k, v.length]))));
  process.exit(0);
})();
