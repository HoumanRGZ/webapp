(async () => {
  const { loadNodeRuntime } = require("@php-wasm/node");
  const { PHP } = require("/home/user/work/harness/node_modules/@php-wasm/node/node_modules/@php-wasm/universal/index.cjs");
  const php = new PHP(await loadNodeRuntime("8.2"));
  const res = await php.run({ code: "<?php echo class_exists('ZipArchive') ? 'ZIP-YES' : 'ZIP-NO'; " });
  console.log(res.text.trim());
})();
