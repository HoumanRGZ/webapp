/* Generate animated schematic GIFs for the learning hub (ISO-flavoured). */
"use strict";
const fs = require("fs");
const { encodeGIF } = require("./gifenc.js");

/* ---------- palette ---------- */
const PAL = [
  [250, 249, 246], // 0 bg cream
  [233, 238, 246], // 1 panel
  [31, 41, 55],    // 2 ink
  [235, 78, 60],   // 3 red accent
  [37, 99, 235],   // 4 blue
  [22, 140, 90],   // 5 green
  [148, 163, 184], // 6 gray
  [255, 255, 255], // 7 white
  [60, 75, 95],    // 8 soft navy
  [217, 119, 6],   // 9 amber
  [124, 58, 237],  // 10 violet (pilot)
  [254, 226, 226], // 11 light red
  [219, 234, 254], // 12 light blue
  [17, 24, 39],    // 13 near-black
];
const BG = 0, PANEL = 1, INK = 2, RED = 3, BLUE = 4, GREEN = 5, GRAY = 6, WHITE = 7, NAVY = 8, AMBER = 9, VIOLET = 10, LRED = 11, LBLUE = 12, BLACK = 13;

/* ---------- canvas ---------- */
const W = 360, H = 220;
function cv() {
  const px = new Uint8Array(W * H).fill(BG);
  return {
    px,
    fillRect(x, y, w, h, c) { for (let j = Math.max(0, y | 0); j < Math.min(H, y + h); j++) for (let i = Math.max(0, x | 0); i < Math.min(W, x + w); i++) px[j * W + i] = c; },
    rect(x, y, w, h, c, th = 1) { for (let t = 0; t < th; t++) { this.hline(x + t, x + w - t - 1, y + t, c); this.hline(x + t, x + w - t - 1, y + h - 1 - t, c); this.vline(y + t, y + h - t - 1, x + t, c); this.vline(y + t, y + h - t - 1, x + w - 1 - t, c); } },
    hline(x1, x2, y, c) { for (let i = Math.max(0, Math.min(x1, x2)); i <= Math.min(W - 1, Math.max(x1, x2)); i++) if (y >= 0 && y < H) px[y * W + i] = c; },
    vline(y1, y2, x, c) { for (let j = Math.max(0, Math.min(y1, y2)); j <= Math.min(H - 1, Math.max(y1, y2)); j++) if (x >= 0 && x < W) px[j * W + x] = c; },
    line(x1, y1, x2, y2, c, th = 1) {
      const dx = Math.abs(x2 - x1), dy = -Math.abs(y2 - y1), sx = x1 < x2 ? 1 : -1, sy = y1 < y2 ? 1 : -1;
      let err = dx + dy, e2, x = x1, y = y1;
      for (;;) {
        for (let tx = 0; tx < th; tx++) for (let ty = 0; ty < th; ty++) if (x + tx >= 0 && x + tx < W && y + ty >= 0 && y + ty < H) px[(y + ty) * W + (x + tx)] = c;
        if (x === x2 && y === y2) break;
        e2 = 2 * err;
        if (e2 >= dy) { err += dy; x += sx; }
        if (e2 <= dx) { err += dx; y += sy; }
      }
    },
    disc(cx, cy, r, c) { for (let j = -r; j <= r; j++) for (let i = -r; i <= r; i++) if (i * i + j * j <= r * r && cy + j >= 0 && cy + j < H && cx + i >= 0 && cx + i < W) px[(cy + j) * W + cx + i] = c; },
    circle(cx, cy, r, c) { for (let a = 0; a < 360; a += 2) { const x = Math.round(cx + r * Math.cos(a * Math.PI / 180)), y = Math.round(cy + r * Math.sin(a * Math.PI / 180)); if (x >= 0 && x < W && y >= 0 && y < H) px[y * W + x] = c; } },
    tri(tipx, tipy, ang, s, c) { // filled triangle, apex toward ang rad
      const ax = Math.cos(ang), ay = Math.sin(ang), bx = -ay, by = ax;
      const p1 = [tipx, tipy], p2 = [tipx - s * ax + 0.55 * s * bx, tipy - s * ay + 0.55 * s * by], p3 = [tipx - s * ax - 0.55 * s * bx, tipy - s * ay - 0.55 * s * by];
      const minx = Math.floor(Math.min(p1[0], p2[0], p3[0])), maxx = Math.ceil(Math.max(p1[0], p2[0], p3[0]));
      const miny = Math.floor(Math.min(p1[1], p2[1], p3[1])), maxy = Math.ceil(Math.max(p1[1], p2[1], p3[1]));
      const area = (p2[0] - p1[0]) * (p3[1] - p1[1]) - (p3[0] - p1[0]) * (p2[1] - p1[1]);
      for (let y = miny; y <= maxy; y++) for (let x = minx; x <= maxx; x++) {
        const w1 = ((p2[0] - x) * (p3[1] - y) - (p3[0] - x) * (p2[1] - y)) / (area || 1);
        const w2 = ((p3[0] - x) * (p1[1] - y) - (p1[0] - x) * (p3[1] - y)) / (area || 1);
        if (w1 >= 0 && w2 >= 0 && w1 + w2 <= 1 && x >= 0 && x < W && y >= 0 && y < H) px[y * W + x] = c;
      }
    },
    chev(x, y, ang, s, c) { // open chevron > for flow
      const a = ang * Math.PI / 180;
      const dx = Math.cos(a), dy = Math.sin(a), px2 = -dy, py = dx;
      this.line(Math.round(x - s * dx + s * 0.6 * px2), Math.round(y - s * dy + s * 0.6 * py), Math.round(x), Math.round(y), c, 1);
      this.line(Math.round(x - s * dx - s * 0.6 * px2), Math.round(y - s * dy - s * 0.6 * py), Math.round(x), Math.round(y), c, 1);
    },
  };
}

/* ---------- 3x5 font ---------- */
const F = {
  "0": ["111", "101", "101", "101", "111"], "1": ["010", "110", "010", "010", "111"], "2": ["111", "001", "111", "100", "111"],
  "3": ["111", "001", "111", "001", "111"], "4": ["101", "101", "111", "001", "001"], "5": ["111", "100", "111", "001", "111"],
  "6": ["111", "100", "111", "101", "111"], "7": ["111", "001", "001", "010", "010"], "8": ["111", "101", "111", "101", "111"], "9": ["111", "101", "111", "001", "111"],
  "A": ["010", "101", "111", "101", "101"], "B": ["110", "101", "110", "101", "110"], "C": ["011", "100", "100", "100", "011"],
  "D": ["110", "101", "101", "101", "110"], "E": ["111", "100", "111", "100", "111"], "F": ["111", "100", "111", "100", "100"],
  "G": ["011", "100", "101", "101", "011"], "H": ["101", "101", "111", "101", "101"], "I": ["111", "010", "010", "010", "111"],
  "K": ["101", "101", "110", "101", "101"], "L": ["100", "100", "100", "100", "111"], "M": ["101", "111", "111", "101", "101"],
  "N": ["101", "111", "111", "111", "101"], "O": ["010", "101", "101", "101", "010"], "P": ["110", "101", "110", "100", "100"],
  "R": ["110", "101", "110", "101", "101"], "S": ["011", "100", "111", "001", "110"], "T": ["111", "010", "010", "010", "010"],
  "U": ["101", "101", "101", "101", "111"], "V": ["101", "101", "101", "101", "010"], "W": ["101", "101", "111", "111", "101"],
  "X": ["101", "101", "010", "101", "101"], "Y": ["101", "101", "010", "010", "010"], "Z": ["111", "001", "010", "100", "111"],
  "+": ["000", "010", "111", "010", "000"], "-": ["000", "000", "111", "000", "000"], "%": ["101", "001", "010", "100", "101"],
  "/": ["001", "001", "010", "100", "100"], "(": ["010", "100", "100", "100", "010"], ")": ["010", "001", "001", "001", "010"],
  ".": ["000", "000", "000", "000", "010"], ":": ["000", "010", "000", "010", "000"], " ": ["000", "000", "000", "000", "000"],
  "Δ": ["010", "101", "101", "101", "111"], "=": ["000", "111", "000", "111", "000"], ">": ["100", "010", "001", "010", "100"],
  "<": ["001", "010", "100", "010", "001"], "~": ["000", "101", "110", "000", "000"], "°": ["010", "101", "010", "000", "000"],
};
function text(c, x, y, s, col, scale = 1) {
  let cx = x;
  for (const ch of String(s).toUpperCase()) {
    const gl = F[ch] || F[" "];
    for (let r = 0; r < 5; r++) for (let col2 = 0; col2 < 3; col2++) {
      if (gl[r][col2] === "1") c.fillRect(cx + col2 * scale, y + r * scale, scale, scale, col);
    }
    cx += 4 * scale;
  }
}

/* ---------- common furniture ---------- */
function chrome(c, title) {
  c.fillRect(0, 0, W, H, PANEL);
  c.fillRect(0, 0, W, 16, NAVY);
  text(c, 6, 5, title, WHITE, 1);
}
function tankSym(c, x, y, w = 30) {
  c.vline(y - 14, y + 6, x - w / 2, INK); c.vline(y - 14, y + 6, x + w / 2, INK); c.hline(x - w / 2, x + w / 2, y + 6, INK);
  for (let j = 0; j < 5; j++) c.hline(x - w / 2 + 2, x + w / 2 - 2, y + 2 + j, LBLUE);
}
function pumpSym(c, cx, cy, r = 15, ang = 0.0) {
  c.circle(cx, cy, r, INK); c.circle(cx, cy, r - 1, INK);
  c.tri(Math.round(cx + 8 * Math.cos(ang)), Math.round(cy + 8 * Math.sin(ang)), ang, 11, INK);
}
function cylH(c, x, y, w, h, pistonFrac, rodLen, rodC) {
  c.rect(x, y, w, h, INK);
  const pxn = x + 6 + Math.round((w - 14) * pistonFrac);
  c.fillRect(pxn, y + 1, 4, h - 2, INK);
  c.hline(pxn + 4, x + w + rodLen, y + (h >> 1), INK); c.hline(pxn + 4, x + w + rodLen, y + (h >> 1) + 1, rodC);
}
function valveBoxes(c, x, y, n, bw, bh, active) {
  for (let i = 0; i < n; i++) c.rect(x + i * bw, y, bw, bh, i === active ? RED : INK, i === active ? 2 : 1);
}
function springS(c, x1, x2, y) {
  const teeth = 5; let px2 = x1, py = y;
  for (let i = 0; i < teeth; i++) {
    const nx = x1 + ((i + 1) / teeth) * (x2 - x1), ny = y + (i % 2 ? -3 : 3);
    c.line(px2, py, Math.round(nx), Math.round(ny), INK, 1); px2 = Math.round(nx); py = Math.round(ny);
  }
  c.line(px2, py, x2, y, INK, 1);
}
function flowAlong(c, pts, t01, col, every = 34, dist = 5) {
  /* marching chevrons along polyline; t01 in [0,1) phase */
  let total = 0;
  const segs = [];
  for (let i = 0; i < pts.length - 1; i++) { const l = Math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1]); segs.push(l); total += l; }
  const off = (t01 * every * 2) % (every / 2);
  for (let d = off; d < total; d += every / 2) {
    let acc = 0, s = 0;
    while (s < segs.length - 1 && acc + segs[s] < d) { acc += segs[s]; s++; }
    const u = segs[s] ? (d - acc) / segs[s] : 0;
    const x = pts[s][0] + (pts[s + 1][0] - pts[s][0]) * u, y = pts[s][1] + (pts[s + 1][1] - pts[s][1]) * u;
    const ang = Math.atan2(pts[s + 1][1] - pts[s][1], pts[s + 1][0] - pts[s][0]) * 180 / Math.PI;
    c.chev(Math.round(x), Math.round(y), ang, dist, col);
  }
}

/* ---------- scenes ---------- */
const GIFS = {};

/* 1) 4/3 valve + DA cylinder extend/retract */
GIFS["anim-hyd-cylinder-cycle.gif"] = (cOut) => {
  const NF = 44;
  for (let f = 0; f < NF; f++) {
    const phase = f / NF;
    let pos, mode; // piston 0..1
    if (phase < 0.36) { pos = phase / 0.36; mode = "EXTEND"; }
    else if (phase < 0.48) { pos = 1; mode = "CENTER"; }
    else if (phase < 0.84) { pos = 1 - (phase - 0.48) / 0.36; mode = "RETRACT"; }
    else { pos = 0; mode = "CENTER"; }
    const activeBox = mode === "EXTEND" ? 0 : mode === "RETRACT" ? 2 : 1;
    const c = cv(); chrome(c, "4/3 VALVE + CYLINDER - WORK CYCLE");
    /* tank + pump */
    tankSym(c, 46, 190, 30); c.vline(156, 184, 46, INK); c.vline(150, 156, 46, INK); c.hline(46, 66, 150, INK);
    pumpSym(c, 84, 150, 14, -Math.PI / 2); c.line(66, 150, 70, 150, INK, 2);
    c.line(84, 136, 84, 96, INK, 2); c.hline(84, 196, 96, INK);
    /* valve 3 boxes */
    const vx = 196, vy = 84, bw = 26, bh = 24;
    valveBoxes(c, vx, vy, 3, bw, bh, activeBox);
    c.hline(vx - 8, vx, vy + 16, INK); c.vline(vy + 16, vy + 28, vx - 6, INK); /*P*/
    c.line(84, 96, vx - 6, 96, INK, 1); c.line(vx - 6, 96, vx - 6, 100, INK, 1);
    /* ports to cylinder (up to cyl at right) */
    const cby = 40, cx0 = 250, cw = 64, chh = 16;
    cylH(c, cx0, cby, cw, chh, pos, 22, RED);
    c.rect(cx0 - 8, cby + 2, 8, 4, INK); c.rect(cx0 - 8, cby + 10, 8, 4, INK);
    /* pipes valve->cyl */
    c.line(vx + 8, vy, vx + 8, cby + 4, INK, 1); c.line(vx + 8, cby + 4, cx0 - 8, cby + 4, INK, 1);
    c.line(vx + 18, vy, vx + 18, cby + 12, INK, 1); c.line(vx + 18, cby + 12, cx0 - 8, cby + 12, INK, 1);
    text(c, vx + 4, vy + bh + 6, "P T", NAVY, 1); text(c, vx + 2, vy - 8, "A B", NAVY, 1);
    /* active flows */
    const t = f / NF;
    if (mode === "EXTEND") {
      flowAlong(c, [[84, 96], [vx - 6, 96], [vx - 6, 100]], t, BLUE, 26, 5);
      flowAlong(c, [[vx + 8, vy], [vx + 8, cby + 4], [cx0 - 8, cby + 4]], t, BLUE, 26, 5);
      flowAlong(c, [[cx0 - 8, cby + 12], [vx + 18, cby + 12], [vx + 18, vy]], t, BLUE, 26, 5);
      text(c, 140, 200, "EXTEND >", RED, 1);
    } else if (mode === "RETRACT") {
      flowAlong(c, [[vx + 18, vy], [vx + 18, cby + 12], [cx0 - 8, cby + 12]], t, GREEN, 26, 5);
      flowAlong(c, [[cx0 - 8, cby + 4], [vx + 8, cby + 4], [vx + 8, vy]], t, GREEN, 26, 5);
      text(c, 140, 200, "< RETRACT", GREEN, 1);
    } else {
      text(c, 150, 200, "CENTER - LOCKED", NAVY, 1);
    }
    /* rod tip marker */
    c.chev(cx0 + cw + 22, cby + 8, mode === "RETRACT" ? 180 : 0, 5, mode === "CENTER" ? GRAY : RED);
    text(c, 6, 205, "ISO1219 ANIMATION", GRAY, 1);
    cOut.push({ pixels: c.px, delayCs: mode === "CENTER" ? 30 : 9 });
  }
};

/* 2) DCV spool shifting: spool lands slide inside bore; ports light up */
GIFS["anim-hyd-dcv-spool.gif"] = (cOut) => {
  const NF = 45;
  for (let f = 0; f < NF; f++) {
    const phase = f / NF;
    /* spool dx: 0 -> -14 -> 0 -> +14 -> 0 */
    let dx, mode;
    if (phase < 0.2) { dx = -14 * (phase / 0.2); mode = "shift left"; }
    else if (phase < 0.4) { dx = -14; mode = "P-A  B-T"; }
    else if (phase < 0.55) { dx = -14 + 14 * ((phase - 0.4) / 0.15); mode = "shift right"; }
    else if (phase < 0.7) { dx = 14 * ((phase - 0.55) / 0.15); mode = "shift right+"; }
    else if (phase < 0.9) { dx = 14; mode = "P-B  A-T"; }
    else { dx = 14 - 14 * ((phase - 0.9) / 0.1); mode = "back to center"; }
    dx = Math.round(dx);
    const c = cv(); chrome(c, "SPOOL INSIDE THE 4/3 BODY - WHAT SHIFTING DOES");
    /* valve body */
    const bx = 60, by = 60, bw = 240, bh = 44;
    c.rect(bx, by, bw, bh, INK); c.rect(bx + 1, by + 1, bw - 2, bh - 2, INK);
    /* ports */
    const px = { A: bx + 40, B: bx + 200, P: bx + 110, T: bx + 140 };
    text(c, px.A - 3, by - 10, "A", NAVY, 1); text(c, px.B - 3, by - 10, "B", NAVY, 1);
    text(c, px.P - 3, by + bh + 4, "P", NAVY, 1); text(c, px.T - 3, by + bh + 4, "T", NAVY, 1);
    c.vline(by, by + 8, px.A, INK); c.vline(by + bh - 8, by + bh, px.P, INK);
    /* spool: 3 lands, 2 grooves */
    const land = 34, groove = 26, sw = 3 * land + 2 * groove, sx0 = bx + (bw - sw) / 2 + dx;
    c.fillRect(sx0, by + 10, land, bh - 20, AMBER);
    c.fillRect(sx0 + land + groove, by + 10, land, bh - 20, AMBER);
    c.fillRect(sx0 + 2 * (land + groove), by + 10, land, bh - 20, AMBER);
    c.hline(sx0 - 20, sx0, by + (bh >> 1), AMBER); c.hline(sx0 + sw, sx0 + sw + 20, by + (bh >> 1), AMBER);
    c.rect(sx0 - 20, by + (bh >> 1) - 6, 10, 12, INK); text(c, sx0 - 26, by - 10, "Y1", INK, 1);
    c.rect(sx0 + sw + 10, by + (bh >> 1) - 6, 10, 12, INK); text(c, sx0 + sw + 22, by - 10, "Y2", INK, 1);
    text(c, 60, 40, mode, RED, 1);
    /* flow viz */
    if (mode === "P-A  B-T") {
      c.line(px.P, by + bh, px.P, by + bh + 26, BLUE, 2); c.chev(px.P, by + bh + 14, 90, 5, BLUE);
      c.line(px.A, by, px.A, by - 26, BLUE, 2); c.chev(px.A, by - 14, -90, 5, BLUE);
      c.line(px.B, by, px.B, by - 26, GREEN, 2); c.chev(px.B, by - 20, 90, 5, GREEN);
      c.line(px.T, by + bh, px.T, by + bh + 26, GREEN, 2); c.chev(px.T, by + bh + 22, 90, 5, GREEN);
      text(c, 60, 140, "OIL: PUMP > A ... B > TANK (EXTEND)", NAVY, 1);
    } else if (mode === "P-B  A-T") {
      c.line(px.P, by + bh, px.P, by + bh + 26, BLUE, 2); c.chev(px.P, by + bh + 14, 90, 5, BLUE);
      c.line(px.B, by, px.B, by - 26, BLUE, 2); c.chev(px.B, by - 14, -90, 5, BLUE);
      c.line(px.A, by, px.A, by - 26, GREEN, 2); c.chev(px.A, by - 20, 90, 5, GREEN);
      c.line(px.T, by + bh, px.T, by + bh + 26, GREEN, 2); c.chev(px.T, by + bh + 22, 90, 5, GREEN);
      text(c, 60, 140, "OIL: PUMP > B ... A > TANK (RETRACT)", NAVY, 1);
    } else if (Math.abs(dx) < 4) {
      text(c, 60, 140, "CENTER: ALL PORTS LOCKED", NAVY, 1);
    }
    /* little cylinder at right showing result */
    const cpos = mode === "P-A  B-T" ? 0.75 : mode === "P-B  A-T" ? 0.25 : 0.5;
    cylH(c, 60, 170, 64, 16, cpos, 24, RED);
    text(c, 140, 178, "= CYLINDER FOLLOWS THE SPOOL", GRAY, 1);
    text(c, 6, 205, "ISO1219 ANIMATION", GRAY, 1);
    cOut.push({ pixels: c.px, delayCs: mode.length > 10 ? 24 : 8 });
  }
};

/* 3) relief valve pops at its setting */
GIFS["anim-hyd-relief-pops.gif"] = (cOut) => {
  const NF = 48;
  const SET = 100;
  for (let f = 0; f < NF; f++) {
    const ph = (f % 24) / 24, cycle = Math.floor(f / 24);
    const p = Math.min(115, 40 + 80 * ph);
    const open = p >= SET - 2;
    const c = cv(); chrome(c, "RELIEF VALVE - CLOSED ... CRACKS AT SETTING");
    /* pump */
    tankSym(c, 40, 190, 26); c.vline(160, 184, 40, INK); c.vline(150, 160, 40, INK); c.hline(40, 58, 150, INK);
    pumpSym(c, 76, 150, 13, -Math.PI / 2); c.line(58, 150, 63, 150, INK, 2);
    c.line(76, 137, 76, 100, INK, 2); c.hline(76, 150, 100, INK);
    /* dead-end line to right */
    c.line(150, 100, 150, 60, INK, 2); c.hline(150, 60, 40 + 2, INK);
    text(c, 160, 66, "DEAD-HEADED LINE", NAVY, 1);
    /* relief branch down at x150 */
    c.vline(100, 132, 150, INK);
    const ry = 132;
    c.rect(136, ry, 28, 22, INK);
    if (open) { c.line(141, ry + 16, 155, ry + 6, RED, 2); c.chev(157, ry + 4, -55, 5, RED); }
    else { c.line(141, ry + 17, 149, ry + 10, INK, 1); }
    springS(c, 166, 186, ry + 11);
    /* tank below relief */
    if (open) { flowAlong(c, [[150, ry + 22], [150, 178]], f / NF, RED, 20, 5); }
    tankSym(c, 150, 190, 26);
    /* gauge bar right */
    const gx = 240, gy = 40, gh = 130;
    c.rect(gx, gy, 22, gh, INK);
    const lvl = Math.round(((p - 30) / 95) * (gh - 4));
    c.fillRect(gx + 2, gy + gh - 2 - lvl, 18, lvl, p >= SET ? RED : AMBER);
    c.hline(gx - 6, gx + 28, gy + gh - 2 - Math.round(((SET - 30) / 95) * (gh - 4)), RED);
    text(c, gx + 34, gy + gh - Math.round(((SET - 30) / 95) * (gh - 4)) - 3, "SET 100 BAR", RED, 1);
    text(c, gx - 10, gy + gh + 10, Math.round(p) + " BAR", p >= SET ? RED : NAVY, 1);
    /* needle */
    if (open) { text(c, 60, 40, "POP! FLOW TO TANK", RED, 1); }
    else if (p > 88) { text(c, 60, 40, "PRESSURE CLIMBING", AMBER, 1); }
    else { text(c, 60, 40, "RELIEF CLOSED", NAVY, 1); }
    text(c, 6, 205, "ISO1219 ANIMATION", GRAY, 1);
    cOut.push({ pixels: c.px, delayCs: open ? 16 : 9 });
  }
};

/* 4) pump keeps the loop alive */
GIFS["anim-hyd-pump-flow.gif"] = (cOut) => {
  const NF = 32;
  for (let f = 0; f < NF; f++) {
    const t = f / NF;
    const c = cv(); chrome(c, "CONTINUOUS FLOW - THE LOOP NEVER SLEEPS");
    tankSym(c, 60, 186, 30);
    c.vline(150, 180, 60, INK); c.vline(150, 154, 60, INK); c.hline(60, 80, 150, INK);
    const ang = -Math.PI / 2 + 0.0; // triangle spins:
    pumpSym(c, 100, 150, 15, -Math.PI / 2 + (Math.PI / 4) * Math.floor((f / 4) % 8) * 0.0 + f * (Math.PI / 8));
    c.line(80, 150, 85, 150, INK, 2);
    /* loop: pump top -> right -> down -> cyl -> left -> back */
    const loop = [[100, 135], [100, 60], [300, 60], [300, 110]];
    c.line(100, 135, 100, 60, INK, 2); c.line(100, 60, 300, 60, INK, 2); c.line(300, 60, 300, 110, INK, 2);
    cylH(c, 250, 110, 56, 18, 0.5 + 0.3 * Math.sin(2 * Math.PI * t), 18, RED);
    c.rect(244, 112, 6, 14, INK);
    c.line(250, 121, 200, 121, INK, 2); c.line(200, 121, 200, 180, INK, 2); c.line(200, 180, 75, 180, INK, 2);
    flowAlong(c, loop, t, BLUE, 30, 5);
    flowAlong(c, [[250, 121], [200, 121], [200, 180], [75, 180]], t, GREEN, 30, 5);
    c.chev(60, 150, 0, 5, BLUE);
    text(c, 60, 30, "PUMP DELIVERS Q - VALVES STEER IT", NAVY, 1);
    text(c, 6, 205, "ISO1219 ANIMATION", GRAY, 1);
    cOut.push({ pixels: c.px, delayCs: 10 });
  }
};

/* 5) pneumatic A+ B+ B- A- sequence */
GIFS["anim-pne-sequence.gif"] = (cOut) => {
  const NF = 40;
  const steps = [[1, 0, "A+  EXTEND CYL A"], [1, 1, "B+  EXTEND CYL B"], [1, 0.999, ""], [1, 0, "B-  RETRACT CYL B"], [0, 0, "A-  RETRACT CYL A"], [0, 0, ""], [0.5, 0.5, "AND AGAIN..."]];
  for (let f = 0; f < NF; f++) {
    const ph = f / NF;
    let pa, pb, label;
    if (ph < 0.2) { pa = ph / 0.2; pb = 0; label = "A+"; }
    else if (ph < 0.4) { pa = 1; pb = (ph - 0.2) / 0.2; label = "B+"; }
    else if (ph < 0.6) { pa = 1; pb = 1 - (ph - 0.4) / 0.2; label = "B-"; }
    else if (ph < 0.8) { pa = 1 - (ph - 0.6) / 0.2; pb = 0; label = "A-"; }
    else { pa = 0; pb = 0; label = "READY"; }
    const c = cv(); chrome(c, "SEQUENCE A+ B+ B- A- (PNEUMATIC)");
    /* cyl A top, B bottom */
    text(c, 24, 52, "A", NAVY, 2);
    cylH(c, 50, 50, 70, 16, pa, 20, RED);
    text(c, 24, 122, "B", NAVY, 2);
    cylH(c, 50, 120, 70, 16, pb, 20, RED);
    /* valves under each */
    valveBoxes(c, 200, 60, 2, 24, 20, label === "A+" ? 0 : label === "A-" ? 1 : -1);
    text(c, 200, 92, "5/2 Y1/Y2", GRAY, 1);
    valveBoxes(c, 200, 130, 2, 24, 20, label === "B+" ? 0 : label === "B-" ? 1 : -1);
    text(c, 200, 162, "5/2 Y3/Y4", GRAY, 1);
    /* pipes */
    c.line(150, 66, 200, 66, INK, 1); c.line(150, 136, 200, 136, INK, 1);
    c.line(150, 66, 130, 66, INK, 1); c.vline(58, 66, 130, INK); c.hline(120, 130, 58, INK);
    /* step banner */
    text(c, 270, 100, label, RED, 3);
    text(c, 262, 130, ["A+ EXTEND", "B+ EXTEND", "B- RETURN", "A- RETURN", "READY"][["A+", "B+", "B-", "A-", "READY"].indexOf(label)], NAVY, 1);
    /* full step list with highlight */
    ["A+", "B+", "B-", "A-"].forEach((s2, i) => {
      text(c, 300, 170 + i * 11, s2, s2 === label ? RED : GRAY, 1);
      if (s2 === label) c.rect(296, 168 + i * 11, 4, 6, RED);
    });
    text(c, 6, 205, "ISO1219 ANIMATION", GRAY, 1);
    cOut.push({ pixels: c.px, delayCs: label === "READY" ? 40 : 10 });
  }
};

/* 6) 5/2 valve switching with solenoid lamps */
GIFS["anim-pne-52-switch.gif"] = (cOut) => {
  const NF = 30;
  for (let f = 0; f < NF; f++) {
    const left = (f % 20) < 10;
    const c = cv(); chrome(c, "5/2 VALVE - ENERGISE Y1 ... PORTS SWAP");
    const vx = 120, vy = 70, bw = 34, bh = 34;
    valveBoxes(c, vx, vy, 2, bw, bh, left ? 0 : 1);
    /* ports */
    const px = { p1: vx + 8, p3: vx + 17, p5: vx + 26, p2: vx + 8, p4: vx + 26 };
    text(c, vx + 6, vy + bh + 8, "1", NAVY, 1); text(c, vx + 15, vy + bh + 8, "3", NAVY, 1); text(c, vx + 24, vy + bh + 8, "5", NAVY, 1);
    text(c, vx + 6, vy - 8, "2", NAVY, 1); text(c, vx + 24, vy - 8, "4", NAVY, 1);
    c.vline(vy + bh, vy + bh + 8, vx + 8, INK); c.vline(vy + bh, vy + bh + 8, vx + 26, INK);
    c.vline(vy - 8, vy, vx + 8, INK); c.vline(vy - 8, vy, vx + 26, INK);
    /* solenoid lamps */
    c.fillRect(vx - 26, vy + 8, 14, 12, left ? AMBER : WHITE); c.rect(vx - 26, vy + 8, 14, 12, INK);
    text(c, vx - 26, vy + 26, "Y1", left ? RED : GRAY, 1);
    c.fillRect(vx + 2 * bw + 12, vy + 8, 14, 12, left ? WHITE : AMBER); c.rect(vx + 2 * bw + 12, vy + 8, 14, 12, INK);
    text(c, vx + 2 * bw + 24, vy + 26, "Y2", left ? GRAY : RED, 1);
    springS(c, vx + 2 * bw + 4, vx + 2 * bw + 12, vy + 14);
    /* supply + cyl */
    c.vline(vy + bh + 8, vy + bh + 26, vx + 8, INK); text(c, vx - 16, vy + bh + 30, "AIR 6 BAR", NAVY, 1);
    cylH(c, 240, 80, 60, 16, left ? 0.2 : 0.8, 18, RED);
    c.rect(234, 82, 6, 4, INK); c.rect(234, 90, 6, 4, INK);
    c.line(vx + 8, vy - 8, vx + 8, 84, INK, 1); c.hline(vx + 8, 234, 84, INK);
    c.line(vx + 26, vy - 8, vx + 26, 92, INK, 1); c.hline(vx + 26, 234, 92, INK);
    const t = (f % 10) / 10;
    if (left) {
      flowAlong(c, [[vx + 8, vy + bh + 26], [vx + 8, vy + bh], [vx + 8, vy]], t, BLUE, 22, 4);
      flowAlong(c, [[vx + 8, vy - 8], [vx + 8, 84], [234, 84]], t, BLUE, 22, 4);
      flowAlong(c, [[234, 92], [vx + 26, 92], [vx + 26, vy - 8]], t, GREEN, 22, 4);
      text(c, 60, 150, "1>2 FEEDS CAP END - ROD OUT", NAVY, 1);
    } else {
      flowAlong(c, [[vx + 26, vy + bh + 26], [vx + 26, vy + bh], [vx + 26, vy]], t + 0.5, BLUE, 22, 4);
      flowAlong(c, [[vx + 26, vy - 8], [vx + 26, 92], [234, 92]], t + 0.5, BLUE, 22, 4);
      flowAlong(c, [[234, 84], [vx + 8, 84], [vx + 8, vy - 8]], t + 0.5, GREEN, 22, 4);
      text(c, 60, 150, "1>4 FEEDS ROD END - ROD IN", NAVY, 1);
    }
    text(c, 6, 205, "ISO1219 ANIMATION", GRAY, 1);
    cOut.push({ pixels: c.px, delayCs: 14 });
  }
};

/* ============ build ============ */
const outDir = process.argv[2] || "/home/user/work/gifs";
fs.mkdirSync(outDir, { recursive: true });
for (const [name, gen] of Object.entries(GIFS)) {
  const frames = [];
  gen(frames);
  const buf = encodeGIF(W, H, PAL, frames);
  fs.writeFileSync(outDir + "/" + name, buf);
  console.log(name, frames.length + " frames", (buf.length / 1024).toFixed(1) + " KB");
}
