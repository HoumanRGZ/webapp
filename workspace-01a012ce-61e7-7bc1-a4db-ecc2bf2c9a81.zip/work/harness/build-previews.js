// Build static frontend preview HTML files for the deck + learning hub (PHP-rendered markup).
const fs = require("fs");
const { loadNodeRuntime } = require("@php-wasm/node");
const { PHP } = require("/home/user/work/harness/node_modules/@php-wasm/node/node_modules/@php-wasm/universal/index.cjs");
const PLUGIN = "/home/user/work/extracted/rgz-engineering-studio";

let src = fs.readFileSync("test-wp.js", "utf8");
const stubs = src.split("const STUBS = `")[1].split("`;")[0];

(async () => {
  const rt = await loadNodeRuntime("8.2");
  const php = new PHP(rt);
  php.writeFile("/internal/rgz-mechanical-deck.php", fs.readFileSync(PLUGIN + "/rgz-mechanical-deck.php", "utf8"));
  const hyd = fs.readFileSync(PLUGIN + "/rgz-engineering-studio.php", "utf8");
  const code =
    stubs.replace("?>", "") +
    "\ndefine('ABSPATH', '/wp/');\n" +
    "$GLOBALS['__options_store'] = [];\n$GLOBALS['__hooks'] = [];\n$GLOBALS['__enqueue'] = [];\n$GLOBALS['__localize'] = [];\n$GLOBALS['__redirect'] = [];\n" +
    "?>\n" +
    hyd +
    "\n" +
    'echo "§DECK§\n" . RGZ_Mechanical_Deck::render_deck([]) . "\n§LEARN§\n" . RGZ_Mechanical_Deck::render_learn([]) . "\n§END§";';
  fs.writeFileSync("/tmp/rgz-preview-code.php", code);
  const res = await php.run({ code });
  fs.writeFileSync("/tmp/rgz-front-out.txt", res.text);
  console.log("sections:", (res.text.match(/§/g) || []).length, "len", res.text.length);
  process.exit(0);
})();
