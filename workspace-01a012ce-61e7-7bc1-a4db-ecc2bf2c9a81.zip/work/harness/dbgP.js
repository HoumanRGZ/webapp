const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const PKG = "/home/user/work/cad-pkg/rgz-3d-cad-studio";
const vc = new VirtualConsole(); // swallow everything
const dom = new JSDOM("<!DOCTYPE html><html><body></body></html>", { url: "https://houmanrgz.ir/cad/", runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc });
const win = dom.window;
win.HTMLCanvasElement.prototype.getContext = function (k) { return null; };
const t = win.document.createElement("script"); t.textContent = fs.readFileSync(PKG + "/assets/three.min.js", "utf8"); win.document.body.appendChild(t);
let src = fs.readFileSync(PKG + "/assets/cad.js", "utf8");
src = src.replace("        var drop = false;\n        if (Math.abs(N2[r + 2]) > 0.99)",
                  "        globalThis.__wv=(globalThis.__wv||[]).concat([w+':'+r+':'+P2.length]); var drop = false;\n        if (false && Math.abs(N2[r + 2]) > 0.99)");
let hits = src.split("globalThis.__wv=").length - 1;
const c = win.document.createElement("script"); c.textContent = src; win.document.body.appendChild(c);
const X = win.__rgzcad2;
if (!X) { console.log("BOOT FAIL"); process.exit(1); }
const s = X.tessLocal({ profiles: [[[0,0],[60,0],[60,45],[0,45]]], holes: [], cuts: [[[15,17.5],[45,17.5],[45,27.5],[15,27.5]]], cutDepth: 6, L: 16, bevel: {mode:0,size:0} });
const P = s.positions, N = s.normals;
let bad = 0; for (let i = 0; i < P.length/9; i++){ const l = Math.hypot(N[i*9], N[i*9+1], N[i*9+2]); if (Math.abs(l-1) > 0.01) bad++; }
console.log("w:r per iter (first 30):", (win.__wv||[]).slice(0,30).join(" "));
console.log("tris:", P.length/9, "bad:", bad);
console.log("filter body entry count (should be 44):", (win.__wv||[]).length);
