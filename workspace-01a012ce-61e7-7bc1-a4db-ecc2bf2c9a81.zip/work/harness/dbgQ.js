const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const PKG = "/home/user/work/cad-pkg/rgz-3d-cad-studio";
const vc = new VirtualConsole();
const dom = new JSDOM("<!DOCTYPE html><html><body></body></html>", { url: "https://houmanrgz.ir/cad/", runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc });
const win = dom.window;
win.HTMLCanvasElement.prototype.getContext = function (k) { return null; };
const t = win.document.createElement("script"); t.textContent = fs.readFileSync(PKG + "/assets/three.min.js", "utf8"); win.document.body.appendChild(t);
let src = fs.readFileSync(PKG + "/assets/cad.js", "utf8");
src = src.replace("filterCaps(P, N, m1, null);",
  "globalThis.__pre = [P.slice(), N.slice()]; filterCaps(P, N, m1, null); globalThis.__post = [P.slice(), N.slice(), (P === globalThis.__pre[0]), (N === globalThis.__pre[1])];");
// also neutralize the drop condition (keep write loop, the v4 setup)
src = src.replace("drop = !capRegionOk(", "drop = false && !capRegionOk(");
const c = win.document.createElement("script"); c.textContent = src; win.document.body.appendChild(c);
const X = win.__rgzcad2;
if (!X) { console.log("BOOT FAIL"); process.exit(1); }
const s = X.tessLocal({ profiles: [[[0,0],[60,0],[60,45],[0,45]]], holes: [], cuts: [[[15,17.5],[45,17.5],[45,27.5],[15,27.5]]], cutDepth: 6, L: 16, bevel: {mode:0,size:0} });
const [P0, N0, P1, N1] = [win.__pre[0], win.__pre[1], win.__post[0], win.__post[1]];
let dP = 0, dN = 0;
for (let i = 0; i < N0.length; i++) { if (P0[i] !== P1[i]) dP++; if (N0[i] !== N1[i]) dN++; }
console.log("walk1 identity? changed P:", dP, "changed N:", dN, "| same refs:", win.__post[2], win.__post[3]);
console.log("N0[0..8]:", N0.slice(0,9));
console.log("s.normals[0..8]:", Array.from(s.normals.slice(0,9)));
console.log("tris pre:", N0.length/9, "final:", s.positions.length/9);
