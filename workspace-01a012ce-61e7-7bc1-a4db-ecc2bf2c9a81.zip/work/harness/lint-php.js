const fs=require('fs');
const Engine=require('php-parser');
const parser=new Engine({parser:{extractDoc:false},ast:{withPositions:false}});
for(const f of process.argv.slice(2)){
  try{parser.parseCode(fs.readFileSync(f,'utf8'),f);console.log('OK  '+f);}
  catch(e){console.log('FAIL '+f+' :: '+e.message);process.exitCode=1;}
}
