// LIVE UI test: user-style edits to the FC opening while the sim runs,
// on the pre-designed "Meter-out speed control" and "Meter-in speed control"
// examples, plus the regenerative-center example behavior check.
const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const code = fs.readFileSync(process.argv[2], "utf8");

(async () => {
  const vc = new VirtualConsole();
  const errors = [];
  vc.on("jsdomError", (e) => errors.push(String((e && e.detail) || e)));
  const dom = new JSDOM(
    `<!DOCTYPE html><body><div id="rgz-hydraulic-studio"></div><script>${code}<\/script>`,
    {
      runScripts: "dangerously", pretendToBeVisual: true, url: "https://example.com/",
      virtualConsole: vc,
      beforeParse(window) {
        window.matchMedia = () => ({ matches: false, addEventListener() {} });
        window.confirm = () => true; window.alert = () => {};
        window.requestAnimationFrame = (cb) => setTimeout(() => cb(performance.now()), 4);
        window.SVGElement.prototype.getBBox = () => ({ x: 0, y: 0, width: 40, height: 12 });
        window.SVGSVGElement.prototype.createSVGPoint = function () {
          const pt = { x: 0, y: 0 };
          pt.matrixTransform = () => pt;
          return pt;
        };
        window.SVGSVGElement.prototype.getScreenCTM =
        window.SVGSVGElement.prototype.getCTM = () => ({
          a: 1, b: 0, c: 0, d: 1, e: 0, f: 0,
          inverse() { return this; }, multiply() { return this; },
        });
        window.console.warn = () => {};
      },
    });
  const { window } = dom; const doc = window.document;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  let failures = 0;
  const ok = (cond, name, detail) => {
    if (cond) console.log("  PASS", name, detail ?? "");
    else { failures++; console.log("  FAIL", name, "=>", detail); }
  };
  await sleep(900);

  async function loadExample(nameRegex) {
    doc.querySelector('[data-action="browse-examples"]').click();
    await sleep(150);
    const lvl = doc.getElementById("rgz-level-selectbox");
    lvl.value = lvl.options[0].value; // Simple
    lvl.dispatchEvent(new window.Event("change", { bubbles: true }));
    await sleep(200);
    const ex = doc.getElementById("rgz-example-selectbox");
    const idx = [...ex.options].findIndex((o) => nameRegex.test(o.textContent));
    if (idx < 0) return -1;
    ex.value = ex.options[idx].value;
    ex.dispatchEvent(new window.Event("change", { bubbles: true }));
    await sleep(100);
    doc.querySelector("[data-modal-open-example]").dispatchEvent(new window.MouseEvent("click", { bubbles: true }));
    await sleep(400);
    return idx;
  }

  const compIdByLabel = (label) => {
    const t = [...doc.querySelectorAll("text.component-label")].find(
      (t) => t.textContent.trim() === label);
    if (!t) return null;
    const g = t.closest("g.rgz-component");
    return g ? g.getAttribute("data-id") : null;
  };
  const simTab = async () => {
    const b = doc.querySelector('button.rgz-tab[data-tab="simulation"]');
    if (b) b.click();
    await sleep(120);
  };
  const speedOf = (label) => {
    const rows = [...doc.querySelectorAll("#rgz-inspector-panel .rgz-kv-row")];
    for (const r of rows) {
      const spans = r.querySelectorAll("span");
      if (spans.length >= 2 && spans[0].textContent.trim() === label) {
        const mm = spans[1].textContent.match(/([-\d.]+)\s*mm\/s/);
        if (mm) return parseFloat(mm[1]);
      }
    }
    return null;
  };

  async function setProp(label, key, value) {
    // select the component via pointerdown (app selection handler)
    const compId = compIdByLabel(label);
    if (!compId) return "no component " + label;
    const g = doc.querySelector(`g.rgz-component[data-id="${compId}"]`);
    const target = [...g.children].find((c) => !(c.classList && c.classList.contains("port"))) || g;
    const PD = window.PointerEvent || window.MouseEvent;
    target.dispatchEvent(new PD("pointerdown", { bubbles: true, cancelable: true }));
    await sleep(350);
    const propTab = doc.querySelector('button.rgz-tab[data-tab="properties"]');
    if (propTab) propTab.click();
    await sleep(150);
    const input = doc.querySelector(`[data-prop-field="${key}"]`);
    if (!input) return "no prop field " + key;
    input.value = String(value);
    input.dispatchEvent(new window.Event("input", { bubbles: true }));
    input.dispatchEvent(new window.Event("change", { bubbles: true }));
    await sleep(150);
    return null;
  }

  async function startSim() {
    [...doc.querySelectorAll('[data-action="simulate"]')].forEach((b) => { if (!b.disabled) b.click(); });
    await sleep(300);
  }

  // ---------- 1) Meter-out example: user-style sweep, fresh load per opening ----------
  const meterOut = {};
  for (const open of [100, 38, 6, 3]) {
    const idx = await loadExample(/Meter-out/i);
    if (idx < 0 && open === 100) { failures++; console.log("  FAIL 'Meter-out speed control' example not found"); }
    await startSim();
    await sleep(500);
    if (open !== 38) {
      const err = await setProp("FC1", "openingPercent", open);
      if (err) { failures++; console.log("  FAIL could not edit FC1 =>", err); break; }
      await sleep(600);
    }
    await simTab();
    meterOut[open] = speedOf("C1");
  }
  console.log("   meter-out live sweep (fresh load each):",
    Object.entries(meterOut).map(([k, v]) => k + "%=" + (v === null ? "?" : v.toFixed(1))).join("  "));
  ok(meterOut[100] > 110, "100% opening runs near pump-limited speed", meterOut[100]);
  ok(meterOut[38] > 110, "38% opening: physically still full speed (meter-out bites only tight)", meterOut[38]);
  ok(meterOut[6] > 40 && meterOut[6] < 105, "6% opening throttles meter-out (theory ~80)", meterOut[6]);
  ok(meterOut[3] > 5 && meterOut[3] < 45, "3% opening throttles much harder (theory ~27)", meterOut[3]);

  // ---------- 2) Meter-in example regression ----------
  idx = await loadExample(/Meter-in/i);
  ok(idx >= 0, "pre-designed 'Meter-in speed control' example found", idx);
  await startSim();
  await sleep(900);
  await simTab();
  const vi45 = speedOf("C1");
  await setProp("FC1", "openingPercent", 5);
  await sleep(900);
  await simTab();
  const vi5 = speedOf("C1");
  console.log("   meter-in live sweep: 45% ->", vi45 && vi45.toFixed(1), " 5% ->", vi5 && vi5.toFixed(1));
  ok(vi45 !== null && vi5 !== null && vi5 < vi45 * 0.6, "meter-in edit slows cylinder", vi45 + " -> " + vi5);

  // ---------- 3) Regenerative center example ----------
  // 80/50 mm cylinder: regen center rapid-extend = 25 L/min / (Aa-Ab) = 212 mm/s.
  // Sample EARLY (600 ms) so the 500 mm stroke is nowhere near its end stop.
  idx = await loadExample(/Regenerative/i);
  ok(idx >= 0, "pre-designed regenerative extension example found", idx);
  await startSim();
  await sleep(600);
  await simTab();
  const vregen = speedOf("C1");
  console.log("   regenerative center speed:", vregen && vregen.toFixed(1), "mm/s (theory 212 = Q/(Aa-Ab))");
  ok(vregen !== null && vregen > 150 && vregen < 320, "regen center: rapid extension (regen position joins P-A-B)", vregen);

  ok(errors.length === 0, "no jsdom errors", errors.join(" | ").slice(0, 200));
  console.log(failures ? `\n${failures} FAILURES` : "\nALL LIVE-EDIT TESTS PASSED");
  process.exit(failures ? 1 : 0);
})();
