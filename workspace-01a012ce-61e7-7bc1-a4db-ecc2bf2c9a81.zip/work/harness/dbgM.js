const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const PKG = "/home/user/work/cad-pkg/rgz-3d-cad-studio";
const vc = new VirtualConsole(); vc.sendTo(console, { omitJSDOMErrors: true });
const dom = new JSDOM("<!DOCTYPE html><html><body></body></html>", { url: "https://houmanrgz.ir/cad/", runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc });
const win = dom.window;
win.HTMLCanvasElement.prototype.getContext = function (k) { return null; };
const t = win.document.createElement("script"); t.textContent = fs.readFileSync(PKG + "/assets/three.min.js", "utf8"); win.document.body.appendChild(t);
let src = fs.readFileSync(PKG + "/assets/cad.js", "utf8");
// log every drop + every write where w !== r
const a1 = "drop = !capRegionOk((P2[r] + P2[r + 3] + P2[r + 6]) / 3, (P2[r + 1] + P2[r + 4] + P2[r + 7]) / 3, P2[r + 2], cutPolys);";
src = src.replace(a1, "drop = !capRegionOk((P2[r] + P2[r + 3] + P2[r + 6]) / 3, (P2[r + 1] + P2[r + 4] + P2[r + 7]) / 3, P2[r + 2], cutPolys); if (drop) { globalThis.__dr=(globalThis.__dr||[]).concat([r/9]); }");
const a2 = "if (!drop) { for (var k2 = 0; k2 < 9; k2++) { P2[w] = P2[r + k2]; N2[w] = N2[r + k2]; } w += 9; }";
src = src.replace(a2, "if (!drop) { if (w !== r) { globalThis.__mv=(globalThis.__mv||[]).concat([[w,r]]); } for (var k2 = 0; k2 < 9; k2++) { P2[w] = P2[r + k2]; N2[w] = N2[r + k2]; } w += 9; }");
const c = win.document.createElement("script"); c.textContent = src; win.document.body.appendChild(c);
const X = win.__rgzcad2;
const s = X.tessLocal({ profiles: [[[0,0],[60,0],[60,45],[0,45]]], holes: [], cuts: [[[15,17.5],[45,17.5],[45,27.5],[15,27.5]]], cutDepth: 6, L: 16, bevel: {mode:0,size:0} });
console.log("dropped tris:", JSON.stringify(win.__dr));
console.log("moves:", JSON.stringify((win.__mv||[]).slice(0,10)));
