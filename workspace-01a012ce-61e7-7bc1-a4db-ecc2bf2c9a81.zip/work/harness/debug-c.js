/* debug phase C run2 */
const fs = require("fs");
const src = fs.readFileSync("/home/user/work/harness/test-cad-pkg.js", "utf8");
const stubStart = src.indexOf("const STUBS");
const stubEnd = src.indexOf("`;", stubStart) + 2;
const STUBS = eval(src.slice(stubStart, stubEnd) + "\n;STUBS;");

(async () => {
  const { loadNodeRuntime } = require("@php-wasm/node");
  const { PHP } = require("/home/user/work/harness/node_modules/@php-wasm/node/node_modules/@php-wasm/universal/index.cjs");
  const php = new PHP(await loadNodeRuntime("8.2"));
  try { php.mkdir("/internal"); } catch (e) {}
  try { php.mkdir("/internal/uploads"); } catch (e) {}
  php.writeFile("/internal/rgz-app-packages.php", fs.readFileSync("/home/user/work/extracted/rgz-engineering-studio/rgz-app-packages.php", "utf8"));
  php.writeFile("/internal/uploads/cad-real.zip", new Uint8Array(fs.readFileSync("/home/user/rgz-3d-cad-studio.zip")));

  const head = STUBS.replace("?>", "") +
    "\ndefine('ABSPATH','/wp/');\n" +
    "$GLOBALS['__hooks']=[];$GLOBALS['__filters']=[];$GLOBALS['__shortcodes']=[];$GLOBALS['__enqueue']=[];$GLOBALS['__localize']=[];$GLOBALS['__redirect']=[];\n" +
    "require_once '/internal/rgz-app-packages.php';\n";

  const code1 = head +
    "$GLOBALS['__options_store']=[];\n" +
    "ob_start();\ntry {\n" +
    "define('RGZ_PKG_TEST',1);\n" +
    "$z='/internal/uploads/cad-real.zip';\n" +
    "$_FILES['rgz_app_package']=['name'=>'rgz-3d-cad-studio.zip','tmp_name'=>$z,'error'=>0,'size'=>filesize($z)];\n" +
    "try { RGZ_Mech_App_Packages::handle_upload(); } catch (\\Throwable $ex) { echo 'RED:' . $ex->getMessage(); }\n" +
    "} catch (\\Throwable $e) { echo 'FATAL1: ' . $e->getMessage(); }\n" +
    "$GLOBALS['__out']=ob_get_clean();\necho $GLOBALS['__out'] . '===S===' . json_encode($GLOBALS['__options_store']);";
  let res = await php.run({ code: code1 });
  let text = res.text || "";
  let opts = (text.split("===S===")[1] || "[]").trim();
  console.log("RUN1>>", text.slice(0, 200).replace(/\n/g, " "), "| opts:", opts.slice(0, 200));

  const code2 = head +
    "$GLOBALS['__options_store']=json_decode('" + opts.replace(/'/g, "\\'") + "', true) ?: [];\n" +
    "ob_start();\ntry {\n" +
    "RGZ_Mech_App_Packages::load_apps(true);\n" +
    "echo 'sc=' . (shortcode_exists('rgz_3d_cad_studio') ? 'YES' : 'NO') . '|';\n" +
    "$st = RGZ_Mech_App_Packages::runtime_status('3d-cad-studio');\n" +
    "echo 'status=' . (isset($st['status']) ? $st['status'] : '?') . '|';\n" +
    "echo 'msg=' . (isset($st['message']) ? $st['message'] : '-') . '|';\n" +
    "if (class_exists('RGZ_CAD_Studio')) { $html = RGZ_CAD_Studio::render_shortcode([]); echo 'html=' . strlen($html) . '|'; } else { echo 'class-missing|'; }\n" +
    "} catch (\\Throwable $e) { echo 'FATAL2: ' . $e->getMessage(); }\n" +
    "$GLOBALS['__out']=ob_get_clean();\necho $GLOBALS['__out'];";
  res = await php.run({ code: code2 });
  console.log("RUN2>>", (res.text || "").slice(0, 700));
})();
