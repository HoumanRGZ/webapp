const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const PKG = "/home/user/work/cad-pkg/rgz-3d-cad-studio";
function build(mod) {
  let src = fs.readFileSync(PKG + "/assets/cad.js", "utf8");
  if (mod === "v1") {
    src = src.split("filterCaps(P, N, m1, null);").join(";").split("filterCaps(P, N, m2, cuts);").join(";").split("filterCaps(P, N, m3, null);").join(";");
  } else if (mod === "v2") {
    src = src.replace("var w = from, r;\n      for (r = from; r < P2.length; r += 9) {", "var w = from, r;\n      return;\n      for (r = from; r < P2.length; r += 9) {");
  } else if (mod === "v3") {
    src = src.replace("      P2.length = w; N2.length = w;\n    }\n    /* centroid test", "      /* no truncate */\n    }\n    /* centroid test");
  } else if (mod === "v4") {   /* keep truncate, remove the condition call: never drop */
    src = src.replace("drop = !capRegionOk(", "drop = false && !capRegionOk(");
  } else if (mod === "v5") {   /* keep drop-condition, remove inner writes */
    src = src.replace("P2[w] = P2[r + k2]; N2[w] = N2[r + k2];", ";");
  }
  const vc = new VirtualConsole();
  const dom = new JSDOM("<!DOCTYPE html><html><body></body></html>", { url: "https://houmanrgz.ir/cad/", runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc });
  const win = dom.window;
  win.HTMLCanvasElement.prototype.getContext = function (k) { return null; };
  const t = win.document.createElement("script"); t.textContent = fs.readFileSync(PKG + "/assets/three.min.js", "utf8"); win.document.body.appendChild(t);
  const c = win.document.createElement("script"); c.textContent = src; win.document.body.appendChild(c);
  const X = win.__rgzcad2;
  if (!X) { return mod + ": BOOT FAILED"; }
  const s = X.tessLocal({ profiles: [[[0,0],[60,0],[60,45],[0,45]]], holes: [], cuts: [[[15,17.5],[45,17.5],[45,27.5],[15,27.5]]], cutDepth: 6, L: 16, bevel: {mode:0,size:0} });
  const P = s.positions, N = s.normals;
  let bad = 0;
  for (let i = 0; i < P.length/9; i++){ const l = Math.hypot(N[i*9], N[i*9+1], N[i*9+2]); if (Math.abs(l-1) > 0.01) bad++; }
  return mod + ": tris=" + (P.length/9) + " bad=" + bad;
}
for (const m of ["v0","v1","v2","v3","v4","v5"]) console.log(build(m));
