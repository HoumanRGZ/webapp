// UI E2E + static: variable-load teaching examples load, simulate, and record charts (both studios)
const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const code = fs.readFileSync(process.argv[2], "utf8");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let pass = 0, fail = 0;
const ok = (c, n, d) => { if (c) { pass++; console.log("  PASS", n, d ?? ""); } else { fail++; console.log("  FAIL", n, "=>", d); } };

// ---- static wiring asserts on the app source ----
ok(/textarea data-prop-field="\$\{t\.key\}"\$\{t\.placeholder/.test(code.replace(/\n/g, " ").replace(/\s+/g, " ").replace(/\\/g, "")) || code.includes('placeholder="${'),
  "property editor renders textarea placeholders");
ok((code.match(/placeholder: "0, 200\\n2, 3000"/g) || []).length === 4, "all 4 cylinder loadProfile fields carry the example placeholder");
ok((code.match(/placeholder: "0, 5\\n2, 40"/g) || []).length === 2, "both motor loadProfile fields carry the example placeholder");
ok(code.includes("Variable load press — load rises with piston position"), "hydraulic variable-load example registered");
ok(code.includes("Variable load — time-based load ramp on a 5/2 cylinder"), "pneumatic variable-load example registered");
ok(code.includes("Variable load formula — sine dance press (math in t & x)"), "formula (t & x) example registered");
ok((code.match(/formula \(t & x\)/g) || []).length >= 6, "all 6 loadMode selects offer formula (t & x)");
ok(code.includes("900*sin(2*pi*0.5*t)"), "formula example profile uses mixed t & x math");
ok(!code.includes("45 examples</span>"), "example-count badges are dynamic (no stale 45)");

function boot(mountId) {
  return new JSDOM(`<!DOCTYPE html><body><div id="${mountId}"></div><script>${code}<\/script>`, {
    runScripts: "dangerously", pretendToBeVisual: true, url: "https://example.com/", virtualConsole: new VirtualConsole(),
    beforeParse(window) {
      window.matchMedia = () => ({ matches: false, addEventListener() {} });
      window.confirm = () => true; window.alert = () => {};
      window.requestAnimationFrame = (cb) => setTimeout(() => cb(performance.now()), 4);
      window.SVGElement.prototype.getBBox = () => ({ x: 0, y: 0, width: 40, height: 12 });
      window.SVGSVGElement.prototype.createSVGPoint = function () { const pt = { x: 0, y: 0 }; pt.matrixTransform = () => pt; return pt; };
      window.SVGSVGElement.prototype.getScreenCTM = window.SVGSVGElement.prototype.getCTM = () => ({ a: 1, b: 0, c: 0, d: 1, e: 0, f: 0, inverse() { return this; }, multiply() { return this; } });
      window.console.warn = () => {};
    },
  });
}

async function pickExample(doc, window, levelRe, nameRe) {
  doc.querySelector('[data-action="browse-examples"]').click(); await sleep(150);
  const lvl = doc.getElementById("rgz-level-selectbox");
  const li = [...lvl.options].findIndex((o) => levelRe.test(o.textContent));
  ok(li >= 0, "level found in example library", lvl.options[li] && lvl.options[li].textContent);
  lvl.value = lvl.options[li].value; lvl.dispatchEvent(new window.Event("change", { bubbles: true })); await sleep(200);
  const ex = doc.getElementById("rgz-example-selectbox");
  const ei = [...ex.options].findIndex((o) => nameRe.test(o.textContent));
  ok(ei >= 0, "variable-load example listed", ex.options[ei] && ex.options[ei].textContent.trim());
  ex.value = ex.options[ei].value; ex.dispatchEvent(new window.Event("change", { bubbles: true })); await sleep(100);
  doc.querySelector("[data-modal-open-example]").dispatchEvent(new window.MouseEvent("click", { bubbles: true }));
  await sleep(400);
}

(async () => {
  console.log("== VARLOAD EXAMPLE: hydraulic studio ==");
  const dom = boot("rgz-hydraulic-studio");
  const { window } = dom; const doc = window.document;
  await sleep(900);
  await pickExample(doc, window, /Intermediate/i, /Variable load press/i);
  const labels = [...doc.querySelectorAll("text.component-label")].map((t) => t.textContent.trim()).join(",");
  ok(/C1/.test(labels) && /V1/.test(labels), "example components placed (V1 + C1)", labels);
  const hasTeaching = [...doc.querySelectorAll("text")].some((t) => /VARIABLE LOAD/i.test(t.textContent));
  ok(hasTeaching, "on-canvas teaching label explains the profile format");
  [...doc.querySelectorAll('[data-action="simulate"]')].forEach((b) => b.click());
  await sleep(2200);
  // charts recorder proves the profiled simulation produces telemetry
  doc.querySelector('[data-action="open-charts"]').click(); await sleep(250);
  const modal = doc.querySelector(".rgz-chart-modal");
  const rows = parseInt(modal.querySelector("[data-rgzch-count]").textContent, 10);
  ok(rows > 5, "simulation of the profiled press records samples", rows + " rows");
  const yIds = [...modal.querySelectorAll("[data-rgzch-y]")].map((b) => b.getAttribute("data-rgzch-y"));
  ok(yIds.some((id) => /:pos$/.test(id)), "position channel available for the press cylinder");
  // cylinder position must actually move (solver consumed the position-based profile without errors)
  modal.querySelector("[data-rgzch-render]").click(); await sleep(150);
  const svg = modal.querySelector("[data-rgzch-view] svg");
  ok(!!svg && svg.querySelector("polyline"), "telemetry renders (sim ran cleanly with position-based load)");
  [...doc.querySelectorAll('[data-action="stop"]')].forEach((b) => { if (!b.disabled) b.click(); });
  dom.window.close();

  console.log("\n== VARLOAD EXAMPLE: pneumatic studio ==");
  const dom2 = boot("rgz-pneumatic-studio");
  const doc2 = dom2.window.document;
  await sleep(900);
  await pickExample(doc2, dom2.window, /Intermediate/i, /time-based load ramp/i);
  const labels2 = [...doc2.querySelectorAll("text.component-label")].map((t) => t.textContent.trim()).join(",");
  ok(/C1/.test(labels2), "pneumatic example cylinder placed", labels2);
  [...doc2.querySelectorAll('[data-action="simulate"]')].forEach((b) => b.click());
  await sleep(1500);
  doc2.querySelector('[data-action="open-charts"]').click(); await sleep(250);
  const rows2 = parseInt(doc2.querySelector(".rgz-chart-modal [data-rgzch-count]").textContent, 10);
  ok(rows2 > 3, "pneumatic profiled circuit records samples", rows2 + " rows");
  [...doc2.querySelectorAll('[data-action="stop"]')].forEach((b) => { if (!b.disabled) b.click(); });
  dom2.window.close();

  // ---- formula example end-to-end (hydraulic studio, Advanced level) ----
  console.log("\n== FORMULA EXAMPLE: hydraulic studio ==");
  const dom3 = boot("rgz-hydraulic-studio");
  const doc3 = dom3.window.document;
  await sleep(900);
  await pickExample(doc3, dom3.window, /Advanced/i, /sine dance press/i);
  const labels3 = [...doc3.querySelectorAll("text.component-label")].map((t) => t.textContent.trim()).join(",");
  ok(/C1/.test(labels3), "formula example cylinder placed", labels3);
  const hasFormulaTeach = [...doc3.querySelectorAll("text")].some((t) => /FORMULA LOAD/i.test(t.textContent));
  ok(hasFormulaTeach, "on-canvas teaching label explains the formula syntax");
  [...doc3.querySelectorAll('[data-action="simulate"]')].forEach((b) => b.click());
  await sleep(2600);
  doc3.querySelector('[data-action="open-charts"]').click(); await sleep(250);
  const modal3 = doc3.querySelector(".rgz-chart-modal");
  const rows3 = parseInt(modal3.querySelector("[data-rgzch-count]").textContent, 10);
  ok(rows3 > 10, "formula-driven simulation records samples", rows3 + " rows");
  const yIds3 = [...modal3.querySelectorAll("[data-rgzch-y]")].map((b) => b.getAttribute("data-rgzch-y"));
  const loadCh = yIds3.find((id) => /:load$/.test(id));
  ok(!!loadCh, "applied-load channel offered for the formula cylinder");
  // plot the load channel and verify the recorded values actually swing (sin term alive)
  const boxes3 = [...modal3.querySelectorAll("[data-rgzch-y]")];
  boxes3.forEach((b) => { b.checked = b.getAttribute("data-rgzch-y") === loadCh; });
  modal3.querySelector("[data-rgzch-render]").click(); await sleep(160);
  const svg3 = modal3.querySelector("[data-rgzch-view] svg");
  ok(!!svg3 && svg3.querySelector("polyline"), "load channel renders");
  const polyPts = svg3 ? svg3.querySelector("polyline").getAttribute("points").trim().split(/\s+/) : [];
  const ys3 = polyPts.map((p) => parseFloat(p.split(",")[1]));
  ok(new Set(ys3.map((v) => v.toFixed(0))).size > 6, "formula load trace varies over the cycle (not flat)", new Set(ys3.map((v) => v.toFixed(0))).size + " distinct y");
  [...doc3.querySelectorAll('[data-action="stop"]')].forEach((b) => { if (!b.disabled) b.click(); });
  dom3.window.close();

  console.log("\n" + (fail ? "SOME FAILED" : "ALL VARIABLE-LOAD EXAMPLE TESTS PASSED") + ` (${pass} passed, ${fail} failed)`);
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error("HARNESS ERROR", e); process.exit(1); });
