const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const PKG = "/home/user/work/cad-pkg/rgz-3d-cad-studio";
const vc = new VirtualConsole(); vc.sendTo(console, { omitJSDOMErrors: true });
const dom = new JSDOM("<!DOCTYPE html><html><body></body></html>", { url: "https://houmanrgz.ir/cad/", runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc });
const win = dom.window;
win.HTMLCanvasElement.prototype.getContext = function (k) { return null; };
const t = win.document.createElement("script"); t.textContent = fs.readFileSync(PKG + "/assets/three.min.js", "utf8"); win.document.body.appendChild(t);
let src = fs.readFileSync(PKG + "/assets/cad.js", "utf8");
src = src.replace("filterCaps(P, N, m1, null);", "globalThis.__s1=[P.slice(),N.slice()]; filterCaps(P, N, m1, null); globalThis.__s2=[P.slice(),N.slice()];");
src = src.replace("var m1 = P.length;", "var m1 = P.length; globalThis.__s0=[P.slice(),N.slice()];");
const c = win.document.createElement("script"); c.textContent = src; win.document.body.appendChild(c);
const X = win.__rgzcad2;
const s = X.tessLocal({ profiles: [[[0,0],[60,0],[60,45],[0,45]]], holes: [], cuts: [[[15,17.5],[45,17.5],[45,27.5],[15,27.5]]], cutDepth: 6, L: 16, bevel: {mode:0,size:0} });
const [P0,N0] = win.__s0, [P1,N1] = win.__s1, [P2,N2] = win.__s2;
console.log("lengths: pre-filter P", P1.length, "N", N1.length, "→ post", P2.length, N2.length);
let dP = 0, dN = 0;
for (let i = 0; i < Math.min(P1.length, P2.length); i++) { if (P1[i] !== P2[i]) dP++; if (N1[i] !== N2[i]) dN++; }
console.log("changed floats around walk1: P:", dP, "N:", dN);
console.log("N pre [0..8]:", N1.slice(0,9).map(v=>+v.toFixed(2)));
console.log("N post[0..8]:", N2.slice(0,9).map(v=>+v.toFixed(2)));
console.log("P pre [27..35]:", P1.slice(27,36).map(v=>+v.toFixed(2)));
console.log("P post[27..35]:", P2.slice(27,36).map(v=>+v.toFixed(2)));
// final output check
const Pf=s.positions; console.log("final P[0..8]:", Array.from(Pf.slice(0,9)).map(v=>+v.toFixed(2)));
