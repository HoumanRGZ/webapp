// jsdom test: profile pane renders, fetches with tokens, paints profile/designs/progress.
const fs = require("fs");
const { JSDOM } = require("jsdom");
const deckJs = fs.readFileSync("../extracted/rgz-engineering-studio/assets/deck.js", "utf8");

// minimal profile pane + learning hub markup mirroring render_deck()
const html = `<!DOCTYPE html><html><body>
<section class="rgzd" data-rgz-deck>
  <div class="rgzd-tabsbar">
    <button data-deck-tab="apps"></button><button data-deck-tab="learn"></button><button data-deck-tab="profile"></button>
  </div>
  <div class="rgzd-pane on" data-deck-pane="apps"><div class="rgzd-grid"></div></div>
  <div class="rgzd-pane" data-deck-pane="learn">
    <div class="rgzl" data-rgz-learn data-default-topic="all">
      <div class="rgzl-grid">
        <article class="rgzl-card" data-lesson="hyd-pascal" data-title="Pascal" data-topic="hydraulics" data-level="beginner">
          <div class="rgzl-card-top"></div><span class="rgzl-minutes">5</span>
          <button data-read-lesson>Read</button><span class="rgzl-read-flag">read</span>
        </article>
        <template data-content="hyd-pascal"><p>x</p></template>
      </div>
      <div class="rgzl-modal-backdrop"><div class="rgzl-modal">
        <div class="rgzl-modal-head"><h2></h2><div class="rgzl-modal-meta"></div><button class="rgzl-close"></button></div>
        <div class="rgzl-modal-body"></div>
        <div class="rgzl-modal-foot"><span class="rgzl-minutes"></span><button data-mark-read>Mark as read</button></div>
      </div></div>
    </div>
  </div>
  <div class="rgzd-pane" data-deck-pane="profile">
    <div class="rgzp" data-rgz-profile>
      <div class="rgzp-signin" data-rgzp-signin><p class="rgzp-hint">hint</p></div>
      <div class="rgzp-body" data-rgzp-body hidden>
        <div class="rgzp-head"><span data-rgzp-avatar></span><b data-rgzp-name></b><span data-rgzp-email></span><span data-rgzp-badges></span></div>
        <input data-rgzp-f="first_name"><input data-rgzp-f="last_name"><input data-rgzp-f="email"><input data-rgzp-f="phone"><input data-rgzp-f="company">
        <button data-rgzp-save></button><span data-rgzp-status></span>
        <div class="rgzp-bar"><i data-rgzp-bar></i></div><span data-rgzp-barlabel></span>
        <ul data-rgzp-readlist></ul>
        <ul data-rgzp-designs="hydraulic"></ul><ul data-rgzp-designs="pneumatic"></ul>
      </div>
    </div>
  </div>
</section></body></html>`;

const dom = new JSDOM(html, { url: "https://houmanrgz.ir/deck/", pretendToBeVisual: true, runScripts: "dangerously", resources: undefined });
// inject the script as an inline <script> so it runs with the jsdom document

const { window } = dom;
let calls = [];
window.fetch = (url, opts) => {
  const params = new URLSearchParams(opts.body);
  const action = params.get("action");
  calls.push(action);
  let payload;
  if (action === "rgz_deck_profile") {
    payload = { success: true, data: {
      email: "houman@test.de", sources: ["hydraulic","pneumatic"],
      profile: { email:"houman@test.de", first_name:"Houman", last_name:"RGZ", phone:"+49", company:"RGZ Eng", progress: {"hyd-pascal": 1} },
      progress: ["hyd-pascal"],
      designs: { hydraulic: [{id:3,name:"Bench test",size:1234,date:"2026-07-01 10:00:00"}], pneumatic: [] }
    }};
  } else if (action === "rgz_deck_profile_save") {
    payload = { success: true, data: { email:"houman@test.de", sources:["hydraulic"], progress:["hyd-pascal"], profile:{ first_name: params.get("first_name"), last_name: params.get("last_name"), phone: params.get("phone"), company: params.get("company") }, designs:{hydraulic:[],pneumatic:[]} } };
  } else if (action === "rgz_deck_progress_save") {
    payload = { success: true, data: { progress: ["hyd-pascal","track-hyd-1-load-to-bore"] } };
  } else payload = { success: false };
  return Promise.resolve({ json: () => Promise.resolve(payload) });
};
window.RGZDeckConfig = { ajaxUrl: "https://houmanrgz.ir/wp-admin/admin-ajax.php", nonce: "abc" };
window.localStorage.setItem("rgzHydraulicAccountToken", "tok-h");
window.localStorage.setItem("rgzPneumaticAccountToken", "tok-p");


const scr = window.document.createElement("script");
scr.textContent = deckJs;
window.document.body.appendChild(scr);

setTimeout(() => {
  const d = window.document;
  const fails = [];
  const expect = (c, m) => { console.log((c ? "   ✓ " : "   ✗ ") + m); if (!c) fails.push(m); };

  expect(calls.includes("rgz_deck_profile"), "profile fetched on load with studio tokens");
  const nameEl = d.querySelector("[data-rgzp-name]");
  expect(nameEl && nameEl.textContent === "Houman RGZ", "full name painted: '" + (nameEl && nameEl.textContent) + "'");
  expect(d.querySelector("[data-rgzp-avatar]").textContent === "HR", "avatar initials HR");
  expect(d.querySelector('[data-rgzp-f="first_name"]').value === "Houman", "first name field filled");
  expect(d.querySelector('[data-rgzp-f="phone"]').value === "+49", "phone field filled");
  expect(d.querySelector("[data-rgzp-badges]").textContent.includes("Hydraulic") && d.querySelector("[data-rgzp-badges]").textContent.includes("Pneumatic"), "both account badges");
  expect(d.querySelector('[data-rgzp-designs="hydraulic"] li b').textContent === "Bench test", "hydraulic design row painted");
  expect(d.querySelector('[data-rgzp-designs="pneumatic"] li.none'), "pneumatic empty state");
  expect(d.querySelector("[data-rgzp-barlabel]").textContent.includes("1 / 1 lessons read"), "progress bar label 1/1");
  expect(d.querySelector('[data-lesson="hyd-pascal"]').classList.contains("is-read"), "server progress painted onto lesson card is-read");

  // save profile
  calls = [];
  d.querySelector('[data-rgzp-f="first_name"]').value = "Houman2";
  d.querySelector("[data-rgzp-save]").click();
  setTimeout(() => {
    expect(calls.includes("rgz_deck_profile_save"), "save button posts profile_save");
    expect(d.querySelector("[data-rgzp-name]").textContent === "Houman2 RGZ", "repainted after save");
    expect(d.querySelector("[data-rgzp-status]").textContent.includes("Saved"), "save status shown");

    // mark as read toggle → progress sync (need 2nd card)
    calls = [];
    window.rgzDeckProgressSync && window.rgzDeckProgressSync("track-hyd-1-load-to-bore", true);
    setTimeout(() => {
      expect(calls.includes("rgz_deck_progress_save"), "progress sync posts read lesson");
      console.log(fails.length ? "\n" + fails.length + " FAILURES" : "\nALL DECK PROFILE TESTS PASSED");
      process.exit(fails.length ? 1 : 0);
    }, 50);
  }, 50);
}, 120);
