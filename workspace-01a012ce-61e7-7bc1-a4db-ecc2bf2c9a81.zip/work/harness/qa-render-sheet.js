// QA (v3): render the app's ISO drawing sheet to PNG for visual inspection + user preview.
// Boots the REAL cad.js against the REAL app.php markup (scraped from the package),
// builds a v3 feature-tree design through the app's own API, then rasterises the sheet.
const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const { Resvg } = require("@resvg/resvg-js");
const PKG = "/home/user/work/cad-pkg/rgz-3d-cad-studio";

/* --- scrape the real shortcode markup out of app.php (literal HTML block) --- */
const php = fs.readFileSync(PKG + "/app.php", "utf8");
const start = php.indexOf("?>", php.indexOf("ob_start();"));
const retAt = php.indexOf("return ob_get_clean();");
  const end = php.lastIndexOf("<?php", retAt);
let html = php.slice(start + 2, end);
html = html.replace(/<\?php\s*echo\s*esc_url\(home_url\('([^']*)'\)\);?\s*\?>/g, (m, p) => "https://houmanrgz.ir" + p);
html = html.replace(/<\?php[^?]*\?>/g, "RGZ 3D CAD Studio");
if (html.indexOf("data-rgzcad") === -1) { console.log("scrape failed — no data-rgzcad root"); process.exit(1); }

const vc = new VirtualConsole(); vc.sendTo(console, { omitJSDOMErrors: true });
const dom = new JSDOM("<!DOCTYPE html><html><head></head><body>" + html + "</body></html>", {
  url: "https://houmanrgz.ir/cad/", runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc
});
const win = dom.window, doc = win.document;
function ctx2d(cv) {
  return new Proxy({}, {
    get(t, k) {
      if (k === "canvas") return cv;
      if (k === "measureText") return s => ({ width: 7 * String(s).length });
      if (k === "getImageData") return (x, y, w, h) => ({ data: new Uint8ClampedArray(Math.max(4, w * h * 4)) });
      if (k === "createLinearGradient" || k === "createRadialGradient") return () => ({ addColorStop() {} });
      if (k === "isPointInPath") return () => false;
      return () => {};
    },
    set() { return true; }
  });
}
win.HTMLCanvasElement.prototype.getContext = function (k) { return k === "2d" ? ctx2d(this) : null; };
win.RGZCAD = { accent: "#eb4e3c", worker: "assets/cad-geometry-worker.js", version: "1.0.0", units: "mm", hubUrl: "https://houmanrgz.ir/mechanical-engineering-deck/#learn-cad" };
const t = doc.createElement("script"); t.textContent = fs.readFileSync(PKG + "/assets/three.min.js", "utf8"); doc.body.appendChild(t);
const c = doc.createElement("script"); c.textContent = fs.readFileSync(PKG + "/assets/cad.js", "utf8"); doc.body.appendChild(c);

setTimeout(() => {
  const U = win.__rgzcad1;
  if (!U) { console.log("boot failed"); process.exit(1); }

  /* Manifold Block: 60×45 plate, 16 mm pad, 1 mm chamfer, Ø10 H7 counterbore + Ø10 through */
  U.S.design.name = "Manifold Block";
  const sk = U.startSketchOnDatum ? U.startSketchOnDatum("xy") : U.sketch();
  sk.entities.push(U.mkEnt("rect", { cx: 30, cy: 22.5, w: 60, h: 45, tol: { w: { on: true, plus: 0.3, minus: 0.3 }, h: { on: true, plus: 0.3, minus: 0.3 } } }));
  U.closeSketchToPad();
  const pad = U.S.design.features[0];
  pad.L = 16; pad.edge = { style: "chamfer", size: 1 }; pad.tol = { on: true, plus: 0.2, minus: 0 };
  sk.entities.push(U.mkEnt("hole", { cx: 15, cy: 22.5, r: 5, hType: "cbore", depth: 0, cbd: 16, cbdDepth: 4, csAngle: 90, tol: { d: { on: true, plus: 0.015, minus: 0 } } }));
  sk.entities.push(U.mkEnt("hole", { cx: 45, cy: 22.5, r: 5, hType: "through", depth: 0, cbd: 12, cbdDepth: 2, csAngle: 90 }));
  U.padSketch(sk.id);

  /* pocket pocket-sketch on the top face -> Pocket.1 */
  U.S.design.sketches.push({ id: "skQ", name: "Sketch.pocket", plane: { kind: "faceTop", topOf: pad.id, origin: [0, 0, 16], u: [1, 0, 0], v: [0, 1, 0], n: [0, 0, 1] }, host: pad.id, entities: [U.mkEnt("rect", { cx: 30, cy: 22.5, w: 30, h: 10 })] });
  U.pocketFromSketch("skQ");
  U.S.design.features[1].L = 6;

  U.setStep("drawing");
  setTimeout(() => {
    const svg = doc.querySelector("[data-sheet] svg");
    if (!svg) { console.log("NO SVG"); process.exit(1); }
    svg.setAttribute("style", "background:#ffffff");
    const s = svg.outerHTML;
    fs.writeFileSync("/home/user/work/cad-pkg/qa-sheet.svg", s);
    const r = new Resvg(s, { background: "#ffffff" });
    fs.writeFileSync("/home/user/cad-iso-drawing-preview.png", r.render().asPng());
    console.log("sheet.svg bytes:", s.length, "| PNG written | features:", U.S.design.features.map(f => f.name).join(", "));
    process.exit(0);
  }, 300);
}, 400);
