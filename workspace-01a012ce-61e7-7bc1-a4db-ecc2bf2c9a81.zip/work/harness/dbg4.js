const fs = require("fs");
const { JSDOM, VirtualConsole } = require("jsdom");
const PKG = "/home/user/work/cad-pkg/rgz-3d-cad-studio";
const vc = new VirtualConsole(); vc.sendTo(console, { omitJSDOMErrors: true });
const dom = new JSDOM("<!DOCTYPE html><html><body></body></html>", { url: "https://houmanrgz.ir/cad/", runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc });
const win = dom.window;
win.HTMLCanvasElement.prototype.getContext = function (k) { return null; };
const t = win.document.createElement("script"); t.textContent = fs.readFileSync(PKG + "/assets/three.min.js", "utf8"); win.document.body.appendChild(t);
const c = win.document.createElement("script"); c.textContent = fs.readFileSync(PKG + "/assets/cad.js", "utf8"); win.document.body.appendChild(c);
const X = win.__rgzcad2, H = win.__rgzcad3;
const payload = { profiles: [[[0,0],[60,0],[60,45],[0,45]]],
  holes: [[15,22.5,5,0,20,16,4,90],[45,22.5,5,2,20,16,4,90]],
  cuts: [[[20,20],[40,20],[40,30],[20,30]]], cutDepth: 5, L: 20, bevel: { mode: 0, size: 0 } };
const soup = X.tessLocal(payload);
const pos = soup.positions, nor = soup.normals, tris = pos.length / 9;
console.log("tris:", tris);
function vkey(i3){ return Math.round(pos[i3]*4096)+"|"+Math.round(pos[i3+1]*4096)+"|"+Math.round(pos[i3+2]*4096); }
const emap = {};
for (let i=0;i<tris;i++) for (let j=0;j<3;j++){
  const ia=i*9+3*j, ib=i*9+3*((j+1)%3);
  const ka=vkey(ia), kb=vkey(ib), ek= ka<kb ? ka+"~"+kb : kb+"~"+ka;
  let r=emap[ek]; if(!r) r=emap[ek]={a:ia,b:ib,faces:[]};
  if (ka<kb){r.a=ia;r.b=ib;} else {r.a=ib;r.b=ia;}
  if(r.faces.indexOf(i)<0) r.faces.push(i);
}
function edgeAt(x1,y1,z1,x2,y2,z2){
  const ka=[x1,y1,z1].map(v=>Math.round(v*4096)).join("|"), kb=[x2,y2,z2].map(v=>Math.round(v*4096)).join("|");
  const ek= ka<kb? ka+"~"+kb : kb+"~"+ka;
  const r=emap[ek];
  if(!r){ console.log(`edge (${x1},${y1},${z1})-(${x2},${y2},${z2}): NOT IN MAP`); return; }
  console.log(`edge (${x1},${y1},${z1})-(${x2},${y2},${z2}): faces=${r.faces.length}`);
  r.faces.forEach(f=>{ const n=[nor[f*9],nor[f*9+1],nor[f*9+2]].map(v=>v.toFixed(3)); console.log("   face",f,"n=("+n.join(",")+") p0=("+[pos[f*9],pos[f*9+1],pos[f*9+2]].map(v=>v.toFixed(2)).join(",")+")"); });
}
edgeAt(20,20,20, 40,20,20);  // long rim top
edgeAt(20,30,20, 40,30,20);
edgeAt(20,20,20, 20,30,20);  // short rim top
edgeAt(20,20,15, 40,20,15);  // long rim floor
edgeAt(20,20,15, 20,30,15);
// HLR top view
const def = H.VIEW_DEFS.top;
const hv = H.hlrView({positions: pos, normals: nor}, def);
const near = hv.runs.filter(r => (Math.abs(r.a[1]+20)<0.6||Math.abs(r.a[1]+30)<0.6) && r.a[0]>14 && r.a[0]<46);
console.log("TOP runs near v=-20/-30 in x 14..46:", near.map(r=>`(${(r.a[0]).toFixed(1)},${(r.a[1]).toFixed(1)})->(${(r.b[0]).toFixed(1)},${(r.b[1]).toFixed(1)}) ${r.vis?"VIS":"HID"}`));
