const S = require("./isolib.js");
const { Resvg } = require("@resvg/resvg-js");
const fs = require("fs");
function open(w,h){return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}"><rect width="${w}" height="${h}" fill="#FBFAF6"/>`}
let s = open(760,430);
s += S.g(110,120,1.4,S.pumpWithMotor({})),"";
s += S.g(260,120,1.4,S.hydMotor({variable:true}));
s += S.g(110,250,1.2,S.tank({}));
s += S.g(260,250,1.2,S.reliefValve({}));
s += S.g(400,120,1.3,S.dcv({boxes:[
  {arrows:[[20,20,24,80],[80,20,76,80]]},
  {closed:[[20,20],[80,20],[20,80],[80,80]]},
  {arrows:[[20,80,24,20],[80,80,76,20]]},
],solL:"Y1",solR:"Y2",springL:true,springR:true,portTop:[{x:20,label:"A"},{x:80,label:"B"}],portBottom:[{x:20,label:"P"},{x:80,label:"T"}]}));
s += S.g(560,120,1.3,S.dcv({boxes:[
  {arrows:[[50,15,50,85]]},
  {closed:[[50,15],[50,85]]},
],solL:"Y1",springR:true,portTop:[{x:50,label:"A"}],portBottom:[{x:50,label:"P"}]}));
s += S.g(400,270,1.2,S.cylDA({}));
s += S.g(560,270,1.2,S.compressor({}));
s += S.g(670,120,1.1,S.pressureGauge({}));
s += S.g(670,270,1.2,S.checkValve({piloted:true}));
s += S.g(120,360,1.2,S.oneWayFlowControl({}));
s += S.g(250,360,1.2,S.filter({}));
s += S.g(360,360,1.2,S.accumulator({}));
s += S.g(470,365,1.1,S.shuttleValve({}));
s += S.g(580,360,1.1,S.throttle({}));
s += S.g(690,360,1.1,S.cylSA({}));
s += "</svg>";
fs.writeFileSync("/home/user/work/render/proof.svg", s);
fs.writeFileSync("/home/user/work/render/proof.png", new Resvg(s,{background:"white",fitTo:{mode:"width",value:1000}}).render().asPng());
console.log("proof rendered");
