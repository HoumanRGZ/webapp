/*! RGZ Fluid Power Solver - nodal network engine (oil + air), production version.
    Self-contained single function so it can be embedded into the Web Worker blob
    via Function#toString and also run on the main thread as fallback.

    Model summary
    - Nodes = connected fluid ports (non-electrical lines). Lines are resistive
      edges (tube ID + length). Tanks/exhausts are ground anchors.
    - Valves are (possibly state-dependent, nonlinear) conductances: directional
      valves incl. all center types, check/pilot-check, relief (with override),
      reducing (downstream regulating), sequence, counterbalance, flow controls
      (needle characteristic + optional pressure compensation), shuttles
      (OR/AND), quick-exhaust, shut-offs, cartridge variants, servo/proportional.
    - Pumps/compressors are flow sources (variable units destroke at their
      compensator setting). Accumulators are gas-charged pressure offsets whose
      charge integrates over time (simChargeL prop).
    - Cylinders are motion boundary conditions: force balance from chamber
      pressures decides direction, flow availability sets the speed; cavitation
      floor and end-stops included. Position integrates on the main thread.
    API: rgzFluidSolve({fluid:'oil'|'air', components, connections, dt, time}) */
/*! RGZ Fluid Power Solver - nodal network engine (oil + air), production version.
    Self-contained single function so it can be embedded into the Web Worker blob
    via Function#toString and also run on the main thread as fallback.

    Model summary
    - Nodes = connected fluid ports (non-electrical lines). Lines are resistive
      edges (tube ID + length). Tanks/exhausts are ground anchors.
    - Valves are (possibly state-dependent, nonlinear) conductances: directional
      valves incl. all center types, check/pilot-check, relief (with override),
      reducing (downstream regulating), sequence, counterbalance, flow controls
      (needle characteristic + optional pressure compensation), shuttles
      (OR/AND), quick-exhaust, shut-offs, cartridge variants, servo/proportional.
    - Pumps/compressors are flow sources (variable units destroke at their
      compensator setting). Accumulators are gas-charged pressure offsets whose
      charge integrates over time (simChargeL prop).
    - Cylinders are motion boundary conditions: force balance from chamber
      pressures decides direction, flow availability sets the speed; cavitation
      floor and end-stops included. Position integrates on the main thread.
    API: rgzFluidSolve({fluid:'oil'|'air', components, connections, dt, time}) */
/*! RGZ Fluid Power Solver - nodal network engine (oil + air), production version.
    Self-contained single function so it can be embedded into the Web Worker blob
    via Function#toString and also run on the main thread as fallback.

    Model summary
    - Nodes = connected fluid ports (non-electrical lines). Lines are resistive
      edges (tube ID + length). Tanks/exhausts are ground anchors.
    - Valves are (possibly state-dependent, nonlinear) conductances: directional
      valves incl. all center types, check/pilot-check, relief (with override),
      reducing (downstream regulating), sequence, counterbalance, flow controls
      (needle characteristic + optional pressure compensation), shuttles
      (OR/AND), quick-exhaust, shut-offs, cartridge variants, servo/proportional.
    - Pumps/compressors are flow sources (variable units destroke at their
      compensator setting). Accumulators are gas-charged pressure offsets whose
      charge integrates over time (simChargeL prop).
    - Cylinders are motion boundary conditions: force balance from chamber
      pressures decides direction, flow availability sets the speed; cavitation
      floor and end-stops included. Position integrates on the main thread.
    API: rgzFluidSolve({fluid:'oil'|'air', components, connections, dt, time}) */
function rgzFluidSolve(opts) {
  "use strict";
  opts = opts || {};
  var FLUID = opts.fluid === "air" ? "air" : "oil";
  var comps = opts.components || [];
  var conns = opts.connections || [];
  var TIME = num(opts.time, 0), DT = num(opts.dt, 0);

  function num(v, f) { var n = Number(v); return Number.isFinite(n) ? n : f; }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  /* Load profiles — two syntaxes:
     1) Point table: "x, load" per line/semicolon — x = seconds (time-based) or
        stroke fraction 0..1 / rev fraction (position-based), load in kg (cyl)
        or N·m (motor). Linear interpolation, clamped ends.
     2) Formula: any math in t (sim seconds) and/or x (stroke or rev fraction
        0..1), evaluated fresh every tick — e.g. "800 + 400*sin(2*pi*t)",
        "min(2500, 3000*x^2)", "if(t<1, 200, 900)". Both variables are bound
        at the same time, so mixed laws like "sin(t) + 800*x" work. */
  var EXPR_CACHE = rgzFluidSolve._expr || (rgzFluidSolve._expr = {});
  var EXPR_FUNS = {
    abs: Math.abs, sqrt: Math.sqrt, cbrt: Math.cbrt, exp: Math.exp, ln: Math.log,
    log: Math.log10, pow: Math.pow, min: Math.min, max: Math.max,
    sin: Math.sin, cos: Math.cos, tan: Math.tan, asin: Math.asin, acos: Math.acos,
    atan: Math.atan, atan2: Math.atan2, sinh: Math.sinh, cosh: Math.cosh, tanh: Math.tanh,
    floor: Math.floor, ceil: Math.ceil, round: Math.round, sign: Math.sign,
    fract: function (v) { return v - Math.floor(v); },
    clamp: function (v, a, b) { return v < a ? a : v > b ? b : v; },
    step: function (edge, v) { return v >= edge ? 1 : 0; },
    pulse: function (v, a, b) { return v >= a && v < b ? 1 : 0; },
    ramp: function (v, a, b) { return b === a ? (v >= a ? 1 : 0) : clamp((v - a) / (b - a), 0, 1); },
    hypot: Math.hypot, deg: function (r) { return r * 180 / Math.PI; }, rad: function (dg) { return dg * Math.PI / 180; },
  };
  function exprTokens(src) {
    var re = /\s*(?:((?:[0-9]*\.[0-9]+|[0-9]+\.?[0-9]*)(?:[eE][+-]?[0-9]+)?)|([A-Za-z_][A-Za-z0-9_]*)|(<=|>=|==|!=|[-+*/%^(),<>]))/y;
    var out = [], m, guard = 0;
    re.lastIndex = 0;
    while (re.lastIndex < src.length) {
      var i0 = re.lastIndex;
      m = re.exec(src);
      if (!m) throw new Error("token");
      if (m[1] !== undefined) out.push({ n: parseFloat(m[1]) });
      else if (m[2] !== undefined) out.push({ f: m[2].toLowerCase() });
      else if (m[3] !== undefined) out.push({ o: m[3] });
      if (re.lastIndex === i0 || ++guard > 4000) throw new Error("token");
    }
    return out;
  }
  function compileExpr(src) {
    var key = String(src);
    if (key in EXPR_CACHE) return EXPR_CACHE[key];
    var fn = null;
    try {
      var toks = exprTokens(key), pos = 0;
      function peek() { return toks[pos] || null; }
      function err() { throw new Error("parse"); }
      function parseCmp() {
        var l = parseAdd(), k = peek();
        if (k && k.o && (k.o === "<" || k.o === ">" || k.o === "<=" || k.o === ">=" || k.o === "==" || k.o === "!=")) {
          pos++;
          var r = parseAdd();
          if (k.o === "<") return function (t, x) { return l(t, x) < r(t, x) ? 1 : 0; };
          if (k.o === ">") return function (t, x) { return l(t, x) > r(t, x) ? 1 : 0; };
          if (k.o === "<=") return function (t, x) { return l(t, x) <= r(t, x) ? 1 : 0; };
          if (k.o === ">=") return function (t, x) { return l(t, x) >= r(t, x) ? 1 : 0; };
          if (k.o === "==") return function (t, x) { return l(t, x) === r(t, x) ? 1 : 0; };
          return function (t, x) { return l(t, x) !== r(t, x) ? 1 : 0; };
        }
        return l;
      }
      function parseAdd() {
        var l = parseMul(), k;
        while ((k = peek()) && k.o && (k.o === "+" || k.o === "-")) {
          pos++;
          var r = parseMul();
          if (k.o === "+") (function (a, b) { l = function (t, x) { return a(t, x) + b(t, x); }; })(l, r);
          else (function (a, b) { l = function (t, x) { return a(t, x) - b(t, x); }; })(l, r);
        }
        return l;
      }
      function parseMul() {
        var l = parseUnary(), k;
        while ((k = peek()) && k.o && (k.o === "*" || k.o === "/" || k.o === "%")) {
          pos++;
          var r = parseUnary();
          if (k.o === "*") (function (a, b) { l = function (t, x) { return a(t, x) * b(t, x); }; })(l, r);
          else if (k.o === "/") (function (a, b) { l = function (t, x) { return b(t, x) === 0 ? 0 : a(t, x) / b(t, x); }; })(l, r);
          else (function (a, b) { l = function (t, x) { var m = b(t, x); return m === 0 ? 0 : a(t, x) % m; }; })(l, r);
        }
        return l;
      }
      function parseUnary() {
        var k = peek();
        if (k && k.o === "-") { pos++; var u = parseUnary(); return function (t, x) { return -u(t, x); }; }
        if (k && k.o === "+") { pos++; return parseUnary(); }
        return parsePow();
      }
      function parsePow() {
        var base = parseAtom(), k = peek();
        if (k && k.o === "^") {
          pos++;
          var ex = parseUnary(); // right-assoc, binds tighter than unary minus
          return function (t, x) { var v = Math.pow(base(t, x), ex(t, x)); return Number.isFinite(v) ? v : 0; };
        }
        return base;
      }
      function parseAtom() {
        var k = peek();
        if (!k) err();
        if (k.n !== undefined) { pos++; var v = k.n; return function () { return v; }; }
        if (k.o === "(") {
          pos++;
          var e0 = parseCmp();
          var c = peek(); if (!c || c.o !== ")") err();
          pos++;
          return e0;
        }
        if (k.f !== undefined) {
          pos++;
          var name = k.f;
          if (name === "t") return function (t) { return t; };
          if (name === "x") return function (t2, x) { return x; };
          if (name === "pi") return function () { return Math.PI; };
          if (name === "tau") return function () { return 2 * Math.PI; };
          if (name === "e") return function () { return Math.E; };
          {
            var fnk = k.f === "if" ? function (c2, a2, b2) { return c2 ? a2 : b2; } : EXPR_FUNS[k.f];
            if (!fnk) err();
            var p0 = peek(); if (!p0 || p0.o !== "(") err();
            pos++;
            var args = [];
            if (!(peek() && peek().o === ")")) {
              args.push(parseCmp());
              while (peek() && peek().o === ",") { pos++; args.push(parseCmp()); }
            }
            var p1 = peek(); if (!p1 || p1.o !== ")") err();
            pos++;
            return function (t, x) {
              var vals = new Array(args.length);
              for (var iA = 0; iA < args.length; iA++) vals[iA] = args[iA](t, x);
              var rv = fnk.apply(null, vals);
              return Number.isFinite(rv) ? rv : 0;
            };
          }
          err();
        }
        err();
      }
      var parsed = parseCmp();
      if (pos !== toks.length) err();
      fn = function (t, x) {
        var v = parsed(num(t, 0), num(x, 0));
        return Number.isFinite(v) ? v : null;
      };
    } catch (eParse) { fn = null; }
    EXPR_CACHE[key] = fn;
    return fn;
  }
  function profileVal(str, axis, t, x) {
    if (!str) return null;
    var rows, pts = [], i, pair, a, b;
    var s = String(str).trim();
    if (!s) return null;
    var tableLike = /^[-0-9eE,;.\s+]+$/.test(s) && s.indexOf(",") >= 0;
    if (tableLike) {
      rows = s.split(/[;\n]+/);
      for (i = 0; i < rows.length; i++) {
        pair = rows[i].split(",");
        a = parseFloat(pair[0]); b = parseFloat(pair[1]);
        if (Number.isFinite(a) && Number.isFinite(b)) pts.push([a, b]);
      }
      if (pts.length) {
        pts.sort(function (p1, p2) { return p1[0] - p2[0]; });
        var xv = num(axis, 0);
        if (xv <= pts[0][0]) return pts[0][1];
        if (xv >= pts[pts.length - 1][0]) return pts[pts.length - 1][1];
        for (i = 1; i < pts.length; i++) {
          if (xv <= pts[i][0]) {
            var x0 = pts[i - 1][0], x1 = pts[i][0], y0 = pts[i - 1][1], y1 = pts[i][1];
            return y0 + (y1 - y0) * (x1 === x0 ? 0 : (xv - x0) / (x1 - x0));
          }
        }
        return pts[pts.length - 1][1];
      }
    }
    var f = compileExpr(s);
    return f ? f(num(t, 0), num(x, 0)) : null;
  }
  function warnProfileOnce(key, label, isMotor) {
    var bag = DYN.warnProf || (DYN.warnProf = {});
    if (bag[key]) return;
    bag[key] = 1;
    warnings.push((label || (isMotor ? "Motor" : "Cylinder")) + ": load profile could not be parsed — using the constant " +
      (isMotor ? "torque" : "load") + ". Use 'value, load' points or a formula in t and x, e.g. 800 + 400*sin(2*pi*t).");
  }
  /* current load (kg) for a cylinder component at this tick */
  function cylLoadKg(P, pos, comp) {
    var mode = String(P.loadMode || "constant");
    if (mode === "time-based" || mode === "position-based" || mode.indexOf("formula") === 0) {
      var axis = mode === "position-based" ? pos : TIME;
      var pv = profileVal(P.loadProfile, axis, TIME, pos);
      if (pv != null) return Math.max(0, pv);
      if (String(P.loadProfile || "").trim()){
        var t0 = compileExpr(String(P.loadProfile).trim());
        // wrong syntax path only — nothing more to do here
        if (!t0) warnProfileOnce(comp ? comp.id : "cyl", comp && comp.label, false);
      }
    }
    return Math.max(0, num(P.loadKg, 0));
  }
  /* current torque load (N·m) for a motor component at this tick */
  function motorLoadNm(P, comp) {
    var mode = String(P.loadMode || "constant");
    if (mode === "time-based" || mode === "position-based" || mode.indexOf("formula") === 0) {
      var ang = num(P.simAngle, 0) / (2 * Math.PI);
      ang = ang - Math.floor(ang);
      var pv = profileVal(P.loadProfile, mode === "position-based" ? ang : TIME, TIME, ang);
      if (pv != null) return pv;
      if (String(P.loadProfile || "").trim() && !compileExpr(String(P.loadProfile).trim())) {
        warnProfileOnce(comp ? comp.id : "mot", comp && comp.label, true);
      }
    }
    return Math.max(0, num(P.loadNm, 0));
  }

  // ---- persistent per-run state (spool timers, cylinder motion, pressure memory)
  var DYN = rgzFluidSolve._dyn;
  if (!DYN || num(TIME, 0) < num(DYN.tNow, 0) - 1e-9) {
    DYN = rgzFluidSolve._dyn = { t: {}, cyl: {}, p: {}, tNow: 0 };
  }
  DYN.tNow = TIME;

  var FLOOR = FLUID === "air" ? -1.0 : -0.9;       // cavitation / vacuum floor, bar
  var LEAK = FLUID === "air" ? 6e-4 : 1.2e-4;      // parasitic leak, L/min/bar
  var PATM = 1.01325;
  var warnings = [];

  var intensPairs = [], vacPairs = [], accumEdges = [], regulators = [], dividers = [];

  // ---------- node registry: one node per referenced port ----------
  var compById = {};
  comps.forEach(function (c) { compById[c.id] = c; });
  var nodeIdx = {}, nodeKeys = [], nodeComp = [], nodePort = [];
  function nodeId(cid, pid, create) {
    var k = cid + "." + pid;
    if (k in nodeIdx) return nodeIdx[k];
    if (!create) return -1;
    nodeIdx[k] = nodeKeys.length; nodeKeys.push(k); nodeComp.push(cid); nodePort.push(pid);
    return nodeIdx[k];
  }
  function pOf(cid, pid) { return nodeId(cid, pid, false); }

  var fluidLines = [];
  conns.forEach(function (c) {
    if (!c || c.lineType === "electrical") return;
    var a = compById[c.from && c.from.componentId], b = compById[c.to && c.to.componentId];
    if (!a || !b) return;
    if (a.type === "textLabel" || b.type === "textLabel") return;
    nodeId(c.from.componentId, c.from.portId, true);
    nodeId(c.to.componentId, c.to.portId, true);
    fluidLines.push(c);
  });
  var N = nodeKeys.length;
  var portConnCount = {};
  fluidLines.forEach(function (c) {
    var k1 = c.from.componentId + "." + c.from.portId, k2 = c.to.componentId + "." + c.to.portId;
    portConnCount[k1] = (portConnCount[k1] || 0) + 1;
    portConnCount[k2] = (portConnCount[k2] || 0) + 1;
  });
  function wired(cid, pid) { return (portConnCount[cid + "." + pid] || 0) > 0; }

  // ---------- edge / source containers ----------
  var edges = [], injections = [];
  function addG(a, b, g, tag, cid) {
    if (a < 0 || b < 0 || !(g > 0)) return null;
    var e = { a: a, b: b, g: g, dyn: null, tag: tag || "", compId: cid || null, flow: 0 };
    edges.push(e); return e;
  }
  function addDynG(a, b, fn, tag, cid) { // fn(pA,pB,edge,pAll) -> conductance L/min/bar
    if (a < 0) return null;
    var e = { a: a, b: (b == null ? -2 : b), g: 0, dyn: fn, tag: tag || "", compId: cid || null, flow: 0 };
    edges.push(e); return e;
  }
  function addGnd(a, g, tag, cid) {
    if (a < 0 || !(g > 0)) return null;
    var e = { a: a, b: -1, g: g, dyn: null, tag: tag || "", compId: cid || null, flow: 0 };
    edges.push(e); return e;
  }
  function addSrc(node, q, tag, cid) {
    if (node < 0) return null;
    var s = { node: node, q: q, qNow: q, dynQ: null, tag: tag || "", compId: cid || null };
    injections.push(s); return s;
  }

  // ---------- conductance law helpers ----------
  function sqrt0(v) { return Math.sqrt(Math.max(v, 0)); }
  function orificeG(kv, dp) { return kv / Math.max(sqrt0(Math.abs(dp)), 0.05); }
  function airOrificeG(kv, pUp, dp) { return kv * sqrt0(Math.max(pUp, 0) + PATM) / Math.max(sqrt0(Math.abs(dp)), 0.05); }
  function kvFromRated(qRated, dpRated, fluidOverride) {
    var air = fluidOverride ? fluidOverride === "air" : FLUID === "air";
    if (air) return qRated / Math.max(sqrt0(7.013) * sqrt0(dpRated || 0.3), 0.05);
    return qRated / Math.max(sqrt0(dpRated || 5), 0.25);
  }
  function lineG(c) {
    var pr = (c && c.properties) || {};
    var d = Math.max(1.5, num(pr.tubeIdMm, FLUID === "air" ? 6 : 12));
    var L = clamp(num(pr.lengthM, 1), 0.05, 400);
    var q0, dp;
    if (FLUID === "air") {
      q0 = 250;
      dp = (0.0105 * L / Math.pow(d, 5.07)) * Math.pow(q0, 1.85) / 4.0;
      return Math.min(q0 / Math.max(dp, 0.002), 3000);
    }
    q0 = 25;
    dp = (0.1847 * L / Math.pow(d, 4)) * q0 + (0.068 * L / Math.pow(d, 4.75)) * Math.pow(q0, 1.75);
    return Math.min(q0 / Math.max(dp, 0.004), 350);
  }
  function reliefG(pUp, setB, qRated, e) { // clamp: Q = g*(p - setB) above setting, plain leak below
    var band = Math.max(2, 0.04 * setB);
    var frac = clamp((pUp - (setB - 0.6)) / band, 0, 1);
    if (e) e.off = frac > 0 ? setB - 0.6 : 0;
    var gFull = Math.max(num(qRated, 60) / 8, 2); // ~8 bar override at rated flow
    return LEAK * 0.02 + (gFull - LEAK * 0.02) * frac; // below crack: sealed-leak class
  }

  var BIGG = FLUID === "air" ? 4000 : 400;         // wide-open path, L/min/bar
  var G_GND = 1e6;

  // ---------- classify ----------
  var pumps = [], reliefs = [], cylinders = [], motors = [], accums = [], gauges = [], flowmeters = [], motorRecs = [];
  comps.forEach(function (c) {
    var t = c.type;
    if (t === "pumpFixed" || t === "pumpVariable" || t === "compressorFixed" || t === "compressorVariable" || t === "powerPack") pumps.push(c);
    if (t === "reliefValve" || t === "cartridgeReliefValve" || t === "powerPack") reliefs.push(c);
    if (t === "cylinderDA" || t === "cylinderSA") cylinders.push(c);
    if (t === "hydraulicMotor" || t === "pneumaticMotor") motors.push(c);
    if (t === "accumulator") accums.push(c);
    if (t === "pressureGauge" || t === "pressureSwitch" || t === "pressureTransducer" || t === "testPoint") gauges.push(c);
    if (t === "flowMeter" || t === "flowSwitch") flowmeters.push(c);
  });
  var reliefSetting = reliefs.length
    ? Math.min.apply(null, reliefs.map(function (c) { return num(c.props.settingBar != null ? c.props.settingBar : c.props.reliefSettingBar, 160); }))
    : (FLUID === "air" ? 8 : 160);

  // ---------- component models ----------
  comps.forEach(function (c) {
    var t = c.type, P = c.props || {};

    if (t === "powerPack") {
      var q = Math.max(0, num(P.flowLpm, 25));
      var iP = pOf(c.id, "P"), iT = pOf(c.id, "T");
      if (iT >= 0) addGnd(iT, G_GND, "tank", c.id);
      if (iP >= 0 && q > 0) addSrc(iP, q, "pump", c.id);
      var setB = num(P.reliefSettingBar, 160);
      if (iP >= 0) addDynG(iP, iT, function (pA, pB, e) { return reliefG(pA, setB, q, e); }, "relief", c.id);
      return;
    }
    if (t === "tank" || t === "exhaust" || t === "breatherFiller") {
      var iTk = pOf(c.id, "T"); if (iTk >= 0) addGnd(iTk, G_GND, "tank", c.id);
      return;
    }
    if (t === "silencer") {
      var iSi = pOf(c.id, "E");
      if (iSi >= 0) addGnd(iSi, Math.max(1400 / (1 + num(P.noiseReductionDb, 20) / 10), 15), "silencer", c.id);
      return;
    }
    if (t === "pumpFixed" || t === "compressorFixed") {
      var q2 = Math.max(0, num(P.flowLpm, 25)), iS = pOf(c.id, "S"), iP2 = pOf(c.id, "P");
      if (iS >= 0) addGnd(iS, G_GND, "suction", c.id);
      if (iP2 >= 0 && q2 > 0) {
        var mx = num(P.maxPressureBar, 180);
        var bandCut = Math.max(1.5, 0.05 * mx);
        var s0 = addSrc(iP2, q2, "pump", c.id);
        var cutOn = mx + bandCut * 0.4 - bandCut; // full flow below this
        s0.dynQ = function (pN) { return pN >= cutOn ? 0 : q2; };
        s0.dynS = function (pN) { return pN >= cutOn ? -q2 / bandCut : 0; };
        s0.qRef = cutOn + bandCut; // anchor: q = (q2/bandCut)*(qRef - p)
      }
      return;
    }
    if (t === "pumpVariable" || t === "compressorVariable") {
      var q3 = Math.max(0, num(P.flowLpm, 32)), iS2 = pOf(c.id, "S"), iP3 = pOf(c.id, "P");
      if (iS2 >= 0) addGnd(iS2, G_GND, "suction", c.id);
      if (iP3 >= 0 && q3 > 0) {
        var cp3 = num(P.compensatorBar, 160);
        var bandV = Math.max(0.06 * cp3, 2);
        var s1 = addSrc(iP3, q3, "pump", c.id);
        s1.dynQ = function (pN) { return pN >= cp3 - bandV ? 0 : q3; };
        s1.dynS = function (pN) { return pN >= cp3 - bandV ? -q3 / bandV : 0; };
        s1.qRef = cp3; // pressure-compensated: holds qRef when stroke drops to 0
      }
      return;
    }
    if (t === "reliefValve" || t === "cartridgeReliefValve") {
      var set2 = num(P.settingBar, 160);
      if (pOf(c.id, "P") >= 0) addDynG(pOf(c.id, "P"), pOf(c.id, "T"), function (pA, pB, e) { return reliefG(pA, set2, num(P.maxFlowLpm, 120), e); }, "relief", c.id);
      return;
    }
    if (t === "cartridgeUnloadingValve") {
      var setU = num(P.unloadBar, 120), iXU = pOf(c.id, "X");
      addDynG(pOf(c.id, "P"), pOf(c.id, "T"), function (pA, pB, e, p) {
        var px = iXU >= 0 ? p[iXU] : 0;
        return reliefG(Math.max(pA, px), setU, num(P.maxFlowLpm, 100), e);
      }, "relief", c.id);
      return;
    }
    if (t === "directionalValve" || t === "pneumaticMemoryValve") { modelDirectional(c); return; }
    if (t === "servoValve") { modelServo(c); return; }
    if (t === "checkValve" || t === "cartridgeCheckValve") {
      var cr = num(P.crackingBar, 0.5);
      var cidH = c.id;
      // Hysteresis (Schmitt trigger): a hard on/off edge flips when the opened valve
      // equalises its ports, and the relaxation then freezes it half-shut (phantom
      // trapped pressure in bypass branches -> e.g. 269 bar behind a stalled check).
      // Open at pA > pB + cr, close at pA < pB + 0.2*cr, hold state in between.
      addDynG(pOf(c.id, "A"), pOf(c.id, "B"), function (pA, pB) {
        var S = DYN.checkHyst || (DYN.checkHyst = {});
        var st = S[cidH] ? 1 : 0;
        if (pA > pB + cr) st = 1;
        else if (pA < pB + 0.2 * cr) st = 0;
        S[cidH] = st;
        return st ? BIGG * 0.5 : LEAK * 0.02;
      }, "check", c.id);
      return;
    }
    if (t === "pilotCheckValve") {
      var cr2 = num(P.crackingBar, 1), ratio = Math.max(1, num(P.pilotRatio, 3));
      var iX2 = pOf(c.id, "X");
      // Pilot piston mechanically unseats the poppet: no pB > pA guard — a real PO
      // check releases even against a fully depressurised load line (the old guard
      // locked the valve shut whenever the held pressure had leaked down, so the
      // return stroke stalled with the pump at relief).
      addDynG(pOf(c.id, "A"), pOf(c.id, "B"), function (pA, pB, e, p) {
        if (pA > pB + cr2) return BIGG * 0.5;
        var px = iX2 >= 0 ? p[iX2] : 0;
        if (px > 0.5 && px * ratio > pB - pA + cr2) return BIGG * 0.25;
        return LEAK * 0.02;
      }, "pcheck", c.id);
      return;
    }
    if (t === "counterbalanceValve" || t === "cartridgeCounterbalanceValve") {
      var set3 = num(P.settingBar, 120), r3 = Math.max(1, num(P.pilotRatio, 3)), iX3 = pOf(c.id, "X");
      addDynG(pOf(c.id, "A"), pOf(c.id, "B"), function (pA, pB, e, p) {
        if (pA > pB) return BIGG * 0.4;
        var px = iX3 >= 0 ? p[iX3] : 0;
        var frac = clamp((pB - (set3 - r3 * px)) / Math.max(2, 0.04 * set3) + 0.5, 0, 1);
        return LEAK * 0.02 + (BIGG * 0.2 - LEAK * 0.02) * frac;
      }, "cb", c.id);
      return;
    }
    if (t === "flowControl" || t === "cartridgeNeedleFlowValve") { modelFlowControl(c); return; }
    if (t === "reducingValve" || t === "cartridgeReducingValve") {
      var iPr = pOf(c.id, "P"), iAr = pOf(c.id, "A"), iTr = pOf(c.id, "T");
      if (iAr >= 0) regulators.push({
        cid: c.id, kind: "red", iP: iPr, iA: iAr, ventTo: iTr,
        set: num(P.outletBar, 45), gC: FLUID === "air" ? 60 : 25,
        gSup: BIGG * 0.5, gV: FLUID === "air" ? 8 : 1.5, qNow: 0,
      });
      return;
    }
    if (t === "sequenceValve" || t === "cartridgeSequenceValve") {
      var set4 = t === "cartridgeSequenceValve" ? num(P.sequenceBar, 70) : num(P.settingBar, 70);
      addDynG(pOf(c.id, "P"), pOf(c.id, "A"), function (pA) {
        return LEAK + (BIGG * 0.3 - LEAK) * clamp((pA - set4) / Math.max(2, 0.05 * set4) + 0.5, 0, 1);
      }, "seq", c.id);
      var iT4 = pOf(c.id, "T"); if (iT4 >= 0) addGnd(iT4, LEAK * 5, "drain", c.id);
      return;
    }
    if (t === "pressureCompensator") {
      var dpc = num(P.deltaPBar, 8), iXc = pOf(c.id, "X");
      addDynG(pOf(c.id, "P"), pOf(c.id, "A"), function (pA, pB, e, p) {
        var px = iXc >= 0 ? p[iXc] : pB;
        return BIGG * 0.3 * clamp((px + dpc - pB) / 2, 0, 1) + LEAK;
      }, "pc", c.id);
      return;
    }
    if (t === "logicCartridgeValve") {
      var iXl = pOf(c.id, "X");
      var ratio3 = Math.max(1, num(P.pilotRatio, 2));
      var cidL = c.id;
      // DIN 24342 slip-in poppet with control cover: the spring-side (cover) area
      // exceeds the ported areas, so X pressurised such that px*(area ratio)
      // exceeds the line pressure clamps the poppet shut; a vented/weak X leaves
      // it free to lift (opens from either port). Schmitt trigger on
      // px*ratio vs max(pA,pB,0) with a 0.3 bar band: a hard un-hysteresised law
      // (old "px + 0.3 > max*0.6") closed the valve at its own ~zero pressure
      // drop, and the geometric-mean relaxation then froze it half-shut, leaving
      // phantom back-pressure (258 bar) on an open leg — plus a wide close margin
      // let the piloted legs leak at low pilot pressure and short the bridge.
      addDynG(pOf(c.id, "A"), pOf(c.id, "B"), function (pA, pB, e, p) {
        var S = DYN.logicHyst || (DYN.logicHyst = {});
        var st = S[cidL] == null ? 1 : S[cidL];   // at rest (X vented) the poppet is free to lift
        var px = iXl >= 0 ? p[iXl] : 0;
        var pMax = Math.max(0, pA, pB);
        if (px * ratio3 > pMax + 0.15) st = 0;
        else if (px * ratio3 < pMax - 0.15) st = 1;
        S[cidL] = st;
        return st ? BIGG * 0.6 : LEAK * 0.02;
      }, "logic", c.id);
      return;
    }
    if (t === "shutoffValve") {
      addG(pOf(c.id, "A"), pOf(c.id, "B"), P.open === false ? LEAK * 0.02 : BIGG * 0.8, "shutoff", c.id);
      return;
    }
    if (t === "cartridgeSolenoidValve22") {
      var open22 = P.energized ? !P.normallyOpen : !!P.normallyOpen;
      addG(pOf(c.id, "P"), pOf(c.id, "A"), open22 ? BIGG * 0.5 : LEAK * 0.02, "cart22", c.id);
      return;
    }
    if (t === "shuttleValve" || t === "cartridgeShuttleValve" || t === "twoPressureValve") {
      var isAnd = t === "twoPressureValve";
      var iAs = pOf(c.id, "A"), iBs = pOf(c.id, "B"), iXs = pOf(c.id, "X");
      if (iXs >= 0) {
        if (iAs >= 0) addDynG(iAs, iXs, function (pA, pX, e, p) {
          var pb = iBs >= 0 ? p[iBs] : 0;
          return LEAK + (BIGG - LEAK) * (isAnd ? clamp((pb - pA) / 0.4 + 0.5, 0, 1) : clamp((pA - pb) / 0.4 + 0.5, 0, 1));
        }, isAnd ? "and" : "or", c.id);
        if (iBs >= 0) addDynG(iBs, iXs, function (pB, pX, e, p) {
          var pa = iAs >= 0 ? p[iAs] : 0;
          return LEAK + (BIGG - LEAK) * (isAnd ? clamp((pa - pB) / 0.4 + 0.5, 0, 1) : clamp((pB - pa) / 0.4 + 0.5, 0, 1));
        }, isAnd ? "and" : "or", c.id);
      }
      return;
    }
    if (t === "quickExhaustValve") {
      var iPq = pOf(c.id, "P"), iAq = pOf(c.id, "A"), iRq = pOf(c.id, "R");
      addDynG(iPq, iAq, function (pA, pB) { return pA >= pB - 0.05 ? BIGG * 0.7 : LEAK; }, "qe-in", c.id);
      if (iRq >= 0) {
        addDynG(iAq, iRq, function (pA, pB, e, p) { return pA > (iPq >= 0 ? p[iPq] : 0) - 0.05 ? BIGG * 1.2 : LEAK; }, "qe-out", c.id);
        addGnd(iRq, BIGG * 0.9, "qe-atm", c.id);
      } else {
        addDynG(iAq, -1, function (pA, pB, e, p) { return pA > (iPq >= 0 ? p[iPq] : 0) - 0.05 ? BIGG * 1.2 : LEAK; }, "qe-out", c.id);
      }
      return;
    }
    if (t === "softStartValve") {
      var iPs = pOf(c.id, "P"), iAs2 = pOf(c.id, "A"), iRs = pOf(c.id, "R"), keySs = "ss." + c.id;
      addDynG(iPs, iAs2, function (pA) {
        if (pA > 1) { if (!(keySs in DYN.t)) DYN.t[keySs] = TIME; } else delete DYN.t[keySs];
        var on = keySs in DYN.t ? clamp((TIME - DYN.t[keySs]) / Math.max(0.1, num(c.props.rampTimeS, 1.5)), 0, 1) : 0;
        return LEAK + BIGG * 0.6 * clamp(on, 0.04, 1);
      }, "softstart", c.id);
      if (iRs >= 0) {
        addDynG(iAs2, iRs, function (pA, pB, e, p) { return (iPs >= 0 ? p[iPs] : 0) < 0.5 ? BIGG * 0.8 : LEAK; }, "softdump", c.id);
        addGnd(iRs, BIGG * 0.5, "ss-atm", c.id);
      } else {
        addDynG(iAs2, -1, function (pA, pB, e, p) { return (iPs >= 0 ? p[iPs] : 0) < 0.5 ? BIGG * 0.8 : LEAK; }, "softdump", c.id);
      }
      return;
    }
    if (t === "pneumaticTimeDelayValve") {
      var iPt = pOf(c.id, "P"), iAt = pOf(c.id, "A"), iRt = pOf(c.id, "R"), keyTd = "td." + c.id;
      var tdElapsed = function (pIn) {
        if (pIn > 1) { if (!(keyTd in DYN.t)) DYN.t[keyTd] = TIME; }
        else { delete DYN.t[keyTd]; }
        return pIn > 1 && (TIME - DYN.t[keyTd] >= num(c.props.delayS, 1));
      };
      addDynG(iPt, iAt, function (pA) { return tdElapsed(pA) ? BIGG * 0.5 : LEAK * 2; }, "tdelay", c.id);
      if (iRt >= 0) {
        addDynG(iAt, iRt, function (pA, pB, e, p) { return !tdElapsed(iPt >= 0 ? p[iPt] : 0) ? BIGG * 0.6 : LEAK; }, "td-ex", c.id);
        addGnd(iRt, BIGG * 0.5, "td-atm", c.id);
      } else {
        addDynG(iAt, -1, function (pA, pB, e, p) { return !tdElapsed(iPt >= 0 ? p[iPt] : 0) ? BIGG * 0.6 : LEAK; }, "td-ex", c.id); // unwired R = open exhaust
      }
      return;
    }
    if (t === "flowDivider") {
      // Positive-displacement / spool flow divider-combiner: the branch carrying
      // MORE than its share must see extra resistance so the other branch gets
      // fed (a plain conductance ratio evaluates flows only once per solve call
      // — stale — so the first cylinder simply grabbed the whole pump and the
      // second never started). The ratio law below reads the live branch flows
      // directly from the current iterate (p[] x gNow) every assemble, and the
      // built-in geometric-mean damping of dynamic edges provides the
      // under-relaxation, giving a stable equalising fixed point: branch above
      // its share is throttled up to 10x, branch below up to 0.35x.
      // Positive-displacement / spool divider-combiner: it FORCES the flow that
      // arrives at the P port to split qA:qB = sA:(1-sA) whatever the two branch
      // loads are (the reason it exists: cylinder synchronisation). In nodal
      // terms it is a current device, not a resistance — every conductance-only
      // model lets the first actuator own the whole pump, so the two stages ran
      // strictly sequentially. Here the divider sinks whatever flow actually
      // reaches P and re-issues exactly sA / (1-sA) of it into the branches as
      // flow sources (combiner direction handled by sign). The cylinder
      // root-solve reads the branch sources as sustained supply, so both
      // actuators move on their shares at the same time; the measured inlet
      // flow is refreshed and damped after every network solve, so choking the
      // inlet (valve centred, relief dumping) throttles the split too. A tiny
      // primer conductance per branch seeds the flow feedback on cold start.
      var sA = clamp(num(P.splitPercentA, 50), 5, 95) / 100;
      var iPd = pOf(c.id, "P"), iAd = pOf(c.id, "A"), iBd = pOf(c.id, "B");
      var gPrim = FLUID === "air" ? 12 : 1;
      var sIn = iPd >= 0 ? addSrc(iPd, 0, "div-in", c.id) : null, sA1 = iAd >= 0 ? addSrc(iAd, 0, "div-a", c.id) : null, sB1 = iBd >= 0 ? addSrc(iBd, 0, "div-b", c.id) : null;
      if (iPd >= 0 && iAd >= 0) addG(iPd, iAd, gPrim, "div-primer", c.id);
      if (iPd >= 0 && iBd >= 0) addG(iPd, iBd, gPrim, "div-primer", c.id);
      if (!DYN.div) DYN.div = {};
      dividers.push({
        cid: c.id, iP: iPd, iA: iAd, iB: iBd, sA: sA,
        sIn: sIn, sA1: sA1, sB1: sB1, qIn: DYN.div[c.id] || 0, qMax: 5,
        inc: null,
      });
      if (sIn) sIn.divTag = 1; if (sA1) sA1.divTag = 1; if (sB1) sB1.divTag = 1;
      return;
    }
    if (t === "filter" || t === "cooler" || t === "suctionStrainer" || t === "oilHeater" || t === "flowMeter" || t === "flowSwitch") {
      addG(pOf(c.id, "A"), pOf(c.id, "B"), FLUID === "air" ? 900 : 90, "passive", c.id);
      return;
    }
    if (t === "junction" || t === "compressedAirDistributor") {
      var prts = [];
      for (var u2 = 0; u2 < N; u2++) if (nodeComp[u2] === c.id) prts.push(u2);
      for (var u3 = 1; u3 < prts.length; u3++) addG(prts[0], prts[u3], 2e4, "junction", c.id);
      return;
    }
    if (t === "cartridgeManifoldBlock") {
      // HIC through-galleries: P -> A (supply), T -> B (return). NOT a common junction.
      var iPm = pOf(c.id, "P"), iAm = pOf(c.id, "A"), iTm = pOf(c.id, "T"), iBm = pOf(c.id, "B");
      if (iPm >= 0 && iAm >= 0) addG(iPm, iAm, BIGG * 0.8, "manifoldPA", c.id);
      if (iTm >= 0 && iBm >= 0) addG(iTm, iBm, BIGG * 0.8, "manifoldTB", c.id);
      return;
    }
    if (t === "valveTerminal") {
      // Manifold valve island: P feeds the station outlets A1..A4 (common supply gallery);
      // B ports and R share the exhaust gallery. Passive manifold (per-station switching
      // is by the electrical layer); ports that are unwired simply stay isolated.
      var iPvt = pOf(c.id, "P"), iRvt = pOf(c.id, "R");
      ["A1", "A2", "A3", "A4"].forEach(function (pa) {
        var ia = pOf(c.id, pa);
        if (iPvt >= 0 && ia >= 0) addG(iPvt, ia, BIGG * 0.5, "vt-supply", c.id);
      });
      ["B1", "B2", "B3", "B4"].forEach(function (pb) {
        var ib = pOf(c.id, pb);
        if (iRvt >= 0 && ib >= 0) addG(iRvt, ib, BIGG * 0.5, "vt-exhaust", c.id);
      });
      return;
    }
    if (t === "frlUnit") {
      var iPf = pOf(c.id, "P"), iAf = pOf(c.id, "A");
      if (iAf >= 0) regulators.push({
        cid: c.id, kind: "frl", iP: iPf, iA: iAf, ventTo: -1,
        set: num(P.regulatorBar, 6), gC: 80, gSup: 1500, gV: 12, qNow: 0,
      });
      return;
    }
    if (t === "accumulator") {
      var iAa2 = pOf(c.id, "A");
      if (iAa2 >= 0) {
        var V0 = Math.max(0.2, num(P.volumeL, 5));
        var pre = Math.max(0, num(P.prechargeBar, 70));
        var stored = clamp(num(P.simChargeL, 0), 0, V0 * 0.98);
        var pAcc = pre * (V0 / Math.max(V0 - stored, 0.05 * V0));
        accumEdges.push({ comp: c, iA: iAa2, g: FLUID === "air" ? 150 : 15, pAcc: pAcc, stored: stored, V0: V0 });
      }
      return;
    }
    if (t === "hydraulicIntensifier") {
      var rt = Math.max(1.1, num(P.ratio, 2));
      addG(pOf(c.id, "P"), pOf(c.id, "A"), BIGG * 0.04, "intens", c.id);
      intensPairs.push({ iP: pOf(c.id, "P"), iA: pOf(c.id, "A"), rt: rt });
      var iTi = pOf(c.id, "T"); if (iTi >= 0) addGnd(iTi, BIGG * 0.4, "intensT", c.id);
      return;
    }
    if (t === "vacuumEjector") {
      var iPv = pOf(c.id, "P"), iVv = pOf(c.id, "V"), iRv = pOf(c.id, "R");
      var qv = num(P.airConsumptionLpm, 90);
      addDynG(iPv, iRv, function (pA) { return airOrificeG(kvFromRated(qv, 5.5), Math.max(pA, 0), Math.abs(pA)); }, "eject", c.id);
      if (iRv >= 0) addGnd(iRv, BIGG * 0.6, "eject-atm", c.id);
      if (iVv >= 0) vacPairs.push({ iV: iVv, vac: num(P.vacuumKpa, -65) / 100, g: BIGG * 0.4 });
      return;
    }
    if (t === "suctionCup") {
      var iVc = pOf(c.id, "V"); if (iVc >= 0) addGnd(iVc, Math.max(LEAK * 60, 0.02), "cup-leak", c.id);
      return;
    }
    if (t === "airBlowNozzle") {
      var iPn = pOf(c.id, "P");
      if (iPn >= 0) addGnd(iPn, airOrificeG(kvFromRated(num(P.flowLpm, 120), 6), 6, 6), "nozzle", c.id);
      return;
    }
    if (t === "hydraulicMotor" || t === "pneumaticMotor") {
      var disp0 = Math.max(1, num(P.displacementCcRev, 25));
      var offT = FLUID === "air" ? 0 : Math.max(0, motorLoadNm(P, c)) * 20 * Math.PI / disp0;
      var mrec = { id: c.id, iA: pOf(c.id, "A"), iB: pOf(c.id, "B"), locked: false };
      motorRecs.push(mrec);
      if (mrec.iA < 0 || mrec.iB < 0) return;
      addDynG(mrec.iA, mrec.iB, function (pA, pB, e) {
        if (mrec.locked) { e.off = 0; return LEAK * 0.02; } // sealed both sides: no phantom circulation
        e.off = offT;
        return FLUID === "air" ? 500 : 30;
      }, "motor", c.id);
      return;
    }
    // measurement / electrical / annotation components: no fluid edges
  });

  function modelFlowControl(c) {
    var P = c.props || {};
    var o = clamp(num(P.openingPercent, 65), 0, 100) / 100;
    var qMax = num(P.maxFlowLpm, 0) || (FLUID === "air" ? 600 : 60);
    var iA = pOf(c.id, "A"), iB = pOf(c.id, "B");
    if (iA < 0 || iB < 0) return;
    var kvMax = FLUID === "air" ? qMax / sqrt0(7.013) : qMax; // ~1 bar drop at full opening
    var kv = kvMax * Math.pow(Math.max(o, 0.004), 1.6);
    if (!P.pressureCompensated) {
      addDynG(iA, iB, function (pA, pB) {
        var dp = Math.abs(pA - pB);
        return FLUID === "air" ? airOrificeG(kv, Math.max(pA, pB), dp) : orificeG(kv, dp);
      }, "fc", c.id);
      return;
    }
    var qSet = qMax * o; // pressure-compensated set point
    addDynG(iA, iB, function (pA, pB) {
      var dp = Math.abs(pA - pB);
      if (dp < 3) return FLUID === "air" ? airOrificeG(kv, Math.max(pA, pB), dp) : orificeG(kv, dp);
      return qSet / dp;
    }, "fc-pc", c.id);
  }

  function modelDirectional(c) {
    var P = c.props || {};
    var state = String(P.spoolState || "center");
    var ports = String(P.ports || "4");
    var kv = kvFromRated(num(P.ratedFlowLpm, 40), Math.max(0.1, num(P.pressureDropBar, 5)));
    var gOpen = FLUID === "air" ? airOrificeG(kv, 6, 0.3) : orificeG(kv, 1.5);
    var gBlocked = Math.max(gOpen * 2e-3, LEAK);
    var nP = pOf(c.id, "P"), nT = pOf(c.id, "T"), nA = pOf(c.id, "A"), nB = pOf(c.id, "B");
    var nR = pOf(c.id, "R"), nS = pOf(c.id, "S");
    // pneumatic valves with an unwired exhaust port exhaust straight to atmosphere
    function ex(n) { return n; }
    if (FLUID === "air") { // unwired exhaust ports vent to atmosphere; wired ones keep their plumbing
      if (nT >= 0 && !wired(c.id, "T")) addGnd(nT, gOpen * 1.5, "dcv-exh", c.id);
      if (nR >= 0 && !wired(c.id, "R")) addGnd(nR, gOpen * 1.5, "dcv-exh", c.id);
      if (nS >= 0 && !wired(c.id, "S")) addGnd(nS, gOpen * 1.5, "dcv-exh", c.id);
    }
    var isMem = c.type === "pneumaticMemoryValve";
    var pairs = [];
    if (isMem) {
      if (state === "left") pairs = [[nP, nA], [nB, nS >= 0 ? nS : nR]];
      else pairs = [[nP, nB], [nA, nR >= 0 ? nR : nS]];
    } else if (ports === "2") {
      if (state === "left") pairs = [[nP, nA]];
    } else if (ports === "3") {
      pairs = state === "left" ? [[nP, nA]] : [[nA, nT]];
    } else {
      // every envelope is user-selectable now: left/right blocks use the same
      // pattern vocabulary as the centre (legacy defaults: left = parallel
      // P->A/B->T, right = crossover P->B/A->T, so old projects are unchanged).
      var blockSet = function (name, dflt) {
        var b = String(name || dflt);
        if (b === "parallel") return [[nP, nA], [nB, nT]];
        if (b === "crossover") return [[nP, nB], [nA, nT]];
        if (b === "open") return [[nP, nT], [nA, nT], [nB, nT]];
        if (b === "tandem") return [[nP, nT]];
        if (b === "float") return [[nA, nT], [nB, nT]];
        if (b === "regenerative") return [[nP, nA], [nB, nA]];
        return [];
      };
      if (state === "left") pairs = blockSet(P.leftBlock, "parallel");
      else if (state === "right") pairs = blockSet(P.rightBlock, "crossover");
      else pairs = blockSet(P.center, "closed");
    }
    pairs.forEach(function (pr) {
      if (pr[0] >= 0 && pr[1] >= 0) {
        addDynG(pr[0], pr[1], function (pA2, pB2) {
          var dp = Math.abs(pA2 - pB2);
          return FLUID === "air" ? airOrificeG(kv, Math.max(pA2, pB2), dp) : orificeG(kv, dp);
        }, "dcv", c.id);
      } else if (FLUID === "air" && pr[0] >= 0 && pr[1] < 0) addGnd(pr[0], gOpen, "dcv-exh2", c.id); // missing exhaust port -> atmosphere
    });
    var nX = pOf(c.id, "X"), nY = pOf(c.id, "Y");
    if (nX >= 0) addGnd(nX, LEAK * 4, "pilotvent", c.id);
    if (nY >= 0) addGnd(nY, LEAK * 4, "pilotvent", c.id);
  }

  function modelServo(c) {
    var P = c.props || {};
    var cmd = clamp(num(P.commandPercent, 0), -100, 100);
    var nP = pOf(c.id, "P"), nT = pOf(c.id, "T"), nA = pOf(c.id, "A"), nB = pOf(c.id, "B");
    var kv = kvFromRated(num(P.ratedFlowLpm, 40), 5);
    var open = Math.abs(cmd) < 3 ? 0 : Math.abs(cmd) / 100;
    var g = FLUID === "air" ? airOrificeG(kv * open, 6, 0.3) : orificeG(kv * open, 1.5);
    var gB = Math.max(g * 2e-3, LEAK);
    if (open > 0) {
      var kvEff = kv * open;
      var sPairs = cmd > 0 ? [[nP, nA], [nB, nT]] : [[nP, nB], [nA, nT]];
      sPairs.forEach(function (pr) {
        if (pr[0] >= 0 && pr[1] >= 0) addDynG(pr[0], pr[1], function (pA2, pB2) {
          var dp = Math.abs(pA2 - pB2);
          return FLUID === "air" ? airOrificeG(kvEff, Math.max(pA2, pB2), dp) : orificeG(kvEff, dp);
        }, "servo", c.id);
      });
    }
  }

  // ---------- lines ----------
  var lineEdges = [];
  fluidLines.forEach(function (c) {
    var a = pOf(c.from.componentId, c.from.portId), b = pOf(c.to.componentId, c.to.portId);
    if (a < 0 || b < 0) return;
    var e = addG(a, b, lineG(c), "line", null);
    if (e) { e.lineId = c.id; e.lineProps = c.properties || {}; lineEdges.push(e); }
  });

  // ---------- cylinder boundary conditions ----------
  var cyls = cylinders.map(function (c) {
    var P = c.props || {};
    var bore = Math.max(8, num(P.boreMm, 50)) / 1000;
    var rod = c.type === "cylinderDA" ? clamp(num(P.rodMm, 36), 0, 0.95 * bore * 1000) / 1000 : 0;
    var Aa = Math.PI * bore * bore / 4;
    var Ab = c.type === "cylinderDA" ? Math.max(0.2 * Aa, Aa - Math.PI * rod * rod / 4) : 0;
    var stroke = Math.max(20, num(P.strokeMm, 300));
    var pos0 = clamp(num(P.simPosition, 0.2), 0, 1);
    var Fload = cylLoadKg(P, pos0, c) * 9.81;
    var st = DYN.cyl[c.id] || (DYN.cyl[c.id] = { q: 0 });
    return {
      comp: c, Aa: Aa, Ab: Ab, stroke: stroke, P: P,
      Fload: Fload,
      iA: pOf(c.id, "A"), iB: pOf(c.id, "B"),
      pos: pos0,
      st: st, q: st.q || 0, starving: false,
      v: 0, pA: 0, pB: 0, force: 0, qA: 0, qB: 0, dir: 0,
    };
  });
  (function () { var ids = {}; cyls.forEach(function (x) { ids[x.comp.id] = 1; }); for (var k in DYN.cyl) if (!(k in ids)) delete DYN.cyl[k]; })();


  // ---------- linear system ----------
  var p = new Float64Array(N);
  for (var si = 0; si < N; si++) p[si] = num(DYN.p[nodeKeys[si]], 0);
  var G = new Float64Array(N * N), bvec = new Float64Array(N), lastP = null;

  function assemble() {
    G.fill(0); bvec.fill(0);
    var i, e, g;
    for (i = 0; i < edges.length; i++) {
      e = edges[i];
      if (e.dyn) e.off = 0;
      g = e.dyn ? (e.dyn(p[e.a] || 0, e.b >= 0 ? p[e.b] : 0, e, p) || 0) : e.g;
      g = Math.max(g, 1e-12);
      if (e.dyn) { // damp state-dependent conductances to kill flip-flop cycles
        if (!(e.gD > 0)) e.gD = g;
        else e.gD = Math.sqrt(e.gD * g); // geometric mean relaxation
        g = e.gD;
      }
      e.gNow = g;
      if (e.b === -1) {
        G[e.a * N + e.a] += e.gNow;
        if (e.off) bvec[e.a] += e.gNow * e.off;
      } else if (e.b >= 0) {
        G[e.a * N + e.a] += e.gNow; G[e.b * N + e.b] += e.gNow;
        G[e.a * N + e.b] -= e.gNow; G[e.b * N + e.a] -= e.gNow;
        if (e.off) { bvec[e.a] += e.gNow * e.off; bvec[e.b] -= e.gNow * e.off; }
      }
    }
    for (i = 0; i < injections.length; i++) {
      var s = injections[i];
      var pn = p[s.node] || 0;
      var q = s.dynQ ? s.dynQ(pn) : s.q;
      s.qNow = q || 0;
      var slp = s.dynS ? s.dynS(pn) || 0 : 0;     // dq/dp (<=0) of the source characteristic
      if (Math.abs(slp) > 1e-9) {
        var qAnchor = s.qRef != null ? (-slp) * s.qRef : (s.qNow - slp * pn); // q = (-slp)*(qRef - p)
        G[s.node * N + s.node] += -slp;
        bvec[s.node] += qAnchor;
        s.qNow = Math.max((-slp) * ((s.qRef != null ? s.qRef : 0) - pn), 0);
      } else {
        bvec[s.node] += s.qNow;
      }
    }
    for (i = 0; i < accumEdges.length; i++) {
      var ac = accumEdges[i], pn = p[ac.iA] || 0;
      var active = pn > ac.pAcc || ac.stored > 0.005 * ac.V0 || (FLUID === "air" && ac.pAcc <= 0);
      var g2 = active ? ac.g : LEAK;
      G[ac.iA * N + ac.iA] += g2;
      bvec[ac.iA] += g2 * ac.pAcc;
      ac.gNow = g2;
    }
    for (i = 0; i < intensPairs.length; i++) {
      var it = intensPairs[i];
      if (it.iA < 0) continue;
      var gI = BIGG * 0.03, tgt = it.rt * (it.iP >= 0 ? p[it.iP] : 0);
      G[it.iA * N + it.iA] += gI; bvec[it.iA] += gI * tgt;
    }
    for (i = 0; i < vacPairs.length; i++) {
      var vq = vacPairs[i];
      var gV = (p[vq.iV] || 0) > vq.vac ? vq.g : LEAK;
      G[vq.iV * N + vq.iV] += gV; bvec[vq.iV] += gV * vq.vac;
    }
    for (i = 0; i < regulators.length; i++) {
      var rg = regulators[i];
      if (rg.iA < 0) continue;
      var pP = rg.iP >= 0 ? p[rg.iP] || 0 : 0, pA = p[rg.iA] || 0;
      var qC = rg.gC * (rg.set - pA);
      var supCap = rg.gSup * Math.max(pP - pA, 0);
      var ventCap = rg.gV * Math.max(pA, 0);
      // decide mode with hysteresis so the branch cannot flack between iterations
      var mode = rg.mode || "band";
      if (pA > pP + 0.5) {
        // downstream pressure exceeds inlet: reverse blocked, relieve via drain only
        if (mode !== "vent") mode = "vent";
      } else if (mode === "band") {
        if (qC > 1.25 * supCap) mode = "cap";
        else if (qC < -1.25 * ventCap) mode = "vent";
      } else if (mode === "cap") {
        if (qC < 0.8 * supCap) mode = "band";
      } else if (mode === "vent") {
        if (qC > -0.8 * ventCap) mode = "band";
      }
      rg.mode = mode;
      if (mode === "cap" && rg.iP >= 0) {
        G[rg.iA * N + rg.iA] += rg.gSup; G[rg.iP * N + rg.iP] += rg.gSup;
        G[rg.iA * N + rg.iP] -= rg.gSup; G[rg.iP * N + rg.iA] -= rg.gSup;
        rg.qNow = supCap;
      } else if (mode === "vent") {
        var setX = rg.set + 0.4;
        if (pA > setX - 0.6) { // poppet opens only above setting: Q = gV*(pA - pT - setX)
          G[rg.iA * N + rg.iA] += rg.gV; bvec[rg.iA] += rg.gV * setX;
          if (rg.ventTo >= 0) { G[rg.ventTo * N + rg.ventTo] += rg.gV; G[rg.iA * N + rg.ventTo] -= rg.gV; G[rg.ventTo * N + rg.iA] -= rg.gV; bvec[rg.ventTo] -= rg.gV * setX; }
          rg.qNow = -rg.gV * Math.max(pA - (rg.ventTo >= 0 ? p[rg.ventTo] || 0 : 0) - setX, 0);
        } else rg.qNow = 0;
      } else {
        G[rg.iA * N + rg.iA] += rg.gC; bvec[rg.iA] += rg.gC * rg.set;
        if (qC > 0 && rg.iP >= 0) { G[rg.iP * N + rg.iA] -= rg.gC; bvec[rg.iP] -= rg.gC * rg.set; }
        else if (qC < 0 && rg.ventTo >= 0) { G[rg.ventTo * N + rg.iA] -= rg.gC; bvec[rg.ventTo] -= rg.gC * rg.set; }
        rg.qNow = qC;
      }
    }
    for (i = 0; i < N; i++) G[i * N + i] += LEAK;
    for (i = 0; i < cyls.length; i++) {
      var cy = cyls[i];
      if (cy.iA >= 0) bvec[cy.iA] -= cy.qA || 0; // extraction from node into chamber
      if (cy.iB >= 0) bvec[cy.iB] -= cy.qB || 0;
    }
  }

  var dbgA = null, dbgB = null;
  function solveLin() {
    var n = N, A = G, b = bvec, i, j, k, f, t2;
    if (rgzFluidSolve._trace && !dbgA) { dbgA = Float64Array.from(G); dbgB = Float64Array.from(bvec); }
    for (k = 0; k < n; k++) {
      var piv = k, mx = Math.abs(A[k * n + k]);
      for (i = k + 1; i < n; i++) { var v2 = Math.abs(A[i * n + k]); if (v2 > mx) { mx = v2; piv = i; } }
      if (mx < 1e-12) { A[k * n + k] = 1e-12; mx = 1e-12; }
      if (piv !== k) {
        for (j = k; j < n; j++) { t2 = A[k * n + j]; A[k * n + j] = A[piv * n + j]; A[piv * n + j] = t2; }
        t2 = b[k]; b[k] = b[piv]; b[piv] = t2;
      }
      for (i = k + 1; i < n; i++) {
        f = A[i * n + k] / A[k * n + k];
        if (f !== 0) { for (j = k; j < n; j++) A[i * n + j] -= f * A[k * n + j]; b[i] -= f * b[k]; }
      }
    }
    for (i = n - 1; i >= 0; i--) {
      var acc = b[i];
      for (j = i + 1; j < n; j++) acc -= A[i * n + j] * p[j];
      p[i] = acc / A[i * n + i];
      if (!Number.isFinite(p[i])) p[i] = 0;
    }
    if (rgzFluidSolve._trace && dbgA) {
      var rmax = 0, ri = -1;
      for (i = 0; i < n; i++) {
        var acc2 = -dbgB[i];
        for (j = 0; j < n; j++) acc2 += dbgA[i * n + j] * p[j];
        if (Math.abs(acc2) > rmax) { rmax = Math.abs(acc2); ri = i; }
      }
      console.log("  solve residual max", rmax.toExponential(2), "at node", nodeKeys[ri], "p=", p[ri].toFixed(2));
      dbgA = null; dbgB = null;
    }
  }

  var pCap = FLUID === "air" ? 25 : 1000;
  (function () {
    var caps = [];
    if (reliefs.length) caps.push(reliefSetting + 20);
    pumps.forEach(function (cp) {
      var m1 = num(cp.props.maxPressureBar, 0), m2 = num(cp.props.compensatorBar, 0) || num(cp.props.reliefSettingBar, 0);
      var c2 = Math.max(m1, m2);
      if (c2 > 0) caps.push(c2 + 15);
    });
    if (caps.length) pCap = Math.min(pCap, Math.min.apply(null, caps));
    // Rod-side metering can intensify pressure ABOVE the pump ceiling by the
    // cylinder area ratio (pB ~ pA * Aa/Ab). If the clamp sits at the pump
    // ceiling, the back-pressure that makes meter-out speed control work can
    // never form and the cylinder runs at full speed — physically wrong.
    if (FLUID !== "air") {
      var ratio = 1;
      cyls.forEach(function (cy) { if (cy.Ab > 0) ratio = Math.max(ratio, Math.min(5, cy.Aa / cy.Ab)); });
      if (ratio > 1.01) pCap = Math.min(1200, Math.ceil(pCap * ratio * 1.05));
    }
  })();
  function applyFloor() {
    for (var i = 0; i < cyls.length; i++) {
      var cy = cyls[i];
      if (cy.iA >= 0 && (cy.qA || 0) > 0 && p[cy.iA] < FLOOR) p[cy.iA] = FLOOR;
      if (cy.iB >= 0 && (cy.qB || 0) > 0 && p[cy.iB] < FLOOR) p[cy.iB] = FLOOR;
    }
    for (i = 0; i < N; i++) {
      if (p[i] < FLOOR - 0.5) p[i] = FLOOR - 0.5;
      else if (p[i] > pCap) p[i] = pCap;
    }
  }

  function edgeFlows() {
    for (var i = 0; i < edges.length; i++) {
      var e = edges[i];
      var pa = p[e.a] || 0, pb = (e.b >= 0 ? p[e.b] : 0) + (e.off || 0);
      e.flow = e.gNow * (pa - pb);
    }
    for (i = 0; i < accumEdges.length; i++) {
      var ac = accumEdges[i];
      ac.flow = (ac.gNow || 0) * ((p[ac.iA] || 0) - ac.pAcc); // + into accumulator
    }
  }

  // ---------- network solve helper (damped nonlinear iteration)
  function solveNetwork(quick) {
    var K = quick ? 14 : 30, prev = null, k, md;
    for (k = 0; k < K; k++) {
      assemble();
      solveLin();
      applyFloor();
      if (prev) {
        md = 0;
        for (var i2 = 0; i2 < N; i2++) md = Math.max(md, Math.abs(p[i2] - prev[i2]));
        if (md < 0.005 && k >= 8) break;
      }
      prev = Float64Array.from(p);
    }
    edgeFlows();
  }

  // ---------- reference reachability (is this node hydraulically ventable?)
  var GMIN = 2e-5; // L/min/bar: below this a chamber cluster is sealed (closed valve paths sit at LEAK*0.02~2.4e-6; tight throttles stay orders of magnitude above)
  function reachesReference(start) {
    if (start < 0) return false;
    var seen = {}, stack = [start], guard = 0;
    while (stack.length && guard++ < 4 * (N + edges.length + 8)) {
      var n = stack.pop();
      if (n === -2) return true; // virtual reference node (accumulator battery)
      if (seen[n]) continue;
      seen[n] = 1;
      for (var i = 0; i < edges.length; i++) {
        var e = edges[i], g = e.gNow != null ? e.gNow : e.g;
        if (e.b === -1 && e.a === n && g > GMIN && e.tag !== "cyl-dem") return true; // ground anchor
        if (g <= GMIN) continue;
        if (e.a === n && e.b >= 0 && !seen[e.b]) stack.push(e.b);
        else if (e.b === n && e.a >= 0 && !seen[e.a]) stack.push(e.a);
      }
      for (var j = 0; j < injections.length; j++) if (injections[j].node === n && (injections[j].q || 0) > 0.01) return true; // real sources only (not chamber expulsion)
      for (var r = 0; r < regulators.length; r++) {                       // regulator transfer paths
        var rg = regulators[r];
        if (rg.iA === n) { if (rg.iP >= 0) stack.push(rg.iP); if (rg.ventTo >= 0) stack.push(rg.ventTo); }
        else if (rg.iP === n || rg.ventTo === n) stack.push(rg.iA);
      }
      for (var a2 = 0; a2 < accumEdges.length; a2++) if (accumEdges[a2].iA === n) stack.push(-2);
    }
    return false;
  }
  function cylLocked(cy) {
    var ra = cy.iA >= 0 ? reachesReference(cy.iA) : false;
    if (cy.Ab <= 0) return !ra;                 // single-acting: only A matters
    var rb = cy.iB >= 0 ? reachesReference(cy.iB) : false;
    return !(ra && rb);
  }

  // Sustained fill capacity of a chamber cluster [L/min]: what steady inflow can
  // reach it. Ground anchors (tank suction) and accumulators = unlimited; otherwise
  // the sum of pump deliveries reachable through open paths. If the opposite chamber
  // sits in the same cluster (regenerative loop), expelled flow feeds the fill, so
  // there is no external deficit.
  function supplyInfo(start, other) {
    var info = { ground: false, q: 0, both: false };
    if (start < 0) return info;
    var seen = {}, stack = [start], guard = 0, injSeen = {};
    while (stack.length && guard++ < 4 * (N + edges.length + 8)) {
      var n = stack.pop();
      if (n === -2) { info.ground = true; continue; }     // accumulator battery sustains flow
      if (n === other && other >= 0) { info.both = true; }
      if (seen[n]) continue;
      seen[n] = 1;
      for (var i = 0; i < edges.length; i++) {
        var e = edges[i], g = e.gNow != null ? e.gNow : e.g;
        if (e.b === -1 && e.a === n && g > GMIN && e.tag !== "cyl-dem") { info.ground = true; continue; }
        if (g <= GMIN) continue;
        // Flow-divider primer edges physically bridge the branches, but for FILL
        // CAPACITY they must not merge the three ports into one cluster: each
        // branch's sustained supply is exactly its own issued share (sA1/sB1),
        // otherwise both cylinders sum pump + both shares and the cap stops
        // enforcing the split (that was the "first cylinder grabs the pump" bug).
        if (e.tag === "div-primer") continue;
        if (e.a === n && e.b >= 0 && !seen[e.b]) stack.push(e.b);
        else if (e.b === n && e.a >= 0 && !seen[e.a]) stack.push(e.a);
      }
      for (var j = 0; j < injections.length; j++) {
        var s = injections[j];
        // capacity = nominal delivery (destroked/cutout pumps still deliver full
        // displacement once downstream pressure sags), so use s.q not s.qNow.
        if (s.node === n && !injSeen[j] && (s.q || 0) > 0.01) { injSeen[j] = 1; info.q += s.q; }
      }
      for (var r = 0; r < regulators.length; r++) {
        var rg = regulators[r];
        if (rg.iA === n) { if (rg.iP >= 0 && !seen[rg.iP]) stack.push(rg.iP); if (rg.ventTo >= 0 && !seen[rg.ventTo]) stack.push(rg.ventTo); }
        else if (rg.iP === n || rg.ventTo === n) { if (rg.iA >= 0 && !seen[rg.iA]) stack.push(rg.iA); }
      }
      for (var a2 = 0; a2 < accumEdges.length; a2++) if (accumEdges[a2].iA === n) stack.push(-2);
    }
    return info;
  }

  // ---------- cylinder steady-state roots (LCP via signed bisection on q)
  function forceNet(cy) {
    var pA = cy.iA >= 0 ? p[cy.iA] : 0, pB = cy.iB >= 0 ? p[cy.iB] : 0;
    cy.pA = pA; cy.pB = pB;
    var Fspring = cy.comp.type === "cylinderSA" && cy.P.springReturn !== false
      ? 250 + 700 * cy.pos * cy.stroke / 500 : 0;
    return 1e5 * (pA * cy.Aa - pB * cy.Ab) - cy.Fload - Fspring;
  }
  function setCylFlow(cy, q) {
    // signed cap-side flow [L/min at local conditions]; + = extend (extract from A, expel into B)
    var qA = q, qB = cy.Ab > 0 ? -q * (cy.Ab / cy.Aa) : 0;
    if (FLUID === "air") {
      qA *= Math.max(((cy.iA >= 0 ? p[cy.iA] : 0) + PATM) / PATM, 0.05);
      qB *= Math.max(((cy.iB >= 0 ? p[cy.iB] : 0) + PATM) / PATM, 0.05);
    }
    cy.qA = qA; cy.qB = qB; cy.q = q;
  }
  function cylRoot(cy) {
    if (cy.iA < 0 && cy.iB < 0) { setCylFlow(cy, 0); cy.v = 0; cy.force = 0; return; }
    setCylFlow(cy, 0); // clean state before force evaluation
    var pumpQtot = 0;
    injections.forEach(function (s) { if (s.tag === "pump") pumpQtot += Math.max(s.qNow || 0, 0); });
    var qCap = Math.max(FLUID === "air" ? 300 : 40, 3.2 * Math.max(pumpQtot, 1));
    // mass-conservation caps: the filling chamber cannot be fed faster than the
    // sustained supply reaching it (otherwise the network cheated with vacuum).
    var qCapE = qCap, qCapR = qCap;
    var sA = supplyInfo(cy.iA, cy.iB);
    if (!sA.ground && !sA.both) qCapE = Math.min(qCap, Math.max(sA.q, 0.05));
    if (cy.Ab > 0) {
      var sB = supplyInfo(cy.iB, cy.iA);
      if (!sB.ground && !sB.both) qCapR = Math.min(qCap, Math.max(sB.q * (cy.Aa / cy.Ab), 0.05));
    }
    // Flow divider in COMBINER direction meters the chamber it is wired to:
    // expulsion through that chamber cannot exceed the branch share. Wired to
    // A (the usual sync hookup) expulsion happens on retract (qCapR); wired to
    // B it happens on extend (cap-side q x Ab/Aa leaves the rod side).
    if (cy.divA && cy.divA.dv.qIn < -0.05) qCapR = Math.min(qCapR, Math.max(-cy.divA.dv.qIn * cy.divA.s, 0.05));
    if (cy.divB && cy.divB.dv.qIn < -0.05) qCapE = Math.min(qCapE, Math.max(-cy.divB.dv.qIn * cy.divB.s * (cy.Ab > 0 ? cy.Aa / cy.Ab : 1), 0.05));
    var atTop = cy.pos >= 0.999, atBot = cy.pos <= 0.001;
    solveNetwork();
    var f0 = forceNet(cy);
    var DEAD = Math.max(45, 0.02 * Math.max(cy.Fload, 1));
    var locked = cylLocked(cy);
    if (rgzFluidSolve._trace && cy.comp.id === rgzFluidSolve._trace) console.log(" root start f0=", f0.toFixed(0), "pA=", cy.pA.toFixed(2), "atTop", atTop, "pos", cy.pos, "locked", locked);
    if (locked || Math.abs(f0) <= DEAD || (f0 > DEAD && atTop) || (f0 < -DEAD && atBot && (cy.Ab > 0 || cy.comp.type === "cylinderSA"))) {
      setCylFlow(cy, 0);
      cy.v = 0; cy.dir = 0; cy.force = f0; cy.starving = false;
      solveNetwork();
      cy.force = forceNet(cy);
      return;
    }
    var lo, hi, flo, fhi;
    if (f0 > DEAD) { // wants to extend: bracket [0, +qCapE]
      lo = 0; hi = qCapE; flo = f0;
      setCylFlow(cy, hi); solveNetwork(); fhi = forceNet(cy);
      if (fhi > 0) { // even at cap it pushes (overrunning supply cap): use cap
        setCylFlow(cy, hi); solveNetwork(); cy.force = forceNet(cy);
        cy.v = (cy.q / 6e4 / cy.Aa) * 1000; cy.dir = 1; cy.starving = false; return;
      }
    } else { // wants to retract: bracket [-qCapR, 0]
      hi = 0; lo = -qCapR; fhi = f0;
      setCylFlow(cy, lo); solveNetwork(); flo = forceNet(cy);
      if (flo < 0) {
        setCylFlow(cy, lo); solveNetwork(); cy.force = forceNet(cy);
        cy.v = (cy.q / 6e4 / cy.Aa) * 1000; cy.dir = -1; cy.starving = false; return;
      }
    }
    for (var it = 0; it < 24; it++) {
      var mid = 0.5 * (lo + hi);
      setCylFlow(cy, mid); solveNetwork();
      var fm = forceNet(cy);
      if (rgzFluidSolve._trace && cy.comp.id === rgzFluidSolve._trace) console.log(" bisect it", it, "q=", mid.toFixed(2), "pA=", cy.pA.toFixed(2), "pB=", cy.pB.toFixed(2), "F=", fm.toFixed(0));
      if (Math.abs(fm) <= DEAD) break;
      if (fm > 0) lo = mid; else hi = mid;
      if (Math.abs(hi - lo) < 0.02) break;
    }
    solveNetwork();
    cy.force = forceNet(cy);
    var v = (cy.q / 6e4 / cy.Aa) * 1000;
    // derived physically: retract speed uses rod-side chamber volume
    if (cy.q < 0 && cy.Ab > 0) v = (cy.q * (cy.Ab / cy.Aa) / 6e4 / cy.Ab) * 1000;
    cy.v = v; cy.dir = cy.q > 0.02 ? 1 : (cy.q < -0.02 ? -1 : 0);
    var pDrive = cy.q > 0 ? cy.pA : cy.pB;
    cy.starving = Math.abs(cy.q) > 1 && pDrive <= FLOOR + 0.25;
    // persist demand for continuity (informational only)
    cy.st.q = cy.q;
  }

  // ---------- iterate: valve linearization rounds + per-cylinder roots
  // Flow dividers: now that every pump source exists, size the split capacity and
  // bootstrap a hot start (sink/source triplet primed to the pump delivery, so the
  // branch cylinders get meaningful flow caps on the very first tick; the measured
  // feedback then converges within a few ticks). qIn itself persists across ticks
  // via DYN.div; the bootstrap only fills a never-initialised entry.
  if (dividers.length) {
    var qPumpAll = 0;
    injections.forEach(function (s2) { if (!s2.divTag) qPumpAll += Math.max(s2.q || 0, 0); });
    for (var dv0 = 0; dv0 < dividers.length; dv0++) {
      var dvI = dividers[dv0];
      // combiner direction passes the full-bore expulsion, bigger than the pump
      // delivery by the area ratio -> 2.5x headroom.
      dvI.qMax = Math.max(2.5 * qPumpAll, 8);
      if (!(dvI.cid in (DYN.div || {})) || !dvI.qIn) dvI.qIn = clamp(Math.min(qPumpAll, 10), 0, dvI.qMax);
      if (dvI.sIn) dvI.sIn.q = -dvI.qIn;
      if (dvI.sA1) dvI.sA1.q = dvI.qIn * dvI.sA;
      if (dvI.sB1) dvI.sB1.q = dvI.qIn * (1 - dvI.sA);
      // branch -> chamber mapping (one line hop): in combiner direction the
      // divider meters the EXPELLED flow, which the cylinder root otherwise
      // never caps (only fill sides are supply-capped) -> the branches would
      // free-run unevenly through the primer paths on retract.
      for (var br = 0; br < 2; br++) {
        var iBr = br === 0 ? dvI.iA : dvI.iB, sBr = br === 0 ? dvI.sA : 1 - dvI.sA;
        if (iBr < 0) continue;
        for (var em = 0; em < edges.length; em++) {
          var emd = edges[em];
          var on = emd.a === iBr ? emd.b : emd.b === iBr ? emd.a : -1;
          if (on < 0 || nodeComp[on] === dvI.cid) continue;
          for (var cm = 0; cm < cyls.length; cm++) {
            var cym = cyls[cm];
            if (cym.comp.id !== nodeComp[on]) continue;
            var rec = { dv: dvI, s: sBr };
            if (cym.iA === on) {
              cym.divA = rec;
              // retract metering ceiling: rod-side fill per unit expulsion is
              // Ab/Aa < 1, so |qIn| may not exceed what the pump can FILL,
              // else the descending loads drive the fill side into cavitation.
              if (cym.Ab > 0) dvI.rMin = Math.min(dvI.rMin || 1, cym.Ab / cym.Aa);
            } else if (cym.iB === on) cym.divB = rec;
          }
        }
      }
      dvI.qMaxComb = dvI.rMin ? Math.min(dvI.qMax, 0.92 * qPumpAll / dvI.rMin) : dvI.qMax;
    }
  }

  solveNetwork(); // priming solve so dynamic conductances / injection qNow are real before lock checks
  var OUTER = cyls.length > 1 ? 3 : 2;
  for (var oi = 0; oi < OUTER; oi++) {
    if (rgzFluidSolve._trace) console.log(" -- outer round", oi);
    for (var mr = 0; mr < motorRecs.length; mr++) {
      var mrc = motorRecs[mr];
      mrc.locked = !(mrc.iA >= 0 && mrc.iB >= 0 && reachesReference(mrc.iA) && reachesReference(mrc.iB));
    }
    for (var ci2 = 0; ci2 < cyls.length; ci2++) cylRoot(cyls[ci2]);
  }
  solveNetwork();
  // Final unrelaxed reporting passes: the bisection probes inside cylRoot jog the
  // on/off dynamic conductances (check valves, reliefs at the crack point, etc.)
  // and the geometric-mean relaxation can freeze them halfway between states
  // (e.g. a bypass check valve stuck almost shut -> phantom trapped pressure).
  // Re-evaluate all dynamics exactly at the converged point so the reported
  // pressures/flows are the fresh fixed point of the final piston demands.
  for (var fi = 0; fi < 3; fi++) {
    for (var fe = 0; fe < edges.length; fe++) edges[fe].gD = 0;
    solveNetwork();
  }

  // Flow divider/combiner controller, exactly ONCE per tick on the converged
  // fixed point (updating inside edgeFlows let mid-bisection probe flows
  // halve qIn repeatedly within the same tick — a shrink-spiral). The divider
  // is a pass-through current device: it cannot create flow, so the split
  // sources re-issue what is OFFERED at P (pump delivery reachable through
  // genuinely open paths, LEAK-only paths don't count). The measured line
  // inflow is used as the shrink-limiter (throttled/relief-limited supply)
  // and as the direction witness (negative -> combiner direction); pure
  // consumption-following traps at the cold-start low fixed point, so while
  // the line delivers >=95% of the current demand the demand grows 1.5x/tick
  // toward the offered ceiling — reaching full delivery in a few ticks from
  // the bootstrap and re-arming after the valve re-opens.
  for (var fi2 = 0; fi2 < dividers.length; fi2++) {
    var dv = dividers[fi2];
    if (dv.iP < 0) continue;
    if (!dv.inc) {
      dv.inc = [];
      for (var ei = 0; ei < edges.length; ei++) {
        var ed = edges[ei];
        var other = ed.a === dv.iP ? ed.b : ed.b === dv.iP ? ed.a : -99;
        if (other > -99 && (other < 0 || nodeComp[other] !== dv.cid)) dv.inc.push(ed);
      }
    }
    var rin = 0;
    for (var di = 0; di < dv.inc.length; di++) {
      var ee = dv.inc[di];
      rin += ee.b === dv.iP ? ee.flow || 0 : -(ee.flow || 0);
    }
    if (Math.abs(rin) < 0.03) rin = 0;
    // offered flow toward P: BFS from P over edges with real conductance
    if (!dv.fwd || dv.qOffT !== TIME) {
      var off = 0, reachAcc = false, seen = {}, stack = [dv.iP], guard = 0, injSeen = {};
      while (stack.length && guard++ < 4 * (N + edges.length + 8)) {
        var n = stack.pop();
        if (n === -2) { reachAcc = true; continue; }
        if (seen[n]) continue;
        seen[n] = 1;
        for (var eo = 0; eo < edges.length; eo++) {
          var e2 = edges[eo], g2 = e2.gNow != null ? e2.gNow : e2.g;
          if (g2 < 0.001) continue;                       // LEAK-only paths are not supply paths
          if (e2.tag === "div-primer") continue;
          if (e2.a === n && e2.b >= 0 && !seen[e2.b]) stack.push(e2.b);
          else if (e2.b === n && e2.a >= 0 && !seen[e2.a]) stack.push(e2.a);
        }
        for (var jo = 0; jo < injections.length; jo++) {
          var s3 = injections[jo];
          if (s3.node === n && !injSeen[jo] && !s3.divTag && (s3.q || 0) > 0.01) { injSeen[jo] = 1; off += s3.q; }
        }
        for (var ro = 0; ro < regulators.length; ro++) {
          var rgo = regulators[ro];
          if (rgo.iA === n) { if (rgo.iP >= 0 && !seen[rgo.iP]) stack.push(rgo.iP); if (rgo.ventTo >= 0 && !seen[rgo.ventTo]) stack.push(rgo.ventTo); }
          else if (rgo.iP === n || rgo.ventTo === n) { if (rgo.iA >= 0 && !seen[rgo.iA]) stack.push(rgo.iA); }
        }
        for (var ao = 0; ao < accumEdges.length; ao++) if (accumEdges[ao].iA === n) stack.push(-2);
      }
      dv.qOff = reachAcc ? dv.qMax : off;
      dv.qOffT = TIME;
    }
    var target;
    if (rin < -1 && dv.qIn >= -0.05) dv.qIn = -Math.min(3, dv.qMax); // combiner snap-arm: primer-carried return detected
    if (dv.qIn < -0.05 || (Math.abs(dv.qIn) <= 0.05 && rin < -0.5)) {
      // combiner direction: follow the measured return flow, capped by what
      // the pump can FILL on the other side (meter-out cannot create oil).
      var capC = dv.qMaxComb || dv.qMax;
      target = rin;
      if (dv.qIn < -0.05 && -rin >= 0.95 * -dv.qIn) target = -Math.min(capC, Math.max(-rin, -dv.qIn * 1.5));
    } else {
      var up = Math.min(dv.qOff || 0, dv.qMax);
      if (up > 0.05) {
        target = rin >= 0.95 * dv.qIn ? Math.min(up, Math.max(rin, dv.qIn * 1.5)) : Math.max(rin, 0);
      } else target = 0;
    }
    dv.qIn = clamp(0.5 * dv.qIn + 0.5 * clamp(target, -dv.qMax, dv.qMax), -dv.qMax, dv.qMax);
    if (Math.abs(dv.qIn) < 0.2 && (dv.qOff || 0) > 1 && rin > -0.5) dv.qIn = Math.min(dv.qOff, dv.qMax, 1.5); // re-arm
    if (DYN.div) DYN.div[dv.cid] = dv.qIn;
    if (dv.sIn) dv.sIn.q = -dv.qIn;
    if (dv.sA1) dv.sA1.q = dv.qIn * dv.sA;
    if (dv.sB1) dv.sB1.q = dv.qIn * (1 - dv.sA);
  }
  for (var ci3 = 0; ci3 < cyls.length; ci3++) cyls[ci3].force = forceNet(cyls[ci3]);
  for (var mi = 0; mi < N; mi++) DYN.p[nodeKeys[mi]] = p[mi];

  // ---------- outputs ----------
  var compMap = {};
  gauges.forEach(function (c) {
    var iP = pOf(c.id, "P");
    compMap[c.id] = { pressureBar: iP >= 0 ? clamp(p[iP], FLOOR, pCap) : 0, flowLpm: 0 };
  });
  flowmeters.forEach(function (c) {
    var q = 0;
    for (var i = 0; i < edges.length; i++) { var e = edges[i]; if (e.compId === c.id && e.tag === "passive") q = Math.abs(e.flow); }
    var iA = pOf(c.id, "A");
    compMap[c.id] = { pressureBar: iA >= 0 ? clamp(p[iA], FLOOR, pCap) : 0, flowLpm: q };
  });
  reliefs.forEach(function (c) {
    if (c.type === "powerPack") return;
    var iP = pOf(c.id, "P");
    compMap[c.id] = { pressureBar: iP >= 0 ? clamp(p[iP], FLOOR, pCap) : 0, flowLpm: 0 };
  });
  comps.forEach(function (c) {
    var t = c.type;
    if (t === "powerPack" || t === "pumpFixed" || t === "pumpVariable" || t === "compressorFixed" || t === "compressorVariable") {
      var iP = pOf(c.id, "P"), qinj = 0;
      for (var j = 0; j < injections.length; j++) { var s = injections[j]; if (s.compId === c.id && s.tag === "pump") qinj = Math.max(s.qNow || 0, 0); }
      compMap[c.id] = { pressureBar: iP >= 0 ? clamp(p[iP], FLOOR, pCap) : 0, flowLpm: qinj };
    }
    if (t === "flowControl" || t === "cartridgeNeedleFlowValve" || t === "checkValve" || t === "cartridgeCheckValve" || t === "pilotCheckValve") {
      var q2 = 0, dp2 = 0;
      for (var i2 = 0; i2 < edges.length; i2++) { var e2 = edges[i2]; if (e2.compId === c.id && e2.b >= 0 && (e2.tag === "fc" || e2.tag === "fc-pc" || e2.tag === "check" || e2.tag === "pcheck")) { q2 = e2.flow; dp2 = Math.abs(p[e2.a] - p[e2.b]); } }
      var iA2 = pOf(c.id, "A");
      compMap[c.id] = { flowLpm: Math.abs(q2), deltaPBar: dp2, pressureBar: iA2 >= 0 ? clamp(p[iA2], FLOOR, pCap) : 0 };
    }
    if (t === "reducingValve" || t === "cartridgeReducingValve" || t === "frlUnit") {
      var iA3 = pOf(c.id, "A"), iP3 = pOf(c.id, "P");
      compMap[c.id] = { pressureBar: iA3 >= 0 ? clamp(p[iA3], FLOOR, pCap) : 0, inletBar: iP3 >= 0 ? clamp(p[iP3], FLOOR, pCap) : 0 };
    }
    if (t === "reliefValve" || t === "cartridgeReliefValve") {
      var q3 = 0;
      for (var i3 = 0; i3 < edges.length; i3++) { var e3 = edges[i3]; if (e3.compId === c.id && e3.tag === "relief") q3 = Math.max(e3.flow, 0); }
      if (compMap[c.id]) compMap[c.id].flowLpm = q3;
    }
    if (t === "directionalValve" || t === "servoValve" || t === "pneumaticMemoryValve") {
      var iA4 = pOf(c.id, "A"), iP4 = pOf(c.id, "P");
      compMap[c.id] = { pressureBar: iA4 >= 0 ? clamp(p[iA4], FLOOR, pCap) : 0, supplyBar: iP4 >= 0 ? clamp(p[iP4], FLOOR, pCap) : 0 };
    }
    if (t === "accumulator") {
      for (var j2 = 0; j2 < accumEdges.length; j2++) if (accumEdges[j2].comp.id === c.id) {
        compMap[c.id] = { pressureBar: clamp(p[accumEdges[j2].iA] || 0, FLOOR, pCap), flowLpm: accumEdges[j2].flow || 0 };
      }
    }
  });

  var cylOut = cyls.map(function (cy) {
    return {
      id: cy.comp.id, label: cy.comp.label || cy.comp.id,
      speedMmS: cy.v, forceKN: Math.abs(cy.force) / 1000,
      pressureBar: Math.max(cy.dir >= 0 ? cy.pA : cy.pB, 0),
      loadKg: cylLoadKg(cy.P, cy.pos, cy.comp),
    };
  });

  var motorOut = motors.map(function (m) {
    var iA = pOf(m.id, "A"), iB = pOf(m.id, "B"), q = 0;
    for (var i = 0; i < edges.length; i++) { var e = edges[i]; if (e.compId === m.id && e.tag === "motor") q = e.flow; }
    var disp = Math.max(1, num(m.props.displacementCcRev, 25));
    var pA = iA >= 0 ? p[iA] : 0, pB = iB >= 0 ? p[iB] : 0;
    var rpm = Math.abs(q) > 0.02 ? (1000 * Math.abs(q)) / disp : 0;
    var torque = Math.abs(pA - pB) * disp / 20 / Math.PI;
    var dirn = pA >= pB ? 1 : -1;
    var loadNmNow = motorLoadNm(m.props, m);
    compMap[m.id] = { pressureBar: clamp(pA - pB, -pCap, pCap), flowLpm: Math.abs(q), rpm: rpm, torqueNm: torque, loadNm: loadNmNow };
    return { id: m.id, label: m.label || m.id, flowLpm: Math.abs(q), rpm: dirn * rpm, torqueNm: torque, loadNm: loadNmNow };
  });

  var lineOut = lineEdges.map(function (e) {
    var qL = e.flow;
    var d = Math.max(1.5, num(e.lineProps.tubeIdMm, FLUID === "air" ? 6 : 12));
    var area = Math.PI * Math.pow(d / 1000, 2) / 4;
    var vel = area > 0 ? Math.abs(qL) / 6e4 / area : 0;
    var pn = Math.max(p[e.a], p[e.b]);
    var vmax = FLUID === "air" ? 25 : (num(e.lineProps.tubeIdMm, 12) < 8 ? 4.5 : 6);
    if (vel > vmax) warnings.push((e.lineId || "line") + " velocity is high (" + vel.toFixed(1) + " m/s).");
    return { id: e.lineId, velocityMps: vel, flowLpm: qL, active: Math.abs(qL) > 0.15, high: pn > 0.8 * reliefSetting, pressureBar: pn };
  });

  var totalQ = 0, pumpP = 0, pumpQreal = 0;
  pumps.forEach(function (cp) {
    totalQ += num(cp.props.flowLpm, 0);
    var iP = pOf(cp.id, "P");
    if (iP >= 0) {
      pumpP = Math.max(pumpP, p[iP]);
      for (var i = 0; i < injections.length; i++) { var s = injections[i]; if (s.compId === cp.id && s.tag === "pump") pumpQreal += Math.max(s.qNow || 0, 0); }
    }
  });
  var netMax = 0; for (var n2 = 0; n2 < N; n2++) netMax = Math.max(netMax, p[n2]);
  var pressureBar = pumpP > 0 ? pumpP : netMax;
  var powerKw = (pumpQreal * Math.max(pressureBar, 0)) / 600;

  var lossKw = 0;
  for (var i4 = 0; i4 < edges.length; i4++) { var e4 = edges[i4]; lossKw += Math.abs(e4.flow) * Math.abs((p[e4.a] || 0) - (e4.b >= 0 ? p[e4.b] : 0)) / 600; }
  var tanks = comps.filter(function (c) { return c.type === "tank" || c.type === "powerPack"; });
  var baseT = tanks.length ? tanks.reduce(function (a2e, c) { return a2e + num(c.props.oilTempC, 40); }, 0) / tanks.length : 40;
  var oilTempC = FLUID === "air" ? 20 : baseT + Math.min(25, 0.4 * lossKw + 0.01 * TIME * Math.min(1, lossKw));

  var activeQ = 0;
  cyls.forEach(function (cy) { activeQ += Math.abs(cy.qA || 0); });
  motorOut.forEach(function (mo) { activeQ += mo.flowLpm; });

  var reliefOpen = false;
  for (var i5 = 0; i5 < edges.length; i5++) { var e5 = edges[i5]; if (e5.tag === "relief" && e5.flow > 0.05) { reliefOpen = true; break; } }
  var anyMoving = cylOut.some(function (co) { return Math.abs(co.speedMmS) > 0.5; }) || motorOut.some(function (mo) { return Math.abs(mo.rpm) > 1; });
  if (reliefOpen && !anyMoving && totalQ > 0.1) warnings.push("Pump flow is going over the relief valve (circuit dead-headed or actuators idle).");
  if (!reliefs.length && pumps.some(function (cp) { return cp.type === "pumpFixed" || cp.type === "powerPack"; })) warnings.push("No pressure relief valve detected for a fixed-displacement source.");
  cyls.forEach(function (cy) {
    if (cy.starving) warnings.push((cy.comp.label || cy.comp.id) + ": supply starved (possible cavitation) — increase flow or opening.");
    if (Math.abs(cy.v) > 250) warnings.push((cy.comp.label || cy.comp.id) + " speed is very high; check flow and pipe size.");
  });
  for (var pj = 0; pj < pumps.length; pj++) {
    var cj = pumps[pj], iPj = pOf(cj.id, "P");
    if (iPj >= 0 && p[iPj] > num(cj.props.maxPressureBar, 320) + 5) { warnings.push((cj.label || cj.id) + ": maximum pressure exceeded — check relief protection."); break; }
  }

  if (opts.debug) {
    return { _dbg: true, N: N, nodeKeys: nodeKeys.slice(), p: Array.from(p),
      edges: edges.map(function(e){return {a:e.a,b:e.b,tag:e.tag,cid:e.compId,gNow:e.gNow,flow:e.flow};}),
      injections: injections.map(function(s){var r={n:s.node,tag:s.tag,cid:s.compId,qNow:s.qNow,q:s.q,hasDyn:!!s.dynQ}; try{r.dynAt0=s.dynQ?s.dynQ(0):null;}catch(e){r.err=String(e);} return r;}) };
  }
  return {
    totalFlowLpm: totalQ,
    activeFlowLpm: activeQ,
    pressureBar: pressureBar,
    reliefSetting: reliefSetting,
    powerKw: powerKw,
    oilTempC: oilTempC,
    time: TIME,
    cylinders: cylOut,
    motors: motorOut,
    lines: lineOut.map(function (l) { return { id: l.id, velocityMps: l.velocityMps, flowLpm: l.flowLpm, active: l.active, high: l.high, pressureBar: l.pressureBar }; }),
    warnings: warnings.slice(0, 40),
    comp: compMap,
    accumulators: accums.map(function (c) {
      var f = 0;
      for (var j = 0; j < accumEdges.length; j++) if (accumEdges[j].comp.id === c.id) f = accumEdges[j].flow || 0;
      return { id: c.id, flowLpm: f }; // + = charging
    }),
  };
}
rgzFluidSolve._dyn = null;

rgzFluidSolve._dyn = null;

rgzFluidSolve._dyn = null;


rgzFluidSolve._dyn = null;

rgzFluidSolve._dyn = null;
rgzFluidSolve._dyn = null;
rgzFluidSolve._dyn = null;

rgzFluidSolve._dyn = null;

rgzFluidSolve._dyn = null;
/* ---------------- user-defined simulation charts (both studios) ----------------
   Records simulation telemetry automatically while a simulation runs
   (one sample every 10 ms of sim time, capped at 30 000 samples) and lets the
   user define custom X/Y charts, render them as SVG and export SVG or CSV.
   One instance per studio is created with rgzChartsFactory({root,state,toast,fluid,name}). */
function rgzChartsFactory(opts) {
  "use strict";
  var root = opts.root,
    S = opts.state,
    toast = opts.toast || function () {},
    fluid = opts.fluid || "oil",
    name = opts.name || (fluid === "oil" ? "hydraulic" : "pneumatic");
  var PALETTE = ["#EB4E3C", "#2563eb", "#059669", "#d97706", "#7c3aed", "#0891b2", "#be185d", "#65a30d"];
  var chart = { rows: [], lastT: -1, stride: 0.01, cap: 30000 };
  var liveTimer = null;
  var liveOn = true;
  /* user-editable chart text (title + axis captions), persisted per studio */
  var LKEY = "rgz.chart.labels." + name;
  var labels = { title: "", x: "", left: "", right: "" };
  try {
    var saved = JSON.parse((window.localStorage && window.localStorage.getItem(LKEY)) || "{}");
    if (saved && typeof saved === "object") for (var lk in labels) if (typeof saved[lk] === "string") labels[lk] = saved[lk];
  } catch (eLS) {}
  function saveLabels() {
    try { window.localStorage && window.localStorage.setItem(LKEY, JSON.stringify(labels)); } catch (eLS2) {}
  }

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function fin(v, d) {
    var n = Number(v);
    return Number.isFinite(n) ? n : d == null ? 0 : d;
  }

  /* Build the channel catalogue from the current circuit + last metrics.
     Channels: system values, per-cylinder position/speed/force/pressure,
     per-motor rpm/flow/rotation, per-gauge pressure, per-flowmeter flow. */
  function buildChannels() {
    var m = (S.sim && S.sim.metrics) || {};
    var list = [];
    function add(id, label, unit, get) { list.push({ id: id, label: label, unit: unit, get: get }); }
    add("sys.p", "System pressure", "bar", function (mm) { return fin(mm.pressureBar); });
    add("sys.q", "Total flow", "L/min", function (mm) { return fin(mm.totalFlowLpm); });
    add("sys.qa", "Active flow", "L/min", function (mm) { return fin(mm.activeFlowLpm); });
    add("sys.kw", "Power", "kW", function (mm) { return fin(mm.powerKw); });
    if (fluid === "oil") add("sys.temp", "Oil temperature", "°C", function (mm) { return fin(mm.oilTempC); });
    function cyOf(mm, id) {
      var a = (mm && mm.cylinders) || [];
      for (var i = 0; i < a.length; i++) if (a[i].id === id) return a[i];
      return null;
    }
    function moOf(mm, id) {
      var a = (mm && mm.motors) || [];
      for (var i = 0; i < a.length; i++) if (a[i].id === id) return a[i];
      return null;
    }
    (S.components || []).forEach(function (c) {
      var lab = String(c.label || c.id), t = c.type;
      if (t === "cylinderDA" || t === "cylinderSA") {
        add(c.id + ":pos", lab + " · position", "%", function () {
          return 100 * Math.max(0, Math.min(1, fin(c.props && c.props.simPosition)));
        });
        add(c.id + ":spd", lab + " · speed", "mm/s", function (mm) {
          var cy = cyOf(mm, c.id); return cy ? fin(cy.speedMmS) : 0;
        });
        add(c.id + ":f", lab + " · force", "kN", function (mm) {
          var cy = cyOf(mm, c.id); return cy ? fin(cy.forceKN) : 0;
        });
        add(c.id + ":p", lab + " · cap-end pressure", "bar", function (mm) {
          var cy = cyOf(mm, c.id); return cy ? fin(cy.pressureBar) : 0;
        });
        add(c.id + ":load", lab + " · applied load", "kg", function (mm) {
          var cy = cyOf(mm, c.id);
          return cy && cy.loadKg != null ? fin(cy.loadKg) : fin(c.props && c.props.loadKg);
        });
      } else if (t === "hydraulicMotor" || t === "pneumaticMotor") {
        add(c.id + ":rpm", lab + " · speed", "rpm", function (mm) {
          var mo = moOf(mm, c.id); return mo ? fin(mo.rpm) : 0;
        });
        add(c.id + ":q", lab + " · flow", "L/min", function (mm) {
          var mo = moOf(mm, c.id); return mo ? fin(mo.flowLpm) : 0;
        });
        add(c.id + ":tq", lab + " · hydraulic torque", "N·m", function (mm) {
          var mo = moOf(mm, c.id); return mo && mo.torqueNm != null ? fin(mo.torqueNm) : 0;
        });
        add(c.id + ":load", lab + " · load torque", "N·m", function (mm) {
          var mo = moOf(mm, c.id);
          return mo && mo.loadNm != null ? fin(mo.loadNm) : fin(c.props && c.props.loadNm);
        });
        add(c.id + ":ang", lab + " · rotation", "deg", function () {
          return (fin(c.props && c.props.simAngle) * 180) / Math.PI;
        });
      } else if (t === "pressureGauge" || t === "pressureSwitch" || t === "pressureTransducer" || t === "testPoint" || t === "accumulator") {
        add(c.id + ":p", lab + " · pressure", "bar", function (mm) {
          var cv = mm && mm.comp ? mm.comp[c.id] : null;
          return cv ? fin(cv.pressureBar) : 0;
        });
        if (t === "accumulator")
          add(c.id + ":q", lab + " · charge flow", "L/min", function (mm) {
            var cv = mm && mm.comp ? mm.comp[c.id] : null;
            return cv ? fin(cv.flowLpm) : 0;
          });
      } else if (t === "flowMeter" || t === "flowSwitch") {
        add(c.id + ":q", lab + " · flow", "L/min", function (mm) {
          var cv = mm && mm.comp ? mm.comp[c.id] : null;
          return cv ? fin(cv.flowLpm) : 0;
        });
      }
    });
    return list;
  }

  /* ---- recorder: called once per sim frame from the app render loop ---- */
  function rec() {
    if (!S.sim || !S.sim.running || !S.sim.metrics) return;
    /* prefer the solver's own timestamp (identical inside a Web Worker) */
    var t = Number.isFinite(Number(S.sim.metrics && S.sim.metrics.time)) ? Number(S.sim.metrics.time) : fin(S.sim.time);
    if (t < chart.lastT - 1e-6) chart.rows = []; // a new run restarts the record
    if (chart.rows.length && t - chart.lastT < chart.stride) { chart.lastT = t; return; }
    chart.lastT = t;
    var m = S.sim.metrics, chans = buildChannels(), row = { t: t };
    for (var i = 0; i < chans.length; i++) {
      try { row[chans[i].id] = fin(chans[i].get(m)); } catch (e) { row[chans[i].id] = 0; }
    }
    chart.rows.push(row);
    if (chart.rows.length > chart.cap) chart.rows.splice(0, chart.rows.length - chart.cap);
  }
  function clear() {
    chart.rows = [];
    chart.lastT = -1;
  }

  /* ---- nice axis ticks (1 / 2 / 2.5 / 5 × 10^k) ---- */
  function niceTicks(lo, hi, count) {
    lo = fin(lo); hi = fin(hi);
    if (hi === lo) {
      if (hi === 0) hi = 1;
      else { var pad = Math.abs(hi) * 0.1; lo -= pad; hi += pad; }
    }
    var raw = (hi - lo) / Math.max(2, count || 6);
    var mag = Math.pow(10, Math.floor(Math.log10(raw)));
    var step = 10 * mag, steps = [1, 2, 2.5, 5, 10];
    for (var i = 0; i < steps.length; i++) if (steps[i] * mag >= raw - 1e-12) { step = steps[i] * mag; break; }
    var lo2 = Math.floor(lo / step) * step, hi2 = Math.ceil(hi / step) * step;
    if (hi2 === lo2) hi2 = lo2 + step;
    var ticks = [];
    for (var v = lo2, k = 0; v <= hi2 + step * 0.5 && k < 60; v += step, k++) ticks.push(v);
    return { lo: lo2, hi: hi2, ticks: ticks };
  }
  function fmtTick(v) {
    var r = Number(v.toFixed(6));
    return Math.abs(r) >= 1000 ? String(Math.round(r)) : String(r);
  }

  /* ---- render the selected series into an SVG string (also used for export) ---- */
  function renderSVG(xId, yIds, rId, lab) {
    lab = lab || labels;
    var rows = chart.rows;
    if (!rows.length)
      return { error: "No samples recorded yet. Start the simulation — recording is automatic — then render again." };
    var chans = buildChannels();
    function chOf(id) {
      for (var i = 0; i < chans.length; i++) if (chans[i].id === id) return chans[i];
      return null;
    }
    var xIsTime = !xId || xId === "time";
    var xCh = xIsTime ? { id: "time", label: "Time", unit: "s" } : chOf(xId);
    if (!xCh) return { error: "Pick a valid X axis channel." };
    yIds = (yIds || []).filter(function (id) { return id && id !== rId && chOf(id); });
    if (rId && !chOf(rId)) rId = null;
    if (!yIds.length && !rId) return { error: "Select at least one Y series (left or right axis)." };
    var xVal = function (r) { return xIsTime ? r.t : fin(r[xCh.id]); };
    var W = 880, H = 486, mL = 66, mR = rId ? 66 : 26, mT = 62, mB = 58;
    var iw = W - mL - mR, ih = H - mT - mB;
    var xMin = Infinity, xMax = -Infinity;
    rows.forEach(function (r) { var v = xVal(r); if (v < xMin) xMin = v; if (v > xMax) xMax = v; });
    if (!Number.isFinite(xMin)) { xMin = 0; xMax = 1; }
    if (xMax === xMin) xMax = xMin + 1;
    var xt = niceTicks(xMin, xMax, 7);
    function extent(ids) {
      var lo = Infinity, hi = -Infinity;
      rows.forEach(function (r) {
        ids.forEach(function (id) {
          var v = fin(r[id]);
          if (v < lo) lo = v;
          if (v > hi) hi = v;
        });
      });
      if (!Number.isFinite(lo)) { lo = 0; hi = 1; }
      return [lo, hi];
    }
    var yE = extent(yIds.length ? yIds : [xCh.id]), yt = niceTicks(yE[0], yE[1], 6);
    var rt = rId ? niceTicks.apply(null, extent([rId]).concat([6])) : null;
    var px = function (v) { return mL + ((v - xt.lo) / (xt.hi - xt.lo)) * iw; };
    var pyL = function (v) { return mT + ih - ((v - yt.lo) / (yt.hi - yt.lo)) * ih; };
    var pyR = rt ? function (v) { return mT + ih - ((v - rt.lo) / (rt.hi - rt.lo)) * ih; } : pyL;
    var out = [];
    out.push('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + W + " " + H + '" role="img" aria-label="RGZ custom chart">');
    out.push('<rect x="0" y="0" width="' + W + '" height="' + H + '" fill="#ffffff" rx="10"/>');
    /* clip path for plot-area content (series + watermark) */
    out.push('<clipPath id="rgzchclip"><rect x="' + mL + '" y="' + mT + '" width="' + iw + '" height="' + ih + '"/></clipPath>');
    /* ---- chart title (editable) ---- */
    var tEnd = rows[rows.length - 1].t, tStart = rows[0].t;
    var titleTxt = (lab.title || "").trim() || (name.charAt(0).toUpperCase() + name.slice(1) + " studio — " + fin(tEnd - tStart).toFixed(1) + " s record");
    out.push('<text x="' + mL + '" y="24" font-family="system-ui,Segoe UI,Arial,sans-serif" font-size="15" font-weight="700" fill="#0f172a">' + esc(titleTxt) + "</text>");
    var i, v;
    // grid + x ticks
    for (i = 0; i < xt.ticks.length; i++) {
      v = xt.ticks[i];
      var gx = px(v).toFixed(1);
      out.push('<line x1="' + gx + '" y1="' + mT + '" x2="' + gx + '" y2="' + (mT + ih) + '" stroke="#e2e8f0" stroke-width="1"/>');
      out.push('<text x="' + gx + '" y="' + (mT + ih + 18) + '" text-anchor="middle" font-family="system-ui,Segoe UI,Arial,sans-serif" font-size="11" fill="#64748b">' + esc(fmtTick(v)) + "</text>");
    }
    // y ticks left
    for (i = 0; i < yt.ticks.length; i++) {
      v = yt.ticks[i];
      var gy = pyL(v).toFixed(1);
      out.push('<line x1="' + mL + '" y1="' + gy + '" x2="' + (mL + iw) + '" y2="' + gy + '" stroke="#e2e8f0" stroke-width="1"/>');
      out.push('<text x="' + (mL - 8) + '" y="' + (fin(gy) + 4) + '" text-anchor="end" font-family="system-ui,Segoe UI,Arial,sans-serif" font-size="11" fill="#64748b">' + esc(fmtTick(v)) + "</text>");
    }
    // y ticks right
    if (rt) {
      for (i = 0; i < rt.ticks.length; i++) {
        v = rt.ticks[i];
        out.push('<text x="' + (mL + iw + 8) + '" y="' + (fin(pyR(v).toFixed(1)) + 4) + '" text-anchor="start" font-family="system-ui,Segoe UI,Arial,sans-serif" font-size="11" fill="#64748b">' + esc(fmtTick(v)) + "</text>");
      }
    }
    // frame
    out.push('<rect x="' + mL + '" y="' + mT + '" width="' + iw + '" height="' + ih + '" fill="none" stroke="#cbd5e1" stroke-width="1.4"/>');
    // series
    var all = yIds.map(function (id) { return { id: id, right: false }; });
    if (rId) all.push({ id: rId, right: true });
    all.forEach(function (s, k) {
      var col = PALETTE[k % PALETTE.length];
      var pts = [];
      for (var i2 = 0; i2 < rows.length; i2++) {
        var r = rows[i2];
        pts.push(px(xVal(r)).toFixed(1) + "," + (s.right ? pyR(fin(r[s.id])) : pyL(fin(r[s.id]))).toFixed(1));
      }
      out.push('<polyline clip-path="url(#rgzchclip)" fill="none" stroke="' + col + '" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" points="' + pts.join(" ") + '"/>');
    });
    // watermark (drawn over the plot, clipped to the plot area — appears in preview and export)
    out.push('<g clip-path="url(#rgzchclip)" opacity="0.13">');
    for (var wx = 0; wx < 4; wx++)
      for (var wy = 0; wy < 3; wy++)
        out.push(
          '<text x="' + (mL + iw * (0.14 + 0.26 * wx)) + '" y="' + (mT + ih * (0.2 + 0.32 * wy)) +
          '" text-anchor="middle" font-family="system-ui,Segoe UI,Arial,sans-serif" font-size="17" font-weight="800" fill="#94a3b8" transform="rotate(-24 ' +
          (mL + iw * (0.14 + 0.26 * wx)) + " " + (mT + ih * (0.2 + 0.32 * wy)) + ')">houmanrgz.ir · RGZ ENGINEERING</text>'
        );
    out.push("</g>");
    // legend
    var lx = mL + 10;
    all.forEach(function (s, k) {
      var col = PALETTE[k % PALETTE.length];
      var cch = chOf(s.id);
      var lab = (cch ? cch.label : s.id) + (cch ? " (" + cch.unit + ")" : "") + (s.right ? " — right" : "");
      out.push('<line x1="' + lx + '" y1="' + (mT - 22) + '" x2="' + (lx + 18) + '" y2="' + (mT - 22) + '" stroke="' + col + '" stroke-width="3"/>');
      out.push('<text x="' + (lx + 24) + '" y="' + (mT - 18) + '" font-family="system-ui,Segoe UI,Arial,sans-serif" font-size="11" fill="#334155">' + esc(lab) + "</text>");
      lx += 34 + lab.length * 6.2;
    });
    // axis labels — user overrides win; sensible unit-aware defaults otherwise
    var xLab = (lab.x || "").trim() || xCh.label + " (" + xCh.unit + ")";
    out.push('<text x="' + (mL + iw / 2) + '" y="' + (H - 14) + '" text-anchor="middle" font-family="system-ui,Segoe UI,Arial,sans-serif" font-size="12" font-weight="600" fill="#334155">' + esc(xLab) + "</text>");
    var lUnits = [];
    yIds.forEach(function (id) { var c = chOf(id); if (c && lUnits.indexOf(c.unit) < 0) lUnits.push(c.unit); });
    var leftDefault = yIds.length === 1 && chOf(yIds[0])
      ? chOf(yIds[0]).label + " (" + chOf(yIds[0]).unit + ")"
      : (lUnits.length === 1 ? lUnits[0] : "value (mixed units — see legend)");
    var leftLab = (lab.left || "").trim() || leftDefault;
    out.push('<text x="18" y="' + (mT + ih / 2) + '" text-anchor="middle" font-family="system-ui,Segoe UI,Arial,sans-serif" font-size="12" font-weight="600" fill="#334155" transform="rotate(-90 18 ' + (mT + ih / 2) + ')">' + esc(leftLab) + "</text>");
    if (rId) {
      var rch = chOf(rId);
      var rightLab = (lab.right || "").trim() || (rch ? rch.label + " (" + rch.unit + ")" : "");
      out.push('<text x="' + (W - 14) + '" y="' + (mT + ih / 2) + '" text-anchor="middle" font-family="system-ui,Segoe UI,Arial,sans-serif" font-size="12" font-weight="600" fill="#334155" transform="rotate(90 ' + (W - 14) + " " + (mT + ih / 2) + ')">' + esc(rightLab) + "</text>");
    }
    out.push('<text x="' + (W - 10) + '" y="' + (H - 6) + '" text-anchor="end" font-family="system-ui,Segoe UI,Arial,sans-serif" font-size="9" fill="#94a3b8">houmanrgz.ir · RGZ Engineering — ' + esc(name) + " studio · captured at t=" + fin(tEnd).toFixed(2) + " s</text>");
    out.push("</svg>");
    return { svg: out.join("\n"), xCh: xCh, yIds: yIds, rId: rId };
  }

  function csvText(xId, yIds, rId) {
    var chans = buildChannels();
    function chOf(id) {
      for (var i = 0; i < chans.length; i++) if (chans[i].id === id) return chans[i];
      return null;
    }
    var xIsTime = !xId || xId === "time";
    var xCh = xIsTime ? { id: "time", label: "Time", unit: "s" } : chOf(xId);
    var cols = (yIds || []).slice();
    if (rId && cols.indexOf(rId) < 0) cols.push(rId);
    var head = [(xCh.label + " [" + xCh.unit + "]")].concat(
      cols.map(function (id) {
        var c = chOf(id);
        return c ? c.label + " [" + c.unit + "]" : id;
      })
    );
    var lines = [head.join(",")];
    chart.rows.forEach(function (r) {
      var line = [String(xIsTime ? Number(fin(r.t).toFixed(4)) : fin(r[xCh.id]))];
      cols.forEach(function (id) { line.push(String(Number(fin(r[id]).toFixed(6)))); });
      lines.push(line.join(","));
    });
    return lines.join("\n");
  }

  function download(fileName, mime, text) {
    try {
      var b = new Blob([text], { type: mime });
      var url = URL.createObjectURL(b);
      var a = document.createElement("a");
      a.href = url;
      a.download = fileName;
      (root.ownerDocument.body || root).appendChild(a);
      a.click();
      setTimeout(function () { try { URL.revokeObjectURL(url); a.remove(); } catch (e) {} }, 400);
    } catch (e) {
      toast("Download failed in this browser: " + e, "error");
    }
  }

  /* ---- the modal ---- */
  function open() {
    var old = root.querySelector(".rgz-modal-backdrop");
    if (old) old.remove();
    var chans = buildChannels();
    var firstCyl = null, firstGauge = null;
    chans.forEach(function (c) {
      if (!firstCyl && /:pos$/.test(c.id)) firstCyl = c;
      if (!firstGauge && /:p$/.test(c.id) && c.id.indexOf("sys.") !== 0) firstGauge = c;
    });
    var optHtml = chans
      .map(function (c) { return '<option value="' + esc(c.id) + '">' + esc(c.label) + " (" + esc(c.unit) + ")</option>"; })
      .join("");
    var yHtml = chans
      .map(function (c) {
        var def = c.id === "sys.p" || (firstCyl && c.id === firstCyl.id);
        return (
          '<label class="rgz-ch-row"><input type="checkbox" data-rgzch-y="' +
          esc(c.id) + '"' + (def ? " checked" : "") + "><span>" + esc(c.label) +
          '</span><span class="rgz-ch-unit">' + esc(c.unit) + "</span></label>"
        );
      })
      .join("");
    var bd = document.createElement("div");
    bd.className = "rgz-modal-backdrop";
    bd.innerHTML =
      '\n      <div class="rgz-modal rgz-chart-modal" role="dialog" aria-modal="true" aria-label="Custom charts">\n        <div class="rgz-modal-head">\n          <div><h3>Custom charts</h3><p><span data-rgzch-count>' +
      chart.rows.length +
      '</span> samples recorded · recording is automatic while the simulation runs (every 10 ms of sim time).</p></div>\n          <button class="rgz-btn icon" data-modal-close>×</button>\n        </div>\n        <div class="rgz-modal-body rgz-chart-body">\n          <div class="rgz-panel rgz-chart-setup">\n            <div class="rgz-panel-title">Chart definition</div>\n            <div class="rgz-field" style="margin-top:8px"><label>X axis</label><select class="rgz-input rgz-select" data-rgzch-x><option value="time" selected>Time (s)</option>' +
      optHtml +
      '</select></div>\n            <div class="rgz-field"><label>Y series — left axis</label><div class="rgz-ch-list">' +
      yHtml +
      '</div></div>\n            <div class="rgz-field"><label>Y series — right axis (optional)</label><select class="rgz-input rgz-select" data-rgzch-r><option value="">None</option>' +
      optHtml +
      '</select></div>\n            <div class="rgz-field"><label>Chart title</label><input class="rgz-input" type="text" data-rgzch-lab="title" placeholder="e.g. Press cycle — position vs time" value="' +
      esc(labels.title) +
      '"></div>\n            <div class="rgz-field"><label>X axis caption</label><input class="rgz-input" type="text" data-rgzch-lab="x" placeholder="default: channel name + unit" value="' +
      esc(labels.x) +
      '"></div>\n            <div class="rgz-field"><label>Left axis caption</label><input class="rgz-input" type="text" data-rgzch-lab="left" placeholder="default: channel / unit" value="' +
      esc(labels.left) +
      '"></div>\n            <div class="rgz-field"><label>Right axis caption</label><input class="rgz-input" type="text" data-rgzch-lab="right" placeholder="default: channel / unit" value="' +
      esc(labels.right) +
      '"></div>\n            <label class="rgz-ch-row" style="margin-top:6px"><input type="checkbox" data-rgzch-live' + (liveOn ? " checked" : "") + '><span>Live preview — redraw while the simulation runs</span></label>\n            <div class="rgz-field-grid" style="margin-top:10px">\n              <button class="rgz-btn primary" data-rgzch-render>Render chart</button>\n              <button class="rgz-btn" data-rgzch-svg>Export SVG</button>\n              <button class="rgz-btn" data-rgzch-csv>Export CSV</button>\n              <button class="rgz-btn danger" data-rgzch-clear>Clear data</button>\n            </div>\n            <p>Example: tick a cylinder “position” channel, leave X = Time, and render a position–time curve. Use the right axis to overlay a differently-scaled channel such as pressure vs. position. Title and axis captions are editable (empty = automatic); every SVG export carries the houmanrgz.ir watermark.</p>\n          </div>\n          <div class="rgz-panel rgz-chart-view-panel">\n            <div class="rgz-panel-title">Preview</div>\n            <div class="rgz-chart-view" data-rgzch-view><div class="rgz-message info">Define X and Y on the left, then press “Render chart”.</div></div>\n          </div>\n        </div>\n        <div class="rgz-modal-foot"><span>Starting a new simulation run clears the previous record.</span><button class="rgz-btn" data-modal-close>Close</button></div>\n      </div>';
    root.appendChild(bd);

    function sel() {
      var xEl = bd.querySelector("[data-rgzch-x]");
      var rEl = bd.querySelector("[data-rgzch-r]");
      var ys = [];
      bd.querySelectorAll("[data-rgzch-y]:checked").forEach(function (el) {
        ys.push(el.getAttribute("data-rgzch-y"));
      });
      return {
        x: xEl ? xEl.value : "time",
        ys: ys,
        r: rEl && rEl.value ? rEl.value : null,
      };
    }
    function setCount() {
      var c = bd.querySelector("[data-rgzch-count]");
      if (c) c.textContent = String(chart.rows.length);
    }
    function render() {
      var s = sel();
      var view = bd.querySelector("[data-rgzch-view]");
      var res = renderSVG(s.x, s.ys, s.r, labels);
      if (res.error) {
        if (view) view.innerHTML = '<div class="rgz-message info">' + esc(res.error) + "</div>";
        toast(res.error, "warning");
        return false;
      }
      if (view) view.innerHTML = res.svg;
      setCount();
      return true;
    }
    function close() {
      if (liveTimer) { clearInterval(liveTimer); liveTimer = null; }
      bd.remove();
    }
    bd.addEventListener("click", function (e) {
      if (e.target === bd || e.target.closest("[data-modal-close]")) return void close();
      if (e.target.closest("[data-rgzch-render]")) return void render();
      if (e.target.closest("[data-rgzch-clear]")) {
        clear();
        setCount();
        var view = bd.querySelector("[data-rgzch-view]");
        if (view) view.innerHTML = '<div class="rgz-message info">Record cleared. Run the simulation to capture new samples.</div>';
        return void toast("Chart record cleared.", "info");
      }
      if (e.target.closest("[data-rgzch-svg]")) {
        var s = sel(), res = renderSVG(s.x, s.ys, s.r, labels);
        if (res.error) return void toast(res.error, "warning");
        download("rgz-" + name + "-chart.svg", "image/svg+xml", '<?xml version="1.0" encoding="UTF-8"?>\n' + res.svg);
        return void toast("Chart SVG exported (with watermark).", "ok");
      }
      if (e.target.closest("[data-rgzch-csv]")) {
        if (!chart.rows.length) return void toast("No samples recorded yet — run the simulation first.", "warning");
        var s2 = sel();
        download("rgz-" + name + "-chart.csv", "text/csv", csvText(s2.x, s2.ys, s2.r));
        return void toast("Chart data exported as CSV.", "ok");
      }
    });
    // editable captions: persist + repaint live
    bd.querySelectorAll("[data-rgzch-lab]").forEach(function (el) {
      el.addEventListener("input", function () {
        labels[el.getAttribute("data-rgzch-lab")] = el.value;
        saveLabels();
        if (bd.querySelector("[data-rgzch-view] svg")) render();
      });
    });
    var liveBox = bd.querySelector("[data-rgzch-live]");
    if (liveBox) liveBox.addEventListener("change", function () { liveOn = !!liveBox.checked; });
    // auto-render immediately when the record already has data — no extra click
    if (chart.rows.length) render();
    // gentle live refresh while the modal is open, the sim is running and Live is on
    liveTimer = setInterval(function () {
      if (!document.contains(bd)) { clearInterval(liveTimer); liveTimer = null; return; }
      setCount();
      if (liveOn && S.sim && S.sim.running && bd.querySelector("[data-rgzch-view] svg")) render();
    }, 700);
  }

  return { rec: rec, open: open, clear: clear, renderSVG: renderSVG, csvText: csvText, rows: function () { return chart.rows; }, buildChannels: buildChannels };
}

/*! RGZ Hydraulic Studio - Production build. Copyright HoumanRGZ / https://houmanrgz.ir . Unauthorized redistribution is prohibited. */
(() => {
  "use strict";
  const e = window.RGZHydraulicStudioConfig || {
      siteUrl: "https://houmanrgz.ir/",
      websiteLabel: "https://houmanrgz.ir",
      assetBase: "",
      version: "1.0.0",
    },
    t = "1.0.0",
    r = e.websiteLabel || "https://houmanrgz.ir",
    n = document.getElementById("rgz-hydraulic-studio");
  if (!n) return;
  const a = [
      "Power",
      "Valves",
      "Actuators",
      "Conditioning",
      "Measurement",
      "Control",
      "Lines",
      "Annotations",
    ],
    i = [
      {
        type: "tank",
        category: "Power",
        name: "Reservoir / tank",
        prefix: "T",
        w: 104,
        h: 80,
        desc: "Hydraulic oil tank with one or more return/suction ports.",
        ports: [{ id: "T", x: 0, y: -42, kind: "hydraulic", required: !0 }],
        defaults: { capacityL: 80, oilTempC: 40 },
        propSchema: [
          {
            key: "capacityL",
            label: "Capacity, L",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "oilTempC",
            label: "Oil temperature, °C",
            type: "number",
            min: -20,
            step: 1,
          },
        ],
      },
      {
        type: "pumpFixed",
        category: "Power",
        name: "Fixed displacement pump",
        prefix: "P",
        w: 126,
        h: 88,
        desc: "Constant-flow hydraulic pump. Requires relief protection.",
        ports: [
          { id: "S", x: -58, y: 0, kind: "hydraulic", required: !0 },
          { id: "P", x: 58, y: 0, kind: "hydraulic", required: !0 },
        ],
        defaults: { flowLpm: 25, maxPressureBar: 180, efficiency: 0.85 },
        propSchema: [
          {
            key: "flowLpm",
            label: "Flow, L/min",
            type: "number",
            min: 0,
            step: 0.1,
          },
          {
            key: "maxPressureBar",
            label: "Max pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "efficiency",
            label: "Efficiency",
            type: "number",
            min: 0.1,
            max: 1,
            step: 0.01,
          },
        ],
      },
      {
        type: "pumpVariable",
        category: "Power",
        name: "Variable displacement pump",
        prefix: "VP",
        w: 136,
        h: 92,
        desc: "Variable/pressure compensated pump for advanced examples.",
        ports: [
          { id: "S", x: -62, y: 0, kind: "hydraulic", required: !0 },
          { id: "P", x: 62, y: 0, kind: "hydraulic", required: !0 },
          { id: "X", x: 0, y: -46, kind: "pilot", required: !1 },
        ],
        defaults: { flowLpm: 32, compensatorBar: 160, maxPressureBar: 210 },
        propSchema: [
          {
            key: "flowLpm",
            label: "Max flow, L/min",
            type: "number",
            min: 0,
            step: 0.1,
          },
          {
            key: "compensatorBar",
            label: "Compensator, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "maxPressureBar",
            label: "Max pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
        ],
      },
      {
        type: "powerPack",
        category: "Power",
        name: "Compact hydraulic power pack",
        prefix: "HPU",
        w: 164,
        h: 112,
        desc: "Single block containing tank, fixed pump, relief valve and pressure gauge to speed up sketching.",
        ports: [
          { id: "P", x: 82, y: -22, kind: "hydraulic", required: !1 },
          { id: "T", x: 82, y: 30, kind: "hydraulic", required: !1 },
        ],
        defaults: {
          flowLpm: 25,
          reliefSettingBar: 160,
          tankCapacityL: 80,
          pressureGauge: !0,
        },
        propSchema: [
          {
            key: "flowLpm",
            label: "Pump flow, L/min",
            type: "number",
            min: 0,
            step: 0.1,
          },
          {
            key: "reliefSettingBar",
            label: "Internal relief, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "tankCapacityL",
            label: "Tank capacity, L",
            type: "number",
            min: 1,
            step: 1,
          },
          { key: "pressureGauge", label: "Include gauge", type: "checkbox" },
        ],
      },
      {
        type: "reliefValve",
        category: "Valves",
        name: "Pressure relief valve",
        prefix: "RV",
        w: 120,
        h: 96,
        desc: "Direct-acting relief valve from pressure line to tank.",
        ports: [
          { id: "P", x: -58, y: 0, kind: "hydraulic", required: !0 },
          { id: "T", x: 58, y: 0, kind: "hydraulic", required: !0 },
        ],
        defaults: { settingBar: 160, crackingBar: 150 },
        propSchema: [
          {
            key: "settingBar",
            label: "Relief setting, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "crackingBar",
            label: "Cracking pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
        ],
      },
      {
        type: "directionalValve",
        category: "Valves",
        name: "Directional control valve builder",
        prefix: "V",
        w: 182,
        h: 118,
        desc: "Configurable 2/2, 3/2, 4/2, 4/3 valve with selectable actuation.",
        ports: [
          { id: "A", x: -42, y: -58, kind: "hydraulic", required: !0 },
          { id: "B", x: 42, y: -58, kind: "hydraulic", required: !0 },
          { id: "P", x: -42, y: 58, kind: "hydraulic", required: !0 },
          { id: "T", x: 42, y: 58, kind: "hydraulic", required: !0 },
          { id: "X", x: -92, y: 0, kind: "pilot", required: !1 },
          { id: "Y", x: 92, y: 0, kind: "pilot", required: !1 },
        ],
        defaults: {
          ports: "4",
          positions: "3",
          center: "closed",
          spoolState: "left",
          leftActuation: "solenoid",
          rightActuation: "spring",
          ratedFlowLpm: 40,
          pressureDropBar: 5,
        },
        propSchema: [
          {
            key: "ports",
            label: "Ports",
            type: "select",
            options: ["2", "3", "4", "5", "6"],
          },
          {
            key: "positions",
            label: "Positions",
            type: "select",
            options: ["2", "3"],
          },
          {
            key: "center",
            label: "Center condition",
            type: "select",
            options: ["closed", "open", "tandem", "float", "regenerative"],
          },
          {
            key: "leftBlock",
            label: "Left block pattern",
            type: "select",
            options: ["parallel", "crossover", "closed", "open", "tandem", "float", "regenerative"],
          },
          {
            key: "rightBlock",
            label: "Right block pattern",
            type: "select",
            options: ["crossover", "parallel", "closed", "open", "tandem", "float", "regenerative"],
          },
          {
            key: "spoolState",
            label: "Simulation spool state",
            type: "select",
            options: ["left", "center", "right"],
          },
          {
            key: "leftActuation",
            label: "Left actuation",
            type: "select",
            options: [
              "manual",
              "lever",
              "push button",
              "pedal",
              "roller",
              "solenoid",
              "proportional solenoid",
              "hydraulic pilot",
              "pneumatic pilot",
              "spring",
              "detent",
            ],
          },
          {
            key: "rightActuation",
            label: "Right actuation",
            type: "select",
            options: [
              "manual",
              "lever",
              "push button",
              "pedal",
              "roller",
              "solenoid",
              "proportional solenoid",
              "hydraulic pilot",
              "pneumatic pilot",
              "spring",
              "detent",
            ],
          },
          {
            key: "ratedFlowLpm",
            label: "Rated flow, L/min",
            type: "number",
            min: 0,
            step: 0.1,
          },
          {
            key: "pressureDropBar",
            label: "Δp at rated flow, bar",
            type: "number",
            min: 0,
            step: 0.1,
          },
        ],
      },
      {
        type: "flowControl",
        category: "Valves",
        name: "Adjustable flow control",
        prefix: "FC",
        w: 116,
        h: 80,
        desc: "Adjustable throttle/needle valve. Can act as meter-in or meter-out.",
        ports: [
          { id: "A", x: -54, y: 0, kind: "hydraulic", required: !0 },
          { id: "B", x: 54, y: 0, kind: "hydraulic", required: !0 },
        ],
        defaults: { openingPercent: 65, pressureCompensated: !1 },
        propSchema: [
          {
            key: "openingPercent",
            label: "Opening, %",
            type: "number",
            min: 0,
            max: 100,
            step: 1,
          },
          {
            key: "pressureCompensated",
            label: "Pressure compensated",
            type: "checkbox",
          },
        ],
      },
      {
        type: "checkValve",
        category: "Valves",
        name: "Check valve",
        prefix: "CV",
        w: 104,
        h: 74,
        desc: "One-way non-return valve.",
        ports: [
          { id: "A", x: -50, y: 0, kind: "hydraulic", required: !0 },
          { id: "B", x: 50, y: 0, kind: "hydraulic", required: !0 },
        ],
        defaults: { crackingBar: 0.5 },
        propSchema: [
          {
            key: "crackingBar",
            label: "Cracking pressure, bar",
            type: "number",
            min: 0,
            step: 0.1,
          },
        ],
      },
      {
        type: "pilotCheckValve",
        category: "Valves",
        name: "Pilot-operated check valve",
        prefix: "PCV",
        w: 126,
        h: 88,
        desc: "Load-holding check valve released by pilot pressure.",
        ports: [
          { id: "A", x: -58, y: 0, kind: "hydraulic", required: !0 },
          { id: "B", x: 58, y: 0, kind: "hydraulic", required: !0 },
          { id: "X", x: 0, y: -44, kind: "pilot", required: !0 },
        ],
        defaults: { pilotRatio: 3, crackingBar: 1 },
        propSchema: [
          {
            key: "pilotRatio",
            label: "Pilot ratio",
            type: "number",
            min: 1,
            step: 0.1,
          },
          {
            key: "crackingBar",
            label: "Cracking pressure, bar",
            type: "number",
            min: 0,
            step: 0.1,
          },
        ],
      },
      {
        type: "counterbalanceValve",
        category: "Valves",
        name: "Counterbalance valve",
        prefix: "CBV",
        w: 132,
        h: 94,
        desc: "Over-center/load-control valve for vertical cylinders.",
        ports: [
          { id: "A", x: -60, y: 0, kind: "hydraulic", required: !0 },
          { id: "B", x: 60, y: 0, kind: "hydraulic", required: !0 },
          { id: "X", x: 0, y: -48, kind: "pilot", required: !0 },
        ],
        defaults: { settingBar: 120, pilotRatio: 3 },
        propSchema: [
          {
            key: "settingBar",
            label: "Setting, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "pilotRatio",
            label: "Pilot ratio",
            type: "number",
            min: 1,
            step: 0.1,
          },
        ],
      },
      {
        type: "sequenceValve",
        category: "Valves",
        name: "Sequence valve",
        prefix: "SV",
        w: 126,
        h: 92,
        desc: "Opens after pressure reaches a set sequence value.",
        ports: [
          { id: "P", x: -58, y: 0, kind: "hydraulic", required: !0 },
          { id: "A", x: 58, y: 0, kind: "hydraulic", required: !0 },
          { id: "T", x: 0, y: 46, kind: "hydraulic", required: !1 },
        ],
        defaults: { settingBar: 70 },
        propSchema: [
          {
            key: "settingBar",
            label: "Sequence pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
        ],
      },
      {
        type: "reducingValve",
        category: "Valves",
        name: "Pressure reducing valve",
        prefix: "PRV",
        w: 126,
        h: 92,
        desc: "Reduces pressure on a branch line.",
        ports: [
          { id: "P", x: -58, y: 0, kind: "hydraulic", required: !0 },
          { id: "A", x: 58, y: 0, kind: "hydraulic", required: !0 },
          { id: "T", x: 0, y: 46, kind: "hydraulic", required: !1 },
        ],
        defaults: { outletBar: 45 },
        propSchema: [
          {
            key: "outletBar",
            label: "Outlet pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
        ],
      },
      {
        type: "cylinderDA",
        category: "Actuators",
        name: "Double-acting cylinder",
        prefix: "C",
        w: 188,
        h: 84,
        desc: "Cylinder with cap-end and rod-end ports.",
        ports: [
          { id: "A", x: -82, y: 34, kind: "hydraulic", required: !0 },
          { id: "B", x: 22, y: 34, kind: "hydraulic", required: !0 },
        ],
        defaults: {
          boreMm: 63,
          rodMm: 36,
          strokeMm: 500,
          loadKg: 350,
          simPosition: 0.25,
        },
        propSchema: [
          { key: "boreMm", label: "Bore, mm", type: "number", min: 1, step: 1 },
          { key: "rodMm", label: "Rod, mm", type: "number", min: 0, step: 1 },
          {
            key: "strokeMm",
            label: "Stroke, mm",
            type: "number",
            min: 1,
            step: 1,
          },
          { key: "loadKg", label: "Load, kg", type: "number", min: 0, step: 1 },
          {
            key: "loadMode",
            label: "Load over cycle",
            type: "select",
            options: ["constant", "time-based", "position-based", "formula (t & x)"],
          },
          {
            key: "loadProfile",
            label: "Load profile — 's, kg' or '0..1, kg' points per line — OR a formula in t & x: 800 + 400*sin(2*pi*t) + 1200*x^2",
            type: "textarea",
            placeholder: "0, 200\n2, 3000",
          },
          {
            key: "simPosition",
            label: "Rod position, 0–1",
            type: "number",
            min: 0,
            max: 1,
            step: 0.01,
          },
        ],
      },
      {
        type: "cylinderSA",
        category: "Actuators",
        name: "Single-acting cylinder",
        prefix: "SC",
        w: 170,
        h: 82,
        desc: "Single-acting cylinder with spring/external return.",
        ports: [{ id: "A", x: -76, y: 34, kind: "hydraulic", required: !0 }],
        defaults: {
          boreMm: 50,
          strokeMm: 300,
          loadKg: 100,
          springReturn: !0,
          simPosition: 0.15,
        },
        propSchema: [
          { key: "boreMm", label: "Bore, mm", type: "number", min: 1, step: 1 },
          {
            key: "strokeMm",
            label: "Stroke, mm",
            type: "number",
            min: 1,
            step: 1,
          },
          { key: "loadKg", label: "Load, kg", type: "number", min: 0, step: 1 },
          {
            key: "loadMode",
            label: "Load over cycle",
            type: "select",
            options: ["constant", "time-based", "position-based", "formula (t & x)"],
          },
          {
            key: "loadProfile",
            label: "Load profile — 's, kg' or '0..1, kg' points per line — OR a formula in t & x: 800 + 400*sin(2*pi*t) + 1200*x^2",
            type: "textarea",
            placeholder: "0, 200\n2, 3000",
          },
          { key: "springReturn", label: "Spring return", type: "checkbox" },
          {
            key: "simPosition",
            label: "Rod position, 0–1",
            type: "number",
            min: 0,
            max: 1,
            step: 0.01,
          },
        ],
      },
      {
        type: "hydraulicMotor",
        category: "Actuators",
        name: "Hydraulic motor",
        prefix: "M",
        w: 122,
        h: 86,
        desc: "Bi-directional hydraulic motor.",
        ports: [
          { id: "A", x: -58, y: 0, kind: "hydraulic", required: !0 },
          { id: "B", x: 58, y: 0, kind: "hydraulic", required: !0 },
        ],
        defaults: { displacementCcRev: 25, loadNm: 20, simAngle: 0 },
        propSchema: [
          {
            key: "displacementCcRev",
            label: "Displacement, cc/rev",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "loadNm",
            label: "Load torque, Nm",
            type: "number",
            min: 0,
            step: 1,
          },          {
            key: "loadMode",
            label: "Load over cycle",
            type: "select",
            options: ["constant", "time-based", "position-based", "formula (t & x)"],
          },
          {
            key: "loadProfile",
            label: "Load torque profile — 's, N·m' points per line — OR a formula in t & x: 20 + 10*sin(2*pi*t)",
            type: "textarea",
            placeholder: "0, 5\n2, 40",
          },

        ],
      },
      {
        type: "accumulator",
        category: "Actuators",
        name: "Accumulator",
        prefix: "ACC",
        w: 96,
        h: 104,
        desc: "Gas-charged hydraulic accumulator.",
        ports: [{ id: "A", x: 0, y: 52, kind: "hydraulic", required: !0 }],
        defaults: { prechargeBar: 70, volumeL: 5 },
        propSchema: [
          {
            key: "prechargeBar",
            label: "Precharge, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "volumeL",
            label: "Volume, L",
            type: "number",
            min: 0.1,
            step: 0.1,
          },
        ],
      },
      {
        type: "flowDivider",
        category: "Valves",
        name: "Flow divider / combiner",
        prefix: "FD",
        w: 132,
        h: 100,
        desc: "Divides one inlet flow into two branches.",
        ports: [
          { id: "P", x: 0, y: 50, kind: "hydraulic", required: !0 },
          { id: "A", x: -56, y: -10, kind: "hydraulic", required: !0 },
          { id: "B", x: 56, y: -10, kind: "hydraulic", required: !0 },
        ],
        defaults: { splitPercentA: 50 },
        propSchema: [
          {
            key: "splitPercentA",
            label: "Flow to A, %",
            type: "number",
            min: 1,
            max: 99,
            step: 1,
          },
        ],
      },
      {
        type: "filter",
        category: "Conditioning",
        name: "Filter",
        prefix: "F",
        w: 110,
        h: 78,
        desc: "Pressure, return, or suction filter.",
        ports: [
          { id: "A", x: -52, y: 0, kind: "hydraulic", required: !0 },
          { id: "B", x: 52, y: 0, kind: "hydraulic", required: !0 },
        ],
        defaults: { ratingMicron: 10, betaRatio: 200 },
        propSchema: [
          {
            key: "ratingMicron",
            label: "Rating, μm",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "betaRatio",
            label: "Beta ratio",
            type: "number",
            min: 1,
            step: 1,
          },
        ],
      },
      {
        type: "cooler",
        category: "Conditioning",
        name: "Cooler / heat exchanger",
        prefix: "HX",
        w: 120,
        h: 82,
        desc: "Oil cooler or heat exchanger.",
        ports: [
          { id: "A", x: -56, y: 0, kind: "hydraulic", required: !0 },
          { id: "B", x: 56, y: 0, kind: "hydraulic", required: !0 },
        ],
        defaults: { coolingKw: 3 },
        propSchema: [
          {
            key: "coolingKw",
            label: "Cooling capacity, kW",
            type: "number",
            min: 0,
            step: 0.1,
          },
        ],
      },
      {
        type: "pressureGauge",
        category: "Measurement",
        name: "Pressure gauge",
        prefix: "PG",
        w: 82,
        h: 92,
        desc: "Analog pressure gauge.",
        ports: [{ id: "P", x: 0, y: 46, kind: "hydraulic", required: !0 }],
        defaults: { rangeBar: 250 },
        propSchema: [
          {
            key: "rangeBar",
            label: "Gauge range, bar",
            type: "number",
            min: 1,
            step: 1,
          },
        ],
      },
      {
        type: "flowMeter",
        category: "Measurement",
        name: "Flow meter",
        prefix: "FM",
        w: 112,
        h: 76,
        desc: "Hydraulic flow meter.",
        ports: [
          { id: "A", x: -54, y: 0, kind: "hydraulic", required: !0 },
          { id: "B", x: 54, y: 0, kind: "hydraulic", required: !0 },
        ],
        defaults: { rangeLpm: 80 },
        propSchema: [
          {
            key: "rangeLpm",
            label: "Range, L/min",
            type: "number",
            min: 1,
            step: 1,
          },
        ],
      },
      {
        type: "pressureSwitch",
        category: "Measurement",
        name: "Pressure switch",
        prefix: "PS",
        w: 108,
        h: 90,
        desc: "Hydraulic pressure switch with electrical contact.",
        ports: [
          { id: "P", x: 0, y: 46, kind: "hydraulic", required: !0 },
          { id: "E", x: 50, y: -24, kind: "electrical", required: !1 },
        ],
        defaults: { switchBar: 80, contact: "NO" },
        propSchema: [
          {
            key: "switchBar",
            label: "Switch pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "contact",
            label: "Contact",
            type: "select",
            options: ["NO", "NC"],
          },
        ],
      },
      {
        type: "pressureTransducer",
        category: "Measurement",
        name: "Pressure transducer",
        prefix: "PT",
        w: 112,
        h: 90,
        desc: "Analog pressure sensor/transducer for feedback and monitoring.",
        ports: [
          { id: "P", x: 0, y: 46, kind: "hydraulic", required: !0 },
          { id: "E", x: 52, y: -18, kind: "electrical", required: !1 },
        ],
        defaults: { rangeBar: 250, signal: "4-20 mA", active: !1 },
        propSchema: [
          {
            key: "rangeBar",
            label: "Range, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "signal",
            label: "Output signal",
            type: "select",
            options: ["4-20 mA", "0-10 V", "IO-Link", "Digital"],
          },
        ],
      },
      {
        type: "flowSwitch",
        category: "Measurement",
        name: "Flow switch / flow sensor",
        prefix: "FS",
        w: 126,
        h: 82,
        desc: "Detects flow above a set value and can trigger a control action.",
        ports: [
          { id: "A", x: -58, y: 0, kind: "hydraulic", required: !0 },
          { id: "B", x: 58, y: 0, kind: "hydraulic", required: !0 },
          { id: "E", x: 0, y: -42, kind: "electrical", required: !1 },
        ],
        defaults: {
          switchLpm: 5,
          active: !1,
          action: "none",
          targetControl: "",
        },
        propSchema: [
          {
            key: "switchLpm",
            label: "Switch flow, L/min",
            type: "number",
            min: 0,
            step: 0.1,
          },
          {
            key: "action",
            label: "Action when active",
            type: "select",
            options: [
              "none",
              "set valve left",
              "set valve center",
              "set valve right",
              "energize solenoid",
              "de-energize solenoid",
            ],
          },
          {
            key: "targetControl",
            label: "Target valve/solenoid ID or label",
            type: "text",
          },
        ],
      },
      {
        type: "temperatureSwitch",
        category: "Measurement",
        name: "Temperature switch",
        prefix: "TS",
        w: 108,
        h: 88,
        desc: "Oil temperature switch/sensor for alarm or control feedback.",
        ports: [
          { id: "P", x: 0, y: 44, kind: "hydraulic", required: !1 },
          { id: "E", x: 50, y: -18, kind: "electrical", required: !1 },
        ],
        defaults: {
          switchTempC: 60,
          active: !1,
          action: "none",
          targetControl: "",
        },
        propSchema: [
          {
            key: "switchTempC",
            label: "Switch temperature, °C",
            type: "number",
            min: -20,
            step: 1,
          },
          {
            key: "active",
            label: "Force active in simulation",
            type: "checkbox",
          },
          {
            key: "action",
            label: "Action when active",
            type: "select",
            options: [
              "none",
              "set valve left",
              "set valve center",
              "set valve right",
              "energize solenoid",
              "de-energize solenoid",
            ],
          },
          {
            key: "targetControl",
            label: "Target valve/solenoid ID or label",
            type: "text",
          },
        ],
      },
      {
        type: "levelSwitch",
        category: "Measurement",
        name: "Tank level switch",
        prefix: "LSH",
        w: 112,
        h: 88,
        desc: "Reservoir level switch for low/high oil level feedback.",
        ports: [
          { id: "E1", x: -52, y: 0, kind: "electrical", required: !1 },
          { id: "E2", x: 52, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: {
          levelPercent: 20,
          mode: "low level",
          active: !1,
          action: "none",
          targetControl: "",
        },
        propSchema: [
          {
            key: "levelPercent",
            label: "Level setpoint, %",
            type: "number",
            min: 0,
            max: 100,
            step: 1,
          },
          {
            key: "mode",
            label: "Switch mode",
            type: "select",
            options: ["low level", "high level"],
          },
          {
            key: "active",
            label: "Force active in simulation",
            type: "checkbox",
          },
          {
            key: "action",
            label: "Action when active",
            type: "select",
            options: [
              "none",
              "set valve left",
              "set valve center",
              "set valve right",
              "energize solenoid",
              "de-energize solenoid",
            ],
          },
          {
            key: "targetControl",
            label: "Target valve/solenoid ID or label",
            type: "text",
          },
        ],
      },
      {
        type: "limitSwitch",
        category: "Control",
        name: "Mechanical limit switch",
        prefix: "LS",
        w: 118,
        h: 78,
        desc: "Roller/lever limit switch for actuator end-position feedback.",
        ports: [
          { id: "E1", x: -56, y: 0, kind: "electrical", required: !1 },
          { id: "E2", x: 56, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: {
          linkedActuator: "",
          triggerAt: "extended",
          triggerPosition: 1,
          active: !1,
          action: "none",
          targetControl: "",
        },
        propSchema: [
          {
            key: "linkedActuator",
            label: "Linked actuator ID/label",
            type: "text",
          },
          {
            key: "triggerAt",
            label: "Trigger position",
            type: "select",
            options: ["retracted", "extended", "custom"],
          },
          {
            key: "triggerPosition",
            label: "Custom position 0–1",
            type: "number",
            min: 0,
            max: 1,
            step: 0.01,
          },
          {
            key: "action",
            label: "Action when active",
            type: "select",
            options: [
              "none",
              "set valve left",
              "set valve center",
              "set valve right",
              "energize solenoid",
              "de-energize solenoid",
            ],
          },
          {
            key: "targetControl",
            label: "Target valve/solenoid ID or label",
            type: "text",
          },
        ],
      },
      {
        type: "cylinderReedSensor",
        category: "Control",
        name: "Cylinder magnetic/reed sensor",
        prefix: "RS",
        w: 126,
        h: 78,
        desc: "Cylinder-mounted magnetic sensor for retracted, extended, or custom rod position.",
        ports: [
          { id: "E1", x: -58, y: 0, kind: "electrical", required: !1 },
          { id: "E2", x: 58, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: {
          linkedActuator: "",
          triggerAt: "extended",
          triggerPosition: 1,
          active: !1,
          action: "set valve right",
          targetControl: "",
        },
        propSchema: [
          {
            key: "linkedActuator",
            label: "Linked cylinder ID/label",
            type: "text",
          },
          {
            key: "triggerAt",
            label: "Trigger position",
            type: "select",
            options: ["retracted", "extended", "custom"],
          },
          {
            key: "triggerPosition",
            label: "Custom position 0–1",
            type: "number",
            min: 0,
            max: 1,
            step: 0.01,
          },
          {
            key: "action",
            label: "Action when active",
            type: "select",
            options: [
              "none",
              "set valve left",
              "set valve center",
              "set valve right",
              "energize solenoid",
              "de-energize solenoid",
            ],
          },
          {
            key: "targetControl",
            label: "Target valve/solenoid ID or label",
            type: "text",
          },
        ],
      },
      {
        type: "linearPositionSensor",
        category: "Control",
        name: "Linear position sensor / LVDT",
        prefix: "LVDT",
        w: 140,
        h: 78,
        desc: "Analog cylinder position feedback sensor with optional switching action.",
        ports: [
          { id: "E1", x: -64, y: 0, kind: "electrical", required: !1 },
          { id: "E2", x: 64, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: {
          linkedActuator: "",
          triggerAt: "custom",
          triggerPosition: 0.5,
          signal: "0-10 V",
          active: !1,
          action: "none",
          targetControl: "",
        },
        propSchema: [
          {
            key: "linkedActuator",
            label: "Linked actuator ID/label",
            type: "text",
          },
          {
            key: "triggerAt",
            label: "Switching point",
            type: "select",
            options: ["retracted", "extended", "custom"],
          },
          {
            key: "triggerPosition",
            label: "Position 0–1",
            type: "number",
            min: 0,
            max: 1,
            step: 0.01,
          },
          {
            key: "signal",
            label: "Output signal",
            type: "select",
            options: ["0-10 V", "4-20 mA", "SSI", "CANopen", "IO-Link"],
          },
          {
            key: "action",
            label: "Action when active",
            type: "select",
            options: [
              "none",
              "set valve left",
              "set valve center",
              "set valve right",
              "energize solenoid",
              "de-energize solenoid",
            ],
          },
          {
            key: "targetControl",
            label: "Target valve/solenoid ID or label",
            type: "text",
          },
        ],
      },
      {
        type: "proximitySensor",
        category: "Control",
        name: "Inductive/proximity sensor",
        prefix: "B",
        w: 118,
        h: 76,
        desc: "Non-contact proximity sensor for position, guard, or machine feedback.",
        ports: [
          { id: "E1", x: -56, y: 0, kind: "electrical", required: !1 },
          { id: "E2", x: 56, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: {
          linkedActuator: "",
          triggerAt: "custom",
          triggerPosition: 0.5,
          sensingDistanceMm: 5,
          active: !1,
          action: "none",
          targetControl: "",
        },
        propSchema: [
          {
            key: "linkedActuator",
            label: "Linked actuator ID/label",
            type: "text",
          },
          {
            key: "triggerAt",
            label: "Trigger position",
            type: "select",
            options: ["retracted", "extended", "custom"],
          },
          {
            key: "triggerPosition",
            label: "Custom position 0–1",
            type: "number",
            min: 0,
            max: 1,
            step: 0.01,
          },
          {
            key: "sensingDistanceMm",
            label: "Sensing distance, mm",
            type: "number",
            min: 0,
            step: 0.1,
          },
          {
            key: "action",
            label: "Action when active",
            type: "select",
            options: [
              "none",
              "set valve left",
              "set valve center",
              "set valve right",
              "energize solenoid",
              "de-energize solenoid",
            ],
          },
          {
            key: "targetControl",
            label: "Target valve/solenoid ID or label",
            type: "text",
          },
        ],
      },
      {
        type: "pushButton",
        category: "Control",
        name: "Push button / manual input",
        prefix: "PB",
        w: 102,
        h: 76,
        desc: "Clickable NO/NC push button for electrohydraulic control examples.",
        ports: [
          { id: "E1", x: -48, y: 0, kind: "electrical", required: !1 },
          { id: "E2", x: 48, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: { contact: "NO", pressed: !1, momentary: !0 },
        propSchema: [
          {
            key: "contact",
            label: "Contact",
            type: "select",
            options: ["NO", "NC"],
          },
          { key: "pressed", label: "Pressed in simulation", type: "checkbox" },
          { key: "momentary", label: "Momentary button", type: "checkbox" },
        ],
      },
      {
        type: "solenoid",
        category: "Control",
        name: "Solenoid coil",
        prefix: "Y",
        w: 92,
        h: 74,
        desc: "Electrical coil for valve actuation.",
        ports: [
          { id: "E1", x: -44, y: 0, kind: "electrical", required: !1 },
          { id: "E2", x: 44, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: { voltage: "24 VDC", energized: !1, targetControl: "" },
        propSchema: [
          { key: "voltage", label: "Voltage", type: "text" },
          {
            key: "energized",
            label: "Energized in simulation",
            type: "checkbox",
          },
          {
            key: "targetControl",
            label: "Drives valve (label/id, empty = auto)",
            type: "text",
          },
        ],
      },
      {
        type: "plc",
        category: "Control",
        name: "PLC I/O block",
        prefix: "PLC",
        w: 126,
        h: 92,
        desc: "Programmable controller: runs logic rungs every scan, e.g. 'PB1 AND NOT B1 -> V1 left' or 'Q1 = PB1 OR Q1 AND NOT B1'. Deleting it stops the sequence.",
        ports: [
          { id: "I1", x: -58, y: -18, kind: "electrical", required: !1 },
          { id: "I2", x: -58, y: 18, kind: "electrical", required: !1 },
          { id: "Q1", x: 58, y: -18, kind: "electrical", required: !1 },
          { id: "Q2", x: 58, y: 18, kind: "electrical", required: !1 },
        ],
        defaults: { program: "Q1 = I1; Q2 = I2;", targetControl: "" },
        propSchema: [
          {
            key: "program",
            label: "Program (PLC rungs)",
            type: "textarea",
          },
        ],
      },
      {
        type: "blindPlug",
        category: "Lines",
        name: "Blind plug / socket cap",
        prefix: "BP",
        w: 56,
        h: 56,
        desc: "Seal an unused port with a blanking cap instead of leaving it open (safety + prevents the open-port exhaust/vent behaviour).",
        ports: [{ id: "A", x: -26, y: 0, kind: "hydraulic", required: !1 }],
        defaults: {},
        propSchema: [],
      },
      {
        type: "blindPlug",
        category: "Lines",
        name: "Blind plug / socket cap",
        prefix: "BP",
        w: 56,
        h: 56,
        desc: "Seal an unused port with a blanking cap instead of leaving it open (stops the open-port exhaust hiss and keeps dirt out).",
        ports: [{ id: "A", x: -26, y: 0, kind: "pneumatic", required: !1 }],
        defaults: {},
        propSchema: [],
      },
      {
        type: "junction",
        category: "Lines",
        name: "Line junction",
        prefix: "J",
        w: 52,
        h: 52,
        desc: "Hydraulic junction/dot for branching lines.",
        ports: [
          { id: "A", x: -26, y: 0, kind: "hydraulic", required: !1 },
          { id: "B", x: 26, y: 0, kind: "hydraulic", required: !1 },
          { id: "C", x: 0, y: -26, kind: "hydraulic", required: !1 },
          { id: "D", x: 0, y: 26, kind: "hydraulic", required: !1 },
        ],
        defaults: {},
        propSchema: [],
      },
      {
        type: "textLabel",
        category: "Annotations",
        name: "Custom text / title",
        prefix: "TXT",
        w: 280,
        h: 90,
        desc: "Movable annotation text for titles, notes and Persian/RTL labels. Appears in print.",
        ports: [],
        defaults: {
          text: "Custom text",
          color: "#e8793c",
          fontSize: 24,
          fontFamily: "Tahoma, Arial, sans-serif",
          fontWeight: "700",
          direction: "auto",
          align: "start",
        },
        propSchema: [
          { key: "text", label: "Text / متن", type: "textarea" },
          { key: "color", label: "Text color", type: "color" },
          {
            key: "fontSize",
            label: "Font size",
            type: "number",
            min: 8,
            max: 96,
            step: 1,
          },
          {
            key: "fontFamily",
            label: "Font family",
            type: "select",
            options: [
              "Tahoma, Arial, sans-serif",
              "Arial, sans-serif",
              "Inter, sans-serif",
              "Times New Roman, serif",
              "Courier New, monospace",
            ],
          },
          {
            key: "fontWeight",
            label: "Font weight",
            type: "select",
            options: ["400", "500", "600", "700", "800", "900"],
          },
          {
            key: "direction",
            label: "Text direction",
            type: "select",
            options: ["auto", "ltr", "rtl"],
          },
          {
            key: "align",
            label: "Alignment",
            type: "select",
            options: ["start", "middle", "end"],
          },
        ],
      },
    ],
    o = {
      "2/2 normally closed": {
        ports: "2",
        positions: "2",
        center: "closed",
        spoolState: "right",
      },
      "2/2 normally open": {
        ports: "2",
        positions: "2",
        center: "open",
        spoolState: "left",
      },
      "3/2 normally closed": {
        ports: "3",
        positions: "2",
        center: "closed",
        spoolState: "right",
      },
      "3/2 normally open": {
        ports: "3",
        positions: "2",
        center: "open",
        spoolState: "left",
      },
      "4/2 directional valve": {
        ports: "4",
        positions: "2",
        center: "closed",
        spoolState: "left",
      },
      "4/3 closed center": {
        ports: "4",
        positions: "3",
        center: "closed",
        spoolState: "center",
      },
      "4/3 open center": {
        ports: "4",
        positions: "3",
        center: "open",
        spoolState: "center",
      },
      "4/3 tandem center": {
        ports: "4",
        positions: "3",
        center: "tandem",
        spoolState: "center",
      },
      "4/3 float center": {
        ports: "4",
        positions: "3",
        center: "float",
        spoolState: "center",
      },
      "4/3 regenerative center": {
        ports: "4",
        positions: "3",
        center: "regenerative",
        spoolState: "center",
      },
      "5/2 directional valve": {
        ports: "5",
        positions: "2",
        center: "closed",
        spoolState: "left",
      },
      "5/3 closed center": {
        ports: "5",
        positions: "3",
        center: "closed",
        spoolState: "center",
      },
      "5/3 open center": {
        ports: "5",
        positions: "3",
        center: "open",
        spoolState: "center",
      },
      "5/3 exhaust center": {
        ports: "5",
        positions: "3",
        center: "float",
        spoolState: "center",
      },
    },
    s = i.find((e) => "directionalValve" === e.type);
  ((s.defaults = Object.assign({ valveType: "4/3 closed center" }, s.defaults)),
    (s.propSchema = [
      {
        key: "valveType",
        label: "Way valve type",
        type: "select",
        options: [
          "2/2 normally closed",
          "2/2 normally open",
          "3/2 normally closed",
          "3/2 normally open",
          "4/2 directional valve",
          "4/3 closed center",
          "4/3 open center",
          "4/3 tandem center",
          "4/3 float center",
          "4/3 regenerative center",
          "5/2 directional valve",
          "5/3 closed center",
          "5/3 open center",
          "5/3 exhaust center",
        ],
      },
      ...s.propSchema,
    ]));
  const l = [
    [
      "directionalValve22NC",
      "2/2 way valve — normally closed",
      "Compact 2-port shut-off valve.",
      "2/2 normally closed",
    ],
    [
      "directionalValve22NO",
      "2/2 way valve — normally open",
      "Compact 2-port normally-open valve.",
      "2/2 normally open",
    ],
    [
      "directionalValve32NC",
      "3/2 way valve — normally closed",
      "Three-port valve for single acting actuators.",
      "3/2 normally closed",
    ],
    [
      "directionalValve32NO",
      "3/2 way valve — normally open",
      "Three-port normally-open valve.",
      "3/2 normally open",
    ],
    [
      "directionalValve42",
      "4/2 way valve",
      "Four-port two-position directional valve.",
      "4/2 directional valve",
    ],
    [
      "directionalValve43Closed",
      "4/3 way valve — closed center",
      "All ports blocked in center.",
      "4/3 closed center",
    ],
    [
      "directionalValve43Open",
      "4/3 way valve — open center",
      "Open-center four-port valve.",
      "4/3 open center",
    ],
    [
      "directionalValve43Tandem",
      "4/3 way valve — tandem center",
      "P to T open, A/B blocked in center.",
      "4/3 tandem center",
    ],
    [
      "directionalValve43Float",
      "4/3 way valve — float center",
      "A/B to T, P blocked in center.",
      "4/3 float center",
    ],
    [
      "directionalValve43Regen",
      "4/3 way valve — regenerative center",
      "Regenerative center option.",
      "4/3 regenerative center",
    ],
    [
      "directionalValve52",
      "5/2 way valve",
      "Five-port two-position directional valve.",
      "5/2 directional valve",
    ],
    [
      "directionalValve53Closed",
      "5/3 way valve — closed center",
      "Five-port three-position closed-center valve.",
      "5/3 closed center",
    ],
    [
      "directionalValve53Open",
      "5/3 way valve — open center",
      "Five-port three-position open-center valve.",
      "5/3 open center",
    ],
  ].map(([e, t, r, n]) =>
    Object.assign({}, s, {
      type: e,
      name: t,
      desc: r,
      baseType: "directionalValve",
      defaults: Object.assign({}, s.defaults, o[n], { valveType: n }),
    }),
  );
  function c(e, t, r) {
    const n = i.find((t) => t.type === e);
    if (!n) return;
    n.defaults = Object.assign(
      {},
      n.defaults || {},
      { showReadout: !0 },
      t || {},
    );
    const a = new Set((n.propSchema || []).map((e) => e.key));
    ((n.propSchema = n.propSchema || []),
      a.has("showReadout") ||
        n.propSchema.push({
          key: "showReadout",
          label: "Show live value in simulation",
          type: "checkbox",
        }),
      (r || []).forEach((e) => {
        a.has(e.key) || n.propSchema.push(e);
      }));
  }
  (i.splice(i.indexOf(s) + 1, 0, ...l),
    i.push(
      {
        type: "electricMotor",
        category: "Power",
        name: "Electric motor / prime mover",
        prefix: "EM",
        w: 96,
        h: 72,
        desc: "Prime mover for a hydraulic pump.",
        ports: [],
        defaults: { powerKw: 5.5, rpm: 1500 },
        propSchema: [
          {
            key: "powerKw",
            label: "Power, kW",
            type: "number",
            min: 0,
            step: 0.1,
          },
          { key: "rpm", label: "Speed, rpm", type: "number", min: 0, step: 1 },
        ],
      },
      {
        type: "suctionStrainer",
        category: "Conditioning",
        name: "Suction strainer",
        prefix: "ST",
        w: 108,
        h: 76,
        desc: "Reservoir suction strainer for pump inlet protection.",
        ports: [
          { id: "A", x: -52, y: 0, kind: "hydraulic", required: !0 },
          { id: "B", x: 52, y: 0, kind: "hydraulic", required: !0 },
        ],
        defaults: { meshMicron: 125 },
        propSchema: [
          {
            key: "meshMicron",
            label: "Mesh, μm",
            type: "number",
            min: 1,
            step: 1,
          },
        ],
      },
      {
        type: "breatherFiller",
        category: "Conditioning",
        name: "Breather / filler cap",
        prefix: "BF",
        w: 92,
        h: 72,
        desc: "Reservoir breather and oil filling point.",
        ports: [{ id: "T", x: 0, y: 36, kind: "hydraulic", required: !1 }],
        defaults: { filterMicron: 10 },
        propSchema: [
          {
            key: "filterMicron",
            label: "Breather filter, μm",
            type: "number",
            min: 1,
            step: 1,
          },
        ],
      },
      {
        type: "testPoint",
        category: "Measurement",
        name: "Pressure test point",
        prefix: "TP",
        w: 74,
        h: 70,
        desc: "Diagnostic pressure test connector.",
        ports: [{ id: "P", x: 0, y: 34, kind: "hydraulic", required: !0 }],
        defaults: { maxPressureBar: 315 },
        propSchema: [
          {
            key: "maxPressureBar",
            label: "Max pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
        ],
      },
      {
        type: "shutoffValve",
        category: "Valves",
        name: "Manual shut-off valve",
        prefix: "SOV",
        w: 108,
        h: 76,
        desc: "Two-port manual isolation valve.",
        ports: [
          { id: "A", x: -52, y: 0, kind: "hydraulic", required: !0 },
          { id: "B", x: 52, y: 0, kind: "hydraulic", required: !0 },
        ],
        defaults: { open: !0 },
        propSchema: [
          { key: "open", label: "Open in simulation", type: "checkbox" },
        ],
      },
      {
        type: "pressureCompensator",
        category: "Valves",
        name: "Pressure compensator",
        prefix: "PC",
        w: 118,
        h: 82,
        desc: "Maintains pressure drop across a flow control element.",
        ports: [
          { id: "P", x: -56, y: 0, kind: "hydraulic", required: !0 },
          { id: "A", x: 56, y: 0, kind: "hydraulic", required: !0 },
          { id: "X", x: 0, y: -40, kind: "pilot", required: !1 },
        ],
        defaults: { deltaPBar: 8 },
        propSchema: [
          {
            key: "deltaPBar",
            label: "Compensated Δp, bar",
            type: "number",
            min: 0,
            step: 0.1,
          },
        ],
      },
      {
        type: "logicCartridgeValve",
        category: "Valves",
        name: "2-way logic / cartridge valve",
        prefix: "LCV",
        w: 124,
        h: 86,
        desc: "Two-way slip-in poppet (logic) cartridge with control cover; pressurised X clamps the poppet shut, vented X lets it lift.",
        ports: [
          { id: "A", x: -56, y: 0, kind: "hydraulic", required: !0 },
          { id: "B", x: 56, y: 0, kind: "hydraulic", required: !0 },
          { id: "X", x: 0, y: -42, kind: "pilot", required: !1 },
        ],
        defaults: { pilotRatio: 2 },
        propSchema: [
          {
            key: "pilotRatio",
            label: "Cover area ratio (X : A)",
            type: "number",
            min: 1,
            step: 0.1,
          },
        ],
      },
      {
        type: "servoValve",
        category: "Valves",
        name: "Servo / proportional valve",
        prefix: "PV",
        w: 166,
        h: 104,
        desc: "Electrohydraulic proportional or servo directional valve.",
        ports: [
          { id: "P", x: -42, y: 52, kind: "hydraulic", required: !0 },
          { id: "T", x: 42, y: 52, kind: "hydraulic", required: !0 },
          { id: "A", x: -42, y: -52, kind: "hydraulic", required: !0 },
          { id: "B", x: 42, y: -52, kind: "hydraulic", required: !0 },
          { id: "E", x: 82, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: { commandPercent: 0, ratedFlowLpm: 40 },
        propSchema: [
          {
            key: "commandPercent",
            label: "Command, %",
            type: "number",
            min: -100,
            max: 100,
            step: 1,
          },
          {
            key: "ratedFlowLpm",
            label: "Rated flow, L/min",
            type: "number",
            min: 0,
            step: 1,
          },
        ],
      },
      {
        type: "hydraulicIntensifier",
        category: "Actuators",
        name: "Pressure intensifier",
        prefix: "INT",
        w: 138,
        h: 88,
        desc: "Hydraulic pressure intensifier / booster.",
        ports: [
          { id: "P", x: -62, y: 0, kind: "hydraulic", required: !0 },
          { id: "A", x: 62, y: 0, kind: "hydraulic", required: !0 },
          { id: "T", x: 0, y: 44, kind: "hydraulic", required: !1 },
        ],
        defaults: { ratio: 2 },
        propSchema: [
          {
            key: "ratio",
            label: "Intensification ratio",
            type: "number",
            min: 1,
            step: 0.1,
          },
        ],
      },
      {
        type: "oilHeater",
        category: "Conditioning",
        name: "Oil heater",
        prefix: "HTR",
        w: 112,
        h: 76,
        desc: "Hydraulic reservoir or in-line oil heater.",
        ports: [
          { id: "A", x: -52, y: 0, kind: "hydraulic", required: !0 },
          { id: "B", x: 52, y: 0, kind: "hydraulic", required: !0 },
        ],
        defaults: { powerKw: 2 },
        propSchema: [
          {
            key: "powerKw",
            label: "Heating power, kW",
            type: "number",
            min: 0,
            step: 0.1,
          },
        ],
      },
    ),
    i.push(
      {
        type: "proportionalAmplifier",
        category: "Control",
        name: "Proportional valve amplifier",
        prefix: "AMP",
        w: 140,
        h: 88,
        desc: "Amplifier card for proportional valves: setpoint scaling, dither, ramp and offset.",
        ports: [
          { id: "E1", x: -64, y: -18, kind: "electrical", required: !1 },
          { id: "E2", x: -64, y: 18, kind: "electrical", required: !1 },
          { id: "Y", x: 64, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: {
          gain: 1,
          offsetPercent: 0,
          ditherHz: 120,
          rampUpS: 0.4,
          rampDownS: 0.4,
          outputPercent: 0,
        },
        propSchema: [
          { key: "gain", label: "Gain", type: "number", min: 0, step: 0.01 },
          {
            key: "offsetPercent",
            label: "Zero offset, %",
            type: "number",
            min: -100,
            max: 100,
            step: 1,
          },
          {
            key: "ditherHz",
            label: "Dither frequency, Hz",
            type: "number",
            min: 0,
            step: 1,
          },
          {
            key: "rampUpS",
            label: "Ramp up, s",
            type: "number",
            min: 0,
            step: 0.01,
          },
          {
            key: "rampDownS",
            label: "Ramp down, s",
            type: "number",
            min: 0,
            step: 0.01,
          },
          {
            key: "outputPercent",
            label: "Output command, %",
            type: "number",
            min: -100,
            max: 100,
            step: 1,
          },
        ],
      },
      {
        type: "setpointPotentiometer",
        category: "Control",
        name: "Setpoint potentiometer",
        prefix: "SP",
        w: 118,
        h: 78,
        desc: "Analog setpoint source for proportional valve command.",
        ports: [
          { id: "E1", x: -56, y: 0, kind: "electrical", required: !1 },
          { id: "OUT", x: 56, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: { setpointPercent: 50 },
        propSchema: [
          {
            key: "setpointPercent",
            label: "Setpoint, %",
            type: "number",
            min: -100,
            max: 100,
            step: 1,
          },
        ],
      },
      {
        type: "rampGenerator",
        category: "Control",
        name: "Ramp generator",
        prefix: "RAMP",
        w: 128,
        h: 80,
        desc: "Electrical ramp generator for smooth acceleration/deceleration of proportional valves.",
        ports: [
          { id: "IN", x: -60, y: 0, kind: "electrical", required: !1 },
          { id: "OUT", x: 60, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: { rampUpS: 1, rampDownS: 1 },
        propSchema: [
          {
            key: "rampUpS",
            label: "Ramp up, s",
            type: "number",
            min: 0,
            step: 0.01,
          },
          {
            key: "rampDownS",
            label: "Ramp down, s",
            type: "number",
            min: 0,
            step: 0.01,
          },
        ],
      },
      {
        type: "electricalRelay",
        category: "Control",
        name: "Relay / contactor coil",
        prefix: "K",
        w: 108,
        h: 76,
        desc: "Relay coil for electro-hydraulic switching logic.",
        ports: [
          { id: "A1", x: -50, y: 0, kind: "electrical", required: !1 },
          { id: "A2", x: 50, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: { energized: !1, coilVoltage: "24 VDC" },
        propSchema: [
          { key: "energized", label: "Energized", type: "checkbox" },
          { key: "coilVoltage", label: "Coil voltage", type: "text" },
        ],
      },
      {
        type: "relayContact",
        category: "Control",
        name: "Relay contact NO/NC",
        prefix: "K-C",
        w: 112,
        h: 76,
        desc: "Electrical relay contact used for latching and interlocking circuits.",
        ports: [
          { id: "E1", x: -54, y: 0, kind: "electrical", required: !1 },
          { id: "E2", x: 54, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: { contact: "NO", closed: !1 },
        propSchema: [
          {
            key: "contact",
            label: "Contact type",
            type: "select",
            options: ["NO", "NC"],
          },
          { key: "closed", label: "Closed in simulation", type: "checkbox" },
        ],
      },
      {
        type: "timerRelay",
        category: "Control",
        name: "Timer relay",
        prefix: "TMR",
        w: 118,
        h: 80,
        desc: "Electrical time relay for dwell and delayed switching sequences.",
        ports: [
          { id: "IN", x: -56, y: 0, kind: "electrical", required: !1 },
          { id: "OUT", x: 56, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: { delayS: 1, mode: "on-delay", active: !1 },
        propSchema: [
          {
            key: "delayS",
            label: "Delay, s",
            type: "number",
            min: 0,
            step: 0.01,
          },
          {
            key: "mode",
            label: "Timer mode",
            type: "select",
            options: ["on-delay", "off-delay", "pulse"],
          },
          { key: "active", label: "Active", type: "checkbox" },
        ],
      },
      {
        type: "emergencyStop",
        category: "Control",
        name: "Emergency stop contact",
        prefix: "ESTOP",
        w: 118,
        h: 78,
        desc: "Emergency-stop normally closed contact for electro-hydraulic safety logic.",
        ports: [
          { id: "E1", x: -56, y: 0, kind: "electrical", required: !1 },
          { id: "E2", x: 56, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: { pressed: !1 },
        propSchema: [
          { key: "pressed", label: "E-stop pressed", type: "checkbox" },
        ],
      },
      {
        type: "hydraulicTrainingNote",
        category: "Annotations",
        name: "Hydraulic formula note",
        prefix: "FORM",
        w: 220,
        h: 100,
        desc: "Formula note card for pressure, flow, power and cylinder calculations.",
        ports: [],
        defaults: {
          text: "p = F / A\nQ = v × A\nP(kW) = p(bar) × Q(L/min) / 600",
          color: "#38bdf8",
          fontSize: 16,
          fontFamily: "Tahoma, Arial, sans-serif",
          fontWeight: "700",
          direction: "ltr",
          align: "start",
        },
        propSchema: [
          { key: "text", label: "Formula text", type: "textarea" },
          { key: "color", label: "Text color", type: "color" },
          {
            key: "fontSize",
            label: "Font size",
            type: "number",
            min: 8,
            max: 72,
            step: 1,
          },
        ],
      },
    ),
    i.push(
      {
        type: "cartridgeCheckValve",
        category: "Valves",
        name: "Cartridge check valve",
        prefix: "CCV",
        w: 124,
        h: 82,
        desc: "Screw-in cartridge check valve for one-way flow and backflow prevention.",
        ports: [
          { id: "A", x: -58, y: 0, kind: "hydraulic", required: !0 },
          { id: "B", x: 58, y: 0, kind: "hydraulic", required: !0 },
        ],
        defaults: {
          sizeNG: 10,
          crackingBar: 1,
          maxPressureBar: 420,
          maxFlowLpm: 80,
        },
        propSchema: [
          {
            key: "sizeNG",
            label: "Nominal size NG",
            type: "number",
            min: 4,
            step: 1,
          },
          {
            key: "crackingBar",
            label: "Cracking pressure, bar",
            type: "number",
            min: 0,
            step: 0.1,
          },
          {
            key: "maxPressureBar",
            label: "Max pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "maxFlowLpm",
            label: "Max flow, L/min",
            type: "number",
            min: 0,
            step: 1,
          },
        ],
      },
      {
        type: "cartridgeReliefValve",
        category: "Valves",
        name: "Cartridge pressure relief valve",
        prefix: "CRV",
        w: 132,
        h: 92,
        desc: "Direct/pilot operated screw-in cartridge relief valve for pressure protection.",
        ports: [
          { id: "P", x: -60, y: 0, kind: "hydraulic", required: !0 },
          { id: "T", x: 60, y: 0, kind: "hydraulic", required: !0 },
        ],
        defaults: {
          settingBar: 160,
          maxPressureBar: 350,
          maxFlowLpm: 120,
          adjustment: "hex cap",
        },
        propSchema: [
          {
            key: "settingBar",
            label: "Relief setting, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "maxPressureBar",
            label: "Max pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "maxFlowLpm",
            label: "Max flow, L/min",
            type: "number",
            min: 0,
            step: 1,
          },
          {
            key: "adjustment",
            label: "Adjustment",
            type: "select",
            options: ["hex cap", "hand knob", "lockable knob"],
          },
        ],
      },
      {
        type: "cartridgeReducingValve",
        category: "Valves",
        name: "Cartridge pressure reducing valve",
        prefix: "CRD",
        w: 132,
        h: 96,
        desc: "Cartridge reducing/relieving valve for branch pressure regulation.",
        ports: [
          { id: "P", x: -60, y: 0, kind: "hydraulic", required: !0 },
          { id: "A", x: 60, y: 0, kind: "hydraulic", required: !0 },
          { id: "T", x: 0, y: 48, kind: "hydraulic", required: !1 },
        ],
        defaults: { outletBar: 50, maxPressureBar: 315, maxFlowLpm: 80 },
        propSchema: [
          {
            key: "outletBar",
            label: "Reduced outlet pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "maxPressureBar",
            label: "Max pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "maxFlowLpm",
            label: "Max flow, L/min",
            type: "number",
            min: 0,
            step: 1,
          },
        ],
      },
      {
        type: "cartridgeSequenceValve",
        category: "Valves",
        name: "Cartridge sequence valve",
        prefix: "CSV",
        w: 132,
        h: 96,
        desc: "Cartridge sequence valve for pressure-dependent actuator sequencing.",
        ports: [
          { id: "P", x: -60, y: 0, kind: "hydraulic", required: !0 },
          { id: "A", x: 60, y: 0, kind: "hydraulic", required: !0 },
          { id: "T", x: 0, y: 48, kind: "hydraulic", required: !1 },
        ],
        defaults: { sequenceBar: 70, maxPressureBar: 315, maxFlowLpm: 80 },
        propSchema: [
          {
            key: "sequenceBar",
            label: "Sequence pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "maxPressureBar",
            label: "Max pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "maxFlowLpm",
            label: "Max flow, L/min",
            type: "number",
            min: 0,
            step: 1,
          },
        ],
      },
      {
        type: "cartridgeUnloadingValve",
        category: "Valves",
        name: "Cartridge unloading valve",
        prefix: "CUV",
        w: 132,
        h: 96,
        desc: "Pilot-operated cartridge unloading valve for energy-saving pump unloading circuits.",
        ports: [
          { id: "P", x: -60, y: 0, kind: "hydraulic", required: !0 },
          { id: "T", x: 60, y: 0, kind: "hydraulic", required: !0 },
          { id: "X", x: 0, y: -48, kind: "pilot", required: !1 },
        ],
        defaults: { unloadBar: 120, maxPressureBar: 315, maxFlowLpm: 100 },
        propSchema: [
          {
            key: "unloadBar",
            label: "Unload pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "maxPressureBar",
            label: "Max pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "maxFlowLpm",
            label: "Max flow, L/min",
            type: "number",
            min: 0,
            step: 1,
          },
        ],
      },
      {
        type: "cartridgeCounterbalanceValve",
        category: "Valves",
        name: "Cartridge counterbalance / load-holding valve",
        prefix: "CLH",
        w: 144,
        h: 104,
        desc: "Cartridge load-holding/counterbalance valve with pilot ratio for overrunning loads.",
        ports: [
          { id: "A", x: -66, y: 0, kind: "hydraulic", required: !0 },
          { id: "B", x: 66, y: 0, kind: "hydraulic", required: !0 },
          { id: "X", x: 0, y: -52, kind: "pilot", required: !1 },
        ],
        defaults: {
          settingBar: 140,
          pilotRatio: 3,
          maxPressureBar: 350,
          maxFlowLpm: 80,
        },
        propSchema: [
          {
            key: "settingBar",
            label: "Load holding setting, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "pilotRatio",
            label: "Pilot ratio",
            type: "number",
            min: 1,
            step: 0.1,
          },
          {
            key: "maxPressureBar",
            label: "Max pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "maxFlowLpm",
            label: "Max flow, L/min",
            type: "number",
            min: 0,
            step: 1,
          },
        ],
      },
      {
        type: "cartridgeNeedleFlowValve",
        category: "Valves",
        name: "Cartridge needle / flow control valve",
        prefix: "CNV",
        w: 126,
        h: 82,
        desc: "Cartridge adjustable needle valve or throttle for metering and speed control.",
        ports: [
          { id: "A", x: -58, y: 0, kind: "hydraulic", required: !0 },
          { id: "B", x: 58, y: 0, kind: "hydraulic", required: !0 },
        ],
        defaults: { openingPercent: 50, reverseCheck: !1, maxFlowLpm: 60 },
        propSchema: [
          {
            key: "openingPercent",
            label: "Opening, %",
            type: "number",
            min: 0,
            max: 100,
            step: 1,
          },
          {
            key: "reverseCheck",
            label: "Include reverse check bypass",
            type: "checkbox",
          },
          {
            key: "maxFlowLpm",
            label: "Max flow, L/min",
            type: "number",
            min: 0,
            step: 1,
          },
        ],
      },
      {
        type: "cartridgeSolenoidValve22",
        category: "Valves",
        name: "2/2 solenoid cartridge valve",
        prefix: "CSV2",
        w: 132,
        h: 88,
        desc: "Two-port, two-position solenoid-operated screw-in cartridge poppet/spool valve.",
        ports: [
          { id: "P", x: -60, y: 0, kind: "hydraulic", required: !0 },
          { id: "A", x: 60, y: 0, kind: "hydraulic", required: !0 },
          { id: "E", x: 0, y: -44, kind: "electrical", required: !1 },
        ],
        defaults: {
          normallyOpen: !1,
          energized: !1,
          maxPressureBar: 315,
          maxFlowLpm: 40,
        },
        propSchema: [
          { key: "normallyOpen", label: "Normally open", type: "checkbox" },
          {
            key: "energized",
            label: "Energized in simulation",
            type: "checkbox",
          },
          {
            key: "maxPressureBar",
            label: "Max pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "maxFlowLpm",
            label: "Max flow, L/min",
            type: "number",
            min: 0,
            step: 1,
          },
        ],
      },
      {
        type: "cartridgeShuttleValve",
        category: "Valves",
        name: "Cartridge shuttle valve",
        prefix: "CSVOR",
        w: 132,
        h: 90,
        desc: "Cartridge shuttle valve selecting the higher pressure of two inputs.",
        ports: [
          { id: "A", x: -60, y: -18, kind: "hydraulic", required: !0 },
          { id: "B", x: -60, y: 18, kind: "hydraulic", required: !0 },
          { id: "X", x: 60, y: 0, kind: "hydraulic", required: !0 },
        ],
        defaults: { maxPressureBar: 315, maxFlowLpm: 40 },
        propSchema: [
          {
            key: "maxPressureBar",
            label: "Max pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "maxFlowLpm",
            label: "Max flow, L/min",
            type: "number",
            min: 0,
            step: 1,
          },
        ],
      },
      {
        type: "cartridgeManifoldBlock",
        category: "Valves",
        name: "Cartridge manifold block",
        prefix: "HIC",
        w: 164,
        h: 112,
        desc: "Manifold/HIC boundary for grouped screw-in and logic cartridge valves.",
        ports: [
          { id: "P", x: -82, y: -28, kind: "hydraulic", required: !1 },
          { id: "T", x: -82, y: 28, kind: "hydraulic", required: !1 },
          { id: "A", x: 82, y: -28, kind: "hydraulic", required: !1 },
          { id: "B", x: 82, y: 28, kind: "hydraulic", required: !1 },
        ],
        defaults: {
          cavityStandard: "ISO 7368 / common cavity",
          note: "Grouped cartridge manifold",
        },
        propSchema: [
          {
            key: "cavityStandard",
            label: "Cavity/standard note",
            type: "text",
          },
          { key: "note", label: "Manifold note", type: "text" },
        ],
      },
    ),
    [
      "pressureGauge",
      "pressureSwitch",
      "pressureTransducer",
      "reliefValve",
      "powerPack",
    ].forEach((e) =>
      c(e, { displayUnit: "bar" }, [
        {
          key: "displayUnit",
          label: "Display unit",
          type: "select",
          options: ["bar", "MPa", "psi"],
        },
      ]),
    ),
    ["flowMeter", "flowSwitch"].forEach((e) =>
      c(e, { displayUnit: "L/min" }, [
        {
          key: "displayUnit",
          label: "Display unit",
          type: "select",
          options: ["L/min", "L/s", "GPM"],
        },
      ]),
    ),
    ["temperatureSwitch"].forEach((e) =>
      c(e, { displayUnit: "°C" }, [
        {
          key: "displayUnit",
          label: "Display unit",
          type: "select",
          options: ["°C", "°F"],
        },
      ]),
    ),
    ["levelSwitch"].forEach((e) =>
      c(e, { displayUnit: "%" }, [
        {
          key: "displayUnit",
          label: "Display unit",
          type: "select",
          options: ["%"],
        },
      ]),
    ),
    [
      "limitSwitch",
      "cylinderReedSensor",
      "linearPositionSensor",
      "proximitySensor",
    ].forEach((e) =>
      c(e, { displayUnit: "%" }, [
        {
          key: "displayUnit",
          label: "Display unit",
          type: "select",
          options: ["%", "state"],
        },
      ]),
    ),
    ["cylinderDA", "cylinderSA"].forEach((e) =>
      c(e, { displayUnit: "position %" }, [
        {
          key: "displayUnit",
          label: "Display unit",
          type: "select",
          options: ["position %", "position mm", "speed mm/s", "force kN"],
        },
      ]),
    ),
    ["hydraulicMotor"].forEach((e) =>
      c(e, { displayUnit: "rpm" }, [
        {
          key: "displayUnit",
          label: "Display unit",
          type: "select",
          options: ["rpm", "rev/s"],
        },
      ]),
    ));
  const d = new Map(i.map((e) => [e.type, e])),
    p = {
      components: [],
      connections: [],
      selected: null,
      pendingPort: null,
      messages: [],
      inspectorTab: "properties",
      search: "",
      nextId: 1,
      exampleLevel: "Simple circuits",
      exampleIndex: 0,
      currentExampleGlobalIndex: null,
      user: e.user || null,
      accountToken: localStorage.getItem("rgzHydraulicAccountToken") || "",
      authMode: "signin",
      projectMeta: {
        projectName: "Untitled hydraulic circuit",
        designer: "",
        standard: "ISO-style / RGZ educational template",
        revision: "A",
        notes:
          "Simulation is approximate and intended for education/preliminary design.",
      },
      viewBox: { x: 0, y: 0, w: 1800, h: 1200 },
      printArea: null,
      printMode: "whole",
      drag: null,
      calc: {
        flowLpm: 25,
        lineType: "pressure",
        velocityMps: 4,
        diameterMm: 12,
        lengthM: 2,
        densityKgM3: 870,
        viscosityCSt: 46,
        fittingK: 2,
      },
      sim: {
        running: !1,
        time: 0,
        raf: null,
        last: 0,
        worker: null,
        workerBusy: !1,
        metrics: null,
        timeScale: 1,
        lastPanelRender: 0,
        lastCanvasRender: 0,
      },
    };
  let u, m, y, h, g, v, f, b, x, w;
  function k(e) {
    return JSON.parse(JSON.stringify(e));
  }
  function M(e) {
    return String(e ?? "").replace(
      /[&<>'"]/g,
      (e) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          "'": "&#39;",
          '"': "&quot;",
        })[e],
    );
  }
  function z(e, t, r) {
    return Math.max(t, Math.min(r, e));
  }
  function S(e, t = 20) {
    return Math.round(e / t) * t;
  }
  function P(e, t = 0) {
    const r = Number(e);
    return Number.isFinite(r) ? r : t;
  }
  function A(e, t = {}, r = []) {
    const n = document.createElementNS("http://www.w3.org/2000/svg", e);
    return (
      Object.entries(t).forEach(([e, t]) => {
        null != t && !1 !== t && n.setAttribute(e, String(t));
      }),
      (Array.isArray(r) ? r : [r]).forEach((e) => {
        "string" == typeof e
          ? n.appendChild(document.createTextNode(e))
          : e && n.appendChild(e);
      }),
      n
    );
  }
  function $(e) {
    return d.get(e);
  }
  function C(e) {
    const t = "string" == typeof e ? e : e?.type,
      r = $(t);
    return "directionalValve" === t || "directionalValve" === r?.baseType;
  }
  function L(e) {
    const t = Number(e.props.ports || 4),
      r = (2 === Number(e.props.positions || 3) ? 136 : 204) / 2 + 22;
    let n;
    return (
      (n =
        t <= 2
          ? [
              { id: "A", x: 0, y: -39, kind: "hydraulic", required: !0 },
              { id: "P", x: 0, y: 39, kind: "hydraulic", required: !0 },
            ]
          : 3 === t
            ? [
                { id: "A", x: 0, y: -39, kind: "hydraulic", required: !0 },
                { id: "P", x: -18, y: 39, kind: "hydraulic", required: !0 },
                { id: "T", x: 18, y: 39, kind: "hydraulic", required: !0 },
              ]
            : 5 === t
              ? [
                  { id: "A", x: -22, y: -39, kind: "hydraulic", required: !0 },
                  { id: "B", x: 22, y: -39, kind: "hydraulic", required: !0 },
                  { id: "R", x: -22, y: 39, kind: "hydraulic", required: !0 },
                  { id: "P", x: 0, y: 39, kind: "hydraulic", required: !0 },
                  { id: "S", x: 22, y: 39, kind: "hydraulic", required: !0 },
                ]
              : [
                  { id: "A", x: -18, y: -39, kind: "hydraulic", required: !0 },
                  { id: "B", x: 18, y: -39, kind: "hydraulic", required: !0 },
                  { id: "P", x: -18, y: 39, kind: "hydraulic", required: !0 },
                  { id: "T", x: 18, y: 39, kind: "hydraulic", required: !0 },
                ]),
      String(e.props.leftActuation || "").includes("pilot") &&
        n.push({ id: "X", x: -r, y: 0, kind: "pilot", required: !1 }),
      String(e.props.rightActuation || "").includes("pilot") &&
        n.push({ id: "Y", x: r, y: 0, kind: "pilot", required: !1 }),
      n
    );
  }
  function B(e) {
    const t = $(e.type);
    return t ? (C(e) ? L(e) : k(t.ports)) : [];
  }
  function T(e, t) {
    const r = p.components.find((t) => t.id === e);
    if (!r) return null;
    const n =
      B(r).find((e) => e.id === t) ||
      ($(r.type)?.ports || []).find((e) => e.id === t);
    if (!n) return null;
    const a = (function (e, t, r = 0) {
      const n = ((Number(r) || 0) * Math.PI) / 180,
        a = Math.cos(n),
        i = Math.sin(n);
      return { x: e * a - t * i, y: e * i + t * a };
    })(n.x, n.y, r.rotation || 0);
    return {
      x: r.x + a.x,
      y: r.y + a.y,
      kind: n.kind,
      component: r,
      port: n,
      vx: a.x,
      vy: a.y,
    };
  }
  function E(e, t, r, n = {}) {
    const a = $(e);
    if (!a) throw new Error(`Unknown component type: ${e}`);
    const i = p.nextId++,
      o = {
        id: `${a.prefix}-${i}`,
        type: e,
        label: `${a.prefix}${i}`,
        x: S(t),
        y: S(r),
        rotation: 0,
        props: k(a.defaults || {}),
      };
    return (
      Object.assign(o, n),
      (o.props = Object.assign(k(a.defaults || {}), n.props || {})),
      o
    );
  }
  function V(e, t, r, n, a = null, i = {}) {
    const o = T(e, t),
      s = T(r, n);
    let l = a;
    return (
      l ||
        (l =
          "electrical" === o?.kind || "electrical" === s?.kind
            ? "electrical"
            : "pilot" === o?.kind || "pilot" === s?.kind
              ? "pilot"
              : "pressure"),
      {
        id: `L-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`,
        from: { componentId: e, portId: t },
        to: { componentId: r, portId: n },
        lineType: l,
        properties: Object.assign(
          {
            tubeIdMm: 12,
            lengthM: 1,
            maxPressureBar: 250,
            color: "",
            strokeWidth: 3,
            routeMode: "auto",
            shift: 0,
          },
          i,
        ),
      }
    );
  }
  function q() {
    return {
      fileType: "rgz-hydraulic-project",
      formatVersion: 1,
      appVersion: t,
      createdBy: "RGZ Hydraulic Studio",
      website: r,
      exportedAt: new Date().toISOString(),
      metadata: k(p.projectMeta),
      viewBox: k(p.viewBox),
      printArea: k(p.printArea),
      components: k(p.components),
      connections: k(p.connections),
    };
  }
  function I(e, t = !1) {
    if (!e || !Array.isArray(e.components) || !Array.isArray(e.connections))
      return void lt(
        "This file does not look like an RGZ Hydraulic Studio project.",
        "error",
      );
    (Ie(),
      (p.components = k(e.components)),
      (p.connections = k(e.connections)),
      (p.projectMeta = Object.assign(p.projectMeta, k(e.metadata || {}))),
      (p.viewBox = Object.assign(
        { x: 0, y: 0, w: 1800, h: 1200 },
        k(e.viewBox || {}),
      )),
      (p.printArea = e.printArea ? k(e.printArea) : null));
    const r = p.components.reduce((e, t) => {
      const r = String(t.id).match(/\d+/g);
      return r ? Math.max(e, ...r.map(Number)) : e;
    }, 0);
    ((p.nextId = Math.max(r + 1, 1)),
      (p.selected = null),
      (p.pendingPort = null),
      R(),
      H(),
      ke(),
      Te(!1),
      t || lt("Project loaded successfully.", "ok"));
  }
  function R() {
    const e = p.viewBox;
    u.setAttribute("viewBox", `${e.x} ${e.y} ${e.w} ${e.h}`);
  }
  function F(e) {
    const t = u.createSVGPoint();
    return (
      (t.x = e.clientX),
      (t.y = e.clientY),
      t.matrixTransform(u.getScreenCTM().inverse())
    );
  }
  function D(e) {
    const t = F(e);
    ((p.drag = {
      kind: "pan",
      startClientX: e.clientX,
      startClientY: e.clientY,
      startViewBox: k(p.viewBox),
      start: t,
    }),
      u.classList.add("rgz-ctrl-pan"));
    try {
      u.setPointerCapture(e.pointerId);
    } catch (e) {}
    e.preventDefault();
  }
  function N(e) {
    const t = e.type || "",
      r = e.category || "Other";
    return e.subcategory
      ? e.subcategory
      : "Power" === r
        ? ["powerPack"].includes(t)
          ? "Power units / service units"
          : [
                "pumpFixed",
                "pumpVariable",
                "compressorFixed",
                "compressorVariable",
                "electricMotor",
              ].includes(t)
            ? "Sources and prime movers"
            : ["tank", "exhaust", "accumulator"].includes(t)
              ? "Reservoirs / receivers"
              : "Power accessories"
        : "Valves" === r
          ? t.includes("cartridge") || "logicCartridgeValve" === t
            ? "Cartridge / manifold valves"
            : C(t) || "servoValve" === t
              ? "Directional and proportional valves"
              : [
                    "reliefValve",
                    "sequenceValve",
                    "reducingValve",
                    "counterbalanceValve",
                    "pressureCompensator",
                    "softStartValve",
                  ].includes(t)
                ? "Pressure control valves"
                : [
                      "flowControl",
                      "flowDivider",
                      "quickExhaustValve",
                      "cartridgeNeedleFlowValve",
                    ].includes(t)
                  ? "Flow control valves"
                  : [
                        "checkValve",
                        "pilotCheckValve",
                        "shuttleValve",
                        "twoPressureValve",
                      ].includes(t)
                    ? "Check and logic valves"
                    : "Other valves"
          : "Actuators" === r
            ? ["cylinderDA", "cylinderSA"].includes(t)
              ? "Linear actuators / cylinders"
              : ["hydraulicMotor", "pneumaticMotor"].includes(t)
                ? "Rotary actuators / motors"
                : ["vacuumEjector", "suctionCup", "airBlowNozzle"].includes(t)
                  ? "Vacuum and air actuators"
                  : ["hydraulicIntensifier"].includes(t)
                    ? "Converters / intensifiers"
                    : "Other actuators"
            : "Conditioning" === r
              ? ["filter", "suctionStrainer", "frlUnit"].includes(t)
                ? "Filtration and air/oil preparation"
                : ["cooler", "oilHeater"].includes(t)
                  ? "Thermal conditioning"
                  : ["breatherFiller", "silencer"].includes(t)
                    ? "Accessories and exhaust"
                    : "Conditioning accessories"
              : "Measurement" === r
                ? ["pressureGauge", "flowMeter"].includes(t)
                  ? "Gauges and meters"
                  : [
                        "pressureSwitch",
                        "pressureTransducer",
                        "flowSwitch",
                        "temperatureSwitch",
                        "levelSwitch",
                      ].includes(t)
                    ? "Switches and transducers"
                    : ["testPoint"].includes(t)
                      ? "Diagnostics"
                      : "Measurement"
                : "Control" === r
                  ? [
                      "pushButton",
                      "solenoid",
                      "plc",
                      "electricalRelay",
                      "relayContact",
                      "timerRelay",
                      "emergencyStop",
                    ].includes(t)
                    ? "Electrical controls"
                    : [
                          "limitSwitch",
                          "cylinderReedSensor",
                          "linearPositionSensor",
                          "proximitySensor",
                        ].includes(t)
                      ? "Feedback sensors"
                      : [
                            "proportionalAmplifier",
                            "setpointPotentiometer",
                            "rampGenerator",
                          ].includes(t)
                        ? "Proportional control electronics"
                        : "Control elements"
                  : "Lines" === r
                    ? "Lines, junctions and connections"
                    : "Annotations" === r
                      ? "Text and notes"
                      : r;
  }

  const RgzIsoDraw = (function () {
    const D = (g, c, d, x) => g.append(A("path", Object.assign({ class: c, d: d }, x || {})));
    const ST = (g, d) => D(g, "symbol-stroke", d);
    const MU = (g, d) => D(g, "symbol-muted", d);
    const AC = (g, d) => D(g, "symbol-accent", d);
    const DA = (g, d) => D(g, "symbol-muted", d, { "stroke-dasharray": "6 5" });
    const SL = (g, d) => D(g, "symbol-solid", d);
    const TRI = SL;
    const CI = (g, cx, cy, r, c) => g.append(A("circle", { class: c || "symbol-fill", cx: cx, cy: cy, r: r }));
    const RC = (g, x, y, w, h, c, rx) => g.append(A("rect", { class: c || "symbol-fill", x: x, y: y, width: w, height: h, rx: rx || 0 }));
    const TX = (g, t2, x, y, s) => g.append(A("text", { class: "port-label", x: x, y: y, "text-anchor": "middle", "font-size": s || 12 }, t2));
    const ENV = (g, w, h) => D(g, "symbol-muted", "M" + (-w / 2) + " " + (-h / 2) + " H" + (w / 2) + " V" + (h / 2) + " H" + (-w / 2) + " Z", { "stroke-dasharray": "7 5" });
    const N = (v, d) => (Number.isFinite(Number(v)) ? Number(v) : d);
    const C01 = (v) => Math.max(0, Math.min(1, v));
    const SPR = (g, x1, y1, x2, y2, n, amp) => {
      n = n || 3; amp = amp || 6;
      const dx = x2 - x1, dy = y2 - y1, len = Math.hypot(dx, dy) || 1, ux = dx / len, uy = dy / len, px = -uy, py = ux;
      const lead = len * 0.12, bx = x1 + ux * lead, by = y1 + uy * lead, bl = len - 2 * lead, ex = x2 - ux * lead, ey = y2 - uy * lead;
      let d = "M" + x1 + " " + y1 + " L" + bx.toFixed(1) + " " + by.toFixed(1);
      for (let i = 1; i < 2 * n; i++) {
        const t = i / (2 * n), ax = bx + ux * bl * t, ay = by + uy * bl * t, s = i % 2 ? 1 : -1;
        d += " L" + (ax + s * px * amp).toFixed(1) + " " + (ay + s * py * amp).toFixed(1);
      }
      d += " L" + ex.toFixed(1) + " " + ey.toFixed(1) + " L" + x2 + " " + y2;
      D(g, "symbol-muted", d);
    };
    const ARR = (g, x1, y1, x2, y2, c, hgt) => {
      c = c || "symbol-accent"; hgt = hgt || 8;
      const a = Math.atan2(y2 - y1, x2 - x1), a1 = a + 2.55, a2 = a - 2.55;
      D(g, c, "M" + x1 + " " + y1 + " L" + x2 + " " + y2 + " M" + (x2 + hgt * Math.cos(a1)).toFixed(1) + " " + (y2 + hgt * Math.sin(a1)).toFixed(1) + " L" + x2 + " " + y2 + " L" + (x2 + hgt * Math.cos(a2)).toFixed(1) + " " + (y2 + hgt * Math.sin(a2)).toFixed(1));
    };
    return function (g, c, td) {
      const P = c.props || {};
      switch (c.type) {

      case "tank":
        ST(g, "M-40 -30 v44 h80 v-44");
        return true;
      case "pumpFixed":
        CI(g, 0, 0, 32);
        ST(g, "M-58 0h26M32 0h26");
        TRI(g, "M-8 -15 L-8 15 L17 0 Z");
        return true;
      case "pumpVariable":
        CI(g, 0, 0, 32);
        ST(g, "M-62 0h30M32 0h30");
        TRI(g, "M-8 -15 L-8 15 L17 0 Z");
        AC(g, "M-34 34 L34 -34 M21 -34h13v13");
        ST(g, "M14 -46 H40 V-30 H14 Z");
        AC(g, "M22 -33 L33 -42 M28.5 -42h4.5v4.5");
        DA(g, "M46 0 V-38 H40");
        return true;
      case "compressorFixed":
        CI(g, 0, 0, 32);
        ST(g, "M-58 0h26M32 0h26");
        TRI(g, "M-8 -15 L-8 15 L17 0 Z");
        return true;
      case "compressorVariable":
        CI(g, 0, 0, 32);
        ST(g, "M-62 0h30M32 0h30");
        TRI(g, "M-8 -15 L-8 15 L17 0 Z");
        AC(g, "M-34 34 L34 -34 M21 -34h13v13");
        ST(g, "M14 -46 H40 V-30 H14 Z");
        AC(g, "M22 -33 L33 -42 M28.5 -42h4.5v4.5");
        DA(g, "M46 0 V-38 H40");
        return true;
      case "powerPack":
        RC(g, -72, -45, 144, 90, "symbol-fill", 8);
        TX(g, "POWER PACK", 0, -28, 13);
        CI(g, -42, -4, 15);
        TRI(g, "M-46 3 L-46 -11 L-34 -4 Z");
        ST(g, "M-56 10 v18 h28 v-18");
        RC(g, -14, -14, 24, 24);
        AC(g, "M-8 6 L6 -10 M-1 -10h7v7");
        SPR(g, 10, 0, 24, 0, 3, 5);
        P.pressureGauge && (CI(g, 44, -8, 12, "symbol-muted"), MU(g, "M44 -8 l8 -8"));
        ST(g, "M36 -22h46M36 30h46");
        TX(g, "P", 57, -30);
        TX(g, "T", 57, 20);
        return true;
      case "reliefValve":
        RC(g, -22, -24, 44, 48);
        ST(g, "M-58 0h36M22 0h36");
        AC(g, "M-10 14 L10 -14 M2 -14h8v8");
        SPR(g, 22, 0, 38, 0, 3, 6);
        AC(g, "M24 10 L40 -10 M33 -10h7v7");
        DA(g, "M-44 0 V14 H-22");
        return true;
      case "sequenceValve":
        RC(g, -22, -24, 44, 48);
        ST(g, "M-58 0h36M22 0h36");
        AC(g, "M-10 14 L10 -14 M2 -14h8v8");
        SPR(g, 22, 0, 38, 0, 3, 6);
        AC(g, "M24 10 L40 -10 M33 -10h7v7");
        DA(g, "M-44 0 V14 H-22");
        DA(g, "M0 24 V46");
        return true;
      case "reducingValve":
        RC(g, -22, -24, 44, 48);
        ST(g, "M-58 0h36M22 0h36");
        AC(g, "M-14 0 H8 M8 -6 L18 0 L8 6");
        SPR(g, 22, 0, 38, 0, 3, 6);
        AC(g, "M24 10 L40 -10 M33 -10h7v7");
        DA(g, "M44 0 V20 H-10 V24");
        DA(g, "M0 24 V46");
        return true;
      case "counterbalanceValve":
        RC(g, -22, -24, 44, 48);
        ST(g, "M-60 0h38M22 0h38");
        AC(g, "M-10 14 L10 -14 M2 -14h8v8");
        SPR(g, 22, 0, 38, 0, 3, 6);
        AC(g, "M24 10 L40 -10 M33 -10h7v7");
        DA(g, "M0 -48 V-24");
        MU(g, "M-40 0 V34 H40 V0");
        ST(g, "M12 28 L12 40 L0 34 Z M-4 28 V40");
        return true;
      case "pressureCompensator":
        RC(g, -20, -22, 40, 44);
        ST(g, "M-56 0h36M20 0h36");
        AC(g, "M-12 0 H8 M8 -6 L18 0 L8 6");
        SPR(g, 20, 0, 34, 0, 3, 6);
        DA(g, "M-42 0 V14 H-20");
        TX(g, "\u0394p", 0, 34, 12);
        return true;
      case "flowControl":
        ST(g, "M-54 0h34M20 0h34");
        ST(g, "M-20 -16 Q-7 0 -20 16 M20 -16 Q7 0 20 16");
        AC(g, "M-32 26 L32 -26 M19 -26h13v13");
        P.pressureCompensated && MU(g, "M-10 30 q5 7 10 0 q5 -7 10 0");
        return true;
      case "checkValve":
        ST(g, "M-50 0h30M24 0h26");
        ST(g, "M-16 -18v36L18 0Z M21 -21v42");
        SPR(g, 2, -22, 2, -38, 3, 5);
        return true;
      case "pilotCheckValve":
        ST(g, "M-58 0h38M24 0h34");
        ST(g, "M-16 -18v36L18 0Z M21 -21v42");
        SPR(g, 2, -22, 2, -38, 3, 5);
        DA(g, "M0 -44 V-27");
        RC(g, -9, -27, 18, 5, "symbol-stroke");
        return true;
      case "shutoffValve":
        ST(g, "M-52 0h30M22 0h30");
        ST(g, "M-22 -14 L-22 14 L0 0 Z M22 -14 L22 14 L0 0 Z");
        return true;
      case "cylinderDA": {
        const r = C01(N(P.simPosition, 0.25)), n = 64 * r - 52, a = n + 126;
        RC(g, -78, -20, 110, 40);
        RC(g, n - 2, -20, 10, 40, "symbol-solid");
        ST(g, "M" + (n + 8).toFixed(1) + " 0 H" + a.toFixed(1));
        MU(g, "M" + a.toFixed(1) + " -12v24");
        ST(g, "M-82 34v-14M22 34v-14");
        return true;
      }
      case "cylinderSA": {
        const r = C01(N(P.simPosition, 0.15)), n = 52 * r - 48, a = n + 110;
        RC(g, -72, -20, 96, 40);
        RC(g, n - 2, -20, 10, 40, "symbol-solid");
        ST(g, "M" + (n + 8).toFixed(1) + " 0 H" + a.toFixed(1));
        MU(g, "M" + a.toFixed(1) + " -12v24");
        SPR(g, n + 14, 0, 18, 0, 3, 7);
        ST(g, "M-76 34v-14");
        return true;
      }
      case "hydraulicMotor": {
        const an = N(P.simAngle, 0);
        CI(g, 0, 0, 32);
        ST(g, "M-58 0h26M32 0h26");
        TRI(g, "M-24 -13 L-24 13 L-6 0 Z");
        AC(g, "M0 0 L" + (18 * Math.cos(an)).toFixed(1) + " " + (18 * Math.sin(an)).toFixed(1) + " M0 0 L" + (18 * Math.cos(an + Math.PI)).toFixed(1) + " " + (18 * Math.sin(an + Math.PI)).toFixed(1));
        return true;
      }
      case "pneumaticMotor": {
        const an = N(P.simAngle, 0);
        CI(g, 0, 0, 32);
        ST(g, "M-58 0h26M32 0h26");
        TRI(g, "M-24 -13 L-24 13 L-6 0 Z");
        AC(g, "M0 0 L" + (18 * Math.cos(an)).toFixed(1) + " " + (18 * Math.sin(an)).toFixed(1) + " M0 0 L" + (18 * Math.cos(an + Math.PI)).toFixed(1) + " " + (18 * Math.sin(an + Math.PI)).toFixed(1));
        return true;
      }
      case "accumulator":
        CI(g, 0, -8, 30);
        MU(g, "M-25 -10 Q0 8 25 -10");
        ST(g, "M0 22 V52");
        CI(g, 0, -38, 2.5, "symbol-solid");
        return true;
      case "flowDivider":
        RC(g, -36, -28, 72, 56);
        ST(g, "M-56 -10h20M36 -10h20M0 50V28");
        AC(g, "M0 22 V0 M0 0 L-18 -16 M-18 -16 L-24 -9 M-18 -16 L-11 -14 M0 0 L18 -16 M18 -16 L24 -9 M18 -16 L11 -14");
        return true;
      case "flowMeter":
        CI(g, 0, 0, 24);
        ST(g, "M-54 0h30M24 0h30");
        ST(g, "M-8 -12 Q16 0 -8 12 M-8 -12 Q-2 0 -8 12");
        return true;
      case "flowSwitch":
        CI(g, 0, 0, 22);
        ST(g, "M-58 0h36M22 0h36");
        ST(g, "M-7 -11 Q14 0 -7 11 M-7 -11 Q-2 0 -7 11");
        ST(g, "M0 -22 V-42");
        return true;
      case "filter":
        ST(g, "M-52 0h22M30 0h22");
        D(g, "symbol-fill", "M-30 0 L0 -26 L30 0 L0 26 Z");
        DA(g, "M0 -26 V26");
        return true;
      case "suctionStrainer":
        ST(g, "M-52 0h28M24 0h28");
        D(g, "symbol-fill", "M-24 0 L0 -22 L24 0 L0 22 Z");
        DA(g, "M0 -22 V22");
        return true;
      case "cooler":
        RC(g, -24, -24, 48, 48);
        ST(g, "M-56 0h32M24 0h32");
        ST(g, "M-24 0 H24");
        ST(g, "M-8 8 V-32 M-13 -25 L-8 -33 L-3 -25 M8 8 V-32 M3 -25 L8 -33 L13 -25");
        return true;
      case "oilHeater":
        RC(g, -24, -24, 48, 48);
        ST(g, "M-52 0h28M24 0h28");
        ST(g, "M-24 0 H24");
        ST(g, "M-8 26 V2 M-14 9 L-8 1 L-2 9 M8 26 V2 M2 9 L8 1 L14 9");
        return true;
      case "breatherFiller":
        ST(g, "M0 36 V6");
        RC(g, -16, -22, 32, 28);
        DA(g, "M-10 -14h20");
        DA(g, "M-10 -6h20");
        DA(g, "M-10 2h20");
        return true;
      case "blindPlug":
        ST(g, "M-26 0h16");
        RC(g, -10, -12, 16, 24);
        ST(g, "M-10 -12 L6 12 M6 -12 L-10 12");
        return true;
      case "junction":
        CI(g, 0, 0, 5, "symbol-solid");
        ST(g, "M-26 0h21M5 0h21M0 -26v21M0 5v21");
        return true;
      case "pressureGauge":
        CI(g, 0, -6, 26);
        ST(g, "M0 46 V20");
        ARR(g, 0, -6, 15, -21);
        return true;
      case "pressureSwitch":
        CI(g, 0, -4, 24);
        ST(g, "M0 46 V20");
        ARR(g, 0, -4, 13, -18);
        MU(g, "M22 -24h8");
        ST(g, "M30 -24 L43 -30");
        MU(g, "M43 -24h7");
        ST(g, "M26 -21v-6M46 -21v-6");
        DA(g, "M16 -8 L26 -24");
        return true;
      case "pressureTransducer":
        CI(g, 0, -4, 24);
        ST(g, "M0 46 V20");
        ARR(g, 0, -4, 13, -18);
        ST(g, "M23 -10 L52 -18");
        return true;
      case "temperatureSwitch":
        CI(g, 0, -6, 22);
        ST(g, "M0 44 V16");
        CI(g, 0, 16, 4, "symbol-solid");
        ARR(g, 0, -6, 12, -20);
        MU(g, "M22 -18h8");
        ST(g, "M30 -18 L43 -24");
        MU(g, "M43 -18h7");
        ST(g, "M26 -15v-6M46 -15v-6");
        DA(g, "M15 -12 L26 -18");
        return true;
      case "levelSwitch":
        MU(g, "M-52 0h20M32 0h20");
        ST(g, "M-32 0 L14 -14");
        CI(g, 21, -16, 7, "symbol-stroke");
        MU(g, "M-36 -5v10");
        return true;

      case "cartridgeCheckValve":
        MU(g, "M-58 0h24M34 0h24");
        SL(g, "M-26 0 L10 -14 L10 14 Z"); // filled poppet wedge seated on the cavity seat
        ST(g, "M10 -15 V15");
        
        ST(g, "M-34 0 H-26 M10 0 H16");
        SPR(g, 16, 0, 34, 0, 3, 5);
        return true;
      case "cartridgeReliefValve":
        MU(g, "M-60 0h26M34 0h26");
        D(g, "symbol-muted", "M-36 -22 H22 V22 H-36 Z", { "stroke-dasharray": "6 5" });
        SL(g, "M-26 0 L10 -14 L10 14 Z"); // filled poppet wedge seated on the cavity seat
        ST(g, "M10 -15 V15");
        
        ST(g, "M-34 0 H-26 M10 0 H34");
        RC(g, -22, -42, 44, 26);
        SPR(g, 0, -38, 0, -20, 3, 4.5);
        MU(g, "M-9 -18 L9 -40 M9 -40 l-3.6 0.8 M9 -40 l-0.8 3.6");
        DA(g, "M-34 0 V-26 H-22");
        return true;
      case "cartridgeReducingValve":
        MU(g, "M-60 0h26M34 0h26");
        D(g, "symbol-muted", "M-36 -22 H22 V22 H-36 Z", { "stroke-dasharray": "6 5" });
        SL(g, "M-26 0 L10 -14 L10 14 Z"); // filled poppet wedge seated on the cavity seat
        ST(g, "M10 -15 V15");
        
        ST(g, "M-34 0 H-26 M10 0 H34");
        RC(g, -22, -42, 44, 26);
        SPR(g, 0, -38, 0, -20, 3, 4.5);
        MU(g, "M-9 -18 L9 -40 M9 -40 l-3.6 0.8 M9 -40 l-0.8 3.6");
        DA(g, "M34 0 V-26 H22");
        DA(g, "M18 -16 V44");
        return true;
      case "cartridgeSequenceValve":
        MU(g, "M-60 0h26M34 0h26");
        D(g, "symbol-muted", "M-36 -22 H22 V22 H-36 Z", { "stroke-dasharray": "6 5" });
        SL(g, "M-26 0 L10 -14 L10 14 Z"); // filled poppet wedge seated on the cavity seat
        ST(g, "M10 -15 V15");
        
        ST(g, "M-34 0 H-26 M10 0 H34");
        RC(g, -22, -42, 44, 26);
        SPR(g, 0, -38, 0, -20, 3, 4.5);
        MU(g, "M-9 -18 L9 -40 M9 -40 l-3.6 0.8 M9 -40 l-0.8 3.6");
        DA(g, "M-34 0 V-26 H-22");
        DA(g, "M18 -16 V44");
        return true;
      case "cartridgeUnloadingValve":
        MU(g, "M-60 0h26M34 0h26");
        D(g, "symbol-muted", "M-36 -22 H22 V22 H-36 Z", { "stroke-dasharray": "6 5" });
        SL(g, "M-26 0 L10 -14 L10 14 Z"); // filled poppet wedge seated on the cavity seat
        ST(g, "M10 -15 V15");
        
        ST(g, "M-34 0 H-26 M10 0 H34");
        RC(g, -22, -42, 44, 26);
        SPR(g, 0, -38, 0, -20, 3, 4.5);
        MU(g, "M-9 -18 L9 -40 M9 -40 l-3.6 0.8 M9 -40 l-0.8 3.6");
        DA(g, "M0 -56 V-42");
        return true;
      case "cartridgeCounterbalanceValve":
        MU(g, "M-66 0h32M34 0h32");
        D(g, "symbol-muted", "M-36 -22 H22 V22 H-36 Z", { "stroke-dasharray": "6 5" });
        SL(g, "M-26 0 L10 -14 L10 14 Z"); // filled poppet wedge seated on the cavity seat
        ST(g, "M10 -15 V15");
        
        ST(g, "M-34 0 H-26 M10 0 H34");
        RC(g, -22, -42, 44, 26);
        SPR(g, 0, -38, 0, -20, 3, 4.5);
        MU(g, "M-9 -18 L9 -40 M9 -40 l-3.6 0.8 M9 -40 l-0.8 3.6");
        DA(g, "M0 -56 V-42");
        MU(g, "M-52 0 V32 H52 V0");
        SL(g, "M10 25 L10 39 L-2 32 Z");
        MU(g, "M-7 24 V40");
        return true;
      case "cartridgeNeedleFlowValve":
        MU(g, "M-58 0h12M46 0h12");
        ST(g, "M-14 -13 Q-5 0 -14 13 M14 -13 Q5 0 14 13");
        AC(g, "M-24 18 L24 -18 M14 -18h10v10");
        return true;
      case "cartridgeSolenoidValve22":
        MU(g, "M-60 0h26M34 0h26");
        D(g, "symbol-muted", "M-36 -22 H22 V22 H-36 Z", { "stroke-dasharray": "6 5" });
        SL(g, "M-26 0 L10 -14 L10 14 Z"); // filled poppet wedge seated on the cavity seat
        ST(g, "M10 -15 V15");
        
        ST(g, "M-34 0 H-26 M10 0 H34");
        RC(g, -38, -44, 16, 16, "symbol-stroke");
        MU(g, "M-38 -44 L-22 -28");
        ST(g, "M-30 -28 L-27 -3");
        MU(g, "M0 -44 H-30");
        ST(g, "M16 -15 V-20");
        SPR(g, 16, -20, 16, -38, 3, 4);
        MU(g, "M10 -38 H22");
        return true;
      case "cartridgeShuttleValve":
        ST(g, "M-60 -18 H-22 V-8 M-60 18 H-22 V8");
        RC(g, -22, -16, 44, 32);
        ST(g, "M-12 -8 L-4 0 L-12 8 M12 -8 L4 0 L12 8");
        CI(g, 0, 0, 5, "symbol-stroke");
        ST(g, "M5 0 H60");
        return true;
      case "logicCartridgeValve":
        // DIN 24342 / ISO 1219 slip-in logic element: poppet on its seat inside
        // the cavity square, closing spring behind the poppet base, dashed
        // control cover on top fed from pilot port X (X pressurised = closed).
        MU(g, "M-56 0h30M26 0h30");
        RC(g, -26, -20, 52, 40, "symbol-stroke");
        ST(g, "M-22 -16 V16");
        SL(g, "M6 -13 L6 13 L-18 0 Z");
        SPR(g, 8, 0, 21, 0, 3, 5);
        D(g, "symbol-muted", "M-16 -40 H16 V-24 H-16 Z", { "stroke-dasharray": "6 4" });
        DA(g, "M0 -42 V-40 M0 -24 V-10");
        return true;
      case "hydraulicIntensifier":
        RC(g, -46, -20, 42, 40);
        RC(g, -26, -20, 10, 40, "symbol-solid");
        RC(g, -4, -10, 40, 20);
        RC(g, 4, -10, 8, 20, "symbol-solid");
        ST(g, "M-16 0 H8");
        ST(g, "M12 0 H36");
        ST(g, "M-62 0h16M36 0h26");
        ST(g, "M0 44 V10");
        return true;

      }
      return false;
    };
  })();

  function j() {
    const e = p.search.trim().toLowerCase();
    ((v.innerHTML = ""),
      a.forEach((t) => {
        const r = i
          .filter((e) => e.category === t)
          .filter(
            (t) =>
              !e ||
              `${t.name} ${t.desc} ${t.type} ${N(t)}`.toLowerCase().includes(e),
          );
        if (!r.length) return;
        const n = document.createElement("details");
        ((n.className = "rgz-category"),
          (n.open = !!e),
          (n.innerHTML = `<summary>${M(t)} <span class="rgz-subcount">${r.length}</span></summary><div class="rgz-subcategory-wrap"></div>`));
        const a = n.querySelector(".rgz-subcategory-wrap"),
          o = new Map();
        (r.forEach((e) => {
          const t = N(e);
          (o.has(t) || o.set(t, []), o.get(t).push(e));
        }),
          o.forEach((t, r) => {
            const n = document.createElement("details");
            ((n.className = "rgz-subcategory"),
              (n.open = !!e),
              (n.innerHTML = `<summary>${M(r)} <span class="rgz-subcount">${t.length}</span></summary><div class="rgz-symbol-list"></div>`));
            const i = n.querySelector(".rgz-symbol-list");
            (t.forEach((e) =>
              i.appendChild(
                (function (e) {
                  const t = document.createElement("div");
                  return (
                    (t.className = "rgz-symbol-card"),
                    (t.draggable = !0),
                    (t.dataset.type = e.type),
                    (t.innerHTML = `\n      <div class="rgz-symbol-icon">${(function (
                      e,
                    ) {
                      const t =
                        'stroke="#f8fafc" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"';
                      if (C(e))
                        return `<svg viewBox="-78 -46 156 92"><rect ${t} x="-54" y="-25" width="108" height="50"/><path ${t} d="M-18-25v50M18-25v50M-43 12L-23-12M-28-12h8v8M-8 0h16M23-12L43 12M38-12h8v8"/></svg>`;
                      switch (e) {
                        case "powerPack":
                          return `<svg viewBox="-80 -50 160 100"><rect ${t} x="-56" y="-34" width="112" height="68" rx="7"/><circle ${t} cx="-24" cy="0" r="16"/><path d="M-30 -8 L-30 8 L-14 0 Z" fill="#f8fafc" stroke="none"/><path ${t} d="M-2 -16 v32 M10 -16 v32 M-56 26h112"/></svg>`;
                        case "tank":
                          return `<svg viewBox="-60 -44 120 88"><path ${t} d="M-34 -22 v36 h68 v-36"/></svg>`;
                        case "pumpFixed":
                          return `<svg viewBox="-60 -40 120 80"><circle ${t} cx="0" cy="0" r="25"/><path ${t} d="M-50 0h25M25 0h50"/><path d="M-7 -11 L-7 11 L13 0 Z" fill="#f8fafc" stroke="none"/></svg>`;
                        case "directionalValve":
                          return `<svg viewBox="-70 -44 140 88"><rect ${t} x="-48" y="-25" width="96" height="50"/><path ${t} d="M-16-25v50M16-25v50M-38 8h24l-8-8M-8-8h24l-8 8M18 8h24l-8-8"/></svg>`;
                        case "cylinderDA":
                          return `<svg viewBox="-80 -40 160 80"><rect ${t} x="-62" y="-16" width="86" height="32"/><rect x="-30" y="-16" width="9" height="32" fill="#f8fafc" stroke="none"/><path ${t} d="M-21 0h65 M44 -8v16 M-42 16v14M16 16v14"/></svg>`;
                        case "cylinderSA":
                          return `<svg viewBox="-80 -40 160 80"><rect ${t} x="-58" y="-16" width="78" height="32"/><rect x="-36" y="-16" width="9" height="32" fill="#f8fafc" stroke="none"/><path ${t} d="M-27 0h53 M-14 0 l3 -6 l3 12 l3 -12 l3 6 M-38 16v14"/></svg>`;
                        case "pressureGauge":
                          return `<svg viewBox="-50 -45 100 90"><circle ${t} cx="0" cy="-5" r="27"/><path ${t} d="M0 22v22 M-6 5 L14 -18 M14 -18 L7 -17 M14 -18 L13 -11"/></svg>`;
                        case "filter":
                          return `<svg viewBox="-60 -40 120 80"><path ${t} d="M-50 0h20M30 0h20M-30 0 L0 -25 L30 0 L0 25 Z"/><path ${t} d="M0 -25 V25" stroke-dasharray="5 4"/></svg>`;
                        case "reliefValve":
                          return `<svg viewBox="-65 -40 130 80"><rect ${t} x="-20" y="-22" width="40" height="44"/><path ${t} d="M-56 0h36M20 0h36 M-9 11 L9 -11 M3 -11h6v6 M20 0 l4 -6 l4 12 l4 -12 l4 6"/><path ${t} d="M-44 0 V12 H-20" stroke-dasharray="5 4"/></svg>`;
                        case "flowControl":
                          return `<svg viewBox="-60 -40 120 80"><path ${t} d="M-52 0h32M20 0h32 M-20 -15 Q-7 0 -20 15 M20 -15 Q7 0 20 15 M-28 22 L28 -22 M18 -22h10v10"/></svg>`;
                        case "checkValve":
                          return `<svg viewBox="-60 -40 120 80"><path ${t} d="M-50 0h30M24 0h26 M-16 -18v36L18 0Z M21 -21v42"/><path ${t} d="M2 -21 l3 -5 l3 8 l3 -8 l3 5"/></svg>`;
                        case "hydraulicMotor":
                          return `<svg viewBox="-60 -40 120 80"><circle ${t} cx="0" cy="0" r="25"/><path ${t} d="M-55 0h30M25 0h30"/><path d="M-20 -11 L-20 11 L-5 0 Z" fill="#f8fafc" stroke="none"/></svg>`;
                        case "pushButton":
                          return `<svg viewBox="-60 -40 120 80"><path ${t} d="M-50 0h26M22 0h28M-22-18v36M-22 0l32-18"/><circle ${t} cx="12" cy="-22" r="7"/></svg>`;
                        case "textLabel":
                          return `<svg viewBox="-70 -42 140 84"><rect ${t} x="-48" y="-25" width="96" height="50" rx="6"/><path ${t} d="M-30 -6h60M-30 10h42"/><text x="0" y="-10" fill="#f8fafc" font-size="18" font-weight="800" text-anchor="middle">T</text></svg>`;
                                                case "accumulator":
                          return `<svg viewBox="-50 -50 100 100"><circle ${t} cx="0" cy="-6" r="27"/><path ${t} d="M-21 -12 Q0 4 21 -12 M0 21 V44"/></svg>`;
                        case "cooler":
                          return `<svg viewBox="-60 -44 120 88"><rect ${t} x="-22" y="-22" width="44" height="44"/><path ${t} d="M-48 0h26M22 0h26M-22 0H22 M-7 6 V-28 M-12 -21 L-7 -29 L-2 -21 M7 6 V-28 M2 -21 L7 -29 L12 -21"/></svg>`;
                        case "pilotCheckValve":
                          return `<svg viewBox="-64 -44 128 88"><path ${t} d="M-54 0h34M24 0h30 M-16 -18v36L18 0Z M21 -21v42"/><path ${t} d="M2 -21 l3 -5 l3 8 l3 -8 l3 5"/><path ${t} d="M0 -42 V-27" stroke-dasharray="5 4"/><rect ${t} x="-8" y="-27" width="16" height="5"/></svg>`;
                        case "counterbalanceValve":
                          return `<svg viewBox="-70 -48 140 96"><rect ${t} x="-20" y="-22" width="40" height="44"/><path ${t} d="M-60 0h40M20 0h40 M-9 11 L9 -11 M3 -11h6v6 M20 0 l4 -6 l4 12 l4 -12 l4 6"/><path ${t} d="M0 -46 V-22 M-38 0 V32 H38 V0" stroke-dasharray="5 4"/><path ${t} d="M-38 0 V32 H38 V0 M0 26 L0 38 L12 32 Z M16 26 V38"/></svg>`;
                        case "shutoffValve":
                          return `<svg viewBox="-60 -40 120 80"><path ${t} d="M-52 0h30M22 0h30 M-22 -14 L-22 14 L0 0 Z M22 -14 L22 14 L0 0 Z"/></svg>`;
                        case "flowMeter":
                          return `<svg viewBox="-56 -40 112 80"><circle ${t} cx="0" cy="0" r="24"/><path ${t} d="M-54 0h30M24 0h30 M-8 -12 Q16 0 -8 12 M-8 -12 Q-2 0 -8 12"/></svg>`;
                        case "sequenceValve":
                          return `<svg viewBox="-65 -46 130 92"><rect ${t} x="-20" y="-22" width="40" height="44"/><path ${t} d="M-56 0h36M20 0h36 M-9 11 L9 -11 M3 -11h6v6 M20 0 l4 -6 l4 12 l4 -12 l4 6"/><path ${t} d="M-44 0 V12 H-20 M0 22 V44" stroke-dasharray="5 4"/></svg>`;
                        case "reducingValve":
                          return `<svg viewBox="-65 -46 130 92"><rect ${t} x="-20" y="-22" width="40" height="44"/><path ${t} d="M-56 0h36M20 0h36 M-12 0 H8 M8 -6 L18 0 L8 6 M20 0 l4 -6 l4 12 l4 -12 l4 6"/><path ${t} d="M40 0 V30 H-10 V22 M0 22 V44" stroke-dasharray="5 4"/></svg>`;
                        case "breatherFiller":
                          return `<svg viewBox="-46 -44 92 88"><path ${t} d="M0 40 V6"/><rect ${t} x="-16" y="-22" width="32" height="28"/><path ${t} d="M-10 -14h20M-10 -6h20M-10 2h20" stroke-dasharray="4 3"/></svg>`;
                        case "cartridgeCheckValve":
                          return `<svg viewBox="-72 -34 144 68"><path ${t} d="M-58 0h24M34 0h24M-34 0h8M16 0 l2 4 l3.5 -8 l3.5 8 l3.5 -8 l3.5 8 l2.5 -4 M-26 0 L10 -14 M-26 0 L10 14 M10 -15 V15 M10 0h6"/></svg>`;
                        case "logicCartridgeValve":
                          return `<svg viewBox="-66 -50 132 92"><rect ${t} x="-26" y="-20" width="52" height="40"/><path ${t} d="M-56 0h30M26 0h30M-22 -16 V16 M6 -13 L6 13 L-18 0 Z M8 0 l2.5 4 l4.5 -8 l4.5 8 l4.5 -8 l2.5 4"/><rect ${t} x="-16" y="-40" width="32" height="16" stroke-dasharray="6 4"/><path ${t} d="M0 -44 V-40 M0 -24 V-10" stroke-dasharray="5 4"/></svg>`;
                        case "cartridgeReliefValve":
                          return `<svg viewBox="-72 -58 144 112"><rect ${t} x="-36" y="-22" width="58" height="44" stroke-dasharray="6 5"/><rect ${t} x="-22" y="-42" width="44" height="26"/><path ${t} d="M-56 0h22M34 0h22M-34 0h8M10 0h26M-26 0 L10 -14 M-26 0 L10 14 M10 -15 V15 M0 -36 l4 3 l-8 6 l8 6 l-8 6 l4 3 M-9 -18 L9 -40"/><path ${t} d="M-34 0 V-26 H-22" stroke-dasharray="5 4"/></svg>`;
                        case "cartridgeReducingValve":
                          return `<svg viewBox="-72 -58 144 112"><rect ${t} x="-36" y="-22" width="58" height="44" stroke-dasharray="6 5"/><rect ${t} x="-22" y="-42" width="44" height="26"/><path ${t} d="M-56 0h22M34 0h22M-34 0h8M10 0h24M-26 0 L10 -14 M-26 0 L10 14 M10 -15 V15 M0 -36 l4 3 l-8 6 l8 6 l-8 6 l4 3 M-9 -18 L9 -40"/><path ${t} d="M34 0 V-26 H22 M18 -16 V44" stroke-dasharray="5 4"/></svg>`;
                        case "cartridgeSequenceValve":
                          return `<svg viewBox="-72 -58 144 112"><rect ${t} x="-36" y="-22" width="58" height="44" stroke-dasharray="6 5"/><rect ${t} x="-22" y="-42" width="44" height="26"/><path ${t} d="M-56 0h22M34 0h22M-34 0h8M10 0h24M-26 0 L10 -14 M-26 0 L10 14 M10 -15 V15 M0 -36 l4 3 l-8 6 l8 6 l-8 6 l4 3 M-9 -18 L9 -40"/><path ${t} d="M-34 0 V-26 H-22 M18 -16 V44" stroke-dasharray="5 4"/></svg>`;
                        case "cartridgeUnloadingValve":
                          return `<svg viewBox="-72 -62 144 116"><rect ${t} x="-36" y="-22" width="58" height="44" stroke-dasharray="6 5"/><rect ${t} x="-22" y="-42" width="44" height="26"/><path ${t} d="M-56 0h22M34 0h22M-34 0h8M10 0h24M-26 0 L10 -14 M-26 0 L10 14 M10 -15 V15 M0 -36 l4 3 l-8 6 l8 6 l-8 6 l4 3 M-9 -18 L9 -40"/><path ${t} d="M0 -56 V-42" stroke-dasharray="5 4"/></svg>`;
                        case "cartridgeCounterbalanceValve":
                          return `<svg viewBox="-76 -62 152 116"><rect ${t} x="-36" y="-22" width="58" height="44" stroke-dasharray="6 5"/><rect ${t} x="-22" y="-42" width="44" height="26"/><path ${t} d="M-66 0h32M34 0h32M-34 0h8M10 0h24 M-26 0 L10 -14 M-26 0 L10 14 M10 -15 V15 M0 -36 l4 3 l-8 6 l8 6 l-8 6 l4 3 M-48 0 V30 H48 V0"/><path ${t} d="M0 -56 V-42" stroke-dasharray="5 4"/><path d="M8 23 L8 39 L-4 31 Z" fill="#f8fafc" stroke="none"/><path ${t} d="M-9 22 V40"/></svg>`;
                        case "cartridgeNeedleFlowValve":
                          return `<svg viewBox="-64 -34 128 68"><path ${t} d="M-58 0h12M46 0h12 M-14 -13 Q-5 0 -14 13 M14 -13 Q5 0 14 13 M-24 18 L24 -18 M14 -18h10v10"/></svg>`;
                        case "cartridgeSolenoidValve22":
                          return `<svg viewBox="-72 -58 144 112"><rect ${t} x="-36" y="-22" width="58" height="44" stroke-dasharray="6 5"/><rect ${t} x="-38" y="-44" width="16" height="16"/><path ${t} d="M-38 -44 L-22 -28 M-30 -28 L-27 -3 M0 -44 H-30 M-56 0h22M34 0h22M-34 0h8M10 0h24M-26 0 L10 -14 M-26 0 L10 14 M10 -15 V15 M16 -15 V-20 l4 -3 l-8 -6 l8 -6 l-8 -6 l4 -3 M11 -40 H21"/></svg>`;
                        case "cartridgeShuttleValve":
                          return `<svg viewBox="-70 -34 140 68"><rect ${t} x="-22" y="-16" width="44" height="32"/><path ${t} d="M-60 -18 H-22 V-8 M-60 18 H-22 V8 M5 0 H60 M-12 -8 L-4 0 L-12 8 M12 -8 L4 0 L12 8"/><circle ${t} cx="0" cy="0" r="5"/></svg>`;
                        case "cartridgeManifoldBlock":
                          return `<svg viewBox="-70 -40 140 80"><rect ${t} x="-50" y="-26" width="100" height="52" stroke-dasharray="7 5"/><path ${t} d="M-64 0h14M50 0h14 M-30 -8h24M-30 8h18"/></svg>`;
default:
                          return `<svg viewBox="-60 -40 120 80"><rect ${t} x="-32" y="-22" width="64" height="44"/><path ${t} d="M-52 0h20M32 0h20"/></svg>`;
                      }
                    })(
                      e.type,
                    )}</div>\n      <div><div class="rgz-symbol-name">${M(e.name)}</div><div class="rgz-symbol-desc">${M(e.desc)}</div></div>\n    `),
                    t.addEventListener("dragstart", (t) => {
                      (t.dataTransfer.setData(
                        "application/rgz-component",
                        e.type,
                      ),
                        (t.dataTransfer.effectAllowed = "copy"));
                    }),
                    t.addEventListener("dblclick", () =>
                      O(
                        e.type,
                        p.viewBox.x + 0.5 * p.viewBox.w,
                        p.viewBox.y + 0.5 * p.viewBox.h,
                      ),
                    ),
                    t
                  );
                })(e),
              ),
            ),
              a.appendChild(n));
          }),
          v.appendChild(n));
      }));
  }
  function O(e, t, r) {
    const n = E(e, t, r);
    (p.components.push(n),
      (p.selected = { kind: "component", id: n.id }),
      H(),
      ke(),
      lt(`${$(e).name} added.`, "ok"));
  }
  function H() {
    ((m.innerHTML = ""),
      (y.innerHTML = ""),
      (h.innerHTML = ""),
      (function () {
        if (!p.printArea || !m) return;
        const e = p.printArea;
        (m.appendChild(
          A("rect", {
            class: "rgz-print-area-rect",
            x: e.x,
            y: e.y,
            width: e.w,
            height: e.h,
            rx: 10,
          }),
        ),
          m.appendChild(
            A(
              "text",
              { class: "rgz-print-area-label", x: e.x + 12, y: e.y + 24 },
              "PRINT AREA",
            ),
          ));
      })());
    const e = (function () {
      const e = new Set();
      if (!p.sim.running) return e;
      if (p.sim.metrics && Array.isArray(p.sim.metrics.lines))
        return (
          p.sim.metrics.lines.forEach((t) => {
            (t.high || P(t.pressureBar, 0) > 5) && e.add(t.id);
          }),
          e
        );
      if (P(p.sim.metrics?.pressureBar, 0) <= 1) return e;
      const t = new Map(),
        r = (e, r, n = null) => {
          e &&
            r &&
            (t.has(e) || t.set(e, []),
            t.has(r) || t.set(r, []),
            t.get(e).push({ node: r, connId: n }),
            t.get(r).push({ node: e, connId: n }));
        },
        n = (e, t) => `${e}.${t}`;
      p.connections.forEach((e) => {
        "electrical" !== e.lineType &&
          r(
            n(e.from.componentId, e.from.portId),
            n(e.to.componentId, e.to.portId),
            e.id,
          );
      });
      const a = [],
        i = (e, t) => t.forEach((t) => r(n(e.id, t[0]), n(e.id, t[1]), null));
      p.components.forEach((e) => {
        if (
          (("pumpFixed" !== e.type &&
            "pumpVariable" !== e.type &&
            "powerPack" !== e.type) ||
            a.push(n(e.id, "P")),
          C(e))
        ) {
          const t = e.props.spoolState || "center",
            r = e.props.center || "closed";
          ("left" === t && i(e, [["P", "A"]]),
            "right" === t && i(e, [["P", "B"]]),
            "center" === t &&
              "regenerative" === r &&
              i(e, [
                ["P", "A"],
                ["P", "B"],
              ]));
        }
        if (
          ([
            "flowControl",
            "checkValve",
            "pilotCheckValve",
            "counterbalanceValve",
            "flowMeter",
            "filter",
            "cooler",
            "suctionStrainer",
            "shutoffValve",
            "pressureCompensator",
            "logicCartridgeValve",
            "oilHeater",
            "cartridgeCheckValve",
            "cartridgeCounterbalanceValve",
            "cartridgeNeedleFlowValve",
            "cartridgeSolenoidValve22",
          ].includes(e.type) && i(e, [["A", "B"]]),
          [
            "sequenceValve",
            "reducingValve",
            "cartridgeReducingValve",
            "cartridgeSequenceValve",
          ].includes(e.type) && i(e, [["P", "A"]]),
          ["cartridgeReliefValve", "cartridgeUnloadingValve"].includes(
            e.type,
          ) && i(e, [["P", "T"]]),
          "cartridgeShuttleValve" === e.type &&
            i(e, [
              ["A", "X"],
              ["B", "X"],
            ]),
          "junction" === e.type)
        ) {
          const t = B(e).map((e) => e.id);
          t.forEach((a, i) =>
            t.slice(i + 1).forEach((t) => r(n(e.id, a), n(e.id, t), null)),
          );
        }
        ("flowDivider" === e.type &&
          i(e, [
            ["P", "A"],
            ["P", "B"],
          ]),
          "accumulator" === e.type ||
            "pressureGauge" === e.type ||
            "pressureSwitch" === e.type ||
            e.type);
      });
      const o = new Set(a),
        s = [...a];
      for (; s.length;) {
        const r = s.shift();
        (t.get(r) || []).forEach((t) => {
          (t.connId && e.add(t.connId),
            o.has(t.node) || (o.add(t.node), s.push(t.node)));
        });
      }
      return e;
    })();
    (p.connections.forEach((t, r) =>
      y.appendChild(
        (function (e, t = 0, r = new Set()) {
          const n = T(e.from.componentId, e.from.portId),
            a = T(e.to.componentId, e.to.portId),
            i = A("g", { "data-id": e.id });
          if (!n || !a) return i;
          const o = (function (e, t, r = null, n = 0) {
              const a =
                  (function (e, t = 0) {
                    if (!e) return 0;
                    return (
                      ({
                        pressure: -1.5,
                        return: 1.5,
                        pilot: -3,
                        drain: 3,
                        electrical: -4,
                      }[e.lineType] ?? 0) +
                      (p.connections.filter(
                        (t) =>
                          t !== e &&
                          ((t.from.componentId === e.from.componentId &&
                            t.from.portId === e.from.portId) ||
                            (t.to.componentId === e.to.componentId &&
                              t.to.portId === e.to.portId) ||
                            (t.from.componentId === e.to.componentId &&
                              t.from.portId === e.to.portId) ||
                            (t.to.componentId === e.from.componentId &&
                              t.to.portId === e.from.portId)),
                      ).length
                        ? 0.45 * ((t % 5) - 2)
                        : 0)
                    );
                  })(r, n) +
                  P(r?.properties?.shift, 0) / 18,
                i = r?.properties?.routeMode || "auto",
                o = t.x - e.x,
                s = t.y - e.y;
              if ("straight" === i)
                return [
                  [e.x, e.y],
                  [t.x, t.y],
                ];
              const l = U(e, o, s),
                c = U(t, -o, -s),
                d = 28 + Math.min(24, 2 * Math.abs(a)),
                u = [e.x, e.y],
                m = [S(e.x + l.x * d, 2), S(e.y + l.y * d, 2)],
                y = [S(t.x + c.x * d, 2), S(t.y + c.y * d, 2)],
                h = Math.abs(y[0] - m[0]),
                g = Math.abs(y[1] - m[1]);
              let v;
              if ("horizontal-first" === i || ("auto" === i && h > g)) {
                const e = S((m[0] + y[0]) / 2 + 18 * a, 10);
                v = [u, m, [e, m[1]], [e, y[1]], y, [t.x, t.y]];
              } else {
                const e = S((m[1] + y[1]) / 2 + 18 * a, 10);
                v = [u, m, [m[0], e], [y[0], e], y, [t.x, t.y]];
              }
              return (function (e) {
                const t = [];
                e.forEach((e) => {
                  const r = t[t.length - 1];
                  (!r ||
                    Math.abs(r[0] - e[0]) > 0.1 ||
                    Math.abs(r[1] - e[1]) > 0.1) &&
                    t.push(e);
                });
                for (let e = t.length - 2; e > 0; e--) {
                  const r = t[e - 1],
                    n = t[e],
                    a = t[e + 1];
                  ((Math.abs(r[0] - n[0]) < 0.1 &&
                    Math.abs(n[0] - a[0]) < 0.1) ||
                    (Math.abs(r[1] - n[1]) < 0.1 &&
                      Math.abs(n[1] - a[1]) < 0.1)) &&
                    t.splice(e, 1);
                }
                return t;
              })(v);
            })(n, a, e, t),
            s = (function (e) {
              return e
                .map((e, t) => `${t ? "L" : "M"} ${e[0]} ${e[1]}`)
                .join(" ");
            })(o),
            l = ["rgz-connection-path", e.lineType || "pressure"];
          "connection" === p.selected?.kind &&
            p.selected.id === e.id &&
            l.push("selected");
          const c = r.has(e.id),
            lm =
              ((p.sim.metrics && p.sim.metrics.lines) || []).find(
                (t) => t.id === e.id,
              ) || null;
          (c && l.push("sim-pressure"),
            p.sim.running &&
              "electrical" !== e.lineType &&
              (lm ? lm.active : P(p.sim.metrics?.activeFlowLpm, 0) > 0.05) &&
              (l.push("sim-active"),
              (lm
                ? lm.high
                : (p.sim.metrics?.pressureBar || 0) > 0.8 * De()) &&
                ("pressure" === e.lineType || "pilot" === e.lineType) &&
                l.push("sim-high")));
          const d = { d: s, class: l.join(" ") },
            u = [`stroke:${e.properties?.color || Ae(e.lineType)}`];
          (u.push(
            `stroke-width:${c ? Math.max(P(e.properties?.strokeWidth, 3) + 3, 6) : e.properties?.strokeWidth || 3}`,
          ),
            (d.style = u.join(";")));
          const m = A("path", d);
          return (
            m.addEventListener("click", (t) => {
              (t.stopPropagation(),
                p.pendingPort
                  ? (function (e, t) {
                      if (!p.pendingPort) return;
                      if ("electrical" === e.lineType)
                        return void lt(
                          "Electrical line branching is not supported yet. Add a PLC or electrical junction block instead.",
                          "warning",
                        );
                      const r = k(p.pendingPort),
                        n = T(r.componentId, r.portId);
                      if (!n) return ((p.pendingPort = null), void H());
                      if ("electrical" === n.kind)
                        return (
                          lt(
                            "Electrical ports cannot be joined to fluid lines.",
                            "error",
                          ),
                          (p.pendingPort = null),
                          void H()
                        );
                      const a = F(t),
                        i = E("junction", a.x, a.y);
                      i.label = i.label || i.id.replace("-", "");
                      const o = k(e.properties || {});
                      (p.components.push(i),
                        (p.connections = p.connections.filter(
                          (t) => t.id !== e.id,
                        )),
                        p.connections.push(
                          V(
                            e.from.componentId,
                            e.from.portId,
                            i.id,
                            "A",
                            e.lineType,
                            Object.assign({}, o, { shift: P(o.shift, 0) - 8 }),
                          ),
                        ),
                        p.connections.push(
                          V(
                            i.id,
                            "B",
                            e.to.componentId,
                            e.to.portId,
                            e.lineType,
                            Object.assign({}, o, { shift: P(o.shift, 0) + 8 }),
                          ),
                        ),
                        p.connections.push(
                          V(
                            r.componentId,
                            r.portId,
                            i.id,
                            "C",
                            "pilot" === n.kind ? "pilot" : e.lineType,
                            Object.assign({}, o, { shift: P(o.shift, 0) + 24 }),
                          ),
                        ),
                        (p.pendingPort = null),
                        (p.selected = { kind: "component", id: i.id }),
                        H(),
                        ke(),
                        lt(
                          "Branch connection added. Move the junction dot to refine the drawing.",
                          "ok",
                        ));
                    })(e, t)
                  : ((p.selected = { kind: "connection", id: e.id }),
                    H(),
                    ke()));
            }),
            i.appendChild(m),
            i
          );
        })(t, r, e),
      ),
    ),
      p.components.forEach((e) =>
        h.appendChild(
          (function (e) {
            const t = $(e.type),
              r = A("g", {
                class: `rgz-component ${"component" === p.selected?.kind && p.selected.id === e.id ? "selected" : ""} ${_(e) ? "sim-moving" : ""}`,
                transform: `translate(${e.x} ${e.y}) rotate(${e.rotation || 0})`,
                "data-id": e.id,
              });
            (r.addEventListener("pointerdown", (t) => {
              if (t.ctrlKey || t.metaKey)
                return (t.stopPropagation(), void D(t));
              if (t.target.classList.contains("port")) return;
              (t.stopPropagation(),
                (p.selected = { kind: "component", id: e.id }));
              const r = F(t);
              ((p.drag = {
                kind: "component",
                id: e.id,
                startPoint: r,
                startX: e.x,
                startY: e.y,
              }),
                H(),
                ke());
            }),
              r.addEventListener("click", (t) => {
                t.ctrlKey ||
                  t.metaKey ||
                  t.target.classList.contains("port") ||
                  (t.stopPropagation(),
                  (p.selected = { kind: "component", id: e.id }),
                  H(),
                  ke());
              }),
              r.addEventListener("dblclick", (t) => {
                (t.stopPropagation(), Pe(e.id));
              }),
              r.appendChild(
                A("rect", {
                  class: "selection-box",
                  x: -t.w / 2 - 12,
                  y: -t.h / 2 - 22,
                  width: t.w + 24,
                  height: t.h + 42,
                  rx: 12,
                }),
              ),
              (function (e, t, r) {
                if (C(t)) Q(e, t);
                else if (RgzIsoDraw(e, t, r)) return;
                else
                  switch (t.type) {
                    case "powerPack":
                      !(function (e, t) {
                        (e.append(
                          A("rect", {
                            class: "symbol-fill",
                            x: -72,
                            y: -45,
                            width: 144,
                            height: 90,
                            rx: 8,
                          }),
                        ),
                          e.append(
                            A(
                              "text",
                              {
                                class: "port-label",
                                x: 0,
                                y: -28,
                                "text-anchor": "middle",
                              },
                              "POWER PACK",
                            ),
                          ),
                          e.append(
                            A("circle", {
                              class: "symbol-muted",
                              cx: -34,
                              cy: -4,
                              r: 18,
                            }),
                          ),
                          e.append(
                            A("path", {
                              class: "symbol-accent",
                              d: "M-40 6 L-22 -4 L-40 -14 Z",
                            }),
                          ),
                          e.append(
                            A("path", {
                              class: "symbol-muted",
                              d: "M-2 -24 v40 h38 v-40 M4 0 q8 6 16 0 t16 0",
                            }),
                          ),
                          e.append(
                            A("path", {
                              class: "symbol-stroke",
                              d: "M36 -22h46M36 30h46",
                            }),
                          ),
                          e.append(
                            A(
                              "text",
                              {
                                class: "port-label",
                                x: 57,
                                y: -30,
                                "text-anchor": "middle",
                              },
                              "P",
                            ),
                          ),
                          e.append(
                            A(
                              "text",
                              {
                                class: "port-label",
                                x: 57,
                                y: 20,
                                "text-anchor": "middle",
                              },
                              "T",
                            ),
                          ),
                          t.props.pressureGauge &&
                            (e.append(
                              A("circle", {
                                class: "symbol-muted",
                                cx: 38,
                                cy: -8,
                                r: 13,
                              }),
                            ),
                            e.append(
                              A("path", {
                                class: "symbol-muted",
                                d: "M38 -8 l8 -8",
                              }),
                            )));
                      })(e, t);
                      break;
                    case "tank":
                      !(function (e) {
                        (e.append(
                          A("path", {
                            class: "symbol-stroke",
                            d: "M-42 -16 v42 h84 v-42",
                          }),
                        ),
                          e.append(
                            A("path", {
                              class: "symbol-muted",
                              d: "M-30 8 q10 8 20 0 t20 0 t20 0",
                            }),
                          ),
                          e.append(
                            A("path", {
                              class: "symbol-muted",
                              d: "M-15 25h30M-25 34h50",
                            }),
                          ));
                      })(e);
                      break;
                    case "pumpFixed":
                      Z(e, !1);
                      break;
                    case "pumpVariable":
                      Z(e, !0);
                      break;
                    case "reliefValve":
                      !(function (e) {
                        (e.append(
                          A("rect", {
                            class: "symbol-fill",
                            x: -30,
                            y: -28,
                            width: 60,
                            height: 56,
                            rx: 4,
                          }),
                        ),
                          e.append(
                            A("path", {
                              class: "symbol-stroke",
                              d: "M-58 0h28M30 0h28",
                            }),
                          ),
                          e.append(
                            A("path", {
                              class: "symbol-accent",
                              d: "M-17 17 L18 -18 M5 -18h13v13",
                            }),
                          ),
                          e.append(
                            A("path", {
                              class: "symbol-muted",
                              d: "M26 20 c12 -10 12 -30 0 -40",
                            }),
                          ));
                      })(e);
                      break;
                    case "directionalValve":
                      Q(e, t);
                      break;
                    case "flowControl":
                      ee(e, t);
                      break;
                    case "checkValve":
                      te(e);
                      break;
                    case "pilotCheckValve":
                      re(e);
                      break;
                    case "counterbalanceValve":
                      ne(e);
                      break;
                    case "sequenceValve":
                      ae(e, "SEQ");
                      break;
                    case "reducingValve":
                      ae(e, "RED");
                      break;
                    case "cylinderDA":
                      ie(e, t);
                      break;
                    case "cylinderSA":
                      oe(e, t);
                      break;
                    case "hydraulicMotor":
                      se(e, t);
                      break;
                    case "accumulator":
                      le(e);
                      break;
                    case "flowDivider":
                      ce(e);
                      break;
                    case "filter":
                      de(e);
                      break;
                    case "cooler":
                      pe(e);
                      break;
                    case "pressureGauge":
                      ue(e);
                      break;
                    case "flowMeter":
                      me(e);
                      break;
                    case "pressureSwitch":
                      !(function (e) {
                        (ue(e),
                          e.append(
                            A("path", {
                              class: "symbol-muted",
                              d: "M28 -24 h22M40 -24v18M34 -6h14",
                            }),
                          ));
                      })(e);
                      break;
                    case "pressureTransducer":
                      !(function (e, t) {
                        (ue(e),
                          e.append(
                            A(
                              "text",
                              {
                                class: "port-label",
                                x: 0,
                                y: 5,
                                "text-anchor": "middle",
                              },
                              "PT",
                            ),
                          ),
                          e.append(
                            A("path", {
                              class: ye(t),
                              d: "M28 -18 h24M42 -18v18M34 0h16",
                            }),
                          ));
                      })(e, t);
                      break;
                    case "flowSwitch":
                      !(function (e, t) {
                        (e.append(
                          A("circle", {
                            class: "symbol-fill",
                            cx: 0,
                            cy: 0,
                            r: 28,
                          }),
                        ),
                          e.append(
                            A("path", {
                              class: "symbol-stroke",
                              d: "M-58 0h30M28 0h30M-10 12L14 0-10-12",
                            }),
                          ),
                          e.append(
                            A("path", {
                              class: ye(t),
                              d: "M0 -42v18M-10 -32h20",
                            }),
                          ),
                          e.append(
                            A(
                              "text",
                              {
                                class: "port-label",
                                x: 0,
                                y: 5,
                                "text-anchor": "middle",
                              },
                              "FS",
                            ),
                          ));
                      })(e, t);
                      break;
                    case "temperatureSwitch":
                      !(function (e, t) {
                        (e.append(
                          A("circle", {
                            class: "symbol-fill",
                            cx: 0,
                            cy: -2,
                            r: 25,
                          }),
                        ),
                          e.append(
                            A("path", {
                              class: "symbol-stroke",
                              d: "M0 23v21M-8 8v-26a8 8 0 0 1 16 0v26a14 14 0 1 1 -16 0",
                            }),
                          ),
                          e.append(
                            A("path", {
                              class: ye(t),
                              d: "M30 -18h20M42 -18v18M36 0h12",
                            }),
                          ));
                      })(e, t);
                      break;
                    case "levelSwitch":
                      !(function (e, t) {
                        (e.append(
                          A("path", {
                            class: "symbol-stroke",
                            d: "M-42 -20v42h84v-42M-30 0q10 7 20 0t20 0t20 0",
                          }),
                        ),
                          e.append(
                            A("path", {
                              class: ye(t),
                              d: "M-52 0h24M28 0h24M-10 -12h20v24h-20z",
                            }),
                          ),
                          e.append(
                            A(
                              "text",
                              {
                                class: "port-label",
                                x: 0,
                                y: 34,
                                "text-anchor": "middle",
                              },
                              "high level" === t.props.mode ? "HIGH" : "LOW",
                            ),
                          ));
                      })(e, t);
                      break;
                    case "limitSwitch":
                      !(function (e, t) {
                        (e.append(
                          A("path", {
                            class: "symbol-stroke",
                            d: "M-56 0h26M24 0h32M-28 -18v36M-26 0l36 -20",
                          }),
                        ),
                          e.append(
                            A("circle", {
                              class: ye(t),
                              cx: 15,
                              cy: -24,
                              r: 7,
                            }),
                          ),
                          e.append(
                            A(
                              "text",
                              {
                                class: "port-label",
                                x: 0,
                                y: 30,
                                "text-anchor": "middle",
                              },
                              t.props.active ? "LS ON" : "LS",
                            ),
                          ));
                      })(e, t);
                      break;
                    case "cylinderReedSensor":
                      !(function (e, t) {
                        (e.append(
                          A("rect", {
                            class: "symbol-fill",
                            x: -46,
                            y: -17,
                            width: 92,
                            height: 34,
                            rx: 15,
                          }),
                        ),
                          e.append(
                            A("path", {
                              class: "symbol-stroke",
                              d: "M-58 0h12M46 0h12M-18 -8h36M-18 8h36",
                            }),
                          ),
                          e.append(
                            A("circle", { class: ye(t), cx: 0, cy: 0, r: 8 }),
                          ),
                          e.append(
                            A(
                              "text",
                              {
                                class: "port-label",
                                x: 0,
                                y: 34,
                                "text-anchor": "middle",
                              },
                              t.props.active ? "REED ON" : "REED",
                            ),
                          ));
                      })(e, t);
                      break;
                    case "linearPositionSensor":
                      !(function (e, t) {
                        e.append(
                          A("rect", {
                            class: "symbol-fill",
                            x: -56,
                            y: -16,
                            width: 112,
                            height: 32,
                            rx: 4,
                          }),
                        );
                        const r = z(P(t.props.triggerPosition, 0.5), 0, 1);
                        (e.append(
                          A("path", {
                            class: "symbol-stroke",
                            d: "M-64 0h8M56 0h8M-42 0h84",
                          }),
                        ),
                          e.append(
                            A("path", {
                              class: ye(t),
                              d: `M${84 * r - 42} -18v36`,
                            }),
                          ),
                          e.append(
                            A(
                              "text",
                              {
                                class: "port-label",
                                x: 0,
                                y: 34,
                                "text-anchor": "middle",
                              },
                              "LVDT",
                            ),
                          ));
                      })(e, t);
                      break;
                    case "proximitySensor":
                      !(function (e, t) {
                        (e.append(
                          A("rect", {
                            class: "symbol-fill",
                            x: -34,
                            y: -20,
                            width: 68,
                            height: 40,
                            rx: 5,
                          }),
                        ),
                          e.append(
                            A("path", {
                              class: "symbol-stroke",
                              d: "M-56 0h22M34 0h22",
                            }),
                          ),
                          e.append(
                            A("path", {
                              class: ye(t),
                              d: "M38 -18 q18 18 0 36M48 -28 q28 28 0 56",
                            }),
                          ),
                          e.append(
                            A(
                              "text",
                              {
                                class: "port-label",
                                x: 0,
                                y: 5,
                                "text-anchor": "middle",
                              },
                              "B",
                            ),
                          ));
                      })(e, t);
                      break;
                    case "pushButton":
                      !(function (e, t) {
                        const r = !!t.props.pressed;
                        (e.append(
                          A("path", {
                            class: "symbol-stroke",
                            d: "M-48 0h24M24 0h24M-24 -20v40",
                          }),
                        ),
                          e.append(
                            A("path", {
                              class: r ? "symbol-accent" : "symbol-muted",
                              d: r ? "M-20 0 H24" : "M-20 0 L18 -18",
                            }),
                          ),
                          e.append(
                            A("circle", {
                              class: r ? "symbol-accent" : "symbol-muted",
                              cx: 18,
                              cy: -24,
                              r: 7,
                            }),
                          ),
                          e.append(
                            A(
                              "text",
                              {
                                class: "port-label",
                                x: 0,
                                y: 30,
                                "text-anchor": "middle",
                              },
                              `${t.props.contact || "NO"} ${r ? "ON" : "OFF"}`,
                            ),
                          ));
                      })(e, t);
                      break;
                    case "solenoid":
                      !(function (e, t) {
                        (e.append(
                          A("rect", {
                            class: "symbol-fill",
                            x: -34,
                            y: -23,
                            width: 68,
                            height: 46,
                            rx: 5,
                          }),
                        ),
                          e.append(
                            A("path", {
                              class: t.props.energized
                                ? "symbol-accent"
                                : "symbol-muted",
                              d: "M-44 0h10M34 0h10M-18 -12 q18 12 0 24M0 -12 q18 12 0 24M18 -12 q18 12 0 24",
                            }),
                          ));
                      })(e, t);
                      break;
                    case "plc":
                      !(function (e) {
                        (e.append(
                          A("rect", {
                            class: "symbol-fill",
                            x: -50,
                            y: -34,
                            width: 100,
                            height: 68,
                            rx: 6,
                          }),
                        ),
                          e.append(
                            A(
                              "text",
                              {
                                class: "port-label",
                                x: 0,
                                y: 5,
                                "text-anchor": "middle",
                              },
                              "PLC",
                            ),
                          ),
                          e.append(
                            A("path", {
                              class: "symbol-muted",
                              d: "M-58 -18h8M-58 18h8M50 -18h8M50 18h8",
                            }),
                          ));
                      })(e);
                      break;
                    case "blindPlug":
                      !(function (e) {
                        (e.append(
                          A("path", { class: "symbol-stroke", d: "M-26 0h16" }),
                        ),
                          e.append(
                            A("rect", {
                              class: "symbol-stroke",
                              x: -10,
                              y: -12,
                              width: 16,
                              height: 24,
                            }),
                          ),
                          e.append(
                            A("path", {
                              class: "symbol-stroke",
                              d: "M-10 -12 L6 12 M6 -12 L-10 12",
                            }),
                          ));
                      })(e);
                      break;
                    case "junction":
                      !(function (e) {
                        (e.append(
                          A("circle", {
                            class: "symbol-fill",
                            cx: 0,
                            cy: 0,
                            r: 9,
                          }),
                        ),
                          e.append(
                            A("path", {
                              class: "symbol-stroke",
                              d: "M-26 0h52M0-26v52",
                            }),
                          ));
                      })(e);
                      break;
                    case "electricMotor":
                      !(function (e) {
                        (e.append(
                          A("circle", {
                            class: "symbol-fill",
                            cx: 0,
                            cy: 0,
                            r: 28,
                          }),
                        ),
                          he(e, "M", 0, 6, 18),
                          e.append(
                            A("path", { class: "symbol-muted", d: "M28 0h26" }),
                          ));
                      })(e);
                      break;
                    case "suctionStrainer":
                      !(function (e) {
                        (de(e),
                          e.append(
                            A("path", {
                              class: "symbol-muted",
                              d: "M-22 18h44M-16 24h32",
                            }),
                          ));
                      })(e);
                      break;
                    case "breatherFiller":
                      !(function (e) {
                        (e.append(
                          A("path", {
                            class: "symbol-stroke",
                            d: "M-28 18h56M-18 28h36M0 36V14",
                          }),
                        ),
                          e.append(
                            A("rect", {
                              class: "symbol-fill",
                              x: -18,
                              y: -18,
                              width: 36,
                              height: 32,
                              rx: 0,
                            }),
                          ),
                          e.append(
                            A("path", {
                              class: "symbol-muted",
                              d: "M-12 -8h24M-12 0h24M-12 8h24",
                            }),
                          ));
                      })(e);
                      break;
                    case "testPoint":
                      !(function (e) {
                        (e.append(
                          A("circle", {
                            class: "symbol-fill",
                            cx: 0,
                            cy: 0,
                            r: 14,
                          }),
                        ),
                          ge(e, "M0 14v28"),
                          e.append(
                            A("path", {
                              class: "symbol-muted",
                              d: "M-10 -6h20M-10 6h20",
                            }),
                          ),
                          he(e, "TP", 0, -24, 10));
                      })(e);
                      break;
                    case "shutoffValve":
                      !(function (e) {
                        (ge(e, "M-52 0h18M34 0h18"),
                          e.append(
                            A("path", {
                              class: "symbol-fill",
                              d: "M-34 -20 L0 0 L-34 20 Z M34 -20 L0 0 L34 20 Z",
                            }),
                          ),
                          e.append(
                            A("path", {
                              class: "symbol-accent",
                              d: "M-22 26L22 -26",
                            }),
                          ));
                      })(e);
                      break;
                    case "pressureCompensator":
                      !(function (e) {
                        (e.append(
                          A("rect", {
                            class: "symbol-fill",
                            x: -34,
                            y: -26,
                            width: 68,
                            height: 52,
                            rx: 0,
                          }),
                        ),
                          ge(e, "M-56 0h22M34 0h22M0 -40v14"),
                          be(e, -2, 0, 1),
                          fe(e, 28, -20, 20, -1),
                          he(e, "Δp", 0, 44, 11));
                      })(e);
                      break;
                    case "logicCartridgeValve":
                      !(function (e) {
                        (e.append(
                          A("rect", {
                            class: "symbol-fill",
                            x: -36,
                            y: -26,
                            width: 72,
                            height: 52,
                            rx: 0,
                          }),
                        ),
                          ge(e, "M-56 0h20M36 0h20M0 -42v16"),
                          be(e, 0, 0, 1),
                          he(e, "X", 0, -48, 9));
                      })(e);
                      break;
                    case "servoValve":
                      !(function (e, t) {
                        (Q(
                          e,
                          Object.assign({}, t, {
                            props: Object.assign({}, t.props, {
                              ports: 4,
                              positions: 3,
                              center: "closed",
                              leftActuation: "proportional solenoid",
                              rightActuation: "proportional solenoid",
                            }),
                          }),
                        ),
                          he(e, "±", 0, 62, 14));
                      })(e, t);
                      break;
                    case "hydraulicIntensifier":
                      !(function (e) {
                        (e.append(
                          A("rect", {
                            class: "symbol-fill",
                            x: -46,
                            y: -18,
                            width: 34,
                            height: 36,
                            rx: 0,
                          }),
                        ),
                          e.append(
                            A("rect", {
                              class: "symbol-fill",
                              x: 10,
                              y: -26,
                              width: 48,
                              height: 52,
                              rx: 0,
                            }),
                          ),
                          ge(e, "M-62 0h16M58 0h18M-12 0h22M0 26v18"),
                          e.append(
                            A("path", {
                              class: "symbol-stroke",
                              d: "M-12 -18v36M10 -26v52",
                            }),
                          ),
                          he(e, "INT", 0, -38, 10));
                      })(e);
                      break;
                    case "oilHeater":
                      !(function (e) {
                        (e.append(
                          A("rect", {
                            class: "symbol-fill",
                            x: -34,
                            y: -22,
                            width: 68,
                            height: 44,
                            rx: 0,
                          }),
                        ),
                          ge(e, "M-52 0h18M34 0h18"),
                          e.append(
                            A("path", {
                              class: "symbol-accent",
                              d: "M-20 8l8 -16l8 16l8 -16l8 16l8 -16",
                            }),
                          ));
                      })(e);
                      break;
                    case "proportionalAmplifier":
                      !(function (e, t) {
                        (e.append(
                          A("rect", {
                            class: "symbol-fill",
                            x: -58,
                            y: -32,
                            width: 116,
                            height: 64,
                            rx: 0,
                          }),
                        ),
                          ge(e, "M-64 -18h6M-64 18h6M58 0h14"),
                          he(e, "AMP", 0, -10, 13),
                          e.append(
                            A("path", {
                              class: "symbol-accent",
                              d: "M-36 16 L-12 -8 L8 8 L36 -20",
                            }),
                          ),
                          e.append(
                            A("path", {
                              class: "symbol-muted",
                              d: "M-42 22h84M-42 -22h84",
                            }),
                          ),
                          he(e, `${P(t.props.outputPercent, 0)}%`, 0, 22, 10));
                      })(e, t);
                      break;
                    case "setpointPotentiometer":
                      !(function (e, t) {
                        (ge(e, "M-56 0h20M36 0h20"),
                          e.append(
                            A("path", {
                              class: "symbol-stroke",
                              d: "M-30 0h60",
                            }),
                          ),
                          e.append(
                            A("path", {
                              class: "symbol-accent",
                              d: "M0 24V-6 M-12 8L0 -6L12 8",
                            }),
                          ),
                          he(
                            e,
                            `${P(t.props.setpointPercent, 0)}%`,
                            0,
                            -22,
                            10,
                          ));
                      })(e, t);
                      break;
                    case "rampGenerator":
                      !(function (e) {
                        (e.append(
                          A("rect", {
                            class: "symbol-fill",
                            x: -52,
                            y: -26,
                            width: 104,
                            height: 52,
                            rx: 0,
                          }),
                        ),
                          ge(e, "M-60 0h8M52 0h8"),
                          e.append(
                            A("path", {
                              class: "symbol-accent",
                              d: "M-32 16 H-10 L28 -16 H36",
                            }),
                          ),
                          he(e, "RAMP", 0, 38, 10));
                      })(e);
                      break;
                    case "electricalRelay":
                      !(function (e, t) {
                        (e.append(
                          A("rect", {
                            class: t.props.energized
                              ? "symbol-accent"
                              : "symbol-fill",
                            x: -32,
                            y: -18,
                            width: 64,
                            height: 36,
                            rx: 0,
                          }),
                        ),
                          ge(e, "M-50 0h18M32 0h18"),
                          he(e, "K", 0, 6, 16));
                      })(e, t);
                      break;
                    case "relayContact":
                      !(function (e, t) {
                        ge(e, "M-54 0h22M26 0h28");
                        const r = !!t.props.closed,
                          n = "NC" === t.props.contact;
                        (r || n
                          ? e.append(
                              A("path", {
                                class: "symbol-stroke",
                                d: "M-28 0H26",
                              }),
                            )
                          : e.append(
                              A("path", {
                                class: "symbol-stroke",
                                d: "M-28 0L22 -18",
                              }),
                            ),
                          he(e, t.props.contact || "NO", 0, 30, 10));
                      })(e, t);
                      break;
                    case "timerRelay":
                      !(function (e) {
                        (e.append(
                          A("rect", {
                            class: "symbol-fill",
                            x: -40,
                            y: -24,
                            width: 80,
                            height: 48,
                            rx: 0,
                          }),
                        ),
                          ge(e, "M-56 0h16M40 0h16"),
                          e.append(
                            A("path", {
                              class: "symbol-muted",
                              d: "M-16 -10h28M-16 0h20M-16 10h28",
                            }),
                          ),
                          he(e, "t", 22, 6, 18));
                      })(e);
                      break;
                    case "emergencyStop":
                      !(function (e, t) {
                        (ge(e, "M-56 0h20M28 0h28"),
                          e.append(
                            A("path", {
                              class: t.props.pressed
                                ? "symbol-accent"
                                : "symbol-stroke",
                              d: "M-32 0L22 -18",
                            }),
                          ),
                          e.append(
                            A("circle", {
                              class: "symbol-muted",
                              cx: 0,
                              cy: -24,
                              r: 11,
                            }),
                          ),
                          he(e, "E", 0, -20, 10));
                      })(e, t);
                      break;
                    case "hydraulicTrainingNote":
                    case "textLabel":
                      !(function (e, t) {
                        const r = String(t.props.text || ""),
                          n = r.split(/\r?\n/).slice(0, 8),
                          a =
                            "auto" === t.props.direction
                              ? /[^\u0000-\u007f]/.test(r)
                                ? "rtl"
                                : "ltr"
                              : t.props.direction || "ltr",
                          i = t.props.align || ("rtl" === a ? "end" : "start"),
                          o = P(t.props.fontSize, 24),
                          s =
                            "middle" === i
                              ? "middle"
                              : "end" === i
                                ? "end"
                                : "start",
                          l = "middle" === s ? 0 : "end" === s ? 130 : -130,
                          c = A("text", {
                            class: "rgz-custom-text",
                            x: l,
                            y: 0,
                            fill: t.props.color || "#f3efe7",
                            "font-size": o,
                            "font-family":
                              t.props.fontFamily || "Tahoma, Arial, sans-serif",
                            "font-weight": t.props.fontWeight || "700",
                            direction: a,
                            "unicode-bidi": "plaintext",
                            "text-anchor": s,
                            style: `direction:${a};unicode-bidi:plaintext;`,
                          });
                        (n.forEach((e, t) => {
                          c.appendChild(
                            A(
                              "tspan",
                              { x: l, dy: t ? 1.25 * o : 0 },
                              e || " ",
                            ),
                          );
                        }),
                          e.append(c));
                      })(e, t);
                      break;
                    case "cartridgeCheckValve":
                      !(function (e) {
                        (xe(e, "M-SR"),
                          ge(e, "M-58 0h22M36 0h22"),
                          e.append(
                            A("path", {
                              class: "symbol-fill",
                              d: "M-18 -18v36L18 0Z",
                            }),
                          ),
                          e.append(
                            A("path", {
                              class: "symbol-stroke",
                              d: "M21 -22v44",
                            }),
                          ),
                          fe(e, 32, -20, 20, -1));
                      })(e);
                      break;
                    case "cartridgeReliefValve":
                      !(function (e) {
                        (we(e, "LC-DB"),
                          e.append(
                            A("rect", {
                              class: "symbol-fill",
                              x: -20,
                              y: -76,
                              width: 40,
                              height: 24,
                              rx: 0,
                            }),
                          ),
                          ge(e, "M0 -52v-8M20 -64h28"),
                          be(e, 0, -64, 1),
                          fe(e, 16, -74, -54, -1),
                          ve(e, -18, -48, 18, -80));
                      })(e);
                      break;
                    case "cartridgeReducingValve":
                      !(function (e) {
                        (we(e, "LC-DR"),
                          ge(e, "M0 34v14"),
                          e.append(
                            A("path", {
                              class: "symbol-muted",
                              d: "M36 0v-42H8",
                            }),
                          ),
                          e.append(
                            A("rect", {
                              class: "symbol-fill",
                              x: -20,
                              y: -76,
                              width: 40,
                              height: 24,
                              rx: 0,
                            }),
                          ),
                          ve(e, -18, -48, 18, -80),
                          he(e, "A→B", 0, 64, 8));
                      })(e);
                      break;
                    case "cartridgeSequenceValve":
                      !(function (e) {
                        (we(e, "LC-SEQ"),
                          ge(e, "M0 34v14"),
                          e.append(
                            A("path", {
                              class: "symbol-muted",
                              d: "M-36 0v-42H0",
                            }),
                          ),
                          e.append(
                            A("rect", {
                              class: "symbol-fill",
                              x: -20,
                              y: -76,
                              width: 40,
                              height: 24,
                              rx: 0,
                            }),
                          ),
                          ve(e, -18, -48, 18, -80));
                      })(e);
                      break;
                    case "cartridgeUnloadingValve":
                      !(function (e) {
                        (we(e, "LC-UNL"),
                          e.append(
                            A("path", {
                              class: "symbol-muted",
                              d: "M0 -48v-20M-14 -68h28",
                            }),
                          ),
                          e.append(
                            A("rect", {
                              class: "symbol-fill",
                              x: -22,
                              y: -86,
                              width: 44,
                              height: 24,
                              rx: 0,
                            }),
                          ),
                          ve(e, -20, -58, 20, -90));
                      })(e);
                      break;
                    case "cartridgeCounterbalanceValve":
                      !(function (e) {
                        (xe(e, "CLH"),
                          ge(e, "M-66 0h24M42 0h24M0 -52v18"),
                          e.append(
                            A("path", {
                              class: "symbol-fill",
                              d: "M-22 -18v36L14 0Z",
                            }),
                          ),
                          e.append(
                            A("path", {
                              class: "symbol-stroke",
                              d: "M18 -22v44",
                            }),
                          ),
                          fe(e, 30, -22, 22, -1),
                          ve(e, -30, 26, 18, -26),
                          e.append(
                            A("path", {
                              class: "symbol-muted",
                              d: "M-34 22h68M-10 12v20l20 -10zM14 10v24",
                            }),
                          ),
                          e.append(
                            A("path", {
                              class: "symbol-muted",
                              d: "M0 -34v-18",
                            }),
                          ),
                          he(e, "X", 0, -58, 9));
                      })(e);
                      break;
                    case "cartridgeNeedleFlowValve":
                      !(function (e, t) {
                        (xe(e, "CNV"),
                          ge(e, "M-58 0h22M36 0h22"),
                          e.append(
                            A("path", {
                              class: "symbol-stroke",
                              d: "M-20 -16 L20 16 M-20 16 L20 -16",
                            }),
                          ),
                          ve(e, -32, 25, 32, -25),
                          t.props &&
                            t.props.reverseCheck &&
                            (e.append(
                              A("path", {
                                class: "symbol-muted",
                                d: "M-31 22h62",
                              }),
                            ),
                            e.append(
                              A("path", {
                                class: "symbol-muted",
                                d: "M-9 12v20l18 -10zM14 10v24",
                              }),
                            )));
                      })(e, t);
                      break;
                    case "cartridgeSolenoidValve22":
                      !(function (e, t) {
                        (xe(e, "2/2"), ge(e, "M-60 0h24M36 0h24M0 -44v10"));
                        (!!t.props.energized != !!t.props.normallyOpen
                          ? W(e, [-20, 0], [20, 0], !0)
                          : (X(e, [-20, 0]), X(e, [20, 0])),
                          e.append(
                            A("rect", {
                              class: t.props.energized
                                ? "symbol-accent"
                                : "symbol-muted",
                              x: -15,
                              y: -72,
                              width: 30,
                              height: 28,
                              rx: 0,
                            }),
                          ),
                          e.append(
                            A("path", {
                              class: "symbol-muted",
                              d: "M-9 -66q18 8 0 16M0 -66q18 8 0 16",
                            }),
                          ),
                          he(e, "Y", 0, -50, 9));
                      })(e, t);
                      break;
                    case "cartridgeShuttleValve":
                      !(function (e) {
                        (xe(e, "OR"),
                          ge(e, "M-60 -18h24M-60 18h24M36 0h24"),
                          e.append(
                            A("path", {
                              class: "symbol-stroke",
                              d: "M-36 -18L30 0M-36 18L30 0",
                            }),
                          ),
                          e.append(
                            A("circle", {
                              class: "symbol-fill",
                              cx: -5,
                              cy: 0,
                              r: 7,
                            }),
                          ),
                          e.append(
                            A("path", {
                              class: "symbol-muted",
                              d: "M24 -12v24",
                            }),
                          ));
                      })(e);
                      break;
                    case "cartridgeManifoldBlock":
                      !(function (e) {
                        (e.append(
                          A("rect", {
                            class: "symbol-fill",
                            x: -74,
                            y: -48,
                            width: 148,
                            height: 96,
                            rx: 0,
                          }),
                        ),
                          [
                            ["-46", "-28"],
                            ["22", "-28"],
                            ["-46", "16"],
                            ["22", "16"],
                          ].forEach((t) => {
                            (e.append(
                              A("rect", {
                                class: "symbol-muted",
                                x: Number(t[0]),
                                y: Number(t[1]),
                                width: 28,
                                height: 24,
                                rx: 0,
                                "stroke-dasharray": "5 4",
                              }),
                            ),
                              e.append(
                                A("path", {
                                  class: "symbol-muted",
                                  d: `M${Number(t[0]) + 7} ${Number(t[1]) + 12}h14`,
                                }),
                              ));
                          }),
                          ge(
                            e,
                            "M-82 -28h36M-82 28h36M50 -28h32M50 28h32M-18 -16h40M-18 28h40M0 -4v20",
                          ),
                          he(e, "HIC", 0, 4, 14));
                      })(e);
                      break;
                    default:
                      !(function (e, t, r, n) {
                        (e.append(
                          A("rect", {
                            class: "symbol-fill",
                            x: -t / 2,
                            y: -r / 2,
                            width: t,
                            height: r,
                            rx: 4,
                          }),
                        ),
                          e.append(
                            A(
                              "text",
                              {
                                class: "port-label",
                                x: 0,
                                y: 5,
                                "text-anchor": "middle",
                              },
                              n,
                            ),
                          ));
                      })(e, r.w, r.h, t.type);
                  }
              })(r, e, t),
              "textLabel" !== e.type &&
                r.appendChild(
                  A(
                    "text",
                    {
                      class: "component-label",
                      x: 0,
                      y: -t.h / 2 - 10,
                      "text-anchor": "middle",
                      ...(e.rotation
                        ? { transform: `rotate(${-e.rotation} 0 ${-t.h / 2 - 10})` }
                        : {}),
                    },
                    e.label || e.id,
                  ),
                ),
              B(e).forEach((t) => {
                const n = A("circle", {
                  class:
                    "port " +
                    (p.pendingPort &&
                    p.pendingPort.componentId === e.id &&
                    p.pendingPort.portId === t.id
                      ? "pending"
                      : ""),
                  cx: t.x,
                  cy: t.y,
                  r: 7,
                  "data-component-id": e.id,
                  "data-port-id": t.id,
                });
                (n.addEventListener("pointerdown", (e) => {
                  (e.stopPropagation(), (e.ctrlKey || e.metaKey) && D(e));
                }),
                  n.addEventListener("click", (r) => {
                    (r.stopPropagation(),
                      r.ctrlKey ||
                        r.metaKey ||
                        (function (e, t) {
                          if (!T(e, t)) return;
                          if (!p.pendingPort)
                            return (
                              (p.pendingPort = { componentId: e, portId: t }),
                              lt(
                                `Start port selected: ${e}.${t}. Now click target port.`,
                                "info",
                              ),
                              void H()
                            );
                          const r = p.pendingPort;
                          if (
                            ((p.pendingPort = null),
                            r.componentId === e && r.portId === t)
                          )
                            return void H();
                          const n = T(r.componentId, r.portId),
                            a = T(e, t);
                          if (!n || !a) return;
                          if (!(
                            n.kind === a.kind ||
                            ("pilot" === n.kind && "hydraulic" === a.kind) ||
                            ("hydraulic" === n.kind && "pilot" === a.kind)
                          ))
                            return (
                              lt(
                                `Incompatible connection: ${n.kind} port cannot connect to ${a.kind} port.`,
                                "error",
                              ),
                              void H()
                            );
                          const i = V(r.componentId, r.portId, e, t);
                          (p.connections.push(i),
                            (p.selected = { kind: "connection", id: i.id }),
                            H(),
                            ke());
                        })(e.id, t.id));
                  }),
                  r.appendChild(n));
                const a = t.y + (t.y < 0 ? -10 : 18);
                r.appendChild(
                  A(
                    "text",
                    {
                      class: "port-label",
                      x: t.x,
                      y: a,
                      "text-anchor": "middle",
                      ...(e.rotation
                        ? { transform: `rotate(${-e.rotation} ${t.x} ${a})` }
                        : {}),
                    },
                    t.id,
                  ),
                );
              }));
            const n = (function (e) {
              if (!p.sim.running || !1 === e.props.showReadout) return "";
              const t = p.sim.metrics || {},
                tcv = (t.comp && t.comp[e.id]) || null,
                tp =
                  tcv && Number.isFinite(tcv.pressureBar)
                    ? tcv.pressureBar
                    : P(t.pressureBar, 0),
                tf =
                  tcv && Number.isFinite(tcv.flowLpm)
                    ? tcv.flowLpm
                    : P(t.activeFlowLpm ?? t.totalFlowLpm, 0);
              if (
                [
                  "pressureGauge",
                  "pressureSwitch",
                  "pressureTransducer",
                  "reliefValve",
                ].includes(e.type)
              )
                return K(G(tp, e.props.displayUnit || "bar"));
              if ("powerPack" === e.type && e.props.pressureGauge)
                return K(G(tp, e.props.displayUnit || "bar"));
              if (["flowMeter", "flowSwitch"].includes(e.type))
                return K(
                  ((r = tf),
                  "L/s" === (n = e.props.displayUnit || "L/min")
                    ? { value: r / 60, suffix: "L/s", decimals: 2 }
                    : "GPM" === n
                      ? { value: 0.264172 * r, suffix: "GPM", decimals: 2 }
                      : { value: r, suffix: "L/min", decimals: 1 }),
                );
              var r, n;
              if ("temperatureSwitch" === e.type)
                return K(
                  (function (e, t) {
                    return "°F" === t
                      ? { value: (9 * e) / 5 + 32, suffix: "°F", decimals: 1 }
                      : { value: e, suffix: "°C", decimals: 1 };
                  })(
                    P(t.oilTempC, e.props.switchTempC || 40),
                    e.props.displayUnit || "°C",
                  ),
                );
              if ("levelSwitch" === e.type)
                return `${P(e.props.levelPercent, 0).toFixed(0)} %`;
              if (
                [
                  "limitSwitch",
                  "cylinderReedSensor",
                  "linearPositionSensor",
                  "proximitySensor",
                ].includes(e.type)
              ) {
                if ("state" === (e.props.displayUnit || "%"))
                  return e.props.active ? "ON" : "OFF";
                const t = Fe(e);
                return `${(t ? 100 * P(t.props.simPosition, 0) : 0).toFixed(0)} %`;
              }
              if ("cylinderDA" === e.type || "cylinderSA" === e.type) {
                if (
                  (function (e) {
                    const t = [
                      "limitSwitch",
                      "cylinderReedSensor",
                      "linearPositionSensor",
                      "proximitySensor",
                    ];
                    return p.components.some((r) => {
                      if (!t.includes(r.type)) return !1;
                      const n = String(r.props.linkedActuator || "")
                        .trim()
                        .toLowerCase();
                      return n
                        ? n === String(e.id).toLowerCase() ||
                            n === String(e.label || "").toLowerCase()
                        : Math.hypot(r.x - e.x, r.y - e.y) < 180;
                    });
                  })(e)
                )
                  return "";
                const r = (t.cylinders || []).find((t) => t.id === e.id),
                  n = z(P(e.props.simPosition, 0), 0, 1),
                  a = Math.max(1, P(e.props.strokeMm, 1)),
                  i = e.props.displayUnit || "position %";
                return "position mm" === i
                  ? `${(n * a).toFixed(0)} mm`
                  : "speed mm/s" === i
                    ? `${P(r?.speedMmS, 0).toFixed(1)} mm/s`
                    : "force kN" === i
                      ? `${P(r?.forceKN, 0).toFixed(1)} kN`
                      : `${(100 * n).toFixed(0)} %`;
              }
              if ("hydraulicMotor" === e.type) {
                const r = (t.motors || []).find((t) => t.id === e.id),
                  n = P(r?.rpm, 0);
                return "rev/s" === (e.props.displayUnit || "rpm")
                  ? `${(n / 60).toFixed(2)} rev/s`
                  : `${n.toFixed(0)} rpm`;
              }
              return "";
            })(e);
            return (
              n &&
                r.appendChild(
                  (function (e, t) {
                    const r = Math.max(74, Math.min(190, 8 * t.length + 22)),
                      n = e.h / 2 + 28,
                      a = A("g", e.rotation ? { class: "rgz-readout-badge", transform: `rotate(${-e.rotation} 0 ${e.h / 2 + 28})` } : { class: "rgz-readout-badge" });
                    return (
                      a.appendChild(
                        A("rect", {
                          class: "rgz-readout-bg",
                          x: -r / 2,
                          y: n - 17,
                          width: r,
                          height: 28,
                          rx: 9,
                        }),
                      ),
                      a.appendChild(
                        A(
                          "text",
                          {
                            class: "rgz-readout-text",
                            x: 0,
                            y: n + 2,
                            "text-anchor": "middle",
                          },
                          t,
                        ),
                      ),
                      a
                    );
                  })(t, n),
                ),
              r
            );
          })(e),
        ),
      ),
      Ne(),
      Ce(),
      Ke());
  }
  function U(e, t = 1, r = 0) {
    let n = e.vx || 0,
      a = e.vy || 0;
    return (
      Math.abs(n) < 1 && Math.abs(a) < 1 && ((n = t), (a = r)),
      Math.abs(n) >= Math.abs(a)
        ? { x: n >= 0 ? 1 : -1, y: 0 }
        : { x: 0, y: a >= 0 ? 1 : -1 }
    );
  }
  function G(e, t) {
    return "MPa" === t
      ? { value: e / 10, suffix: "MPa", decimals: 2 }
      : "psi" === t
        ? { value: 14.5038 * e, suffix: "psi", decimals: 0 }
        : { value: e, suffix: "bar", decimals: 1 };
  }
  function K(e) {
    return `${P(e.value, 0).toFixed(e.decimals)} ${e.suffix}`;
  }
  function _(e) {
    return (
      !!p.sim.running &&
      ["cylinderDA", "cylinderSA", "hydraulicMotor"].includes(e.type)
    );
  }
  function Z(e, t) {
    (e.append(A("circle", { class: "symbol-fill", cx: 0, cy: 0, r: 32 })),
      e.append(A("path", { class: "symbol-stroke", d: "M-58 0h26M32 0h26" })),
      e.append(
        A("path", { class: "symbol-accent", d: "M-8 15 L17 0 L-8 -15 Z" }),
      ),
      t &&
        e.append(
          A("path", {
            class: "symbol-accent",
            d: "M-32 32 L32 -32 M19 -32h13v13",
          }),
        ));
  }
  function W(e, t, r, n = !0) {
    t &&
      r &&
      (function (e, t, r = {}) {
        e.append(
          A(
            "path",
            Object.assign(
              {
                class: "symbol-stroke",
                d: t,
                "marker-end": r.arrow ? "url(#rgz-arrow)" : null,
              },
              r.attrs || {},
            ),
          ),
        );
      })(e, `M${t[0]} ${t[1]} L${r[0]} ${r[1]}`, { arrow: n });
  }
  function X(e, t) {
    if (!t) return;
    const [r, n] = t,
      a = n < 0 ? 1 : -1;
    e.append(
      A("path", {
        class: "symbol-muted",
        d: `M${r} ${n} v${10 * a} M${r - 7} ${n + 10 * a} h14`,
      }),
    );
  }
  function Y(e, t, r) {
    e.append(A("circle", { class: "symbol-muted", cx: t, cy: r, r: 2.2 }));
  }
  function Q(e, t) {
    const r = Number(t.props.positions || 3),
      n = Number(t.props.ports || 4),
      a = 2 === r ? 136 : 204,
      i = a / r;
    const _ps = 3 === r ? ["left", "center", "right"] : ["left", "right"],
      _sp = Math.max(
        0,
        _ps.indexOf(t.props.spoolState || (3 === r ? "center" : "left")),
      ),
      _sh = a / 2 - i * _sp - i / 2,
      h = A("g", { transform: "translate(" + _sh.toFixed(1) + " 0)" });
    (e.append(h),
      h.append(
        A("rect", {
          class: "symbol-fill",
          x: -a / 2,
          y: -39,
          width: a,
          height: 78,
          rx: 0,
        }),
      ));
    for (let t = 1; t < r; t++)
      h.append(
        A("path", { class: "symbol-muted", d: `M${-a / 2 + t * i} -39 v78` }),
      );
    L(t)
      .filter((e) => !["X", "Y"].includes(e.id))
      .forEach((t) => {
        const r = t.y < 0 ? 1 : -1;
        e.append(
          A("path", { class: "symbol-muted", d: `M${t.x} ${t.y} v${12 * r}` }),
        );
      });
    const o = 3 === r ? ["left", "center", "right"] : ["left", "right"];
    o.forEach((r, o) =>
      (function (e, t, r, n, a) {
        const i = (function (e, t) {
            return t <= 2
              ? { A: [e, -27], P: [e, 27] }
              : 3 === t
                ? { A: [e, -27], P: [e - 18, 27], T: [e + 18, 27] }
                : 5 === t
                  ? {
                      A: [e - 22, -27],
                      B: [e + 22, -27],
                      R: [e - 22, 27],
                      P: [e, 27],
                      S: [e + 22, 27],
                    }
                  : {
                      A: [e - 18, -27],
                      B: [e + 18, -27],
                      P: [e - 18, 27],
                      T: [e + 18, 27],
                    };
          })(t, n),
          o =
            "center" === r
              ? a.props.center || "closed"
              : "left" === r
                ? a.props.leftBlock || "parallel"
                : a.props.rightBlock || "crossover";
        // unified envelope drawer: every position renders its selected block pattern
        (function (e, t, r, n) {
          if ("closed" === r) return Object.values(t).forEach((t) => X(e, t));
          if ("tandem" === r)
            return void (5 === n
              ? (W(e, t.P, t.R, !0), W(e, t.P, t.S, !0), X(e, t.A), X(e, t.B))
              : t.P && t.T
                ? (W(e, t.P, t.T, !0), t.A && X(e, t.A), t.B && X(e, t.B))
                : (t.P && X(e, t.P), t.A && X(e, t.A), t.B && X(e, t.B), t.T && X(e, t.T)));
          if ("float" === r)
            return void (5 === n
              ? (W(e, t.A, t.R, !0), W(e, t.B, t.S, !0), X(e, t.P))
              : (t.A && t.T && W(e, t.A, t.T, !0),
                t.B && t.T && W(e, t.B, t.T, !0),
                t.P && X(e, t.P)));
          if ("regenerative" === r) {
            const r = t.P || [0, 0];
            return (
              t.P && t.A && W(e, t.P, t.A, !0),
              t.P && t.B && W(e, t.P, t.B, !0),
              t.P && t.A && Y(e, r[0], r[1] - 11),
              t.T && X(e, t.T),
              t.R && X(e, t.R),
              void (t.S && X(e, t.S))
            );
          }
          if ("parallel" === r)
            return void (5 === n
              ? (W(e, t.P, t.A, !0), W(e, t.B, t.S, !0), X(e, t.R))
              : 3 === n
                ? (W(e, t.P, t.A, !0), t.T && X(e, t.T))
                : 2 >= n
                  ? W(e, t.P, t.A, !0)
                  : (W(e, t.P, t.A, !0), W(e, t.B, t.T, !0)));
          if ("crossover" === r)
            return void (5 === n
              ? (W(e, t.P, t.B, !0), W(e, t.A, t.R, !0), X(e, t.S))
              : 3 === n
                ? (W(e, t.A, t.T, !0), t.P && X(e, t.P))
                : 2 >= n
                  ? (X(e, t.P), X(e, t.A))
                  : (W(e, t.P, t.B, !0), W(e, t.A, t.T, !0)));
          const a2 = Object.values(t),
            i2 = a2.reduce((e, t) => e + t[0], 0) / a2.length;
          (Y(e, i2, 0), a2.forEach((t) => W(e, t, [i2, 0], !1)));
        })(e, i, o, n);
      })(h, -a / 2 + i * o + i / 2, r, n, t),
    );
    const s = t.props.spoolState || (3 === r ? "center" : "left"),
      l = Math.max(0, o.indexOf(s)),
      c = -a / 2 + i * l + i / 2;
    (h.append(
      A("rect", {
        class: "symbol-accent",
        x: c - i / 2 + 4,
        y: -35,
        width: i - 8,
        height: 70,
        rx: 0,
      }),
    ),
      J(e, -a / 2 - 22, t.props.leftActuation || "manual", "left"),
      J(e, a / 2 + 22, t.props.rightActuation || "spring", "right"));
  }
  function J(e, t, r, n) {
    const a = "left" === n ? -1 : 1,
      i = -a,
      o = String(r || "").toLowerCase(),
      s = "symbol-muted";
    function l(r = !1) {
      (e.append(
        A("rect", {
          class: s,
          x: t - 12,
          y: -17,
          width: 24,
          height: 34,
          rx: 0,
        }),
      ),
        e.append(A("path", { class: s, d: `M${t - 8} 12 L${t + 8} -12` })),
        r &&
          e.append(
            A("path", {
              class: "symbol-accent",
              d: `M${t - 18} 22 L${t + 18} -22 M${t + 8} -22h10v10`,
            }),
          ));
    }
    o.includes("spring")
      ? (function () {
          const r = t + 4 * a,
            n = [];
          for (let e = 0; e <= 8; e++) n.push([r + a * e * 4, e % 2 ? -7 : 7]);
          e.append(
            A("path", {
              class: s,
              d: n.map((e, t) => `${t ? "L" : "M"}${e[0]} ${e[1]}`).join(" "),
            }),
          );
        })()
      : o.includes("proportional")
        ? l(!0)
        : o.includes("solenoid")
          ? l(!1)
          : o.includes("pilot")
            ? (function () {
                const r = t + 17 * i,
                  n = t - 17 * i;
                e.append(
                  A("path", { class: s, d: `M${n} -17 L${r} 0 L${n} 17 Z` }),
                );
              })()
            : o.includes("lever")
              ? (e.append(
                  A("circle", { class: s, cx: t - 5 * a, cy: 18, r: 3 }),
                ),
                e.append(
                  A("path", {
                    class: s,
                    d: `M${t - 5 * a} 18 L${t + 18 * a} -22`,
                  }),
                ),
                e.append(
                  A("circle", { class: s, cx: t + 20 * a, cy: -25, r: 5 }),
                ))
              : o.includes("roller")
                ? (e.append(
                    A("path", {
                      class: s,
                      d: `M${t - 18 * a} 0 H${t + 8 * a}`,
                    }),
                  ),
                  e.append(
                    A("circle", { class: s, cx: t + 15 * a, cy: 0, r: 7 }),
                  ))
                : o.includes("pedal")
                  ? (e.append(
                      A("path", {
                        class: s,
                        d: `M${t - 14 * a} 18 L${t + 18 * a} 0 L${t + 12 * a} -8`,
                      }),
                    ),
                    e.append(
                      A("path", { class: s, d: `M${t + 8 * a} -8 h${22 * a}` }),
                    ))
                  : o.includes("detent")
                    ? (e.append(
                        A("path", {
                          class: s,
                          d: `M${t - 18 * a} -14 h${36 * a} M${t - 18 * a} 14 h${36 * a}`,
                        }),
                      ),
                      e.append(A("circle", { class: s, cx: t, cy: -14, r: 3 })),
                      e.append(A("circle", { class: s, cx: t, cy: 14, r: 3 })))
                    : (e.append(
                        A("path", {
                          class: s,
                          d: `M${t} -17 v34 M${t - 12} -17 h24`,
                        }),
                      ),
                      e.append(
                        A("rect", {
                          class: s,
                          x: t - 8,
                          y: -27,
                          width: 16,
                          height: 8,
                          rx: 2,
                        }),
                      ));
  }
  function ee(e, t) {
    (e.append(A("path", { class: "symbol-stroke", d: "M-54 0h34M20 0h34" })),
      e.append(
        A("path", {
          class: "symbol-stroke",
          d: "M-18 -22 L18 22 M-18 22 L18 -22",
        }),
      ),
      e.append(
        A("path", {
          class: "symbol-accent",
          d: "M-32 26 L32 -26 M18 -26h14v14",
        }),
      ),
      t.props.pressureCompensated &&
        e.append(
          A("path", {
            class: "symbol-muted",
            d: "M-5 -30 q12 10 0 20 q-12 10 0 20 q12 10 0 20",
          }),
        ));
  }
  function te(e) {
    (e.append(A("path", { class: "symbol-stroke", d: "M-50 0h32M24 0h26" })),
      e.append(A("path", { class: "symbol-fill", d: "M-18 -22 V22 L24 0 Z" })),
      e.append(A("path", { class: "symbol-stroke", d: "M27 -24v48" })));
  }
  function re(e) {
    (te(e),
      e.append(
        A("path", { class: "symbol-muted", d: "M0 -44 v24 M-12 -34 h24" }),
      ));
  }
  function ne(e) {
    (e.append(
      A("rect", {
        class: "symbol-fill",
        x: -34,
        y: -28,
        width: 68,
        height: 56,
        rx: 4,
      }),
    ),
      e.append(
        A("path", {
          class: "symbol-stroke",
          d: "M-60 0h26M34 0h26M-18 14L18-14M6-14h12v12",
        }),
      ),
      e.append(
        A("path", {
          class: "symbol-muted",
          d: "M0 -48 v20M-10 -38h20M28 20c12-10 12-30 0-40",
        }),
      ));
  }
  function ae(e, t) {
    (e.append(
      A("rect", {
        class: "symbol-fill",
        x: -34,
        y: -28,
        width: 68,
        height: 56,
        rx: 4,
      }),
    ),
      e.append(
        A("path", { class: "symbol-stroke", d: "M-58 0h24M34 0h24M0 28v18" }),
      ),
      e.append(
        A("path", { class: "symbol-accent", d: "M-18 14L18-14M6-14h12v12" }),
      ),
      e.append(
        A(
          "text",
          { class: "port-label", x: 0, y: 5, "text-anchor": "middle" },
          t,
        ),
      ));
  }
  function ie(e, t) {
    const r = z(P(t.props.simPosition, 0.25), 0, 1),
      n = 38 + 58 * r;
    (e.append(
      A("rect", {
        class: "symbol-fill",
        x: -78,
        y: -22,
        width: 112,
        height: 44,
        rx: 2,
      }),
    ),
      e.append(
        A("path", { class: "symbol-stroke", d: `M${40 * r - 44} -22 v44` }),
      ),
      e.append(
        A("path", { class: "symbol-accent", d: `M${40 * r - 24} 0 H${n}` }),
      ),
      e.append(
        A("path", { class: "symbol-stroke", d: "M-82 34v-12M22 34v-12" }),
      ),
      e.append(A("path", { class: "symbol-muted", d: `M${n} -14 v28` })));
  }
  function oe(e, t) {
    const r = z(P(t.props.simPosition, 0.15), 0, 1),
      n = 24 + 66 * r;
    (e.append(
      A("rect", {
        class: "symbol-fill",
        x: -72,
        y: -22,
        width: 100,
        height: 44,
        rx: 2,
      }),
    ),
      e.append(
        A("path", { class: "symbol-accent", d: `M${44 * r - 22} 0 H${n}` }),
      ),
      e.append(
        A("path", {
          class: "symbol-muted",
          d: "M-54 -13 l28 26M-26 -13 l-28 26M-40 -13 l28 26",
        }),
      ),
      e.append(A("path", { class: "symbol-stroke", d: "M-76 34v-12" })),
      e.append(A("path", { class: "symbol-muted", d: `M${n} -14 v28` })));
  }
  function se(e, t) {
    const r = P(t.props.simAngle, 0);
    (e.append(A("circle", { class: "symbol-fill", cx: 0, cy: 0, r: 32 })),
      e.append(A("path", { class: "symbol-stroke", d: "M-58 0h26M32 0h26" })),
      e.append(
        A("path", {
          class: "symbol-accent",
          d: `M0 0 L${22 * Math.cos(r)} ${22 * Math.sin(r)} M0 0 L${22 * Math.cos(r + Math.PI)} ${22 * Math.sin(r + Math.PI)}`,
        }),
      ),
      e.append(
        A("path", { class: "symbol-stroke", d: "M10 -14 L-16 0 L10 14 Z" }),
      ));
  }
  function le(e) {
    (e.append(
      A("path", {
        class: "symbol-fill",
        d: "M-30 48 V-12 a30 30 0 0 1 60 0 v60 Z",
      }),
    ),
      e.append(A("path", { class: "symbol-muted", d: "M-25 2 q25 -18 50 0" })),
      e.append(A("path", { class: "symbol-stroke", d: "M0 48v4" })));
  }
  function ce(e) {
    (e.append(A("circle", { class: "symbol-fill", cx: 0, cy: 0, r: 34 })),
      e.append(
        A("path", {
          class: "symbol-stroke",
          d: "M0 50V20M0 18L-35 -10M0 18L35 -10",
        }),
      ),
      e.append(
        A("path", { class: "symbol-accent", d: "M0 18L-20 2M0 18L20 2" }),
      ));
  }
  function de(e) {
    (e.append(
      A("path", { class: "symbol-fill", d: "M-30 0 L0 -28 L30 0 L0 28 Z" }),
    ),
      e.append(
        A("path", {
          class: "symbol-stroke",
          d: "M-52 0h22M30 0h22M-16 -14 L16 14M16 -14 L-16 14",
        }),
      ));
  }
  function pe(e) {
    (e.append(
      A("rect", {
        class: "symbol-fill",
        x: -34,
        y: -24,
        width: 68,
        height: 48,
        rx: 3,
      }),
    ),
      e.append(
        A("path", {
          class: "symbol-stroke",
          d: "M-56 0h22M34 0h22M-22 -12 h44M-22 0h44M-22 12h44",
        }),
      ),
      e.append(
        A("path", {
          class: "symbol-accent",
          d: "M-28 30 L28 -30M14 -30h14v14",
        }),
      ));
  }
  function ue(e) {
    (e.append(A("circle", { class: "symbol-fill", cx: 0, cy: -8, r: 30 })),
      e.append(
        A("path", { class: "symbol-stroke", d: "M0 22v24M0-8l17-15M-16-8h32" }),
      ));
  }
  function me(e) {
    (e.append(A("circle", { class: "symbol-fill", cx: 0, cy: 0, r: 28 })),
      e.append(
        A("path", {
          class: "symbol-stroke",
          d: "M-54 0h26M28 0h26M-8 12L13 0-8-12",
        }),
      ),
      e.append(
        A(
          "text",
          { class: "port-label", x: 0, y: 5, "text-anchor": "middle" },
          "Q",
        ),
      ));
  }
  function ye(e) {
    return e.props?.active ? "symbol-accent" : "symbol-muted";
  }
  function he(e, t, r, n, a = 12) {
    e.append(
      A(
        "text",
        {
          class: "port-label",
          x: r,
          y: n,
          "text-anchor": "middle",
          "font-size": a,
        },
        t,
      ),
    );
  }
  function ge(e, t) {
    e.append(A("path", { class: "symbol-stroke", d: t }));
  }
  function ve(e, t = -30, r = 28, n = 30, a = -28) {
    e.append(
      A("path", {
        class: "symbol-accent",
        d: `M${t} ${r} L${n} ${a} M${n - 12} ${a}h12v12`,
      }),
    );
  }
  function fe(e, t = 28, r = -24, n = 24, a = 1) {
    const i = [];
    for (let e = 0; e <= 8; e++)
      i.push([t + (e % 2 ? 7 * a : 0), r + ((n - r) * e) / 8]);
    e.append(
      A("path", {
        class: "symbol-muted",
        d: i.map((e, t) => `${t ? "L" : "M"}${e[0]} ${e[1]}`).join(" "),
      }),
    );
  }
  function be(e, t = 0, r = 0, n = 1) {
    (e.append(
      A("path", {
        class: "symbol-fill",
        d: `M${t - 18 * n} ${r - 18} L${t - 18 * n} ${r + 18} L${t + 16 * n} ${r} Z`,
      }),
    ),
      e.append(
        A("path", {
          class: "symbol-stroke",
          d: `M${t + 19 * n} ${r - 22} v44`,
        }),
      ));
  }
  function ee(e, t) {
    (ge(e, "M-54 0h32M22 0h32"),
      e.append(
        A("path", {
          class: "symbol-stroke",
          d: "M-20 -18 L20 18 M-20 18 L20 -18",
        }),
      ),
      ve(e, -34, 28, 34, -28),
      t.props &&
        t.props.pressureCompensated &&
        e.append(
          A("path", {
            class: "symbol-muted",
            d: "M-4 -34 q12 8 0 16 q-12 8 0 16 q12 8 0 16 q-12 8 0 16",
          }),
        ));
  }
  function te(e) {
    (ge(e, "M-50 0h28M28 0h22"), be(e, 0, 0, 1));
  }
  function re(e) {
    (te(e),
      e.append(
        A("path", { class: "symbol-muted", d: "M0 -44 v22 M-12 -34h24" }),
      ),
      e.append(
        A("path", { class: "symbol-muted", d: "M-16 -42 L0 -22 L16 -42" }),
      ));
  }
  function ne(e) {
    (e.append(
      A("rect", {
        class: "symbol-fill",
        x: -36,
        y: -28,
        width: 72,
        height: 56,
        rx: 0,
      }),
    ),
      ge(e, "M-60 0h24M36 0h24"),
      be(e, -4, 0, 1),
      ve(e, -20, 20, 24, -20),
      fe(e, 30, -22, 22, -1),
      e.append(
        A("path", { class: "symbol-muted", d: "M0 -48v20 M-10 -38h20" }),
      ));
  }
  function ae(e, t) {
    (e.append(
      A("rect", {
        class: "symbol-fill",
        x: -36,
        y: -28,
        width: 72,
        height: 56,
        rx: 0,
      }),
    ),
      ge(e, "M-58 0h22M36 0h22"),
      be(e, -4, 0, 1),
      fe(e, 30, -22, 22, -1),
      ve(e, -22, 22, 20, -20),
      he(e, t, 0, 44, 10));
  }
  function Z(e, t) {
    (e.append(A("circle", { class: "symbol-fill", cx: 0, cy: 0, r: 31 })),
      ge(e, "M-58 0h27M31 0h27"),
      e.append(
        A("path", { class: "symbol-stroke", d: "M-9 14 L16 0 L-9 -14 Z" }),
      ),
      t && ve(e, -32, 32, 32, -32));
  }
  function se(e, t) {
    const r = P(t?.props?.simAngle, 0);
    (e.append(A("circle", { class: "symbol-fill", cx: 0, cy: 0, r: 31 })),
      ge(e, "M-58 0h27M31 0h27"),
      e.append(
        A("path", { class: "symbol-stroke", d: "M12 -14 L-14 0 L12 14 Z" }),
      ),
      e.append(
        A("path", {
          class: "symbol-accent",
          d: `M0 0 L${20 * Math.cos(r)} ${20 * Math.sin(r)} M0 0 L${20 * Math.cos(r + Math.PI)} ${20 * Math.sin(r + Math.PI)}`,
        }),
      ));
  }
  function ie(e, t) {
    const r = z(P(t?.props?.simPosition, 0.25), 0, 1),
      n = 64 * r - 52,
      a = 74 + 10 * r;
    (e.append(
      A("rect", {
        class: "symbol-fill",
        x: -78,
        y: -20,
        width: 110,
        height: 40,
        rx: 0,
      }),
    ),
      e.append(
        A("path", { class: "symbol-stroke", d: `M${n} -20v40 M${n} 0H${a}` }),
      ),
      e.append(A("path", { class: "symbol-muted", d: `M${a} -12v24` })),
      ge(e, "M-82 34v-14M22 34v-14"));
  }
  function oe(e, t) {
    const r = z(P(t?.props?.simPosition, 0.15), 0, 1),
      n = 52 * r - 48,
      a = 62 + 12 * r;
    (e.append(
      A("rect", {
        class: "symbol-fill",
        x: -72,
        y: -20,
        width: 96,
        height: 40,
        rx: 0,
      }),
    ),
      e.append(
        A("path", { class: "symbol-stroke", d: `M${n} -20v40 M${n} 0H${a}` }),
      ),
      e.append(
        A("path", {
          class: "symbol-muted",
          d: "M-58 -12 l24 24 M-34 -12 l-24 24 M-46 -12 l24 24",
        }),
      ),
      e.append(A("path", { class: "symbol-muted", d: `M${a} -12v24` })),
      ge(e, "M-76 34v-14"));
  }
  function le(e) {
    (e.append(
      A("path", {
        class: "symbol-fill",
        d: "M-30 46 V-10 a30 30 0 0 1 60 0 v56 Z",
      }),
    ),
      e.append(A("path", { class: "symbol-muted", d: "M-26 -2 q26 -16 52 0" })),
      ge(e, "M0 46v10"));
  }
  function ce(e) {
    (e.append(A("circle", { class: "symbol-fill", cx: 0, cy: 0, r: 32 })),
      ge(e, "M0 50V20M0 18L-38 -10M0 18L38 -10"),
      e.append(
        A("path", {
          class: "symbol-stroke",
          d: "M0 18L-18 4M0 18L18 4",
          "marker-end": "url(#rgz-arrow)",
        }),
      ));
  }
  function de(e) {
    (e.append(
      A("path", { class: "symbol-fill", d: "M-30 0 L0 -28 L30 0 L0 28 Z" }),
    ),
      ge(e, "M-52 0h22M30 0h22"),
      e.append(
        A("path", {
          class: "symbol-muted",
          d: "M-15 -14 L15 14 M15 -14 L-15 14",
        }),
      ));
  }
  function pe(e) {
    (e.append(
      A("rect", {
        class: "symbol-fill",
        x: -34,
        y: -24,
        width: 68,
        height: 48,
        rx: 0,
      }),
    ),
      ge(e, "M-56 0h22M34 0h22"),
      e.append(
        A("path", {
          class: "symbol-muted",
          d: "M-24 -12h48M-24 0h48M-24 12h48",
        }),
      ),
      ve(e, -28, 30, 28, -30));
  }
  function ue(e) {
    (e.append(A("circle", { class: "symbol-fill", cx: 0, cy: -8, r: 28 })),
      ge(e, "M0 20v26"),
      e.append(
        A("path", { class: "symbol-stroke", d: "M0 -8l16 -13M-15 -8h30" }),
      ));
  }
  function me(e) {
    (e.append(A("circle", { class: "symbol-fill", cx: 0, cy: 0, r: 28 })),
      ge(e, "M-54 0h26M28 0h26"),
      he(e, "Q", 0, 5, 16),
      e.append(A("path", { class: "symbol-stroke", d: "M-10 12L14 0-10-12" })));
  }
  function xe(e, t = "") {
    (e.append(
      A("rect", {
        class: "symbol-muted",
        x: -46,
        y: -34,
        width: 92,
        height: 68,
        rx: 0,
        "stroke-dasharray": "8 5",
      }),
    ),
      e.append(
        A("path", { class: "symbol-muted", d: "M-34 -34v68M34 -34v68" }),
      ),
      t && he(e, t, 0, 49, 9));
  }
  function we(e, t = "") {
    (xe(e, t),
      ge(e, "M-60 0h24M36 0h24M0 -48v14"),
      e.append(A("path", { class: "symbol-fill", d: "M-18 -18v36L18 0Z" })),
      e.append(A("path", { class: "symbol-stroke", d: "M21 -22v44" })),
      fe(e, 30, -21, 21, -1),
      e.append(A("path", { class: "symbol-muted", d: "M0 -34v14M-10 -28h20" })),
      he(e, "X", 0, -54, 9));
  }
  function ke() {
    const e = p.selected
      ? "component" === p.selected.kind
        ? p.components.find((e) => e.id === p.selected.id) || null
        : ("connection" === p.selected.kind &&
            p.connections.find((e) => e.id === p.selected.id)) ||
          null
      : null;
    ((g.innerHTML = `\n      <div class="rgz-section-title"><h2>02 — Inspector</h2><span class="rgz-badge">client-side</span></div>\n      <div class="rgz-tabs">\n        <button class="rgz-tab ${"properties" === p.inspectorTab ? "active" : ""}" data-tab="properties">Properties</button>\n        <button class="rgz-tab ${"simulation" === p.inspectorTab ? "active" : ""}" data-tab="simulation">Simulation</button>\n        <button class="rgz-tab ${"calculator" === p.inspectorTab ? "active" : ""}" data-tab="calculator">Piping</button>\n      </div>\n      <div id="rgz-inspector-panel"></div>\n    `),
      g.querySelectorAll("[data-tab]").forEach((e) => {
        e.addEventListener("click", () => {
          ((p.inspectorTab = e.dataset.tab), ke());
        });
      }));
    const t = g.querySelector("#rgz-inspector-panel");
    ("properties" === p.inspectorTab &&
      (function (e, t) {
        if (!t)
          return (
            (e.innerHTML = `\n        <div class="rgz-panel">\n          <div class="rgz-panel-title">Project properties</div>\n          ${Me("projectName", "Project name")}\n          ${Me("designer", "Designer")}\n          ${Me("standard", "Print/sketching standard")}\n          ${Me("revision", "Revision")}\n          <div class="rgz-field"><label>Notes</label><textarea data-project-field="notes">${M(p.projectMeta.notes)}</textarea></div>\n          <p>Select a symbol or line to edit its properties. Drag symbols from the left library. Click ports to connect lines.</p>\n        </div>\n        <div class="rgz-panel"><div class="rgz-panel-title">Export and print guarantee</div><p>Printed drawings and RGZ project metadata include ${r}. Encrypted .rgz files are processed in the browser and are not uploaded.</p></div>\n      `),
            void (function (e) {
              e.querySelectorAll("[data-project-field]").forEach((e) => {
                e.addEventListener("input", () => {
                  ((p.projectMeta[e.dataset.projectField] = e.value), Ke());
                });
              });
            })(e)
          );
        if ("connection" === p.selected.kind)
          return (
            (e.innerHTML =
              (((n = t).properties = n.properties || {}),
              `\n      <div class="rgz-panel">\n        <div class="rgz-panel-title">Connection line</div>\n        <div class="rgz-kv">\n          <div class="rgz-kv-row"><span>From</span><span>${M(n.from.componentId)}.${M(n.from.portId)}</span></div>\n          <div class="rgz-kv-row"><span>To</span><span>${M(n.to.componentId)}.${M(n.to.portId)}</span></div>\n        </div>\n        <div class="rgz-field"><label>Line type</label><select class="rgz-small-input" data-conn-field="lineType">${["pressure", "return", "pilot", "drain", "electrical"].map((e) => `<option value="${e}" ${n.lineType === e ? "selected" : ""}>${e}</option>`).join("")}</select></div>\n        <div class="rgz-field-grid">\n          <div class="rgz-field"><label>Line color</label><input class="rgz-small-input" type="color" data-conn-prop="color" value="${M(n.properties.color || Ae(n.lineType))}" /></div>\n          <div class="rgz-field"><label>Line thickness</label><input class="rgz-small-input" type="number" min="1" max="9" step="0.5" data-conn-prop="strokeWidth" value="${M(n.properties.strokeWidth ?? 3)}" /></div>\n        </div>\n        <div class="rgz-field"><label>Line shape</label><select class="rgz-small-input" data-conn-prop="routeMode">${["auto", "horizontal-first", "vertical-first", "straight"].map((e) => `<option value="${e}" ${n.properties.routeMode === e ? "selected" : ""}>${e}</option>`).join("")}</select></div>\n        <div class="rgz-field"><label>Manual shift / offset</label><input class="rgz-small-input" type="range" min="-120" max="120" step="5" data-conn-prop="shift" value="${M(n.properties.shift ?? 0)}" /></div>\n        <div class="rgz-field-grid">\n          <div class="rgz-field"><label>Tube/hose ID, mm</label><input class="rgz-small-input" type="number" step="0.1" data-conn-prop="tubeIdMm" value="${M(n.properties.tubeIdMm ?? 12)}" /></div>\n          <div class="rgz-field"><label>Length, m</label><input class="rgz-small-input" type="number" step="0.1" data-conn-prop="lengthM" value="${M(n.properties.lengthM ?? 1)}" /></div>\n        </div>\n        <div class="rgz-field"><label>Max pressure, bar</label><input class="rgz-small-input" type="number" step="1" data-conn-prop="maxPressureBar" value="${M(n.properties.maxPressureBar ?? 250)}" /></div>\n        <button class="rgz-btn danger" style="width:100%;margin-top:12px" data-action="delete-selected">Delete line</button>\n      </div>\n    `)),
            void (function (e, t) {
              (e.querySelectorAll("[data-conn-field]").forEach((e) => {
                e.addEventListener("change", () => {
                  ((t[e.dataset.connField] = e.value), H());
                });
              }),
                e.querySelectorAll("[data-conn-prop]").forEach((e) => {
                  const r = () => {
                    const r = e.dataset.connProp;
                    ((t.properties[r] =
                      "number" === e.type || "range" === e.type
                        ? P(e.value)
                        : e.value),
                      H());
                  };
                  (e.addEventListener("input", r),
                    e.addEventListener("change", r));
                }));
            })(e, t)
          );
        var n;
        const a = t,
          i = $(a.type),
          o = [
            `<div class="rgz-field"><label>Label</label><input class="rgz-small-input" data-comp-field="label" value="${M(a.label || "")}" /></div>`,
            `<div class="rgz-field-grid"><div class="rgz-field"><label>X</label><input class="rgz-small-input" data-comp-field="x" type="number" value="${P(a.x)}" /></div><div class="rgz-field"><label>Y</label><input class="rgz-small-input" data-comp-field="y" type="number" value="${P(a.y)}" /></div></div>`,
            `<div class="rgz-field"><label>Rotation</label><input class="rgz-small-input" data-comp-field="rotation" type="number" step="90" value="${P(a.rotation)}" /></div>`,
          ];
        ((i.propSchema || []).forEach((e) => o.push(ze(a, e))),
          (e.innerHTML = `\n      <div class="rgz-panel">\n        <div class="rgz-panel-title">${M(i.name)}</div>\n        <p>${M(i.desc)}</p>\n        ${o.join("")}\n        <div class="rgz-field-grid" style="margin-top:12px">\n          <button class="rgz-btn" data-action="rotate-selected-ccw">Rotate -90°</button>\n          <button class="rgz-btn" data-action="rotate-selected">Rotate +90°</button>\n          <button class="rgz-btn" data-action="duplicate-selected">Duplicate</button>\n          <button class="rgz-btn danger" data-action="delete-selected">Delete</button>\n        </div>\n      </div>\n      <div class="rgz-panel">\n        <div class="rgz-panel-title">Ports</div>\n        <div class="rgz-kv">${B(
            a,
          )
            .map(
              (e) =>
                `<div class="rgz-kv-row"><span>${M(e.id)}</span><span>${M(e.kind)}${e.required ? " · required" : ""}</span></div>`,
            )
            .join("")}</div>\n      </div>\n    `),
          Se(e, a));
      })(t, e),
      "simulation" === p.inspectorTab &&
        (function (e) {
          const t = p.sim.metrics || {},
            r = t.cylinders || [],
            n = t.motors || [],
            a = t.warnings || [];
          ((e.innerHTML = `\n      <div class="rgz-panel">\n        <div class="rgz-panel-title">Simulation engine</div>\n        <div class="rgz-kv">\n          <div class="rgz-kv-row"><span>Status</span><span>${p.sim.running ? "Running" : "Idle"}</span></div>\n          <div class="rgz-kv-row"><span>Time</span><span>${p.sim.time.toFixed(2)} s</span></div>\n          <div class="rgz-kv-row"><span>Time scale</span><span>${P(p.sim.timeScale, 1).toFixed(2)}×</span></div>\n          <div class="rgz-kv-row"><span>Solver</span><span>Browser Web Worker + SVG animation</span></div>\n          <div class="rgz-kv-row"><span>Pump flow</span><span>${P(t.totalFlowLpm, 0).toFixed(1)} L/min</span></div>\n          <div class="rgz-kv-row"><span>Active circuit flow</span><span>${P(t.activeFlowLpm, 0).toFixed(1)} L/min</span></div>\n          <div class="rgz-kv-row"><span>Estimated pressure</span><span>${P(t.pressureBar, 0).toFixed(1)} bar</span></div>\n          <div class="rgz-kv-row"><span>Hydraulic power</span><span>${P(t.powerKw, 0).toFixed(2)} kW</span></div>\n        </div>\n        <p>This V1 solver estimates flow, pressure state, cylinder speed/force, line velocity and pressure-drop risk. It runs on the user's CPU, not the server.</p>\n      </div>\n      <div class="rgz-panel">\n        <div class="rgz-panel-title">Time scale</div>\n        <div class="rgz-field-grid">\n          <div class="rgz-field"><label>Speed multiplier, 0.00–3.00</label><input class="rgz-small-input" type="range" min="0" max="3" step="0.01" data-time-scale value="${P(p.sim.timeScale, 1)}" /></div>\n          <div class="rgz-field"><label>Current scale</label><input class="rgz-small-input" type="number" min="0" max="3" step="0.01" data-time-scale value="${P(p.sim.timeScale, 1).toFixed(2)}" /></div>\n        </div>\n        <p>1.00× is real time. Use values below 1.00 for slow motion and above 1.00 for faster simulation. 0.00 pauses motion without stopping simulation.</p>\n      </div>\n      <div class="rgz-panel">\n        <div class="rgz-panel-title">Actuator states</div>\n        <div class="rgz-kv">\n          ${r.length ? r.map((e) => `<div class="rgz-kv-row"><span>${M(e.label)}</span><span>${P(e.speedMmS).toFixed(1)} mm/s · ${P(e.forceKN).toFixed(1)} kN</span></div>`).join("") : ""}\n          ${n.length ? n.map((e) => `<div class="rgz-kv-row"><span>${M(e.label)}</span><span>${P(e.flowLpm).toFixed(1)} L/min · ${P(e.rpm).toFixed(0)} rpm</span></div>`).join("") : ""}\n          ${r.length || n.length ? "" : '<div class="rgz-message info">No actuator metrics yet. Start simulation with a valid circuit.</div>'}\n        </div>\n      </div>\n      <div class="rgz-panel">\n        <div class="rgz-panel-title">Control console</div>\n        ${(function () {
            const e = [];
            return (
              p.components.forEach((t) => {
                if (C(t)) {
                  const r = [
                    "left",
                    ...(3 === Number(t.props.positions || 3) ? ["center"] : []),
                    "right",
                  ]
                    .map(
                      (e) =>
                        `<button class="rgz-btn ${t.props.spoolState === e ? "primary" : ""}" data-control-kind="valve" data-id="${M(t.id)}" data-value="${e}">${e}</button>`,
                    )
                    .join("");
                  e.push(
                    `<div class="rgz-message info"><strong>${M(t.label || t.id)} — valve spool</strong><div class="rgz-field-grid" style="margin-top:8px">${r}</div></div>`,
                  );
                }
                ("pushButton" === t.type &&
                  e.push(
                    `<div class="rgz-message info"><strong>${M(t.label || t.id)} — push button</strong><button class="rgz-btn ${t.props.pressed ? "primary" : ""}" style="width:100%;margin-top:8px" data-control-kind="pushButton" data-id="${M(t.id)}">${t.props.pressed ? "Release button" : "Push button"}</button></div>`,
                  ),
                  "plc" === t.type &&
                    e.push(
                      `<div class="rgz-message info"><strong>${M(t.label || t.id)} — PLC program</strong><div style="font-size:11px;line-height:1.55;margin-top:6px">Rungs separated by <code>;</code><br><b>Latched rule</b>: <code>COND -&gt; TARGET VALUE</code> &nbsp;e.g. <code>PB1 AND NOT B1 -&gt; V1 left</code><br><b>Combinatorial</b>: <code>OUT = COND</code> &nbsp;e.g. <code>Q1 = PB1 OR Q1 AND NOT B1</code> (seal-in; cleared when false)<br>Signals = component labels/ids (PB1, B1, PS1, K1…); <code>I1..I4/Q1..Q4</code> = wired pins. Terms: <code>NOT AND , &amp; OR |</code>. Values: valves <code>left/right/center</code> (extend/retract/stop), coils &amp; relays <code>on/off</code>, timers <code>start/reset</code> (term true after its delay). Coils drive valves: odd digit &rarr; left, even &rarr; right (Y1/Y2). PLC valve rungs override coils.</div></div>`,
                    ),
                  "solenoid" === t.type &&
                    e.push(
                      `<div class="rgz-message info"><strong>${M(t.label || t.id)} — solenoid coil</strong><button class="rgz-btn ${t.props.energized ? "primary" : ""}" style="width:100%;margin-top:8px" data-control-kind="solenoid" data-id="${M(t.id)}">${t.props.energized ? "De-energize" : "Energize"}</button></div>`,
                    ),
                  "servoValve" === t.type &&
                    e.push(
                      `<div class="rgz-message info"><strong>${M(t.label || t.id)} — proportional command</strong><div class="rgz-field-grid" style="margin-top:8px"><input class="rgz-small-input" type="range" min="-100" max="100" step="1" data-live-prop="commandPercent" data-id="${M(t.id)}" value="${P(t.props.commandPercent, 0)}" /><input class="rgz-small-input" type="number" min="-100" max="100" step="1" data-live-prop="commandPercent" data-id="${M(t.id)}" value="${P(t.props.commandPercent, 0)}" /></div></div>`,
                    ),
                  "proportionalAmplifier" === t.type &&
                    e.push(
                      `<div class="rgz-message info"><strong>${M(t.label || t.id)} — amplifier output</strong><div class="rgz-field-grid" style="margin-top:8px"><input class="rgz-small-input" type="range" min="-100" max="100" step="1" data-live-prop="outputPercent" data-id="${M(t.id)}" value="${P(t.props.outputPercent, 0)}" /><input class="rgz-small-input" type="number" min="-100" max="100" step="1" data-live-prop="outputPercent" data-id="${M(t.id)}" value="${P(t.props.outputPercent, 0)}" /></div></div>`,
                    ),
                  [
                    "limitSwitch",
                    "cylinderReedSensor",
                    "linearPositionSensor",
                    "proximitySensor",
                    "pressureSwitch",
                    "pressureTransducer",
                    "flowSwitch",
                    "temperatureSwitch",
                    "levelSwitch",
                  ].includes(t.type) &&
                    e.push(
                      `<div class="rgz-message ${t.props.active ? "ok" : "info"}"><strong>${M(t.label || t.id)} — sensor feedback</strong><br>Status: ${t.props.active ? "ACTIVE" : "inactive"}${t.props.action && "none" !== t.props.action ? `<br>Action: ${M(t.props.action)} ${t.props.targetControl ? "→ " + M(t.props.targetControl) : ""}` : ""}</div>`,
                    ));
              }),
              e.length
                ? e.join("")
                : '<div class="rgz-message info"><strong>No controllable equipment</strong><br>Add a directional valve, push button, solenoid, or feedback sensor to use live controls.</div>'
            );
          })()}\n        <p>Use these controls during simulation. Double-click any equipment on the canvas to edit its real-world characteristics.</p>\n      </div>\n      <div class="rgz-panel">\n        <div class="rgz-panel-title">Advanced simulation warnings</div>\n        ${a.length ? a.map((e) => `<div class="rgz-message warning"><strong>Warning</strong><br>${M(e)}</div>`).join("") : '<div class="rgz-message ok"><strong>OK</strong><br>No advanced solver warnings.</div>'}\n      </div>\n      <div class="rgz-disclaimer">Disclaimer: results are approximate and suitable for educational/preliminary design only. Validate final systems with qualified engineering review and applicable standards.</div>\n    `),
            (function (e) {
              e.querySelectorAll("[data-live-prop]").forEach((t) => {
                const r = () => {
                  const r = p.components.find((e) => e.id === t.dataset.id);
                  r &&
                    ((r.props[t.dataset.liveProp] = P(t.value, 0)),
                    e
                      .querySelectorAll(
                        `[data-live-prop="${t.dataset.liveProp}"][data-id="${t.dataset.id}"]`,
                      )
                      .forEach((e) => {
                        e !== t && (e.value = t.value);
                      }),
                    H());
                };
                (t.addEventListener("input", r),
                  t.addEventListener("change", r));
              });
            })(e),
            (function (e) {
              e.querySelectorAll("[data-time-scale]").forEach((t) => {
                (t.addEventListener("input", () => {
                  const r = z(P(t.value, 1), 0, 3);
                  ((p.sim.timeScale = r),
                    e.querySelectorAll("[data-time-scale]").forEach((e) => {
                      e !== t &&
                        (e.value = "number" === e.type ? r.toFixed(2) : r);
                    }));
                }),
                  t.addEventListener("change", () => {
                    const e = z(P(t.value, 1), 0, 3);
                    ((p.sim.timeScale = e),
                      (t.value = "number" === t.type ? e.toFixed(2) : e));
                  }));
              });
            })(e));
        })(t),
      "calculator" === p.inspectorTab &&
        (function (e) {
          const t = (function () {
            const e = Math.max(1e-6, P(p.calc.flowLpm, 0) / 6e4),
              t = Math.max(0.01, P(p.calc.velocityMps, Be(p.calc.lineType))),
              r = 1e3 * Math.sqrt((4 * e) / (Math.PI * t)),
              n = [4, 5, 6, 8, 10, 12, 13, 16, 19, 20, 25, 32, 38, 50, 63, 75],
              a = n.find((e) => e >= r) || n[n.length - 1],
              i = Math.max(0.001, P(p.calc.diameterMm, a) / 1e3),
              o = e / ((Math.PI * i * i) / 4),
              s = P(p.calc.densityKgM3, 870),
              l = 1e-6 * P(p.calc.viscosityCSt, 46),
              c = (o * i) / Math.max(l, 1e-9);
            let d;
            d = c < 2300 ? 64 / Math.max(c, 1) : 0.3164 / Math.pow(c, 0.25);
            const u =
                (((d * Math.max(0, P(p.calc.lengthM, 1))) / i +
                  Math.max(0, P(p.calc.fittingK, 0))) *
                  ((s * o * o) / 2)) /
                1e5,
              m = [],
              y = {
                suction: { min: 0.6, max: 1.2 },
                return: { min: 1.5, max: 3 },
                pressure: { min: 3, max: 6 },
                drain: { min: 0.5, max: 2 },
                pilot: { min: 0.5, max: 3 },
              }[p.calc.lineType] || { min: 1, max: 6 };
            return (
              o > y.max &&
                m.push({
                  type: "warning",
                  text: `Velocity is higher than the recommended ${y.min}–${y.max} m/s range for ${p.calc.lineType} lines.`,
                }),
              o < y.min &&
                m.push({
                  type: "info",
                  text: `Velocity is below the usual ${y.min}–${y.max} m/s range; the line may be oversized but pressure drop will be lower.`,
                }),
              u > 5 &&
                m.push({
                  type: "warning",
                  text: "Estimated pressure drop is high. Increase ID, reduce length, or reduce fitting losses.",
                }),
              m.length ||
                m.push({
                  type: "ok",
                  text: "Sizing looks reasonable for preliminary design.",
                }),
              {
                recommendedDiameterMm: r,
                nearestStandardMm: a,
                actualVelocityMps: o,
                reynolds: c,
                pressureDropBar: u,
                messages: m,
              }
            );
          })();
          ((e.innerHTML = `\n      <div class="rgz-panel">\n        <div class="rgz-panel-title">Pipe / hose sizing calculator</div>\n        <div class="rgz-field-grid">\n          ${Le("flowLpm", "Flow, L/min", 0.1)}\n          <div class="rgz-field"><label>Line type</label><select class="rgz-small-input" data-calc="lineType">${["suction", "pressure", "return", "drain", "pilot"].map((e) => `<option value="${e}" ${p.calc.lineType === e ? "selected" : ""}>${e}</option>`).join("")}</select></div>\n          ${Le("velocityMps", "Target velocity, m/s", 0.1)}\n          ${Le("diameterMm", "Candidate ID, mm", 0.1)}\n          ${Le("lengthM", "Length, m", 0.1)}\n          ${Le("fittingK", "Fittings K total", 0.1)}\n          ${Le("densityKgM3", "Oil density, kg/m³", 1)}\n          ${Le("viscosityCSt", "Viscosity, cSt", 0.1)}\n        </div>\n        <div class="rgz-kv">\n          <div class="rgz-kv-row"><span>Recommended ID</span><span>${t.recommendedDiameterMm.toFixed(1)} mm</span></div>\n          <div class="rgz-kv-row"><span>Nearest standard ID</span><span>${t.nearestStandardMm} mm</span></div>\n          <div class="rgz-kv-row"><span>Actual velocity</span><span>${t.actualVelocityMps.toFixed(2)} m/s</span></div>\n          <div class="rgz-kv-row"><span>Reynolds number</span><span>${Math.round(t.reynolds).toLocaleString()}</span></div>\n          <div class="rgz-kv-row"><span>Estimated Δp</span><span>${t.pressureDropBar.toFixed(3)} bar</span></div>\n        </div>\n        ${t.messages.map((e) => `<div class="rgz-message ${e.type}"><strong>${e.type.toUpperCase()}</strong><br>${M(e.text)}</div>`).join("")}\n        <p>Formula: Q = A × v. Pressure drop uses Darcy-Weisbach with a simplified friction-factor estimate.</p>\n      </div>\n      ${(function () {
            const e = p.components.find(
                (e) => "cylinderDA" === e.type || "cylinderSA" === e.type,
              ),
              t = p.components.find(
                (e) =>
                  "pumpFixed" === e.type ||
                  "pumpVariable" === e.type ||
                  "powerPack" === e.type,
              ),
              r = De(),
              n = Math.max(1, P(e?.props?.boreMm, 50)),
              a = Math.max(0, P(e?.props?.rodMm, 0)),
              i = Math.max(1, P(e?.props?.strokeMm, 300)),
              o = Math.max(0, P(t?.props?.flowLpm, 20)),
              s = (Math.PI * Math.pow(n / 1e3, 2)) / 4,
              l = Math.max(0.1 * s, s - (Math.PI * Math.pow(a / 1e3, 2)) / 4),
              c = (1e5 * r * s) / 1e3,
              d = (1e5 * r * l) / 1e3,
              u = (o / 6e4 / s) * 1e3,
              m = (o / 6e4 / l) * 1e3,
              y = (r * o) / 600,
              h = i / Math.max(u, 0.001);
            return `<div class="rgz-panel"><div class="rgz-panel-title">Hydraulic formula assistant</div><div class="rgz-kv">\n      <div class="rgz-kv-row"><span>Cylinder area extend/retract</span><span>${(1e6 * s).toFixed(0)} / ${(1e6 * l).toFixed(0)} mm²</span></div>\n      <div class="rgz-kv-row"><span>Force at relief pressure</span><span>${c.toFixed(1)} / ${d.toFixed(1)} kN</span></div>\n      <div class="rgz-kv-row"><span>Speed at pump flow</span><span>${u.toFixed(1)} / ${m.toFixed(1)} mm/s</span></div>\n      <div class="rgz-kv-row"><span>Approx. extension time</span><span>${h.toFixed(2)} s</span></div>\n      <div class="rgz-kv-row"><span>Hydraulic power</span><span>${y.toFixed(2)} kW</span></div>\n    </div><p>Core relations: p = F/A, Q = vA, P(kW)=p(bar)×Q(L/min)/600. For proportional valves, command changes effective flow area and cylinder velocity.</p></div>`;
          })()}\n    `),
            e.querySelectorAll("[data-calc]").forEach((e) => {
              e.addEventListener("input", () => {
                const t = e.dataset.calc;
                ((p.calc[t] = "number" === e.type ? P(e.value) : e.value),
                  "lineType" === t &&
                    (p.calc.velocityMps = Be(p.calc.lineType)),
                  ke());
              });
            }));
        })(t));
  }
  function Me(e, t) {
    return `<div class="rgz-field"><label>${M(t)}</label><input class="rgz-small-input" data-project-field="${e}" value="${M(p.projectMeta[e] || "")}" /></div>`;
  }
  function ze(e, t) {
    const r = e.props[t.key];
    if ("select" === t.type)
      return `<div class="rgz-field"><label>${M(t.label)}</label><select class="rgz-small-input" data-prop-field="${t.key}">${t.options.map((e) => `<option value="${M(e)}" ${String(r) === String(e) ? "selected" : ""}>${M(e)}</option>`).join("")}</select></div>`;
    if ("checkbox" === t.type)
      return `<div class="rgz-field"><label><input type="checkbox" data-prop-field="${t.key}" ${r ? "checked" : ""} /> ${M(t.label)}</label></div>`;
    if ("textarea" === t.type)
      return `<div class="rgz-field"><label>${M(t.label)}</label><textarea data-prop-field="${t.key}"${t.placeholder ? ` placeholder="${M(t.placeholder)}"` : ""}>${M(r || "")}</textarea></div>`;
    const n =
        "number" === t.type ? "number" : "color" === t.type ? "color" : "text",
      a = [
        void 0 !== t.min ? `min="${t.min}"` : "",
        void 0 !== t.max ? `max="${t.max}"` : "",
        void 0 !== t.step ? `step="${t.step}"` : "",
      ].join(" ");
    return `<div class="rgz-field"><label>${M(t.label)}</label><input class="rgz-small-input" type="${n}" ${a} data-prop-field="${t.key}" value="${M(r ?? "")}" /></div>`;
  }
  function Se(e, t) {
    (e.querySelectorAll("[data-comp-field]").forEach((e) => {
      e.addEventListener("input", () => {
        const r = e.dataset.compField;
        ((t[r] = ["x", "y", "rotation"].includes(r) ? P(e.value) : e.value),
          ("x" !== r && "y" !== r) || (t[r] = S(t[r])),
          H());
      });
    }),
      e.querySelectorAll("[data-prop-field]").forEach((e) => {
        const r = () => {
          const r = e.dataset.propField;
          ("checkbox" === e.type
            ? (t.props[r] = e.checked)
            : "number" === e.type
              ? (t.props[r] = P(e.value))
              : (t.props[r] = e.value),
            "valveType" === r &&
              (function (e) {
                if (!C(e)) return;
                const t = o[e.props.valveType];
                t && Object.assign(e.props, t);
              })(t),
            H());
        };
        (e.addEventListener("input", r),
          e.addEventListener("change", () => {
            (r(), C(t) && H());
          }));
      }));
  }
  function Pe(e) {
    const t = p.components.find((t) => t.id === e);
    if (!t) return;
    const r = $(t.type),
      a = n.querySelector(".rgz-modal-backdrop");
    a && a.remove();
    const i = [
        `<div class="rgz-field"><label>Visible label</label><input class="rgz-small-input" data-comp-field="label" value="${M(t.label || "")}" /></div>`,
        `<div class="rgz-field-grid"><div class="rgz-field"><label>X position</label><input class="rgz-small-input" data-comp-field="x" type="number" value="${P(t.x)}" /></div><div class="rgz-field"><label>Y position</label><input class="rgz-small-input" data-comp-field="y" type="number" value="${P(t.y)}" /></div></div>`,
        `<div class="rgz-field"><label>Rotation, degrees</label><input class="rgz-small-input" data-comp-field="rotation" type="number" step="90" value="${P(t.rotation)}" /></div>`,
        ...(r.propSchema || []).map((e) => ze(t, e)),
      ],
      o = document.createElement("div");
    ((o.className = "rgz-modal-backdrop"),
      (o.innerHTML = `\n      <div class="rgz-modal" role="dialog" aria-modal="true" aria-label="Component characteristics">\n        <div class="rgz-modal-head">\n          <div><h3>${M(r.name)}</h3><p>${M(r.desc || "")}</p></div>\n          <button class="rgz-btn icon" data-modal-close>×</button>\n        </div>\n        <div class="rgz-modal-body">\n          <div class="rgz-panel">\n            <div class="rgz-panel-title">Real-world editable characteristics</div>\n            ${i.join("")}\n          </div>\n          <div class="rgz-panel">\n            <div class="rgz-panel-title">Technical identity</div>\n            <div class="rgz-kv">\n              <div class="rgz-kv-row"><span>Component ID</span><span>${M(t.id)}</span></div>\n              <div class="rgz-kv-row"><span>Symbol type</span><span>${M(r.baseType || t.type)}</span></div>\n              <div class="rgz-kv-row"><span>Library item</span><span>${M(r.name)}</span></div>\n            </div>\n          </div>\n          <div class="rgz-panel">\n            <div class="rgz-panel-title">Ports</div>\n            <div class="rgz-kv">${B(
        t,
      )
        .map(
          (e) =>
            `<div class="rgz-kv-row"><span>${M(e.id)}</span><span>${M(e.kind)}${e.required ? " · required" : ""}</span></div>`,
        )
        .join(
          "",
        )}</div>\n          </div>\n        </div>\n        <div class="rgz-modal-foot">\n          <span>Double-click any equipment to edit these characteristics.</span>\n          <button class="rgz-btn primary" data-modal-close>Done</button>\n        </div>\n      </div>\n    `),
      n.appendChild(o),
      Se(o, t),
      o.addEventListener("click", (e) => {
        (e.target === o || e.target.closest("[data-modal-close]")) &&
          (o.remove(), ke());
      }));
  }
  function Ae(e) {
    return (
      {
        pressure: "#93c5fd",
        return: "#a7f3d0",
        pilot: "#fbbf24",
        drain: "#c4b5fd",
        electrical: "#f0abfc",
      }[e] || "#d9e7ff"
    );
  }
  function $e(e) {
    const t = e.dataset.id,
      r = e.dataset.controlKind,
      n = p.components.find((e) => e.id === t);
    n &&
      ("valve" === r && (n.props.spoolState = e.dataset.value),
      "pushButton" === r && (n.props.pressed = !n.props.pressed),
      "solenoid" === r && (n.props.energized = !n.props.energized),
      H(),
      "simulation" === p.inspectorTab && ke());
  }
  function Ce() {
    const e = document.getElementById("rgz-mobile-live-controls");
    if (!e) return;
    if (!p.sim.running)
      return (
        (e.innerHTML = ""),
        (e._lastHtml = ""),
        void e.classList.remove("active")
      );
    const t = p.components.filter((e) => C(e)),
      r = [];
    (t.forEach((e) => {
      const t = [
        "left",
        ...(3 === Number(e.props.positions || 3) ? ["center"] : []),
        "right",
      ]
        .map(
          (t) =>
            `<button class="rgz-btn ${e.props.spoolState === t ? "primary" : ""}" data-control-kind="valve" data-id="${M(e.id)}" data-value="${t}">${t}</button>`,
        )
        .join("");
      r.push(
        `<div class="rgz-mobile-control-row"><strong>${M(e.label || e.id)}</strong><span>${t}</span></div>`,
      );
    }),
      p.components
        .filter((e) => "pushButton" === e.type || "solenoid" === e.type)
        .forEach((e) => {
          const t =
            "pushButton" === e.type ? e.props.pressed : e.props.energized;
          r.push(
            `<div class="rgz-mobile-control-row"><strong>${M(e.label || e.id)}</strong><span><button class="rgz-btn ${t ? "primary" : ""}" data-control-kind="${e.type}" data-id="${M(e.id)}">${t ? "ON" : "OFF"}</button></span></div>`,
          );
        }));
    const n = `<div class="rgz-mobile-live-head"><strong>Live controls · ${P(p.sim.timeScale, 1).toFixed(2)}×</strong><button class="rgz-btn danger" data-action="stop">Stop</button></div>${r.length ? r.join("") : '<div class="rgz-message info">No valves or live controls in this circuit.</div>'}`;
    (e._lastHtml !== n && ((e.innerHTML = n), (e._lastHtml = n)),
      e.classList.add("active"));
  }
  function Le(e, t, r) {
    return `<div class="rgz-field"><label>${M(t)}</label><input class="rgz-small-input" type="number" step="${r}" data-calc="${e}" value="${M(p.calc[e])}" /></div>`;
  }
  function Be(e) {
    return (
      { suction: 0.9, return: 2.2, pressure: 4, drain: 1.2, pilot: 1.5 }[e] || 4
    );
  }
  function Te(e = !0) {
    const t = [],
      r = (e, r, n, a = "") =>
        t.push({ severity: e, title: r, detail: n, fix: a }),
      n = p.components,
      a = p.connections;
    (n.length ||
      r(
        "error",
        "Empty drawing",
        "No hydraulic components exist in the project.",
        "Drag symbols from the library or load one of the 15 examples.",
      ),
      n.some((e) => "tank" === e.type || "powerPack" === e.type) ||
        r(
          "error",
          "Missing reservoir",
          "A hydraulic circuit normally requires an oil reservoir/tank.",
          "Add a reservoir/tank symbol or a compact power-pack block.",
        ),
      n.some(
        (e) =>
          "pumpFixed" === e.type ||
          "pumpVariable" === e.type ||
          "powerPack" === e.type,
      ) ||
        r(
          "error",
          "Missing pump",
          "No hydraulic power source was found.",
          "Add a fixed/variable displacement pump or a compact power-pack block.",
        ),
      n.forEach((e) => {
        (e.label ||
          r(
            "warning",
            "Unlabeled component",
            `${e.id} has no visible label.`,
            "Add a component label in the inspector.",
          ),
          B(e).forEach((t) => {
            t.required &&
              !Ee(e.id, t.id) &&
              r(
                "error",
                "Required port is open",
                `${e.label || e.id}.${t.id} is not connected.`,
                "Connect this port or change the component configuration.",
              );
          }),
          "pumpFixed" !== e.type ||
            n.some((e) => "reliefValve" === e.type || "powerPack" === e.type) ||
            r(
              "error",
              "Fixed pump without relief valve",
              `${e.label || e.id} is a fixed displacement pump but no relief valve exists.`,
              "Add a relief valve from the pressure line to tank, or use a compact power-pack block with internal relief.",
            ),
          "cylinderDA" === e.type &&
            ((Ee(e.id, "A") && Ee(e.id, "B")) ||
              r(
                "error",
                "Double-acting cylinder incomplete",
                `${e.label || e.id} requires both A and B lines.`,
                "Connect both cylinder ports to a directional valve.",
              )),
          "pilotCheckValve" !== e.type ||
            Ee(e.id, "X") ||
            r(
              "warning",
              "Pilot line missing",
              `${e.label || e.id} will not release without a pilot line.`,
              "Connect pilot port X.",
            ),
          "counterbalanceValve" !== e.type ||
            Ee(e.id, "X") ||
            r(
              "warning",
              "Counterbalance pilot missing",
              `${e.label || e.id} normally needs an external pilot line.`,
              "Connect pilot port X from the opposite cylinder line.",
            ));
      }),
      a.forEach((e) => {
        const t = T(e.from.componentId, e.from.portId),
          n = T(e.to.componentId, e.to.portId);
        t && n
          ? t.kind === n.kind ||
            ("pilot" === t.kind && "hydraulic" === n.kind) ||
            ("hydraulic" === t.kind && "pilot" === n.kind) ||
            r(
              "error",
              "Incompatible line types",
              `${e.id} connects ${t.kind} to ${n.kind}.`,
              "Use hydraulic-to-hydraulic, pilot-to-pilot/hydraulic, or electrical-to-electrical connections.",
            )
          : r(
              "error",
              "Broken connection",
              `${e.id} references a component or port that no longer exists.`,
              "Delete and redraw this connection.",
            );
      }),
      n
        .filter(
          (e) =>
            "pumpFixed" === e.type ||
            "pumpVariable" === e.type ||
            "powerPack" === e.type,
        )
        .forEach((e) => {
          "powerPack" !== e.type &&
            (Ve(e.id, "S", "tank") ||
              r(
                "warning",
                "Pump suction not directly connected to tank",
                `${e.label || e.id} suction S is not directly connected to a reservoir in this V1 checker.`,
                "Connect pump S to tank T or place a recognized suction line/filter path.",
              ));
        }),
      n
        .filter((e) => "reliefValve" === e.type)
        .forEach((e) => {
          Ve(e.id, "T", "tank") ||
            Ve(e.id, "T", "powerPack") ||
            r(
              "error",
              "Relief valve tank port problem",
              `${e.label || e.id}.T is not connected to tank.`,
              "Connect relief T port to the reservoir.",
            );
        }),
      n.some(
        (e) =>
          "pressureGauge" === e.type ||
          ("powerPack" === e.type && e.props.pressureGauge),
      )
        ? r(
            "info",
            "Instrumentation found",
            "A pressure gauge exists in the circuit or inside the compact power pack. Good practice for pump outlet monitoring.",
          )
        : r(
            "warning",
            "No pressure gauge",
            "No pressure gauge was found.",
            "Add a gauge near the pump outlet or enable the compact power-pack gauge.",
          ),
      n.some((e) => "pumpFixed" === e.type || "pumpVariable" === e.type) &&
        !n.some(
          (e) =>
            "suctionStrainer" === e.type ||
            "filter" === e.type ||
            "powerPack" === e.type,
        ) &&
        r(
          "warning",
          "No suction/pressure filtration",
          "Training material emphasizes conditioning and filtration of the pressure medium.",
          "Add suction strainer, pressure filter, return filter, or use the power unit block.",
        ),
      n.some((e) => "servoValve" === e.type) &&
        !n.some((e) => "proportionalAmplifier" === e.type) &&
        r(
          "warning",
          "Proportional valve without amplifier",
          "A proportional/servo valve normally needs an amplifier, setpoint and ramp/dither settings.",
          "Add proportional amplifier and setpoint/ramp elements.",
        ),
      n.some((e) => "servoValve" === e.type) &&
        !n.some(
          (e) =>
            "linearPositionSensor" === e.type ||
            "pressureTransducer" === e.type,
        ) &&
        r(
          "info",
          "Open-loop proportional control",
          "No analog feedback sensor was found. This is acceptable for speed control but not for accurate positioning.",
          "For positioning, add LVDT/position feedback and controller logic.",
        ),
      n.some((e) => "cylinderDA" === e.type || "cylinderSA" === e.type) &&
        !n.some((e) => "flowControl" === e.type || "servoValve" === e.type) &&
        r(
          "warning",
          "Cylinder speed not controlled",
          "Cylinder speed depends on flow. Training circuits normally include flow control or proportional flow metering.",
          "Add a flow control valve or proportional valve.",
        ),
      n.some((e) => "pumpFixed" === e.type) &&
        !n.some(
          (e) => "testPoint" === e.type || "pressureTransducer" === e.type,
        ) &&
        r(
          "info",
          "Diagnostics recommended",
          "A pressure test point or pressure transducer helps troubleshooting and commissioning.",
          "Add a test point near the pump/manifold pressure line.",
        ));
    const i = t.filter((e) => "error" === e.severity).length;
    return (
      (t.length && i) ||
        i ||
        t.unshift({
          severity: "ok",
          title: "Circuit check passed",
          detail:
            "No blocking schematic errors were detected. Simulation is enabled.",
          fix: "",
        }),
      (p.messages = t),
      qe(),
      e &&
        lt(
          i
            ? `Check finished with ${i} blocking error(s).`
            : "Check passed. You can simulate this circuit.",
          i ? "error" : "ok",
        ),
      t
    );
  }
  function Ee(e, t) {
    return p.connections.some(
      (r) =>
        (r.from.componentId === e && r.from.portId === t) ||
        (r.to.componentId === e && r.to.portId === t),
    );
  }
  function Ve(e, t, r) {
    return p.connections.some((n) => {
      let a = null;
      return (
        n.from.componentId === e &&
          n.from.portId === t &&
          (a = n.to.componentId),
        n.to.componentId === e && n.to.portId === t && (a = n.from.componentId),
        a && p.components.find((e) => e.id === a)?.type === r
      );
    });
  }
  function qe() {
    f &&
      (p.messages.length
        ? (f.innerHTML = p.messages
            .map((e) => {
              return `\n      <div class="rgz-message ${e.severity}"><strong>${((t = e.severity), { error: "⛔", warning: "⚠️", info: "ℹ️", ok: "✅" }[t] || "•")} ${M(e.title)}</strong><br>${M(e.detail)}${e.fix ? `<br><em>Fix: ${M(e.fix)}</em>` : ""}</div>\n    `;
              var t;
            })
            .join(""))
        : (f.innerHTML =
            '<div class="rgz-message info"><strong>Ready</strong><br>No messages. Press “Check circuit” to validate the schematic.</div>'));
  }
  function Ie() {
    (p.sim.raf && cancelAnimationFrame(p.sim.raf),
      (p.sim.raf = null),
      (p.sim.running = !1),
      Ne(),
      H(),
      Ce(),
      ke());
  }
  // ---------- user-defined simulation charts ----------
  function chartApi() {
    return (
      p.__rgzCharts ||
      (p.__rgzCharts = rgzChartsFactory({
        root: n,
        state: p,
        toast: lt,
        fluid: "oil",
        name: "hydraulic",
      }))
    );
  }
  // ---------- electrical scan engine: PLC rungs + solenoid->valve drive ----------
  // Runs once per sim tick (before the fluid solve) and replaces the old
  // decorative behaviour: refreshes signal states, evaluates every PLC
  // program rung, then lets energized coils drive their valves. Deleting the
  // PLC from an electro-hydraulic example therefore REALLY stops the
  // sequence — the bare coil/valve hardware has no logic of its own.
  function rgzElectricalScan() {
    const comps = p.components,
      conns = p.connections,
      plcs = comps.filter((c) => "plc" === c.type),
      sols = comps.filter((c) => "solenoid" === c.type);
    if (!plcs.length && !sols.length) return;
    const lc = (s) => String(null == s ? "" : s).trim().toLowerCase(),
      findComp = (nm) => {
        const k = lc(nm);
        return k
          ? comps.find((c) => lc(c.id) === k || lc(c.label) === k) || null
          : null;
      },
      timerDone = (c) =>
        Number.isFinite(c.props.__t) &&
        p.sim.time - c.props.__t >= Math.max(0, P(c.props.delayS, 1)),
      sigState = (c) => {
        if (!c || !c.props) return false;
        const pr = c.props,
          nc = "NC" === String(pr.contact || "NO").toUpperCase();
        let raw;
        ("pushButton" === c.type
          ? (raw = !!pr.pressed)
          : "emergencyStop" === c.type
            ? (raw = !pr.pressed) // safety contact: healthy (not pressed) = true
            : "solenoid" === c.type || "electricalRelay" === c.type
              ? (raw = !!pr.energized)
              : "relayContact" === c.type
                ? (raw = !!pr.closed)
                : "timerRelay" === c.type
                  ? (raw = timerDone(c))
                  : (raw = !!pr.active));
        return nc ? !raw : !!raw;
      },
      wiredPin = (c, portId) => {
        const out = [];
        for (const cn of conns) {
          if (!cn || "electrical" !== cn.lineType) continue;
          const f = cn.from || {},
            g = cn.to || {};
          if (f.componentId === c.id && f.portId === portId) {
            const o = comps.find((x) => x.id === g.componentId);
            o && o.id !== c.id && out.push(o);
          } else if (g.componentId === c.id && g.portId === portId) {
            const o = comps.find((x) => x.id === f.componentId);
            o && o.id !== c.id && out.push(o);
          }
        }
        return out;
      },
      isValve = (c) => C(c) || "pneumaticMemoryValve" === c.type,
      plcValveWrites = new Set(),
      coilDesired = new Map(),
      coilOwned = new Set(),
      setTimer = (c, on) => {
        (on
          ? Number.isFinite(c.props.__t) || (c.props.__t = p.sim.time)
          : (c.props.__t = null),
          (c.props.active = Number.isFinite(c.props.__t) || timerDone(c)));
      },
      PASSIVE_WORDS = {
        off: 1, false: 1, 0: 1, "de-energize": 1, deenergize: 1, reset: 1,
        stop: 1, center: 1, centre: 1, right: 1, retract: 1, open: 1,
      },
      wordActive = (v) => !PASSIVE_WORDS[v],
      writeValve = (v, val) => {
        plcValveWrites.add(v.id);
        const three = 3 === Number(v.props.positions || 3);
        ("left" === val || "extend" === val || "on" === val
          ? (v.props.spoolState = "left")
          : "right" === val || "retract" === val
            ? (v.props.spoolState = "right")
            : ("center" === val || "centre" === val || "stop" === val || "off" === val) &&
              (v.props.spoolState = three ? "center" : "right"));
      },
      applyTarget = (pl, tgt, val, qPins) => {
        const pinM = /^q([1-4])$/i.exec(tgt);
        if (pinM) return void (qPins["Q" + pinM[1]] = wordActive(lc(val)));
        const c = findComp(tgt);
        if (!c) return;
        const v = lc(val);
        (isValve(c)
          ? writeValve(c, v)
          : "solenoid" === c.type || "electricalRelay" === c.type
            ? (coilOwned.add(c.id), coilDesired.set(c.id, wordActive(v)))
            : "timerRelay" === c.type
              ? (coilOwned.add(c.id), setTimer(c, /^(start|on|true|1|energize|extend|left)$/.test(v)))
              : "energized" in Object(c.props || {})
                ? (coilOwned.add(c.id), coilDesired.set(c.id, wordActive(v))) // solenoid-operated cartridges etc.
                : void 0);
      };
    plcs.forEach((pl) => {
      const qPins = {},
        stmts = String(pl.props.program || "")
          .replace(/^\s*[A-Za-z][\w .+\/\-]{0,48}:\s*/, "") // optional leading TITLE:
          .split(/[;\n]+/)
          .map((s) => s.replace(/(\/\/|#).*$/, "").trim())
          .filter(Boolean),
        pinVal = (nm) => wiredPin(pl, nm.toUpperCase()).some((o) => sigState(o)),
        evalCond = (src) =>
          src.split(/\s+OR\s+|\|+/i).some((br) => {
            const terms = br
              .split(/\s+AND\s+|&+|,+/i)
              .map((s) => s.trim())
              .filter(Boolean);
            return (
              !!terms.length &&
              terms.every((tm) => {
                const neg = /^\s*(NOT\b|!)/.test(tm),
                  nm = tm.replace(/^\s*(NOT\b|!)\s*/, "").trim();
                let v;
                (/^I[1-4]$/i.test(nm) || /^Q[1-4]$/i.test(nm)
                  ? (v = pinVal(nm))
                  : /^(ON|TRUE|1)$/i.test(nm)
                    ? (v = true)
                    : /^(OFF|FALSE|0)$/i.test(nm)
                      ? (v = false)
                      : (v = sigState(findComp(nm))));
                return neg ? !v : v;
              })
            );
          });
      // ownership pre-pass: coils/relays/timers named as ANY rule target are
      // PLC-driven combinatorial outputs (default OFF when no rung drives them)
      stmts.forEach((st) => {
        const m1 = /^([A-Za-z][\w.+\-]*)\s*=/.exec(st),
          m2 = /->\s*([A-Za-z][\w.+\-]*)/.exec(st),
          tn = m1 ? m1[1] : m2 ? m2[1] : null;
        if (tn && !/^[IQ][1-4]$/i.test(tn)) {
          const c = findComp(tn);
          c &&
            ("solenoid" === c.type ||
              "electricalRelay" === c.type ||
              "timerRelay" === c.type ||
              "energized" in Object(c.props || {})) &&
            coilOwned.add(c.id);
        }
      });
      stmts.forEach((st) => {
        let m = /^(.+?)\s*->\s*([A-Za-z][\w.+\-]*)\s*([A-Za-z][\w\-]*)?$/.exec(st);
        if (m) {
          if (evalCond(m[1])) applyTarget(pl, m[2], m[3] || "on", qPins);
          return;
        }
        m = /^([A-Za-z][\w.+\-]*)\s*=\s*(.+)$/.exec(st);
        if (m) {
          const on = evalCond(m[2]);
          if (/^Q[1-4]$/i.test(m[1])) qPins[m[1].toUpperCase()] = on;
          else {
            const c = findComp(m[1]);
            c &&
              (isValve(c)
                ? writeValve(c, on ? "left" : "stop")
                : "solenoid" === c.type || "electricalRelay" === c.type
                  ? (coilOwned.add(c.id), coilDesired.set(c.id, on))
                  : "timerRelay" === c.type && setTimer(c, on));
          }
        }
      });
      // flush Q pins through the real wires (edge-triggered for timers)
      const prevQ = (pl.props.__q = pl.props.__q || {});
      Object.keys(qPins).forEach((pin) => {
        const v = !!qPins[pin];
        wiredPin(pl, pin).forEach((o) => {
          ("solenoid" === o.type || "electricalRelay" === o.type
            ? (coilOwned.add(o.id), coilDesired.set(o.id, v))
            : "timerRelay" === o.type
              ? v !== !!prevQ[pin] && setTimer(o, v)
              : "energized" in Object(o.props || {})
                ? (coilOwned.add(o.id), coilDesired.set(o.id, v))
                : isValve(o) && writeValve(o, v ? "left" : "stop"));
        });
        prevQ[pin] = v;
      });
    });
    // combinatorial coil flush
    coilOwned.forEach((id) => {
      const c = comps.find((x) => x.id === id);
      c &&
        ("solenoid" === c.type ||
          "electricalRelay" === c.type ||
          ("timerRelay" !== c.type && "energized" in Object(c.props || {}))) &&
        (c.props.energized = !!coilDesired.get(id));
    });
    // ---------- solenoid -> valve drive ----------
    // A coil drives a valve when it is bound (targetControl), PLC-driven, or
    // electrically wired (single-valve circuits auto-map). Coil labels ending
    // in an odd digit drive LEFT, even digit RIGHT (Y1/Y2 convention); a
    // digitless pair maps first-found -> left. PLC valve rungs override coils.
    const valves = comps.filter((e) => isValve(e));
    if (valves.length && sols.length) {
      const buckets = new Map(),
        bucketOf = (v) => {
          let b = buckets.get(v.id);
          if (!b) buckets.set(v.id, (b = { left: [], right: [] }));
          return b;
        };
      sols.forEach((s) => {
        let v = null;
        const tc = lc(s.props.targetControl);
        tc && (v = valves.find((x) => lc(x.id) === tc || lc(x.label) === tc) || null);
        const wired = conns.some(
          (cn) =>
            cn &&
            "electrical" === cn.lineType &&
            ((cn.from || {}).componentId === s.id ||
              (cn.to || {}).componentId === s.id),
        );
        if (!tc && !wired && !coilDesired.has(s.id) && !coilOwned.has(s.id))
          return; // decorative loose coil: leave the valve manual
        if (!v) {
          if (1 === valves.length) v = valves[0];
          else return;
        }
        const b = bucketOf(v),
          la = String(v.props.leftActuation || ""),
          ra = String(v.props.rightActuation || ""),
          SOL = (x) => /solenoid|electrical/i.test(x);
        let side;
        if (SOL(la) && !SOL(ra)) side = "left";           // single electrical side drives there
        else if (SOL(ra) && !SOL(la)) side = "right";
        else {
          const nm = String(s.label || s.id || ""),
            d = /(\d+)\s*$/.exec(nm);
          side = d
            ? parseInt(d[1], 10) % 2
              ? "left"
              : "right"
            : b.left.length && !b.right.length
              ? "right"
              : "left";
        }
        b[side].push(s);
      });
      buckets.forEach((b, vid) => {
        if (plcValveWrites.has(vid)) return;
        const v = comps.find((x) => x.id === vid);
        if (!v) return;
        const three = 3 === Number(v.props.positions || 3),
          springLeft = /spring/i.test(String(v.props.leftActuation || "")),
          l = b.left.some((s) => !!s.props.energized),
          r = b.right.some((s) => !!s.props.energized);
        (l && !r
          ? (v.props.spoolState = "left")
          : r && !l
            ? (v.props.spoolState = "right")
            : l ||
              r ||
              (v.props.spoolState = three ? "center" : springLeft ? "left" : "right"));
      });
    }
  }
  function Re(e) {
    if (!p.sim.running) return;
    const t =
      z((e - p.sim.last) / 1e3, 0, 0.08) * z(P(p.sim.timeScale, 1), 0, 3);
    ((p.sim.last = e),
      (p.sim.time += t),
            rgzElectricalScan(),
      (function (e) {
        window.matchMedia("(max-width: 920px)").matches
          ? (p.sim.metrics = je(p.components, p.connections, e, p.sim.time))
          : p.sim.worker && !p.sim.workerBusy
            ? ((p.sim.workerBusy = !0),
              p.sim.worker.postMessage({
                components: p.components,
                connections: p.connections,
                dt: e,
                time: p.sim.time,
              }))
            : p.sim.worker ||
              (p.sim.metrics = je(p.components, p.connections, e, p.sim.time));
      })(t),
      (function (e) {
        const t =
            p.sim.metrics || je(p.components, p.connections, e, p.sim.time),
          r = new Map((t.cylinders || []).map((e) => [e.id, e])),
          n = new Map((t.motors || []).map((e) => [e.id, e])),
          o = new Map((t.accumulators || []).map((e) => [e.id, e]));
        (p.components.forEach((t) => {
          if ("cylinderDA" === t.type || "cylinderSA" === t.type) {
            const n = r.get(t.id),
              a = Math.max(1, P(t.props.strokeMm, 500)),
              i = ((n ? n.speedMmS : 0) / a) * e;
            t.props.simPosition = z(P(t.props.simPosition, 0.2) + i, 0, 1);
          }
          if ("hydraulicMotor" === t.type) {
            const r = n.get(t.id),
              a = Math.max(0, P(r ? r.flowLpm : 0, 0)),
              i = P(r ? r.rpm : 0, 0);
            a > 0.05 &&
              Math.abs(i) > 0.1 &&
              (t.props.simAngle =
                P(t.props.simAngle, 0) + (i / 60) * 2 * Math.PI * e);
          }
          if ("accumulator" === t.type) {
            const a2 = o.get(t.id),
              c2 = Math.max(0.5, P(t.props.volumeL, 5));
            a2 &&
              (t.props.simChargeL = z(
                P(t.props.simChargeL, 0) + (P(a2.flowLpm, 0) * e) / 60,
                0,
                0.98 * c2,
              ));
          }
        }),
          (function (e = {}) {
            const t = [
              "limitSwitch",
              "cylinderReedSensor",
              "linearPositionSensor",
              "proximitySensor",
              "pressureSwitch",
              "pressureTransducer",
              "flowSwitch",
              "temperatureSwitch",
              "levelSwitch",
            ];
            p.components
              .filter((e) => t.includes(e.type))
              .forEach((t) => {
                const r = (function (e, t = {}) {
                  const tcv2 = (t.comp && t.comp[e.id]) || null;
                  if ("pressureSwitch" === e.type) {
                    const pv2 =
                        tcv2 && Number.isFinite(tcv2.pressureBar)
                          ? tcv2.pressureBar
                          : P(t.pressureBar, 0),
                      sw2 = P(e.props.switchBar, 999999);
                    // Schmitt: picks up at switchBar, drops out 5% below (real switch hysteresis)
                    return e.props.active ? pv2 > 0.95 * sw2 : pv2 >= sw2;
                  }
                  if ("pressureTransducer" === e.type)
                    return (
                      (tcv2 && Number.isFinite(tcv2.pressureBar)
                        ? tcv2.pressureBar
                        : P(t.pressureBar, 0)) > 1
                    );
                  if ("flowSwitch" === e.type)
                    return (
                      (tcv2 && Number.isFinite(tcv2.flowLpm)
                        ? tcv2.flowLpm
                        : P(t.activeFlowLpm ?? t.totalFlowLpm, 0)) >=
                      P(e.props.switchLpm, 0)
                    );
                  if ("temperatureSwitch" === e.type) {
                    const tt2 = Number.isFinite(t.oilTempC)
                        ? t.oilTempC
                        : P(t.oilTempC, 20),
                      sw3 = P(e.props.switchTempC, 60);
                    return e.props.active ? tt2 > sw3 - 2 : tt2 >= sw3;
                  }
                  if ("levelSwitch" === e.type) return !!e.props.active;
                  const r = Fe(e);
                  if (!r) return !1;
                  const n = z(P(r.props.simPosition, 0), 0, 1),
                    a = e.props.triggerAt || "custom",
                    was = !!e.props.active,
                    tp2 = z(P(e.props.triggerPosition, 0.5), 0, 1);
                  // Schmitt-style bands: a switch that picked up stays ON until
                  // the actuator leaves the neighbourhood (no flicker at edges).
                  return "retracted" === a
                    ? was
                      ? n <= 0.08
                      : n <= 0.02
                    : "extended" === a
                      ? was
                        ? n >= 0.92
                        : n >= 0.98
                      : "middle" === a
                        ? Math.abs(n - tp2) <= 0.08
                        : was
                          ? n >= tp2 - 0.05
                          : n >= tp2;
                })(t, e);
                ((t.props.active = r),
                  r &&
                    (function (e) {
                      const t = e.props.action || "none";
                      if ("none" === t) return;
                      const r = (function (e, t) {
                        const r = String(e || "")
                            .trim()
                            .toLowerCase(),
                          n = p.components.filter(
                            (e) => C(e) || "solenoid" === e.type,
                          );
                        if (r) {
                          const e = n.find(
                            (e) =>
                              String(e.id).toLowerCase() === r ||
                              String(e.label || "").toLowerCase() === r,
                          );
                          if (e) return e;
                        }
                        return t.startsWith("set valve")
                          ? n.find((e) => C(e)) || null
                          : (t.includes("solenoid") &&
                              n.find((e) => "solenoid" === e.type)) ||
                              null;
                      })(e.props.targetControl, t);
                      r &&
                        ("set valve left" === t &&
                          C(r) &&
                          (r.props.spoolState = "left"),
                        "set valve center" === t &&
                          C(r) &&
                          (r.props.spoolState = "center"),
                        "set valve right" === t &&
                          C(r) &&
                          (r.props.spoolState = "right"),
                        "energize solenoid" === t &&
                          "solenoid" === r.type &&
                          (r.props.energized = !0),
                        "de-energize solenoid" === t &&
                          "solenoid" === r.type &&
                          (r.props.energized = !1));
                    })(t));
              });
          })(t));
      })(t));
    p.sim.metrics && chartApi().rec();
    const r = window.matchMedia("(max-width: 920px)").matches,
      n = r ? 180 : 90;
    ((!p.sim.lastCanvasRender || e - p.sim.lastCanvasRender > n) &&
      ((p.sim.lastCanvasRender = e), H()),
      e - p.sim.lastPanelRender > (r ? 1e3 : 500) &&
        ((p.sim.lastPanelRender = e), "simulation" === p.inspectorTab && ke()),
      (p.sim.raf = requestAnimationFrame(Re)));
  }
  function Fe(e) {
    const t = String(e.props.linkedActuator || "")
        .trim()
        .toLowerCase(),
      r = p.components.filter(
        (e) => "cylinderDA" === e.type || "cylinderSA" === e.type,
      );
    if (t) {
      const e = r.find(
        (e) =>
          String(e.id).toLowerCase() === t ||
          String(e.label || "").toLowerCase() === t,
      );
      if (e) return e;
    }
    return r.length
      ? r
          .slice()
          .sort(
            (t, r) =>
              Math.hypot(t.x - e.x, t.y - e.y) -
              Math.hypot(r.x - e.x, r.y - e.y),
          )[0]
      : null;
  }
  function De() {
    const e = p.components.filter(
      (e) => "reliefValve" === e.type || "powerPack" === e.type,
    );
    return e.length
      ? Math.min(
          ...e.map((e) =>
            P(e.props.settingBar ?? e.props.reliefSettingBar, 160),
          ),
        )
      : 160;
  }
  function Ne() {
    b &&
      (b.classList.toggle("running", p.sim.running),
      (document.getElementById("rgz-sim-status").textContent = p.sim.running
        ? `Running · ${p.sim.time.toFixed(1)} s`
        : "Idle"),
      n.querySelectorAll('[data-action="simulate"]').forEach((e) => {
        e.disabled = p.sim.running;
      }),
      n.querySelectorAll('[data-action="stop"]').forEach((e) => {
        e.disabled = !p.sim.running;
      }),
      n
        .querySelectorAll('[data-action="toggle-live-controls"]')
        .forEach((e) => {
          e.disabled = !p.sim.running;
        }));
  }
  function je(e, t, r, n) {
    return computeHydraulics(e, t, r, n);
  }
  function computeHydraulics(e, t, r, n) {
    return rgzFluidSolve({
      fluid: "oil",
      components: e,
      connections: t,
      dt: r,
      time: n,
    });
  }
  function Oe() {
    ((p.printArea = k(p.viewBox)),
      H(),
      lt(
        "Print area set from current view. Pan/zoom first, then press this button to define another area.",
        "ok",
      ));
  }
  function He() {
    ((p.printArea = null),
      H(),
      lt("Print area cleared. Printing will use the whole drawing.", "info"));
  }
  function Ue() {
    const e = n.querySelector(".rgz-modal-backdrop");
    e && e.remove();
    const t = document.createElement("div");
    ((t.className = "rgz-modal-backdrop"),
      (t.innerHTML = `\n      <div class="rgz-modal rgz-print-modal" role="dialog" aria-modal="true" aria-label="Print options">\n        <div class="rgz-modal-head">\n          <div><h3>Print / PDF options</h3><p>The drawing will be forced to fit on one paper with the RGZ title block and watermark.</p></div>\n          <button class="rgz-btn icon" data-modal-close>×</button>\n        </div>\n        <div class="rgz-modal-body">\n          <div class="rgz-panel">\n            <div class="rgz-panel-title">Print range</div>\n            <div class="rgz-field-grid" style="margin-top:10px">\n              <button class="rgz-btn" data-print-area="whole">Whole drawing</button>\n              <button class="rgz-btn ${p.printArea ? "primary" : ""}" data-print-area="selected" ${p.printArea ? "" : "disabled"}>Selected area</button>\n            </div>\n            <div class="rgz-field-grid" style="margin-top:10px">\n              <button class="rgz-btn" data-action="set-print-area">Set area = current view</button>\n              <button class="rgz-btn" data-action="clear-print-area" ${p.printArea ? "" : "disabled"}>Clear area</button>\n            </div>\n            <p>For user-defined one-page printing, zoom/pan to the desired area and click “Set area = current view”.</p>\n          </div>\n          <div class="rgz-panel">\n            <div class="rgz-panel-title">Orientation</div>\n            <div class="rgz-field-grid" style="margin-top:10px">\n              <button class="rgz-btn primary" data-print-orientation="landscape" data-print-pages="1">A4 Landscape</button>\n              <button class="rgz-btn" data-print-orientation="portrait" data-print-pages="1">A4 Portrait</button>\n            </div>\n            <p>One-page output is the default. Multi-page appears only for large circuits.</p>\n          </div>\n          ${
        (function () {
          const e = Ge(0);
          return e.w > 1450 || e.h > 900 || p.components.length > 28;
        })()
          ? '<div class="rgz-panel"><div class="rgz-panel-title">Large-circuit multi-page</div><div class="rgz-field-grid" style="margin-top:10px"><button class="rgz-btn" data-print-orientation="landscape" data-print-pages="2x1">2 pages wide</button><button class="rgz-btn" data-print-orientation="landscape" data-print-pages="2x2">2 × 2 pages</button></div><p>Use only for very large advanced circuits when one-page scaling becomes unreadable.</p></div>'
          : ""
      }\n        </div>\n        <div class="rgz-modal-foot"><span>Non-removable print watermark: HoumanRGZ</span><button class="rgz-btn" data-modal-close>Cancel</button></div>\n      </div>`),
      n.appendChild(t),
      t.addEventListener("click", (e) => {
        const n = e.target.closest("[data-print-area]");
        if (n)
          return (
            (p.printMode = n.dataset.printArea),
            t
              .querySelectorAll("[data-print-area]")
              .forEach((e) => e.classList.remove("primary")),
            void n.classList.add("primary")
          );
        const a = e.target.closest(
          '[data-action="set-print-area"], [data-action="clear-print-area"]',
        );
        if (a)
          return (
            "set-print-area" === a.dataset.action && Oe(),
            "clear-print-area" === a.dataset.action && He(),
            t.remove(),
            void Ue()
          );
        const i = e.target.closest("[data-print-orientation]");
        if (i) {
          const e = i.dataset.printOrientation,
            n = i.dataset.printPages || "1",
            a =
              "selected" === p.printMode && p.printArea ? "selected" : "whole";
          return (
            t.remove(),
            void (function (e = "landscape", t = "whole", n = "1") {
              Ke();
              const a = "selected" === t && p.printArea ? p.printArea : Ge(120),
                i = "portrait" === e ? "A4 portrait" : "A4 landscape",
                o = "portrait" === e ? 210 : 297,
                s = "portrait" === e ? 297 : 210,
                l = p.projectMeta,
                c =
                  "2x2" === n
                    ? { cols: 2, rows: 2 }
                    : "2x1" === n
                      ? { cols: 2, rows: 1 }
                      : { cols: 1, rows: 1 };
              function d(e) {
                const t = u.cloneNode(!0);
                (t.setAttribute("viewBox", `${e.x} ${e.y} ${e.w} ${e.h}`),
                  t.setAttribute("width", "100%"),
                  t.setAttribute("height", "100%"),
                  t.setAttribute("preserveAspectRatio", "xMidYMid meet"));
                const r = t.querySelector(".rgz-canvas-bg");
                return (
                  r && r.setAttribute("fill", "#ffffff"),
                  t
                    .querySelectorAll(".selected")
                    .forEach((e) => e.classList.remove("selected")),
                  t
                    .querySelectorAll(".sim-active,.sim-high")
                    .forEach((e) =>
                      e.classList.remove("sim-active", "sim-high"),
                    ),
                  t
                    .querySelectorAll("#rgz-print-area-layer")
                    .forEach((e) => e.remove()),
                  t.outerHTML
                );
              }
              const m = [];
              for (let e = 0; e < c.rows; e++)
                for (let t = 0; t < c.cols; t++) {
                  const n = {
                      x: a.x + (t * a.w) / c.cols,
                      y: a.y + (e * a.h) / c.rows,
                      w: a.w / c.cols,
                      h: a.h / c.rows,
                    },
                    i =
                      c.cols * c.rows > 1
                        ? ` — Page ${e * c.cols + t + 1}/${c.cols * c.rows}`
                        : "";
                  m.push(
                    `<div class="page">\n          <div class="sheet"><div class="watermark">HoumanRGZ</div>${d(n)}</div>\n          <div class="title">\n            <div><strong>Project:</strong> ${M(l.projectName || "Untitled")}${i}</div><div><strong>Designer:</strong> ${M(l.designer || "-")}</div><div><strong>Date:</strong> ${M(new Date().toLocaleDateString())}</div>\n            <div><strong>Standard:</strong> ${M(l.standard || "ISO-style")}</div><div><strong>Revision:</strong> ${M(l.revision || "A")}</div><div><strong>Made in RGZ Hydraulic Studio:</strong> ${M(r)}</div>\n          </div>\n        </div>`,
                  );
                }
              const y = `<!doctype html><html><head><meta charset="utf-8"><title>${M(l.projectName || "RGZ Hydraulic Print")}</title>\n      <style>\n        @page{size:${i};margin:0} *{box-sizing:border-box} html,body{margin:0;padding:0;background:#fff;color:#111;font-family:Arial,sans-serif}.page{width:${o}mm;height:${s}mm;padding:8mm;display:grid;grid-template-rows:minmax(0,1fr) 18mm;overflow:hidden;break-after:page;page-break-after:always;break-inside:avoid;page-break-inside:avoid}.page:last-child{break-after:auto;page-break-after:auto}.sheet{position:relative;min-height:0;border:1px solid #111;overflow:hidden}.sheet svg{position:relative;z-index:1;display:block;width:100%;height:100%}.watermark{position:absolute;z-index:5;inset:0;display:grid;place-items:center;pointer-events:none;font-size:${"portrait" === e ? 58 : 70}px;font-weight:900;letter-spacing:.08em;color:rgba(0,0,0,.09);transform:rotate(-28deg);user-select:none}.title{display:grid;grid-template-columns:2fr 1fr 1fr;border:1px solid #111;border-top:0;font-size:8.5px;line-height:1.15;overflow:hidden}.title>div{padding:3px 5px;border-right:1px solid #111;min-height:9mm;overflow:hidden}.title>div:nth-child(3n){border-right:0}.rgz-canvas-bg{fill:#fff}.rgz-connection-path{fill:none;stroke-width:2.4;stroke-linecap:round;stroke-linejoin:round}.rgz-connection-path.pilot,.rgz-connection-path.drain{stroke-dasharray:7 5}.rgz-connection-path.electrical{stroke-dasharray:10 5 2 5}.symbol-stroke,.symbol-muted,.symbol-accent{stroke:#111!important;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}.symbol-fill{fill:#fff!important;stroke:#111!important;stroke-width:2}.port{fill:#fff!important;stroke:#111!important;stroke-width:2}.port-label,.component-label{fill:#111!important;stroke:#fff!important;stroke-width:3;paint-order:stroke;font-weight:700}.selection-box{display:none}.rgz-readout-bg{fill:#fff!important;stroke:#111!important}.rgz-readout-text{fill:#111!important;font-size:13px;font-weight:900} marker path{fill:#111}@media screen{body{background:#ddd}.page{margin:12px auto;background:white;box-shadow:0 6px 26px rgba(0,0,0,.22)}}\n      </style></head><body>${m.join("")}<script>window.onload=()=>setTimeout(()=>window.print(),250);<\/script></body></html>`,
                h = window.open("", "_blank", "width=1200,height=800");
              h
                ? (h.document.open(), h.document.write(y), h.document.close())
                : lt(
                    "Popup blocked. Please allow popups for the print view.",
                    "warning",
                  );
            })(e, a, n)
          );
        }
        (e.target === t || e.target.closest("[data-modal-close]")) &&
          t.remove();
      }));
  }
  function Ge(e = 100) {
    if (!p.components.length) return { x: 0, y: 0, w: 1200, h: 800 };
    let t = 1 / 0,
      r = 1 / 0,
      n = -1 / 0,
      a = -1 / 0;
    return (
      p.components.forEach((e) => {
        const i = $(e.type) || { w: 100, h: 80 };
        ((t = Math.min(t, e.x - i.w / 2)),
          (n = Math.max(n, e.x + i.w / 2)),
          (r = Math.min(r, e.y - i.h / 2)),
          (a = Math.max(a, e.y + i.h / 2)));
      }),
      {
        x: t - e,
        y: r - e,
        w: Math.max(500, n - t + 2 * e),
        h: Math.max(320, a - r + 2 * e),
      }
    );
  }
  function Ke() {
    if (!w) return;
    const e = p.projectMeta;
    w.innerHTML = `\n      <div><strong>Project:</strong> ${M(e.projectName || "Untitled")}</div>\n      <div><strong>Designer:</strong> ${M(e.designer || "-")}</div>\n      <div><strong>Date:</strong> ${new Date().toLocaleDateString()}</div>\n      <div><strong>Standard/template:</strong> ${M(e.standard || "ISO-style")}</div>\n      <div><strong>Revision:</strong> ${M(e.revision || "A")}</div>\n      <div><strong>Made in RGZ Hydraulic Studio:</strong> ${M(r)}</div>\n    `;
  }
  async function _e(t, r = {}, n = e.authNonce) {
    if (!e.ajaxUrl)
      throw new Error("WordPress AJAX endpoint is not configured.");
    const a = new FormData();
    (a.append("action", t),
      a.append("nonce", n || ""),
      p.accountToken && a.append("token", p.accountToken),
      Object.entries(r).forEach(([e, t]) => a.append(e, null == t ? "" : t)));
    const i = await fetch(e.ajaxUrl, {
        method: "POST",
        body: a,
        credentials: "same-origin",
      }),
      o = await i.json().catch(() => null);
    if (!i.ok || !o || !o.success)
      throw new Error(o?.data?.message || "Request failed.");
    return (
      o.data?.nonces &&
        ((e.authNonce = o.data.nonces.authNonce || e.authNonce),
        (e.saveNonce = o.data.nonces.saveNonce || e.saveNonce)),
      Object.prototype.hasOwnProperty.call(o.data || {}, "token") &&
        ((p.accountToken = o.data.token || ""),
        p.accountToken
          ? localStorage.setItem("rgzHydraulicAccountToken", p.accountToken)
          : localStorage.removeItem("rgzHydraulicAccountToken")),
      Object.prototype.hasOwnProperty.call(o.data || {}, "user") &&
        (p.user = o.data.user || null),
      o.data || {}
    );
  }
  function Ze(t = {}) {
    return new Promise((r) => {
      const a = n.querySelector(".rgz-modal-backdrop");
      a && a.remove();
      const i = document.createElement("div");
      ((i.className = "rgz-modal-backdrop"), n.appendChild(i));
      const o = (e) => {
          (i.remove(), r(e || null));
        },
        s = () => {
          p.user
            ? ((i.innerHTML = `\n            <div class="rgz-modal rgz-auth-modal" role="dialog" aria-modal="true" aria-label="RGZ account">\n              <div class="rgz-modal-head"><div><h3>RGZ Hydraulics account</h3><p>${M(p.user.name)} · ${M(p.user.email)}</p></div><button class="rgz-btn icon" data-modal-close>×</button></div>\n              <div class="rgz-modal-body"><div class="rgz-panel"><div class="rgz-panel-title">My earlier designs</div><div id="rgz-my-designs" class="rgz-design-list"><div class="rgz-message info">Loading designs…</div></div></div></div>\n              <div class="rgz-modal-foot"><button class="rgz-btn" data-auth-logout>Sign out</button><button class="rgz-btn primary" data-modal-done>Continue</button></div>\n            </div>`),
              (async function (e) {
                if (e)
                  try {
                    const t =
                      (await _e("rgz_hydraulic_my_designs")).designs || [];
                    if (!t.length)
                      return void (e.innerHTML =
                        '<div class="rgz-message info"><strong>No saved designs yet</strong><br>Save/export a sketch and it will appear here.</div>');
                    e.innerHTML = t
                      .map(
                        (e) =>
                          `\n        <div class="rgz-design-row">\n          <div><strong>${M(e.file_name || "hydraulic-project.rgz")}</strong><span>${M(e.created_at || "")} · ${Math.round(Number(e.file_size || 0) / 1024)} KB${e.password_hint ? " · hint: " + M(e.password_hint) : ""}</span></div>\n          <div><button class="rgz-btn" data-design-action="load" data-id="${M(e.id)}">Load</button><button class="rgz-btn" data-design-action="download" data-id="${M(e.id)}">Download</button></div>\n        </div>`,
                      )
                      .join("");
                  } catch (t) {
                    e.innerHTML = `<div class="rgz-message error"><strong>Error</strong><br>${M(t.message)}</div>`;
                  }
              })(i.querySelector("#rgz-my-designs")))
            : (i.innerHTML = `\n            <div class="rgz-modal rgz-auth-modal" role="dialog" aria-modal="true" aria-label="Sign in or sign up">\n              <div class="rgz-modal-head"><div><h3>Sign in to save designs</h3><p>Create an account once, then your encrypted sketches appear under My designs.</p></div><button class="rgz-btn icon" data-modal-close>×</button></div>\n              <div class="rgz-modal-body">\n                <div class="rgz-tabs"><button class="rgz-tab ${"signin" === p.authMode ? "active" : ""}" data-auth-mode="signin">Sign in</button><button class="rgz-tab ${"signup" === p.authMode ? "active" : ""}" data-auth-mode="signup">Easy sign up</button><button class="rgz-tab" data-auth-mode="info">Why?</button></div>\n                ${"signup" === p.authMode ? '\n                  <div class="rgz-panel"><div class="rgz-panel-title">Create account</div><div class="rgz-field"><label>Name</label><input class="rgz-small-input" id="rgz-auth-name" autocomplete="name" /></div><div class="rgz-field"><label>Email</label><input class="rgz-small-input" id="rgz-auth-email" type="email" autocomplete="email" /></div><div class="rgz-field"><label>Password</label><input class="rgz-small-input" id="rgz-auth-password" type="password" autocomplete="new-password" /></div><button class="rgz-btn primary" style="width:100%;margin-top:12px" data-auth-submit="signup">Create account</button></div>' : "info" === p.authMode ? '\n                  <div class="rgz-panel"><div class="rgz-panel-title">Why account?</div><p>Your encrypted designs can be listed, downloaded, and loaded later from your own account. The backend stays organized by user and email.</p><p>Your design encryption password is stored encrypted for administrator/teacher support. Your RGZ account sign-in password is never visible to the site owner.</p></div>' : '\n                  <div class="rgz-panel"><div class="rgz-panel-title">Sign in</div><div class="rgz-field"><label>Email or username</label><input class="rgz-small-input" id="rgz-auth-login" autocomplete="username" /></div><div class="rgz-field"><label>Password</label><input class="rgz-small-input" id="rgz-auth-password" type="password" autocomplete="current-password" /></div><button class="rgz-btn primary" style="width:100%;margin-top:12px" data-auth-submit="signin">Sign in</button></div>'}\n              </div>\n              <div class="rgz-modal-foot"><span>Required before saving encrypted designs.</span><button class="rgz-btn" data-modal-close>Cancel</button></div>\n            </div>`);
        };
      (s(),
        i.addEventListener("click", async (r) => {
          if (r.target === i || r.target.closest("[data-modal-close]"))
            return o(null);
          const n = r.target.closest("[data-auth-mode]");
          if (n) return ((p.authMode = n.dataset.authMode), void s());
          if (r.target.closest("[data-modal-done]")) return o(p.user);
          if (r.target.closest("[data-auth-logout]")) {
            try {
              (await _e("rgz_hydraulic_logout"),
                (p.user = null),
                (e.user = null),
                s());
            } catch (e) {
              lt(e.message, "error");
            }
            return;
          }
          const a = r.target.closest("[data-auth-submit]");
          if (a)
            try {
              if ("signin" === a.dataset.authSubmit) {
                const e = await _e("rgz_hydraulic_login", {
                  login: i.querySelector("#rgz-auth-login")?.value || "",
                  password: i.querySelector("#rgz-auth-password")?.value || "",
                });
                p.user = e.user;
              } else {
                const e = await _e("rgz_hydraulic_register", {
                  name: i.querySelector("#rgz-auth-name")?.value || "",
                  email: i.querySelector("#rgz-auth-email")?.value || "",
                  password: i.querySelector("#rgz-auth-password")?.value || "",
                });
                p.user = e.user;
              }
              if ((lt(`Signed in as ${p.user.name}.`, "ok"), t.required))
                return o(p.user);
              s();
            } catch (e) {
              lt(e.message, "error");
            }
          const l = r.target.closest("[data-design-action]");
          if (l) {
            const e = l.dataset.id,
              t = l.dataset.designAction;
            ("download" === t &&
              (await (async function (e) {
                try {
                  const t = await Ye(e);
                  et(
                    new Blob([Xe(t.file_base64)], {
                      type: "application/octet-stream",
                    }),
                    t.file_name || "hydraulic-project.rgz",
                  );
                } catch (e) {
                  lt(e.message, "error");
                }
              })(e)),
              "load" === t &&
                (await (async function (e) {
                  try {
                    const t = await Ye(e);
                    await Qe(Xe(t.file_base64));
                  } catch (e) {
                    lt(e.message, "error");
                  }
                })(e),
                o(p.user)));
          }
        }));
    });
  }
  async function We() {
    const t = await (async function () {
      return p.user ? p.user : Ze({ required: !0 });
    })();
    if (!t) return;
    const r = await new Promise((e) => {
      const t = n.querySelector(".rgz-modal-backdrop");
      t && t.remove();
      const r = document.createElement("div");
      ((r.className = "rgz-modal-backdrop"),
        (r.innerHTML = `\n        <div class="rgz-modal rgz-auth-modal" role="dialog" aria-modal="true" aria-label="Save encrypted design">\n          <div class="rgz-modal-head"><div><h3>Save encrypted design</h3><p>Signed in as ${M(p.user?.name || "")} · ${M(p.user?.email || "")}</p></div><button class="rgz-btn icon" data-modal-close>×</button></div>\n          <div class="rgz-modal-body">\n            <div class="rgz-panel">\n              <div class="rgz-panel-title">Encryption</div>\n              <div class="rgz-field"><label>Design encryption password</label><input class="rgz-small-input" type="password" id="rgz-save-password" autocomplete="new-password" /></div>\n              <div class="rgz-field"><label>Optional password hint, not the password</label><input class="rgz-small-input" id="rgz-save-hint" placeholder="Example: usual project password" /></div>\n              <p>The .rgz file is encrypted in the browser. For teacher support, the design password is stored encrypted in the RGZ Hydraulics backend and visible only to site administrators.</p>\n            </div>\n          </div>\n          <div class="rgz-modal-foot"><button class="rgz-btn" data-modal-close>Cancel</button><button class="rgz-btn primary" data-save-confirm>Save / Export</button></div>\n        </div>`),
        n.appendChild(r),
        r.querySelector("#rgz-save-password")?.focus(),
        r.addEventListener("click", (t) => {
          if (
            ((t.target === r || t.target.closest("[data-modal-close]")) &&
              (r.remove(), e(null)),
            t.target.closest("[data-save-confirm]"))
          ) {
            const t = r.querySelector("#rgz-save-password")?.value || "",
              n = r.querySelector("#rgz-save-hint")?.value || "";
            if (!t)
              return void lt("Please enter an encryption password.", "warning");
            (r.remove(), e({ password: t, passwordHint: n }));
          }
        }));
    });
    if (!r) return;
    const { password: a, passwordHint: i } = r;
    try {
      p.projectMeta.designer || (p.projectMeta.designer = t.name);
      const r = q();
      ((r.metadata.designer = t.name), (r.metadata.email = t.email));
      const __thumb = __rgzBlueprint(r);
      const n = new TextEncoder().encode(JSON.stringify(r)),
        o = await (async function (e) {
          if ("CompressionStream" in window) {
            const t = new CompressionStream("gzip"),
              r = t.writable.getWriter();
            return (
              r.write(e),
              r.close(),
              {
                bytes: new Uint8Array(
                  await new Response(t.readable).arrayBuffer(),
                ),
                compressed: !0,
              }
            );
          }
          return { bytes: e, compressed: !1 };
        })(n),
        s = crypto.getRandomValues(new Uint8Array(16)),
        l = crypto.getRandomValues(new Uint8Array(12)),
        c = await Je(a, s),
        d = new Uint8Array(
          await crypto.subtle.encrypt({ name: "AES-GCM", iv: l }, c, o.bytes),
        ),
        u = new Uint8Array(5 + s.length + l.length + d.length);
      (u.set(new TextEncoder().encode("RGZ1"), 0),
        (u[4] = o.compressed ? 1 : 0),
        u.set(s, 5),
        u.set(l, 21),
        u.set(d, 33));
      const m = `${
        (r.metadata.projectName || "hydraulic-project")
          .replace(/[^a-z0-9-_]+/gi, "-")
          .replace(/^-|-$/g, "")
          .toLowerCase() || "hydraulic-project"
      }.rgz`;
      (et(new Blob([u], { type: "application/octet-stream" }), m),
        await (async function ({
          bytes: t,
          fileName: r,
          passwordHint: n,
          designPassword: a,
          thumb: __thumb,
        }) {
          const i = Number(e.maxUploadBytes || 524288);
          if (!e.ajaxUrl || !e.saveNonce)
            return void lt(
              "Local export complete. Backend storage is not configured.",
              "warning",
            );
          if (t.byteLength > i)
            return void lt(
              "Local export complete. Backend storage skipped because the .rgz file is larger than 512 KB.",
              "warning",
            );
          const o = new FormData();
          (o.append("action", "rgz_hydraulic_save_design"),
            o.append("nonce", e.saveNonce),
            p.accountToken && o.append("token", p.accountToken),
            o.append("password_hint", n || ""),
            o.append("design_password", a || ""),
            o.append("file_name", r),
            o.append("thumb", __thumb || ""),
            o.append(
              "file_base64",
              (function (e) {
                let t = "";
                for (let r = 0; r < e.length; r += 32768)
                  t += String.fromCharCode.apply(
                    null,
                    e.subarray(r, r + 32768),
                  );
                return btoa(t);
              })(t),
            ));
          const s = await fetch(e.ajaxUrl, {
              method: "POST",
              body: o,
              credentials: "same-origin",
            }),
            l = await s.json().catch(() => null);
          if (!s.ok || !l || !l.success)
            throw new Error(
              l?.data?.message ||
                "The encrypted design could not be stored in RGZ Hydraulics.",
            );
          l.data?.nonces &&
            ((e.authNonce = l.data.nonces.authNonce || e.authNonce),
            (e.saveNonce = l.data.nonces.saveNonce || e.saveNonce));
        })({ bytes: u, fileName: m, passwordHint: i, designPassword: a, thumb: __thumb }),
        lt(
          "Encrypted .rgz file exported and saved to your RGZ Hydraulics account.",
          "ok",
        ));
    } catch (e) {
      lt("Export failed: " + e.message, "error");
    }
  }
  function Xe(e) {
    const t = atob(e),
      r = new Uint8Array(t.length);
    for (let e = 0; e < t.length; e++) r[e] = t.charCodeAt(e);
    return r;
  }
  function __rgzBlueprint(proj) {
    try {
      const comps = (proj.components || []).map((c) => {
        const d = $(c.type) || {};
        return [c.type, Math.round(c.x), Math.round(c.y), c.rotation || 0, d.w || 64, d.h || 64];
      });
      const conns = [];
      (proj.connections || []).forEach((l) => {
        const a = T(l.from.componentId, l.from.portId),
          b = T(l.to.componentId, l.to.portId);
        if (a && b) conns.push([Math.round(a.x), Math.round(a.y), Math.round(b.x), Math.round(b.y), l.lineType || "pressure"]);
      });
      return JSON.stringify({ v: 1, comps, conns });
    } catch (e) { return ""; }
  }
  async function Ye(e) {
    const t = await _e("rgz_hydraulic_get_design", { id: e });
    if (!t.design?.file_base64) throw new Error("Stored design file is empty.");
    return t.design;
  }
  async function Qe(e) {
    const t = window.prompt("Enter the password for this .rgz file:");
    if (t)
      try {
        if ("RGZ1" !== new TextDecoder().decode(e.slice(0, 4)))
          throw new Error("Invalid RGZ file header.");
        const r = 1 === e[4],
          n = e.slice(5, 21),
          a = e.slice(21, 33),
          i = e.slice(33),
          o = await Je(t, n),
          s = new Uint8Array(
            await crypto.subtle.decrypt({ name: "AES-GCM", iv: a }, o, i),
          ),
          l = r
            ? await (async function (e) {
                if ("DecompressionStream" in window) {
                  const t = new DecompressionStream("gzip"),
                    r = t.writable.getWriter();
                  return (
                    r.write(e),
                    r.close(),
                    new Uint8Array(await new Response(t.readable).arrayBuffer())
                  );
                }
                throw new Error(
                  "This browser cannot decompress gzip RGZ files. Try a modern Chrome/Edge browser.",
                );
              })(s)
            : s;
        I(JSON.parse(new TextDecoder().decode(l)));
      } catch (e) {
        lt("Import failed. Wrong password or damaged .rgz file.", "error");
      }
  }
  /* Deep link from the Mechanical Deck "My designs": open a saved design directly. */
  (function () {
    let openId = null;
    try {
      const m = (window.location.hash || "").match(/rgz-open=(\d+)/);
      if (m) openId = m[1];
    } catch (e0) {}
    if (!openId) return;
    setTimeout(async () => {
      try {
        if (!p.accountToken) {
          lt("Sign in via the account dialog to open your saved design from the deck.", "warning");
          return;
        }
        const d = await Ye(openId);
        await Qe(Xe(d.file_base64));
        lt("Saved design loaded from your deck profile.", "ok");
      } catch (err) {
        lt("Could not open the saved design: " + ((err && err.message) || err), "error");
      }
      try { history.replaceState(null, "", window.location.pathname + window.location.search); } catch (e1) {}
    }, 800);
  })();
  async function Je(e, t) {
    const r = await crypto.subtle.importKey(
      "raw",
      new TextEncoder().encode(e),
      "PBKDF2",
      !1,
      ["deriveKey"],
    );
    return crypto.subtle.deriveKey(
      { name: "PBKDF2", salt: t, iterations: 21e4, hash: "SHA-256" },
      r,
      { name: "AES-GCM", length: 256 },
      !1,
      ["encrypt", "decrypt"],
    );
  }
  function et(e, t) {
    const r = document.createElement("a");
    ((r.href = URL.createObjectURL(e)),
      (r.download = t),
      document.body.appendChild(r),
      r.click(),
      setTimeout(() => {
        (URL.revokeObjectURL(r.href), r.remove());
      }, 500));
  }
  function tt(e = 1) {
    const t = p.viewBox,
      r = t.x + t.w / 2,
      n = t.y + t.h / 2,
      a = z(t.w * e, 300, 5e3),
      i = z(t.h * e, 200, 3500);
    ((p.viewBox = { x: r - a / 2, y: n - i / 2, w: a, h: i }), R());
  }
  function rt(e) {
    const t = `rgz-show-${e}`,
      r = n.classList.contains(t);
    (["rgz-show-library", "rgz-show-actions", "rgz-show-inspector"].forEach(
      (e) => n.classList.remove(e),
    ),
      r || n.classList.add(t));
  }
  function nt() {
    const e = window.visualViewport
      ? window.visualViewport.height
      : window.innerHeight;
    document.documentElement.style.setProperty("--rgz-vh", `${e}px`);
  }
  function at() {
    if (
      (nt(),
      !window.matchMedia("(max-width: 920px) and (orientation: landscape)")
        .matches || document.fullscreenElement)
    )
      return;
    const e = document.documentElement.requestFullscreen
      ? document.documentElement
      : n;
    (e.requestFullscreen &&
      e.requestFullscreen({ navigationUI: "hide" }).catch(() => {}),
      screen.orientation &&
        screen.orientation.lock &&
        screen.orientation.lock("landscape").catch(() => {}),
      setTimeout(() => window.scrollTo(0, 1), 80));
  }
  function it(e = 90) {
    if ("component" !== p.selected?.kind)
      return void lt(
        "Select a schematic symbol first, then rotate it.",
        "info",
      );
    const t = p.components.find((e) => e.id === p.selected.id);
    t &&
      ((t.rotation = (((P(t.rotation, 0) + e) % 360) + 360) % 360), H(), ke());
  }
  function ot() {
    if (p.selected) {
      if ("component" === p.selected.kind) {
        const e = p.selected.id;
        ((p.components = p.components.filter((t) => t.id !== e)),
          (p.connections = p.connections.filter(
            (t) => t.from.componentId !== e && t.to.componentId !== e,
          )));
      } else
        "connection" === p.selected.kind &&
          (p.connections = p.connections.filter((e) => e.id !== p.selected.id));
      ((p.selected = null), H(), ke());
    }
  }
  function st() {
    if (!p.components.length)
      return ((p.viewBox = { x: 0, y: 0, w: 1800, h: 1200 }), void R());
    const e = p.components.map((e) => e.x),
      t = p.components.map((e) => e.y),
      r = Math.min(...e) - 220,
      n = Math.max(...e) + 220,
      a = Math.min(...t) - 180,
      i = Math.max(...t) + 180;
    ((p.viewBox = {
      x: r,
      y: a,
      w: Math.max(600, n - r),
      h: Math.max(380, i - a),
    }),
      R());
  }
  function lt(e, t = "info") {
    const r = document.getElementById("rgz-toasts");
    if (!r) return;
    const n = document.createElement("div");
    ((n.className = `rgz-toast ${t}`),
      (n.textContent = e),
      r.appendChild(n),
      setTimeout(() => {
        ((n.style.opacity = "0"), (n.style.transform = "translateY(-6px)"));
      }, 3600),
      setTimeout(() => n.remove(), 4200));
  }
  const ct = [
    "Simple circuits",
    "Intermediate electrohydraulic circuits",
    "Advanced real-world class circuits",
  ];
  function dt() {
    const e = [...ct];
    return (
      yt.forEach((t) => {
        t.level && !e.includes(t.level) && e.push(t.level);
      }),
      e
    );
  }
  function pt(e = p.exampleLevel) {
    return yt
      .map((e, t) => Object.assign({ globalIndex: t }, e))
      .filter((t) => t.level === e);
  }
  function ut() {
    const e = document.getElementById("rgz-level-selectbox"),
      t = document.getElementById("rgz-example-selectbox");
    if (!e || !t) return;
    const r = dt();
    r.includes(p.exampleLevel) || (p.exampleLevel = r[0]);
    const n = pt(p.exampleLevel);
    ((p.exampleIndex = Math.floor(
      z(P(p.exampleIndex, 0), 0, Math.max(0, n.length - 1)),
    )),
      (e.innerHTML = r
        .map(
          (e) =>
            `<option value="${M(e)}" ${e === p.exampleLevel ? "selected" : ""}>${M(
              (function (e) {
                return String(e || "")
                  .replace(" electrohydraulic circuits", "")
                  .replace(" electropneumatic circuits", "")
                  .replace(" real-world class circuits", "");
              })(e),
            )}</option>`,
        )
        .join("")),
      (t.innerHTML = n
        .map(
          (e, t) =>
            `<option value="${t}" ${t === p.exampleIndex ? "selected" : ""}>${String(t + 1).padStart(2, "0")} — ${M(e.name)}</option>`,
        )
        .join("")),
      (e.onchange = () => {
        ((p.exampleLevel = e.value), (p.exampleIndex = 0), ut());
        const t = pt(p.exampleLevel)[0],
          r = document.getElementById("rgz-example-preview");
        r && t && (r.textContent = `01 — ${t.name}`);
      }),
      (t.onchange = () => {
        p.exampleIndex = P(t.value, 0);
        const e = pt(p.exampleLevel)[p.exampleIndex],
          r = document.getElementById("rgz-example-preview");
        r &&
          e &&
          (r.textContent = `${String(p.exampleIndex + 1).padStart(2, "0")} — ${e.name}`);
      }));
  }
  function mt() {
    const e = pt(p.exampleLevel),
      t = e[p.exampleIndex] || e[0];
    t &&
      ((p.currentExampleGlobalIndex = t.globalIndex),
      I(ht(t.globalIndex)),
      (p.currentExampleGlobalIndex = t.globalIndex),
      st());
  }
  const yt = [
    {
      level: "Simple circuits",
      name: "Pump, tank, relief valve and pressure gauge",
      builder: function () {
        const {
          project: e,
          add: t,
          connect: r,
        } = gt("Pump, tank, relief valve and pressure gauge");
        return (vt(t, 0, 430), e);
      },
    },
    {
      level: "Simple circuits",
      name: "Single-acting cylinder with 3/2 valve",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = gt("Single-acting cylinder with 3/2 valve"),
          n = vt(t),
          a = t(
            "directionalValve",
            620,
            420,
            {
              ports: "3",
              positions: "2",
              center: "closed",
              spoolState: "left",
              leftActuation: "manual",
              rightActuation: "spring",
            },
            "V1",
          ),
          i = t(
            "cylinderSA",
            880,
            330,
            { boreMm: 50, strokeMm: 300, loadKg: 100 },
            "C1",
          );
        return (
          r(n.pump, "P", a, "P", "pressure"),
          r(a, "T", n.tank, "T", "return"),
          r(a, "A", i, "A", "pressure"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Double-acting cylinder with 4/2 valve + end sensors",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = gt("Double-acting cylinder with 4/2 valve + end sensors"),
          n = vt(t),
          a = t(
            "directionalValve",
            620,
            420,
            {
              ports: "4",
              positions: "2",
              spoolState: "left",
              leftActuation: "solenoid",
              rightActuation: "solenoid",
            },
            "V1",
          ),
          i = t(
            "cylinderDA",
            900,
            330,
            { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 350 },
            "C1",
          );
        return (
          t(
            "cylinderReedSensor",
            900,
            230,
            {
              linkedActuator: "C1",
              triggerAt: "extended",
              action: "set valve right",
              targetControl: "V1",
            },
            "B1-EXT",
          ),
          t(
            "cylinderReedSensor",
            900,
            430,
            {
              linkedActuator: "C1",
              triggerAt: "retracted",
              action: "set valve left",
              targetControl: "V1",
            },
            "B2-RET",
          ),
          r(n.pump, "P", a, "P", "pressure"),
          r(a, "T", n.tank, "T", "return"),
          r(a, "A", i, "A", "pressure"),
          r(a, "B", i, "B", "return"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Double-acting cylinder with 4/3 closed center",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = gt("Double-acting cylinder with 4/3 closed center"),
          n = vt(t),
          a = t(
            "directionalValve",
            620,
            420,
            {
              ports: "4",
              positions: "3",
              center: "closed",
              spoolState: "left",
              leftActuation: "solenoid",
              rightActuation: "solenoid",
            },
            "V1",
          ),
          i = t(
            "cylinderDA",
            900,
            330,
            { boreMm: 80, rodMm: 45, strokeMm: 600, loadKg: 550 },
            "C1",
          );
        return (
          r(n.pump, "P", a, "P", "pressure"),
          r(a, "T", n.tank, "T", "return"),
          r(a, "A", i, "A", "pressure"),
          r(a, "B", i, "B", "return"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Double-acting cylinder with 4/3 tandem center",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = gt("Double-acting cylinder with 4/3 tandem center"),
          n = vt(t),
          a = t(
            "directionalValve",
            620,
            420,
            {
              ports: "4",
              positions: "3",
              center: "tandem",
              spoolState: "center",
              leftActuation: "lever",
              rightActuation: "spring",
            },
            "V1",
          ),
          i = t(
            "cylinderDA",
            900,
            330,
            { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 350 },
            "C1",
          );
        return (
          r(n.pump, "P", a, "P", "pressure"),
          r(a, "T", n.tank, "T", "return"),
          r(a, "A", i, "A", "pressure"),
          r(a, "B", i, "B", "return"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Meter-in speed control",
      builder: function () {
        const { project: e, add: t, connect: r } = gt("Meter-in speed control"),
          n = vt(t),
          a = t(
            "directionalValve",
            610,
            420,
            {
              ports: "4",
              positions: "3",
              center: "closed",
              spoolState: "left",
            },
            "V1",
          ),
          i = t("flowControl", 780, 310, { openingPercent: 45 }, "FC1"),
          o = t(
            "cylinderDA",
            980,
            310,
            { boreMm: 63, rodMm: 36, strokeMm: 450, loadKg: 250 },
            "C1",
          );
        return (
          r(n.pump, "P", a, "P", "pressure"),
          r(a, "T", n.tank, "T", "return"),
          r(a, "A", i, "A", "pressure"),
          r(i, "B", o, "A", "pressure"),
          r(a, "B", o, "B", "return"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Meter-out speed control",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = gt("Meter-out speed control"),
          n = vt(t),
          a = t(
            "directionalValve",
            610,
            420,
            {
              ports: "4",
              positions: "3",
              center: "closed",
              spoolState: "left",
            },
            "V1",
          ),
          i = t("flowControl", 790, 455, { openingPercent: 38 }, "FC1"),
          o = t(
            "cylinderDA",
            980,
            310,
            { boreMm: 63, rodMm: 36, strokeMm: 450, loadKg: 250 },
            "C1",
          );
        return (
          r(n.pump, "P", a, "P", "pressure"),
          r(a, "T", n.tank, "T", "return"),
          r(a, "A", o, "A", "pressure"),
          r(o, "B", i, "A", "return"),
          r(i, "B", a, "B", "return"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Regenerative cylinder extension",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = gt("Regenerative cylinder extension"),
          n = vt(t),
          a = t(
            "directionalValve",
            610,
            420,
            {
              ports: "4",
              positions: "3",
              center: "regenerative",
              spoolState: "center",
            },
            "V1",
          ),
          o = t(
            "cylinderDA",
            930,
            310,
            { boreMm: 80, rodMm: 50, strokeMm: 500, loadKg: 180 },
            "C1",
          );
        return (
          r(n.pump, "P", a, "P", "pressure"),
          r(a, "T", n.tank, "T", "return"),
          r(a, "A", o, "A", "pressure"),
          r(a, "B", o, "B", "pressure"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Sequence valve clamp-and-work circuit",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = gt("Sequence valve clamp-and-work circuit"),
          n = vt(t),
          a = t(
            "directionalValve",
            570,
            440,
            {
              ports: "4",
              positions: "3",
              center: "closed",
              spoolState: "left",
            },
            "V1",
          ),
          i = t(
            "cylinderDA",
            840,
            260,
            { boreMm: 50, rodMm: 28, strokeMm: 250, loadKg: 150 },
            "Clamp",
          ),
          o = t("sequenceValve", 780, 430, { settingBar: 55 }, "SV1"),
          s = t(
            "cylinderDA",
            1040,
            430,
            { boreMm: 80, rodMm: 45, strokeMm: 400, loadKg: 500 },
            "Work",
          ),
          l = t("checkValve", 780, 560, { crackingBar: 0.5 }, "CV1");
        return (
          (l.rotation = 180),
          r(n.pump, "P", a, "P", "pressure"),
          r(a, "T", n.tank, "T", "return"),
          r(a, "A", i, "A", "pressure"),
          r(a, "A", o, "P", "pressure"),
          r(o, "A", s, "A", "pressure"),
          r(s, "A", l, "A", "pressure"),
          r(l, "B", o, "P", "pressure"),
          r(i, "B", a, "B", "return"),
          r(s, "B", a, "B", "return"),
          r(o, "T", n.tank, "T", "drain"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Pressure reducing branch circuit",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = gt("Pressure reducing branch circuit"),
          n = vt(t),
          a = t(
            "directionalValve",
            570,
            440,
            {
              ports: "4",
              positions: "3",
              center: "closed",
              spoolState: "left",
            },
            "V1",
          ),
          i = t("reducingValve", 770, 295, { outletBar: 45 }, "PRV1"),
          o = t(
            "cylinderDA",
            1e3,
            285,
            { boreMm: 50, rodMm: 28, strokeMm: 350, loadKg: 120 },
            "LowP",
          ),
          s = t(
            "cylinderDA",
            1e3,
            500,
            { boreMm: 63, rodMm: 36, strokeMm: 350, loadKg: 280 },
            "Main",
          );
        return (
          r(n.pump, "P", a, "P", "pressure"),
          r(a, "T", n.tank, "T", "return"),
          r(a, "A", i, "P", "pressure"),
          r(i, "A", o, "A", "pressure"),
          r(i, "T", n.tank, "T", "drain"),
          r(a, "A", s, "A", "pressure"),
          r(o, "B", a, "B", "return"),
          r(s, "B", a, "B", "return"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Counterbalance vertical cylinder circuit",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = gt("Counterbalance vertical cylinder circuit"),
          n = vt(t),
          a = t(
            "directionalValve",
            580,
            440,
            {
              ports: "4",
              positions: "3",
              center: "closed",
              spoolState: "left",
            },
            "V1",
          ),
          i = t(
            "counterbalanceValve",
            810,
            455,
            { settingBar: 120, pilotRatio: 3 },
            "CBV1",
          ),
          o = t(
            "cylinderDA",
            1030,
            330,
            { boreMm: 80, rodMm: 45, strokeMm: 700, loadKg: 800 },
            "Vertical",
          );
        return (
          r(n.pump, "P", a, "P", "pressure"),
          r(a, "T", n.tank, "T", "return"),
          r(a, "A", o, "A", "pressure"),
          r(o, "B", i, "A", "return"),
          r(i, "B", a, "B", "return"),
          r(a, "A", i, "X", "pilot"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Pilot-operated check valve load holding",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = gt("Pilot-operated check valve load holding"),
          n = vt(t),
          a = t(
            "directionalValve",
            580,
            440,
            {
              ports: "4",
              positions: "3",
              center: "closed",
              spoolState: "left",
            },
            "V1",
          ),
          i = t("pilotCheckValve", 800, 310, { pilotRatio: 3 }, "PCV1"),
          o = t(
            "cylinderDA",
            1030,
            330,
            { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 400 },
            "C1",
          );
        return (
          r(n.pump, "P", a, "P", "pressure"),
          r(a, "T", n.tank, "T", "return"),
          r(a, "A", i, "A", "pressure"),
          r(i, "B", o, "A", "pressure"),
          r(o, "B", a, "B", "return"),
          r(a, "B", i, "X", "pilot"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Hydraulic motor speed control",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = gt("Hydraulic motor speed control"),
          n = vt(t),
          a = t(
            "directionalValve",
            570,
            440,
            {
              ports: "4",
              positions: "3",
              center: "closed",
              spoolState: "left",
            },
            "V1",
          ),
          i = t("flowControl", 770, 330, { openingPercent: 60 }, "FC1"),
          o = t(
            "hydraulicMotor",
            980,
            330,
            { displacementCcRev: 25, loadNm: 22 },
            "M1",
          );
        return (
          r(n.pump, "P", a, "P", "pressure"),
          r(a, "T", n.tank, "T", "return"),
          r(a, "A", i, "A", "pressure"),
          r(i, "B", o, "A", "pressure"),
          r(o, "B", a, "B", "return"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Accumulator charging/unloading circuit",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = gt("Accumulator charging/unloading circuit"),
          n = vt(t),
          a = t(
            "accumulator",
            650,
            330,
            { prechargeBar: 70, volumeL: 5 },
            "ACC1",
          ),
          i = t("pressureSwitch", 650, 510, { switchBar: 140 }, "PS1"),
          o = t(
            "directionalValve",
            870,
            430,
            {
              ports: "3",
              positions: "2",
              center: "tandem",
              spoolState: "center",
              leftActuation: "solenoid",
              rightActuation: "spring",
            },
            "Unload",
          );
        return (
          r(n.pump, "P", a, "A", "pressure"),
          r(n.pump, "P", i, "P", "pressure"),
          r(n.pump, "P", o, "P", "pressure"),
          r(o, "A", a, "A", "pressure"),
          r(o, "T", n.tank, "T", "return"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Flow divider two-cylinder synchronization",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = gt("Flow divider two-cylinder synchronization"),
          n = vt(t),
          a = t(
            "directionalValve",
            560,
            440,
            {
              ports: "4",
              positions: "3",
              center: "closed",
              spoolState: "left",
            },
            "V1",
          ),
          i = t("flowDivider", 760, 340, { splitPercentA: 50 }, "FD1"),
          o = t(
            "cylinderDA",
            1010,
            245,
            { boreMm: 50, rodMm: 28, strokeMm: 400, loadKg: 160 },
            "C1",
          ),
          s = t(
            "cylinderDA",
            1010,
            450,
            { boreMm: 50, rodMm: 28, strokeMm: 400, loadKg: 160 },
            "C2",
          );
        return (
          r(n.pump, "P", a, "P", "pressure"),
          r(a, "T", n.tank, "T", "return"),
          r(a, "A", i, "P", "pressure"),
          r(i, "A", o, "A", "pressure"),
          r(i, "B", s, "A", "pressure"),
          r(o, "B", a, "B", "return"),
          r(s, "B", a, "B", "return"),
          e
        );
      },
    },
    ...[
      "Electrohydraulic auto-return cylinder with reed sensors",
      "Two-hand push button clamp circuit",
      "Pressure switch automatic retract circuit",
      "PLC controlled cylinder dwell circuit",
      "Sequential two-cylinder electrohydraulic circuit",
      "Motor start/stop with flow switch feedback",
      "Accumulator assisted clamp with pressure switch",
      "Counterbalance lift with limit-switch reversal",
      "Meter-out cylinder with solenoid valve control",
      "Pressure reducing branch with sensor feedback",
      "Regenerative fast approach with electric changeover",
      "Flow divider with dual cylinder end sensors",
      "Pilot check load-hold with emergency release",
      "Temperature alarm and cooler bypass control",
      "Semi-automatic press cycle with PLC I/O",
    ].map((e, t) => ({
      level: "Intermediate electrohydraulic circuits",
      name: e,
      builder: () =>
        (function (e, t = 0) {
          if (1 === t)
            return (function (e) {
              const { project: t, add: r, connect: n } = gt(e),
                a = vt(r, 0, 500),
                i = r(
                  "directionalValve",
                  500,
                  380,
                  {
                    valveType: "4/3 closed center",
                    ports: "4",
                    positions: "3",
                    center: "closed",
                    spoolState: "center",
                    leftActuation: "solenoid",
                    rightActuation: "spring",
                  },
                  "V1",
                ),
                o = r(
                  "cylinderDA",
                  910,
                  285,
                  { boreMm: 63, rodMm: 36, strokeMm: 420, loadKg: 320 },
                  "Clamp",
                ),
                s = r(
                  "pressureGauge",
                  330,
                  315,
                  { rangeBar: 250, displayUnit: "bar" },
                  "PG1",
                ),
                l = r(
                  "pressureSwitch",
                  650,
                  520,
                  {
                    switchBar: 85,
                    action: "none",
                    targetControl: "",
                  },
                  "PS1",
                ),
                c = r(
                  "pushButton",
                  275,
                  705,
                  { contact: "NO", pressed: !1 },
                  "PB1",
                ),
                d = r(
                  "pushButton",
                  425,
                  705,
                  { contact: "NO", pressed: !1 },
                  "PB2",
                ),
                p = r(
                  "plc",
                  600,
                  705,
                  {
                    program:
                      "TWO-HAND CLAMP: Q1 = PB1 AND PB2 AND NOT B1 AND NOT PS1",
                    targetControl: "",
                  },
                  "PLC1",
                ),
                u = r(
                  "solenoid",
                  760,
                  705,
                  { voltage: "24 VDC", energized: !1 },
                  "Y1",
                ),
                m = r(
                  "cylinderReedSensor",
                  910,
                  155,
                  {
                    linkedActuator: "Clamp",
                    triggerAt: "extended",
                    action: "none",
                    targetControl: "",
                  },
                  "B1",
                ),
                y = r(
                  "cylinderReedSensor",
                  910,
                  420,
                  {
                    linkedActuator: "Clamp",
                    triggerAt: "retracted",
                    action: "none",
                    targetControl: "",
                  },
                  "B2",
                );
              return (
                n(a.pump, "P", i, "P", "pressure", {
                  routeMode: "horizontal-first",
                  shift: -30,
                  color: "#ef4444",
                }),
                n(i, "T", a.tank, "T", "return", {
                  routeMode: "horizontal-first",
                  shift: 34,
                  color: "#22c55e",
                }),
                n(i, "A", o, "A", "pressure", {
                  routeMode: "horizontal-first",
                  shift: -22,
                  color: "#ef4444",
                }),
                n(i, "B", o, "B", "return", {
                  routeMode: "horizontal-first",
                  shift: 30,
                  color: "#22c55e",
                }),
                n(a.pump, "P", s, "P", "pressure", {
                  shift: -70,
                  color: "#ef4444",
                }),
                n(i, "A", l, "P", "pressure", {
                  routeMode: "vertical-first",
                  shift: 55,
                  color: "#f59e0b",
                }),
                n(c, "E2", p, "I1", "electrical", {
                  routeMode: "horizontal-first",
                  shift: -15,
                  color: "#d946ef",
                }),
                n(d, "E2", p, "I2", "electrical", {
                  routeMode: "horizontal-first",
                  shift: 15,
                  color: "#d946ef",
                }),
                n(p, "Q1", u, "E1", "electrical", {
                  routeMode: "horizontal-first",
                  color: "#d946ef",
                }),
                n(m, "E1", p, "I1", "electrical", {
                  routeMode: "vertical-first",
                  shift: -50,
                  color: "#d946ef",
                }),
                n(y, "E1", p, "I2", "electrical", {
                  routeMode: "vertical-first",
                  shift: 50,
                  color: "#d946ef",
                }),
                (t.viewBox = { x: 40, y: 70, w: 1120, h: 760 }),
                t
              );
            })(e);
          const { project: r, add: n, connect: a } = gt(e),
            i = vt(n, 0, 500),
            o = n(
              "directionalValve",
              500,
              390,
              {
                ports: "4",
                positions: "3",
                center: "closed",
                spoolState: "left",
                leftActuation: "solenoid",
                rightActuation: "solenoid",
              },
              "V1",
            ),
            s = n(
              "cylinderDA",
              920,
              260,
              { boreMm: 63, rodMm: 36, strokeMm: 450, loadKg: 300 },
              "C1",
            ),
            l = n("plc", 470, 705, { program: "" }, "PLC1");
          (a(i.pump, "P", o, "P", "pressure", { shift: -20 }),
            a(o, "T", i.tank, "T", "return", { shift: 20 }),
            a(o, "A", s, "A", "pressure", {
              routeMode: "horizontal-first",
              shift: -15,
            }),
            a(o, "B", s, "B", "return", {
              routeMode: "horizontal-first",
              shift: 25,
            }));
          const c = (e) =>
            (r.connections = r.connections.filter(
              (t) => !(t.from.componentId === o.id && t.from.portId === e),
            ));
          if (0 === t) {
            l.props.program =
              "AUTO-RETURN: B1 -> V1 right; B2 -> V1 left";
            const e = n(
                "cylinderReedSensor",
                920,
                140,
                {
                  linkedActuator: "C1",
                  triggerAt: "extended",
                  action: "none",
                  targetControl: "",
                },
                "B1",
              ),
              t = n(
                "cylinderReedSensor",
                920,
                395,
                {
                  linkedActuator: "C1",
                  triggerAt: "retracted",
                  action: "none",
                  targetControl: "",
                },
                "B2",
              );
            (a(e, "E1", l, "I1", "electrical", { color: "#d946ef" }),
              a(t, "E1", l, "I2", "electrical", { color: "#d946ef" }));
          } else if (2 === t) {
            l.props.program =
              "PRESSURE CLAMP: PS1 -> V1 right; B2 -> V1 center";
            const e = n(
                "pressureSwitch",
                650,
                520,
                {
                  switchBar: 120,
                  action: "none",
                  targetControl: "",
                },
                "PS1",
              ),
              t = n(
                "cylinderReedSensor",
                920,
                140,
                {
                  linkedActuator: "C1",
                  triggerAt: "extended",
                  action: "none",
                  targetControl: "",
                },
                "B1",
              ),
              u = n(
                "cylinderReedSensor",
                920,
                395,
                {
                  linkedActuator: "C1",
                  triggerAt: "retracted",
                  action: "none",
                  targetControl: "",
                },
                "B2",
              );
            (a(o, "A", e, "P", "pressure", {
              routeMode: "vertical-first",
              shift: 55,
              color: "#f59e0b",
            }),
              a(e, "E", l, "I1", "electrical", { color: "#d946ef" }),
              a(t, "E1", l, "I2", "electrical", { color: "#d946ef" }),
              a(u, "E1", l, "I2", "electrical", { color: "#d946ef" }));
          } else if (3 === t) {
            ((l.props.program =
              "DWELL: Q1 = SB1 OR Q1 AND NOT B1; Q2 = B1 AND NOT B2; Y2 = T1 OR Y2 AND NOT B2; B2 -> T1 reset"),
              o.props.spoolState = "center");
            const e = n(
                "pushButton",
                260,
                705,
                { contact: "NO", pressed: !1 },
                "SB1",
              ),
              t = n(
                "timerRelay",
                660,
                560,
                { delayS: 3, mode: "on-delay" },
                "T1",
              ),
              u = n(
                "solenoid",
                820,
                645,
                { voltage: "24 VDC", energized: !1 },
                "Y1",
              ),
              m = n(
                "solenoid",
                820,
                755,
                { voltage: "24 VDC", energized: !1 },
                "Y2",
              ),
              y = n(
                "cylinderReedSensor",
                920,
                140,
                {
                  linkedActuator: "C1",
                  triggerAt: "extended",
                  action: "none",
                  targetControl: "",
                },
                "B1",
              ),
              d = n(
                "cylinderReedSensor",
                920,
                395,
                {
                  linkedActuator: "C1",
                  triggerAt: "retracted",
                  action: "none",
                  targetControl: "",
                },
                "B2",
              );
            (a(e, "E2", l, "I1", "electrical", { color: "#d946ef" }),
              a(y, "E1", l, "I2", "electrical", { color: "#d946ef" }),
              a(l, "Q1", u, "E1", "electrical", { color: "#d946ef" }),
              a(l, "Q2", t, "IN", "electrical", { color: "#d946ef" }),
              a(t, "OUT", m, "E1", "electrical", { color: "#d946ef" }));
          } else if (4 === t) {
            ((l.props.program =
              "SEQUENCE: B1 -> V1 right; B2 -> V1 center"));
            const e = n(
                "sequenceValve",
                660,
                420,
                { settingBar: 80 },
                "SV1",
              ),
              g = n(
                "checkValve",
                660,
                545,
                { crackingBar: 0.5 },
                "CV1",
              ),
              t = n(
                "cylinderDA",
                920,
                520,
                { boreMm: 63, rodMm: 36, strokeMm: 400, loadKg: 450 },
                "C2",
              ),
              u = n(
                "cylinderReedSensor",
                920,
                400,
                {
                  linkedActuator: "C2",
                  triggerAt: "extended",
                  action: "none",
                  targetControl: "",
                },
                "B1",
              ),
              m = n(
                "cylinderReedSensor",
                920,
                350,
                {
                  linkedActuator: "C1",
                  triggerAt: "retracted",
                  action: "none",
                  targetControl: "",
                },
                "B2",
              );
            ((g.rotation = 180),
              a(o, "A", e, "P", "pressure", { shift: -60 }),
              a(e, "A", t, "A", "pressure", { shift: -60 }),
              a(t, "A", g, "A", "pressure", { shift: -80 }),
              a(g, "B", e, "P", "pressure", { shift: -80 }),
              a(e, "T", i.tank, "T", "drain", { shift: -95 }),
              a(o, "B", t, "B", "return", {
                routeMode: "horizontal-first",
                shift: 45,
              }),
              a(u, "E1", l, "I1", "electrical", { color: "#d946ef" }),
              a(m, "E1", l, "I2", "electrical", { color: "#d946ef" }));
          } else if (5 === t) {
            ((l.props.program =
              "MOTOR START/STOP: Q1 = PB-STOP AND PB-START OR PB-STOP AND Q1 AND FS1"),
              o.props.spoolState = "center",
              (r.connections = r.connections.filter(
                (e) => e.to.componentId !== s.id && e.from.componentId !== s.id,
              )),
              (r.components = r.components.filter((e) => e.id !== s.id)));
            const e = n(
                "hydraulicMotor",
                960,
                290,
                { displacementCcRev: 40, loadNm: 25 },
                "M1",
              ),
              t = n(
                "flowSwitch",
                700,
                270,
                { switchLpm: 15, action: "none", targetControl: "" },
                "FS1",
              ),
              u = n(
                "pushButton",
                260,
                650,
                { contact: "NO", pressed: !1 },
                "PB-START",
              ),
              m = n(
                "pushButton",
                260,
                760,
                { contact: "NC", pressed: !1 },
                "PB-STOP",
              ),
              y = n(
                "solenoid",
                790,
                705,
                { voltage: "24 VDC", energized: !1 },
                "Y1",
              );
            (a(o, "A", t, "A", "pressure", {
              routeMode: "horizontal-first",
              shift: -20,
            }),
              a(t, "B", e, "A", "pressure", {
                routeMode: "horizontal-first",
                shift: -20,
              }),
              a(e, "B", o, "B", "return", {
                routeMode: "horizontal-first",
                shift: 25,
              }),
              a(t, "E", l, "I1", "electrical", { color: "#d946ef" }),
              a(u, "E2", l, "I1", "electrical", { color: "#d946ef" }),
              a(m, "E2", l, "I2", "electrical", { color: "#d946ef" }),
              a(l, "Q1", y, "E1", "electrical", { color: "#d946ef" }));
          } else if (6 === t) {
            ((l.props.program =
              "ACCUMULATOR CLAMP: PS1 -> V1 center; B2 -> V1 left"));
            const e = n(
                "accumulator",
                650,
                220,
                { prechargeBar: 70, volumeL: 4 },
                "ACC1",
              ),
              t = n("pilotCheckValve", 690, 310, { pilotRatio: 3 }, "PCV1"),
              u = n(
                "pressureSwitch",
                650,
                520,
                {
                  switchBar: 110,
                  action: "none",
                  targetControl: "",
                },
                "PS1",
              ),
              m = n(
                "cylinderReedSensor",
                920,
                395,
                {
                  linkedActuator: "C1",
                  triggerAt: "retracted",
                  action: "none",
                  targetControl: "",
                },
                "B2",
              );
            (c("A"),
              a(o, "A", t, "A", "pressure", {
                routeMode: "horizontal-first",
                shift: -20,
              }),
              a(t, "B", s, "A", "pressure", {
                routeMode: "horizontal-first",
                shift: -20,
              }),
              a(o, "B", t, "X", "pilot", { shift: -55 }),
              a(i.pump, "P", e, "A", "pressure", { shift: -55 }),
              a(t, "B", u, "P", "pressure", {
                routeMode: "vertical-first",
                shift: 55,
                color: "#f59e0b",
              }),
              a(u, "E", l, "I1", "electrical", { color: "#d946ef" }),
              a(m, "E1", l, "I2", "electrical", { color: "#d946ef" }));
          } else if (7 === t) {
            ((l.props.program =
              "COUNTERBALANCE LIFT: LS1 -> V1 right; LS2 -> V1 center"),
              o.props.spoolState = "center",
              (s.props.loadKg = 800));
            const e = n(
                "counterbalanceValve",
                660,
                455,
                { settingBar: 120, pilotRatio: 3 },
                "CBV1",
              ),
              t = n(
                "limitSwitch",
                920,
                140,
                {
                  linkedActuator: "C1",
                  triggerAt: "extended",
                  action: "none",
                  targetControl: "",
                },
                "LS1",
              ),
              u = n(
                "limitSwitch",
                920,
                395,
                {
                  linkedActuator: "C1",
                  triggerAt: "retracted",
                  action: "none",
                  targetControl: "",
                },
                "LS2",
              );
            (c("B"),
              a(s, "B", e, "A", "return", { shift: 45 }),
              a(e, "B", o, "B", "return", { shift: 55 }),
              a(o, "A", e, "X", "pilot", { shift: -75 }),
              a(t, "E1", l, "I1", "electrical", { color: "#d946ef" }),
              a(u, "E1", l, "I2", "electrical", { color: "#d946ef" }));
          } else if (8 === t) {
            ((l.props.program =
              "METER-OUT JOG: Q1 = PB1 AND NOT PB2; Q2 = PB2 AND NOT PB1"));
            const e = n(
                "flowControl",
                700,
                430,
                { openingPercent: 40 },
                "FC1",
              ),
              t = n(
                "pushButton",
                260,
                650,
                { contact: "NO", pressed: !1 },
                "PB1",
              ),
              u = n(
                "pushButton",
                260,
                760,
                { contact: "NO", pressed: !1 },
                "PB2",
              ),
              m = n(
                "solenoid",
                790,
                650,
                { voltage: "24 VDC", energized: !1 },
                "Y1",
              ),
              y = n(
                "solenoid",
                790,
                760,
                { voltage: "24 VDC", energized: !1 },
                "Y2",
              );
            (c("B"),
              a(s, "B", e, "A", "return", {
                routeMode: "horizontal-first",
                shift: 30,
              }),
              a(e, "B", o, "B", "return", {
                routeMode: "horizontal-first",
                shift: 40,
              }),
              a(t, "E2", l, "I1", "electrical", { color: "#d946ef" }),
              a(u, "E2", l, "I2", "electrical", { color: "#d946ef" }),
              a(l, "Q1", m, "E1", "electrical", { color: "#d946ef" }),
              a(l, "Q2", y, "E1", "electrical", { color: "#d946ef" }));
          } else if (9 === t) {
            ((l.props.program =
              "REDUCED BRANCH: Q1 = PT1"));
            const e = n("reducingValve", 640, 215, { outletBar: 60 }, "PRV1"),
              t = n(
                "cylinderDA",
                920,
                520,
                { boreMm: 80, rodMm: 45, strokeMm: 400, loadKg: 600 },
                "Main",
              ),
              u = n(
                "pressureTransducer",
                700,
                420,
                { rangeBar: 160, signal: "4-20 mA" },
                "PT1",
              );
            (c("A"),
              a(o, "A", e, "P", "pressure", { shift: -55 }),
              a(e, "A", s, "A", "pressure", { shift: -55 }),
              a(e, "T", i.tank, "T", "drain", { shift: -65 }),
              a(o, "A", t, "A", "pressure", {
                routeMode: "horizontal-first",
                shift: -40,
              }),
              a(o, "B", t, "B", "return", {
                routeMode: "horizontal-first",
                shift: 45,
              }),
              a(e, "A", u, "P", "pressure", {
                routeMode: "vertical-first",
                shift: 60,
                color: "#f59e0b",
              }),
              a(u, "E", l, "I1", "electrical", { color: "#d946ef" }));
          } else if (10 === t) {
            ((l.props.program =
              "REGEN FAST APPROACH: B1 -> V1 left; B2 -> V1 right; B3 -> V1 center"),
              (o.props.center = "regenerative"),
              (o.props.spoolState = "center"));
            const e = n(
                "cylinderReedSensor",
                920,
                95,
                {
                  linkedActuator: "C1",
                  triggerAt: "custom",
                  triggerPosition: 0.6,
                  action: "none",
                  targetControl: "",
                },
                "B1",
              ),
              t = n(
                "cylinderReedSensor",
                920,
                140,
                {
                  linkedActuator: "C1",
                  triggerAt: "extended",
                  action: "none",
                  targetControl: "",
                },
                "B2",
              ),
              u = n(
                "cylinderReedSensor",
                920,
                395,
                {
                  linkedActuator: "C1",
                  triggerAt: "retracted",
                  action: "none",
                  targetControl: "",
                },
                "B3",
              );
            (a(e, "E1", l, "I1", "electrical", { color: "#d946ef" }),
              a(t, "E1", l, "I2", "electrical", { color: "#d946ef" }),
              a(u, "E1", l, "I2", "electrical", { color: "#d946ef" }));
          } else if (11 === t) {
            ((l.props.program =
              "FLOW-DIVIDER SYNC: B1 AND B2 -> V1 right"));
            const e = n("flowDivider", 650, 300, { splitPercentA: 50 }, "FD1"),
              t = n(
                "cylinderDA",
                920,
                520,
                { boreMm: 63, rodMm: 36, strokeMm: 450, loadKg: 300 },
                "C2",
              ),
              u = n(
                "cylinderReedSensor",
                920,
                95,
                {
                  linkedActuator: "C1",
                  triggerAt: "extended",
                  action: "none",
                  targetControl: "",
                },
                "B1",
              ),
              m = n(
                "cylinderReedSensor",
                920,
                355,
                {
                  linkedActuator: "C2",
                  triggerAt: "extended",
                  action: "none",
                  targetControl: "",
                },
                "B2",
              );
            (c("A"),
              a(o, "A", e, "P", "pressure", { shift: -30 }),
              a(e, "A", s, "A", "pressure", { shift: -30 }),
              a(e, "B", t, "A", "pressure", { shift: -30 }),
              a(o, "B", t, "B", "return", {
                routeMode: "horizontal-first",
                shift: 45,
              }),
              a(u, "E1", l, "I1", "electrical", { color: "#d946ef" }),
              a(m, "E1", l, "I2", "electrical", { color: "#d946ef" }));
          } else if (12 === t) {
            ((l.props.program =
              "LOAD-HOLD E-RELEASE: Q1 = NOT ES1"),
              o.props.spoolState = "center",
              (s.props.loadKg = 650));
            const e = n("pilotCheckValve", 690, 310, { pilotRatio: 3 }, "PCV1"),
              t = n(
                "cartridgeSolenoidValve22",
                640,
                480,
                { normallyOpen: !1, energized: !1 },
                "EN1",
              ),
              u = n("emergencyStop", 270, 705, { pressed: !1 }, "ES1");
            (c("A"),
              a(o, "A", e, "A", "pressure", {
                routeMode: "horizontal-first",
                shift: -20,
              }),
              a(e, "B", s, "A", "pressure", {
                routeMode: "horizontal-first",
                shift: -20,
              }),
              a(o, "B", e, "X", "pilot", { shift: -55 }),
              a(e, "B", t, "P", "pressure", {
                routeMode: "vertical-first",
                shift: 55,
              }),
              a(t, "A", i.tank, "T", "drain", { shift: 65 }),
              a(u, "E2", l, "I1", "electrical", { color: "#d946ef" }),
              a(l, "Q1", t, "E", "electrical", { color: "#d946ef" }));
          } else if (13 === t) {
            ((l.props.program =
              "COOLING: Q1 = TSH1"),
              (r.connections = r.connections.filter(
                (e) => !(e.from.componentId === o.id && "T" === e.from.portId),
              )));
            const e = n("filter", 600, 590, { ratingMicron: 10 }, "F1"),
              t = n("junction", 740, 590, {}, "J1"),
              u = n("cooler", 900, 590, { coolingKw: 6 }, "HX1"),
              m = n("junction", 1060, 590, {}, "J2"),
              y = n(
                "directionalValve",
                900,
                460,
                {
                  ports: "2",
                  positions: "2",
                  center: "closed",
                  spoolState: "left",
                  leftActuation: "spring",
                  rightActuation: "solenoid",
                },
                "V2",
              ),
              d = n(
                "temperatureSwitch",
                740,
                710,
                {
                  switchTempC: 60,
                  action: "none",
                  targetControl: "",
                },
                "TSH1",
              ),
              p = n(
                "solenoid",
                470,
                560,
                { voltage: "24 VDC", energized: !1, targetControl: "V2" },
                "Y1",
              );
            (a(o, "T", e, "A", "return", { shift: 20 }),
              a(e, "B", t, "A", "return"),
              a(t, "B", u, "A", "return", { shift: 30 }),
              a(u, "B", m, "A", "return", { shift: 30 }),
              a(m, "B", i.tank, "T", "return", { shift: 40 }),
              a(t, "C", y, "P", "return", { shift: -70 }),
              a(y, "A", m, "C", "return", { shift: -70 }),
              a(t, "D", d, "P", "return", { shift: 70 }),
              a(d, "E", l, "I1", "electrical", { color: "#d946ef" }),
              a(l, "Q1", p, "E1", "electrical", { color: "#d946ef" }));
          } else if (14 === t) {
            ((l.props.program =
              "PRESS CYCLE: Q1 = ES1 AND PB-START OR ES1 AND Q1 AND NOT PS1; Q2 = ES1 AND PS1 OR ES1 AND Q2 AND NOT PB-START"),
              o.props.spoolState = "center",
              (s.props.loadKg = 1200),
              (s.props.strokeMm = 400));
            const e = n(
                "pressureSwitch",
                650,
                520,
                {
                  switchBar: 140,
                  action: "none",
                  targetControl: "",
                },
                "PS1",
              ),
              t = n(
                "pushButton",
                260,
                650,
                { contact: "NO", pressed: !1 },
                "PB-START",
              ),
              u = n("emergencyStop", 260, 760, { pressed: !1 }, "ES1"),
              m = n(
                "solenoid",
                790,
                650,
                { voltage: "24 VDC", energized: !1 },
                "Y1",
              ),
              y = n(
                "solenoid",
                790,
                760,
                { voltage: "24 VDC", energized: !1 },
                "Y2",
              );
            (a(o, "A", e, "P", "pressure", {
              routeMode: "vertical-first",
              shift: 55,
              color: "#f59e0b",
            }),
              a(e, "E", l, "I1", "electrical", { color: "#d946ef" }),
              a(t, "E2", l, "I1", "electrical", { color: "#d946ef" }),
              a(u, "E2", l, "I2", "electrical", { color: "#d946ef" }),
              a(l, "Q1", m, "E1", "electrical", { color: "#d946ef" }),
              a(l, "Q2", y, "E1", "electrical", { color: "#d946ef" }));
          }
          return ((r.viewBox = { x: 40, y: 40, w: 1120, h: 760 }), r);
        })(e, t),
    })),
    ...[
      "Steel mill roll gap hydraulic positioning system",
      "Heavy-duty mine loader boom and bucket hydraulics",
      "Hydraulic press with prefill, clamp and return stages",
      "Mobile crane outrigger and boom control manifold",
      "Injection molding clamp hydraulic power circuit",
      "Wind turbine pitch hydraulic unit with accumulator backup",
      "Ship hatch cover synchronized cylinder system",
      "Tunnel boring machine gripper and thrust circuit",
      "Mining conveyor take-up hydraulic tensioning system",
      "Steel coil car lift and traverse hydraulic system",
      "Foundry ladle tilt safety hydraulic circuit",
      "Hydraulic test bench with load simulation and cooling",
      "Excavator attachment auxiliary hydraulic manifold",
      "Industrial baler compaction and ejector system",
      "Large gate actuator redundant hydraulic power unit",
    ].map((e, t) => ({
      level: "Advanced real-world class circuits",
      name: e,
      builder: () =>
        (function (e, t = 0) {
          const { project: r, add: n, connect: a } = gt(e);
          r.viewBox = { x: 0, y: 0, w: 1680, h: 1120 };
          const i = vt(n, 0, 620),
            o = n("junction", 360, 430, {}, "P-MAN"),
            s = n("junction", 360, 760, {}, "T-MAN"),
            l = n("filter", 260, 760, { ratingMicron: 10 }, "RF1"),
            c = n("cooler", 260, 870, { coolingKw: 8 + t }, "HX1"),
            d = n(
              "accumulator",
              360,
              250,
              { prechargeBar: 90, volumeL: 10 + t },
              "ACC1",
            );
          (a(i.pump, "P", o, "A", "pressure", { shift: -35 }),
            a(i.tank, "T", l, "A", "return", { shift: 40 }),
            a(l, "B", c, "A", "return", { shift: 30 }),
            a(c, "B", s, "A", "return", { shift: 30 }),
            a(o, "C", d, "A", "pressure", { shift: -70 }));
          const p = t % 4 == 0 ? 4 : t % 4 == 1 ? 3 : 2,
            u = [];
          for (let e = 0; e < p; e++) {
            const r = 250 + 190 * e,
              i = n(
                "directionalValve",
                660,
                r,
                {
                  valveType: e % 2 ? "4/3 tandem center" : "4/3 closed center",
                  ports: "4",
                  positions: "3",
                  center: e % 2 ? "tandem" : "closed",
                  spoolState: "center",
                  leftActuation: "solenoid",
                  rightActuation: "solenoid",
                },
                `V${e + 1}`,
              );
            if (
              (a(o, "B", i, "P", "pressure", { shift: -30 - 12 * e }),
              a(i, "T", s, "B", "return", { shift: 30 + 12 * e }),
              e === p - 1 && t % 3 == 1)
            ) {
              const t = n(
                "hydraulicMotor",
                1110,
                r - 15,
                { displacementCcRev: 45, loadNm: 80 },
                `M${e + 1}`,
              );
              (a(i, "A", t, "A", "pressure", {
                routeMode: "horizontal-first",
                shift: -25,
              }),
                a(t, "B", i, "B", "return", {
                  routeMode: "horizontal-first",
                  shift: 25,
                }),
                u.push(t));
            } else {
              const t = n(
                  "cylinderDA",
                  1120,
                  r - 15,
                  {
                    boreMm: 80 + 15 * e,
                    rodMm: 45,
                    strokeMm: 600 + 100 * e,
                    loadKg: 700 + 250 * e,
                  },
                  `C${e + 1}`,
                ),
                o =
                  e % 2 == 0
                    ? n(
                        "counterbalanceValve",
                        900,
                        r + 55,
                        { settingBar: 130, pilotRatio: 3 },
                        `CBV${e + 1}`,
                      )
                    : null;
              (o
                ? (a(i, "A", t, "A", "pressure", {
                    routeMode: "horizontal-first",
                    shift: -30,
                  }),
                  a(t, "B", o, "A", "return", {
                    routeMode: "horizontal-first",
                    shift: 25,
                  }),
                  a(o, "B", i, "B", "return", {
                    routeMode: "horizontal-first",
                    shift: 35,
                  }),
                  a(i, "A", o, "X", "pilot", { shift: -70 }))
                : (a(i, "A", t, "A", "pressure", {
                    routeMode: "horizontal-first",
                    shift: -25,
                  }),
                  a(t, "B", i, "B", "return", {
                    routeMode: "horizontal-first",
                    shift: 25,
                  })),
                n(
                  "linearPositionSensor",
                  1120,
                  r - 95,
                  {
                    linkedActuator: t.label,
                    triggerAt: "custom",
                    triggerPosition: 0.8,
                    action: "set valve center",
                    targetControl: i.label,
                  },
                  `LVDT${e + 1}`,
                ),
                u.push(t));
            }
          }
          n(
            "plc",
            660,
            970,
            {
              program:
                "Advanced interlocked sequence: sensors -> PLC -> solenoid valves.",
            },
            "PLC1",
          );
          return (
            a(
              o,
              "D",
              n(
                "pressureTransducer",
                500,
                230,
                { rangeBar: 315, signal: "4-20 mA" },
                "PT1",
              ),
              "P",
              "pressure",
              { shift: -85, color: "#ef4444", routeMode: "vertical-first" },
            ),
            n(
              "temperatureSwitch",
              500,
              875,
              { switchTempC: 60, action: "set valve center" },
              "TS1",
            ),
            n(
              "levelSwitch",
              170,
              705,
              { levelPercent: 20, mode: "low level" },
              "LSH1",
            ),
            (r.metadata.notes = `${e}: advanced real-world class hydraulic layout with power unit, conditioning, accumulator, manifold valves, feedback sensors and PLC control.`),
            r
          );
        })(e, t),
    })),
    ...[
      "Proportional speed control with setpoint and amplifier",
      "Proportional cylinder feed drive with ramp generator",
      "Proportional pressure control and force limiting",
      "Positioning axis with proportional valve and LVDT",
      "Energy-saving proportional unloading circuit",
      "Proportional flow control with pressure compensator",
      "Servo valve diagnostic circuit with test points",
      "Electrohydraulic sequence with timer and relay latch",
    ].map((e, t) => ({
      level: "Proportional and electro-hydraulic training circuits",
      name: e,
      builder: () =>
        (function (e, t = 0) {
          const { project: r, add: n, connect: a } = gt(e),
            i = vt(n, 0, 520),
            o = n(
              "servoValve",
              600,
              360,
              { commandPercent: 2 === t ? 20 : 45, ratedFlowLpm: 40 },
              "PV1",
            ),
            s = n(
              "proportionalAmplifier",
              420,
              650,
              {
                gain: 1,
                ditherHz: 120,
                rampUpS: 1 === t ? 1.2 : 0.4,
                rampDownS: 0.6,
                outputPercent: 45,
              },
              "AMP1",
            ),
            l = n(
              "setpointPotentiometer",
              220,
              650,
              { setpointPercent: 45 },
              "SP1",
            ),
            c = n(
              "cylinderDA",
              940,
              300,
              { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 300 },
              "Axis",
            ),
            d = n("pressureGauge", 340, 260, { rangeBar: 250 }, "PG1");
          if (
            (a(i.pump, "P", o, "P", "pressure", { shift: -30 }),
            a(o, "T", i.tank, "T", "return", { shift: 30 }),
            a(o, "A", c, "A", "pressure", { shift: -20 }),
            a(o, "B", c, "B", "return", { shift: 25 }),
            a(i.pump, "P", d, "P", "pressure", { shift: -70 }),
            a(l, "OUT", s, "E1", "electrical", { color: "#d946ef" }),
            a(s, "Y", o, "E", "electrical", { color: "#d946ef" }),
            1 === t)
          ) {
            const e = n(
              "rampGenerator",
              320,
              560,
              { rampUpS: 1.2, rampDownS: 0.8 },
              "RAMP1",
            );
            ((r.connections = r.connections.filter(
              (e) =>
                !(e.from.componentId === l.id && e.to.componentId === s.id),
            )),
              a(l, "OUT", e, "IN", "electrical", { color: "#d946ef" }),
              a(e, "OUT", s, "E1", "electrical", { color: "#d946ef" }));
          }
          if (2 === t) {
            const e = n(
                "pressureSwitch",
                760,
                520,
                {
                  switchBar: 80,
                  action: "set valve center",
                  targetControl: "PV1",
                },
                "PS1",
              ),
              t = n("reducingValve", 760, 420, { outletBar: 60 }, "PRV1");
            (a(o, "A", t, "P", "pressure", { shift: -50 }),
              a(t, "A", c, "A", "pressure", { shift: -50 }),
              a(t, "T", i.tank, "T", "drain", { shift: -65 }),
              a(o, "A", e, "P", "pilot", { color: "#f59e0b", shift: 60 }));
          }
          if (3 === t) {
            const e = n(
                "linearPositionSensor",
                940,
                170,
                {
                  linkedActuator: "Axis",
                  triggerAt: "custom",
                  triggerPosition: 0.75,
                  action: "set valve center",
                  targetControl: "PV1",
                  signal: "0-10 V",
                },
                "LVDT1",
              ),
              t = n(
                "plc",
                620,
                650,
                {
                  program:
                    "Position compare: setpoint - actual -> amplifier command",
                },
                "CTRL",
              );
            (a(e, "E1", t, "I1", "electrical", { color: "#d946ef" }),
              a(t, "Q1", s, "E2", "electrical", { color: "#d946ef" }));
          }
          if (4 === t) {
            const e = n("reliefValve", 420, 440, { settingBar: 90 }, "UNLOAD");
            (a(i.pump, "P", e, "P", "pressure", { shift: 70 }),
              a(e, "T", i.tank, "T", "return", { shift: 80 }));
          }
          if (5 === t) {
            const e = n(
                "pressureCompensator",
                760,
                420,
                { deltaPBar: 8 },
                "PC1",
              ),
              t = n(
                "flowControl",
                760,
                250,
                { openingPercent: 55, pressureCompensated: !0 },
                "FC1",
              );
            (a(o, "A", t, "A", "pressure", { shift: -65 }),
              a(t, "B", e, "P", "pressure", { shift: -65 }),
              a(e, "A", c, "A", "pressure", { shift: -65 }));
          }
          if (6 === t) {
            const e = n("testPoint", 480, 250, {}, "TP-P"),
              t = n("testPoint", 760, 250, {}, "TP-A");
            (a(o, "P", e, "P", "pressure", { shift: -80 }),
              a(o, "A", t, "P", "pressure", { shift: -90 }));
          }
          if (7 === t) {
            const e = n("pushButton", 180, 560, { pressed: !1 }, "START"),
              t = n("electricalRelay", 320, 560, { energized: !1 }, "K1"),
              r = n("timerRelay", 480, 560, { delayS: 1.5 }, "T1");
            (a(e, "E2", t, "A1", "electrical", { color: "#d946ef" }),
              a(t, "A2", r, "IN", "electrical", { color: "#d946ef" }),
              a(r, "OUT", s, "E2", "electrical", { color: "#d946ef" }));
          }
          return ((r.viewBox = { x: 40, y: 110, w: 1160, h: 760 }), r);
        })(e, t),
    })),
    ...[
      "Cartridge manifold with relief, check and test points",
      "Cartridge load-holding cylinder manifold",
      "Cartridge sequence clamp-and-work circuit",
      "Slip-in logic bridge press — poppet cartridges piloted by a small 4/3 DCV",
      "Cartridge needle valve motor speed control",
      "Cartridge unloading circuit with accumulator",
      "2/2 solenoid cartridge actuator enable circuit",
      "Cartridge shuttle valve pilot selection circuit",
    ].map((e, t) => ({
      level: "Cartridge valve manifold circuits",
      name: e,
      builder: () =>
        (function (e, t = 0) {
          const { project: r, add: n, connect: a } = gt(e),
            i = vt(n, 0, 520),
            o = n("cartridgeManifoldBlock", 540, 430, { note: e }, "HIC1"),
            s = n(
              "directionalValve",
              760,
              420,
              {
                ports: "4",
                positions: "3",
                center: "closed",
                spoolState: "left",
                leftActuation: 7 === t ? "hydraulic pilot" : "solenoid",
                rightActuation: 7 === t ? "spring" : "solenoid",
              },
              "V1",
            ),
            l = n(
              "cylinderDA",
              1040,
              315,
              { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 350 },
              "C1",
            ),
            c = n("pressureGauge", 380, 275, { rangeBar: 250 }, "PG1");
          if (
            (a(i.pump, "P", o, "P", "pressure", { shift: -35 }),
            a(o, "A", s, "P", "pressure", { shift: -20 }),
            a(s, "T", o, "T", "return", { shift: 25 }),
            a(o, "T", i.tank, "T", "return", { shift: 40 }),
            a(s, "A", l, "A", "pressure", { shift: -20 }),
            a(s, "B", l, "B", "return", { shift: 25 }),
            a(o, "P", c, "P", "pressure", { shift: -70 }),
            0 === t)
          ) {
            const e = n(
                "cartridgeReliefValve",
                540,
                250,
                { settingBar: 160 },
                "CRV1",
              ),
              t = n(
                "cartridgeCheckValve",
                540,
                610,
                { crackingBar: 1 },
                "CCV1",
              ),
              r = n("testPoint", 700, 250, {}, "TP1");
            (a(o, "P", e, "P", "pressure", { shift: -70 }),
              a(e, "T", o, "T", "return", { shift: -75 }),
              a(i.tank, "T", t, "A", "return", { shift: 70 }),
              a(t, "B", o, "T", "return", { shift: 70 }),
              a(o, "P", r, "P", "pressure", { shift: -90 }));
          }
          if (1 === t) {
            const e = n(
              "cartridgeCounterbalanceValve",
              880,
              480,
              { settingBar: 140, pilotRatio: 3 },
              "CLH1",
            );
            ((r.connections = r.connections.filter(
              (e) => !(e.from.componentId === s.id && "B" === e.from.portId),
            )),
              a(l, "B", e, "A", "return", { shift: 45 }),
              a(e, "B", s, "B", "return", { shift: 55 }),
              a(s, "A", e, "X", "pilot", { shift: -75 }));
          }
          if (2 === t) {
            const e = n(
                "cartridgeSequenceValve",
                780,
                250,
                { sequenceBar: 60 },
                "CSV1",
              ),
              t = n(
                "cylinderDA",
                1040,
                520,
                { boreMm: 50, rodMm: 28, strokeMm: 350, loadKg: 180 },
                "C2",
              ),
              r2 = n(
                "cartridgeCheckValve",
                780,
                130,
                { crackingBar: 1 },
                "CCV1",
              );
            ((r2.rotation = 180),
              a(s, "A", e, "P", "pressure", { shift: -60 }),
              a(e, "A", t, "A", "pressure", { shift: -60 }),
              a(t, "A", r2, "A", "pressure", { shift: -80 }),
              a(r2, "B", e, "P", "pressure", { shift: -80 }),
              a(e, "T", o, "T", "drain", { shift: -95 }),
              a(t, "B", s, "B", "return", { shift: 60 }));
          }
          if (3 === t) {
            // Slip-in logic elements in a four-way bridge (DIN 24342 / ISO 7368
            // style): four 2-way poppet cartridges carry the full flow, while the
            // small 4/3 DCV only pilots the control covers (X). X pressurised =
            // poppet clamped shut; X vented = element opens (spring side).
            //   LEFT  : X(LCV2,LCV3) pressurised -> closed; LCV1,LCV4 open -> P->A, B->T (press stroke)
            //   RIGHT : X(LCV1,LCV4) pressurised -> closed; LCV2,LCV3 open -> P->B, A->T (retract)
            //   CENTRE: float centre vents every cover -> all poppets open: pump
            //           unloads P->T through the bridge and the cylinder floats.
            ((s.label = "PV1"),
              (s.props.center = "float"),
              (s.props.note =
                "Pilot DCV: shifts the logic control covers only (small flow)"),
              (i.hpu.props.flowLpm = 40),
              (i.hpu.props.reliefSettingBar = 210),
              (i.hpu.props.tankCapacityL = 160),
              (l.props.boreMm = 80),
              (l.props.rodMm = 45),
              (l.props.strokeMm = 450),
              (l.props.loadKg = 2500),
              (r.connections = r.connections.filter(
                (e) =>
                  !(
                    e.from.componentId === s.id &&
                    e.to.componentId === l.id &&
                    ("A" === e.from.portId || "B" === e.from.portId)
                  ),
              )));
            const e = n("logicCartridgeValve", 720, 245, { pilotRatio: 2 }, "LCV1"),
              u = n("logicCartridgeValve", 720, 590, { pilotRatio: 2 }, "LCV2"),
              m = n("logicCartridgeValve", 915, 245, { pilotRatio: 2 }, "LCV3"),
              y = n("logicCartridgeValve", 915, 590, { pilotRatio: 2 }, "LCV4");
            (a(o, "A", e, "A", "pressure", { shift: -55 }),
              a(o, "A", u, "A", "pressure", { shift: -70 }),
              a(e, "B", l, "A", "pressure", { shift: -55 }),
              a(l, "A", m, "A", "return", { shift: -25 }),
              a(u, "B", l, "B", "pressure", { shift: 55 }),
              a(l, "B", y, "A", "return", { shift: 30 }),
              a(m, "B", o, "B", "return", { shift: 80 }),
              a(y, "B", o, "B", "return", { shift: 95 }),
              a(s, "A", u, "X", "pilot", { color: "#f59e0b", shift: -40 }),
              a(s, "A", m, "X", "pilot", { color: "#f59e0b", shift: -55 }),
              a(s, "B", e, "X", "pilot", { color: "#f59e0b", shift: -25 }),
              a(s, "B", y, "X", "pilot", { color: "#f59e0b", shift: 40 }));
          }
          if (4 === t) {
            const e = n(
                "cartridgeNeedleFlowValve",
                880,
                250,
                { openingPercent: 45, reverseCheck: !0 },
                "CNV1",
              ),
              t = n(
                "hydraulicMotor",
                1080,
                300,
                { displacementCcRev: 32, loadNm: 25 },
                "M1",
              );
            ((r.connections = r.connections.filter(
              (e) => e.to.componentId !== l.id && e.from.componentId !== l.id,
            )),
              (r.components = r.components.filter((e) => e.id !== l.id)),
              a(s, "A", e, "A", "pressure", { shift: -45 }),
              a(e, "B", t, "A", "pressure", { shift: -45 }),
              a(t, "B", s, "B", "return", { shift: 45 }));
          }
          if (5 === t) {
            const e = n(
                "accumulator",
                760,
                250,
                { prechargeBar: 70, volumeL: 5 },
                "ACC1",
              ),
              t = n(
                "cartridgeUnloadingValve",
                540,
                250,
                { unloadBar: 130 },
                "CUV1",
              );
            (a(o, "P", e, "A", "pressure", { shift: -80 }),
              a(o, "P", t, "P", "pressure", { shift: -100 }),
              a(t, "T", o, "T", "return", { shift: -100 }),
              a(o, "P", t, "X", "pilot", { color: "#f59e0b", shift: -115 }));
          }
          if (6 === t) {
            const e = n(
              "cartridgeSolenoidValve22",
              700,
              250,
              { normallyOpen: !1, energized: !0 },
              "EN1",
            );
            ((r.connections = r.connections.filter(
              (e) =>
                !(e.from.componentId === o.id && e.to.componentId === s.id),
            )),
              a(o, "A", e, "P", "pressure", { shift: -45 }),
              a(e, "A", s, "P", "pressure", { shift: -45 }));
          }
          if (7 === t) {
            const e = n("cartridgeShuttleValve", 720, 250, {}, "OR1"),
              t = n("pressureSwitch", 600, 180, { switchBar: 60 }, "PS1"),
              r = n("pressureSwitch", 840, 180, { switchBar: 80 }, "PS2");
            (a(o, "P", e, "A", "pilot", { color: "#f59e0b", shift: -30 }),
              a(s, "A", e, "B", "pilot", { color: "#f59e0b", shift: 30 }),
              a(o, "P", t, "P", "pilot", { color: "#f59e0b", shift: -50 }),
              a(s, "A", r, "P", "pilot", { color: "#f59e0b", shift: 50 }),
              a(e, "X", s, "X", "pilot", { color: "#f59e0b", shift: -85 }));
          }
          return ((r.viewBox = { x: 60, y: 120, w: 1180, h: 760 }), r);
        })(e, t),
    })),    {
      level: "Intermediate electrohydraulic circuits",
      name: "Variable load press — load rises with piston position",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = gt("Variable load press — load rises with piston position"),
          n = vt(t),
          a = t(
            "directionalValve",
            620,
            420,
            {
              ports: "4",
              positions: "3",
              center: "closed",
              spoolState: "left",
              leftActuation: "manual",
              rightActuation: "spring",
            },
            "V1",
          ),
          i = t(
            "cylinderDA",
            880,
            330,
            {
              boreMm: 63,
              rodMm: 36,
              strokeMm: 500,
              loadKg: 200,
              loadMode: "position-based",
              loadProfile: "0, 200\n0.5, 800\n1, 3000",
              simPosition: 0.2,
            },
            "C1",
          ),
          o = t("pressureGauge", 780, 210, {}, "G1"),
          c = t(
            "textLabel",
            890,
            640,
            {
              text:
                "VARIABLE LOAD — open C1 Properties:\n" +
                "1. Set 'Load over cycle' = position-based (or time-based).\n" +
                "2. 'Load profile points' = one pair per line: position 0..1 (or seconds), load in kg. Here: 0,200 → 0.5,800 → 1,3000, interpolated linearly.\n" +
                "3. Simulate and watch G1 climb as the press meets the workpiece. Plot it with the 📈 Charts button.\n" +
                "TIP: 'formula (t & x)' mode accepts real math, e.g. 800 + 1200*sin(2*pi*t) + 2500*x^2 — see the companion Formula example.",
              fontSize: 15,
            },
            "TXT1",
          );
        return (
          r(n.pump, "P", a, "P", "pressure"),
          r(a, "T", n.tank, "T", "return"),
          r(a, "A", i, "A", "pressure"),
          r(a, "B", i, "B", "pressure"),
          r(a, "A", o, "P", "pressure"),
          e
        );
      },
    },
    {
      level: "Advanced real-world class circuits",
      name: "Variable load formula — sine dance press (math in t & x)",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = gt("Variable load formula — sine dance press (math in t & x)"),
          n = vt(t),
          a = t(
            "directionalValve",
            620,
            420,
            {
              ports: "4",
              positions: "3",
              center: "closed",
              spoolState: "left",
              leftActuation: "manual",
              rightActuation: "spring",
            },
            "V1",
          ),
          i = t(
            "cylinderDA",
            880,
            330,
            {
              boreMm: 63,
              rodMm: 36,
              strokeMm: 500,
              loadKg: 500,
              loadMode: "formula (t & x)",
              loadProfile: "1200 + 900*sin(2*pi*0.5*t) + 2200*x^2",
              simPosition: 0.2,
            },
            "C1",
          ),
          o = t("pressureGauge", 780, 210, {}, "G1"),
          c = t(
            "textLabel",
            890,
            660,
            {
              text:
                "FORMULA LOAD — open C1 Properties, 'Load over cycle' = formula (t & x).\n" +
                "The load profile is any math expression in t (time, s) and x (stroke 0..1), used TOGETHER:\n" +
                "  1200 + 900*sin(2*pi*0.5*t) + 2200*x^2   — oscillates every 2 s and grows toward the end of stroke.\n" +
                "Functions: sin cos tan asin acos atan sqrt cbrt exp ln log abs min max pow floor ceil round sign\n" +
                "  clamp(v,a,b) step(edge,v) pulse(v,a,b) ramp(v,a,b) hypot mod via % — comparisons x<0.5, if(t<1,200,900).\n" +
                "Constants: pi e tau. Point tables 'x, load' per line still work. Results below 0 kg are clamped.\n" +
                "Motors: x = revolution fraction 0..1, load in N·m. Watch it live in 📈 Charts (C1 · applied load).",
              fontSize: 15,
            },
            "TXT1",
          );
        return (
          r(n.pump, "P", a, "P", "pressure"),
          r(a, "T", n.tank, "T", "return"),
          r(a, "A", i, "A", "pressure"),
          r(a, "B", i, "B", "pressure"),
          r(a, "A", o, "P", "pressure"),
          e
        );
      },
    },

  ];
  function ht(t) {
    const r = yt[t] || yt[0],
      n = e.exampleOverrides && e.exampleOverrides[String(t)];
    if (n && Array.isArray(n.components) && Array.isArray(n.connections))
      return k(n);
    const a = r.builder();
    return (
      t < 15 &&
        (function (e, t = 0) {
          const r = e.components || [],
            n = (e, t, r) => {
              e && ((e.x = t), (e.y = r));
            },
            a = (e) => r.filter((t) => t.type === e),
            i = r.filter(
              (e) =>
                "directionalValve" === e.type ||
                String(e.type).startsWith("directionalValve"),
            ),
            o = a("powerPack")[0];
          (n(o, 150, 500), i.forEach((e, t) => n(e, 450, 390 + 115 * t)));
          const s = r.filter(
            (e) => "cylinderDA" === e.type || "cylinderSA" === e.type,
          );
          (s.forEach((e, t) => n(e, 870, 1 === s.length ? 270 : 220 + 230 * t)),
            a("hydraulicMotor").forEach((e, t) => n(e, 870, 270 + 170 * t)),
            a("flowControl").forEach((e, r) =>
              n(e, 650, 6 === t ? 455 : 270 + 105 * r),
            ),
            a("checkValve").forEach((e, t) => n(e, 660, 285 + 100 * t)),
            a("pilotCheckValve").forEach((e, t) => n(e, 650, 270 + 120 * t)),
            a("counterbalanceValve").forEach((e, t) =>
              n(e, 660, 455 + 110 * t),
            ),
            a("sequenceValve").forEach((e, t) => n(e, 640, 390 + 110 * t)),
            a("reducingValve").forEach((e, t) => n(e, 640, 270 + 110 * t)),
            a("flowDivider").forEach((e, t) => n(e, 650, 300 + 130 * t)),
            a("junction").forEach((e, t) => n(e, 650, 285 + 100 * t)),
            a("accumulator").forEach((e, t) => n(e, 650, 255 + 135 * t)),
            a("pressureSwitch").forEach((e, t) => n(e, 650, 430 + 105 * t)),
            a("pressureGauge").forEach((e, t) => n(e, 320, 310 + 110 * t)),
            a("filter").forEach((e, t) => n(e, 305, 565 + 80 * t)),
            a("cooler").forEach((e, t) => n(e, 305, 640 + 80 * t)),
            r
              .filter((e) =>
                [
                  "limitSwitch",
                  "cylinderReedSensor",
                  "linearPositionSensor",
                  "proximitySensor",
                ].includes(e.type),
              )
              .forEach((e, t) => {
                const r =
                  s.find(
                    (t) =>
                      e.props.linkedActuator &&
                      (t.id === e.props.linkedActuator ||
                        t.label === e.props.linkedActuator),
                  ) || s[0];
                n(
                  e,
                  r ? r.x : 870,
                  r ? r.y + (t % 2 ? 120 : -120) : 140 + 90 * t,
                );
              }),
            r
              .filter((e) =>
                [
                  "pressureTransducer",
                  "flowSwitch",
                  "temperatureSwitch",
                  "levelSwitch",
                ].includes(e.type),
              )
              .forEach((e, t) => n(e, 1030, 160 + 95 * t)),
            r.forEach((e) => {
              ((e.x = S(e.x, 10)), (e.y = S(e.y, 10)));
            }));
        })(a, t),
      (a.metadata.projectName = r.name),
      (a.metadata.notes = `Predesigned RGZ Hydraulic Studio example: ${r.name}.`),
      (function (e, t) {
        const r = `${t.level || "Circuit"}\n${t.name}`;
        e.components.some((e) => "TXT-TITLE" === e.id) ||
          e.components.push({
            id: "TXT-TITLE",
            type: "textLabel",
            label: "Title",
            x: 90,
            y: 90,
            rotation: 0,
            props: {
              text: r,
              color: "#e8793c",
              fontSize: 24,
              fontFamily: "Tahoma, Arial, sans-serif",
              fontWeight: "800",
              direction: "auto",
              align: "start",
            },
          });
      })(a, r),
      a
    );
  }
  function gt(e) {
    const n = {
      fileType: "rgz-hydraulic-project",
      formatVersion: 1,
      appVersion: t,
      createdBy: "RGZ Hydraulic Studio",
      website: r,
      metadata: {
        projectName: e,
        designer: "",
        standard: "ISO-style / RGZ educational template",
        revision: "A",
        notes: "",
      },
      viewBox: { x: 40, y: 60, w: 1160, h: 720 },
      components: [],
      connections: [],
    };
    let a = 1;
    return {
      project: n,
      add: (e, t, r, i = {}, o = null) => {
        const s = $(e),
          l = {
            id: `${s.prefix}-${a++}`,
            type: e,
            label: o || `${s.prefix}${a - 1}`,
            x: t,
            y: r,
            rotation: 0,
            props: Object.assign(k(s.defaults || {}), i),
          };
        return (n.components.push(l), l);
      },
      connect: (e, t, r, a, i = "pressure", o = {}) => {
        n.connections.push({
          id: `L-${n.connections.length + 1}`,
          from: { componentId: e.id, portId: t },
          to: { componentId: r.id, portId: a },
          lineType: i,
          properties: Object.assign(
            {
              tubeIdMm: 12,
              lengthM: 1,
              maxPressureBar: 250,
              color: "",
              strokeWidth: 3,
              routeMode: "auto",
              shift: 0,
            },
            o,
          ),
        });
      },
    };
  }
  function vt(e, t, r = 500) {
    const n = e(
      "powerPack",
      180,
      r,
      {
        flowLpm: 25,
        reliefSettingBar: 160,
        tankCapacityL: 80,
        pressureGauge: !0,
      },
      "HPU1",
    );
    return { tank: n, pump: n, relief: n, gauge: n, hpu: n };
  }
  function ie(e, t) {
    const r = z(P(t.props.simPosition, 0.25), 0, 1),
      n = 40 * r - 44,
      a = 38 + 58 * r;
    (e.append(
      A("rect", {
        class: "symbol-fill",
        x: -78,
        y: -22,
        width: 112,
        height: 44,
        rx: 0,
      }),
    ),
      e.append(
        A("path", { class: "symbol-stroke", d: `M${n} -22 v44 M${n} 0 H${a}` }),
      ),
      e.append(A("path", { class: "symbol-muted", d: `M${a} -14 v28` })),
      e.append(
        A("path", { class: "symbol-stroke", d: "M-82 34v-12M22 34v-12" }),
      ));
  }
  function oe(e, t) {
    const r = z(P(t.props.simPosition, 0.15), 0, 1),
      n = 44 * r - 22,
      a = 24 + 66 * r;
    (e.append(
      A("rect", {
        class: "symbol-fill",
        x: -72,
        y: -22,
        width: 100,
        height: 44,
        rx: 0,
      }),
    ),
      e.append(
        A("path", { class: "symbol-stroke", d: `M${n} -22 v44 M${n} 0 H${a}` }),
      ),
      e.append(
        A("path", {
          class: "symbol-muted",
          d: "M-54 -13 l28 26M-26 -13l-28 26M-40 -13l28 26",
        }),
      ),
      e.append(A("path", { class: "symbol-muted", d: `M${a} -14 v28` })),
      e.append(A("path", { class: "symbol-stroke", d: "M-76 34v-12" })));
  }
  ((Array.isArray(e.customExamples) ? e.customExamples : []).forEach((e) => {
    e &&
      e.project &&
      Array.isArray(e.project.components) &&
      Array.isArray(e.project.connections) &&
      (yt.some((t) => t.customId && t.customId === e.id) ||
        yt.push({
          level: e.level || "Owner custom circuits",
          name: e.name || "Custom circuit",
          customId: e.id || `custom-${yt.length}`,
          builder: () => k(e.project),
        }));
  }),
    (function () {
      let e = document.querySelector('meta[name="viewport"]');
      if (
        (e ||
          ((e = document.createElement("meta")),
          e.setAttribute("name", "viewport"),
          document.head.appendChild(e)),
        e.setAttribute(
          "content",
          "width=device-width, initial-scale=1, viewport-fit=cover, maximum-scale=1",
        ),
        ["apple-mobile-web-app-capable", "mobile-web-app-capable"].forEach(
          (e) => {
            if (!document.querySelector(`meta[name="${e}"]`)) {
              const t = document.createElement("meta");
              (t.setAttribute("name", e),
                t.setAttribute("content", "yes"),
                document.head.appendChild(t));
            }
          },
        ),
        nt(),
        document.getElementById("rgz-runtime-critical-style"))
      )
        return;
      const t = document.createElement("style");
      ((t.id = "rgz-runtime-critical-style"),
        (t.textContent =
          "\n      html.rgz-hydraulic-page, body.rgz-hydraulic-page { margin:0!important; padding:0!important; overflow:hidden!important; background:#070b16!important; }\n      .rgz-hydraulic-studio-root { position:fixed!important; inset:0!important; width:100vw!important; height:100dvh!important; z-index:999999!important; overflow:hidden!important; margin:0!important; }\n      .rgz-modal-backdrop { position:fixed!important; inset:0!important; z-index:1000005!important; display:grid!important; place-items:center!important; background:rgba(2,6,23,.72)!important; padding:20px!important; }\n      .rgz-mobile-landscape-bar { display:none; }\n      .rgz-orientation-blocker { display:none; }\n      @media (max-width: 920px) and (orientation: portrait) {\n        .rgz-orientation-blocker { position:fixed!important; inset:0!important; z-index:1000010!important; display:grid!important; place-items:center!important; background:#070b16!important; color:#fff!important; text-align:center!important; padding:24px!important; }\n      }\n    "),
        document.head.appendChild(t));
    })(),
    document.documentElement.classList.add("rgz-hydraulic-page"),
    document.body.classList.add("rgz-hydraulic-page"),
    (n.innerHTML = `\n      <div class="rgz-app" aria-label="RGZ Hydraulic Studio hydraulic schematic application">\n        <div class="rgz-orientation-blocker">\n          <div class="rgz-orientation-card">\n            <div class="rgz-phone-rotate"><span></span></div>\n            <h2>Turn your phone</h2>\n            <p>Please rotate your phone to landscape mode to use RGZ Hydraulic Studio.</p>\n          </div>\n        </div>\n        <header class="rgz-topbar">\n          <div class="rgz-brand">\n            <div class="rgz-mark">RGZ</div>\n            <div>\n              <h1>RGZ Hydraulic Studio</h1>\n              <p>Online ISO-style hydraulic schematic design, checking, simulation and pipe sizing</p>\n            </div>\n          </div>\n          <div class="rgz-mobile-landscape-bar">\n            <button class="rgz-btn" data-action="toggle-library">Symbols</button>\n            <button class="rgz-btn" data-action="toggle-actions">Actions</button>\n            <button class="rgz-btn" data-action="toggle-inspector">Properties</button>\n            <button class="rgz-btn rgz-mobile-zoom" data-action="zoom-in">+</button>\n            <button class="rgz-btn rgz-mobile-zoom" data-action="zoom-out">−</button>\n          </div>\n          <div class="rgz-actions">\n            <button class="rgz-btn" data-action="fullscreen">Fullscreen</button>\n            <button class="rgz-btn" data-action="new">New</button>\n            <button class="rgz-btn" data-action="insert-power-pack">Power pack</button>\n            <button class="rgz-btn" data-action="insert-text">Text</button>\n            <button class="rgz-btn" data-action="fit">Fit</button>\n            <button class="rgz-btn" data-action="rotate-selected">Rotate 90°</button>\n            <button class="rgz-btn blue" data-action="check">Check circuit</button>\n            <button class="rgz-btn green" data-action="simulate">Simulate</button>\n            <button class="rgz-btn danger" data-action="stop" disabled>Stop</button>\n            <button class="rgz-btn" data-action="open-charts" title="Record simulation data and design custom charts (X/Y of any channel)">📈 Charts</button>\n            <div class="rgz-file-menu" id="rgz-file-menu">\n              <button class="rgz-btn primary" data-action="toggle-file-menu">File ▾</button>\n              <div class="rgz-file-menu-list">\n                <button class="rgz-btn" data-action="export-rgz">Save / Export</button>\n                <button class="rgz-btn" data-action="import-rgz">Import</button>\n                <button class="rgz-btn" data-action="account">Account</button>\n                <button class="rgz-btn" data-action="print">Print / PDF</button>\n                <button class="rgz-btn" data-action="set-print-area">Set print area</button>\n                <button class="rgz-btn" data-action="clear-print-area">Clear print area</button>\n                ${e.canManageExamples ? '<hr><button class="rgz-btn blue" data-action="add-example-template">Add current as new example</button><button class="rgz-btn" data-action="save-example-template">Update opened example</button><button class="rgz-btn" data-action="reset-example-template">Reset opened example</button>' : ""}\n              </div>\n            </div>\n            <input type="file" id="rgz-import-input" accept=".rgz,application/octet-stream" hidden />\n          </div>\n        </header>\n        <main class="rgz-main">\n          <aside class="rgz-sidebar">\n            <div class="rgz-section-title"><h2>00 — Start Fast</h2><span class="rgz-badge">${yt.length} examples</span></div>\n            <div class="rgz-panel rgz-examples-panel">\n              <div class="rgz-panel-title">Pre-designed ready circuits</div>\n              <button class="rgz-btn primary" style="width:100%;margin-top:10px" data-action="browse-examples">Browse circuit library</button>\n              <p>Open a clean popup to explore Simple, Intermediate and Advanced examples without sidebar text overflow.</p>\n            </div>\n            <div class="rgz-section-title"><h2>01 — Symbol Library</h2><span class="rgz-badge">${i.length} components</span></div>\n            <div class="rgz-search"><input class="rgz-input" id="rgz-search" placeholder="Search pumps, valves, cylinders…" /></div>\n            <div id="rgz-library"></div>\n          </aside>\n          <section class="rgz-workspace">\n            <div class="rgz-canvas-toolbar">\n              <div class="rgz-tool-pill"><span class="rgz-status-dot" id="rgz-status-dot"></span><span id="rgz-sim-status">Idle</span></div>\n              <div class="rgz-tool-pill"><span id="rgz-coords">x: 0 · y: 0</span></div>\n              <div class="rgz-tool-pill">Click one port, then another port to connect.</div>\n            </div>\n            <div class="rgz-canvas-wrap">\n              <svg id="rgz-canvas" role="img" aria-label="Hydraulic schematic canvas"></svg>\n            </div>\n            <div class="rgz-mobile-sim-controls">\n              <button class="rgz-btn green" data-action="simulate">Run</button>\n              <button class="rgz-btn danger" data-action="stop">Stop</button>\n              <button class="rgz-btn" data-action="toggle-live-controls">Controls</button>\n            </div>\n            <div id="rgz-mobile-live-controls" class="rgz-mobile-live-controls"></div>\n            <div id="rgz-print-block" class="rgz-print-title-block"></div>\n            <div class="rgz-bottom-panel">\n              <div class="rgz-bottom-header">\n                <div class="rgz-panel-title">Validation / Simulation messages</div>\n                <div style="display:flex;gap:6px"><button class="rgz-btn" data-action="toggle-messages">Show/Hide</button><button class="rgz-btn" data-action="clear-messages">Clear</button></div>\n              </div>\n              <div id="rgz-messages" class="rgz-message-list"></div>\n            </div>\n          </section>\n          <aside class="rgz-inspector" id="rgz-inspector"></aside>\n        </main>\n        <div class="rgz-toast-wrap" id="rgz-toasts"></div>\n      </div>\n    `),
    (u = document.getElementById("rgz-canvas")),
    (g = document.getElementById("rgz-inspector")),
    (v = document.getElementById("rgz-library")),
    (f = document.getElementById("rgz-messages")),
    (b = document.getElementById("rgz-status-dot")),
    (x = document.getElementById("rgz-coords")),
    (w = document.getElementById("rgz-print-block")),
    (u.innerHTML =
      '\n      <defs>\n        <marker id="rgz-arrow" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto" markerUnits="strokeWidth">\n          <path d="M0,0 L0,6 L9,3 z" fill="#f8fafc" />\n        </marker>\n      </defs>\n      <rect class="rgz-canvas-bg" x="-5000" y="-5000" width="10000" height="10000" fill="#07101f"></rect>\n      <g id="rgz-print-area-layer"></g>\n      <g id="rgz-connections"></g>\n      <g id="rgz-components"></g>\n    '),
    (m = document.getElementById("rgz-print-area-layer")),
    (y = document.getElementById("rgz-connections")),
    (h = document.getElementById("rgz-components")),
    R(),
    n.addEventListener(
      "pointerdown",
      (e) => {
        const t = e.target.closest('[data-action="stop"]'),
          r = e.target.closest("[data-control-kind]");
        if (t) return (e.preventDefault(), e.stopPropagation(), void Ie());
        r &&
          (e.preventDefault(),
          e.stopPropagation(),
          (r.dataset.rgzPointerHandled = String(Date.now())),
          $e(r));
      },
      !0,
    ),
    n.addEventListener("click", (t) => {
      const r = t.target.closest("[data-control-kind]");
      if (r) {
        const e = Number(r.dataset.rgzPointerHandled || 0);
        if (e && Date.now() - e < 800) return;
        return (t.preventDefault(), t.stopPropagation(), void $e(r));
      }
      const a = t.target.closest("[data-action]");
      a &&
        (t.preventDefault(),
        (function (t) {
          switch (t) {
            case "toggle-library":
              rt("library");
              break;
            case "toggle-actions":
              rt("actions");
              break;
            case "toggle-inspector":
              rt("inspector");
              break;
            case "toggle-messages":
              !(function () {
                const e = n.querySelector(".rgz-bottom-panel");
                e && e.classList.toggle("rgz-open");
              })();
              break;
            case "toggle-live-controls":
              !(function () {
                const e = document.getElementById("rgz-mobile-live-controls");
                e && e.classList.toggle("rgz-collapsed");
              })();
              break;
            case "toggle-file-menu":
              !(function () {
                const e = document.getElementById("rgz-file-menu");
                e && e.classList.toggle("open");
              })();
              break;
            case "zoom-in":
              tt(0.78);
              break;
            case "zoom-out":
              tt(1.28);
              break;
            case "fullscreen":
              !(async function () {
                try {
                  if (document.fullscreenElement)
                    return (
                      await document.exitFullscreen(),
                      void n.classList.remove("rgz-fallback-fullscreen")
                    );
                  n.requestFullscreen
                    ? await n.requestFullscreen()
                    : n.classList.toggle("rgz-fallback-fullscreen");
                } catch (e) {
                  n.classList.toggle("rgz-fallback-fullscreen");
                }
                setTimeout(() => {
                  (R(), H());
                }, 120);
              })();
              break;
            case "new":
              (p.components.length &&
                !window.confirm(
                  "Start a new blank circuit? Unsaved changes will be lost unless exported.",
                )) ||
                (Ie(),
                (p.components = []),
                (p.connections = []),
                (p.selected = null),
                (p.pendingPort = null),
                (p.projectMeta.projectName = "Untitled hydraulic circuit"),
                (p.currentExampleGlobalIndex = null),
                (p.nextId = 1),
                H(),
                ke(),
                Te(!1));
              break;
            case "insert-power-pack":
              O(
                "powerPack",
                p.viewBox.x + 160,
                p.viewBox.y + p.viewBox.h - 180,
              );
              break;
            case "insert-text":
              !(function () {
                const e = E(
                  "textLabel",
                  p.viewBox.x + 0.5 * p.viewBox.w,
                  p.viewBox.y + 100,
                  { props: { text: "متن / Custom text" } },
                );
                (p.components.push(e),
                  (p.selected = { kind: "component", id: e.id }),
                  H(),
                  ke(),
                  Pe(e.id));
              })();
              break;
            case "fit":
              st();
              break;
            case "rotate-selected":
              it(90);
              break;
            case "rotate-selected-ccw":
              it(-90);
              break;
            case "check":
              Te(!0);
              break;
            case "simulate":
              (at(),
                (function () {
                  if (p.sim.running) return;
                  if (Te(!1).filter((e) => "error" === e.severity).length) {
                    qe();
                    const e = n.querySelector(".rgz-bottom-panel");
                    return (
                      e && e.classList.add("rgz-open"),
                      void lt(
                        "Simulation blocked. Fix circuit errors first.",
                        "error",
                      )
                    );
                  }
                  ((function () {
                    if (!p.sim.worker)
                      try {
                        const e = new Blob(
                            [
                              `\n      function number(value, fallback){ const n = Number(value); return Number.isFinite(n) ? n : fallback; }\n      function clamp(v,min,max){ return Math.max(min, Math.min(max, v)); }\n      const fluidNet = ${rgzFluidSolve.toString()};\n      const solver = function(c, x, dt, tm){ return fluidNet({ fluid: 'oil', components: c, connections: x, dt: dt, time: tm }); };\n      self.onmessage = function(event){\n        const d = event.data;\n        self.postMessage(solver(d.components || [], d.connections || [], d.dt || 0, d.time || 0));\n      };\n    `,
                            ],
                            { type: "application/javascript" },
                          ),
                          t = URL.createObjectURL(e);
                        ((p.sim.worker = new Worker(t)),
                          (p.sim.worker.onmessage = (e) => {
                            ((p.sim.workerBusy = !1), (p.sim.metrics = e.data));
                          }),
                          (p.sim.worker.onerror = () => {
                            ((p.sim.workerBusy = !1),
                              (p.sim.worker = null),
                              lt(
                                "Web Worker solver failed; using main-thread fallback.",
                                "warning",
                              ));
                          }));
                      } catch (e) {
                        p.sim.worker = null;
                      }
                  })(),
                    (p.sim.running = !0),
                    (p.inspectorTab = "simulation"),
                    (p.sim.time = 0),
                    (p.sim.last = performance.now()),
                    (p.sim.lastCanvasRender = 0),
                    n.classList.remove("rgz-show-actions"));
                  const e = document.getElementById("rgz-mobile-live-controls");
                  (e && e.classList.remove("rgz-collapsed"),
                    Ne(),
                    ke(),
                    Ce(),
                    lt(
                      "Simulation started. Use live valve controls or the Properties panel to change states.",
                      "ok",
                    ),
                    (p.sim.raf = requestAnimationFrame(Re)));
                })());
              break;
            case "stop":
              Ie();
              break;
            case "open-charts":
              chartApi().open();
              break;
            case "set-print-area":
              Oe();
              break;
            case "clear-print-area":
              He();
              break;
            case "print":
              Ue();
              break;
            case "export-rgz":
              We();
              break;
            case "import-rgz":
              document.getElementById("rgz-import-input").click();
              break;
            case "browse-examples":
              !(function () {
                const e = n.querySelector(".rgz-modal-backdrop");
                e && e.remove();
                const t = document.createElement("div");
                ((t.className = "rgz-modal-backdrop"),
                  (t.innerHTML =
                    '\n      <div class="rgz-modal rgz-examples-modal" role="dialog" aria-modal="true" aria-label="Pre-designed circuits">\n        <div class="rgz-modal-head">\n          <div><h3>Pre-designed circuit library</h3><p>Choose a level and an example. Each level contains 15 circuits numbered 01–15.</p></div>\n          <button class="rgz-btn icon" data-modal-close>×</button>\n        </div>\n        <div class="rgz-modal-body">\n          <div class="rgz-example-modal-grid">\n            <div class="rgz-field"><label>Level</label><select class="rgz-native-select" id="rgz-level-selectbox"></select></div>\n            <div class="rgz-field"><label>Example</label><select class="rgz-native-select" id="rgz-example-selectbox"></select></div>\n          </div>\n          <div class="rgz-panel"><div class="rgz-panel-title">Selected circuit</div><p id="rgz-example-preview" class="rgz-example-preview"></p></div>\n        </div>\n        <div class="rgz-modal-foot"><span>Symmetrical examples load as editable drawings.</span><button class="rgz-btn" data-modal-close>Cancel</button><button class="rgz-btn primary" data-modal-open-example>Open selected circuit</button></div>\n      </div>\n    '),
                  n.appendChild(t),
                  ut());
                const r = () => {
                  const e = pt(p.exampleLevel),
                    r = e[p.exampleIndex] || e[0],
                    n = t.querySelector("#rgz-example-preview");
                  n &&
                    r &&
                    (n.textContent = `${String(p.exampleIndex + 1).padStart(2, "0")} — ${r.name}`);
                };
                (r(),
                  t.addEventListener("click", (e) => {
                    if (e.target.closest("[data-modal-open-example]"))
                      return (mt(), void t.remove());
                    ((e.target === t ||
                      e.target.closest("[data-modal-close]")) &&
                      t.remove(),
                      setTimeout(r, 0));
                  }));
              })();
              break;
            case "load-example":
              mt();
              break;
            case "add-example-template":
              !(async function () {
                if (!e.canManageExamples)
                  return void lt(
                    "Only the site owner can add pre-designed circuits.",
                    "error",
                  );
                if (!p.components.length)
                  return void lt(
                    "Design something first, then add it as a new pre-designed circuit.",
                    "warning",
                  );
                const t = (
                  window.prompt("Title for the new pre-designed circuit:") || ""
                ).trim();
                if (!t) return;
                const r = dt(),
                  n = p.exampleLevel || r[0] || "Owner custom circuits",
                  a =
                    (
                      window.prompt(
                        `Level/category for this circuit:\n\nExisting levels:\n${r.join("\n")}\n\nYou can type a new level too.`,
                        n,
                      ) || ""
                    ).trim() || "Owner custom circuits",
                  i = q();
                ((i.metadata.projectName = t),
                  (i.metadata.notes = `Owner-added pre-designed RGZ circuit: ${t}.`));
                try {
                  const r = await _e(
                    "rgz_hydraulic_add_example",
                    { name: t, level: a, project_json: JSON.stringify(i) },
                    e.saveNonce,
                  );
                  ((e.customExamples = e.customExamples || []),
                    e.customExamples.push(r.item),
                    yt.push({
                      level: r.item.level,
                      name: r.item.name,
                      customId: r.item.id,
                      builder: () => k(r.item.project),
                    }),
                    (p.exampleLevel = r.item.level),
                    (p.exampleIndex = pt(p.exampleLevel).length - 1),
                    lt("New pre-designed circuit added for all users.", "ok"));
                } catch (e) {
                  lt(e.message, "error");
                }
              })();
              break;
            case "save-example-template":
              !(async function () {
                if (!e.canManageExamples)
                  return void lt(
                    "Only the site owner can save pre-designed circuits.",
                    "error",
                  );
                const t = p.currentExampleGlobalIndex;
                if (null == t)
                  return void lt(
                    "Open a pre-designed circuit first, edit it, then save it as the shared template.",
                    "warning",
                  );
                const r = yt[t];
                if (!r) return;
                if (
                  !window.confirm(
                    `Save the current drawing as the shared pre-designed circuit for all users?\n\n${r.level} — ${r.name}`,
                  )
                )
                  return;
                const n = q();
                ((n.metadata.projectName = r.name),
                  (n.metadata.notes = `Owner-modified pre-designed RGZ circuit: ${r.name}.`));
                try {
                  const r = await _e(
                    "rgz_hydraulic_save_example",
                    { index: t, project_json: JSON.stringify(n) },
                    e.saveNonce,
                  );
                  ((e.exampleOverrides = e.exampleOverrides || {}),
                    (e.exampleOverrides[String(t)] = r.project || n),
                    lt(
                      "Pre-designed circuit saved. Everyone will now load this version.",
                      "ok",
                    ));
                } catch (e) {
                  lt(e.message, "error");
                }
              })();
              break;
            case "reset-example-template":
              !(async function () {
                if (!e.canManageExamples) return;
                const t = p.currentExampleGlobalIndex;
                if (null == t)
                  return void lt(
                    "Open a pre-designed circuit first.",
                    "warning",
                  );
                const r = yt[t];
                if (
                  r &&
                  window.confirm(
                    `Reset this pre-designed circuit to the built-in version?\n\n${r.name}`,
                  )
                )
                  try {
                    (await _e(
                      "rgz_hydraulic_reset_example",
                      { index: t },
                      e.saveNonce,
                    ),
                      e.exampleOverrides &&
                        delete e.exampleOverrides[String(t)],
                      I(ht(t)),
                      (p.currentExampleGlobalIndex = t),
                      lt(
                        "Pre-designed circuit reset to built-in version.",
                        "ok",
                      ));
                  } catch (e) {
                    lt(e.message, "error");
                  }
              })();
              break;
            case "account":
              Ze();
              break;
            case "clear-messages":
              ((p.messages = []), qe());
              break;
            case "delete-selected":
              ot();
              break;
            case "duplicate-selected":
              !(function () {
                if ("component" !== p.selected?.kind) return;
                const e = p.components.find((e) => e.id === p.selected.id);
                if (!e) return;
                const t = $(e.type),
                  r = E(e.type, e.x + 60, e.y + 60, { props: k(e.props) });
                ((r.label = `${t.prefix}${p.nextId - 1}`),
                  p.components.push(r),
                  (p.selected = { kind: "component", id: r.id }),
                  H(),
                  ke());
              })();
          }
          (["toggle-file-menu"].includes(t) ||
            (function () {
              const e = document.getElementById("rgz-file-menu");
              e && e.classList.remove("open");
            })(),
            [
              "toggle-library",
              "toggle-actions",
              "toggle-inspector",
              "toggle-messages",
            ].includes(t) ||
              (window.matchMedia(
                "(max-width: 920px) and (orientation: landscape)",
              ).matches &&
                n.classList.remove(
                  "rgz-show-library",
                  "rgz-show-actions",
                  "rgz-show-inspector",
                )));
        })(a.getAttribute("data-action")));
    }),
    u.addEventListener("dragover", (e) => e.preventDefault()),
    u.addEventListener("drop", (e) => {
      e.preventDefault();
      const t = e.dataTransfer.getData("application/rgz-component");
      if (!t) return;
      const r = F(e);
      O(t, r.x, r.y);
    }),
    u.addEventListener("pointerdown", (e) => {
      (e.ctrlKey ||
        e.metaKey ||
        e.target === u ||
        e.target.classList.contains("rgz-canvas-bg")) &&
        D(e);
    }),
    u.addEventListener("pointermove", (e) => {
      const t = F(e);
      if (
        ((x.textContent = `x: ${Math.round(t.x)} · y: ${Math.round(t.y)}`),
        p.drag)
      )
        if ("component" === p.drag.kind) {
          const t = p.components.find((e) => e.id === p.drag.id);
          if (!t) return;
          const r = F(e);
          ((t.x = S(p.drag.startX + (r.x - p.drag.startPoint.x))),
            (t.y = S(p.drag.startY + (r.y - p.drag.startPoint.y))),
            H());
        } else if ("pan" === p.drag.kind) {
          const t = p.viewBox.w / u.clientWidth,
            r = p.viewBox.h / u.clientHeight;
          ((p.viewBox.x =
            p.drag.startViewBox.x - (e.clientX - p.drag.startClientX) * t),
            (p.viewBox.y =
              p.drag.startViewBox.y - (e.clientY - p.drag.startClientY) * r),
            R());
        }
    }),
    u.addEventListener("pointerup", (e) => {
      if (p.drag) {
        p.drag = null;
        try {
          u.releasePointerCapture(e.pointerId);
        } catch (e) {}
      }
      e.ctrlKey || e.metaKey || u.classList.remove("rgz-ctrl-pan");
    }),
    u.addEventListener(
      "wheel",
      (e) => {
        e.preventDefault();
        const t = F(e),
          r = e.deltaY > 0 ? 1.12 : 0.88,
          n = p.viewBox;
        ((n.x = t.x - (t.x - n.x) * r),
          (n.y = t.y - (t.y - n.y) * r),
          (n.w = z(n.w * r, 300, 5e3)),
          (n.h = z(n.h * r, 200, 3500)),
          R());
      },
      { passive: !1 },
    ),
    document.addEventListener("keydown", (e) => {
      if (
        (("Control" !== e.key && "Meta" !== e.key) ||
          u.classList.add("rgz-ctrl-pan"),
        "Delete" === e.key || "Backspace" === e.key)
      ) {
        const e = String(document.activeElement?.tagName || "").toLowerCase();
        ["input", "textarea", "select"].includes(e) || ot();
      }
      (e.ctrlKey || e.metaKey) &&
        "s" === e.key.toLowerCase() &&
        (e.preventDefault(), We());
    }),
    document.addEventListener("keyup", (e) => {
      ("Control" !== e.key && "Meta" !== e.key) ||
        u.classList.remove("rgz-ctrl-pan");
    }),
    window.addEventListener("blur", () => u.classList.remove("rgz-ctrl-pan")),
    document.getElementById("rgz-search").addEventListener("input", (e) => {
      ((p.search = e.target.value), j());
    }),
    document
      .getElementById("rgz-import-input")
      .addEventListener("change", (e) => {
        const t = e.target.files?.[0];
        t &&
          (async function (e) {
            await Qe(new Uint8Array(await e.arrayBuffer()));
          })(t).finally(() => {
            e.target.value = "";
          });
      }),
    window.addEventListener("orientationchange", () => setTimeout(at, 450)),
    window.addEventListener("resize", () => {
      (nt(), setTimeout(at, 150));
    }),
    window.visualViewport &&
      window.visualViewport.addEventListener("resize", nt),
    n.addEventListener("pointerdown", at, { once: !1 }),
    j(),
    ut(),
    (p.components = []),
    (p.connections = []),
    (p.selected = null),
    (p.pendingPort = null),
    (p.currentExampleGlobalIndex = null),
    H(),
    qe(),
    ke(),
    (async function () {
      if (p.accountToken)
        try {
          const e = await _e("rgz_hydraulic_me");
          ((p.user = e.user || null),
            p.user ||
              ((p.accountToken = ""),
              localStorage.removeItem("rgzHydraulicAccountToken")));
        } catch (e) {
          ((p.user = null),
            (p.accountToken = ""),
            localStorage.removeItem("rgzHydraulicAccountToken"));
        }
    })(),
    setTimeout(at, 500),
    lt(
      "RGZ Hydraulic Studio loaded. Drag a symbol onto the canvas or load an example.",
      "ok",
    ));
})(); /*! RGZ Pneumatic Studio - Production build. Copyright HoumanRGZ / https://houmanrgz.ir . Unauthorized redistribution is prohibited. */
(() => {
  "use strict";
  const e = window.RGZPneumaticStudioConfig || {
      siteUrl: "https://houmanrgz.ir/",
      websiteLabel: "https://houmanrgz.ir",
      assetBase: "",
      version: "1.0.0",
    },
    t = "1.0.0",
    r = e.websiteLabel || "https://houmanrgz.ir",
    n = document.getElementById("rgz-pneumatic-studio");
  if (!n) return;
  const a = [
      "Power",
      "Valves",
      "Actuators",
      "Conditioning",
      "Measurement",
      "Control",
      "Lines",
      "Annotations",
    ],
    i = [
      {
        type: "exhaust",
        category: "Power",
        name: "Atmosphere / exhaust reference",
        prefix: "T",
        w: 104,
        h: 80,
        desc: "Reference exhaust/atmosphere connection for pneumatic circuits.",
        ports: [{ id: "T", x: 0, y: -42, kind: "pneumatic", required: !0 }],
        defaults: { capacityL: 80, oilTempC: 40 },
        propSchema: [
          {
            key: "capacityL",
            label: "Capacity, L",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "oilTempC",
            label: "Air temperature, °C",
            type: "number",
            min: -20,
            step: 1,
          },
        ],
      },
      {
        type: "compressorFixed",
        category: "Power",
        name: "Air compressor",
        prefix: "P",
        w: 126,
        h: 88,
        desc: "Compressed-air source. Supplies flow to pneumatic circuits through an FRL/service unit.",
        ports: [
          { id: "S", x: -58, y: 0, kind: "pneumatic", required: !0 },
          { id: "P", x: 58, y: 0, kind: "pneumatic", required: !0 },
        ],
        defaults: { flowLpm: 500, maxPressureBar: 8, efficiency: 0.75 },
        propSchema: [
          {
            key: "flowLpm",
            label: "Flow, L/min",
            type: "number",
            min: 0,
            step: 0.1,
          },
          {
            key: "maxPressureBar",
            label: "Max pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "efficiency",
            label: "Efficiency",
            type: "number",
            min: 0.1,
            max: 1,
            step: 0.01,
          },
        ],
      },
      {
        type: "compressorVariable",
        category: "Power",
        name: "Variable compressor / vacuum compressor",
        prefix: "VP",
        w: 136,
        h: 92,
        desc: "Variable compressed-air source or vacuum compressor for advanced examples.",
        ports: [
          { id: "S", x: -62, y: 0, kind: "pneumatic", required: !0 },
          { id: "P", x: 62, y: 0, kind: "pneumatic", required: !0 },
          { id: "X", x: 0, y: -46, kind: "pilot", required: !1 },
        ],
        defaults: { flowLpm: 700, compensatorBar: 6, maxPressureBar: 10 },
        propSchema: [
          {
            key: "flowLpm",
            label: "Max flow, L/min",
            type: "number",
            min: 0,
            step: 0.1,
          },
          {
            key: "compensatorBar",
            label: "Compensator, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "maxPressureBar",
            label: "Max pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
        ],
      },
      {
        type: "powerPack",
        category: "Power",
        name: "Compressed air service unit",
        prefix: "HPU",
        w: 164,
        h: 112,
        desc: "Single block containing compressor, receiver, filter, regulator and pressure gauge to speed up sketching.",
        ports: [
          { id: "P", x: 82, y: -22, kind: "pneumatic", required: !1 },
          { id: "T", x: 82, y: 30, kind: "pneumatic", required: !1 },
        ],
        defaults: {
          flowLpm: 500,
          reliefSettingBar: 6,
          exhaustCapacityL: 50,
          pressureGauge: !0,
        },
        propSchema: [
          {
            key: "flowLpm",
            label: "Compressor flow, L/min",
            type: "number",
            min: 0,
            step: 0.1,
          },
          {
            key: "reliefSettingBar",
            label: "Regulator pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "exhaustCapacityL",
            label: "Receiver volume, L",
            type: "number",
            min: 1,
            step: 1,
          },
          { key: "pressureGauge", label: "Include gauge", type: "checkbox" },
        ],
      },
      {
        type: "reliefValve",
        category: "Valves",
        name: "Safety relief / regulator valve",
        prefix: "RV",
        w: 120,
        h: 96,
        desc: "Safety relief valve or relieving regulator for compressed air systems.",
        ports: [
          { id: "P", x: -58, y: 0, kind: "pneumatic", required: !0 },
          { id: "T", x: 58, y: 0, kind: "pneumatic", required: !0 },
        ],
        defaults: { settingBar: 8, crackingBar: 7.5 },
        propSchema: [
          {
            key: "settingBar",
            label: "Regulator/safety setting, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "crackingBar",
            label: "Cracking pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
        ],
      },
      {
        type: "directionalValve",
        category: "Valves",
        name: "Directional control valve builder",
        prefix: "V",
        w: 182,
        h: 118,
        desc: "Configurable 2/2, 3/2, 4/2, 4/3 valve with selectable actuation.",
        ports: [
          { id: "A", x: -42, y: -58, kind: "pneumatic", required: !0 },
          { id: "B", x: 42, y: -58, kind: "pneumatic", required: !0 },
          { id: "P", x: -42, y: 58, kind: "pneumatic", required: !0 },
          { id: "T", x: 42, y: 58, kind: "pneumatic", required: !0 },
          { id: "X", x: -92, y: 0, kind: "pilot", required: !1 },
          { id: "Y", x: 92, y: 0, kind: "pilot", required: !1 },
        ],
        defaults: {
          ports: "5",
          positions: "3",
          center: "closed",
          spoolState: "left",
          leftActuation: "solenoid",
          rightActuation: "spring",
          ratedFlowLpm: 600,
          pressureDropBar: 0.3,
        },
        propSchema: [
          {
            key: "ports",
            label: "Ports",
            type: "select",
            options: ["2", "3", "4", "5", "6"],
          },
          {
            key: "positions",
            label: "Positions",
            type: "select",
            options: ["2", "3"],
          },
          {
            key: "center",
            label: "Center condition",
            type: "select",
            options: ["closed", "open", "tandem", "float", "regenerative"],
          },
          {
            key: "leftBlock",
            label: "Left block pattern",
            type: "select",
            options: ["parallel", "crossover", "closed", "open", "tandem", "float", "regenerative"],
          },
          {
            key: "rightBlock",
            label: "Right block pattern",
            type: "select",
            options: ["crossover", "parallel", "closed", "open", "tandem", "float", "regenerative"],
          },
          {
            key: "spoolState",
            label: "Simulation spool state",
            type: "select",
            options: ["left", "center", "right"],
          },
          {
            key: "leftActuation",
            label: "Left actuation",
            type: "select",
            options: [
              "manual",
              "lever",
              "push button",
              "pedal",
              "roller",
              "solenoid",
              "proportional solenoid",
              "pneumatic pilot",
              "pneumatic pilot",
              "spring",
              "detent",
            ],
          },
          {
            key: "rightActuation",
            label: "Right actuation",
            type: "select",
            options: [
              "manual",
              "lever",
              "push button",
              "pedal",
              "roller",
              "solenoid",
              "proportional solenoid",
              "pneumatic pilot",
              "pneumatic pilot",
              "spring",
              "detent",
            ],
          },
          {
            key: "ratedFlowLpm",
            label: "Rated flow, L/min",
            type: "number",
            min: 0,
            step: 0.1,
          },
          {
            key: "pressureDropBar",
            label: "Δp at rated flow, bar",
            type: "number",
            min: 0,
            step: 0.1,
          },
        ],
      },
      {
        type: "flowControl",
        category: "Valves",
        name: "Adjustable flow control",
        prefix: "FC",
        w: 116,
        h: 80,
        desc: "Adjustable throttle/needle valve. Can act as meter-in or meter-out.",
        ports: [
          { id: "A", x: -54, y: 0, kind: "pneumatic", required: !0 },
          { id: "B", x: 54, y: 0, kind: "pneumatic", required: !0 },
        ],
        defaults: { openingPercent: 65, pressureCompensated: !1 },
        propSchema: [
          {
            key: "openingPercent",
            label: "Opening, %",
            type: "number",
            min: 0,
            max: 100,
            step: 1,
          },
          {
            key: "pressureCompensated",
            label: "Pressure compensated",
            type: "checkbox",
          },
        ],
      },
      {
        type: "checkValve",
        category: "Valves",
        name: "Check valve",
        prefix: "CV",
        w: 104,
        h: 74,
        desc: "One-way non-return valve.",
        ports: [
          { id: "A", x: -50, y: 0, kind: "pneumatic", required: !0 },
          { id: "B", x: 50, y: 0, kind: "pneumatic", required: !0 },
        ],
        defaults: { crackingBar: 0.5 },
        propSchema: [
          {
            key: "crackingBar",
            label: "Cracking pressure, bar",
            type: "number",
            min: 0,
            step: 0.1,
          },
        ],
      },
      {
        type: "pilotCheckValve",
        category: "Valves",
        name: "Pilot-operated check valve",
        prefix: "PCV",
        w: 126,
        h: 88,
        desc: "Load-holding check valve released by pilot pressure.",
        ports: [
          { id: "A", x: -58, y: 0, kind: "pneumatic", required: !0 },
          { id: "B", x: 58, y: 0, kind: "pneumatic", required: !0 },
          { id: "X", x: 0, y: -44, kind: "pilot", required: !0 },
        ],
        defaults: { pilotRatio: 3, crackingBar: 1 },
        propSchema: [
          {
            key: "pilotRatio",
            label: "Pilot ratio",
            type: "number",
            min: 1,
            step: 0.1,
          },
          {
            key: "crackingBar",
            label: "Cracking pressure, bar",
            type: "number",
            min: 0,
            step: 0.1,
          },
        ],
      },
      {
        type: "counterbalanceValve",
        category: "Valves",
        name: "Counterbalance valve",
        prefix: "CBV",
        w: 132,
        h: 94,
        desc: "Over-center/load-control valve for vertical cylinders.",
        ports: [
          { id: "A", x: -60, y: 0, kind: "pneumatic", required: !0 },
          { id: "B", x: 60, y: 0, kind: "pneumatic", required: !0 },
          { id: "X", x: 0, y: -48, kind: "pilot", required: !0 },
        ],
        defaults: { settingBar: 5, pilotRatio: 3 },
        propSchema: [
          {
            key: "settingBar",
            label: "Setting, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "pilotRatio",
            label: "Pilot ratio",
            type: "number",
            min: 1,
            step: 0.1,
          },
        ],
      },
      {
        type: "sequenceValve",
        category: "Valves",
        name: "Sequence valve",
        prefix: "SV",
        w: 126,
        h: 92,
        desc: "Opens after pressure reaches a set sequence value.",
        ports: [
          { id: "P", x: -58, y: 0, kind: "pneumatic", required: !0 },
          { id: "A", x: 58, y: 0, kind: "pneumatic", required: !0 },
          { id: "T", x: 0, y: 46, kind: "pneumatic", required: !1 },
        ],
        defaults: { settingBar: 70 },
        propSchema: [
          {
            key: "settingBar",
            label: "Sequence pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
        ],
      },
      {
        type: "reducingValve",
        category: "Valves",
        name: "Pressure reducing valve",
        prefix: "PRV",
        w: 126,
        h: 92,
        desc: "Reduces pressure on a branch line.",
        ports: [
          { id: "P", x: -58, y: 0, kind: "pneumatic", required: !0 },
          { id: "A", x: 58, y: 0, kind: "pneumatic", required: !0 },
          { id: "T", x: 0, y: 46, kind: "pneumatic", required: !1 },
        ],
        defaults: { outletBar: 4 },
        propSchema: [
          {
            key: "outletBar",
            label: "Outlet pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
        ],
      },
      {
        type: "cylinderDA",
        category: "Actuators",
        name: "Double-acting cylinder",
        prefix: "C",
        w: 188,
        h: 84,
        desc: "Cylinder with cap-end and rod-end ports.",
        ports: [
          { id: "A", x: -82, y: 34, kind: "pneumatic", required: !0 },
          { id: "B", x: 22, y: 34, kind: "pneumatic", required: !0 },
        ],
        defaults: {
          boreMm: 63,
          rodMm: 36,
          strokeMm: 500,
          loadKg: 350,
          simPosition: 0.25,
        },
        propSchema: [
          { key: "boreMm", label: "Bore, mm", type: "number", min: 1, step: 1 },
          { key: "rodMm", label: "Rod, mm", type: "number", min: 0, step: 1 },
          {
            key: "strokeMm",
            label: "Stroke, mm",
            type: "number",
            min: 1,
            step: 1,
          },
          { key: "loadKg", label: "Load, kg", type: "number", min: 0, step: 1 },
          {
            key: "loadMode",
            label: "Load over cycle",
            type: "select",
            options: ["constant", "time-based", "position-based", "formula (t & x)"],
          },
          {
            key: "loadProfile",
            label: "Load profile — 's, kg' or '0..1, kg' points per line — OR a formula in t & x: 800 + 400*sin(2*pi*t) + 1200*x^2",
            type: "textarea",
            placeholder: "0, 200\n2, 3000",
          },
          {
            key: "simPosition",
            label: "Rod position, 0–1",
            type: "number",
            min: 0,
            max: 1,
            step: 0.01,
          },
        ],
      },
      {
        type: "cylinderSA",
        category: "Actuators",
        name: "Single-acting cylinder",
        prefix: "SC",
        w: 170,
        h: 82,
        desc: "Single-acting cylinder with spring/external return.",
        ports: [{ id: "A", x: -76, y: 34, kind: "pneumatic", required: !0 }],
        defaults: {
          boreMm: 50,
          strokeMm: 300,
          loadKg: 100,
          springReturn: !0,
          simPosition: 0.15,
        },
        propSchema: [
          { key: "boreMm", label: "Bore, mm", type: "number", min: 1, step: 1 },
          {
            key: "strokeMm",
            label: "Stroke, mm",
            type: "number",
            min: 1,
            step: 1,
          },
          { key: "loadKg", label: "Load, kg", type: "number", min: 0, step: 1 },
          {
            key: "loadMode",
            label: "Load over cycle",
            type: "select",
            options: ["constant", "time-based", "position-based", "formula (t & x)"],
          },
          {
            key: "loadProfile",
            label: "Load profile — 's, kg' or '0..1, kg' points per line — OR a formula in t & x: 800 + 400*sin(2*pi*t) + 1200*x^2",
            type: "textarea",
            placeholder: "0, 200\n2, 3000",
          },
          { key: "springReturn", label: "Spring return", type: "checkbox" },
          {
            key: "simPosition",
            label: "Rod position, 0–1",
            type: "number",
            min: 0,
            max: 1,
            step: 0.01,
          },
        ],
      },
      {
        type: "pneumaticMotor",
        category: "Actuators",
        name: "Air motor",
        prefix: "M",
        w: 122,
        h: 86,
        desc: "Bi-directional pneumatic motor.",
        ports: [
          { id: "A", x: -58, y: 0, kind: "pneumatic", required: !0 },
          { id: "B", x: 58, y: 0, kind: "pneumatic", required: !0 },
        ],
        defaults: { displacementCcRev: 25, loadNm: 20, simAngle: 0 },
        propSchema: [
          {
            key: "displacementCcRev",
            label: "Displacement, cc/rev",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "loadNm",
            label: "Load torque, Nm",
            type: "number",
            min: 0,
            step: 1,
          },          {
            key: "loadMode",
            label: "Load over cycle",
            type: "select",
            options: ["constant", "time-based", "position-based", "formula (t & x)"],
          },
          {
            key: "loadProfile",
            label: "Load torque profile — 's, N·m' points per line — OR a formula in t & x: 20 + 10*sin(2*pi*t)",
            type: "textarea",
            placeholder: "0, 5\n2, 40",
          },

        ],
      },
      {
        type: "accumulator",
        category: "Actuators",
        name: "Air receiver / buffer tank",
        prefix: "ACC",
        w: 96,
        h: 104,
        desc: "Compressed-air receiver or buffer reservoir.",
        ports: [{ id: "A", x: 0, y: 52, kind: "pneumatic", required: !0 }],
        defaults: { prechargeBar: 5, volumeL: 5 },
        propSchema: [
          {
            key: "prechargeBar",
            label: "Precharge, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "volumeL",
            label: "Volume, L",
            type: "number",
            min: 0.1,
            step: 0.1,
          },
        ],
      },
      {
        type: "flowDivider",
        category: "Valves",
        name: "Flow divider / combiner",
        prefix: "FD",
        w: 132,
        h: 100,
        desc: "Divides one inlet flow into two branches.",
        ports: [
          { id: "P", x: 0, y: 50, kind: "pneumatic", required: !0 },
          { id: "A", x: -56, y: -10, kind: "pneumatic", required: !0 },
          { id: "B", x: 56, y: -10, kind: "pneumatic", required: !0 },
        ],
        defaults: { splitPercentA: 50 },
        propSchema: [
          {
            key: "splitPercentA",
            label: "Flow to A, %",
            type: "number",
            min: 1,
            max: 99,
            step: 1,
          },
        ],
      },
      {
        type: "filter",
        category: "Conditioning",
        name: "Filter",
        prefix: "F",
        w: 110,
        h: 78,
        desc: "Pressure, return, or suction filter.",
        ports: [
          { id: "A", x: -52, y: 0, kind: "pneumatic", required: !0 },
          { id: "B", x: 52, y: 0, kind: "pneumatic", required: !0 },
        ],
        defaults: { ratingMicron: 10, betaRatio: 200 },
        propSchema: [
          {
            key: "ratingMicron",
            label: "Rating, μm",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "betaRatio",
            label: "Beta ratio",
            type: "number",
            min: 1,
            step: 1,
          },
        ],
      },
      {
        type: "cooler",
        category: "Conditioning",
        name: "Cooler / heat exchanger",
        prefix: "HX",
        w: 120,
        h: 82,
        desc: "Air dryer, aftercooler or moisture-removal unit.",
        ports: [
          { id: "A", x: -56, y: 0, kind: "pneumatic", required: !0 },
          { id: "B", x: 56, y: 0, kind: "pneumatic", required: !0 },
        ],
        defaults: { coolingKw: 3 },
        propSchema: [
          {
            key: "coolingKw",
            label: "Cooling capacity, kW",
            type: "number",
            min: 0,
            step: 0.1,
          },
        ],
      },
      {
        type: "pressureGauge",
        category: "Measurement",
        name: "Pressure gauge",
        prefix: "PG",
        w: 82,
        h: 92,
        desc: "Analog pressure gauge.",
        ports: [{ id: "P", x: 0, y: 46, kind: "pneumatic", required: !0 }],
        defaults: { rangeBar: 10 },
        propSchema: [
          {
            key: "rangeBar",
            label: "Gauge range, bar",
            type: "number",
            min: 1,
            step: 1,
          },
        ],
      },
      {
        type: "flowMeter",
        category: "Measurement",
        name: "Flow meter",
        prefix: "FM",
        w: 112,
        h: 76,
        desc: "Pneumatic flow meter.",
        ports: [
          { id: "A", x: -54, y: 0, kind: "pneumatic", required: !0 },
          { id: "B", x: 54, y: 0, kind: "pneumatic", required: !0 },
        ],
        defaults: { rangeLpm: 600 },
        propSchema: [
          {
            key: "rangeLpm",
            label: "Range, L/min",
            type: "number",
            min: 1,
            step: 1,
          },
        ],
      },
      {
        type: "pressureSwitch",
        category: "Measurement",
        name: "Pressure switch",
        prefix: "PS",
        w: 108,
        h: 90,
        desc: "Pneumatic pressure switch with electrical contact.",
        ports: [
          { id: "P", x: 0, y: 46, kind: "pneumatic", required: !0 },
          { id: "E", x: 50, y: -24, kind: "electrical", required: !1 },
        ],
        defaults: { switchBar: 5, contact: "NO" },
        propSchema: [
          {
            key: "switchBar",
            label: "Switch pressure, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "contact",
            label: "Contact",
            type: "select",
            options: ["NO", "NC"],
          },
        ],
      },
      {
        type: "pressureTransducer",
        category: "Measurement",
        name: "Pressure transducer",
        prefix: "PT",
        w: 112,
        h: 90,
        desc: "Analog pressure sensor/transducer for feedback and monitoring.",
        ports: [
          { id: "P", x: 0, y: 46, kind: "pneumatic", required: !0 },
          { id: "E", x: 52, y: -18, kind: "electrical", required: !1 },
        ],
        defaults: { rangeBar: 10, signal: "4-20 mA", active: !1 },
        propSchema: [
          {
            key: "rangeBar",
            label: "Range, bar",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "signal",
            label: "Output signal",
            type: "select",
            options: ["4-20 mA", "0-10 V", "IO-Link", "Digital"],
          },
        ],
      },
      {
        type: "flowSwitch",
        category: "Measurement",
        name: "Flow switch / flow sensor",
        prefix: "FS",
        w: 126,
        h: 82,
        desc: "Detects flow above a set value and can trigger a control action.",
        ports: [
          { id: "A", x: -58, y: 0, kind: "pneumatic", required: !0 },
          { id: "B", x: 58, y: 0, kind: "pneumatic", required: !0 },
          { id: "E", x: 0, y: -42, kind: "electrical", required: !1 },
        ],
        defaults: {
          switchLpm: 50,
          active: !1,
          action: "none",
          targetControl: "",
        },
        propSchema: [
          {
            key: "switchLpm",
            label: "Switch flow, L/min",
            type: "number",
            min: 0,
            step: 0.1,
          },
          {
            key: "action",
            label: "Action when active",
            type: "select",
            options: [
              "none",
              "set valve left",
              "set valve center",
              "set valve right",
              "energize solenoid",
              "de-energize solenoid",
            ],
          },
          {
            key: "targetControl",
            label: "Target valve/solenoid ID or label",
            type: "text",
          },
        ],
      },
      {
        type: "temperatureSwitch",
        category: "Measurement",
        name: "Temperature switch",
        prefix: "TS",
        w: 108,
        h: 88,
        desc: "Compressed-air temperature switch/sensor for alarm or control feedback.",
        ports: [
          { id: "P", x: 0, y: 44, kind: "pneumatic", required: !1 },
          { id: "E", x: 50, y: -18, kind: "electrical", required: !1 },
        ],
        defaults: {
          switchTempC: 60,
          active: !1,
          action: "none",
          targetControl: "",
        },
        propSchema: [
          {
            key: "switchTempC",
            label: "Switch temperature, °C",
            type: "number",
            min: -20,
            step: 1,
          },
          {
            key: "active",
            label: "Force active in simulation",
            type: "checkbox",
          },
          {
            key: "action",
            label: "Action when active",
            type: "select",
            options: [
              "none",
              "set valve left",
              "set valve center",
              "set valve right",
              "energize solenoid",
              "de-energize solenoid",
            ],
          },
          {
            key: "targetControl",
            label: "Target valve/solenoid ID or label",
            type: "text",
          },
        ],
      },
      {
        type: "levelSwitch",
        category: "Measurement",
        name: "Condensate level switch",
        prefix: "LSH",
        w: 112,
        h: 88,
        desc: "Condensate level switch for filter bowls, dryers or receivers.",
        ports: [
          { id: "E1", x: -52, y: 0, kind: "electrical", required: !1 },
          { id: "E2", x: 52, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: {
          levelPercent: 20,
          mode: "low level",
          active: !1,
          action: "none",
          targetControl: "",
        },
        propSchema: [
          {
            key: "levelPercent",
            label: "Level setpoint, %",
            type: "number",
            min: 0,
            max: 100,
            step: 1,
          },
          {
            key: "mode",
            label: "Switch mode",
            type: "select",
            options: ["low level", "high level"],
          },
          {
            key: "active",
            label: "Force active in simulation",
            type: "checkbox",
          },
          {
            key: "action",
            label: "Action when active",
            type: "select",
            options: [
              "none",
              "set valve left",
              "set valve center",
              "set valve right",
              "energize solenoid",
              "de-energize solenoid",
            ],
          },
          {
            key: "targetControl",
            label: "Target valve/solenoid ID or label",
            type: "text",
          },
        ],
      },
      {
        type: "limitSwitch",
        category: "Control",
        name: "Mechanical limit switch",
        prefix: "LS",
        w: 118,
        h: 78,
        desc: "Roller/lever limit switch for actuator end-position feedback.",
        ports: [
          { id: "E1", x: -56, y: 0, kind: "electrical", required: !1 },
          { id: "E2", x: 56, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: {
          linkedActuator: "",
          triggerAt: "extended",
          triggerPosition: 1,
          active: !1,
          action: "none",
          targetControl: "",
        },
        propSchema: [
          {
            key: "linkedActuator",
            label: "Linked actuator ID/label",
            type: "text",
          },
          {
            key: "triggerAt",
            label: "Trigger position",
            type: "select",
            options: ["retracted", "extended", "custom"],
          },
          {
            key: "triggerPosition",
            label: "Custom position 0–1",
            type: "number",
            min: 0,
            max: 1,
            step: 0.01,
          },
          {
            key: "action",
            label: "Action when active",
            type: "select",
            options: [
              "none",
              "set valve left",
              "set valve center",
              "set valve right",
              "energize solenoid",
              "de-energize solenoid",
            ],
          },
          {
            key: "targetControl",
            label: "Target valve/solenoid ID or label",
            type: "text",
          },
        ],
      },
      {
        type: "cylinderReedSensor",
        category: "Control",
        name: "Cylinder magnetic/reed sensor",
        prefix: "RS",
        w: 126,
        h: 78,
        desc: "Cylinder-mounted magnetic sensor for retracted, extended, or custom rod position.",
        ports: [
          { id: "E1", x: -58, y: 0, kind: "electrical", required: !1 },
          { id: "E2", x: 58, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: {
          linkedActuator: "",
          triggerAt: "extended",
          triggerPosition: 1,
          active: !1,
          action: "set valve right",
          targetControl: "",
        },
        propSchema: [
          {
            key: "linkedActuator",
            label: "Linked cylinder ID/label",
            type: "text",
          },
          {
            key: "triggerAt",
            label: "Trigger position",
            type: "select",
            options: ["retracted", "extended", "custom"],
          },
          {
            key: "triggerPosition",
            label: "Custom position 0–1",
            type: "number",
            min: 0,
            max: 1,
            step: 0.01,
          },
          {
            key: "action",
            label: "Action when active",
            type: "select",
            options: [
              "none",
              "set valve left",
              "set valve center",
              "set valve right",
              "energize solenoid",
              "de-energize solenoid",
            ],
          },
          {
            key: "targetControl",
            label: "Target valve/solenoid ID or label",
            type: "text",
          },
        ],
      },
      {
        type: "linearPositionSensor",
        category: "Control",
        name: "Linear position sensor / LVDT",
        prefix: "LVDT",
        w: 140,
        h: 78,
        desc: "Analog cylinder position feedback sensor with optional switching action.",
        ports: [
          { id: "E1", x: -64, y: 0, kind: "electrical", required: !1 },
          { id: "E2", x: 64, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: {
          linkedActuator: "",
          triggerAt: "custom",
          triggerPosition: 0.5,
          signal: "0-10 V",
          active: !1,
          action: "none",
          targetControl: "",
        },
        propSchema: [
          {
            key: "linkedActuator",
            label: "Linked actuator ID/label",
            type: "text",
          },
          {
            key: "triggerAt",
            label: "Switching point",
            type: "select",
            options: ["retracted", "extended", "custom"],
          },
          {
            key: "triggerPosition",
            label: "Position 0–1",
            type: "number",
            min: 0,
            max: 1,
            step: 0.01,
          },
          {
            key: "signal",
            label: "Output signal",
            type: "select",
            options: ["0-10 V", "4-20 mA", "SSI", "CANopen", "IO-Link"],
          },
          {
            key: "action",
            label: "Action when active",
            type: "select",
            options: [
              "none",
              "set valve left",
              "set valve center",
              "set valve right",
              "energize solenoid",
              "de-energize solenoid",
            ],
          },
          {
            key: "targetControl",
            label: "Target valve/solenoid ID or label",
            type: "text",
          },
        ],
      },
      {
        type: "proximitySensor",
        category: "Control",
        name: "Inductive/proximity sensor",
        prefix: "B",
        w: 118,
        h: 76,
        desc: "Non-contact proximity sensor for position, guard, or machine feedback.",
        ports: [
          { id: "E1", x: -56, y: 0, kind: "electrical", required: !1 },
          { id: "E2", x: 56, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: {
          linkedActuator: "",
          triggerAt: "custom",
          triggerPosition: 0.5,
          sensingDistanceMm: 5,
          active: !1,
          action: "none",
          targetControl: "",
        },
        propSchema: [
          {
            key: "linkedActuator",
            label: "Linked actuator ID/label",
            type: "text",
          },
          {
            key: "triggerAt",
            label: "Trigger position",
            type: "select",
            options: ["retracted", "extended", "custom"],
          },
          {
            key: "triggerPosition",
            label: "Custom position 0–1",
            type: "number",
            min: 0,
            max: 1,
            step: 0.01,
          },
          {
            key: "sensingDistanceMm",
            label: "Sensing distance, mm",
            type: "number",
            min: 0,
            step: 0.1,
          },
          {
            key: "action",
            label: "Action when active",
            type: "select",
            options: [
              "none",
              "set valve left",
              "set valve center",
              "set valve right",
              "energize solenoid",
              "de-energize solenoid",
            ],
          },
          {
            key: "targetControl",
            label: "Target valve/solenoid ID or label",
            type: "text",
          },
        ],
      },
      {
        type: "pushButton",
        category: "Control",
        name: "Push button / manual input",
        prefix: "PB",
        w: 102,
        h: 76,
        desc: "Clickable NO/NC push button for electropneumatic control examples.",
        ports: [
          { id: "E1", x: -48, y: 0, kind: "electrical", required: !1 },
          { id: "E2", x: 48, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: { contact: "NO", pressed: !1, momentary: !0 },
        propSchema: [
          {
            key: "contact",
            label: "Contact",
            type: "select",
            options: ["NO", "NC"],
          },
          { key: "pressed", label: "Pressed in simulation", type: "checkbox" },
          { key: "momentary", label: "Momentary button", type: "checkbox" },
        ],
      },
      {
        type: "solenoid",
        category: "Control",
        name: "Solenoid coil",
        prefix: "Y",
        w: 92,
        h: 74,
        desc: "Electrical coil for valve actuation.",
        ports: [
          { id: "E1", x: -44, y: 0, kind: "electrical", required: !1 },
          { id: "E2", x: 44, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: { voltage: "24 VDC", energized: !1, targetControl: "" },
        propSchema: [
          { key: "voltage", label: "Voltage", type: "text" },
          {
            key: "energized",
            label: "Energized in simulation",
            type: "checkbox",
          },
          {
            key: "targetControl",
            label: "Drives valve (label/id, empty = auto)",
            type: "text",
          },
        ],
      },
      {
        type: "plc",
        category: "Control",
        name: "PLC I/O block",
        prefix: "PLC",
        w: 126,
        h: 92,
        desc: "Programmable controller: runs logic rungs every scan, e.g. 'PB1 AND NOT B1 -> V1 left' or 'Q1 = PB1 OR Q1 AND NOT B1'. Deleting it stops the sequence.",
        ports: [
          { id: "I1", x: -58, y: -18, kind: "electrical", required: !1 },
          { id: "I2", x: -58, y: 18, kind: "electrical", required: !1 },
          { id: "Q1", x: 58, y: -18, kind: "electrical", required: !1 },
          { id: "Q2", x: 58, y: 18, kind: "electrical", required: !1 },
        ],
        defaults: { program: "Q1 = I1; Q2 = I2;", targetControl: "" },
        propSchema: [
          {
            key: "program",
            label: "Program (PLC rungs)",
            type: "textarea",
          },
        ],
      },
      {
        type: "junction",
        category: "Lines",
        name: "Line junction",
        prefix: "J",
        w: 52,
        h: 52,
        desc: "Pneumatic junction/dot for branching lines.",
        ports: [
          { id: "A", x: -26, y: 0, kind: "pneumatic", required: !1 },
          { id: "B", x: 26, y: 0, kind: "pneumatic", required: !1 },
          { id: "C", x: 0, y: -26, kind: "pneumatic", required: !1 },
          { id: "D", x: 0, y: 26, kind: "pneumatic", required: !1 },
        ],
        defaults: {},
        propSchema: [],
      },
      {
        type: "textLabel",
        category: "Annotations",
        name: "Custom text / title",
        prefix: "TXT",
        w: 280,
        h: 90,
        desc: "Movable annotation text for titles, notes and Persian/RTL labels. Appears in print.",
        ports: [],
        defaults: {
          text: "Custom text",
          color: "#e8793c",
          fontSize: 24,
          fontFamily: "Tahoma, Arial, sans-serif",
          fontWeight: "700",
          direction: "auto",
          align: "start",
        },
        propSchema: [
          { key: "text", label: "Text / متن", type: "textarea" },
          { key: "color", label: "Text color", type: "color" },
          {
            key: "fontSize",
            label: "Font size",
            type: "number",
            min: 8,
            max: 96,
            step: 1,
          },
          {
            key: "fontFamily",
            label: "Font family",
            type: "select",
            options: [
              "Tahoma, Arial, sans-serif",
              "Arial, sans-serif",
              "Inter, sans-serif",
              "Times New Roman, serif",
              "Courier New, monospace",
            ],
          },
          {
            key: "fontWeight",
            label: "Font weight",
            type: "select",
            options: ["400", "500", "600", "700", "800", "900"],
          },
          {
            key: "direction",
            label: "Text direction",
            type: "select",
            options: ["auto", "ltr", "rtl"],
          },
          {
            key: "align",
            label: "Alignment",
            type: "select",
            options: ["start", "middle", "end"],
          },
        ],
      },
    ],
    o = {
      exhaust: {
        name: "Atmosphere / exhaust reference",
        desc: "Reference exhaust/atmosphere connection for pneumatic circuits.",
        defaults: { capacityL: 0, oilTempC: 25 },
        propLabels: {
          capacityL: "Reference volume, L",
          oilTempC: "Air temperature, °C",
        },
      },
      compressorFixed: {
        name: "Air compressor",
        desc: "Compressed air source. Supplies pressure and flow to the pneumatic service unit.",
        propLabels: {
          flowLpm: "Free air delivery, L/min",
          maxPressureBar: "Max pressure, bar",
        },
      },
      compressorVariable: {
        name: "Variable compressor / vacuum compressor",
        desc: "Variable compressed-air source or vacuum compressor for advanced pneumatic examples.",
      },
      powerPack: {
        name: "Compressed air service unit",
        desc: "Compact block containing compressor, receiver, regulator, filter and pressure gauge.",
        propLabels: {
          flowLpm: "Compressor flow, L/min",
          reliefSettingBar: "Regulator pressure, bar",
          exhaustCapacityL: "Receiver volume, L",
        },
      },
      reliefValve: {
        name: "Safety relief / pressure regulator valve",
        desc: "Pressure limiting valve or relieving regulator for compressed air systems.",
        propLabels: { settingBar: "Regulator/safety setting, bar" },
      },
      flowControl: {
        name: "One-way speed control / throttle",
        desc: "Adjustable pneumatic speed control for meter-in or meter-out cylinder control.",
      },
      pilotCheckValve: {
        name: "Pilot-operated check / lock valve",
        desc: "Pneumatic load-holding/check valve released by pilot pressure.",
      },
      counterbalanceValve: {
        name: "Quick exhaust / dump valve",
        desc: "Fast exhaust valve used to increase cylinder speed or dump air safely.",
      },
      sequenceValve: {
        name: "Pneumatic sequence valve",
        desc: "Opens after pressure reaches a set value to create pneumatic sequences.",
      },
      reducingValve: {
        name: "Pressure regulator",
        desc: "Reduces branch pressure in pneumatic circuits.",
      },
      cylinderDA: {
        name: "Double-acting pneumatic cylinder",
        desc: "Compressed-air cylinder with cap-end and rod-end ports.",
      },
      cylinderSA: {
        name: "Single-acting pneumatic cylinder",
        desc: "Single-acting compressed-air cylinder with spring/external return.",
      },
      pneumaticMotor: {
        name: "Air motor",
        desc: "Rotary pneumatic actuator / air motor.",
      },
      accumulator: {
        name: "Air receiver / buffer tank",
        desc: "Compressed-air receiver used as buffer volume or storage.",
      },
      filter: {
        name: "Air filter / water separator",
        desc: "Compressed-air filter or water separator.",
      },
      cooler: {
        name: "Air dryer / aftercooler",
        desc: "Air dryer, aftercooler or moisture-removal unit.",
      },
      pressureGauge: {
        name: "Pneumatic pressure gauge",
        desc: "Pressure gauge for compressed air systems.",
      },
      flowMeter: {
        name: "Air flow meter",
        desc: "Flow meter for compressed air consumption and leakage checks.",
      },
      pressureSwitch: {
        name: "Pneumatic pressure switch",
        desc: "Pressure switch for compressed-air control and feedback.",
      },
      pressureTransducer: {
        name: "Pneumatic pressure transducer",
        desc: "Analog pressure sensor/transducer for compressed-air feedback.",
      },
      temperatureSwitch: {
        name: "Air temperature switch",
        desc: "Compressed-air temperature switch/sensor for alarm or control feedback.",
      },
      levelSwitch: {
        name: "Condensate level switch",
        desc: "Condensate level switch for filter bowls, dryers or receivers.",
      },
    };
  (i.forEach((e) => {
    const t = o[e.type];
    t &&
      (t.name && (e.name = t.name),
      t.desc && (e.desc = t.desc),
      t.defaults &&
        (e.defaults = Object.assign({}, e.defaults || {}, t.defaults)),
      t.propLabels &&
        e.propSchema &&
        e.propSchema.forEach((e) => {
          t.propLabels[e.key] && (e.label = t.propLabels[e.key]);
        }));
  }),
    i.push(
      {
        type: "frlUnit",
        category: "Conditioning",
        name: "FRL unit",
        prefix: "FRL",
        w: 142,
        h: 86,
        desc: "Filter-regulator-lubricator air preparation unit.",
        ports: [
          { id: "P", x: -66, y: 0, kind: "pneumatic", required: !0 },
          { id: "A", x: 66, y: 0, kind: "pneumatic", required: !0 },
        ],
        defaults: { regulatorBar: 6, filterMicron: 5, lubricator: !1 },
        propSchema: [
          {
            key: "regulatorBar",
            label: "Regulated pressure, bar",
            type: "number",
            min: 0,
            step: 0.1,
          },
          {
            key: "filterMicron",
            label: "Filter rating, μm",
            type: "number",
            min: 0,
            step: 1,
          },
          { key: "lubricator", label: "Include lubricator", type: "checkbox" },
        ],
      },
      {
        type: "silencer",
        category: "Conditioning",
        name: "Exhaust silencer / muffler",
        prefix: "SIL",
        w: 88,
        h: 64,
        desc: "Muffler for pneumatic exhaust ports R/S/T.",
        ports: [{ id: "E", x: -40, y: 0, kind: "pneumatic", required: !1 }],
        defaults: { noiseReductionDb: 20 },
        propSchema: [
          {
            key: "noiseReductionDb",
            label: "Noise reduction, dB",
            type: "number",
            min: 0,
            step: 1,
          },
        ],
      },
      {
        type: "quickExhaustValve",
        category: "Valves",
        name: "Quick exhaust valve",
        prefix: "QEV",
        w: 124,
        h: 86,
        desc: "Pneumatic valve that vents cylinder air locally for fast motion.",
        ports: [
          { id: "P", x: -56, y: 0, kind: "pneumatic", required: !0 },
          { id: "A", x: 56, y: -18, kind: "pneumatic", required: !0 },
          { id: "R", x: 56, y: 18, kind: "pneumatic", required: !1 },
        ],
        defaults: { exhaustCv: 1.2 },
        propSchema: [
          {
            key: "exhaustCv",
            label: "Exhaust Cv",
            type: "number",
            min: 0,
            step: 0.1,
          },
        ],
      },
      {
        type: "vacuumEjector",
        category: "Actuators",
        name: "Vacuum ejector / Venturi",
        prefix: "VE",
        w: 134,
        h: 86,
        desc: "Compressed-air vacuum generator for pick-and-place systems.",
        ports: [
          { id: "P", x: -60, y: 0, kind: "pneumatic", required: !0 },
          { id: "V", x: 60, y: -18, kind: "pneumatic", required: !0 },
          { id: "R", x: 60, y: 18, kind: "pneumatic", required: !1 },
        ],
        defaults: { vacuumKpa: -65, airConsumptionLpm: 90 },
        propSchema: [
          { key: "vacuumKpa", label: "Vacuum, kPa", type: "number", step: 1 },
          {
            key: "airConsumptionLpm",
            label: "Air consumption, L/min",
            type: "number",
            min: 0,
            step: 1,
          },
        ],
      },
      {
        type: "suctionCup",
        category: "Actuators",
        name: "Vacuum suction cup",
        prefix: "SCUP",
        w: 96,
        h: 70,
        desc: "Suction cup actuator for vacuum handling.",
        ports: [{ id: "V", x: -44, y: 0, kind: "pneumatic", required: !0 }],
        defaults: { cupDiameterMm: 40, holdingForceN: 80 },
        propSchema: [
          {
            key: "cupDiameterMm",
            label: "Cup diameter, mm",
            type: "number",
            min: 1,
            step: 1,
          },
          {
            key: "holdingForceN",
            label: "Holding force, N",
            type: "number",
            min: 0,
            step: 1,
          },
        ],
      },
      {
        type: "airBlowNozzle",
        category: "Actuators",
        name: "Air blow nozzle",
        prefix: "NOZ",
        w: 96,
        h: 62,
        desc: "Air blow nozzle for cleaning, cooling or ejecting parts.",
        ports: [{ id: "P", x: -44, y: 0, kind: "pneumatic", required: !0 }],
        defaults: { nozzleDiameterMm: 2, flowLpm: 120 },
        propSchema: [
          {
            key: "nozzleDiameterMm",
            label: "Nozzle diameter, mm",
            type: "number",
            min: 0,
            step: 0.1,
          },
          {
            key: "flowLpm",
            label: "Flow, L/min",
            type: "number",
            min: 0,
            step: 1,
          },
        ],
      },
      {
        type: "shuttleValve",
        category: "Valves",
        name: "Shuttle valve / OR logic",
        prefix: "OR",
        w: 118,
        h: 80,
        desc: "Pneumatic OR logic valve: output receives pressure from either input.",
        ports: [
          { id: "A", x: -54, y: -18, kind: "pneumatic", required: !0 },
          { id: "B", x: -54, y: 18, kind: "pneumatic", required: !0 },
          { id: "X", x: 54, y: 0, kind: "pneumatic", required: !0 },
        ],
        defaults: {},
        propSchema: [],
      },
      {
        type: "twoPressureValve",
        category: "Valves",
        name: "Two-pressure valve / AND logic",
        prefix: "AND",
        w: 118,
        h: 80,
        desc: "Pneumatic AND logic valve: output only when both inputs are pressurized.",
        ports: [
          { id: "A", x: -54, y: -18, kind: "pneumatic", required: !0 },
          { id: "B", x: -54, y: 18, kind: "pneumatic", required: !0 },
          { id: "X", x: 54, y: 0, kind: "pneumatic", required: !0 },
        ],
        defaults: {},
        propSchema: [],
      },
      {
        type: "softStartValve",
        category: "Valves",
        name: "Soft-start / dump valve",
        prefix: "SSV",
        w: 126,
        h: 84,
        desc: "Soft-start and quick-dump valve for pneumatic safety circuits.",
        ports: [
          { id: "P", x: -58, y: 0, kind: "pneumatic", required: !0 },
          { id: "A", x: 58, y: -18, kind: "pneumatic", required: !0 },
          { id: "R", x: 58, y: 18, kind: "pneumatic", required: !1 },
        ],
        defaults: { rampTimeS: 1.5 },
        propSchema: [
          {
            key: "rampTimeS",
            label: "Ramp time, s",
            type: "number",
            min: 0,
            step: 0.1,
          },
        ],
      },
    ),
    i.push(
      {
        type: "compressedAirDistributor",
        category: "Lines",
        name: "Compressed-air distributor / manifold",
        prefix: "DIST",
        w: 132,
        h: 96,
        desc: "Compressed-air distribution manifold with one supply and multiple outlet branches.",
        ports: [
          { id: "P", x: -64, y: 0, kind: "pneumatic", required: !0 },
          { id: "A", x: 64, y: -28, kind: "pneumatic", required: !1 },
          { id: "B", x: 64, y: 0, kind: "pneumatic", required: !1 },
          { id: "C", x: 64, y: 28, kind: "pneumatic", required: !1 },
        ],
        defaults: { outlets: 3, pressureBar: 6 },
        propSchema: [
          {
            key: "outlets",
            label: "Number of outlets",
            type: "number",
            min: 1,
            max: 6,
            step: 1,
          },
          {
            key: "pressureBar",
            label: "Distribution pressure, bar",
            type: "number",
            min: 0,
            step: 0.1,
          },
        ],
      },
      {
        type: "valveTerminal",
        category: "Valves",
        name: "Valve terminal / manifold valve island",
        prefix: "VT",
        w: 178,
        h: 116,
        desc: "Block-mounted directional valves with common supply and common exhaust, reducing tubing effort.",
        ports: [
          { id: "P", x: -88, y: 0, kind: "pneumatic", required: !0 },
          { id: "R", x: -88, y: 34, kind: "pneumatic", required: !1 },
          { id: "A1", x: 88, y: -34, kind: "pneumatic", required: !1 },
          { id: "B1", x: 88, y: -12, kind: "pneumatic", required: !1 },
          { id: "A2", x: 88, y: 12, kind: "pneumatic", required: !1 },
          { id: "B2", x: 88, y: 34, kind: "pneumatic", required: !1 },
          { id: "E", x: 0, y: -58, kind: "electrical", required: !1 },
        ],
        defaults: { stations: 2, fieldbus: "none", supplyBar: 6 },
        propSchema: [
          {
            key: "stations",
            label: "Valve stations",
            type: "number",
            min: 1,
            max: 16,
            step: 1,
          },
          {
            key: "fieldbus",
            label: "Electrical interface",
            type: "select",
            options: ["none", "multi-pin", "fieldbus"],
          },
          {
            key: "supplyBar",
            label: "Supply pressure, bar",
            type: "number",
            min: 0,
            step: 0.1,
          },
        ],
      },
      {
        type: "powerSupply24V",
        category: "Control",
        name: "24 V DC power supply",
        prefix: "PSU",
        w: 120,
        h: 76,
        desc: "Electrical power supply for electropneumatic controls and PLC inputs/outputs.",
        ports: [
          { id: "+24", x: -56, y: -12, kind: "electrical", required: !1 },
          { id: "0V", x: -56, y: 12, kind: "electrical", required: !1 },
          { id: "OUT", x: 56, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: { voltage: 24, currentA: 2 },
        propSchema: [
          {
            key: "voltage",
            label: "Voltage, VDC",
            type: "number",
            min: 0,
            step: 1,
          },
          {
            key: "currentA",
            label: "Current, A",
            type: "number",
            min: 0,
            step: 0.1,
          },
        ],
      },
      {
        type: "indicatorLamp",
        category: "Control",
        name: "Indicator lamp",
        prefix: "H",
        w: 82,
        h: 72,
        desc: "Optical indicator used in electrical signal control sections.",
        ports: [
          { id: "E1", x: -38, y: 0, kind: "electrical", required: !1 },
          { id: "E2", x: 38, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: { colorLamp: "green", on: !1 },
        propSchema: [
          {
            key: "colorLamp",
            label: "Lamp color",
            type: "select",
            options: ["green", "red", "yellow", "blue", "white"],
          },
          { key: "on", label: "On in simulation", type: "checkbox" },
        ],
      },
      {
        type: "electricalRelay",
        category: "Control",
        name: "Relay / contactor coil",
        prefix: "K",
        w: 108,
        h: 76,
        desc: "Relay coil for electropneumatic switching logic.",
        ports: [
          { id: "A1", x: -50, y: 0, kind: "electrical", required: !1 },
          { id: "A2", x: 50, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: { energized: !1, coilVoltage: "24 VDC" },
        propSchema: [
          { key: "energized", label: "Energized", type: "checkbox" },
          { key: "coilVoltage", label: "Coil voltage", type: "text" },
        ],
      },
      {
        type: "relayContact",
        category: "Control",
        name: "Relay contact NO/NC",
        prefix: "K-C",
        w: 112,
        h: 76,
        desc: "Electrical relay contact used for latching and interlocking circuits.",
        ports: [
          { id: "E1", x: -54, y: 0, kind: "electrical", required: !1 },
          { id: "E2", x: 54, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: { contact: "NO", closed: !1 },
        propSchema: [
          {
            key: "contact",
            label: "Contact type",
            type: "select",
            options: ["NO", "NC"],
          },
          { key: "closed", label: "Closed in simulation", type: "checkbox" },
        ],
      },
      {
        type: "terminalStrip",
        category: "Control",
        name: "Terminal strip",
        prefix: "X",
        w: 126,
        h: 80,
        desc: "Terminal connection strip for wiring documentation.",
        ports: [
          { id: "E1", x: -58, y: -18, kind: "electrical", required: !1 },
          { id: "E2", x: -58, y: 18, kind: "electrical", required: !1 },
          { id: "Q1", x: 58, y: -18, kind: "electrical", required: !1 },
          { id: "Q2", x: 58, y: 18, kind: "electrical", required: !1 },
        ],
        defaults: { terminals: 8 },
        propSchema: [
          {
            key: "terminals",
            label: "Number of terminals",
            type: "number",
            min: 2,
            step: 1,
          },
        ],
      },
      {
        type: "inductiveSensor",
        category: "Control",
        name: "Inductive proximity sensor",
        prefix: "B",
        w: 118,
        h: 76,
        desc: "Electronic proximity sensor for metallic targets and end-position feedback.",
        ports: [
          { id: "E1", x: -56, y: 0, kind: "electrical", required: !1 },
          { id: "E2", x: 56, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: {
          linkedActuator: "",
          triggerAt: "custom",
          triggerPosition: 0.5,
          sensingDistanceMm: 4,
          active: !1,
          action: "none",
          targetControl: "",
        },
        propSchema: [
          {
            key: "linkedActuator",
            label: "Linked actuator ID/label",
            type: "text",
          },
          {
            key: "triggerAt",
            label: "Trigger position",
            type: "select",
            options: ["retracted", "extended", "custom"],
          },
          {
            key: "triggerPosition",
            label: "Custom position 0–1",
            type: "number",
            min: 0,
            max: 1,
            step: 0.01,
          },
          {
            key: "sensingDistanceMm",
            label: "Sensing distance, mm",
            type: "number",
            min: 0,
            step: 0.1,
          },
          {
            key: "action",
            label: "Action when active",
            type: "select",
            options: [
              "none",
              "set valve left",
              "set valve center",
              "set valve right",
              "energize solenoid",
              "de-energize solenoid",
            ],
          },
          {
            key: "targetControl",
            label: "Target valve/solenoid ID or label",
            type: "text",
          },
        ],
      },
      {
        type: "capacitiveSensor",
        category: "Control",
        name: "Capacitive proximity sensor",
        prefix: "B",
        w: 118,
        h: 76,
        desc: "Electronic proximity sensor for non-metallic parts, filling levels and objects.",
        ports: [
          { id: "E1", x: -56, y: 0, kind: "electrical", required: !1 },
          { id: "E2", x: 56, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: {
          sensitivity: 50,
          active: !1,
          action: "none",
          targetControl: "",
        },
        propSchema: [
          {
            key: "sensitivity",
            label: "Sensitivity, %",
            type: "number",
            min: 0,
            max: 100,
            step: 1,
          },
          {
            key: "action",
            label: "Action when active",
            type: "select",
            options: [
              "none",
              "set valve left",
              "set valve center",
              "set valve right",
              "energize solenoid",
              "de-energize solenoid",
            ],
          },
          {
            key: "targetControl",
            label: "Target valve/solenoid ID or label",
            type: "text",
          },
        ],
      },
      {
        type: "opticalSensor",
        category: "Control",
        name: "Optical proximity sensor",
        prefix: "B",
        w: 118,
        h: 76,
        desc: "Photoelectric sensor for part detection and electropneumatic input signals.",
        ports: [
          { id: "E1", x: -56, y: 0, kind: "electrical", required: !1 },
          { id: "E2", x: 56, y: 0, kind: "electrical", required: !1 },
        ],
        defaults: {
          mode: "diffuse",
          active: !1,
          action: "none",
          targetControl: "",
        },
        propSchema: [
          {
            key: "mode",
            label: "Optical mode",
            type: "select",
            options: ["diffuse", "through-beam", "retro-reflective"],
          },
          {
            key: "action",
            label: "Action when active",
            type: "select",
            options: [
              "none",
              "set valve left",
              "set valve center",
              "set valve right",
              "energize solenoid",
              "de-energize solenoid",
            ],
          },
          {
            key: "targetControl",
            label: "Target valve/solenoid ID or label",
            type: "text",
          },
        ],
      },
      {
        type: "pneumaticTimeDelayValve",
        category: "Valves",
        name: "Pneumatic time-delay valve",
        prefix: "TD",
        w: 136,
        h: 86,
        desc: "Pneumatic timer using restrictor/reservoir principle for delayed switching.",
        ports: [
          { id: "P", x: -62, y: 0, kind: "pneumatic", required: !0 },
          { id: "A", x: 62, y: 0, kind: "pneumatic", required: !0 },
          { id: "R", x: 0, y: 42, kind: "pneumatic", required: !1 },
        ],
        defaults: { delayS: 1, mode: "on-delay" },
        propSchema: [
          {
            key: "delayS",
            label: "Delay, s",
            type: "number",
            min: 0,
            step: 0.1,
          },
          {
            key: "mode",
            label: "Mode",
            type: "select",
            options: ["on-delay", "off-delay"],
          },
        ],
      },
      {
        type: "pneumaticMemoryValve",
        category: "Valves",
        name: "Pneumatic memory valve / double-pilot 5/2",
        prefix: "MEM",
        w: 150,
        h: 92,
        desc: "Bistable pneumatic memory valve for signal storage and sequence control.",
        ports: [
          { id: "P", x: 0, y: 46, kind: "pneumatic", required: !0 },
          { id: "A", x: -34, y: -46, kind: "pneumatic", required: !0 },
          { id: "B", x: 34, y: -46, kind: "pneumatic", required: !0 },
          { id: "R", x: -34, y: 46, kind: "pneumatic", required: !1 },
          { id: "S", x: 34, y: 46, kind: "pneumatic", required: !1 },
          { id: "X", x: -75, y: 0, kind: "pilot", required: !1 },
          { id: "Y", x: 75, y: 0, kind: "pilot", required: !1 },
        ],
        defaults: { spoolState: "left" },
        propSchema: [
          {
            key: "spoolState",
            label: "Memory state",
            type: "select",
            options: ["left", "right"],
          },
        ],
      },
      {
        type: "pneumaticFunctionChart",
        category: "Annotations",
        name: "Function chart / displacement-step note",
        prefix: "FCN",
        w: 260,
        h: 120,
        desc: "Documentation note for pneumatic function diagrams and step sequences.",
        ports: [],
        defaults: {
          text: "Step 1: A+\nStep 2: B+\nStep 3: B-\nStep 4: A-",
          color: "#38bdf8",
          fontSize: 16,
          fontFamily: "Tahoma, Arial, sans-serif",
          fontWeight: "700",
          direction: "ltr",
          align: "start",
        },
        propSchema: [
          { key: "text", label: "Function chart text", type: "textarea" },
          { key: "color", label: "Text color", type: "color" },
          {
            key: "fontSize",
            label: "Font size",
            type: "number",
            min: 8,
            max: 72,
            step: 1,
          },
        ],
      },
    ));
  const s = {
      "2/2 normally closed": {
        ports: "2",
        positions: "2",
        center: "closed",
        spoolState: "right",
      },
      "2/2 normally open": {
        ports: "2",
        positions: "2",
        center: "open",
        spoolState: "left",
      },
      "3/2 normally closed": {
        ports: "3",
        positions: "2",
        center: "closed",
        spoolState: "right",
      },
      "3/2 normally open": {
        ports: "3",
        positions: "2",
        center: "open",
        spoolState: "left",
      },
      "4/2 directional valve": {
        ports: "5",
        positions: "2",
        center: "closed",
        spoolState: "left",
      },
      "4/3 closed center": {
        ports: "5",
        positions: "3",
        center: "closed",
        spoolState: "center",
      },
      "4/3 open center": {
        ports: "5",
        positions: "3",
        center: "open",
        spoolState: "center",
      },
      "4/3 tandem center": {
        ports: "5",
        positions: "3",
        center: "tandem",
        spoolState: "center",
      },
      "4/3 float center": {
        ports: "5",
        positions: "3",
        center: "float",
        spoolState: "center",
      },
      "4/3 regenerative center": {
        ports: "5",
        positions: "3",
        center: "regenerative",
        spoolState: "center",
      },
      "5/2 directional valve": {
        ports: "5",
        positions: "2",
        center: "closed",
        spoolState: "left",
      },
      "5/3 closed center": {
        ports: "5",
        positions: "3",
        center: "closed",
        spoolState: "center",
      },
      "5/3 open center": {
        ports: "5",
        positions: "3",
        center: "open",
        spoolState: "center",
      },
      "5/3 exhaust center": {
        ports: "5",
        positions: "3",
        center: "float",
        spoolState: "center",
      },
    },
    l = i.find((e) => "directionalValve" === e.type);
  ((l.defaults = Object.assign({ valveType: "4/3 closed center" }, l.defaults)),
    (l.propSchema = [
      {
        key: "valveType",
        label: "Way valve type",
        type: "select",
        options: [
          "2/2 normally closed",
          "2/2 normally open",
          "3/2 normally closed",
          "3/2 normally open",
          "4/2 directional valve",
          "4/3 closed center",
          "4/3 open center",
          "4/3 tandem center",
          "4/3 float center",
          "4/3 regenerative center",
          "5/2 directional valve",
          "5/3 closed center",
          "5/3 open center",
          "5/3 exhaust center",
        ],
      },
      ...l.propSchema,
    ]));
  const c = [
    [
      "directionalValve22NC",
      "2/2 way valve — normally closed",
      "Compact 2-port shut-off valve.",
      "2/2 normally closed",
    ],
    [
      "directionalValve22NO",
      "2/2 way valve — normally open",
      "Compact 2-port normally-open valve.",
      "2/2 normally open",
    ],
    [
      "directionalValve32NC",
      "3/2 way valve — normally closed",
      "Three-port valve for single acting actuators.",
      "3/2 normally closed",
    ],
    [
      "directionalValve32NO",
      "3/2 way valve — normally open",
      "Three-port normally-open valve.",
      "3/2 normally open",
    ],
    [
      "directionalValve42",
      "4/2 way valve",
      "Four-port two-position directional valve.",
      "4/2 directional valve",
    ],
    [
      "directionalValve43Closed",
      "4/3 way valve — closed center",
      "All ports blocked in center.",
      "4/3 closed center",
    ],
    [
      "directionalValve43Open",
      "4/3 way valve — open center",
      "Open-center four-port valve.",
      "4/3 open center",
    ],
    [
      "directionalValve43Tandem",
      "4/3 way valve — tandem center",
      "P to T open, A/B blocked in center.",
      "4/3 tandem center",
    ],
    [
      "directionalValve43Float",
      "4/3 way valve — float center",
      "A/B to T, P blocked in center.",
      "4/3 float center",
    ],
    [
      "directionalValve43Regen",
      "4/3 way valve — regenerative center",
      "Regenerative center option.",
      "4/3 regenerative center",
    ],
    [
      "directionalValve52",
      "5/2 way valve",
      "Five-port two-position directional valve.",
      "5/2 directional valve",
    ],
    [
      "directionalValve53Closed",
      "5/3 way valve — closed center",
      "Five-port three-position closed-center valve.",
      "5/3 closed center",
    ],
    [
      "directionalValve53Open",
      "5/3 way valve — open center",
      "Five-port three-position open-center valve.",
      "5/3 open center",
    ],
  ].map(([e, t, r, n]) =>
    Object.assign({}, l, {
      type: e,
      name: t,
      desc: r,
      baseType: "directionalValve",
      defaults: Object.assign({}, l.defaults, s[n], { valveType: n }),
    }),
  );
  function p(e, t, r) {
    const n = i.find((t) => t.type === e);
    if (!n) return;
    n.defaults = Object.assign(
      {},
      n.defaults || {},
      { showReadout: !0 },
      t || {},
    );
    const a = new Set((n.propSchema || []).map((e) => e.key));
    ((n.propSchema = n.propSchema || []),
      a.has("showReadout") ||
        n.propSchema.push({
          key: "showReadout",
          label: "Show live value in simulation",
          type: "checkbox",
        }),
      (r || []).forEach((e) => {
        a.has(e.key) || n.propSchema.push(e);
      }));
  }
  (i.splice(i.indexOf(l) + 1, 0, ...c),
    [
      "pressureGauge",
      "pressureSwitch",
      "pressureTransducer",
      "reliefValve",
      "powerPack",
    ].forEach((e) =>
      p(e, { displayUnit: "bar" }, [
        {
          key: "displayUnit",
          label: "Display unit",
          type: "select",
          options: ["bar", "MPa", "psi"],
        },
      ]),
    ),
    ["flowMeter", "flowSwitch"].forEach((e) =>
      p(e, { displayUnit: "L/min" }, [
        {
          key: "displayUnit",
          label: "Display unit",
          type: "select",
          options: ["L/min", "L/s", "GPM"],
        },
      ]),
    ),
    ["temperatureSwitch"].forEach((e) =>
      p(e, { displayUnit: "°C" }, [
        {
          key: "displayUnit",
          label: "Display unit",
          type: "select",
          options: ["°C", "°F"],
        },
      ]),
    ),
    ["levelSwitch"].forEach((e) =>
      p(e, { displayUnit: "%" }, [
        {
          key: "displayUnit",
          label: "Display unit",
          type: "select",
          options: ["%"],
        },
      ]),
    ),
    [
      "limitSwitch",
      "cylinderReedSensor",
      "linearPositionSensor",
      "proximitySensor",
      "inductiveSensor",
      "capacitiveSensor",
      "opticalSensor",
    ].forEach((e) =>
      p(e, { displayUnit: "%" }, [
        {
          key: "displayUnit",
          label: "Display unit",
          type: "select",
          options: ["%", "state"],
        },
      ]),
    ),
    ["cylinderDA", "cylinderSA"].forEach((e) =>
      p(e, { displayUnit: "position %" }, [
        {
          key: "displayUnit",
          label: "Display unit",
          type: "select",
          options: ["position %", "position mm", "speed mm/s", "force kN"],
        },
      ]),
    ),
    ["pneumaticMotor"].forEach((e) =>
      p(e, { displayUnit: "rpm" }, [
        {
          key: "displayUnit",
          label: "Display unit",
          type: "select",
          options: ["rpm", "rev/s"],
        },
      ]),
    ));
  const d = new Map(i.map((e) => [e.type, e])),
    u = {
      components: [],
      connections: [],
      selected: null,
      pendingPort: null,
      messages: [],
      inspectorTab: "properties",
      search: "",
      nextId: 1,
      exampleLevel: "Simple circuits",
      exampleIndex: 0,
      currentExampleGlobalIndex: null,
      user: e.user || null,
      accountToken: localStorage.getItem("rgzPneumaticAccountToken") || "",
      authMode: "signin",
      projectMeta: {
        projectName: "Untitled pneumatic circuit",
        designer: "",
        standard: "ISO-style / RGZ educational template",
        revision: "A",
        notes:
          "Simulation is approximate and intended for education/preliminary design.",
      },
      viewBox: { x: 0, y: 0, w: 1800, h: 1200 },
      printArea: null,
      printMode: "whole",
      drag: null,
      calc: {
        flowLpm: 25,
        lineType: "pressure",
        velocityMps: 4,
        diameterMm: 12,
        lengthM: 2,
        densityKgM3: 870,
        viscosityCSt: 46,
        fittingK: 2,
      },
      sim: {
        running: !1,
        time: 0,
        raf: null,
        last: 0,
        worker: null,
        workerBusy: !1,
        metrics: null,
        timeScale: 1,
        lastPanelRender: 0,
        lastCanvasRender: 0,
      },
    };
  let m, g, h, y, v, f, b, x, w, k;
  function M(e) {
    return JSON.parse(JSON.stringify(e));
  }
  function z(e) {
    return String(e ?? "").replace(
      /[&<>'"]/g,
      (e) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          "'": "&#39;",
          '"': "&quot;",
        })[e],
    );
  }
  function S(e, t, r) {
    return Math.max(t, Math.min(r, e));
  }
  function A(e, t = 20) {
    return Math.round(e / t) * t;
  }
  function P(e, t = 0) {
    const r = Number(e);
    return Number.isFinite(r) ? r : t;
  }
  function $(e, t = {}, r = []) {
    const n = document.createElementNS("http://www.w3.org/2000/svg", e);
    return (
      Object.entries(t).forEach(([e, t]) => {
        null != t && !1 !== t && n.setAttribute(e, String(t));
      }),
      (Array.isArray(r) ? r : [r]).forEach((e) => {
        "string" == typeof e
          ? n.appendChild(document.createTextNode(e))
          : e && n.appendChild(e);
      }),
      n
    );
  }
  function L(e) {
    return d.get(e);
  }
  function C(e) {
    const t = "string" == typeof e ? e : e?.type,
      r = L(t);
    return "directionalValve" === t || "directionalValve" === r?.baseType;
  }
  function B(e) {
    const t = Number(e.props.ports || 4),
      r = (2 === Number(e.props.positions || 3) ? 136 : 204) / 2 + 22;
    let n;
    return (
      (n =
        t <= 2
          ? [
              { id: "A", x: 0, y: -39, kind: "pneumatic", required: !0 },
              { id: "P", x: 0, y: 39, kind: "pneumatic", required: !0 },
            ]
          : 3 === t
            ? [
                { id: "A", x: 0, y: -39, kind: "pneumatic", required: !0 },
                { id: "P", x: -18, y: 39, kind: "pneumatic", required: !0 },
                { id: "T", x: 18, y: 39, kind: "pneumatic", required: !0 },
              ]
            : 5 === t
              ? [
                  { id: "A", x: -22, y: -39, kind: "pneumatic", required: !0 },
                  { id: "B", x: 22, y: -39, kind: "pneumatic", required: !0 },
                  { id: "R", x: -22, y: 39, kind: "pneumatic", required: !1 },
                  { id: "P", x: 0, y: 39, kind: "pneumatic", required: !0 },
                  { id: "S", x: 22, y: 39, kind: "pneumatic", required: !1 },
                ]
              : [
                  { id: "A", x: -18, y: -39, kind: "pneumatic", required: !0 },
                  { id: "B", x: 18, y: -39, kind: "pneumatic", required: !0 },
                  { id: "P", x: -18, y: 39, kind: "pneumatic", required: !0 },
                  { id: "T", x: 18, y: 39, kind: "pneumatic", required: !0 },
                ]),
      String(e.props.leftActuation || "").includes("pilot") &&
        n.push({ id: "X", x: -r, y: 0, kind: "pilot", required: !1 }),
      String(e.props.rightActuation || "").includes("pilot") &&
        n.push({ id: "Y", x: r, y: 0, kind: "pilot", required: !1 }),
      n
    );
  }
  function T(e) {
    const t = L(e.type);
    return t ? (C(e) ? B(e) : M(t.ports)) : [];
  }
  function E(e, t) {
    const r = u.components.find((t) => t.id === e);
    if (!r) return null;
    let n = t;
    C(r) && 5 === Number(r.props.ports || 4) && "T" === t && (n = "R");
    const a =
      T(r).find((e) => e.id === n) ||
      (L(r.type)?.ports || []).find((e) => e.id === n);
    if (!a) return null;
    const i = (function (e, t, r = 0) {
      const n = ((Number(r) || 0) * Math.PI) / 180,
        a = Math.cos(n),
        i = Math.sin(n);
      return { x: e * a - t * i, y: e * i + t * a };
    })(a.x, a.y, r.rotation || 0);
    return {
      x: r.x + i.x,
      y: r.y + i.y,
      kind: a.kind,
      component: r,
      port: a,
      vx: i.x,
      vy: i.y,
    };
  }
  function V(e, t, r, n = {}) {
    const a = L(e);
    if (!a) throw new Error(`Unknown component type: ${e}`);
    const i = u.nextId++,
      o = {
        id: `${a.prefix}-${i}`,
        type: e,
        label: `${a.prefix}${i}`,
        x: A(t),
        y: A(r),
        rotation: 0,
        props: M(a.defaults || {}),
      };
    return (
      Object.assign(o, n),
      (o.props = Object.assign(M(a.defaults || {}), n.props || {})),
      o
    );
  }
  function q(e, t, r, n, a = null, i = {}) {
    const o = E(e, t),
      s = E(r, n);
    let l = a;
    return (
      l ||
        (l =
          "electrical" === o?.kind || "electrical" === s?.kind
            ? "electrical"
            : "pilot" === o?.kind || "pilot" === s?.kind
              ? "pilot"
              : "pressure"),
      {
        id: `L-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`,
        from: { componentId: e, portId: t },
        to: { componentId: r, portId: n },
        lineType: l,
        properties: Object.assign(
          {
            tubeIdMm: 12,
            lengthM: 1,
            maxPressureBar: 10,
            color: "",
            strokeWidth: 3,
            routeMode: "auto",
            shift: 0,
          },
          i,
        ),
      }
    );
  }
  function I() {
    return {
      fileType: "rgz-pneumatic-project",
      formatVersion: 1,
      appVersion: t,
      createdBy: "RGZ Pneumatic Studio",
      website: r,
      exportedAt: new Date().toISOString(),
      metadata: M(u.projectMeta),
      viewBox: M(u.viewBox),
      printArea: M(u.printArea),
      components: M(u.components),
      connections: M(u.connections),
    };
  }
  function D(e, t = !1) {
    if (!e || !Array.isArray(e.components) || !Array.isArray(e.connections))
      return void ct(
        "This file does not look like an RGZ Pneumatic Studio project.",
        "error",
      );
    (De(),
      (u.components = M(e.components)),
      (u.connections = M(e.connections)),
      (u.projectMeta = Object.assign(u.projectMeta, M(e.metadata || {}))),
      (u.viewBox = Object.assign(
        { x: 0, y: 0, w: 1800, h: 1200 },
        M(e.viewBox || {}),
      )),
      (u.printArea = e.printArea ? M(e.printArea) : null));
    const r = u.components.reduce((e, t) => {
      const r = String(t.id).match(/\d+/g);
      return r ? Math.max(e, ...r.map(Number)) : e;
    }, 0);
    ((u.nextId = Math.max(r + 1, 1)),
      (u.selected = null),
      (u.pendingPort = null),
      R(),
      H(),
      Me(),
      Ee(!1),
      t || ct("Project loaded successfully.", "ok"));
  }
  function R() {
    const e = u.viewBox;
    m.setAttribute("viewBox", `${e.x} ${e.y} ${e.w} ${e.h}`);
  }
  function j(e) {
    const t = m.createSVGPoint();
    return (
      (t.x = e.clientX),
      (t.y = e.clientY),
      t.matrixTransform(m.getScreenCTM().inverse())
    );
  }
  function F(e) {
    const t = j(e);
    ((u.drag = {
      kind: "pan",
      startClientX: e.clientX,
      startClientY: e.clientY,
      startViewBox: M(u.viewBox),
      start: t,
    }),
      m.classList.add("rgz-ctrl-pan"));
    try {
      m.setPointerCapture(e.pointerId);
    } catch (e) {}
    e.preventDefault();
  }
  function N(e) {
    const t = e.type || "",
      r = e.category || "Other";
    return e.subcategory
      ? e.subcategory
      : "Power" === r
        ? ["powerPack"].includes(t)
          ? "Power units / service units"
          : [
                "pumpFixed",
                "pumpVariable",
                "compressorFixed",
                "compressorVariable",
                "electricMotor",
              ].includes(t)
            ? "Sources and prime movers"
            : ["tank", "exhaust", "accumulator"].includes(t)
              ? "Reservoirs / receivers"
              : "Power accessories"
        : "Valves" === r
          ? t.includes("cartridge") || "logicCartridgeValve" === t
            ? "Cartridge / manifold valves"
            : C(t) || "servoValve" === t
              ? "Directional and proportional valves"
              : [
                    "reliefValve",
                    "sequenceValve",
                    "reducingValve",
                    "counterbalanceValve",
                    "pressureCompensator",
                    "softStartValve",
                  ].includes(t)
                ? "Pressure control valves"
                : [
                      "flowControl",
                      "flowDivider",
                      "quickExhaustValve",
                      "cartridgeNeedleFlowValve",
                    ].includes(t)
                  ? "Flow control valves"
                  : [
                        "checkValve",
                        "pilotCheckValve",
                        "shuttleValve",
                        "twoPressureValve",
                      ].includes(t)
                    ? "Check and logic valves"
                    : "Other valves"
          : "Actuators" === r
            ? ["cylinderDA", "cylinderSA"].includes(t)
              ? "Linear actuators / cylinders"
              : ["hydraulicMotor", "pneumaticMotor"].includes(t)
                ? "Rotary actuators / motors"
                : ["vacuumEjector", "suctionCup", "airBlowNozzle"].includes(t)
                  ? "Vacuum and air actuators"
                  : ["hydraulicIntensifier"].includes(t)
                    ? "Converters / intensifiers"
                    : "Other actuators"
            : "Conditioning" === r
              ? ["filter", "suctionStrainer", "frlUnit"].includes(t)
                ? "Filtration and air/oil preparation"
                : ["cooler", "oilHeater"].includes(t)
                  ? "Thermal conditioning"
                  : ["breatherFiller", "silencer"].includes(t)
                    ? "Accessories and exhaust"
                    : "Conditioning accessories"
              : "Measurement" === r
                ? ["pressureGauge", "flowMeter"].includes(t)
                  ? "Gauges and meters"
                  : [
                        "pressureSwitch",
                        "pressureTransducer",
                        "flowSwitch",
                        "temperatureSwitch",
                        "levelSwitch",
                      ].includes(t)
                    ? "Switches and transducers"
                    : ["testPoint"].includes(t)
                      ? "Diagnostics"
                      : "Measurement"
                : "Control" === r
                  ? [
                      "pushButton",
                      "solenoid",
                      "plc",
                      "electricalRelay",
                      "relayContact",
                      "timerRelay",
                      "emergencyStop",
                    ].includes(t)
                    ? "Electrical controls"
                    : [
                          "limitSwitch",
                          "cylinderReedSensor",
                          "linearPositionSensor",
                          "proximitySensor",
                        ].includes(t)
                      ? "Feedback sensors"
                      : [
                            "proportionalAmplifier",
                            "setpointPotentiometer",
                            "rampGenerator",
                          ].includes(t)
                        ? "Proportional control electronics"
                        : "Control elements"
                  : "Lines" === r
                    ? "Lines, junctions and connections"
                    : "Annotations" === r
                      ? "Text and notes"
                      : r;
  }

  const RgzIsoDraw = (function () {
    const D = (g, c, d, x) => g.append($("path", Object.assign({ class: c, d: d }, x || {})));
    const ST = (g, d) => D(g, "symbol-stroke", d);
    const MU = (g, d) => D(g, "symbol-muted", d);
    const AC = (g, d) => D(g, "symbol-accent", d);
    const DA = (g, d) => D(g, "symbol-muted", d, { "stroke-dasharray": "6 5" });
    const SL = (g, d) => D(g, "symbol-solid", d);
    const TRI = ST;
    const CI = (g, cx, cy, r, c) => g.append($("circle", { class: c || "symbol-fill", cx: cx, cy: cy, r: r }));
    const RC = (g, x, y, w, h, c, rx) => g.append($("rect", { class: c || "symbol-fill", x: x, y: y, width: w, height: h, rx: rx || 0 }));
    const TX = (g, t2, x, y, s) => g.append($("text", { class: "port-label", x: x, y: y, "text-anchor": "middle", "font-size": s || 12 }, t2));
    const ENV = (g, w, h) => D(g, "symbol-muted", "M" + (-w / 2) + " " + (-h / 2) + " H" + (w / 2) + " V" + (h / 2) + " H" + (-w / 2) + " Z", { "stroke-dasharray": "7 5" });
    const N = (v, d) => (Number.isFinite(Number(v)) ? Number(v) : d);
    const C01 = (v) => Math.max(0, Math.min(1, v));
    const SPR = (g, x1, y1, x2, y2, n, amp) => {
      n = n || 3; amp = amp || 6;
      const dx = x2 - x1, dy = y2 - y1, len = Math.hypot(dx, dy) || 1, ux = dx / len, uy = dy / len, px = -uy, py = ux;
      const lead = len * 0.12, bx = x1 + ux * lead, by = y1 + uy * lead, bl = len - 2 * lead, ex = x2 - ux * lead, ey = y2 - uy * lead;
      let d = "M" + x1 + " " + y1 + " L" + bx.toFixed(1) + " " + by.toFixed(1);
      for (let i = 1; i < 2 * n; i++) {
        const t = i / (2 * n), ax = bx + ux * bl * t, ay = by + uy * bl * t, s = i % 2 ? 1 : -1;
        d += " L" + (ax + s * px * amp).toFixed(1) + " " + (ay + s * py * amp).toFixed(1);
      }
      d += " L" + ex.toFixed(1) + " " + ey.toFixed(1) + " L" + x2 + " " + y2;
      D(g, "symbol-muted", d);
    };
    const ARR = (g, x1, y1, x2, y2, c, hgt) => {
      c = c || "symbol-accent"; hgt = hgt || 8;
      const a = Math.atan2(y2 - y1, x2 - x1), a1 = a + 2.55, a2 = a - 2.55;
      D(g, c, "M" + x1 + " " + y1 + " L" + x2 + " " + y2 + " M" + (x2 + hgt * Math.cos(a1)).toFixed(1) + " " + (y2 + hgt * Math.sin(a1)).toFixed(1) + " L" + x2 + " " + y2 + " L" + (x2 + hgt * Math.cos(a2)).toFixed(1) + " " + (y2 + hgt * Math.sin(a2)).toFixed(1));
    };
    return function (g, c, td) {
      const P = c.props || {};
      switch (c.type) {

      case "tank":
        ST(g, "M-40 -30 v44 h80 v-44");
        return true;
      case "pumpFixed":
        CI(g, 0, 0, 32);
        ST(g, "M-58 0h26M32 0h26");
        TRI(g, "M-8 -15 L-8 15 L17 0 Z");
        return true;
      case "pumpVariable":
        CI(g, 0, 0, 32);
        ST(g, "M-62 0h30M32 0h30");
        TRI(g, "M-8 -15 L-8 15 L17 0 Z");
        AC(g, "M-34 34 L34 -34 M21 -34h13v13");
        ST(g, "M14 -46 H40 V-30 H14 Z");
        AC(g, "M22 -33 L33 -42 M28.5 -42h4.5v4.5");
        DA(g, "M46 0 V-38 H40");
        return true;
      case "compressorFixed":
        CI(g, 0, 0, 32);
        ST(g, "M-58 0h26M32 0h26");
        TRI(g, "M-8 -15 L-8 15 L17 0 Z");
        return true;
      case "compressorVariable":
        CI(g, 0, 0, 32);
        ST(g, "M-62 0h30M32 0h30");
        TRI(g, "M-8 -15 L-8 15 L17 0 Z");
        AC(g, "M-34 34 L34 -34 M21 -34h13v13");
        ST(g, "M14 -46 H40 V-30 H14 Z");
        AC(g, "M22 -33 L33 -42 M28.5 -42h4.5v4.5");
        DA(g, "M46 0 V-38 H40");
        return true;
      case "powerPack":
        RC(g, -72, -45, 144, 90, "symbol-fill", 8);
        TX(g, "POWER PACK", 0, -28, 13);
        CI(g, -42, -4, 15);
        TRI(g, "M-46 3 L-46 -11 L-34 -4 Z");
        ST(g, "M-56 10 v18 h28 v-18");
        RC(g, -14, -14, 24, 24);
        AC(g, "M-8 6 L6 -10 M-1 -10h7v7");
        SPR(g, 10, 0, 24, 0, 3, 5);
        P.pressureGauge && (CI(g, 44, -8, 12, "symbol-muted"), MU(g, "M44 -8 l8 -8"));
        ST(g, "M36 -22h46M36 30h46");
        TX(g, "P", 57, -30);
        TX(g, "T", 57, 20);
        return true;
      case "reliefValve":
        RC(g, -22, -24, 44, 48);
        ST(g, "M-58 0h36M22 0h36");
        AC(g, "M-10 14 L10 -14 M2 -14h8v8");
        SPR(g, 22, 0, 38, 0, 3, 6);
        AC(g, "M24 10 L40 -10 M33 -10h7v7");
        DA(g, "M-44 0 V14 H-22");
        return true;
      case "sequenceValve":
        RC(g, -22, -24, 44, 48);
        ST(g, "M-58 0h36M22 0h36");
        AC(g, "M-10 14 L10 -14 M2 -14h8v8");
        SPR(g, 22, 0, 38, 0, 3, 6);
        AC(g, "M24 10 L40 -10 M33 -10h7v7");
        DA(g, "M-44 0 V14 H-22");
        DA(g, "M0 24 V46");
        return true;
      case "reducingValve":
        RC(g, -22, -24, 44, 48);
        ST(g, "M-58 0h36M22 0h36");
        AC(g, "M-14 0 H8 M8 -6 L18 0 L8 6");
        SPR(g, 22, 0, 38, 0, 3, 6);
        AC(g, "M24 10 L40 -10 M33 -10h7v7");
        DA(g, "M44 0 V20 H-10 V24");
        DA(g, "M0 24 V46");
        return true;
      case "counterbalanceValve":
        RC(g, -22, -24, 44, 48);
        ST(g, "M-60 0h38M22 0h38");
        AC(g, "M-10 14 L10 -14 M2 -14h8v8");
        SPR(g, 22, 0, 38, 0, 3, 6);
        AC(g, "M24 10 L40 -10 M33 -10h7v7");
        DA(g, "M0 -48 V-24");
        MU(g, "M-40 0 V34 H40 V0");
        ST(g, "M12 28 L12 40 L0 34 Z M-4 28 V40");
        return true;
      case "pressureCompensator":
        RC(g, -20, -22, 40, 44);
        ST(g, "M-56 0h36M20 0h36");
        AC(g, "M-12 0 H8 M8 -6 L18 0 L8 6");
        SPR(g, 20, 0, 34, 0, 3, 6);
        DA(g, "M-42 0 V14 H-20");
        TX(g, "\u0394p", 0, 34, 12);
        return true;
      case "flowControl":
        ST(g, "M-54 0h34M20 0h34");
        ST(g, "M-20 -16 Q-7 0 -20 16 M20 -16 Q7 0 20 16");
        AC(g, "M-32 26 L32 -26 M19 -26h13v13");
        P.pressureCompensated && MU(g, "M-10 30 q5 7 10 0 q5 -7 10 0");
        return true;
      case "checkValve":
        ST(g, "M-50 0h30M24 0h26");
        ST(g, "M-16 -18v36L18 0Z M21 -21v42");
        SPR(g, 2, -22, 2, -38, 3, 5);
        return true;
      case "pilotCheckValve":
        ST(g, "M-58 0h38M24 0h34");
        ST(g, "M-16 -18v36L18 0Z M21 -21v42");
        SPR(g, 2, -22, 2, -38, 3, 5);
        DA(g, "M0 -44 V-27");
        RC(g, -9, -27, 18, 5, "symbol-stroke");
        return true;
      case "shutoffValve":
        ST(g, "M-52 0h30M22 0h30");
        ST(g, "M-22 -14 L-22 14 L0 0 Z M22 -14 L22 14 L0 0 Z");
        return true;
      case "cylinderDA": {
        const r = C01(N(P.simPosition, 0.25)), n = 64 * r - 52, a = n + 126;
        RC(g, -78, -20, 110, 40);
        RC(g, n - 2, -20, 10, 40, "symbol-solid");
        ST(g, "M" + (n + 8).toFixed(1) + " 0 H" + a.toFixed(1));
        MU(g, "M" + a.toFixed(1) + " -12v24");
        ST(g, "M-82 34v-14M22 34v-14");
        return true;
      }
      case "cylinderSA": {
        const r = C01(N(P.simPosition, 0.15)), n = 52 * r - 48, a = n + 110;
        RC(g, -72, -20, 96, 40);
        RC(g, n - 2, -20, 10, 40, "symbol-solid");
        ST(g, "M" + (n + 8).toFixed(1) + " 0 H" + a.toFixed(1));
        MU(g, "M" + a.toFixed(1) + " -12v24");
        SPR(g, n + 14, 0, 18, 0, 3, 7);
        ST(g, "M-76 34v-14");
        return true;
      }
      case "hydraulicMotor": {
        const an = N(P.simAngle, 0);
        CI(g, 0, 0, 32);
        ST(g, "M-58 0h26M32 0h26");
        TRI(g, "M-24 -13 L-24 13 L-6 0 Z");
        AC(g, "M0 0 L" + (18 * Math.cos(an)).toFixed(1) + " " + (18 * Math.sin(an)).toFixed(1) + " M0 0 L" + (18 * Math.cos(an + Math.PI)).toFixed(1) + " " + (18 * Math.sin(an + Math.PI)).toFixed(1));
        return true;
      }
      case "pneumaticMotor": {
        const an = N(P.simAngle, 0);
        CI(g, 0, 0, 32);
        ST(g, "M-58 0h26M32 0h26");
        TRI(g, "M-24 -13 L-24 13 L-6 0 Z");
        AC(g, "M0 0 L" + (18 * Math.cos(an)).toFixed(1) + " " + (18 * Math.sin(an)).toFixed(1) + " M0 0 L" + (18 * Math.cos(an + Math.PI)).toFixed(1) + " " + (18 * Math.sin(an + Math.PI)).toFixed(1));
        return true;
      }
      case "accumulator":
        CI(g, 0, -8, 30);
        MU(g, "M-25 -10 Q0 8 25 -10");
        ST(g, "M0 22 V52");
        CI(g, 0, -38, 2.5, "symbol-solid");
        return true;
      case "flowDivider":
        RC(g, -36, -28, 72, 56);
        ST(g, "M-56 -10h20M36 -10h20M0 50V28");
        AC(g, "M0 22 V0 M0 0 L-18 -16 M-18 -16 L-24 -9 M-18 -16 L-11 -14 M0 0 L18 -16 M18 -16 L24 -9 M18 -16 L11 -14");
        return true;
      case "flowMeter":
        CI(g, 0, 0, 24);
        ST(g, "M-54 0h30M24 0h30");
        ST(g, "M-8 -12 Q16 0 -8 12 M-8 -12 Q-2 0 -8 12");
        return true;
      case "flowSwitch":
        CI(g, 0, 0, 22);
        ST(g, "M-58 0h36M22 0h36");
        ST(g, "M-7 -11 Q14 0 -7 11 M-7 -11 Q-2 0 -7 11");
        ST(g, "M0 -22 V-42");
        return true;
      case "filter":
        ST(g, "M-52 0h22M30 0h22");
        D(g, "symbol-fill", "M-30 0 L0 -26 L30 0 L0 26 Z");
        DA(g, "M0 -26 V26");
        return true;
      case "suctionStrainer":
        ST(g, "M-52 0h28M24 0h28");
        D(g, "symbol-fill", "M-24 0 L0 -22 L24 0 L0 22 Z");
        DA(g, "M0 -22 V22");
        return true;
      case "cooler":
        RC(g, -24, -24, 48, 48);
        ST(g, "M-56 0h32M24 0h32");
        ST(g, "M-24 0 H24");
        ST(g, "M-8 8 V-32 M-13 -25 L-8 -33 L-3 -25 M8 8 V-32 M3 -25 L8 -33 L13 -25");
        return true;
      case "oilHeater":
        RC(g, -24, -24, 48, 48);
        ST(g, "M-52 0h28M24 0h28");
        ST(g, "M-24 0 H24");
        ST(g, "M-8 26 V2 M-14 9 L-8 1 L-2 9 M8 26 V2 M2 9 L8 1 L14 9");
        return true;
      case "breatherFiller":
        ST(g, "M0 36 V6");
        RC(g, -16, -22, 32, 28);
        DA(g, "M-10 -14h20");
        DA(g, "M-10 -6h20");
        DA(g, "M-10 2h20");
        return true;
      case "blindPlug":
        ST(g, "M-26 0h16");
        RC(g, -10, -12, 16, 24);
        ST(g, "M-10 -12 L6 12 M6 -12 L-10 12");
        return true;
      case "junction":
        CI(g, 0, 0, 5, "symbol-solid");
        ST(g, "M-26 0h21M5 0h21M0 -26v21M0 5v21");
        return true;
      case "pressureGauge":
        CI(g, 0, -6, 26);
        ST(g, "M0 46 V20");
        ARR(g, 0, -6, 15, -21);
        return true;
      case "pressureSwitch":
        CI(g, 0, -4, 24);
        ST(g, "M0 46 V20");
        ARR(g, 0, -4, 13, -18);
        MU(g, "M22 -24h8");
        ST(g, "M30 -24 L43 -30");
        MU(g, "M43 -24h7");
        ST(g, "M26 -21v-6M46 -21v-6");
        DA(g, "M16 -8 L26 -24");
        return true;
      case "pressureTransducer":
        CI(g, 0, -4, 24);
        ST(g, "M0 46 V20");
        ARR(g, 0, -4, 13, -18);
        ST(g, "M23 -10 L52 -18");
        return true;
      case "temperatureSwitch":
        CI(g, 0, -6, 22);
        ST(g, "M0 44 V16");
        CI(g, 0, 16, 4, "symbol-solid");
        ARR(g, 0, -6, 12, -20);
        MU(g, "M22 -18h8");
        ST(g, "M30 -18 L43 -24");
        MU(g, "M43 -18h7");
        ST(g, "M26 -15v-6M46 -15v-6");
        DA(g, "M15 -12 L26 -18");
        return true;
      case "levelSwitch":
        MU(g, "M-52 0h20M32 0h20");
        ST(g, "M-32 0 L14 -14");
        CI(g, 21, -16, 7, "symbol-stroke");
        MU(g, "M-36 -5v10");
        return true;

      case "exhaust":
        ST(g, "M0 -42 V-12");
        ST(g, "M-12 -12 H12 L0 6 Z");
        return true;
      case "silencer":
        ST(g, "M-40 0h14");
        SL(g, "M-12 -13 L-12 13 L-26 0 Z");
        return true;
      case "quickExhaustValve":
        RC(g, -32, -30, 64, 60, "symbol-fill", 4);
        ST(g, "M-56 0h24M32 -18h24M32 18h24");
        ST(g, "M-32 0 H-18");
        ST(g, "M-18 12 Q0 -12 18 12");
        ST(g, "M18 -6 V-18 H32");
        ST(g, "M0 12 V18 H32");
        return true;
      case "shuttleValve":
        RC(g, -36, -28, 72, 56);
        ST(g, "M-54 -18h18M-54 18h18M36 0h18");
        ST(g, "M-36 -18 H-22 M-36 18 H-22");
        ST(g, "M-22 -14 L-8 0 L-22 14");
        CI(g, -2, 0, 5, "symbol-stroke");
        ST(g, "M3 0 H36");
        TX(g, "OR", 0, -20, 10);
        return true;
      case "twoPressureValve":
        RC(g, -36, -28, 72, 56);
        ST(g, "M-54 -18h18M-54 18h18M36 0h18");
        ST(g, "M-36 -18 H-22 M-36 18 H-22");
        ST(g, "M-22 -14 L-8 0 L-22 14");
        ST(g, "M22 -14 L8 0 L22 14");
        ST(g, "M22 0 H36");
        MU(g, "M-8 0 H8");
        TX(g, "AND", 0, -20, 10);
        return true;
      case "vacuumEjector":
        RC(g, -34, -28, 68, 56);
        ST(g, "M-60 0h26M34 -18h26M34 18h26");
        ST(g, "M-24 -8 L-6 -2 V2 L-24 8 Z");
        ST(g, "M2 -4 L22 -10 V10 L2 4 Z");
        ST(g, "M-2 0 V-18 H34");
        ST(g, "M22 6 V18 H34");
        return true;
      case "suctionCup":
        ST(g, "M-44 0 H-20 V-18 H0");
        ST(g, "M-16 -2 Q-16 -18 0 -18 Q16 -18 16 -2 Q18 12 24 16 H-24 Q-18 12 -16 -2 Z");
        MU(g, "M-24 16 V20 H24 V16");
        return true;
      case "airBlowNozzle":
        ST(g, "M-44 0h20");
        ST(g, "M-24 -10 L-4 -3 V3 L-24 10 Z");
        ST(g, "M6 0h16 M8 -5l12 -4 M8 5l12 4");
        return true;
      case "frlUnit":
        RC(g, -62, -36, 124, 72, "symbol-fill", 6);
        ST(g, "M-66 0h4M62 0h4");
        MU(g, "M-62 0 H62");
        MU(g, "M-46 4 V26 H-26 V4");
        MU(g, "M-46 16 H-26");
        DA(g, "M-36 0 V-12");
        RC(g, -11, -13, 22, 26);
        AC(g, "M-6 0 H2 M2 -4 L7 0 L2 4");
        SPR(g, 11, 0, 22, 0, 3, 4);
        DA(g, "M2 13 V19 H-4");
        CI(g, 0, -24, 8, "symbol-muted");
        MU(g, "M0 -24 l5 -5");
        DA(g, "M0 -16 V-13");
        P.lubricator && (MU(g, "M26 4 V26 H46 V4"), MU(g, "M36 8 l-3 6 q0 4 3 4 q3 0 3 -4 Z"));
        TX(g, "F", -36, 33, 10);
        TX(g, "R", 0, 33, 10);
        P.lubricator && TX(g, "L", 36, 33, 10);
        return true;
      case "softStartValve":
        RC(g, -32, -30, 64, 62);
        ST(g, "M-58 0h26M32 -18h26M32 18h26");
        ST(g, "M-32 0 H-12");
        ST(g, "M-10 -14 Q-4 0 -10 14 M10 -14 Q4 0 10 14");
        AC(g, "M-20 16 L20 -18 M10 -18h10v10");
        ST(g, "M12 0 H22 V-18 H32");
        ST(g, "M4 14 V26 H24 V18 H32");
        return true;
      case "pneumaticTimeDelayValve":
        RC(g, -28, -18, 56, 36);
        ST(g, "M0 -18 V36");
        AC(g, "M-22 0 H-6 M-11 -5 L-3 0 L-11 5");
        ST(g, "M6 0 h8 M4 -5 V5");
        ST(g, "M22 2 V12 H8 V18 H0 V42");
        ST(g, "M-62 0h34");
        ST(g, "M28 0h34");
        SPR(g, 20, 22, 20, 34, 3, 4);
        DA(g, "M-40 0 V30 H-16");
        ST(g, "M-16 24 Q-9 30 -16 36 M-4 24 Q-11 30 -4 36");
        DA(g, "M-4 30 H6");
        CI(g, 13, 30, 7, "symbol-muted");
        DA(g, "M-10 22 V6 H-28");
        TX(g, "t", 26, 33, 11);
        return true;
      case "compressedAirDistributor":
        RC(g, -40, -34, 16, 68);
        ST(g, "M-64 0h40");
        ST(g, "M-24 -28h88M-24 0h88M-24 28h88");
        return true;

      }
      return false;
    };
  })();

  function O() {
    const e = u.search.trim().toLowerCase();
    ((f.innerHTML = ""),
      a.forEach((t) => {
        const r = i
          .filter((e) => e.category === t)
          .filter(
            (t) =>
              !e ||
              `${t.name} ${t.desc} ${t.type} ${N(t)}`.toLowerCase().includes(e),
          );
        if (!r.length) return;
        const n = document.createElement("details");
        ((n.className = "rgz-category"),
          (n.open = !!e),
          (n.innerHTML = `<summary>${z(t)} <span class="rgz-subcount">${r.length}</span></summary><div class="rgz-subcategory-wrap"></div>`));
        const a = n.querySelector(".rgz-subcategory-wrap"),
          o = new Map();
        (r.forEach((e) => {
          const t = N(e);
          (o.has(t) || o.set(t, []), o.get(t).push(e));
        }),
          o.forEach((t, r) => {
            const n = document.createElement("details");
            ((n.className = "rgz-subcategory"),
              (n.open = !!e),
              (n.innerHTML = `<summary>${z(r)} <span class="rgz-subcount">${t.length}</span></summary><div class="rgz-symbol-list"></div>`));
            const i = n.querySelector(".rgz-symbol-list");
            (t.forEach((e) =>
              i.appendChild(
                (function (e) {
                  const t = document.createElement("div");
                  return (
                    (t.className = "rgz-symbol-card"),
                    (t.draggable = !0),
                    (t.dataset.type = e.type),
                    (t.innerHTML = `\n      <div class="rgz-symbol-icon">${(function (
                      e,
                    ) {
                      const t =
                        'stroke="#f8fafc" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"';
                      if (C(e))
                        return `<svg viewBox="-78 -46 156 92"><rect ${t} x="-54" y="-25" width="108" height="50"/><path ${t} d="M-18-25v50M18-25v50M-43 12L-23-12M-28-12h8v8M-8 0h16M23-12L43 12M38-12h8v8"/></svg>`;
                      switch (e) {
                        case "powerPack":
                          return `<svg viewBox="-80 -50 160 100"><rect ${t} x="-56" y="-34" width="112" height="68" rx="7"/><circle ${t} cx="-24" cy="0" r="16"/><path ${t} d="M-29 8L-14 0-29-8M8-16v32M20-16v32M-56 26h112"/></svg>`;
                        case "exhaust":
                          return `<svg viewBox="-60 -44 120 88"><path ${t} d="M0 -26 V-2 M-12 -2 H12 L0 14 Z"/></svg>`;
                        case "compressorFixed":
                          return `<svg viewBox="-60 -40 120 80"><circle ${t} cx="0" cy="0" r="25"/><path ${t} d="M-50 0h25M25 0h50M-7 -11 L-7 11 L13 0 Z"/></svg>`;
                        case "directionalValve":
                          return `<svg viewBox="-70 -44 140 88"><rect ${t} x="-48" y="-25" width="96" height="50"/><path ${t} d="M-16-25v50M16-25v50M-38 8h24l-8-8M-8-8h24l-8 8M18 8h24l-8-8"/></svg>`;
                        case "cylinderDA":
                          return `<svg viewBox="-80 -40 160 80"><rect ${t} x="-62" y="-16" width="86" height="32"/><rect x="-30" y="-16" width="9" height="32" fill="#f8fafc" stroke="none"/><path ${t} d="M-21 0h65 M44 -8v16 M-42 16v14M16 16v14"/></svg>`;
                        case "cylinderSA":
                          return `<svg viewBox="-80 -40 160 80"><rect ${t} x="-58" y="-16" width="78" height="32"/><rect x="-36" y="-16" width="9" height="32" fill="#f8fafc" stroke="none"/><path ${t} d="M-27 0h53 M-14 0 l3 -6 l3 12 l3 -12 l3 6 M-38 16v14"/></svg>`;
                        case "pressureGauge":
                          return `<svg viewBox="-50 -45 100 90"><circle ${t} cx="0" cy="-5" r="27"/><path ${t} d="M0 22v22 M-6 5 L14 -18 M14 -18 L7 -17 M14 -18 L13 -11"/></svg>`;
                        case "filter":
                          return `<svg viewBox="-60 -40 120 80"><path ${t} d="M-50 0h20M30 0h20M-30 0 L0 -25 L30 0 L0 25 Z"/><path ${t} d="M0 -25 V25" stroke-dasharray="5 4"/></svg>`;
                        case "reliefValve":
                          return `<svg viewBox="-65 -40 130 80"><rect ${t} x="-20" y="-22" width="40" height="44"/><path ${t} d="M-56 0h36M20 0h36 M-9 11 L9 -11 M3 -11h6v6 M20 0 l4 -6 l4 12 l4 -12 l4 6"/><path ${t} d="M-44 0 V12 H-20" stroke-dasharray="5 4"/></svg>`;
                        case "flowControl":
                          return `<svg viewBox="-60 -40 120 80"><path ${t} d="M-52 0h32M20 0h32 M-20 -15 Q-7 0 -20 15 M20 -15 Q7 0 20 15 M-28 22 L28 -22 M18 -22h10v10"/></svg>`;
                        case "checkValve":
                          return `<svg viewBox="-60 -40 120 80"><path ${t} d="M-50 0h30M24 0h26 M-16 -18v36L18 0Z M21 -21v42"/><path ${t} d="M2 -21 l3 -5 l3 8 l3 -8 l3 5"/></svg>`;
                        case "pneumaticMotor":
                          return `<svg viewBox="-60 -40 120 80"><circle ${t} cx="0" cy="0" r="25"/><path ${t} d="M-55 0h30M25 0h30M-20 -11 L-20 11 L-5 0 Z"/></svg>`;
                        case "pushButton":
                          return `<svg viewBox="-60 -40 120 80"><path ${t} d="M-50 0h26M22 0h28M-22-18v36M-22 0l32-18"/><circle ${t} cx="12" cy="-22" r="7"/></svg>`;
                        case "textLabel":
                          return `<svg viewBox="-70 -42 140 84"><rect ${t} x="-48" y="-25" width="96" height="50" rx="6"/><path ${t} d="M-30 -6h60M-30 10h42"/><text x="0" y="-10" fill="#f8fafc" font-size="18" font-weight="800" text-anchor="middle">T</text></svg>`;
                                                case "silencer":
                          return `<svg viewBox="-56 -40 112 80"><path ${t} d="M-40 0h16"/><path d="M-10 -13 L-10 13 L-26 0 Z" fill="#f8fafc" stroke="none"/></svg>`;
                        case "accumulator":
                          return `<svg viewBox="-50 -50 100 100"><circle ${t} cx="0" cy="-6" r="27"/><path ${t} d="M-21 -12 Q0 4 21 -12 M0 21 V44"/></svg>`;
                        case "cooler":
                          return `<svg viewBox="-60 -44 120 88"><rect ${t} x="-22" y="-22" width="44" height="44"/><path ${t} d="M-48 0h26M22 0h26M-22 0H22 M-7 6 V-28 M-12 -21 L-7 -29 L-2 -21 M7 6 V-28 M2 -21 L7 -29 L12 -21"/></svg>`;
                        case "shuttleValve":
                          return `<svg viewBox="-58 -40 116 80"><rect ${t} x="-32" y="-24" width="60" height="48"/><path ${t} d="M-50 -16h18M-50 16h18M28 0h22 M-32 -16 H-22 M-32 16 H-22 M-22 -13 L-8 0 L-22 13"/><circle ${t} cx="-2" cy="0" r="5"/><path ${t} d="M3 0 H28"/></svg>`;
                        case "twoPressureValve":
                          return `<svg viewBox="-58 -40 116 80"><rect ${t} x="-32" y="-24" width="60" height="48"/><path ${t} d="M-50 -16h18M-50 16h18M28 0h22 M-32 -16 H-22 M-32 16 H-22 M-22 -13 L-8 0 L-22 13 M22 -13 L8 0 L22 13 M22 0 H28 M-8 0 H8"/></svg>`;
                        case "quickExhaustValve":
                          return `<svg viewBox="-60 -40 120 80"><rect ${t} x="-30" y="-26" width="56" height="52" rx="4"/><path ${t} d="M-52 0h22 M26 -16h24 M26 16h24 M-30 0 H-18 M-18 10 Q-4 -10 10 10 M10 -4 V-16 H26 M-4 10 V16 H26"/></svg>`;
                        case "vacuumEjector":
                          return `<svg viewBox="-64 -40 128 80"><rect ${t} x="-32" y="-24" width="62" height="48"/><path ${t} d="M-56 0h24 M30 -14h26 M30 14h26 M-24 -8 L-6 -2 V2 L-24 8 Z M2 -4 L22 -10 V10 L2 4 Z M-2 0 V-14 H30 M22 6 V14 H30"/></svg>`;
                        case "suctionCup":
                          return `<svg viewBox="-56 -40 112 80"><path ${t} d="M-42 0 H-18 V-12 H0 M-13 0 Q-13 -14 0 -14 Q13 -14 13 0 Q15 12 20 16 H-20 Q-15 12 -13 0 Z M-20 16 V20 H20 V16"/></svg>`;
                        case "airBlowNozzle":
                          return `<svg viewBox="-52 -40 104 80"><path ${t} d="M-40 0h16 M-24 -10 L-4 -3 V3 L-24 10 Z M4 0h16 M6 -5l12 -4 M6 5l12 4"/></svg>`;
                        case "frlUnit":
                          return `<svg viewBox="-70 -40 140 80"><rect ${t} x="-58" y="-30" width="116" height="60" rx="6"/><path ${t} d="M-66 0h8M58 0h8 M-44 2 V24 H-28 V2 M-44 14 H-28"/><path ${t} d="M-36 2 V-10" stroke-dasharray="4 3"/><rect ${t} x="-11" y="-11" width="22" height="24"/><path ${t} d="M-5 1 H3 M3 -3 L8 1 L3 5 M11 1 l3 -4 l3 8 l3 -8 l3 4"/><circle ${t} cx="0" cy="-20" r="7"/><path ${t} d="M0 -20 l4 -4"/></svg>`;
                        case "softStartValve":
                          return `<svg viewBox="-62 -40 124 80"><rect ${t} x="-28" y="-26" width="56" height="54"/><path ${t} d="M-52 0h24 M28 -14h24 M28 16h24 M-28 0 H-12 M-10 -12 Q-4 0 -10 12 M10 -12 Q4 0 10 12 M-18 14 L16 -14 M8 -14h8v8 M12 0 H20 V-14 H28 M4 12 V22 H22 V16 H28"/></svg>`;
                        case "pilotCheckValve":
                          return `<svg viewBox="-64 -44 128 88"><path ${t} d="M-54 0h34M24 0h30 M-16 -18v36L18 0Z M21 -21v42"/><path ${t} d="M2 -21 l3 -5 l3 8 l3 -8 l3 5"/><path ${t} d="M0 -42 V-27" stroke-dasharray="5 4"/><rect ${t} x="-8" y="-27" width="16" height="5"/></svg>`;
                        case "counterbalanceValve":
                          return `<svg viewBox="-70 -48 140 96"><rect ${t} x="-20" y="-22" width="40" height="44"/><path ${t} d="M-60 0h40M20 0h40 M-9 11 L9 -11 M3 -11h6v6 M20 0 l4 -6 l4 12 l4 -12 l4 6"/><path ${t} d="M0 -46 V-22" stroke-dasharray="5 4"/><path ${t} d="M-38 0 V32 H38 V0 M0 26 L0 38 L12 32 Z M16 26 V38"/></svg>`;
                        case "shutoffValve":
                          return `<svg viewBox="-60 -40 120 80"><path ${t} d="M-52 0h30M22 0h30 M-22 -14 L-22 14 L0 0 Z M22 -14 L22 14 L0 0 Z"/></svg>`;
                        case "sequenceValve":
                          return `<svg viewBox="-65 -46 130 92"><rect ${t} x="-20" y="-22" width="40" height="44"/><path ${t} d="M-56 0h36M20 0h36 M-9 11 L9 -11 M3 -11h6v6 M20 0 l4 -6 l4 12 l4 -12 l4 6"/><path ${t} d="M-44 0 V12 H-20 M0 22 V44" stroke-dasharray="5 4"/></svg>`;
                        case "reducingValve":
                          return `<svg viewBox="-65 -46 130 92"><rect ${t} x="-20" y="-22" width="40" height="44"/><path ${t} d="M-56 0h36M20 0h36 M-12 0 H8 M8 -6 L18 0 L8 6 M20 0 l4 -6 l4 12 l4 -12 l4 6"/><path ${t} d="M40 0 V30 H-10 V22 M0 22 V44" stroke-dasharray="5 4"/></svg>`;
                        case "flowMeter":
                          return `<svg viewBox="-56 -40 112 80"><circle ${t} cx="0" cy="0" r="24"/><path ${t} d="M-54 0h30M24 0h30 M-8 -12 Q16 0 -8 12 M-8 -12 Q-2 0 -8 12"/></svg>`;
                        case "pneumaticTimeDelayValve":
                          return `<svg viewBox="-70 -46 140 92"><rect ${t} x="-24" y="-16" width="48" height="32"/><path ${t} d="M0 -16 V16 M-19 0 H-5 M-10 -5 L-2 0 L-10 5 M6 0 h8 M4 -5 V5 M-58 0h34 M24 0h34 M18 2 V10 H6 V16 H0 V38"/><path ${t} d="M-34 0 V26 H-14 M-14 21 Q-8 26 -14 31 M-4 21 Q-10 26 -4 31"/><circle ${t} cx="10" cy="26" r="6"/><path ${t} d="M-4 26 H4"/></svg>`;
                        case "compressedAirDistributor":
                          return `<svg viewBox="-68 -40 136 80"><rect ${t} x="-36" y="-30" width="14" height="60"/><path ${t} d="M-58 0h36 M-22 -24 H58 M-22 0 H58 M-22 24 H58"/></svg>`;
default:
                          return `<svg viewBox="-60 -40 120 80"><rect ${t} x="-32" y="-22" width="64" height="44"/><path ${t} d="M-52 0h20M32 0h20"/></svg>`;
                      }
                    })(
                      e.type,
                    )}</div>\n      <div><div class="rgz-symbol-name">${z(e.name)}</div><div class="rgz-symbol-desc">${z(e.desc)}</div></div>\n    `),
                    t.addEventListener("dragstart", (t) => {
                      (t.dataTransfer.setData(
                        "application/rgz-component",
                        e.type,
                      ),
                        (t.dataTransfer.effectAllowed = "copy"));
                    }),
                    t.addEventListener("dblclick", () =>
                      U(
                        e.type,
                        u.viewBox.x + 0.5 * u.viewBox.w,
                        u.viewBox.y + 0.5 * u.viewBox.h,
                      ),
                    ),
                    t
                  );
                })(e),
              ),
            ),
              a.appendChild(n));
          }),
          f.appendChild(n));
      }));
  }
  function U(e, t, r) {
    const n = V(e, t, r);
    (u.components.push(n),
      (u.selected = { kind: "component", id: n.id }),
      H(),
      Me(),
      ct(`${L(e).name} added.`, "ok"));
  }
  function H() {
    ((g.innerHTML = ""),
      (h.innerHTML = ""),
      (y.innerHTML = ""),
      (function () {
        if (!u.printArea || !g) return;
        const e = u.printArea;
        (g.appendChild(
          $("rect", {
            class: "rgz-print-area-rect",
            x: e.x,
            y: e.y,
            width: e.w,
            height: e.h,
            rx: 10,
          }),
        ),
          g.appendChild(
            $(
              "text",
              { class: "rgz-print-area-label", x: e.x + 12, y: e.y + 24 },
              "PRINT AREA",
            ),
          ));
      })());
    const e = (function () {
      const e = new Set();
      if (!u.sim.running) return e;
      if (u.sim.metrics && Array.isArray(u.sim.metrics.lines))
        return (
          u.sim.metrics.lines.forEach((t) => {
            (t.high || P(t.pressureBar, 0) > 5) && e.add(t.id);
          }),
          e
        );
      if (P(u.sim.metrics?.pressureBar, 0) <= 1) return e;
      const t = new Map(),
        r = (e, r, n = null) => {
          e &&
            r &&
            (t.has(e) || t.set(e, []),
            t.has(r) || t.set(r, []),
            t.get(e).push({ node: r, connId: n }),
            t.get(r).push({ node: e, connId: n }));
        },
        n = (e, t) => `${e}.${t}`;
      u.connections.forEach((e) => {
        "electrical" !== e.lineType &&
          r(
            n(e.from.componentId, e.from.portId),
            n(e.to.componentId, e.to.portId),
            e.id,
          );
      });
      const a = [],
        i = (e, t) => t.forEach((t) => r(n(e.id, t[0]), n(e.id, t[1]), null));
      u.components.forEach((e) => {
        if (
          (("compressorFixed" !== e.type &&
            "compressorVariable" !== e.type &&
            "powerPack" !== e.type) ||
            a.push(n(e.id, "P")),
          C(e))
        ) {
          const t = e.props.spoolState || "center",
            r = e.props.center || "closed";
          ("left" === t && i(e, [["P", "A"]]),
            "right" === t && i(e, [["P", "B"]]),
            "center" === t &&
              "regenerative" === r &&
              i(e, [
                ["P", "A"],
                ["P", "B"],
              ]));
        }
        if (
          ([
            "flowControl",
            "checkValve",
            "pilotCheckValve",
            "counterbalanceValve",
            "flowMeter",
            "filter",
            "cooler",
            "frlUnit",
          ].includes(e.type) && i(e, [["A", "B"]]),
          "compressedAirDistributor" === e.type &&
            i(e, [
              ["P", "A"],
              ["P", "B"],
              ["P", "C"],
            ]),
          "valveTerminal" === e.type &&
            i(e, [
              ["P", "A1"],
              ["P", "B1"],
              ["P", "A2"],
              ["P", "B2"],
            ]),
          "pneumaticTimeDelayValve" === e.type && i(e, [["P", "A"]]),
          "pneumaticMemoryValve" === e.type &&
            i(e, [["P", "right" === e.props.spoolState ? "B" : "A"]]),
          ["quickExhaustValve", "softStartValve", "vacuumEjector"].includes(
            e.type,
          ) &&
            i(e, [
              ["P", "A"],
              ["P", "V"],
            ]),
          ["shuttleValve", "twoPressureValve"].includes(e.type) &&
            i(e, [
              ["A", "X"],
              ["B", "X"],
            ]),
          ["sequenceValve", "reducingValve"].includes(e.type) &&
            i(e, [["P", "A"]]),
          "junction" === e.type)
        ) {
          const t = T(e).map((e) => e.id);
          t.forEach((a, i) =>
            t.slice(i + 1).forEach((t) => r(n(e.id, a), n(e.id, t), null)),
          );
        }
        ("flowDivider" === e.type &&
          i(e, [
            ["P", "A"],
            ["P", "B"],
          ]),
          "accumulator" === e.type ||
            "pressureGauge" === e.type ||
            "pressureSwitch" === e.type ||
            e.type);
      });
      const o = new Set(a),
        s = [...a];
      for (; s.length;) {
        const r = s.shift();
        (t.get(r) || []).forEach((t) => {
          (t.connId && e.add(t.connId),
            o.has(t.node) || (o.add(t.node), s.push(t.node)));
        });
      }
      return e;
    })();
    (u.connections.forEach((t, r) =>
      h.appendChild(
        (function (e, t = 0, r = new Set()) {
          const n = E(e.from.componentId, e.from.portId),
            a = E(e.to.componentId, e.to.portId),
            i = $("g", { "data-id": e.id });
          if (!n || !a) return i;
          const o = (function (e, t, r = null, n = 0) {
              const a =
                  (function (e, t = 0) {
                    if (!e) return 0;
                    return (
                      ({
                        pressure: -1.5,
                        return: 1.5,
                        pilot: -3,
                        drain: 3,
                        electrical: -4,
                      }[e.lineType] ?? 0) +
                      (u.connections.filter(
                        (t) =>
                          t !== e &&
                          ((t.from.componentId === e.from.componentId &&
                            t.from.portId === e.from.portId) ||
                            (t.to.componentId === e.to.componentId &&
                              t.to.portId === e.to.portId) ||
                            (t.from.componentId === e.to.componentId &&
                              t.from.portId === e.to.portId) ||
                            (t.to.componentId === e.from.componentId &&
                              t.to.portId === e.from.portId)),
                      ).length
                        ? 0.45 * ((t % 5) - 2)
                        : 0)
                    );
                  })(r, n) +
                  P(r?.properties?.shift, 0) / 18,
                i = r?.properties?.routeMode || "auto",
                o = t.x - e.x,
                s = t.y - e.y;
              if ("straight" === i)
                return [
                  [e.x, e.y],
                  [t.x, t.y],
                ];
              const l = G(e, o, s),
                c = G(t, -o, -s),
                p = 28 + Math.min(24, 2 * Math.abs(a)),
                d = [e.x, e.y],
                m = [A(e.x + l.x * p, 2), A(e.y + l.y * p, 2)],
                g = [A(t.x + c.x * p, 2), A(t.y + c.y * p, 2)],
                h = Math.abs(g[0] - m[0]),
                y = Math.abs(g[1] - m[1]);
              let v;
              if ("horizontal-first" === i || ("auto" === i && h > y)) {
                const e = A((m[0] + g[0]) / 2 + 18 * a, 10);
                v = [d, m, [e, m[1]], [e, g[1]], g, [t.x, t.y]];
              } else {
                const e = A((m[1] + g[1]) / 2 + 18 * a, 10);
                v = [d, m, [m[0], e], [g[0], e], g, [t.x, t.y]];
              }
              return (function (e) {
                const t = [];
                e.forEach((e) => {
                  const r = t[t.length - 1];
                  (!r ||
                    Math.abs(r[0] - e[0]) > 0.1 ||
                    Math.abs(r[1] - e[1]) > 0.1) &&
                    t.push(e);
                });
                for (let e = t.length - 2; e > 0; e--) {
                  const r = t[e - 1],
                    n = t[e],
                    a = t[e + 1];
                  ((Math.abs(r[0] - n[0]) < 0.1 &&
                    Math.abs(n[0] - a[0]) < 0.1) ||
                    (Math.abs(r[1] - n[1]) < 0.1 &&
                      Math.abs(n[1] - a[1]) < 0.1)) &&
                    t.splice(e, 1);
                }
                return t;
              })(v);
            })(n, a, e, t),
            s = (function (e) {
              return e
                .map((e, t) => `${t ? "L" : "M"} ${e[0]} ${e[1]}`)
                .join(" ");
            })(o),
            l = ["rgz-connection-path", e.lineType || "pressure"];
          "connection" === u.selected?.kind &&
            u.selected.id === e.id &&
            l.push("selected");
          const c = r.has(e.id),
            lm =
              ((u.sim.metrics && u.sim.metrics.lines) || []).find(
                (t) => t.id === e.id,
              ) || null;
          (c && l.push("sim-pressure"),
            u.sim.running &&
              "electrical" !== e.lineType &&
              (lm ? lm.active : P(u.sim.metrics?.activeFlowLpm, 0) > 0.05) &&
              (l.push("sim-active"),
              (lm
                ? lm.high
                : (u.sim.metrics?.pressureBar || 0) >
                  0.8 *
                    (function () {
                      const e = u.components.filter(
                        (e) =>
                          "reliefValve" === e.type || "powerPack" === e.type,
                      );
                      return e.length
                        ? Math.min(
                            ...e.map((e) =>
                              P(
                                e.props.settingBar ?? e.props.reliefSettingBar,
                                6,
                              ),
                            ),
                          )
                        : 6;
                    })()) &&
                ("pressure" === e.lineType || "pilot" === e.lineType) &&
                l.push("sim-high")));
          const p = { d: s, class: l.join(" ") },
            d = [`stroke:${e.properties?.color || $e(e.lineType)}`];
          (d.push(
            `stroke-width:${c ? Math.max(P(e.properties?.strokeWidth, 3) + 3, 6) : e.properties?.strokeWidth || 3}`,
          ),
            (p.style = d.join(";")));
          const m = $("path", p);
          return (
            m.addEventListener("click", (t) => {
              (t.stopPropagation(),
                u.pendingPort
                  ? (function (e, t) {
                      if (!u.pendingPort) return;
                      if ("electrical" === e.lineType)
                        return void ct(
                          "Electrical line branching is not supported yet. Add a PLC or electrical junction block instead.",
                          "warning",
                        );
                      const r = M(u.pendingPort),
                        n = E(r.componentId, r.portId);
                      if (!n) return ((u.pendingPort = null), void H());
                      if ("electrical" === n.kind)
                        return (
                          ct(
                            "Electrical ports cannot be joined to fluid lines.",
                            "error",
                          ),
                          (u.pendingPort = null),
                          void H()
                        );
                      const a = j(t),
                        i = V("junction", a.x, a.y);
                      i.label = i.label || i.id.replace("-", "");
                      const o = M(e.properties || {});
                      (u.components.push(i),
                        (u.connections = u.connections.filter(
                          (t) => t.id !== e.id,
                        )),
                        u.connections.push(
                          q(
                            e.from.componentId,
                            e.from.portId,
                            i.id,
                            "A",
                            e.lineType,
                            Object.assign({}, o, { shift: P(o.shift, 0) - 8 }),
                          ),
                        ),
                        u.connections.push(
                          q(
                            i.id,
                            "B",
                            e.to.componentId,
                            e.to.portId,
                            e.lineType,
                            Object.assign({}, o, { shift: P(o.shift, 0) + 8 }),
                          ),
                        ),
                        u.connections.push(
                          q(
                            r.componentId,
                            r.portId,
                            i.id,
                            "C",
                            "pilot" === n.kind ? "pilot" : e.lineType,
                            Object.assign({}, o, { shift: P(o.shift, 0) + 24 }),
                          ),
                        ),
                        (u.pendingPort = null),
                        (u.selected = { kind: "component", id: i.id }),
                        H(),
                        Me(),
                        ct(
                          "Branch connection added. Move the junction dot to refine the drawing.",
                          "ok",
                        ));
                    })(e, t)
                  : ((u.selected = { kind: "connection", id: e.id }),
                    H(),
                    Me()));
            }),
            i.appendChild(m),
            i
          );
        })(t, r, e),
      ),
    ),
      u.components.forEach((e) =>
        y.appendChild(
          (function (e) {
            const t = L(e.type),
              r = $("g", {
                class: `rgz-component ${"component" === u.selected?.kind && u.selected.id === e.id ? "selected" : ""} ${Z(e) ? "sim-moving" : ""}`,
                transform: `translate(${e.x} ${e.y}) rotate(${e.rotation || 0})`,
                "data-id": e.id,
              });
            (r.addEventListener("pointerdown", (t) => {
              if (t.ctrlKey || t.metaKey)
                return (t.stopPropagation(), void F(t));
              if (t.target.classList.contains("port")) return;
              (t.stopPropagation(),
                (u.selected = { kind: "component", id: e.id }));
              const r = j(t);
              ((u.drag = {
                kind: "component",
                id: e.id,
                startPoint: r,
                startX: e.x,
                startY: e.y,
              }),
                H(),
                Me());
            }),
              r.addEventListener("click", (t) => {
                t.ctrlKey ||
                  t.metaKey ||
                  t.target.classList.contains("port") ||
                  (t.stopPropagation(),
                  (u.selected = { kind: "component", id: e.id }),
                  H(),
                  Me());
              }),
              r.addEventListener("dblclick", (t) => {
                (t.stopPropagation(), Pe(e.id));
              }),
              r.appendChild(
                $("rect", {
                  class: "selection-box",
                  x: -t.w / 2 - 12,
                  y: -t.h / 2 - 22,
                  width: t.w + 24,
                  height: t.h + 42,
                  rx: 12,
                }),
              ),
              (function (e, t, r) {
                if (C(t)) J(e, t);
                else if (RgzIsoDraw(e, t, r)) return;
                else
                  switch (t.type) {
                    case "powerPack":
                      !(function (e, t) {
                        (e.append(
                          $("rect", {
                            class: "symbol-fill",
                            x: -72,
                            y: -45,
                            width: 144,
                            height: 90,
                            rx: 8,
                          }),
                        ),
                          e.append(
                            $(
                              "text",
                              {
                                class: "port-label",
                                x: 0,
                                y: -28,
                                "text-anchor": "middle",
                              },
                              "POWER PACK",
                            ),
                          ),
                          e.append(
                            $("circle", {
                              class: "symbol-muted",
                              cx: -34,
                              cy: -4,
                              r: 18,
                            }),
                          ),
                          e.append(
                            $("path", {
                              class: "symbol-accent",
                              d: "M-40 6 L-22 -4 L-40 -14 Z",
                            }),
                          ),
                          e.append(
                            $("path", {
                              class: "symbol-muted",
                              d: "M-2 -24 v40 h38 v-40 M4 0 q8 6 16 0 t16 0",
                            }),
                          ),
                          e.append(
                            $("path", {
                              class: "symbol-stroke",
                              d: "M36 -22h46M36 30h46",
                            }),
                          ),
                          e.append(
                            $(
                              "text",
                              {
                                class: "port-label",
                                x: 57,
                                y: -30,
                                "text-anchor": "middle",
                              },
                              "P",
                            ),
                          ),
                          e.append(
                            $(
                              "text",
                              {
                                class: "port-label",
                                x: 57,
                                y: 20,
                                "text-anchor": "middle",
                              },
                              "T",
                            ),
                          ),
                          t.props.pressureGauge &&
                            (e.append(
                              $("circle", {
                                class: "symbol-muted",
                                cx: 38,
                                cy: -8,
                                r: 13,
                              }),
                            ),
                            e.append(
                              $("path", {
                                class: "symbol-muted",
                                d: "M38 -8 l8 -8",
                              }),
                            )));
                      })(e, t);
                      break;
                    case "exhaust":
                      !(function (e) {
                        (e.append(
                          $("path", {
                            class: "symbol-stroke",
                            d: "M-42 -16 v42 h84 v-42",
                          }),
                        ),
                          e.append(
                            $("path", {
                              class: "symbol-muted",
                              d: "M-30 8 q10 8 20 0 t20 0 t20 0",
                            }),
                          ),
                          e.append(
                            $("path", {
                              class: "symbol-muted",
                              d: "M-15 25h30M-25 34h50",
                            }),
                          ));
                      })(e);
                      break;
                    case "compressorFixed":
                      X(e, !1);
                      break;
                    case "compressorVariable":
                      X(e, !0);
                      break;
                    case "reliefValve":
                      !(function (e) {
                        (e.append(
                          $("rect", {
                            class: "symbol-fill",
                            x: -30,
                            y: -28,
                            width: 60,
                            height: 56,
                            rx: 4,
                          }),
                        ),
                          e.append(
                            $("path", {
                              class: "symbol-stroke",
                              d: "M-58 0h28M30 0h28",
                            }),
                          ),
                          e.append(
                            $("path", {
                              class: "symbol-accent",
                              d: "M-17 17 L18 -18 M5 -18h13v13",
                            }),
                          ),
                          e.append(
                            $("path", {
                              class: "symbol-muted",
                              d: "M26 20 c12 -10 12 -30 0 -40",
                            }),
                          ));
                      })(e);
                      break;
                    case "directionalValve":
                      J(e, t);
                      break;
                    case "flowControl":
                      te(e, t);
                      break;
                    case "checkValve":
                      re(e);
                      break;
                    case "pilotCheckValve":
                      ne(e);
                      break;
                    case "counterbalanceValve":
                      ae(e);
                      break;
                    case "sequenceValve":
                      ie(e, "SEQ");
                      break;
                    case "reducingValve":
                      ie(e, "RED");
                      break;
                    case "cylinderDA":
                      oe(e, t);
                      break;
                    case "cylinderSA":
                      se(e, t);
                      break;
                    case "pneumaticMotor":
                      le(e, t);
                      break;
                    case "accumulator":
                      ce(e);
                      break;
                    case "flowDivider":
                      pe(e);
                      break;
                    case "filter":
                      de(e);
                      break;
                    case "cooler":
                      ue(e);
                      break;
                    case "pressureGauge":
                      me(e);
                      break;
                    case "flowMeter":
                      ge(e);
                      break;
                    case "pressureSwitch":
                      !(function (e) {
                        (me(e),
                          e.append(
                            $("path", {
                              class: "symbol-muted",
                              d: "M28 -24 h22M40 -24v18M34 -6h14",
                            }),
                          ));
                      })(e);
                      break;
                    case "pressureTransducer":
                      !(function (e, t) {
                        (me(e),
                          e.append(
                            $(
                              "text",
                              {
                                class: "port-label",
                                x: 0,
                                y: 5,
                                "text-anchor": "middle",
                              },
                              "PT",
                            ),
                          ),
                          e.append(
                            $("path", {
                              class: he(t),
                              d: "M28 -18 h24M42 -18v18M34 0h16",
                            }),
                          ));
                      })(e, t);
                      break;
                    case "flowSwitch":
                      !(function (e, t) {
                        (e.append(
                          $("circle", {
                            class: "symbol-fill",
                            cx: 0,
                            cy: 0,
                            r: 28,
                          }),
                        ),
                          e.append(
                            $("path", {
                              class: "symbol-stroke",
                              d: "M-58 0h30M28 0h30M-10 12L14 0-10-12",
                            }),
                          ),
                          e.append(
                            $("path", {
                              class: he(t),
                              d: "M0 -42v18M-10 -32h20",
                            }),
                          ),
                          e.append(
                            $(
                              "text",
                              {
                                class: "port-label",
                                x: 0,
                                y: 5,
                                "text-anchor": "middle",
                              },
                              "FS",
                            ),
                          ));
                      })(e, t);
                      break;
                    case "temperatureSwitch":
                      !(function (e, t) {
                        (e.append(
                          $("circle", {
                            class: "symbol-fill",
                            cx: 0,
                            cy: -2,
                            r: 25,
                          }),
                        ),
                          e.append(
                            $("path", {
                              class: "symbol-stroke",
                              d: "M0 23v21M-8 8v-26a8 8 0 0 1 16 0v26a14 14 0 1 1 -16 0",
                            }),
                          ),
                          e.append(
                            $("path", {
                              class: he(t),
                              d: "M30 -18h20M42 -18v18M36 0h12",
                            }),
                          ));
                      })(e, t);
                      break;
                    case "levelSwitch":
                      !(function (e, t) {
                        (e.append(
                          $("path", {
                            class: "symbol-stroke",
                            d: "M-42 -20v42h84v-42M-30 0q10 7 20 0t20 0t20 0",
                          }),
                        ),
                          e.append(
                            $("path", {
                              class: he(t),
                              d: "M-52 0h24M28 0h24M-10 -12h20v24h-20z",
                            }),
                          ),
                          e.append(
                            $(
                              "text",
                              {
                                class: "port-label",
                                x: 0,
                                y: 34,
                                "text-anchor": "middle",
                              },
                              "high level" === t.props.mode ? "HIGH" : "LOW",
                            ),
                          ));
                      })(e, t);
                      break;
                    case "limitSwitch":
                      !(function (e, t) {
                        (e.append(
                          $("path", {
                            class: "symbol-stroke",
                            d: "M-56 0h26M24 0h32M-28 -18v36M-26 0l36 -20",
                          }),
                        ),
                          e.append(
                            $("circle", {
                              class: he(t),
                              cx: 15,
                              cy: -24,
                              r: 7,
                            }),
                          ),
                          e.append(
                            $(
                              "text",
                              {
                                class: "port-label",
                                x: 0,
                                y: 30,
                                "text-anchor": "middle",
                              },
                              t.props.active ? "LS ON" : "LS",
                            ),
                          ));
                      })(e, t);
                      break;
                    case "cylinderReedSensor":
                      !(function (e, t) {
                        (e.append(
                          $("rect", {
                            class: "symbol-fill",
                            x: -46,
                            y: -17,
                            width: 92,
                            height: 34,
                            rx: 15,
                          }),
                        ),
                          e.append(
                            $("path", {
                              class: "symbol-stroke",
                              d: "M-58 0h12M46 0h12M-18 -8h36M-18 8h36",
                            }),
                          ),
                          e.append(
                            $("circle", { class: he(t), cx: 0, cy: 0, r: 8 }),
                          ),
                          e.append(
                            $(
                              "text",
                              {
                                class: "port-label",
                                x: 0,
                                y: 34,
                                "text-anchor": "middle",
                              },
                              t.props.active ? "REED ON" : "REED",
                            ),
                          ));
                      })(e, t);
                      break;
                    case "linearPositionSensor":
                      !(function (e, t) {
                        e.append(
                          $("rect", {
                            class: "symbol-fill",
                            x: -56,
                            y: -16,
                            width: 112,
                            height: 32,
                            rx: 4,
                          }),
                        );
                        const r = S(P(t.props.triggerPosition, 0.5), 0, 1);
                        (e.append(
                          $("path", {
                            class: "symbol-stroke",
                            d: "M-64 0h8M56 0h8M-42 0h84",
                          }),
                        ),
                          e.append(
                            $("path", {
                              class: he(t),
                              d: `M${84 * r - 42} -18v36`,
                            }),
                          ),
                          e.append(
                            $(
                              "text",
                              {
                                class: "port-label",
                                x: 0,
                                y: 34,
                                "text-anchor": "middle",
                              },
                              "LVDT",
                            ),
                          ));
                      })(e, t);
                      break;
                    case "proximitySensor":
                      ye(e, t);
                      break;
                    case "pushButton":
                      !(function (e, t) {
                        const r = !!t.props.pressed;
                        (e.append(
                          $("path", {
                            class: "symbol-stroke",
                            d: "M-48 0h24M24 0h24M-24 -20v40",
                          }),
                        ),
                          e.append(
                            $("path", {
                              class: r ? "symbol-accent" : "symbol-muted",
                              d: r ? "M-20 0 H24" : "M-20 0 L18 -18",
                            }),
                          ),
                          e.append(
                            $("circle", {
                              class: r ? "symbol-accent" : "symbol-muted",
                              cx: 18,
                              cy: -24,
                              r: 7,
                            }),
                          ),
                          e.append(
                            $(
                              "text",
                              {
                                class: "port-label",
                                x: 0,
                                y: 30,
                                "text-anchor": "middle",
                              },
                              `${t.props.contact || "NO"} ${r ? "ON" : "OFF"}`,
                            ),
                          ));
                      })(e, t);
                      break;
                    case "solenoid":
                      !(function (e, t) {
                        (e.append(
                          $("rect", {
                            class: "symbol-fill",
                            x: -34,
                            y: -23,
                            width: 68,
                            height: 46,
                            rx: 5,
                          }),
                        ),
                          e.append(
                            $("path", {
                              class: t.props.energized
                                ? "symbol-accent"
                                : "symbol-muted",
                              d: "M-44 0h10M34 0h10M-18 -12 q18 12 0 24M0 -12 q18 12 0 24M18 -12 q18 12 0 24",
                            }),
                          ));
                      })(e, t);
                      break;
                    case "plc":
                      !(function (e) {
                        (e.append(
                          $("rect", {
                            class: "symbol-fill",
                            x: -50,
                            y: -34,
                            width: 100,
                            height: 68,
                            rx: 6,
                          }),
                        ),
                          e.append(
                            $(
                              "text",
                              {
                                class: "port-label",
                                x: 0,
                                y: 5,
                                "text-anchor": "middle",
                              },
                              "PLC",
                            ),
                          ),
                          e.append(
                            $("path", {
                              class: "symbol-muted",
                              d: "M-58 -18h8M-58 18h8M50 -18h8M50 18h8",
                            }),
                          ));
                      })(e);
                      break;
                    case "blindPlug":
                      !(function (e) {
                        (e.append(
                          A("path", { class: "symbol-stroke", d: "M-26 0h16" }),
                        ),
                          e.append(
                            A("rect", {
                              class: "symbol-stroke",
                              x: -10,
                              y: -12,
                              width: 16,
                              height: 24,
                            }),
                          ),
                          e.append(
                            A("path", {
                              class: "symbol-stroke",
                              d: "M-10 -12 L6 12 M6 -12 L-10 12",
                            }),
                          ));
                      })(e);
                      break;
                    case "junction":
                      !(function (e) {
                        (e.append(
                          $("circle", {
                            class: "symbol-fill",
                            cx: 0,
                            cy: 0,
                            r: 9,
                          }),
                        ),
                          e.append(
                            $("path", {
                              class: "symbol-stroke",
                              d: "M-26 0h52M0-26v52",
                            }),
                          ));
                      })(e);
                      break;
                    case "frlUnit":
                      ke(e, r.w, r.h, "FRL");
                      break;
                    case "silencer":
                      ke(e, r.w, r.h, "SIL");
                      break;
                    case "quickExhaustValve":
                      ke(e, r.w, r.h, "QEV");
                      break;
                    case "vacuumEjector":
                      ke(e, r.w, r.h, "VAC");
                      break;
                    case "suctionCup":
                      ke(e, r.w, r.h, "CUP");
                      break;
                    case "airBlowNozzle":
                      ke(e, r.w, r.h, "NOZ");
                      break;
                    case "shuttleValve":
                      ke(e, r.w, r.h, "OR");
                      break;
                    case "twoPressureValve":
                      ke(e, r.w, r.h, "AND");
                      break;
                    case "softStartValve":
                      ke(e, r.w, r.h, "SSV");
                      break;
                    case "frlUnit":
                      !(function (e) {
                        (e.append(
                          $("rect", {
                            class: "symbol-fill",
                            x: -60,
                            y: -24,
                            width: 40,
                            height: 48,
                            rx: 0,
                          }),
                        ),
                          e.append(
                            $("rect", {
                              class: "symbol-fill",
                              x: -20,
                              y: -24,
                              width: 40,
                              height: 48,
                              rx: 0,
                            }),
                          ),
                          e.append(
                            $("rect", {
                              class: "symbol-fill",
                              x: 20,
                              y: -24,
                              width: 40,
                              height: 48,
                              rx: 0,
                            }),
                          ),
                          fe(e, "M-66 0h6M60 0h6"),
                          e.append(
                            $("path", {
                              class: "symbol-muted",
                              d: "M-52 -12l24 24M-52 12l24 -24M-8 12L8 -12M0 -12v24M36 -10q8 10 0 20q-8 -10 0 -20",
                            }),
                          ),
                          ve(e, "F R L", 0, 42, 10));
                      })(e);
                      break;
                    case "silencer":
                      !(function (e) {
                        (fe(e, "M-40 0h18"),
                          e.append(
                            $("rect", {
                              class: "symbol-fill",
                              x: -22,
                              y: -14,
                              width: 36,
                              height: 28,
                              rx: 0,
                            }),
                          ),
                          e.append(
                            $("path", {
                              class: "symbol-muted",
                              d: "M-14 -8h20M-14 0h26M-14 8h20M18 -12l16 -10M18 0l18 0M18 12l16 10",
                            }),
                          ));
                      })(e);
                      break;
                    case "quickExhaustValve":
                      !(function (e) {
                        (e.append(
                          $("rect", {
                            class: "symbol-fill",
                            x: -34,
                            y: -26,
                            width: 68,
                            height: 52,
                            rx: 0,
                          }),
                        ),
                          fe(e, "M-56 0h22M34 -18h22M34 18h22"),
                          W(e, [-18, 0], [18, -18], !0),
                          W(e, [0, 0], [18, 18], !0),
                          ve(e, "QEV", 0, 42, 10));
                      })(e);
                      break;
                    case "vacuumEjector":
                      !(function (e) {
                        (fe(e, "M-60 0h24M22 0h38M16 -20v-22"),
                          e.append(
                            $("path", {
                              class: "symbol-fill",
                              d: "M-36 -16 L-6 0 L-36 16 Z M22 -16 L-6 0 L22 16 Z",
                            }),
                          ),
                          e.append(
                            $("path", {
                              class: "symbol-accent",
                              d: "M-8 0h18",
                              "marker-end": "url(#rgz-arrow)",
                            }),
                          ),
                          ve(e, "V", 16, -48, 10));
                      })(e);
                      break;
                    case "suctionCup":
                      !(function (e) {
                        (fe(e, "M-44 0h30"),
                          e.append(
                            $("path", {
                              class: "symbol-fill",
                              d: "M-14 -10 C10 -26 38 -20 44 0 C38 20 10 26 -14 10 Z",
                            }),
                          ),
                          e.append(
                            $("path", {
                              class: "symbol-muted",
                              d: "M12 -12v24M24 -10v20",
                            }),
                          ));
                      })(e);
                      break;
                    case "airBlowNozzle":
                      !(function (e) {
                        (fe(e, "M-44 0h22"),
                          e.append(
                            $("path", {
                              class: "symbol-fill",
                              d: "M-22 -14 L18 0 L-22 14 Z",
                            }),
                          ),
                          e.append(
                            $("path", {
                              class: "symbol-accent",
                              d: "M20 0h30M26 -10l24 -10M26 10l24 10",
                            }),
                          ));
                      })(e);
                      break;
                    case "shuttleValve":
                      !(function (e) {
                        (e.append(
                          $("rect", {
                            class: "symbol-fill",
                            x: -36,
                            y: -26,
                            width: 72,
                            height: 52,
                            rx: 0,
                          }),
                        ),
                          fe(e, "M-54 -18h18M-54 18h18M36 0h18"),
                          e.append(
                            $("circle", {
                              class: "symbol-muted",
                              cx: -8,
                              cy: 0,
                              r: 8,
                            }),
                          ),
                          W(e, [-36, -18], [36, 0], !1),
                          W(e, [-36, 18], [36, 0], !1),
                          ve(e, "OR", 0, 42, 10));
                      })(e);
                      break;
                    case "twoPressureValve":
                      !(function (e) {
                        (e.append(
                          $("rect", {
                            class: "symbol-fill",
                            x: -36,
                            y: -26,
                            width: 72,
                            height: 52,
                            rx: 0,
                          }),
                        ),
                          fe(e, "M-54 -18h18M-54 18h18M36 0h18"),
                          W(e, [-36, -18], [0, 0], !1),
                          W(e, [-36, 18], [0, 0], !1),
                          we(e, 12, 0, 1),
                          ve(e, "AND", 0, 42, 10));
                      })(e);
                      break;
                    case "softStartValve":
                      !(function (e) {
                        (e.append(
                          $("rect", {
                            class: "symbol-fill",
                            x: -38,
                            y: -26,
                            width: 76,
                            height: 52,
                            rx: 0,
                          }),
                        ),
                          fe(e, "M-58 0h20M38 -14h20M38 14h20"),
                          e.append(
                            $("path", {
                              class: "symbol-stroke",
                              d: "M-22 12 C-10 -8 6 -14 24 -14",
                              "marker-end": "url(#rgz-arrow)",
                            }),
                          ),
                          be(e, -22, 22, 20, -22),
                          ve(e, "SSV", 0, 42, 10));
                      })(e);
                      break;
                    case "compressedAirDistributor":
                      !(function (e) {
                        (e.append(
                          $("rect", {
                            class: "symbol-fill",
                            x: -42,
                            y: -32,
                            width: 84,
                            height: 64,
                            rx: 0,
                          }),
                        ),
                          fe(e, "M-64 0h22M42 -28h22M42 0h22M42 28h22"),
                          e.append(
                            $("path", {
                              class: "symbol-stroke",
                              d: "M-30 0H22M22 0v-28M22 0v28",
                            }),
                          ),
                          ve(e, "DIST", 0, 48, 10));
                      })(e);
                      break;
                    case "valveTerminal":
                      !(function (e, t) {
                        (e.append(
                          $("rect", {
                            class: "symbol-fill",
                            x: -78,
                            y: -44,
                            width: 156,
                            height: 88,
                            rx: 0,
                          }),
                        ),
                          fe(
                            e,
                            "M-88 0h10M-88 34h10M78 -34h10M78 -12h10M78 12h10M78 34h10M0 -58v14",
                          ));
                        const r = Math.max(
                          1,
                          Math.min(4, P(t.props.stations, 2)),
                        );
                        for (let t = 0; t < r; t++) {
                          const r = 38 * t - 58;
                          (e.append(
                            $("rect", {
                              class: "symbol-muted",
                              x: r,
                              y: -28,
                              width: 32,
                              height: 56,
                              rx: 0,
                            }),
                          ),
                            e.append(
                              $("path", {
                                class: "symbol-muted",
                                d: `M${r + 6} 16L${r + 26} -16M${r + 6} -16L${r + 26} 16`,
                              }),
                            ));
                        }
                        ve(
                          e,
                          "fieldbus" === t.props.fieldbus ? "BUS" : "VT",
                          0,
                          60,
                          10,
                        );
                      })(e, t);
                      break;
                    case "powerSupply24V":
                      !(function (e) {
                        (e.append(
                          $("rect", {
                            class: "symbol-fill",
                            x: -46,
                            y: -24,
                            width: 92,
                            height: 48,
                            rx: 0,
                          }),
                        ),
                          fe(e, "M-56 -12h10M-56 12h10M46 0h10"),
                          ve(e, "24 V", 0, -2, 15),
                          ve(e, "DC", 0, 15, 10),
                          e.append(
                            $("path", {
                              class: "symbol-muted",
                              d: "M-36 -30h72",
                            }),
                          ));
                      })(e);
                      break;
                    case "indicatorLamp":
                      !(function (e, t) {
                        (fe(e, "M-38 0h12M26 0h12"),
                          e.append(
                            $("circle", {
                              class: t.props.on
                                ? "symbol-accent"
                                : "symbol-fill",
                              cx: 0,
                              cy: 0,
                              r: 22,
                            }),
                          ),
                          e.append(
                            $("path", {
                              class: "symbol-muted",
                              d: "M-12 -12L12 12M12 -12L-12 12",
                            }),
                          ),
                          ve(e, "H", 0, 36, 10));
                      })(e, t);
                      break;
                    case "electricalRelay":
                      !(function (e, t) {
                        (e.append(
                          $("rect", {
                            class: t.props.energized
                              ? "symbol-accent"
                              : "symbol-fill",
                            x: -32,
                            y: -18,
                            width: 64,
                            height: 36,
                            rx: 0,
                          }),
                        ),
                          fe(e, "M-50 0h18M32 0h18"),
                          ve(e, "K", 0, 6, 16));
                      })(e, t);
                      break;
                    case "relayContact":
                      !(function (e, t) {
                        fe(e, "M-54 0h22M26 0h28");
                        const r = !!t.props.closed || "NC" === t.props.contact;
                        (e.append(
                          $("path", {
                            class: "symbol-stroke",
                            d: r ? "M-28 0H26" : "M-28 0L22 -18",
                          }),
                        ),
                          ve(e, t.props.contact || "NO", 0, 30, 10));
                      })(e, t);
                      break;
                    case "terminalStrip":
                      !(function (e) {
                        e.append(
                          $("rect", {
                            class: "symbol-fill",
                            x: -48,
                            y: -24,
                            width: 96,
                            height: 48,
                            rx: 0,
                          }),
                        );
                        for (let t = 0; t < 4; t++) {
                          const r = 20 * t - 30;
                          (e.append(
                            $("circle", {
                              class: "symbol-muted",
                              cx: r,
                              cy: 0,
                              r: 5,
                            }),
                          ),
                            ve(e, String(t + 1), r, 18, 8));
                        }
                        (fe(e, "M-58 -18h10M-58 18h10M48 -18h10M48 18h10"),
                          ve(e, "X", 0, -32, 10));
                      })(e);
                      break;
                    case "inductiveSensor":
                      !(function (e, t) {
                        (ye(e, t), ve(e, "IND", 0, 36, 9));
                      })(e, t);
                      break;
                    case "capacitiveSensor":
                      !(function (e, t) {
                        (ye(e, t), ve(e, "CAP", 0, 36, 9));
                      })(e, t);
                      break;
                    case "opticalSensor":
                      !(function (e, t) {
                        (ye(e, t),
                          e.append(
                            $("path", {
                              class: "symbol-accent",
                              d: "M20 -18l24 -12M20 0h28M20 18l24 12",
                            }),
                          ),
                          ve(e, "OPT", 0, 36, 9));
                      })(e, t);
                      break;
                    case "pneumaticTimeDelayValve":
                      !(function (e) {
                        (e.append(
                          $("rect", {
                            class: "symbol-fill",
                            x: -38,
                            y: -24,
                            width: 76,
                            height: 48,
                            rx: 0,
                          }),
                        ),
                          fe(e, "M-62 0h24M38 0h24M0 24v18"),
                          e.append(
                            $("path", {
                              class: "symbol-stroke",
                              d: "M-20 12L20 -12M-20 -12L20 12",
                            }),
                          ),
                          e.append(
                            $("circle", {
                              class: "symbol-muted",
                              cx: 0,
                              cy: -42,
                              r: 12,
                            }),
                          ),
                          be(e, -26, 24, 26, -24),
                          ve(e, "t", 0, -38, 12));
                      })(e);
                      break;
                    case "pneumaticMemoryValve":
                      !(function (e, t) {
                        (J(e, {
                          type: "directionalValve",
                          props: {
                            ports: "5",
                            positions: "2",
                            spoolState: t.props.spoolState || "left",
                            leftActuation: "pneumatic pilot",
                            rightActuation: "pneumatic pilot",
                          },
                        }),
                          ve(e, "MEM", 0, 62, 10));
                      })(e, t);
                      break;
                    case "pneumaticFunctionChart":
                    case "textLabel":
                      !(function (e, t) {
                        const r = String(t.props.text || ""),
                          n = r.split(/\r?\n/).slice(0, 8),
                          a =
                            "auto" === t.props.direction
                              ? /[^\u0000-\u007f]/.test(r)
                                ? "rtl"
                                : "ltr"
                              : t.props.direction || "ltr",
                          i = t.props.align || ("rtl" === a ? "end" : "start"),
                          o = P(t.props.fontSize, 24),
                          s =
                            "middle" === i
                              ? "middle"
                              : "end" === i
                                ? "end"
                                : "start",
                          l = "middle" === s ? 0 : "end" === s ? 130 : -130,
                          c = $("text", {
                            class: "rgz-custom-text",
                            x: l,
                            y: 0,
                            fill: t.props.color || "#f3efe7",
                            "font-size": o,
                            "font-family":
                              t.props.fontFamily || "Tahoma, Arial, sans-serif",
                            "font-weight": t.props.fontWeight || "700",
                            direction: a,
                            "unicode-bidi": "plaintext",
                            "text-anchor": s,
                            style: `direction:${a};unicode-bidi:plaintext;`,
                          });
                        (n.forEach((e, t) => {
                          c.appendChild(
                            $(
                              "tspan",
                              { x: l, dy: t ? 1.25 * o : 0 },
                              e || " ",
                            ),
                          );
                        }),
                          e.append(c));
                      })(e, t);
                      break;
                    default:
                      ke(e, r.w, r.h, t.type);
                  }
              })(r, e, t),
              "textLabel" !== e.type &&
                r.appendChild(
                  $(
                    "text",
                    {
                      class: "component-label",
                      x: 0,
                      y: -t.h / 2 - 10,
                      "text-anchor": "middle",
                      ...(e.rotation
                        ? { transform: `rotate(${-e.rotation} 0 ${-t.h / 2 - 10})` }
                        : {}),
                    },
                    e.label || e.id,
                  ),
                ),
              T(e).forEach((t) => {
                const n = $("circle", {
                  class:
                    "port " +
                    (u.pendingPort &&
                    u.pendingPort.componentId === e.id &&
                    u.pendingPort.portId === t.id
                      ? "pending"
                      : ""),
                  cx: t.x,
                  cy: t.y,
                  r: 7,
                  "data-component-id": e.id,
                  "data-port-id": t.id,
                });
                (n.addEventListener("pointerdown", (e) => {
                  (e.stopPropagation(), (e.ctrlKey || e.metaKey) && F(e));
                }),
                  n.addEventListener("click", (r) => {
                    (r.stopPropagation(),
                      r.ctrlKey ||
                        r.metaKey ||
                        (function (e, t) {
                          if (!E(e, t)) return;
                          if (!u.pendingPort)
                            return (
                              (u.pendingPort = { componentId: e, portId: t }),
                              ct(
                                `Start port selected: ${e}.${t}. Now click target port.`,
                                "info",
                              ),
                              void H()
                            );
                          const r = u.pendingPort;
                          if (
                            ((u.pendingPort = null),
                            r.componentId === e && r.portId === t)
                          )
                            return void H();
                          const n = E(r.componentId, r.portId),
                            a = E(e, t);
                          if (!n || !a) return;
                          if (!(
                            n.kind === a.kind ||
                            ("pilot" === n.kind && "pneumatic" === a.kind) ||
                            ("pneumatic" === n.kind && "pilot" === a.kind)
                          ))
                            return (
                              ct(
                                `Incompatible connection: ${n.kind} port cannot connect to ${a.kind} port.`,
                                "error",
                              ),
                              void H()
                            );
                          const i = q(r.componentId, r.portId, e, t);
                          (u.connections.push(i),
                            (u.selected = { kind: "connection", id: i.id }),
                            H(),
                            Me());
                        })(e.id, t.id));
                  }),
                  r.appendChild(n));
                const a = t.y + (t.y < 0 ? -10 : 18);
                r.appendChild(
                  $(
                    "text",
                    {
                      class: "port-label",
                      x: t.x,
                      y: a,
                      "text-anchor": "middle",
                      ...(e.rotation
                        ? { transform: `rotate(${-e.rotation} ${t.x} ${a})` }
                        : {}),
                    },
                    t.id,
                  ),
                );
              }));
            const n = (function (e) {
              if (!u.sim.running || !1 === e.props.showReadout) return "";
              const t = u.sim.metrics || {},
                tcv = (t.comp && t.comp[e.id]) || null,
                tp =
                  tcv && Number.isFinite(tcv.pressureBar)
                    ? tcv.pressureBar
                    : P(t.pressureBar, 0),
                tf =
                  tcv && Number.isFinite(tcv.flowLpm)
                    ? tcv.flowLpm
                    : P(t.activeFlowLpm ?? t.totalFlowLpm, 0);
              if (
                [
                  "pressureGauge",
                  "pressureSwitch",
                  "pressureTransducer",
                  "reliefValve",
                ].includes(e.type)
              )
                return _(K(tp, e.props.displayUnit || "bar"));
              if ("powerPack" === e.type && e.props.pressureGauge)
                return _(K(tp, e.props.displayUnit || "bar"));
              if (["flowMeter", "flowSwitch"].includes(e.type))
                return _(
                  ((r = tf),
                  "L/s" === (n = e.props.displayUnit || "L/min")
                    ? { value: r / 60, suffix: "L/s", decimals: 2 }
                    : "GPM" === n
                      ? { value: 0.264172 * r, suffix: "GPM", decimals: 2 }
                      : { value: r, suffix: "L/min", decimals: 1 }),
                );
              var r, n;
              if ("temperatureSwitch" === e.type)
                return _(
                  (function (e, t) {
                    return "°F" === t
                      ? { value: (9 * e) / 5 + 32, suffix: "°F", decimals: 1 }
                      : { value: e, suffix: "°C", decimals: 1 };
                  })(
                    P(t.oilTempC, e.props.switchTempC || 40),
                    e.props.displayUnit || "°C",
                  ),
                );
              if ("levelSwitch" === e.type)
                return `${P(e.props.levelPercent, 0).toFixed(0)} %`;
              if (
                [
                  "limitSwitch",
                  "cylinderReedSensor",
                  "linearPositionSensor",
                  "proximitySensor",
                  "inductiveSensor",
                  "capacitiveSensor",
                  "opticalSensor",
                ].includes(e.type)
              ) {
                if ("state" === (e.props.displayUnit || "%"))
                  return e.props.active ? "ON" : "OFF";
                const t = je(e);
                return `${(t ? 100 * P(t.props.simPosition, 0) : 0).toFixed(0)} %`;
              }
              if ("cylinderDA" === e.type || "cylinderSA" === e.type) {
                if (
                  (function (e) {
                    const t = [
                      "limitSwitch",
                      "cylinderReedSensor",
                      "linearPositionSensor",
                      "proximitySensor",
                      "inductiveSensor",
                      "capacitiveSensor",
                      "opticalSensor",
                    ];
                    return u.components.some((r) => {
                      if (!t.includes(r.type)) return !1;
                      const n = String(r.props.linkedActuator || "")
                        .trim()
                        .toLowerCase();
                      return n
                        ? n === String(e.id).toLowerCase() ||
                            n === String(e.label || "").toLowerCase()
                        : Math.hypot(r.x - e.x, r.y - e.y) < 180;
                    });
                  })(e)
                )
                  return "";
                const r = (t.cylinders || []).find((t) => t.id === e.id),
                  n = S(P(e.props.simPosition, 0), 0, 1),
                  a = Math.max(1, P(e.props.strokeMm, 1)),
                  i = e.props.displayUnit || "position %";
                return "position mm" === i
                  ? `${(n * a).toFixed(0)} mm`
                  : "speed mm/s" === i
                    ? `${P(r?.speedMmS, 0).toFixed(1)} mm/s`
                    : "force kN" === i
                      ? `${P(r?.forceKN, 0).toFixed(1)} kN`
                      : `${(100 * n).toFixed(0)} %`;
              }
              if ("pneumaticMotor" === e.type) {
                const r = (t.motors || []).find((t) => t.id === e.id),
                  n = P(r?.rpm, 0);
                return "rev/s" === (e.props.displayUnit || "rpm")
                  ? `${(n / 60).toFixed(2)} rev/s`
                  : `${n.toFixed(0)} rpm`;
              }
              return "";
            })(e);
            return (
              n &&
                r.appendChild(
                  (function (e, t) {
                    const r = Math.max(74, Math.min(190, 8 * t.length + 22)),
                      n = e.h / 2 + 28,
                      a = $("g", e.rotation ? { class: "rgz-readout-badge", transform: `rotate(${-e.rotation} 0 ${e.h / 2 + 28})` } : { class: "rgz-readout-badge" });
                    return (
                      a.appendChild(
                        $("rect", {
                          class: "rgz-readout-bg",
                          x: -r / 2,
                          y: n - 17,
                          width: r,
                          height: 28,
                          rx: 9,
                        }),
                      ),
                      a.appendChild(
                        $(
                          "text",
                          {
                            class: "rgz-readout-text",
                            x: 0,
                            y: n + 2,
                            "text-anchor": "middle",
                          },
                          t,
                        ),
                      ),
                      a
                    );
                  })(t, n),
                ),
              r
            );
          })(e),
        ),
      ),
      Fe(),
      Ce(),
      _e());
  }
  function G(e, t = 1, r = 0) {
    let n = e.vx || 0,
      a = e.vy || 0;
    return (
      Math.abs(n) < 1 && Math.abs(a) < 1 && ((n = t), (a = r)),
      Math.abs(n) >= Math.abs(a)
        ? { x: n >= 0 ? 1 : -1, y: 0 }
        : { x: 0, y: a >= 0 ? 1 : -1 }
    );
  }
  function K(e, t) {
    return "MPa" === t
      ? { value: e / 10, suffix: "MPa", decimals: 2 }
      : "psi" === t
        ? { value: 14.5038 * e, suffix: "psi", decimals: 0 }
        : { value: e, suffix: "bar", decimals: 1 };
  }
  function _(e) {
    return `${P(e.value, 0).toFixed(e.decimals)} ${e.suffix}`;
  }
  function Z(e) {
    return (
      !!u.sim.running &&
      ["cylinderDA", "cylinderSA", "pneumaticMotor"].includes(e.type)
    );
  }
  function X(e, t) {
    (e.append($("circle", { class: "symbol-fill", cx: 0, cy: 0, r: 32 })),
      e.append($("path", { class: "symbol-stroke", d: "M-58 0h26M32 0h26" })),
      e.append(
        $("path", { class: "symbol-accent", d: "M-8 15 L17 0 L-8 -15 Z" }),
      ),
      t &&
        e.append(
          $("path", {
            class: "symbol-accent",
            d: "M-32 32 L32 -32 M19 -32h13v13",
          }),
        ));
  }
  function W(e, t, r, n = !0) {
    t &&
      r &&
      (function (e, t, r = {}) {
        e.append(
          $(
            "path",
            Object.assign(
              {
                class: "symbol-stroke",
                d: t,
                "marker-end": r.arrow ? "url(#rgz-arrow)" : null,
              },
              r.attrs || {},
            ),
          ),
        );
      })(e, `M${t[0]} ${t[1]} L${r[0]} ${r[1]}`, { arrow: n });
  }
  function Y(e, t) {
    if (!t) return;
    const [r, n] = t,
      a = n < 0 ? 1 : -1;
    e.append(
      $("path", {
        class: "symbol-muted",
        d: `M${r} ${n} v${10 * a} M${r - 7} ${n + 10 * a} h14`,
      }),
    );
  }
  function Q(e, t, r) {
    e.append($("circle", { class: "symbol-muted", cx: t, cy: r, r: 2.2 }));
  }
  function J(e, t) {
    const r = Number(t.props.positions || 3),
      n = Number(t.props.ports || 4),
      a = 2 === r ? 136 : 204,
      i = a / r;
    const _ps = 3 === r ? ["left", "center", "right"] : ["left", "right"],
      _sp = Math.max(
        0,
        _ps.indexOf(t.props.spoolState || (3 === r ? "center" : "left")),
      ),
      _sh = a / 2 - i * _sp - i / 2,
      h = $("g", { transform: "translate(" + _sh.toFixed(1) + " 0)" });
    (e.append(h),
      h.append(
        $("rect", {
          class: "symbol-fill",
          x: -a / 2,
          y: -39,
          width: a,
          height: 78,
          rx: 0,
        }),
      ));
    for (let t = 1; t < r; t++)
      h.append(
        $("path", { class: "symbol-muted", d: `M${-a / 2 + t * i} -39 v78` }),
      );
    B(t)
      .filter((e) => !["X", "Y"].includes(e.id))
      .forEach((t) => {
        const r = t.y < 0 ? 1 : -1;
        e.append(
          $("path", { class: "symbol-muted", d: `M${t.x} ${t.y} v${12 * r}` }),
        );
      });
    const o = 3 === r ? ["left", "center", "right"] : ["left", "right"];
    o.forEach((r, o) =>
      (function (e, t, r, n, a) {
        const i = (function (e, t) {
            return t <= 2
              ? { A: [e, -27], P: [e, 27] }
              : 3 === t
                ? { A: [e, -27], P: [e - 18, 27], T: [e + 18, 27] }
                : 5 === t
                  ? {
                      A: [e - 22, -27],
                      B: [e + 22, -27],
                      R: [e - 22, 27],
                      P: [e, 27],
                      S: [e + 22, 27],
                    }
                  : {
                      A: [e - 18, -27],
                      B: [e + 18, -27],
                      P: [e - 18, 27],
                      T: [e + 18, 27],
                    };
          })(t, n),
          o =
            "center" === r
              ? a.props.center || "closed"
              : "left" === r
                ? a.props.leftBlock || "parallel"
                : a.props.rightBlock || "crossover";
        // unified envelope drawer: every position renders its selected block pattern
        (function (e, t, r, n) {
          if ("closed" === r) return Object.values(t).forEach((t) => Y(e, t));
          if ("tandem" === r)
            return void (5 === n
              ? (W(e, t.P, t.R, !0), W(e, t.P, t.S, !0), Y(e, t.A), Y(e, t.B))
              : t.P && t.T
                ? (W(e, t.P, t.T, !0), t.A && Y(e, t.A), t.B && Y(e, t.B))
                : (t.P && Y(e, t.P), t.A && Y(e, t.A), t.B && Y(e, t.B), t.T && Y(e, t.T)));
          if ("float" === r)
            return void (5 === n
              ? (W(e, t.A, t.R, !0), W(e, t.B, t.S, !0), Y(e, t.P))
              : (t.A && t.T && W(e, t.A, t.T, !0),
                t.B && t.T && W(e, t.B, t.T, !0),
                t.P && Y(e, t.P)));
          if ("regenerative" === r) {
            const r = t.P || [0, 0];
            return (
              t.P && t.A && W(e, t.P, t.A, !0),
              t.P && t.B && W(e, t.P, t.B, !0),
              t.P && t.A && Q(e, r[0], r[1] - 11),
              t.T && Y(e, t.T),
              t.R && Y(e, t.R),
              void (t.S && Y(e, t.S))
            );
          }
          if ("parallel" === r)
            return void (5 === n
              ? (W(e, t.P, t.A, !0), W(e, t.B, t.S, !0), Y(e, t.R))
              : 3 === n
                ? (W(e, t.P, t.A, !0), t.T && Y(e, t.T))
                : 2 >= n
                  ? W(e, t.P, t.A, !0)
                  : (W(e, t.P, t.A, !0), W(e, t.B, t.T, !0)));
          if ("crossover" === r)
            return void (5 === n
              ? (W(e, t.P, t.B, !0), W(e, t.A, t.R, !0), Y(e, t.S))
              : 3 === n
                ? (W(e, t.A, t.T, !0), t.P && Y(e, t.P))
                : 2 >= n
                  ? (Y(e, t.P), Y(e, t.A))
                  : (W(e, t.P, t.B, !0), W(e, t.A, t.T, !0)));
          const a2 = Object.values(t),
            i2 = a2.reduce((e, t) => e + t[0], 0) / a2.length;
          (Q(e, i2, 0), a2.forEach((t) => W(e, t, [i2, 0], !1)));
        })(e, i, o, n);
      })(h, -a / 2 + i * o + i / 2, r, n, t),
    );
    const s = t.props.spoolState || (3 === r ? "center" : "left"),
      l = Math.max(0, o.indexOf(s)),
      c = -a / 2 + i * l + i / 2;
    (h.append(
      $("rect", {
        class: "symbol-accent",
        x: c - i / 2 + 4,
        y: -35,
        width: i - 8,
        height: 70,
        rx: 0,
      }),
    ),
      ee(e, -a / 2 - 22, t.props.leftActuation || "manual", "left"),
      ee(e, a / 2 + 22, t.props.rightActuation || "spring", "right"));
  }
  function ee(e, t, r, n) {
    const a = "left" === n ? -1 : 1,
      i = -a,
      o = String(r || "").toLowerCase(),
      s = "symbol-muted";
    function l(r = !1) {
      (e.append(
        $("rect", {
          class: s,
          x: t - 12,
          y: -17,
          width: 24,
          height: 34,
          rx: 0,
        }),
      ),
        e.append($("path", { class: s, d: `M${t - 8} 12 L${t + 8} -12` })),
        r &&
          e.append(
            $("path", {
              class: "symbol-accent",
              d: `M${t - 18} 22 L${t + 18} -22 M${t + 8} -22h10v10`,
            }),
          ));
    }
    o.includes("spring")
      ? (function () {
          const r = t + 4 * a,
            n = [];
          for (let e = 0; e <= 8; e++) n.push([r + a * e * 4, e % 2 ? -7 : 7]);
          e.append(
            $("path", {
              class: s,
              d: n.map((e, t) => `${t ? "L" : "M"}${e[0]} ${e[1]}`).join(" "),
            }),
          );
        })()
      : o.includes("proportional")
        ? l(!0)
        : o.includes("solenoid")
          ? l(!1)
          : o.includes("pilot")
            ? (function () {
                const r = t + 17 * i,
                  n = t - 17 * i;
                e.append(
                  $("path", { class: s, d: `M${n} -17 L${r} 0 L${n} 17 Z` }),
                );
              })()
            : o.includes("lever")
              ? (e.append(
                  $("circle", { class: s, cx: t - 5 * a, cy: 18, r: 3 }),
                ),
                e.append(
                  $("path", {
                    class: s,
                    d: `M${t - 5 * a} 18 L${t + 18 * a} -22`,
                  }),
                ),
                e.append(
                  $("circle", { class: s, cx: t + 20 * a, cy: -25, r: 5 }),
                ))
              : o.includes("roller")
                ? (e.append(
                    $("path", {
                      class: s,
                      d: `M${t - 18 * a} 0 H${t + 8 * a}`,
                    }),
                  ),
                  e.append(
                    $("circle", { class: s, cx: t + 15 * a, cy: 0, r: 7 }),
                  ))
                : o.includes("pedal")
                  ? (e.append(
                      $("path", {
                        class: s,
                        d: `M${t - 14 * a} 18 L${t + 18 * a} 0 L${t + 12 * a} -8`,
                      }),
                    ),
                    e.append(
                      $("path", { class: s, d: `M${t + 8 * a} -8 h${22 * a}` }),
                    ))
                  : o.includes("detent")
                    ? (e.append(
                        $("path", {
                          class: s,
                          d: `M${t - 18 * a} -14 h${36 * a} M${t - 18 * a} 14 h${36 * a}`,
                        }),
                      ),
                      e.append($("circle", { class: s, cx: t, cy: -14, r: 3 })),
                      e.append($("circle", { class: s, cx: t, cy: 14, r: 3 })))
                    : (e.append(
                        $("path", {
                          class: s,
                          d: `M${t} -17 v34 M${t - 12} -17 h24`,
                        }),
                      ),
                      e.append(
                        $("rect", {
                          class: s,
                          x: t - 8,
                          y: -27,
                          width: 16,
                          height: 8,
                          rx: 2,
                        }),
                      ));
  }
  function te(e, t) {
    (e.append($("path", { class: "symbol-stroke", d: "M-54 0h34M20 0h34" })),
      e.append(
        $("path", {
          class: "symbol-stroke",
          d: "M-18 -22 L18 22 M-18 22 L18 -22",
        }),
      ),
      e.append(
        $("path", {
          class: "symbol-accent",
          d: "M-32 26 L32 -26 M18 -26h14v14",
        }),
      ),
      t.props.pressureCompensated &&
        e.append(
          $("path", {
            class: "symbol-muted",
            d: "M-5 -30 q12 10 0 20 q-12 10 0 20 q12 10 0 20",
          }),
        ));
  }
  function re(e) {
    (e.append($("path", { class: "symbol-stroke", d: "M-50 0h32M24 0h26" })),
      e.append($("path", { class: "symbol-fill", d: "M-18 -22 V22 L24 0 Z" })),
      e.append($("path", { class: "symbol-stroke", d: "M27 -24v48" })));
  }
  function ne(e) {
    (re(e),
      e.append(
        $("path", { class: "symbol-muted", d: "M0 -44 v24 M-12 -34 h24" }),
      ));
  }
  function ae(e) {
    (e.append(
      $("rect", {
        class: "symbol-fill",
        x: -34,
        y: -28,
        width: 68,
        height: 56,
        rx: 4,
      }),
    ),
      e.append(
        $("path", {
          class: "symbol-stroke",
          d: "M-60 0h26M34 0h26M-18 14L18-14M6-14h12v12",
        }),
      ),
      e.append(
        $("path", {
          class: "symbol-muted",
          d: "M0 -48 v20M-10 -38h20M28 20c12-10 12-30 0-40",
        }),
      ));
  }
  function ie(e, t) {
    (e.append(
      $("rect", {
        class: "symbol-fill",
        x: -34,
        y: -28,
        width: 68,
        height: 56,
        rx: 4,
      }),
    ),
      e.append(
        $("path", { class: "symbol-stroke", d: "M-58 0h24M34 0h24M0 28v18" }),
      ),
      e.append(
        $("path", { class: "symbol-accent", d: "M-18 14L18-14M6-14h12v12" }),
      ),
      e.append(
        $(
          "text",
          { class: "port-label", x: 0, y: 5, "text-anchor": "middle" },
          t,
        ),
      ));
  }
  function oe(e, t) {
    const r = S(P(t.props.simPosition, 0.25), 0, 1),
      n = 38 + 58 * r;
    (e.append(
      $("rect", {
        class: "symbol-fill",
        x: -78,
        y: -22,
        width: 112,
        height: 44,
        rx: 2,
      }),
    ),
      e.append(
        $("path", { class: "symbol-stroke", d: `M${40 * r - 44} -22 v44` }),
      ),
      e.append(
        $("path", { class: "symbol-accent", d: `M${40 * r - 24} 0 H${n}` }),
      ),
      e.append(
        $("path", { class: "symbol-stroke", d: "M-82 34v-12M22 34v-12" }),
      ),
      e.append($("path", { class: "symbol-muted", d: `M${n} -14 v28` })));
  }
  function se(e, t) {
    const r = S(P(t.props.simPosition, 0.15), 0, 1),
      n = 24 + 66 * r;
    (e.append(
      $("rect", {
        class: "symbol-fill",
        x: -72,
        y: -22,
        width: 100,
        height: 44,
        rx: 2,
      }),
    ),
      e.append(
        $("path", { class: "symbol-accent", d: `M${44 * r - 22} 0 H${n}` }),
      ),
      e.append(
        $("path", {
          class: "symbol-muted",
          d: "M-54 -13 l28 26M-26 -13 l-28 26M-40 -13 l28 26",
        }),
      ),
      e.append($("path", { class: "symbol-stroke", d: "M-76 34v-12" })),
      e.append($("path", { class: "symbol-muted", d: `M${n} -14 v28` })));
  }
  function le(e, t) {
    const r = P(t.props.simAngle, 0);
    (e.append($("circle", { class: "symbol-fill", cx: 0, cy: 0, r: 32 })),
      e.append($("path", { class: "symbol-stroke", d: "M-58 0h26M32 0h26" })),
      e.append(
        $("path", {
          class: "symbol-accent",
          d: `M0 0 L${22 * Math.cos(r)} ${22 * Math.sin(r)} M0 0 L${22 * Math.cos(r + Math.PI)} ${22 * Math.sin(r + Math.PI)}`,
        }),
      ),
      e.append(
        $("path", { class: "symbol-stroke", d: "M10 -14 L-16 0 L10 14 Z" }),
      ));
  }
  function ce(e) {
    (e.append(
      $("path", {
        class: "symbol-fill",
        d: "M-30 48 V-12 a30 30 0 0 1 60 0 v60 Z",
      }),
    ),
      e.append($("path", { class: "symbol-muted", d: "M-25 2 q25 -18 50 0" })),
      e.append($("path", { class: "symbol-stroke", d: "M0 48v4" })));
  }
  function pe(e) {
    (e.append($("circle", { class: "symbol-fill", cx: 0, cy: 0, r: 34 })),
      e.append(
        $("path", {
          class: "symbol-stroke",
          d: "M0 50V20M0 18L-35 -10M0 18L35 -10",
        }),
      ),
      e.append(
        $("path", { class: "symbol-accent", d: "M0 18L-20 2M0 18L20 2" }),
      ));
  }
  function de(e) {
    (e.append(
      $("path", { class: "symbol-fill", d: "M-30 0 L0 -28 L30 0 L0 28 Z" }),
    ),
      e.append(
        $("path", {
          class: "symbol-stroke",
          d: "M-52 0h22M30 0h22M-16 -14 L16 14M16 -14 L-16 14",
        }),
      ));
  }
  function ue(e) {
    (e.append(
      $("rect", {
        class: "symbol-fill",
        x: -34,
        y: -24,
        width: 68,
        height: 48,
        rx: 3,
      }),
    ),
      e.append(
        $("path", {
          class: "symbol-stroke",
          d: "M-56 0h22M34 0h22M-22 -12 h44M-22 0h44M-22 12h44",
        }),
      ),
      e.append(
        $("path", {
          class: "symbol-accent",
          d: "M-28 30 L28 -30M14 -30h14v14",
        }),
      ));
  }
  function me(e) {
    (e.append($("circle", { class: "symbol-fill", cx: 0, cy: -8, r: 30 })),
      e.append(
        $("path", { class: "symbol-stroke", d: "M0 22v24M0-8l17-15M-16-8h32" }),
      ));
  }
  function ge(e) {
    (e.append($("circle", { class: "symbol-fill", cx: 0, cy: 0, r: 28 })),
      e.append(
        $("path", {
          class: "symbol-stroke",
          d: "M-54 0h26M28 0h26M-8 12L13 0-8-12",
        }),
      ),
      e.append(
        $(
          "text",
          { class: "port-label", x: 0, y: 5, "text-anchor": "middle" },
          "Q",
        ),
      ));
  }
  function he(e) {
    return e.props?.active ? "symbol-accent" : "symbol-muted";
  }
  function ye(e, t) {
    (e.append(
      $("rect", {
        class: "symbol-fill",
        x: -34,
        y: -20,
        width: 68,
        height: 40,
        rx: 5,
      }),
    ),
      e.append($("path", { class: "symbol-stroke", d: "M-56 0h22M34 0h22" })),
      e.append(
        $("path", {
          class: he(t),
          d: "M38 -18 q18 18 0 36M48 -28 q28 28 0 56",
        }),
      ),
      e.append(
        $(
          "text",
          { class: "port-label", x: 0, y: 5, "text-anchor": "middle" },
          "B",
        ),
      ));
  }
  function ve(e, t, r, n, a = 12) {
    e.append(
      $(
        "text",
        {
          class: "port-label",
          x: r,
          y: n,
          "text-anchor": "middle",
          "font-size": a,
        },
        t,
      ),
    );
  }
  function fe(e, t) {
    e.append($("path", { class: "symbol-stroke", d: t }));
  }
  function be(e, t = -30, r = 28, n = 30, a = -28) {
    e.append(
      $("path", {
        class: "symbol-accent",
        d: `M${t} ${r} L${n} ${a} M${n - 12} ${a}h12v12`,
      }),
    );
  }
  function xe(e, t = 28, r = -24, n = 24, a = 1) {
    const i = [];
    for (let e = 0; e <= 8; e++)
      i.push([t + (e % 2 ? 7 * a : 0), r + ((n - r) * e) / 8]);
    e.append(
      $("path", {
        class: "symbol-muted",
        d: i.map((e, t) => `${t ? "L" : "M"}${e[0]} ${e[1]}`).join(" "),
      }),
    );
  }
  function we(e, t = 0, r = 0, n = 1) {
    (e.append(
      $("path", {
        class: "symbol-fill",
        d: `M${t - 18 * n} ${r - 18} L${t - 18 * n} ${r + 18} L${t + 16 * n} ${r} Z`,
      }),
    ),
      e.append(
        $("path", {
          class: "symbol-stroke",
          d: `M${t + 19 * n} ${r - 22} v44`,
        }),
      ));
  }
  function te(e, t) {
    (fe(e, "M-54 0h32M22 0h32"),
      e.append(
        $("path", {
          class: "symbol-stroke",
          d: "M-20 -18 L20 18 M-20 18 L20 -18",
        }),
      ),
      be(e, -34, 28, 34, -28),
      t.props &&
        t.props.pressureCompensated &&
        e.append(
          $("path", {
            class: "symbol-muted",
            d: "M-4 -34 q12 8 0 16 q-12 8 0 16 q12 8 0 16 q-12 8 0 16",
          }),
        ));
  }
  function re(e) {
    (fe(e, "M-50 0h28M28 0h22"), we(e, 0, 0, 1));
  }
  function ne(e) {
    (re(e),
      e.append(
        $("path", { class: "symbol-muted", d: "M0 -44 v22 M-12 -34h24" }),
      ),
      e.append(
        $("path", { class: "symbol-muted", d: "M-16 -42 L0 -22 L16 -42" }),
      ));
  }
  function ae(e) {
    (e.append(
      $("rect", {
        class: "symbol-fill",
        x: -36,
        y: -28,
        width: 72,
        height: 56,
        rx: 0,
      }),
    ),
      fe(e, "M-60 0h24M36 0h24"),
      we(e, -4, 0, 1),
      be(e, -20, 20, 24, -20),
      xe(e, 30, -22, 22, -1),
      e.append(
        $("path", { class: "symbol-muted", d: "M0 -48v20 M-10 -38h20" }),
      ));
  }
  function ie(e, t) {
    (e.append(
      $("rect", {
        class: "symbol-fill",
        x: -36,
        y: -28,
        width: 72,
        height: 56,
        rx: 0,
      }),
    ),
      fe(e, "M-58 0h22M36 0h22"),
      we(e, -4, 0, 1),
      xe(e, 30, -22, 22, -1),
      be(e, -22, 22, 20, -20),
      ve(e, t, 0, 44, 10));
  }
  function X(e, t) {
    (e.append($("circle", { class: "symbol-fill", cx: 0, cy: 0, r: 31 })),
      fe(e, "M-58 0h27M31 0h27"),
      e.append(
        $("path", { class: "symbol-stroke", d: "M14 -14 L-12 0 L14 14 Z" }),
      ),
      t && be(e, -32, 32, 32, -32));
  }
  function le(e, t) {
    const r = P(t?.props?.simAngle, 0);
    (e.append($("circle", { class: "symbol-fill", cx: 0, cy: 0, r: 31 })),
      fe(e, "M-58 0h27M31 0h27"),
      e.append(
        $("path", { class: "symbol-stroke", d: "M12 -14 L-14 0 L12 14 Z" }),
      ),
      e.append(
        $("path", {
          class: "symbol-accent",
          d: `M0 0 L${20 * Math.cos(r)} ${20 * Math.sin(r)} M0 0 L${20 * Math.cos(r + Math.PI)} ${20 * Math.sin(r + Math.PI)}`,
        }),
      ));
  }
  function oe(e, t) {
    const r = S(P(t?.props?.simPosition, 0.25), 0, 1),
      n = 64 * r - 52,
      a = 74 + 10 * r;
    (e.append(
      $("rect", {
        class: "symbol-fill",
        x: -78,
        y: -20,
        width: 110,
        height: 40,
        rx: 0,
      }),
    ),
      e.append(
        $("path", { class: "symbol-stroke", d: `M${n} -20v40 M${n} 0H${a}` }),
      ),
      e.append($("path", { class: "symbol-muted", d: `M${a} -12v24` })),
      fe(e, "M-82 34v-14M22 34v-14"));
  }
  function se(e, t) {
    const r = S(P(t?.props?.simPosition, 0.15), 0, 1),
      n = 52 * r - 48,
      a = 62 + 12 * r;
    (e.append(
      $("rect", {
        class: "symbol-fill",
        x: -72,
        y: -20,
        width: 96,
        height: 40,
        rx: 0,
      }),
    ),
      e.append(
        $("path", { class: "symbol-stroke", d: `M${n} -20v40 M${n} 0H${a}` }),
      ),
      e.append(
        $("path", {
          class: "symbol-muted",
          d: "M-58 -12 l24 24 M-34 -12 l-24 24 M-46 -12 l24 24",
        }),
      ),
      e.append($("path", { class: "symbol-muted", d: `M${a} -12v24` })),
      fe(e, "M-76 34v-14"));
  }
  function ce(e) {
    (e.append(
      $("path", {
        class: "symbol-fill",
        d: "M-30 46 V-10 a30 30 0 0 1 60 0 v56 Z",
      }),
    ),
      e.append($("path", { class: "symbol-muted", d: "M-26 -2 q26 -16 52 0" })),
      fe(e, "M0 46v10"));
  }
  function pe(e) {
    (e.append($("circle", { class: "symbol-fill", cx: 0, cy: 0, r: 32 })),
      fe(e, "M0 50V20M0 18L-38 -10M0 18L38 -10"),
      e.append(
        $("path", {
          class: "symbol-stroke",
          d: "M0 18L-18 4M0 18L18 4",
          "marker-end": "url(#rgz-arrow)",
        }),
      ));
  }
  function de(e) {
    (e.append(
      $("path", { class: "symbol-fill", d: "M-30 0 L0 -28 L30 0 L0 28 Z" }),
    ),
      fe(e, "M-52 0h22M30 0h22"),
      e.append(
        $("path", {
          class: "symbol-muted",
          d: "M-15 -14 L15 14 M15 -14 L-15 14",
        }),
      ));
  }
  function ue(e) {
    (e.append(
      $("rect", {
        class: "symbol-fill",
        x: -34,
        y: -24,
        width: 68,
        height: 48,
        rx: 0,
      }),
    ),
      fe(e, "M-56 0h22M34 0h22"),
      e.append(
        $("path", {
          class: "symbol-muted",
          d: "M-24 -12h48M-24 0h48M-24 12h48",
        }),
      ),
      be(e, -28, 30, 28, -30));
  }
  function me(e) {
    (e.append($("circle", { class: "symbol-fill", cx: 0, cy: -8, r: 28 })),
      fe(e, "M0 20v26"),
      e.append(
        $("path", { class: "symbol-stroke", d: "M0 -8l16 -13M-15 -8h30" }),
      ));
  }
  function ge(e) {
    (e.append($("circle", { class: "symbol-fill", cx: 0, cy: 0, r: 28 })),
      fe(e, "M-54 0h26M28 0h26"),
      ve(e, "Q", 0, 5, 16),
      e.append($("path", { class: "symbol-stroke", d: "M-10 12L14 0-10-12" })));
  }
  function ke(e, t, r, n) {
    (e.append(
      $("rect", {
        class: "symbol-fill",
        x: -t / 2,
        y: -r / 2,
        width: t,
        height: r,
        rx: 4,
      }),
    ),
      e.append(
        $(
          "text",
          { class: "port-label", x: 0, y: 5, "text-anchor": "middle" },
          n,
        ),
      ));
  }
  function Me() {
    const e = u.selected
      ? "component" === u.selected.kind
        ? u.components.find((e) => e.id === u.selected.id) || null
        : ("connection" === u.selected.kind &&
            u.connections.find((e) => e.id === u.selected.id)) ||
          null
      : null;
    ((v.innerHTML = `\n      <div class="rgz-section-title"><h2>02 — Inspector</h2><span class="rgz-badge">client-side</span></div>\n      <div class="rgz-tabs">\n        <button class="rgz-tab ${"properties" === u.inspectorTab ? "active" : ""}" data-tab="properties">Properties</button>\n        <button class="rgz-tab ${"simulation" === u.inspectorTab ? "active" : ""}" data-tab="simulation">Simulation</button>\n        <button class="rgz-tab ${"calculator" === u.inspectorTab ? "active" : ""}" data-tab="calculator">Piping</button>\n      </div>\n      <div id="rgz-inspector-panel"></div>\n    `),
      v.querySelectorAll("[data-tab]").forEach((e) => {
        e.addEventListener("click", () => {
          ((u.inspectorTab = e.dataset.tab), Me());
        });
      }));
    const t = v.querySelector("#rgz-inspector-panel");
    ("properties" === u.inspectorTab &&
      (function (e, t) {
        if (!t)
          return (
            (e.innerHTML = `\n        <div class="rgz-panel">\n          <div class="rgz-panel-title">Project properties</div>\n          ${ze("projectName", "Project name")}\n          ${ze("designer", "Designer")}\n          ${ze("standard", "Print/sketching standard")}\n          ${ze("revision", "Revision")}\n          <div class="rgz-field"><label>Notes</label><textarea data-project-field="notes">${z(u.projectMeta.notes)}</textarea></div>\n          <p>Select a symbol or line to edit its properties. Drag symbols from the left library. Click ports to connect lines.</p>\n        </div>\n        <div class="rgz-panel"><div class="rgz-panel-title">Export and print guarantee</div><p>Printed drawings and RGZ project metadata include ${r}. Encrypted .rgz files are processed in the browser and are not uploaded.</p></div>\n      `),
            void (function (e) {
              e.querySelectorAll("[data-project-field]").forEach((e) => {
                e.addEventListener("input", () => {
                  ((u.projectMeta[e.dataset.projectField] = e.value), _e());
                });
              });
            })(e)
          );
        if ("connection" === u.selected.kind)
          return (
            (e.innerHTML =
              (((n = t).properties = n.properties || {}),
              `\n      <div class="rgz-panel">\n        <div class="rgz-panel-title">Connection line</div>\n        <div class="rgz-kv">\n          <div class="rgz-kv-row"><span>From</span><span>${z(n.from.componentId)}.${z(n.from.portId)}</span></div>\n          <div class="rgz-kv-row"><span>To</span><span>${z(n.to.componentId)}.${z(n.to.portId)}</span></div>\n        </div>\n        <div class="rgz-field"><label>Line type</label><select class="rgz-small-input" data-conn-field="lineType">${["pressure", "return", "pilot", "drain", "electrical"].map((e) => `<option value="${e}" ${n.lineType === e ? "selected" : ""}>${e}</option>`).join("")}</select></div>\n        <div class="rgz-field-grid">\n          <div class="rgz-field"><label>Line color</label><input class="rgz-small-input" type="color" data-conn-prop="color" value="${z(n.properties.color || $e(n.lineType))}" /></div>\n          <div class="rgz-field"><label>Line thickness</label><input class="rgz-small-input" type="number" min="1" max="9" step="0.5" data-conn-prop="strokeWidth" value="${z(n.properties.strokeWidth ?? 3)}" /></div>\n        </div>\n        <div class="rgz-field"><label>Line shape</label><select class="rgz-small-input" data-conn-prop="routeMode">${["auto", "horizontal-first", "vertical-first", "straight"].map((e) => `<option value="${e}" ${n.properties.routeMode === e ? "selected" : ""}>${e}</option>`).join("")}</select></div>\n        <div class="rgz-field"><label>Manual shift / offset</label><input class="rgz-small-input" type="range" min="-120" max="120" step="5" data-conn-prop="shift" value="${z(n.properties.shift ?? 0)}" /></div>\n        <div class="rgz-field-grid">\n          <div class="rgz-field"><label>Tube/hose ID, mm</label><input class="rgz-small-input" type="number" step="0.1" data-conn-prop="tubeIdMm" value="${z(n.properties.tubeIdMm ?? 12)}" /></div>\n          <div class="rgz-field"><label>Length, m</label><input class="rgz-small-input" type="number" step="0.1" data-conn-prop="lengthM" value="${z(n.properties.lengthM ?? 1)}" /></div>\n        </div>\n        <div class="rgz-field"><label>Max pressure, bar</label><input class="rgz-small-input" type="number" step="1" data-conn-prop="maxPressureBar" value="${z(n.properties.maxPressureBar ?? 10)}" /></div>\n        <button class="rgz-btn danger" style="width:100%;margin-top:12px" data-action="delete-selected">Delete line</button>\n      </div>\n    `)),
            void (function (e, t) {
              (e.querySelectorAll("[data-conn-field]").forEach((e) => {
                e.addEventListener("change", () => {
                  ((t[e.dataset.connField] = e.value), H());
                });
              }),
                e.querySelectorAll("[data-conn-prop]").forEach((e) => {
                  const r = () => {
                    const r = e.dataset.connProp;
                    ((t.properties[r] =
                      "number" === e.type || "range" === e.type
                        ? P(e.value)
                        : e.value),
                      H());
                  };
                  (e.addEventListener("input", r),
                    e.addEventListener("change", r));
                }));
            })(e, t)
          );
        var n;
        const a = t,
          i = L(a.type),
          o = [
            `<div class="rgz-field"><label>Label</label><input class="rgz-small-input" data-comp-field="label" value="${z(a.label || "")}" /></div>`,
            `<div class="rgz-field-grid"><div class="rgz-field"><label>X</label><input class="rgz-small-input" data-comp-field="x" type="number" value="${P(a.x)}" /></div><div class="rgz-field"><label>Y</label><input class="rgz-small-input" data-comp-field="y" type="number" value="${P(a.y)}" /></div></div>`,
            `<div class="rgz-field"><label>Rotation</label><input class="rgz-small-input" data-comp-field="rotation" type="number" step="90" value="${P(a.rotation)}" /></div>`,
          ];
        ((i.propSchema || []).forEach((e) => o.push(Se(a, e))),
          (e.innerHTML = `\n      <div class="rgz-panel">\n        <div class="rgz-panel-title">${z(i.name)}</div>\n        <p>${z(i.desc)}</p>\n        ${o.join("")}\n        <div class="rgz-field-grid" style="margin-top:12px">\n          <button class="rgz-btn" data-action="rotate-selected-ccw">Rotate -90°</button>\n          <button class="rgz-btn" data-action="rotate-selected">Rotate +90°</button>\n          <button class="rgz-btn" data-action="duplicate-selected">Duplicate</button>\n          <button class="rgz-btn danger" data-action="delete-selected">Delete</button>\n        </div>\n      </div>\n      <div class="rgz-panel">\n        <div class="rgz-panel-title">Ports</div>\n        <div class="rgz-kv">${T(
            a,
          )
            .map(
              (e) =>
                `<div class="rgz-kv-row"><span>${z(e.id)}</span><span>${z(e.kind)}${e.required ? " · required" : ""}</span></div>`,
            )
            .join("")}</div>\n      </div>\n    `),
          Ae(e, a));
      })(t, e),
      "simulation" === u.inspectorTab &&
        (function (e) {
          const t = u.sim.metrics || {},
            r = t.cylinders || [],
            n = t.motors || [],
            a = t.warnings || [];
          ((e.innerHTML = `\n      <div class="rgz-panel">\n        <div class="rgz-panel-title">Simulation engine</div>\n        <div class="rgz-kv">\n          <div class="rgz-kv-row"><span>Status</span><span>${u.sim.running ? "Running" : "Idle"}</span></div>\n          <div class="rgz-kv-row"><span>Time</span><span>${u.sim.time.toFixed(2)} s</span></div>\n          <div class="rgz-kv-row"><span>Time scale</span><span>${P(u.sim.timeScale, 1).toFixed(2)}×</span></div>\n          <div class="rgz-kv-row"><span>Solver</span><span>Browser Web Worker + SVG animation</span></div>\n          <div class="rgz-kv-row"><span>Compressor flow</span><span>${P(t.totalFlowLpm, 0).toFixed(1)} L/min</span></div>\n          <div class="rgz-kv-row"><span>Active circuit flow</span><span>${P(t.activeFlowLpm, 0).toFixed(1)} L/min</span></div>\n          <div class="rgz-kv-row"><span>Estimated pressure</span><span>${P(t.pressureBar, 0).toFixed(1)} bar</span></div>\n          <div class="rgz-kv-row"><span>Pneumatic power</span><span>${P(t.powerKw, 0).toFixed(2)} kW</span></div>\n        </div>\n        <p>This V1 solver estimates flow, pressure state, cylinder speed/force, line velocity and pressure-drop risk. It runs on the user's CPU, not the server.</p>\n      </div>\n      <div class="rgz-panel">\n        <div class="rgz-panel-title">Time scale</div>\n        <div class="rgz-field-grid">\n          <div class="rgz-field"><label>Speed multiplier, 0.00–3.00</label><input class="rgz-small-input" type="range" min="0" max="3" step="0.01" data-time-scale value="${P(u.sim.timeScale, 1)}" /></div>\n          <div class="rgz-field"><label>Current scale</label><input class="rgz-small-input" type="number" min="0" max="3" step="0.01" data-time-scale value="${P(u.sim.timeScale, 1).toFixed(2)}" /></div>\n        </div>\n        <p>1.00× is real time. Use values below 1.00 for slow motion and above 1.00 for faster simulation. 0.00 pauses motion without stopping simulation.</p>\n      </div>\n      <div class="rgz-panel">\n        <div class="rgz-panel-title">Actuator states</div>\n        <div class="rgz-kv">\n          ${r.length ? r.map((e) => `<div class="rgz-kv-row"><span>${z(e.label)}</span><span>${P(e.speedMmS).toFixed(1)} mm/s · ${P(e.forceKN).toFixed(1)} kN</span></div>`).join("") : ""}\n          ${n.length ? n.map((e) => `<div class="rgz-kv-row"><span>${z(e.label)}</span><span>${P(e.flowLpm).toFixed(1)} L/min · ${P(e.rpm).toFixed(0)} rpm</span></div>`).join("") : ""}\n          ${r.length || n.length ? "" : '<div class="rgz-message info">No actuator metrics yet. Start simulation with a valid circuit.</div>'}\n        </div>\n      </div>\n      <div class="rgz-panel">\n        <div class="rgz-panel-title">Control console</div>\n        ${(function () {
            const e = [];
            return (
              u.components.forEach((t) => {
                if (C(t)) {
                  const r = [
                    "left",
                    ...(3 === Number(t.props.positions || 3) ? ["center"] : []),
                    "right",
                  ]
                    .map(
                      (e) =>
                        `<button class="rgz-btn ${t.props.spoolState === e ? "primary" : ""}" data-control-kind="valve" data-id="${z(t.id)}" data-value="${e}">${e}</button>`,
                    )
                    .join("");
                  e.push(
                    `<div class="rgz-message info"><strong>${z(t.label || t.id)} — valve spool</strong><div class="rgz-field-grid" style="margin-top:8px">${r}</div></div>`,
                  );
                }
                ("pushButton" === t.type &&
                  e.push(
                    `<div class="rgz-message info"><strong>${z(t.label || t.id)} — push button</strong><button class="rgz-btn ${t.props.pressed ? "primary" : ""}" style="width:100%;margin-top:8px" data-control-kind="pushButton" data-id="${z(t.id)}">${t.props.pressed ? "Release button" : "Push button"}</button></div>`,
                  ),
                  "plc" === t.type &&
                    e.push(
                      `<div class="rgz-message info"><strong>${z(t.label || t.id)} — PLC program</strong><div style="font-size:11px;line-height:1.55;margin-top:6px">Rungs separated by <code>;</code><br><b>Latched rule</b>: <code>COND -&gt; TARGET VALUE</code> &nbsp;e.g. <code>PB1 AND NOT B1 -&gt; V1 left</code><br><b>Combinatorial</b>: <code>OUT = COND</code> &nbsp;e.g. <code>Q1 = PB1 OR Q1 AND NOT B1</code> (seal-in; cleared when false)<br>Signals = component labels/ids (PB1, B1, PS1, K1…); <code>I1..I4/Q1..Q4</code> = wired pins. Terms: <code>NOT AND , &amp; OR |</code>. Values: valves <code>left/right/center</code> (extend/retract/stop), coils &amp; relays <code>on/off</code>, timers <code>start/reset</code> (term true after its delay). Coils drive valves: odd digit &rarr; left, even &rarr; right (Y1/Y2). PLC valve rungs override coils.</div></div>`,
                    ),
                  "solenoid" === t.type &&
                    e.push(
                      `<div class="rgz-message info"><strong>${z(t.label || t.id)} — solenoid coil</strong><button class="rgz-btn ${t.props.energized ? "primary" : ""}" style="width:100%;margin-top:8px" data-control-kind="solenoid" data-id="${z(t.id)}">${t.props.energized ? "De-energize" : "Energize"}</button></div>`,
                    ),
                  [
                    "limitSwitch",
                    "cylinderReedSensor",
                    "linearPositionSensor",
                    "proximitySensor",
                    "inductiveSensor",
                    "capacitiveSensor",
                    "opticalSensor",
                    "pressureSwitch",
                    "pressureTransducer",
                    "flowSwitch",
                    "temperatureSwitch",
                    "levelSwitch",
                  ].includes(t.type) &&
                    e.push(
                      `<div class="rgz-message ${t.props.active ? "ok" : "info"}"><strong>${z(t.label || t.id)} — sensor feedback</strong><br>Status: ${t.props.active ? "ACTIVE" : "inactive"}${t.props.action && "none" !== t.props.action ? `<br>Action: ${z(t.props.action)} ${t.props.targetControl ? "→ " + z(t.props.targetControl) : ""}` : ""}</div>`,
                    ));
              }),
              e.length
                ? e.join("")
                : '<div class="rgz-message info"><strong>No controllable equipment</strong><br>Add a directional valve, push button, solenoid, or feedback sensor to use live controls.</div>'
            );
          })()}\n        <p>Use these controls during simulation. Double-click any equipment on the canvas to edit its real-world characteristics.</p>\n      </div>\n      <div class="rgz-panel">\n        <div class="rgz-panel-title">Advanced simulation warnings</div>\n        ${a.length ? a.map((e) => `<div class="rgz-message warning"><strong>Warning</strong><br>${z(e)}</div>`).join("") : '<div class="rgz-message ok"><strong>OK</strong><br>No advanced solver warnings.</div>'}\n      </div>\n      <div class="rgz-disclaimer">Disclaimer: results are approximate and suitable for educational/preliminary design only. Validate final systems with qualified engineering review and applicable standards.</div>\n    `),
            (function (e) {
              e.querySelectorAll("[data-time-scale]").forEach((t) => {
                (t.addEventListener("input", () => {
                  const r = S(P(t.value, 1), 0, 3);
                  ((u.sim.timeScale = r),
                    e.querySelectorAll("[data-time-scale]").forEach((e) => {
                      e !== t &&
                        (e.value = "number" === e.type ? r.toFixed(2) : r);
                    }));
                }),
                  t.addEventListener("change", () => {
                    const e = S(P(t.value, 1), 0, 3);
                    ((u.sim.timeScale = e),
                      (t.value = "number" === t.type ? e.toFixed(2) : e));
                  }));
              });
            })(e));
        })(t),
      "calculator" === u.inspectorTab &&
        (function (e) {
          const t = (function () {
            const e = Math.max(1e-6, P(u.calc.flowLpm, 0) / 6e4),
              t = Math.max(0.01, P(u.calc.velocityMps, Te(u.calc.lineType))),
              r = 1e3 * Math.sqrt((4 * e) / (Math.PI * t)),
              n = [4, 5, 6, 8, 10, 12, 13, 16, 19, 20, 25, 32, 38, 50, 63, 75],
              a = n.find((e) => e >= r) || n[n.length - 1],
              i = Math.max(0.001, P(u.calc.diameterMm, a) / 1e3),
              o = e / ((Math.PI * i * i) / 4),
              s = P(u.calc.densityKgM3, 870),
              l = 1e-6 * P(u.calc.viscosityCSt, 46),
              c = (o * i) / Math.max(l, 1e-9);
            let p;
            p = c < 2300 ? 64 / Math.max(c, 1) : 0.3164 / Math.pow(c, 0.25);
            const d =
                (((p * Math.max(0, P(u.calc.lengthM, 1))) / i +
                  Math.max(0, P(u.calc.fittingK, 0))) *
                  ((s * o * o) / 2)) /
                1e5,
              m = [],
              g = {
                suction: { min: 0.6, max: 1.2 },
                return: { min: 1.5, max: 3 },
                pressure: { min: 3, max: 6 },
                drain: { min: 0.5, max: 2 },
                pilot: { min: 0.5, max: 3 },
              }[u.calc.lineType] || { min: 1, max: 6 };
            return (
              o > g.max &&
                m.push({
                  type: "warning",
                  text: `Velocity is higher than the recommended ${g.min}–${g.max} m/s range for ${u.calc.lineType} lines.`,
                }),
              o < g.min &&
                m.push({
                  type: "info",
                  text: `Velocity is below the usual ${g.min}–${g.max} m/s range; the line may be oversized but pressure drop will be lower.`,
                }),
              d > 5 &&
                m.push({
                  type: "warning",
                  text: "Estimated pressure drop is high. Increase ID, reduce length, or reduce fitting losses.",
                }),
              m.length ||
                m.push({
                  type: "ok",
                  text: "Sizing looks reasonable for preliminary design.",
                }),
              {
                recommendedDiameterMm: r,
                nearestStandardMm: a,
                actualVelocityMps: o,
                reynolds: c,
                pressureDropBar: d,
                messages: m,
              }
            );
          })();
          ((e.innerHTML = `\n      <div class="rgz-panel">\n        <div class="rgz-panel-title">Pipe / hose sizing calculator</div>\n        <div class="rgz-field-grid">\n          ${Be("flowLpm", "Flow, L/min", 0.1)}\n          <div class="rgz-field"><label>Line type</label><select class="rgz-small-input" data-calc="lineType">${["suction", "pressure", "return", "drain", "pilot"].map((e) => `<option value="${e}" ${u.calc.lineType === e ? "selected" : ""}>${e}</option>`).join("")}</select></div>\n          ${Be("velocityMps", "Target velocity, m/s", 0.1)}\n          ${Be("diameterMm", "Candidate ID, mm", 0.1)}\n          ${Be("lengthM", "Length, m", 0.1)}\n          ${Be("fittingK", "Fittings K total", 0.1)}\n          ${Be("densityKgM3", "Air density, kg/m³", 1)}\n          ${Be("viscosityCSt", "Viscosity, cSt", 0.1)}\n        </div>\n        <div class="rgz-kv">\n          <div class="rgz-kv-row"><span>Recommended ID</span><span>${t.recommendedDiameterMm.toFixed(1)} mm</span></div>\n          <div class="rgz-kv-row"><span>Nearest standard ID</span><span>${t.nearestStandardMm} mm</span></div>\n          <div class="rgz-kv-row"><span>Actual velocity</span><span>${t.actualVelocityMps.toFixed(2)} m/s</span></div>\n          <div class="rgz-kv-row"><span>Reynolds number</span><span>${Math.round(t.reynolds).toLocaleString()}</span></div>\n          <div class="rgz-kv-row"><span>Estimated Δp</span><span>${t.pressureDropBar.toFixed(3)} bar</span></div>\n        </div>\n        ${t.messages.map((e) => `<div class="rgz-message ${e.type}"><strong>${e.type.toUpperCase()}</strong><br>${z(e.text)}</div>`).join("")}\n        <p>Formula: Q = A × v. Pressure drop uses Darcy-Weisbach with a simplified friction-factor estimate.</p>\n      </div>\n    `),
            e.querySelectorAll("[data-calc]").forEach((e) => {
              e.addEventListener("input", () => {
                const t = e.dataset.calc;
                ((u.calc[t] = "number" === e.type ? P(e.value) : e.value),
                  "lineType" === t &&
                    (u.calc.velocityMps = Te(u.calc.lineType)),
                  Me());
              });
            }));
        })(t));
  }
  function ze(e, t) {
    return `<div class="rgz-field"><label>${z(t)}</label><input class="rgz-small-input" data-project-field="${e}" value="${z(u.projectMeta[e] || "")}" /></div>`;
  }
  function Se(e, t) {
    const r = e.props[t.key];
    if ("select" === t.type)
      return `<div class="rgz-field"><label>${z(t.label)}</label><select class="rgz-small-input" data-prop-field="${t.key}">${t.options.map((e) => `<option value="${z(e)}" ${String(r) === String(e) ? "selected" : ""}>${z(e)}</option>`).join("")}</select></div>`;
    if ("checkbox" === t.type)
      return `<div class="rgz-field"><label><input type="checkbox" data-prop-field="${t.key}" ${r ? "checked" : ""} /> ${z(t.label)}</label></div>`;
    if ("textarea" === t.type)
      return `<div class="rgz-field"><label>${z(t.label)}</label><textarea data-prop-field="${t.key}"${t.placeholder ? ` placeholder="${z(t.placeholder)}"` : ""}>${z(r || "")}</textarea></div>`;
    const n =
        "number" === t.type ? "number" : "color" === t.type ? "color" : "text",
      a = [
        void 0 !== t.min ? `min="${t.min}"` : "",
        void 0 !== t.max ? `max="${t.max}"` : "",
        void 0 !== t.step ? `step="${t.step}"` : "",
      ].join(" ");
    return `<div class="rgz-field"><label>${z(t.label)}</label><input class="rgz-small-input" type="${n}" ${a} data-prop-field="${t.key}" value="${z(r ?? "")}" /></div>`;
  }
  function Ae(e, t) {
    (e.querySelectorAll("[data-comp-field]").forEach((e) => {
      e.addEventListener("input", () => {
        const r = e.dataset.compField;
        ((t[r] = ["x", "y", "rotation"].includes(r) ? P(e.value) : e.value),
          ("x" !== r && "y" !== r) || (t[r] = A(t[r])),
          H());
      });
    }),
      e.querySelectorAll("[data-prop-field]").forEach((e) => {
        const r = () => {
          const r = e.dataset.propField;
          ("checkbox" === e.type
            ? (t.props[r] = e.checked)
            : "number" === e.type
              ? (t.props[r] = P(e.value))
              : (t.props[r] = e.value),
            "valveType" === r &&
              (function (e) {
                if (!C(e)) return;
                const t = s[e.props.valveType];
                t && Object.assign(e.props, t);
              })(t),
            H());
        };
        (e.addEventListener("input", r),
          e.addEventListener("change", () => {
            (r(), C(t) && H());
          }));
      }));
  }
  function Pe(e) {
    const t = u.components.find((t) => t.id === e);
    if (!t) return;
    const r = L(t.type),
      a = n.querySelector(".rgz-modal-backdrop");
    a && a.remove();
    const i = [
        `<div class="rgz-field"><label>Visible label</label><input class="rgz-small-input" data-comp-field="label" value="${z(t.label || "")}" /></div>`,
        `<div class="rgz-field-grid"><div class="rgz-field"><label>X position</label><input class="rgz-small-input" data-comp-field="x" type="number" value="${P(t.x)}" /></div><div class="rgz-field"><label>Y position</label><input class="rgz-small-input" data-comp-field="y" type="number" value="${P(t.y)}" /></div></div>`,
        `<div class="rgz-field"><label>Rotation, degrees</label><input class="rgz-small-input" data-comp-field="rotation" type="number" step="90" value="${P(t.rotation)}" /></div>`,
        ...(r.propSchema || []).map((e) => Se(t, e)),
      ],
      o = document.createElement("div");
    ((o.className = "rgz-modal-backdrop"),
      (o.innerHTML = `\n      <div class="rgz-modal" role="dialog" aria-modal="true" aria-label="Component characteristics">\n        <div class="rgz-modal-head">\n          <div><h3>${z(r.name)}</h3><p>${z(r.desc || "")}</p></div>\n          <button class="rgz-btn icon" data-modal-close>×</button>\n        </div>\n        <div class="rgz-modal-body">\n          <div class="rgz-panel">\n            <div class="rgz-panel-title">Real-world editable characteristics</div>\n            ${i.join("")}\n          </div>\n          <div class="rgz-panel">\n            <div class="rgz-panel-title">Technical identity</div>\n            <div class="rgz-kv">\n              <div class="rgz-kv-row"><span>Component ID</span><span>${z(t.id)}</span></div>\n              <div class="rgz-kv-row"><span>Symbol type</span><span>${z(r.baseType || t.type)}</span></div>\n              <div class="rgz-kv-row"><span>Library item</span><span>${z(r.name)}</span></div>\n            </div>\n          </div>\n          <div class="rgz-panel">\n            <div class="rgz-panel-title">Ports</div>\n            <div class="rgz-kv">${T(
        t,
      )
        .map(
          (e) =>
            `<div class="rgz-kv-row"><span>${z(e.id)}</span><span>${z(e.kind)}${e.required ? " · required" : ""}</span></div>`,
        )
        .join(
          "",
        )}</div>\n          </div>\n        </div>\n        <div class="rgz-modal-foot">\n          <span>Double-click any equipment to edit these characteristics.</span>\n          <button class="rgz-btn primary" data-modal-close>Done</button>\n        </div>\n      </div>\n    `),
      n.appendChild(o),
      Ae(o, t),
      o.addEventListener("click", (e) => {
        (e.target === o || e.target.closest("[data-modal-close]")) &&
          (o.remove(), Me());
      }));
  }
  function $e(e) {
    return (
      {
        pressure: "#93c5fd",
        return: "#a7f3d0",
        pilot: "#fbbf24",
        drain: "#c4b5fd",
        electrical: "#f0abfc",
      }[e] || "#d9e7ff"
    );
  }
  function Le(e) {
    const t = e.dataset.id,
      r = e.dataset.controlKind,
      n = u.components.find((e) => e.id === t);
    n &&
      ("valve" === r && (n.props.spoolState = e.dataset.value),
      "pushButton" === r && (n.props.pressed = !n.props.pressed),
      "solenoid" === r && (n.props.energized = !n.props.energized),
      H(),
      "simulation" === u.inspectorTab && Me());
  }
  function Ce() {
    const e = document.getElementById("rgz-mobile-live-controls");
    if (!e) return;
    if (!u.sim.running)
      return (
        (e.innerHTML = ""),
        (e._lastHtml = ""),
        void e.classList.remove("active")
      );
    const t = u.components.filter((e) => C(e)),
      r = [];
    (t.forEach((e) => {
      const t = [
        "left",
        ...(3 === Number(e.props.positions || 3) ? ["center"] : []),
        "right",
      ]
        .map(
          (t) =>
            `<button class="rgz-btn ${e.props.spoolState === t ? "primary" : ""}" data-control-kind="valve" data-id="${z(e.id)}" data-value="${t}">${t}</button>`,
        )
        .join("");
      r.push(
        `<div class="rgz-mobile-control-row"><strong>${z(e.label || e.id)}</strong><span>${t}</span></div>`,
      );
    }),
      u.components
        .filter((e) => "pushButton" === e.type || "solenoid" === e.type)
        .forEach((e) => {
          const t =
            "pushButton" === e.type ? e.props.pressed : e.props.energized;
          r.push(
            `<div class="rgz-mobile-control-row"><strong>${z(e.label || e.id)}</strong><span><button class="rgz-btn ${t ? "primary" : ""}" data-control-kind="${e.type}" data-id="${z(e.id)}">${t ? "ON" : "OFF"}</button></span></div>`,
          );
        }));
    const n = `<div class="rgz-mobile-live-head"><strong>Live controls · ${P(u.sim.timeScale, 1).toFixed(2)}×</strong><button class="rgz-btn danger" data-action="stop">Stop</button></div>${r.length ? r.join("") : '<div class="rgz-message info">No valves or live controls in this circuit.</div>'}`;
    (e._lastHtml !== n && ((e.innerHTML = n), (e._lastHtml = n)),
      e.classList.add("active"));
  }
  function Be(e, t, r) {
    return `<div class="rgz-field"><label>${z(t)}</label><input class="rgz-small-input" type="number" step="${r}" data-calc="${e}" value="${z(u.calc[e])}" /></div>`;
  }
  function Te(e) {
    return (
      { suction: 0.9, return: 2.2, pressure: 4, drain: 1.2, pilot: 1.5 }[e] || 4
    );
  }
  function Ee(e = !0) {
    const t = [],
      r = (e, r, n, a = "") =>
        t.push({ severity: e, title: r, detail: n, fix: a }),
      n = u.components,
      a = u.connections;
    (n.length ||
      r(
        "error",
        "Empty drawing",
        "No pneumatic components exist in the project.",
        "Drag symbols from the library or load one of the 15 examples.",
      ),
      n.some((e) => "exhaust" === e.type || "powerPack" === e.type) ||
        r(
          "error",
          "Missing air source/service unit",
          "A pneumatic circuit normally requires a compressed-air source or service unit.",
          "Add a compressed-air service unit or compressor source.",
        ),
      n.some(
        (e) =>
          "compressorFixed" === e.type ||
          "compressorVariable" === e.type ||
          "powerPack" === e.type,
      ) ||
        r(
          "error",
          "Missing compressor",
          "No compressed-air source was found.",
          "Add an air compressor or compressed-air service unit.",
        ),
      n.forEach((e) => {
        (e.label ||
          r(
            "warning",
            "Unlabeled component",
            `${e.id} has no visible label.`,
            "Add a component label in the inspector.",
          ),
          T(e).forEach((t) => {
            t.required &&
              !Ve(e.id, t.id) &&
              r(
                "error",
                "Required port is open",
                `${e.label || e.id}.${t.id} is not connected.`,
                "Connect this port or change the component configuration.",
              );
          }),
          "compressorFixed" !== e.type ||
            n.some((e) => "reliefValve" === e.type || "powerPack" === e.type) ||
            r(
              "error",
              "Compressor without pressure regulation",
              `${e.label || e.id} is a compressor but no pressure regulation/safety valve exists.`,
              "Add a regulator/safety valve, or use a compressed-air service unit with internal regulation.",
            ),
          "cylinderDA" === e.type &&
            ((Ve(e.id, "A") && Ve(e.id, "B")) ||
              r(
                "error",
                "Double-acting cylinder incomplete",
                `${e.label || e.id} requires both A and B lines.`,
                "Connect both cylinder ports to a directional valve.",
              )),
          "pilotCheckValve" !== e.type ||
            Ve(e.id, "X") ||
            r(
              "warning",
              "Pilot line missing",
              `${e.label || e.id} will not release without a pilot line.`,
              "Connect pilot port X.",
            ),
          "counterbalanceValve" !== e.type ||
            Ve(e.id, "X") ||
            r(
              "warning",
              "Quick exhaust / pilot line note",
              `${e.label || e.id} normally needs an external pilot line.`,
              "Connect pilot port X from the opposite cylinder line.",
            ));
      }),
      a.forEach((e) => {
        const t = E(e.from.componentId, e.from.portId),
          n = E(e.to.componentId, e.to.portId);
        t && n
          ? t.kind === n.kind ||
            ("pilot" === t.kind && "pneumatic" === n.kind) ||
            ("pneumatic" === t.kind && "pilot" === n.kind) ||
            r(
              "error",
              "Incompatible line types",
              `${e.id} connects ${t.kind} to ${n.kind}.`,
              "Use pneumatic-to-pneumatic, pilot-to-pilot/pneumatic, or electrical-to-electrical connections.",
            )
          : r(
              "error",
              "Broken connection",
              `${e.id} references a component or port that no longer exists.`,
              "Delete and redraw this connection.",
            );
      }),
      n
        .filter(
          (e) =>
            "compressorFixed" === e.type ||
            "compressorVariable" === e.type ||
            "powerPack" === e.type,
        )
        .forEach((e) => {
          "powerPack" !== e.type &&
            (qe(e.id, "S", "exhaust") ||
              r(
                "warning",
                "Compressor inlet/service source note",
                `${e.label || e.id} inlet/source path is not represented in this simplified checker.`,
                "This may be acceptable for plant-air supply; otherwise add air source conditioning.",
              ));
        }),
      n
        .filter((e) => "reliefValve" === e.type)
        .forEach((e) => {
          qe(e.id, "T", "exhaust") ||
            qe(e.id, "T", "powerPack") ||
            r(
              "error",
              "Relief/regulator exhaust port issue",
              `${e.label || e.id}.T is not connected to exhaust.`,
              "Connect exhaust/relief port to atmosphere/silencer or service unit exhaust.",
            );
        }),
      n.some(
        (e) =>
          "pressureGauge" === e.type ||
          ("powerPack" === e.type && e.props.pressureGauge),
      )
        ? r(
            "info",
            "Instrumentation found",
            "A pressure gauge exists in the circuit or inside the compressed-air service unit. Good practice for compressor/service-unit outlet monitoring.",
          )
        : r(
            "warning",
            "No pressure gauge",
            "No pressure gauge was found.",
            "Add a gauge near the service-unit outlet or enable the service-unit gauge.",
          ),
      n.some((e) => "frlUnit" === e.type || "powerPack" === e.type) ||
        r(
          "warning",
          "Missing air preparation / FRL",
          "Festo basic pneumatics emphasizes clean, dry and regulated air before valves and actuators.",
          "Add an FRL unit or use the compressed-air service unit block.",
        ),
      n.some(
        (e) =>
          "compressorFixed" === e.type ||
          "compressorVariable" === e.type ||
          "powerPack" === e.type,
      ) &&
        !n.some((e) => "accumulator" === e.type || "powerPack" === e.type) &&
        r(
          "info",
          "Receiver/buffer recommended",
          "A receiver helps buffer pressure fluctuations and air demand.",
          "Add an air receiver/buffer tank for larger systems.",
        ),
      n.some((e) => C(e) && 5 === Number(e.props.ports || 0)) &&
        !n.some((e) => "silencer" === e.type || "powerPack" === e.type) &&
        r(
          "warning",
          "Exhaust silencing recommended",
          "Pneumatic valves exhaust air to atmosphere; silencers reduce noise and contamination.",
          "Add exhaust silencers/mufflers on R/S/T exhaust ports.",
        ),
      n.some((e) => "cylinderDA" === e.type || "cylinderSA" === e.type) &&
        !n.some(
          (e) => "flowControl" === e.type || "quickExhaustValve" === e.type,
        ) &&
        r(
          "warning",
          "Cylinder speed not controlled",
          "Pneumatic cylinder speed should normally be controlled with one-way flow controls, typically meter-out for smooth motion.",
          "Add one-way speed controls or a quick exhaust valve as appropriate.",
        ),
      n.some(
        (e) =>
          "solenoid" === e.type ||
          (C(e) &&
            String(e.props.leftActuation + e.props.rightActuation).includes(
              "solenoid",
            )),
      ) &&
        !n.some((e) => "powerSupply24V" === e.type || "plc" === e.type) &&
        r(
          "info",
          "Electrical supply documentation recommended",
          "Electropneumatic systems should document 24 V DC supply, terminals and signal control section.",
          "Add 24 V DC power supply and terminal strip/PLC blocks.",
        ),
      n
        .filter(
          (e) =>
            "powerPack" === e.type ||
            "frlUnit" === e.type ||
            "compressedAirDistributor" === e.type,
        )
        .forEach((e) => {
          P(
            e.props.reliefSettingBar ??
              e.props.regulatorBar ??
              e.props.pressureBar,
            6,
          ) > 8 &&
            r(
              "warning",
              "High pneumatic working pressure",
              `${e.label || e.id} is set above typical 4–8 bar training/industrial practice.`,
              "Use around 6 bar unless the component data requires more.",
            );
        }));
    const i = t.filter((e) => "error" === e.severity).length;
    return (
      (t.length && i) ||
        i ||
        t.unshift({
          severity: "ok",
          title: "Circuit check passed",
          detail:
            "No blocking schematic errors were detected. Simulation is enabled.",
          fix: "",
        }),
      (u.messages = t),
      Ie(),
      e &&
        ct(
          i
            ? `Check finished with ${i} blocking error(s).`
            : "Check passed. You can simulate this circuit.",
          i ? "error" : "ok",
        ),
      t
    );
  }
  function Ve(e, t) {
    return u.connections.some(
      (r) =>
        (r.from.componentId === e && r.from.portId === t) ||
        (r.to.componentId === e && r.to.portId === t),
    );
  }
  function qe(e, t, r) {
    return u.connections.some((n) => {
      let a = null;
      return (
        n.from.componentId === e &&
          n.from.portId === t &&
          (a = n.to.componentId),
        n.to.componentId === e && n.to.portId === t && (a = n.from.componentId),
        a && u.components.find((e) => e.id === a)?.type === r
      );
    });
  }
  function Ie() {
    b &&
      (u.messages.length
        ? (b.innerHTML = u.messages
            .map((e) => {
              return `\n      <div class="rgz-message ${e.severity}"><strong>${((t = e.severity), { error: "⛔", warning: "⚠️", info: "ℹ️", ok: "✅" }[t] || "•")} ${z(e.title)}</strong><br>${z(e.detail)}${e.fix ? `<br><em>Fix: ${z(e.fix)}</em>` : ""}</div>\n    `;
              var t;
            })
            .join(""))
        : (b.innerHTML =
            '<div class="rgz-message info"><strong>Ready</strong><br>No messages. Press “Check circuit” to validate the schematic.</div>'));
  }
  function De() {
    (u.sim.raf && cancelAnimationFrame(u.sim.raf),
      (u.sim.raf = null),
      (u.sim.running = !1),
      Fe(),
      H(),
      Ce(),
      Me());
  }
  // ---------- user-defined simulation charts ----------
  function chartApi() {
    return (
      u.__rgzCharts ||
      (u.__rgzCharts = rgzChartsFactory({
        root: n,
        state: u,
        toast: ct,
        fluid: "air",
        name: "pneumatic",
      }))
    );
  }
  // ---------- electrical scan engine: PLC rungs + solenoid->valve drive ----------
  // Runs once per sim tick (before the fluid solve) and replaces the old
  // decorative behaviour: refreshes signal states, evaluates every PLC
  // program rung, then lets energized coils drive their valves. Deleting the
  // PLC from an electro-hydraulic example therefore REALLY stops the
  // sequence — the bare coil/valve hardware has no logic of its own.
  function rgzElectricalScan() {
    const comps = u.components,
      conns = u.connections,
      plcs = comps.filter((c) => "plc" === c.type),
      sols = comps.filter((c) => "solenoid" === c.type);
    if (!plcs.length && !sols.length) return;
    const lc = (s) => String(null == s ? "" : s).trim().toLowerCase(),
      findComp = (nm) => {
        const k = lc(nm);
        return k
          ? comps.find((c) => lc(c.id) === k || lc(c.label) === k) || null
          : null;
      },
      timerDone = (c) =>
        Number.isFinite(c.props.__t) &&
        u.sim.time - c.props.__t >= Math.max(0, P(c.props.delayS, 1)),
      sigState = (c) => {
        if (!c || !c.props) return false;
        const pr = c.props,
          nc = "NC" === String(pr.contact || "NO").toUpperCase();
        let raw;
        ("pushButton" === c.type
          ? (raw = !!pr.pressed)
          : "emergencyStop" === c.type
            ? (raw = !pr.pressed) // safety contact: healthy (not pressed) = true
            : "solenoid" === c.type || "electricalRelay" === c.type
              ? (raw = !!pr.energized)
              : "relayContact" === c.type
                ? (raw = !!pr.closed)
                : "timerRelay" === c.type
                  ? (raw = timerDone(c))
                  : (raw = !!pr.active));
        return nc ? !raw : !!raw;
      },
      wiredPin = (c, portId) => {
        const out = [];
        for (const cn of conns) {
          if (!cn || "electrical" !== cn.lineType) continue;
          const f = cn.from || {},
            g = cn.to || {};
          if (f.componentId === c.id && f.portId === portId) {
            const o = comps.find((x) => x.id === g.componentId);
            o && o.id !== c.id && out.push(o);
          } else if (g.componentId === c.id && g.portId === portId) {
            const o = comps.find((x) => x.id === f.componentId);
            o && o.id !== c.id && out.push(o);
          }
        }
        return out;
      },
      isValve = (c) => C(c) || "pneumaticMemoryValve" === c.type,
      plcValveWrites = new Set(),
      coilDesired = new Map(),
      coilOwned = new Set(),
      setTimer = (c, on) => {
        (on
          ? Number.isFinite(c.props.__t) || (c.props.__t = u.sim.time)
          : (c.props.__t = null),
          (c.props.active = Number.isFinite(c.props.__t) || timerDone(c)));
      },
      PASSIVE_WORDS = {
        off: 1, false: 1, 0: 1, "de-energize": 1, deenergize: 1, reset: 1,
        stop: 1, center: 1, centre: 1, right: 1, retract: 1, open: 1,
      },
      wordActive = (v) => !PASSIVE_WORDS[v],
      writeValve = (v, val) => {
        plcValveWrites.add(v.id);
        const three = 3 === Number(v.props.positions || 3);
        ("left" === val || "extend" === val || "on" === val
          ? (v.props.spoolState = "left")
          : "right" === val || "retract" === val
            ? (v.props.spoolState = "right")
            : ("center" === val || "centre" === val || "stop" === val || "off" === val) &&
              (v.props.spoolState = three ? "center" : "right"));
      },
      applyTarget = (pl, tgt, val, qPins) => {
        const pinM = /^q([1-4])$/i.exec(tgt);
        if (pinM) return void (qPins["Q" + pinM[1]] = wordActive(lc(val)));
        const c = findComp(tgt);
        if (!c) return;
        const v = lc(val);
        (isValve(c)
          ? writeValve(c, v)
          : "solenoid" === c.type || "electricalRelay" === c.type
            ? (coilOwned.add(c.id), coilDesired.set(c.id, wordActive(v)))
            : "timerRelay" === c.type
              ? (coilOwned.add(c.id), setTimer(c, /^(start|on|true|1|energize|extend|left)$/.test(v)))
              : "energized" in Object(c.props || {})
                ? (coilOwned.add(c.id), coilDesired.set(c.id, wordActive(v))) // solenoid-operated cartridges etc.
                : void 0);
      };
    plcs.forEach((pl) => {
      const qPins = {},
        stmts = String(pl.props.program || "")
          .replace(/^\s*[A-Za-z][\w .+\/\-]{0,48}:\s*/, "") // optional leading TITLE:
          .split(/[;\n]+/)
          .map((s) => s.replace(/(\/\/|#).*$/, "").trim())
          .filter(Boolean),
        pinVal = (nm) => wiredPin(pl, nm.toUpperCase()).some((o) => sigState(o)),
        evalCond = (src) =>
          src.split(/\s+OR\s+|\|+/i).some((br) => {
            const terms = br
              .split(/\s+AND\s+|&+|,+/i)
              .map((s) => s.trim())
              .filter(Boolean);
            return (
              !!terms.length &&
              terms.every((tm) => {
                const neg = /^\s*(NOT\b|!)/.test(tm),
                  nm = tm.replace(/^\s*(NOT\b|!)\s*/, "").trim();
                let v;
                (/^I[1-4]$/i.test(nm) || /^Q[1-4]$/i.test(nm)
                  ? (v = pinVal(nm))
                  : /^(ON|TRUE|1)$/i.test(nm)
                    ? (v = true)
                    : /^(OFF|FALSE|0)$/i.test(nm)
                      ? (v = false)
                      : (v = sigState(findComp(nm))));
                return neg ? !v : v;
              })
            );
          });
      // ownership pre-pass: coils/relays/timers named as ANY rule target are
      // PLC-driven combinatorial outputs (default OFF when no rung drives them)
      stmts.forEach((st) => {
        const m1 = /^([A-Za-z][\w.+\-]*)\s*=/.exec(st),
          m2 = /->\s*([A-Za-z][\w.+\-]*)/.exec(st),
          tn = m1 ? m1[1] : m2 ? m2[1] : null;
        if (tn && !/^[IQ][1-4]$/i.test(tn)) {
          const c = findComp(tn);
          c &&
            ("solenoid" === c.type ||
              "electricalRelay" === c.type ||
              "timerRelay" === c.type ||
              "energized" in Object(c.props || {})) &&
            coilOwned.add(c.id);
        }
      });
      stmts.forEach((st) => {
        let m = /^(.+?)\s*->\s*([A-Za-z][\w.+\-]*)\s*([A-Za-z][\w\-]*)?$/.exec(st);
        if (m) {
          if (evalCond(m[1])) applyTarget(pl, m[2], m[3] || "on", qPins);
          return;
        }
        m = /^([A-Za-z][\w.+\-]*)\s*=\s*(.+)$/.exec(st);
        if (m) {
          const on = evalCond(m[2]);
          if (/^Q[1-4]$/i.test(m[1])) qPins[m[1].toUpperCase()] = on;
          else {
            const c = findComp(m[1]);
            c &&
              (isValve(c)
                ? writeValve(c, on ? "left" : "stop")
                : "solenoid" === c.type || "electricalRelay" === c.type
                  ? (coilOwned.add(c.id), coilDesired.set(c.id, on))
                  : "timerRelay" === c.type && setTimer(c, on));
          }
        }
      });
      // flush Q pins through the real wires (edge-triggered for timers)
      const prevQ = (pl.props.__q = pl.props.__q || {});
      Object.keys(qPins).forEach((pin) => {
        const v = !!qPins[pin];
        wiredPin(pl, pin).forEach((o) => {
          ("solenoid" === o.type || "electricalRelay" === o.type
            ? (coilOwned.add(o.id), coilDesired.set(o.id, v))
            : "timerRelay" === o.type
              ? v !== !!prevQ[pin] && setTimer(o, v)
              : "energized" in Object(o.props || {})
                ? (coilOwned.add(o.id), coilDesired.set(o.id, v))
                : isValve(o) && writeValve(o, v ? "left" : "stop"));
        });
        prevQ[pin] = v;
      });
    });
    // combinatorial coil flush
    coilOwned.forEach((id) => {
      const c = comps.find((x) => x.id === id);
      c &&
        ("solenoid" === c.type ||
          "electricalRelay" === c.type ||
          ("timerRelay" !== c.type && "energized" in Object(c.props || {}))) &&
        (c.props.energized = !!coilDesired.get(id));
    });
    // ---------- solenoid -> valve drive ----------
    // A coil drives a valve when it is bound (targetControl), PLC-driven, or
    // electrically wired (single-valve circuits auto-map). Coil labels ending
    // in an odd digit drive LEFT, even digit RIGHT (Y1/Y2 convention); a
    // digitless pair maps first-found -> left. PLC valve rungs override coils.
    const valves = comps.filter((e) => isValve(e));
    if (valves.length && sols.length) {
      const buckets = new Map(),
        bucketOf = (v) => {
          let b = buckets.get(v.id);
          if (!b) buckets.set(v.id, (b = { left: [], right: [] }));
          return b;
        };
      sols.forEach((s) => {
        let v = null;
        const tc = lc(s.props.targetControl);
        tc && (v = valves.find((x) => lc(x.id) === tc || lc(x.label) === tc) || null);
        const wired = conns.some(
          (cn) =>
            cn &&
            "electrical" === cn.lineType &&
            ((cn.from || {}).componentId === s.id ||
              (cn.to || {}).componentId === s.id),
        );
        if (!tc && !wired && !coilDesired.has(s.id) && !coilOwned.has(s.id))
          return; // decorative loose coil: leave the valve manual
        if (!v) {
          if (1 === valves.length) v = valves[0];
          else return;
        }
        const b = bucketOf(v),
          la = String(v.props.leftActuation || ""),
          ra = String(v.props.rightActuation || ""),
          SOL = (x) => /solenoid|electrical/i.test(x);
        let side;
        if (SOL(la) && !SOL(ra)) side = "left";           // single electrical side drives there
        else if (SOL(ra) && !SOL(la)) side = "right";
        else {
          const nm = String(s.label || s.id || ""),
            d = /(\d+)\s*$/.exec(nm);
          side = d
            ? parseInt(d[1], 10) % 2
              ? "left"
              : "right"
            : b.left.length && !b.right.length
              ? "right"
              : "left";
        }
        b[side].push(s);
      });
      buckets.forEach((b, vid) => {
        if (plcValveWrites.has(vid)) return;
        const v = comps.find((x) => x.id === vid);
        if (!v) return;
        const three = 3 === Number(v.props.positions || 3),
          springLeft = /spring/i.test(String(v.props.leftActuation || "")),
          l = b.left.some((s) => !!s.props.energized),
          r = b.right.some((s) => !!s.props.energized);
        (l && !r
          ? (v.props.spoolState = "left")
          : r && !l
            ? (v.props.spoolState = "right")
            : l ||
              r ||
              (v.props.spoolState = three ? "center" : springLeft ? "left" : "right"));
      });
    }
  }
  function Re(e) {
    if (!u.sim.running) return;
    const t =
      S((e - u.sim.last) / 1e3, 0, 0.08) * S(P(u.sim.timeScale, 1), 0, 3);
    ((u.sim.last = e),
      (u.sim.time += t),
            rgzElectricalScan(),
      (function (e) {
        window.matchMedia("(max-width: 920px)").matches
          ? (u.sim.metrics = Ne(u.components, u.connections, e, u.sim.time))
          : u.sim.worker && !u.sim.workerBusy
            ? ((u.sim.workerBusy = !0),
              u.sim.worker.postMessage({
                components: u.components,
                connections: u.connections,
                dt: e,
                time: u.sim.time,
              }))
            : u.sim.worker ||
              (u.sim.metrics = Ne(u.components, u.connections, e, u.sim.time));
      })(t),
      (function (e) {
        const t =
            u.sim.metrics || Ne(u.components, u.connections, e, u.sim.time),
          r = new Map((t.cylinders || []).map((e) => [e.id, e])),
          n = new Map((t.motors || []).map((e) => [e.id, e])),
          o = new Map((t.accumulators || []).map((e) => [e.id, e]));
        (u.components.forEach((t) => {
          if ("cylinderDA" === t.type || "cylinderSA" === t.type) {
            const n = r.get(t.id),
              a = Math.max(1, P(t.props.strokeMm, 500)),
              i = ((n ? n.speedMmS : 0) / a) * e;
            t.props.simPosition = S(P(t.props.simPosition, 0.2) + i, 0, 1);
          }
          if ("pneumaticMotor" === t.type) {
            const r = n.get(t.id),
              a = Math.max(0, P(r ? r.flowLpm : 0, 0)),
              i = P(r ? r.rpm : 0, 0);
            a > 0.05 &&
              Math.abs(i) > 0.1 &&
              (t.props.simAngle =
                P(t.props.simAngle, 0) + (i / 60) * 2 * Math.PI * e);
          }
          if ("accumulator" === t.type) {
            const a2 = o.get(t.id),
              c2 = Math.max(0.5, P(t.props.volumeL, 5));
            a2 &&
              (t.props.simChargeL = S(
                P(t.props.simChargeL, 0) + (P(a2.flowLpm, 0) * e) / 60,
                0,
                0.98 * c2,
              ));
          }
        }),
          (function (e = {}) {
            const t = [
              "limitSwitch",
              "cylinderReedSensor",
              "linearPositionSensor",
              "proximitySensor",
              "inductiveSensor",
              "capacitiveSensor",
              "opticalSensor",
              "pressureSwitch",
              "pressureTransducer",
              "flowSwitch",
              "temperatureSwitch",
              "levelSwitch",
            ];
            u.components
              .filter((e) => t.includes(e.type))
              .forEach((t) => {
                const r = (function (e, t = {}) {
                  const tcv2 = (t.comp && t.comp[e.id]) || null;
                  if ("pressureSwitch" === e.type) {
                    const pv2 =
                        tcv2 && Number.isFinite(tcv2.pressureBar)
                          ? tcv2.pressureBar
                          : P(t.pressureBar, 0),
                      sw2 = P(e.props.switchBar, 999999);
                    // Schmitt: picks up at switchBar, drops out 5% below (real switch hysteresis)
                    return e.props.active ? pv2 > 0.95 * sw2 : pv2 >= sw2;
                  }
                  if ("pressureTransducer" === e.type)
                    return (
                      (tcv2 && Number.isFinite(tcv2.pressureBar)
                        ? tcv2.pressureBar
                        : P(t.pressureBar, 0)) > 1
                    );
                  if ("flowSwitch" === e.type)
                    return (
                      (tcv2 && Number.isFinite(tcv2.flowLpm)
                        ? tcv2.flowLpm
                        : P(t.activeFlowLpm ?? t.totalFlowLpm, 0)) >=
                      P(e.props.switchLpm, 0)
                    );
                  if ("temperatureSwitch" === e.type) {
                    const tt2 = Number.isFinite(t.oilTempC)
                        ? t.oilTempC
                        : P(t.oilTempC, 20),
                      sw3 = P(e.props.switchTempC, 60);
                    return e.props.active ? tt2 > sw3 - 2 : tt2 >= sw3;
                  }
                  if ("levelSwitch" === e.type) return !!e.props.active;
                  const r = je(e);
                  if (!r) return !1;
                  const n = S(P(r.props.simPosition, 0), 0, 1),
                    a = e.props.triggerAt || "custom",
                    was = !!e.props.active,
                    tp2 = S(P(e.props.triggerPosition, 0.5), 0, 1);
                  // Schmitt-style bands: a switch that picked up stays ON until
                  // the actuator leaves the neighbourhood (no flicker at edges).
                  return "retracted" === a
                    ? was
                      ? n <= 0.08
                      : n <= 0.02
                    : "extended" === a
                      ? was
                        ? n >= 0.92
                        : n >= 0.98
                      : "middle" === a
                        ? Math.abs(n - tp2) <= 0.08
                        : was
                          ? n >= tp2 - 0.05
                          : n >= tp2;
                })(t, e);
                ((t.props.active = r),
                  r &&
                    (function (e) {
                      const t = e.props.action || "none";
                      if ("none" === t) return;
                      const r = (function (e, t) {
                        const r = String(e || "")
                            .trim()
                            .toLowerCase(),
                          n = u.components.filter(
                            (e) => C(e) || "solenoid" === e.type,
                          );
                        if (r) {
                          const e = n.find(
                            (e) =>
                              String(e.id).toLowerCase() === r ||
                              String(e.label || "").toLowerCase() === r,
                          );
                          if (e) return e;
                        }
                        return t.startsWith("set valve")
                          ? n.find((e) => C(e)) || null
                          : (t.includes("solenoid") &&
                              n.find((e) => "solenoid" === e.type)) ||
                              null;
                      })(e.props.targetControl, t);
                      r &&
                        ("set valve left" === t &&
                          C(r) &&
                          (r.props.spoolState = "left"),
                        "set valve center" === t &&
                          C(r) &&
                          (r.props.spoolState = "center"),
                        "set valve right" === t &&
                          C(r) &&
                          (r.props.spoolState = "right"),
                        "energize solenoid" === t &&
                          "solenoid" === r.type &&
                          (r.props.energized = !0),
                        "de-energize solenoid" === t &&
                          "solenoid" === r.type &&
                          (r.props.energized = !1));
                    })(t));
              });
          })(t));
      })(t));
    u.sim.metrics && chartApi().rec();
    const r = window.matchMedia("(max-width: 920px)").matches,
      n = r ? 180 : 90;
    ((!u.sim.lastCanvasRender || e - u.sim.lastCanvasRender > n) &&
      ((u.sim.lastCanvasRender = e), H()),
      e - u.sim.lastPanelRender > (r ? 1e3 : 500) &&
        ((u.sim.lastPanelRender = e), "simulation" === u.inspectorTab && Me()),
      (u.sim.raf = requestAnimationFrame(Re)));
  }
  function je(e) {
    const t = String(e.props.linkedActuator || "")
        .trim()
        .toLowerCase(),
      r = u.components.filter(
        (e) => "cylinderDA" === e.type || "cylinderSA" === e.type,
      );
    if (t) {
      const e = r.find(
        (e) =>
          String(e.id).toLowerCase() === t ||
          String(e.label || "").toLowerCase() === t,
      );
      if (e) return e;
    }
    return r.length
      ? r
          .slice()
          .sort(
            (t, r) =>
              Math.hypot(t.x - e.x, t.y - e.y) -
              Math.hypot(r.x - e.x, r.y - e.y),
          )[0]
      : null;
  }
  function Fe() {
    x &&
      (x.classList.toggle("running", u.sim.running),
      (document.getElementById("rgz-sim-status").textContent = u.sim.running
        ? `Running · ${u.sim.time.toFixed(1)} s`
        : "Idle"),
      n.querySelectorAll('[data-action="simulate"]').forEach((e) => {
        e.disabled = u.sim.running;
      }),
      n.querySelectorAll('[data-action="stop"]').forEach((e) => {
        e.disabled = !u.sim.running;
      }),
      n
        .querySelectorAll('[data-action="toggle-live-controls"]')
        .forEach((e) => {
          e.disabled = !u.sim.running;
        }));
  }
  function Ne(e, t, r, n) {
    return Oe(e, t, r, n);
  }
  function Oe(e, t, r, n) {
    return rgzFluidSolve({
      fluid: "air",
      components: e,
      connections: t,
      dt: r,
      time: n,
    });
  }
  function Ue() {
    ((u.printArea = M(u.viewBox)),
      H(),
      ct(
        "Print area set from current view. Pan/zoom first, then press this button to define another area.",
        "ok",
      ));
  }
  function He() {
    ((u.printArea = null),
      H(),
      ct("Print area cleared. Printing will use the whole drawing.", "info"));
  }
  function Ge() {
    const e = n.querySelector(".rgz-modal-backdrop");
    e && e.remove();
    const t = document.createElement("div");
    ((t.className = "rgz-modal-backdrop"),
      (t.innerHTML = `\n      <div class="rgz-modal rgz-print-modal" role="dialog" aria-modal="true" aria-label="Print options">\n        <div class="rgz-modal-head">\n          <div><h3>Print / PDF options</h3><p>The drawing will be forced to fit on one paper with the RGZ title block and watermark.</p></div>\n          <button class="rgz-btn icon" data-modal-close>×</button>\n        </div>\n        <div class="rgz-modal-body">\n          <div class="rgz-panel">\n            <div class="rgz-panel-title">Print range</div>\n            <div class="rgz-field-grid" style="margin-top:10px">\n              <button class="rgz-btn" data-print-area="whole">Whole drawing</button>\n              <button class="rgz-btn ${u.printArea ? "primary" : ""}" data-print-area="selected" ${u.printArea ? "" : "disabled"}>Selected area</button>\n            </div>\n            <div class="rgz-field-grid" style="margin-top:10px">\n              <button class="rgz-btn" data-action="set-print-area">Set area = current view</button>\n              <button class="rgz-btn" data-action="clear-print-area" ${u.printArea ? "" : "disabled"}>Clear area</button>\n            </div>\n            <p>For user-defined one-page printing, zoom/pan to the desired area and click “Set area = current view”.</p>\n          </div>\n          <div class="rgz-panel">\n            <div class="rgz-panel-title">Orientation</div>\n            <div class="rgz-field-grid" style="margin-top:10px">\n              <button class="rgz-btn primary" data-print-orientation="landscape" data-print-pages="1">A4 Landscape</button>\n              <button class="rgz-btn" data-print-orientation="portrait" data-print-pages="1">A4 Portrait</button>\n            </div>\n            <p>One-page output is the default. Multi-page appears only for large circuits.</p>\n          </div>\n          ${
        (function () {
          const e = Ke(0);
          return e.w > 1450 || e.h > 900 || u.components.length > 28;
        })()
          ? '<div class="rgz-panel"><div class="rgz-panel-title">Large-circuit multi-page</div><div class="rgz-field-grid" style="margin-top:10px"><button class="rgz-btn" data-print-orientation="landscape" data-print-pages="2x1">2 pages wide</button><button class="rgz-btn" data-print-orientation="landscape" data-print-pages="2x2">2 × 2 pages</button></div><p>Use only for very large advanced circuits when one-page scaling becomes unreadable.</p></div>'
          : ""
      }\n        </div>\n        <div class="rgz-modal-foot"><span>Non-removable print watermark: HoumanRGZ</span><button class="rgz-btn" data-modal-close>Cancel</button></div>\n      </div>`),
      n.appendChild(t),
      t.addEventListener("click", (e) => {
        const n = e.target.closest("[data-print-area]");
        if (n)
          return (
            (u.printMode = n.dataset.printArea),
            t
              .querySelectorAll("[data-print-area]")
              .forEach((e) => e.classList.remove("primary")),
            void n.classList.add("primary")
          );
        const a = e.target.closest(
          '[data-action="set-print-area"], [data-action="clear-print-area"]',
        );
        if (a)
          return (
            "set-print-area" === a.dataset.action && Ue(),
            "clear-print-area" === a.dataset.action && He(),
            t.remove(),
            void Ge()
          );
        const i = e.target.closest("[data-print-orientation]");
        if (i) {
          const e = i.dataset.printOrientation,
            n = i.dataset.printPages || "1",
            a =
              "selected" === u.printMode && u.printArea ? "selected" : "whole";
          return (
            t.remove(),
            void (function (e = "landscape", t = "whole", n = "1") {
              _e();
              const a = "selected" === t && u.printArea ? u.printArea : Ke(120),
                i = "portrait" === e ? "A4 portrait" : "A4 landscape",
                o = "portrait" === e ? 210 : 297,
                s = "portrait" === e ? 297 : 210,
                l = u.projectMeta,
                c =
                  "2x2" === n
                    ? { cols: 2, rows: 2 }
                    : "2x1" === n
                      ? { cols: 2, rows: 1 }
                      : { cols: 1, rows: 1 };
              function p(e) {
                const t = m.cloneNode(!0);
                (t.setAttribute("viewBox", `${e.x} ${e.y} ${e.w} ${e.h}`),
                  t.setAttribute("width", "100%"),
                  t.setAttribute("height", "100%"),
                  t.setAttribute("preserveAspectRatio", "xMidYMid meet"));
                const r = t.querySelector(".rgz-canvas-bg");
                return (
                  r && r.setAttribute("fill", "#ffffff"),
                  t
                    .querySelectorAll(".selected")
                    .forEach((e) => e.classList.remove("selected")),
                  t
                    .querySelectorAll(".sim-active,.sim-high")
                    .forEach((e) =>
                      e.classList.remove("sim-active", "sim-high"),
                    ),
                  t
                    .querySelectorAll("#rgz-print-area-layer")
                    .forEach((e) => e.remove()),
                  t.outerHTML
                );
              }
              const d = [];
              for (let e = 0; e < c.rows; e++)
                for (let t = 0; t < c.cols; t++) {
                  const n = {
                      x: a.x + (t * a.w) / c.cols,
                      y: a.y + (e * a.h) / c.rows,
                      w: a.w / c.cols,
                      h: a.h / c.rows,
                    },
                    i =
                      c.cols * c.rows > 1
                        ? ` — Page ${e * c.cols + t + 1}/${c.cols * c.rows}`
                        : "";
                  d.push(
                    `<div class="page">\n          <div class="sheet"><div class="watermark">HoumanRGZ</div>${p(n)}</div>\n          <div class="title">\n            <div><strong>Project:</strong> ${z(l.projectName || "Untitled")}${i}</div><div><strong>Designer:</strong> ${z(l.designer || "-")}</div><div><strong>Date:</strong> ${z(new Date().toLocaleDateString())}</div>\n            <div><strong>Standard:</strong> ${z(l.standard || "ISO-style")}</div><div><strong>Revision:</strong> ${z(l.revision || "A")}</div><div><strong>Made in RGZ Pneumatic Studio:</strong> ${z(r)}</div>\n          </div>\n        </div>`,
                  );
                }
              const g = `<!doctype html><html><head><meta charset="utf-8"><title>${z(l.projectName || "RGZ Pneumatic Print")}</title>\n      <style>\n        @page{size:${i};margin:0} *{box-sizing:border-box} html,body{margin:0;padding:0;background:#fff;color:#111;font-family:Arial,sans-serif}.page{width:${o}mm;height:${s}mm;padding:8mm;display:grid;grid-template-rows:minmax(0,1fr) 18mm;overflow:hidden;break-after:page;page-break-after:always;break-inside:avoid;page-break-inside:avoid}.page:last-child{break-after:auto;page-break-after:auto}.sheet{position:relative;min-height:0;border:1px solid #111;overflow:hidden}.sheet svg{position:relative;z-index:1;display:block;width:100%;height:100%}.watermark{position:absolute;z-index:5;inset:0;display:grid;place-items:center;pointer-events:none;font-size:${"portrait" === e ? 58 : 70}px;font-weight:900;letter-spacing:.08em;color:rgba(0,0,0,.09);transform:rotate(-28deg);user-select:none}.title{display:grid;grid-template-columns:2fr 1fr 1fr;border:1px solid #111;border-top:0;font-size:8.5px;line-height:1.15;overflow:hidden}.title>div{padding:3px 5px;border-right:1px solid #111;min-height:9mm;overflow:hidden}.title>div:nth-child(3n){border-right:0}.rgz-canvas-bg{fill:#fff}.rgz-connection-path{fill:none;stroke-width:2.4;stroke-linecap:round;stroke-linejoin:round}.rgz-connection-path.pilot,.rgz-connection-path.drain{stroke-dasharray:7 5}.rgz-connection-path.electrical{stroke-dasharray:10 5 2 5}.symbol-stroke,.symbol-muted,.symbol-accent{stroke:#111!important;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}.symbol-fill{fill:#fff!important;stroke:#111!important;stroke-width:2}.port{fill:#fff!important;stroke:#111!important;stroke-width:2}.port-label,.component-label{fill:#111!important;stroke:#fff!important;stroke-width:3;paint-order:stroke;font-weight:700}.selection-box{display:none}.rgz-readout-bg{fill:#fff!important;stroke:#111!important}.rgz-readout-text{fill:#111!important;font-size:13px;font-weight:900} marker path{fill:#111}@media screen{body{background:#ddd}.page{margin:12px auto;background:white;box-shadow:0 6px 26px rgba(0,0,0,.22)}}\n      </style></head><body>${d.join("")}<script>window.onload=()=>setTimeout(()=>window.print(),250);<\/script></body></html>`,
                h = window.open("", "_blank", "width=1200,height=800");
              h
                ? (h.document.open(), h.document.write(g), h.document.close())
                : ct(
                    "Popup blocked. Please allow popups for the print view.",
                    "warning",
                  );
            })(e, a, n)
          );
        }
        (e.target === t || e.target.closest("[data-modal-close]")) &&
          t.remove();
      }));
  }
  function Ke(e = 100) {
    if (!u.components.length) return { x: 0, y: 0, w: 1200, h: 800 };
    let t = 1 / 0,
      r = 1 / 0,
      n = -1 / 0,
      a = -1 / 0;
    return (
      u.components.forEach((e) => {
        const i = L(e.type) || { w: 100, h: 80 };
        ((t = Math.min(t, e.x - i.w / 2)),
          (n = Math.max(n, e.x + i.w / 2)),
          (r = Math.min(r, e.y - i.h / 2)),
          (a = Math.max(a, e.y + i.h / 2)));
      }),
      {
        x: t - e,
        y: r - e,
        w: Math.max(500, n - t + 2 * e),
        h: Math.max(320, a - r + 2 * e),
      }
    );
  }
  function _e() {
    if (!k) return;
    const e = u.projectMeta;
    k.innerHTML = `\n      <div><strong>Project:</strong> ${z(e.projectName || "Untitled")}</div>\n      <div><strong>Designer:</strong> ${z(e.designer || "-")}</div>\n      <div><strong>Date:</strong> ${new Date().toLocaleDateString()}</div>\n      <div><strong>Standard/template:</strong> ${z(e.standard || "ISO-style")}</div>\n      <div><strong>Revision:</strong> ${z(e.revision || "A")}</div>\n      <div><strong>Made in RGZ Pneumatic Studio:</strong> ${z(r)}</div>\n    `;
  }
  async function Ze(t, r = {}, n = e.authNonce) {
    if (!e.ajaxUrl)
      throw new Error("WordPress AJAX endpoint is not configured.");
    const a = new FormData();
    (a.append("action", t),
      a.append("nonce", n || ""),
      u.accountToken && a.append("token", u.accountToken),
      Object.entries(r).forEach(([e, t]) => a.append(e, null == t ? "" : t)));
    const i = await fetch(e.ajaxUrl, {
        method: "POST",
        body: a,
        credentials: "same-origin",
      }),
      o = await i.json().catch(() => null);
    if (!i.ok || !o || !o.success)
      throw new Error(o?.data?.message || "Request failed.");
    return (
      o.data?.nonces &&
        ((e.authNonce = o.data.nonces.authNonce || e.authNonce),
        (e.saveNonce = o.data.nonces.saveNonce || e.saveNonce)),
      Object.prototype.hasOwnProperty.call(o.data || {}, "token") &&
        ((u.accountToken = o.data.token || ""),
        u.accountToken
          ? localStorage.setItem("rgzPneumaticAccountToken", u.accountToken)
          : localStorage.removeItem("rgzPneumaticAccountToken")),
      Object.prototype.hasOwnProperty.call(o.data || {}, "user") &&
        (u.user = o.data.user || null),
      o.data || {}
    );
  }
  function Xe(t = {}) {
    return new Promise((r) => {
      const a = n.querySelector(".rgz-modal-backdrop");
      a && a.remove();
      const i = document.createElement("div");
      ((i.className = "rgz-modal-backdrop"), n.appendChild(i));
      const o = (e) => {
          (i.remove(), r(e || null));
        },
        s = () => {
          u.user
            ? ((i.innerHTML = `\n            <div class="rgz-modal rgz-auth-modal" role="dialog" aria-modal="true" aria-label="RGZ account">\n              <div class="rgz-modal-head"><div><h3>RGZ Pneumatics account</h3><p>${z(u.user.name)} · ${z(u.user.email)}</p></div><button class="rgz-btn icon" data-modal-close>×</button></div>\n              <div class="rgz-modal-body"><div class="rgz-panel"><div class="rgz-panel-title">My earlier designs</div><div id="rgz-my-designs" class="rgz-design-list"><div class="rgz-message info">Loading designs…</div></div></div></div>\n              <div class="rgz-modal-foot"><button class="rgz-btn" data-auth-logout>Sign out</button><button class="rgz-btn primary" data-modal-done>Continue</button></div>\n            </div>`),
              (async function (e) {
                if (e)
                  try {
                    const t =
                      (await Ze("rgz_pneumatic_my_designs")).designs || [];
                    if (!t.length)
                      return void (e.innerHTML =
                        '<div class="rgz-message info"><strong>No saved designs yet</strong><br>Save/export a sketch and it will appear here.</div>');
                    e.innerHTML = t
                      .map(
                        (e) =>
                          `\n        <div class="rgz-design-row">\n          <div><strong>${z(e.file_name || "pneumatic-project.rgz")}</strong><span>${z(e.created_at || "")} · ${Math.round(Number(e.file_size || 0) / 1024)} KB${e.password_hint ? " · hint: " + z(e.password_hint) : ""}</span></div>\n          <div><button class="rgz-btn" data-design-action="load" data-id="${z(e.id)}">Load</button><button class="rgz-btn" data-design-action="download" data-id="${z(e.id)}">Download</button></div>\n        </div>`,
                      )
                      .join("");
                  } catch (t) {
                    e.innerHTML = `<div class="rgz-message error"><strong>Error</strong><br>${z(t.message)}</div>`;
                  }
              })(i.querySelector("#rgz-my-designs")))
            : (i.innerHTML = `\n            <div class="rgz-modal rgz-auth-modal" role="dialog" aria-modal="true" aria-label="Sign in or sign up">\n              <div class="rgz-modal-head"><div><h3>Sign in to save designs</h3><p>Create an account once, then your encrypted sketches appear under My designs.</p></div><button class="rgz-btn icon" data-modal-close>×</button></div>\n              <div class="rgz-modal-body">\n                <div class="rgz-tabs"><button class="rgz-tab ${"signin" === u.authMode ? "active" : ""}" data-auth-mode="signin">Sign in</button><button class="rgz-tab ${"signup" === u.authMode ? "active" : ""}" data-auth-mode="signup">Easy sign up</button><button class="rgz-tab" data-auth-mode="info">Why?</button></div>\n                ${"signup" === u.authMode ? '\n                  <div class="rgz-panel"><div class="rgz-panel-title">Create account</div><div class="rgz-field"><label>Name</label><input class="rgz-small-input" id="rgz-auth-name" autocomplete="name" /></div><div class="rgz-field"><label>Email</label><input class="rgz-small-input" id="rgz-auth-email" type="email" autocomplete="email" /></div><div class="rgz-field"><label>Password</label><input class="rgz-small-input" id="rgz-auth-password" type="password" autocomplete="new-password" /></div><button class="rgz-btn primary" style="width:100%;margin-top:12px" data-auth-submit="signup">Create account</button></div>' : "info" === u.authMode ? '\n                  <div class="rgz-panel"><div class="rgz-panel-title">Why account?</div><p>Your encrypted designs can be listed, downloaded, and loaded later from your own account. The backend stays organized by user and email.</p><p>Your design encryption password is stored encrypted for administrator/teacher support. Your RGZ account sign-in password is never visible to the site owner.</p></div>' : '\n                  <div class="rgz-panel"><div class="rgz-panel-title">Sign in</div><div class="rgz-field"><label>Email or username</label><input class="rgz-small-input" id="rgz-auth-login" autocomplete="username" /></div><div class="rgz-field"><label>Password</label><input class="rgz-small-input" id="rgz-auth-password" type="password" autocomplete="current-password" /></div><button class="rgz-btn primary" style="width:100%;margin-top:12px" data-auth-submit="signin">Sign in</button></div>'}\n              </div>\n              <div class="rgz-modal-foot"><span>Required before saving encrypted designs.</span><button class="rgz-btn" data-modal-close>Cancel</button></div>\n            </div>`);
        };
      (s(),
        i.addEventListener("click", async (r) => {
          if (r.target === i || r.target.closest("[data-modal-close]"))
            return o(null);
          const n = r.target.closest("[data-auth-mode]");
          if (n) return ((u.authMode = n.dataset.authMode), void s());
          if (r.target.closest("[data-modal-done]")) return o(u.user);
          if (r.target.closest("[data-auth-logout]")) {
            try {
              (await Ze("rgz_pneumatic_logout"),
                (u.user = null),
                (e.user = null),
                s());
            } catch (e) {
              ct(e.message, "error");
            }
            return;
          }
          const a = r.target.closest("[data-auth-submit]");
          if (a)
            try {
              if ("signin" === a.dataset.authSubmit) {
                const e = await Ze("rgz_pneumatic_login", {
                  login: i.querySelector("#rgz-auth-login")?.value || "",
                  password: i.querySelector("#rgz-auth-password")?.value || "",
                });
                u.user = e.user;
              } else {
                const e = await Ze("rgz_pneumatic_register", {
                  name: i.querySelector("#rgz-auth-name")?.value || "",
                  email: i.querySelector("#rgz-auth-email")?.value || "",
                  password: i.querySelector("#rgz-auth-password")?.value || "",
                });
                u.user = e.user;
              }
              if ((ct(`Signed in as ${u.user.name}.`, "ok"), t.required))
                return o(u.user);
              s();
            } catch (e) {
              ct(e.message, "error");
            }
          const l = r.target.closest("[data-design-action]");
          if (l) {
            const e = l.dataset.id,
              t = l.dataset.designAction;
            ("download" === t &&
              (await (async function (e) {
                try {
                  const t = await Qe(e);
                  tt(
                    new Blob([Ye(t.file_base64)], {
                      type: "application/octet-stream",
                    }),
                    t.file_name || "pneumatic-project.rgz",
                  );
                } catch (e) {
                  ct(e.message, "error");
                }
              })(e)),
              "load" === t &&
                (await (async function (e) {
                  try {
                    const t = await Qe(e);
                    await Je(Ye(t.file_base64));
                  } catch (e) {
                    ct(e.message, "error");
                  }
                })(e),
                o(u.user)));
          }
        }));
    });
  }
  async function We() {
    const t = await (async function () {
      return u.user ? u.user : Xe({ required: !0 });
    })();
    if (!t) return;
    const r = await new Promise((e) => {
      const t = n.querySelector(".rgz-modal-backdrop");
      t && t.remove();
      const r = document.createElement("div");
      ((r.className = "rgz-modal-backdrop"),
        (r.innerHTML = `\n        <div class="rgz-modal rgz-auth-modal" role="dialog" aria-modal="true" aria-label="Save encrypted design">\n          <div class="rgz-modal-head"><div><h3>Save encrypted design</h3><p>Signed in as ${z(u.user?.name || "")} · ${z(u.user?.email || "")}</p></div><button class="rgz-btn icon" data-modal-close>×</button></div>\n          <div class="rgz-modal-body">\n            <div class="rgz-panel">\n              <div class="rgz-panel-title">Encryption</div>\n              <div class="rgz-field"><label>Design encryption password</label><input class="rgz-small-input" type="password" id="rgz-save-password" autocomplete="new-password" /></div>\n              <div class="rgz-field"><label>Optional password hint, not the password</label><input class="rgz-small-input" id="rgz-save-hint" placeholder="Example: usual project password" /></div>\n              <p>The .rgz file is encrypted in the browser. For teacher support, the design password is stored encrypted in the RGZ Pneumatics backend and visible only to site administrators.</p>\n            </div>\n          </div>\n          <div class="rgz-modal-foot"><button class="rgz-btn" data-modal-close>Cancel</button><button class="rgz-btn primary" data-save-confirm>Save / Export</button></div>\n        </div>`),
        n.appendChild(r),
        r.querySelector("#rgz-save-password")?.focus(),
        r.addEventListener("click", (t) => {
          if (
            ((t.target === r || t.target.closest("[data-modal-close]")) &&
              (r.remove(), e(null)),
            t.target.closest("[data-save-confirm]"))
          ) {
            const t = r.querySelector("#rgz-save-password")?.value || "",
              n = r.querySelector("#rgz-save-hint")?.value || "";
            if (!t)
              return void ct("Please enter an encryption password.", "warning");
            (r.remove(), e({ password: t, passwordHint: n }));
          }
        }));
    });
    if (!r) return;
    const { password: a, passwordHint: i } = r;
    try {
      u.projectMeta.designer || (u.projectMeta.designer = t.name);
      const r = I();
      ((r.metadata.designer = t.name), (r.metadata.email = t.email));
      const __thumb = __rgzBlueprint(r);
      const n = new TextEncoder().encode(JSON.stringify(r)),
        o = await (async function (e) {
          if ("CompressionStream" in window) {
            const t = new CompressionStream("gzip"),
              r = t.writable.getWriter();
            return (
              r.write(e),
              r.close(),
              {
                bytes: new Uint8Array(
                  await new Response(t.readable).arrayBuffer(),
                ),
                compressed: !0,
              }
            );
          }
          return { bytes: e, compressed: !1 };
        })(n),
        s = crypto.getRandomValues(new Uint8Array(16)),
        l = crypto.getRandomValues(new Uint8Array(12)),
        c = await et(a, s),
        p = new Uint8Array(
          await crypto.subtle.encrypt({ name: "AES-GCM", iv: l }, c, o.bytes),
        ),
        d = new Uint8Array(5 + s.length + l.length + p.length);
      (d.set(new TextEncoder().encode("RGZ1"), 0),
        (d[4] = o.compressed ? 1 : 0),
        d.set(s, 5),
        d.set(l, 21),
        d.set(p, 33));
      const m = `${
        (r.metadata.projectName || "pneumatic-project")
          .replace(/[^a-z0-9-_]+/gi, "-")
          .replace(/^-|-$/g, "")
          .toLowerCase() || "pneumatic-project"
      }.rgz`;
      (tt(new Blob([d], { type: "application/octet-stream" }), m),
        await (async function ({
          bytes: t,
          fileName: r,
          passwordHint: n,
          designPassword: a,
          thumb: __thumb,
        }) {
          const i = Number(e.maxUploadBytes || 524288);
          if (!e.ajaxUrl || !e.saveNonce)
            return void ct(
              "Local export complete. Backend storage is not configured.",
              "warning",
            );
          if (t.byteLength > i)
            return void ct(
              "Local export complete. Backend storage skipped because the .rgz file is larger than 512 KB.",
              "warning",
            );
          const o = new FormData();
          (o.append("action", "rgz_pneumatic_save_design"),
            o.append("nonce", e.saveNonce),
            u.accountToken && o.append("token", u.accountToken),
            o.append("password_hint", n || ""),
            o.append("design_password", a || ""),
            o.append("file_name", r),
            o.append("thumb", __thumb || ""),
            o.append(
              "file_base64",
              (function (e) {
                let t = "";
                for (let r = 0; r < e.length; r += 32768)
                  t += String.fromCharCode.apply(
                    null,
                    e.subarray(r, r + 32768),
                  );
                return btoa(t);
              })(t),
            ));
          const s = await fetch(e.ajaxUrl, {
              method: "POST",
              body: o,
              credentials: "same-origin",
            }),
            l = await s.json().catch(() => null);
          if (!s.ok || !l || !l.success)
            throw new Error(
              l?.data?.message ||
                "The encrypted design could not be stored in RGZ Pneumatics.",
            );
          l.data?.nonces &&
            ((e.authNonce = l.data.nonces.authNonce || e.authNonce),
            (e.saveNonce = l.data.nonces.saveNonce || e.saveNonce));
        })({ bytes: d, fileName: m, passwordHint: i, designPassword: a, thumb: __thumb }),
        ct(
          "Encrypted .rgz file exported and saved to your RGZ Pneumatics account.",
          "ok",
        ));
    } catch (e) {
      ct("Export failed: " + e.message, "error");
    }
  }
  function Ye(e) {
    const t = atob(e),
      r = new Uint8Array(t.length);
    for (let e = 0; e < t.length; e++) r[e] = t.charCodeAt(e);
    return r;
  }
  function __rgzBlueprint(proj) {
    try {
      const comps = (proj.components || []).map((c) => {
        const d = L(c.type) || {};
        return [c.type, Math.round(c.x), Math.round(c.y), c.rotation || 0, d.w || 64, d.h || 64];
      });
      const conns = [];
      (proj.connections || []).forEach((l) => {
        const a = T(l.from.componentId, l.from.portId),
          b = T(l.to.componentId, l.to.portId);
        if (a && b) conns.push([Math.round(a.x), Math.round(a.y), Math.round(b.x), Math.round(b.y), l.lineType || "pressure"]);
      });
      return JSON.stringify({ v: 1, comps, conns });
    } catch (e) { return ""; }
  }
  async function Qe(e) {
    const t = await Ze("rgz_pneumatic_get_design", { id: e });
    if (!t.design?.file_base64) throw new Error("Stored design file is empty.");
    return t.design;
  }
  async function Je(e) {
    const t = window.prompt("Enter the password for this .rgz file:");
    if (t)
      try {
        if ("RGZ1" !== new TextDecoder().decode(e.slice(0, 4)))
          throw new Error("Invalid RGZ file header.");
        const r = 1 === e[4],
          n = e.slice(5, 21),
          a = e.slice(21, 33),
          i = e.slice(33),
          o = await et(t, n),
          s = new Uint8Array(
            await crypto.subtle.decrypt({ name: "AES-GCM", iv: a }, o, i),
          ),
          l = r
            ? await (async function (e) {
                if ("DecompressionStream" in window) {
                  const t = new DecompressionStream("gzip"),
                    r = t.writable.getWriter();
                  return (
                    r.write(e),
                    r.close(),
                    new Uint8Array(await new Response(t.readable).arrayBuffer())
                  );
                }
                throw new Error(
                  "This browser cannot decompress gzip RGZ files. Try a modern Chrome/Edge browser.",
                );
              })(s)
            : s;
        D(JSON.parse(new TextDecoder().decode(l)));
      } catch (e) {
        ct("Import failed. Wrong password or damaged .rgz file.", "error");
      }
  }
  /* Deep link from the Mechanical Deck "My designs": open a saved design directly. */
  (function () {
    let openId = null;
    try {
      const m = (window.location.hash || "").match(/rgz-open=(\d+)/);
      if (m) openId = m[1];
    } catch (e0) {}
    if (!openId) return;
    setTimeout(async () => {
      try {
        if (!u.accountToken) {
          ct("Sign in via the account dialog to open your saved design from the deck.", "warning");
          return;
        }
        const d = await Qe(openId);
        await Je(Ye(d.file_base64));
        ct("Saved design loaded from your deck profile.", "ok");
      } catch (err) {
        ct("Could not open the saved design: " + ((err && err.message) || err), "error");
      }
      try { history.replaceState(null, "", window.location.pathname + window.location.search); } catch (e1) {}
    }, 800);
  })();
  async function et(e, t) {
    const r = await crypto.subtle.importKey(
      "raw",
      new TextEncoder().encode(e),
      "PBKDF2",
      !1,
      ["deriveKey"],
    );
    return crypto.subtle.deriveKey(
      { name: "PBKDF2", salt: t, iterations: 21e4, hash: "SHA-256" },
      r,
      { name: "AES-GCM", length: 256 },
      !1,
      ["encrypt", "decrypt"],
    );
  }
  function tt(e, t) {
    const r = document.createElement("a");
    ((r.href = URL.createObjectURL(e)),
      (r.download = t),
      document.body.appendChild(r),
      r.click(),
      setTimeout(() => {
        (URL.revokeObjectURL(r.href), r.remove());
      }, 500));
  }
  function rt(e = 1) {
    const t = u.viewBox,
      r = t.x + t.w / 2,
      n = t.y + t.h / 2,
      a = S(t.w * e, 300, 5e3),
      i = S(t.h * e, 200, 3500);
    ((u.viewBox = { x: r - a / 2, y: n - i / 2, w: a, h: i }), R());
  }
  function nt(e) {
    const t = `rgz-show-${e}`,
      r = n.classList.contains(t);
    (["rgz-show-library", "rgz-show-actions", "rgz-show-inspector"].forEach(
      (e) => n.classList.remove(e),
    ),
      r || n.classList.add(t));
  }
  function at() {
    const e = window.visualViewport
      ? window.visualViewport.height
      : window.innerHeight;
    document.documentElement.style.setProperty("--rgz-vh", `${e}px`);
  }
  function it() {
    if (
      (at(),
      !window.matchMedia("(max-width: 920px) and (orientation: landscape)")
        .matches || document.fullscreenElement)
    )
      return;
    const e = document.documentElement.requestFullscreen
      ? document.documentElement
      : n;
    (e.requestFullscreen &&
      e.requestFullscreen({ navigationUI: "hide" }).catch(() => {}),
      screen.orientation &&
        screen.orientation.lock &&
        screen.orientation.lock("landscape").catch(() => {}),
      setTimeout(() => window.scrollTo(0, 1), 80));
  }
  function ot(e = 90) {
    if ("component" !== u.selected?.kind)
      return void ct(
        "Select a schematic symbol first, then rotate it.",
        "info",
      );
    const t = u.components.find((e) => e.id === u.selected.id);
    t &&
      ((t.rotation = (((P(t.rotation, 0) + e) % 360) + 360) % 360), H(), Me());
  }
  function st() {
    if (u.selected) {
      if ("component" === u.selected.kind) {
        const e = u.selected.id;
        ((u.components = u.components.filter((t) => t.id !== e)),
          (u.connections = u.connections.filter(
            (t) => t.from.componentId !== e && t.to.componentId !== e,
          )));
      } else
        "connection" === u.selected.kind &&
          (u.connections = u.connections.filter((e) => e.id !== u.selected.id));
      ((u.selected = null), H(), Me());
    }
  }
  function lt() {
    if (!u.components.length)
      return ((u.viewBox = { x: 0, y: 0, w: 1800, h: 1200 }), void R());
    const e = u.components.map((e) => e.x),
      t = u.components.map((e) => e.y),
      r = Math.min(...e) - 220,
      n = Math.max(...e) + 220,
      a = Math.min(...t) - 180,
      i = Math.max(...t) + 180;
    ((u.viewBox = {
      x: r,
      y: a,
      w: Math.max(600, n - r),
      h: Math.max(380, i - a),
    }),
      R());
  }
  function ct(e, t = "info") {
    const r = document.getElementById("rgz-toasts");
    if (!r) return;
    const n = document.createElement("div");
    ((n.className = `rgz-toast ${t}`),
      (n.textContent = e),
      r.appendChild(n),
      setTimeout(() => {
        ((n.style.opacity = "0"), (n.style.transform = "translateY(-6px)"));
      }, 3600),
      setTimeout(() => n.remove(), 4200));
  }
  const pt = [
    "Simple circuits",
    "Intermediate electropneumatic circuits",
    "Advanced real-world class circuits",
  ];
  function dt() {
    const e = [...pt];
    return (
      ht.forEach((t) => {
        t.level && !e.includes(t.level) && e.push(t.level);
      }),
      e
    );
  }
  function ut(e = u.exampleLevel) {
    return ht
      .map((e, t) => Object.assign({ globalIndex: t }, e))
      .filter((t) => t.level === e);
  }
  function mt() {
    const e = document.getElementById("rgz-level-selectbox"),
      t = document.getElementById("rgz-example-selectbox");
    if (!e || !t) return;
    const r = dt();
    r.includes(u.exampleLevel) || (u.exampleLevel = r[0]);
    const n = ut(u.exampleLevel);
    ((u.exampleIndex = Math.floor(
      S(P(u.exampleIndex, 0), 0, Math.max(0, n.length - 1)),
    )),
      (e.innerHTML = r
        .map(
          (e) =>
            `<option value="${z(e)}" ${e === u.exampleLevel ? "selected" : ""}>${z(
              (function (e) {
                return String(e || "")
                  .replace(" electrohydraulic circuits", "")
                  .replace(" electropneumatic circuits", "")
                  .replace(" real-world class circuits", "");
              })(e),
            )}</option>`,
        )
        .join("")),
      (t.innerHTML = n
        .map(
          (e, t) =>
            `<option value="${t}" ${t === u.exampleIndex ? "selected" : ""}>${String(t + 1).padStart(2, "0")} — ${z(e.name)}</option>`,
        )
        .join("")),
      (e.onchange = () => {
        ((u.exampleLevel = e.value), (u.exampleIndex = 0), mt());
        const t = ut(u.exampleLevel)[0],
          r = document.getElementById("rgz-example-preview");
        r && t && (r.textContent = `01 — ${t.name}`);
      }),
      (t.onchange = () => {
        u.exampleIndex = P(t.value, 0);
        const e = ut(u.exampleLevel)[u.exampleIndex],
          r = document.getElementById("rgz-example-preview");
        r &&
          e &&
          (r.textContent = `${String(u.exampleIndex + 1).padStart(2, "0")} — ${e.name}`);
      }));
  }
  function gt() {
    const e = ut(u.exampleLevel),
      t = e[u.exampleIndex] || e[0];
    t &&
      ((u.currentExampleGlobalIndex = t.globalIndex),
      D(yt(t.globalIndex)),
      (u.currentExampleGlobalIndex = t.globalIndex),
      lt());
  }
  const ht = [
    {
      level: "Simple circuits",
      name: "Compressor, receiver, FRL and pressure gauge",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = vt("Compressor, receiver, FRL and pressure gauge"),
          n = ft(t, 0, 430),
          a = t("frlUnit", 520, 408, { regulatorBar: 6, filterMicron: 5 }, "FRL1"),
          i = t(
            "compressedAirDistributor",
            830,
            408,
            { outlets: 3, pressureBar: 6 },
            "DIST1",
          );
        return (
          r(n.compressor, "P", a, "P", "pressure"),
          r(a, "A", i, "P", "pressure"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Single-acting cylinder with 3/2 valve",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = vt("Single-acting cylinder with 3/2 valve"),
          n = ft(t),
          a = t(
            "directionalValve",
            620,
            420,
            {
              ports: "3",
              positions: "2",
              center: "closed",
              spoolState: "left",
              leftActuation: "manual",
              rightActuation: "spring",
            },
            "V1",
          ),
          i = t(
            "cylinderSA",
            880,
            330,
            { boreMm: 50, strokeMm: 300, loadKg: 100 },
            "C1",
          );
        return (
          r(n.compressor, "P", a, "P", "pressure"),
          r(a, "T", n.exhaust, "T", "return"),
          r(a, "A", i, "A", "pressure"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Double-acting cylinder with 5/2 valve + end sensors",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = vt("Double-acting cylinder with 5/2 valve + end sensors"),
          n = ft(t),
          a = t(
            "directionalValve",
            620,
            420,
            {
              ports: "5",
              positions: "2",
              spoolState: "left",
              leftActuation: "solenoid",
              rightActuation: "solenoid",
            },
            "V1",
          ),
          i = t(
            "cylinderDA",
            900,
            330,
            { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 350 },
            "C1",
          );
        return (
          t(
            "cylinderReedSensor",
            900,
            230,
            {
              linkedActuator: "C1",
              triggerAt: "extended",
              action: "set valve right",
              targetControl: "V1",
            },
            "B1-EXT",
          ),
          t(
            "cylinderReedSensor",
            900,
            430,
            {
              linkedActuator: "C1",
              triggerAt: "retracted",
              action: "set valve left",
              targetControl: "V1",
            },
            "B2-RET",
          ),
          r(n.compressor, "P", a, "P", "pressure"),
          r(a, "T", n.exhaust, "T", "return"),
          r(a, "A", i, "A", "pressure"),
          r(a, "B", i, "B", "return"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Double-acting cylinder with 5/3 closed center",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = vt("Double-acting cylinder with 5/3 closed center"),
          n = ft(t),
          a = t(
            "directionalValve",
            620,
            420,
            {
              ports: "5",
              positions: "3",
              center: "closed",
              spoolState: "left",
              leftActuation: "solenoid",
              rightActuation: "solenoid",
            },
            "V1",
          ),
          i = t(
            "cylinderDA",
            900,
            330,
            { boreMm: 80, rodMm: 45, strokeMm: 600, loadKg: 550 },
            "C1",
          );
        return (
          r(n.compressor, "P", a, "P", "pressure"),
          r(a, "T", n.exhaust, "T", "return"),
          r(a, "A", i, "A", "pressure"),
          r(a, "B", i, "B", "return"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Double-acting cylinder with 5/3 exhaust center",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = vt("Double-acting cylinder with 5/3 exhaust center"),
          n = ft(t),
          a = t(
            "directionalValve",
            620,
            420,
            {
              ports: "5",
              positions: "3",
              center: "float",
              spoolState: "center",
              leftActuation: "solenoid",
              rightActuation: "solenoid",
            },
            "V1",
          ),
          i = t(
            "cylinderDA",
            900,
            330,
            { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 350 },
            "C1",
          );
        return (
          r(n.compressor, "P", a, "P", "pressure"),
          r(a, "T", n.exhaust, "T", "return"),
          r(a, "A", i, "A", "pressure"),
          r(a, "B", i, "B", "return"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Meter-in pneumatic speed control",
      builder: function () {
        const { project: e, add: t, connect: r } = vt("Meter-in speed control"),
          n = ft(t),
          a = t(
            "directionalValve",
            610,
            420,
            {
              ports: "5",
              positions: "3",
              center: "closed",
              spoolState: "left",
            },
            "V1",
          ),
          i = t("flowControl", 780, 310, { openingPercent: 45 }, "FC1"),
          o = t(
            "cylinderDA",
            980,
            310,
            { boreMm: 63, rodMm: 36, strokeMm: 450, loadKg: 250 },
            "C1",
          );
        return (
          r(n.compressor, "P", a, "P", "pressure"),
          r(a, "T", n.exhaust, "T", "return"),
          r(a, "A", i, "A", "pressure"),
          r(i, "B", o, "A", "pressure"),
          r(a, "B", o, "B", "return"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Meter-out pneumatic speed control",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = vt("Meter-out speed control"),
          n = ft(t),
          a = t(
            "directionalValve",
            610,
            420,
            {
              ports: "5",
              positions: "3",
              center: "closed",
              spoolState: "left",
            },
            "V1",
          ),
          i = t("flowControl", 790, 455, { openingPercent: 38 }, "FC1"),
          o = t(
            "cylinderDA",
            980,
            310,
            { boreMm: 63, rodMm: 36, strokeMm: 450, loadKg: 250 },
            "C1",
          );
        return (
          r(n.compressor, "P", a, "P", "pressure"),
          r(a, "T", n.exhaust, "T", "return"),
          r(a, "A", o, "A", "pressure"),
          r(o, "B", i, "A", "return"),
          r(i, "B", a, "B", "return"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Quick exhaust fast cylinder extension",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = vt("Quick exhaust fast cylinder extension"),
          n = ft(t),
          a = t(
            "directionalValve",
            610,
            420,
            {
              ports: "5",
              positions: "3",
              center: "closed",
              spoolState: "left",
            },
            "V1",
          ),
          i = t("quickExhaustValve", 790, 305, { exhaustCv: 1.6 }, "QE1"),
          o = t(
            "cylinderDA",
            990,
            310,
            { boreMm: 80, rodMm: 50, strokeMm: 500, loadKg: 180 },
            "C1",
          );
        return (
          r(n.compressor, "P", a, "P", "pressure"),
          r(a, "T", n.exhaust, "T", "return"),
          r(a, "A", i, "P", "pressure"),
          r(i, "A", o, "A", "pressure"),
          r(i, "R", n.exhaust, "T", "return", { shift: 35 }),
          r(a, "B", o, "B", "return"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Pneumatic sequence clamp-and-work circuit",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = vt("Sequence valve clamp-and-work circuit"),
          n = ft(t),
          a = t(
            "directionalValve",
            570,
            440,
            {
              ports: "5",
              positions: "3",
              center: "closed",
              spoolState: "left",
            },
            "V1",
          ),
          i = t(
            "cylinderDA",
            840,
            260,
            { boreMm: 50, rodMm: 28, strokeMm: 250, loadKg: 150 },
            "Clamp",
          ),
          o = t("sequenceValve", 780, 430, { settingBar: 4.5 }, "SV1"),
          s = t(
            "cylinderDA",
            1040,
            430,
            { boreMm: 80, rodMm: 45, strokeMm: 400, loadKg: 500 },
            "Work",
          ),
          l = t("checkValve", 780, 560, { crackingBar: 0.3 }, "CV1");
        return (
          (l.rotation = 180),
          r(n.compressor, "P", a, "P", "pressure"),
          r(a, "T", n.exhaust, "T", "return"),
          r(a, "A", i, "A", "pressure"),
          r(a, "A", o, "P", "pressure"),
          r(o, "A", s, "A", "pressure"),
          r(s, "A", l, "A", "pressure"),
          r(l, "B", o, "P", "pressure"),
          r(i, "B", a, "B", "return"),
          r(s, "B", a, "B", "return"),
          r(o, "T", n.exhaust, "T", "drain"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Pressure regulator branch circuit",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = vt("Pressure reducing branch circuit"),
          n = ft(t),
          a = t(
            "directionalValve",
            570,
            440,
            {
              ports: "5",
              positions: "3",
              center: "closed",
              spoolState: "left",
            },
            "V1",
          ),
          i = t("reducingValve", 770, 295, { outletBar: 4 }, "PRV1"),
          o = t(
            "cylinderDA",
            1e3,
            285,
            { boreMm: 50, rodMm: 28, strokeMm: 350, loadKg: 120 },
            "LowP",
          ),
          s = t(
            "cylinderDA",
            1e3,
            500,
            { boreMm: 63, rodMm: 36, strokeMm: 350, loadKg: 280 },
            "Main",
          );
        return (
          r(n.compressor, "P", a, "P", "pressure"),
          r(a, "T", n.exhaust, "T", "return"),
          r(a, "A", i, "P", "pressure"),
          r(i, "A", o, "A", "pressure"),
          r(i, "T", n.exhaust, "T", "drain"),
          r(a, "A", s, "A", "pressure"),
          r(o, "B", a, "B", "return"),
          r(s, "B", a, "B", "return"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Rodless/vertical cylinder air-lock circuit",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = vt("Vertical cylinder air-lock circuit"),
          n = ft(t),
          a = t(
            "directionalValve",
            580,
            440,
            {
              ports: "5",
              positions: "3",
              center: "closed",
              spoolState: "left",
            },
            "V1",
          ),
          i = t(
            "counterbalanceValve",
            810,
            455,
            { settingBar: 5, pilotRatio: 3 },
            "CBV1",
          ),
          o = t(
            "cylinderDA",
            1030,
            330,
            { boreMm: 80, rodMm: 45, strokeMm: 700, loadKg: 800 },
            "Vertical",
          );
        return (
          r(n.compressor, "P", a, "P", "pressure"),
          r(a, "T", n.exhaust, "T", "return"),
          r(a, "A", o, "A", "pressure"),
          r(o, "B", i, "A", "return"),
          r(i, "B", a, "B", "return"),
          r(a, "A", i, "X", "pilot"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Pilot check pneumatic load holding",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = vt("Pilot-operated check valve load holding"),
          n = ft(t),
          a = t(
            "directionalValve",
            580,
            440,
            {
              ports: "5",
              positions: "3",
              center: "closed",
              spoolState: "left",
            },
            "V1",
          ),
          i = t("pilotCheckValve", 800, 310, { pilotRatio: 3 }, "PCV1"),
          o = t(
            "cylinderDA",
            1030,
            330,
            { boreMm: 63, rodMm: 36, strokeMm: 500, loadKg: 150 },
            "C1",
          );
        return (
          r(n.compressor, "P", a, "P", "pressure"),
          r(a, "T", n.exhaust, "T", "return"),
          r(a, "A", i, "A", "pressure"),
          r(i, "B", o, "A", "pressure"),
          r(o, "B", a, "B", "return"),
          r(a, "B", i, "X", "pilot"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Air motor speed control",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = vt("Air motor speed control"),
          n = ft(t),
          a = t(
            "directionalValve",
            570,
            440,
            {
              ports: "5",
              positions: "3",
              center: "closed",
              spoolState: "left",
            },
            "V1",
          ),
          i = t("flowControl", 770, 330, { openingPercent: 60 }, "FC1"),
          o = t(
            "pneumaticMotor",
            980,
            330,
            { displacementCcRev: 25, loadNm: 22 },
            "M1",
          );
        return (
          r(n.compressor, "P", a, "P", "pressure"),
          r(a, "T", n.exhaust, "T", "return"),
          r(a, "A", i, "A", "pressure"),
          r(i, "B", o, "A", "pressure"),
          r(o, "B", a, "B", "return"),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Vacuum ejector and suction cup circuit",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = vt("Vacuum ejector and suction cup circuit"),
          n = ft(t),
          a = t(
            "directionalValve",
            570,
            420,
            {
              ports: "3",
              positions: "2",
              center: "closed",
              spoolState: "left",
              leftActuation: "solenoid",
              rightActuation: "spring",
            },
            "V1",
          ),
          i = t(
            "vacuumEjector",
            790,
            330,
            { vacuumKpa: -65, airConsumptionLpm: 90 },
            "VE1",
          ),
          o = t(
            "suctionCup",
            1e3,
            300,
            { cupDiameterMm: 50, holdingForceN: 120 },
            "CUP1",
          ),
          s = t(
            "pressureTransducer",
            1e3,
            430,
            { rangeBar: 1, signal: "Digital" },
            "VS1",
          );
        return (
          r(n.compressor, "P", a, "P", "pressure"),
          r(a, "A", i, "P", "pressure"),
          r(a, "T", n.exhaust, "T", "return"),
          r(i, "V", o, "V", "pressure", { color: "#38bdf8", shift: -25 }),
          r(i, "R", n.exhaust, "T", "return", { shift: 35 }),
          r(o, "V", s, "P", "pilot", { color: "#f59e0b", shift: 45 }),
          e
        );
      },
    },
    {
      level: "Simple circuits",
      name: "Two-cylinder pneumatic synchronization",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = vt("Flow divider two-cylinder synchronization"),
          n = ft(t),
          a = t(
            "directionalValve",
            560,
            440,
            {
              ports: "5",
              positions: "3",
              center: "closed",
              spoolState: "left",
            },
            "V1",
          ),
          i = t("flowDivider", 760, 340, { splitPercentA: 50 }, "FD1"),
          o = t(
            "cylinderDA",
            1010,
            245,
            { boreMm: 50, rodMm: 28, strokeMm: 400, loadKg: 160 },
            "C1",
          ),
          s = t(
            "cylinderDA",
            1010,
            450,
            { boreMm: 50, rodMm: 28, strokeMm: 400, loadKg: 160 },
            "C2",
          );
        return (
          r(n.compressor, "P", a, "P", "pressure"),
          r(a, "T", n.exhaust, "T", "return"),
          r(a, "A", i, "P", "pressure"),
          r(i, "A", o, "A", "pressure"),
          r(i, "B", s, "A", "pressure"),
          r(o, "B", a, "B", "return"),
          r(s, "B", a, "B", "return"),
          e
        );
      },
    },
    ...[
      "Electropneumatic auto-return cylinder with reed sensors",
      "Two-hand push button clamp circuit",
      "Pressure switch automatic retract circuit",
      "PLC controlled cylinder dwell circuit",
      "Sequential two-cylinder electropneumatic circuit",
      "Motor start/stop with flow switch feedback",
      "Air receiver / buffer tank assisted clamp with pressure switch",
      "Vertical cylinder with limit-switch reversal",
      "Meter-out cylinder with solenoid valve control",
      "Pressure reducing branch with sensor feedback",
      "Fast approach with electric changeover to working speed",
      "Flow divider with dual cylinder end sensors",
      "Pilot check load-hold with emergency release",
      "Temperature alarm and cooler bypass control",
      "Semi-automatic press cycle with PLC I/O",
    ].map((e, t) => ({
      level: "Intermediate electropneumatic circuits",
      name: e,
      builder: () =>
        (function (e, t = 0) {
          if (1 === t)
            return (function (e) {
              const { project: t, add: r, connect: n } = vt(e),
                a = ft(r, 0, 500),
                i = r(
                  "directionalValve",
                  500,
                  380,
                  {
                    valveType: "4/3 closed center",
                    ports: "5",
                    positions: "3",
                    center: "closed",
                    spoolState: "center",
                    leftActuation: "solenoid",
                    rightActuation: "spring",
                  },
                  "V1",
                ),
                o = r(
                  "cylinderDA",
                  910,
                  285,
                  { boreMm: 63, rodMm: 36, strokeMm: 420, loadKg: 320 },
                  "Clamp",
                ),
                s = r(
                  "pressureGauge",
                  330,
                  315,
                  { rangeBar: 10, displayUnit: "bar" },
                  "PG1",
                ),
                l = r(
                  "pressureSwitch",
                  650,
                  520,
                  {
                    switchBar: 5,
                    action: "none",
                    targetControl: "",
                  },
                  "PS1",
                ),
                c = r(
                  "pushButton",
                  275,
                  705,
                  { contact: "NO", pressed: !1 },
                  "PB1",
                ),
                p = r(
                  "pushButton",
                  425,
                  705,
                  { contact: "NO", pressed: !1 },
                  "PB2",
                ),
                d = r(
                  "plc",
                  600,
                  705,
                  {
                    program:
                      "TWO-HAND CLAMP: Q1 = PB1 AND PB2 AND NOT B1 AND NOT PS1",
                    targetControl: "",
                  },
                  "PLC1",
                ),
                u = r(
                  "solenoid",
                  760,
                  705,
                  { voltage: "24 VDC", energized: !1 },
                  "Y1",
                ),
                m = r(
                  "cylinderReedSensor",
                  910,
                  155,
                  {
                    linkedActuator: "Clamp",
                    triggerAt: "extended",
                    action: "none",
                    targetControl: "",
                  },
                  "B1",
                ),
                g = r(
                  "cylinderReedSensor",
                  910,
                  420,
                  {
                    linkedActuator: "Clamp",
                    triggerAt: "retracted",
                    action: "none",
                    targetControl: "",
                  },
                  "B2",
                );
              return (
                n(a.compressor, "P", i, "P", "pressure", {
                  routeMode: "horizontal-first",
                  shift: -30,
                  color: "#ef4444",
                }),
                n(i, "T", a.exhaust, "T", "return", {
                  routeMode: "horizontal-first",
                  shift: 34,
                  color: "#22c55e",
                }),
                n(i, "A", o, "A", "pressure", {
                  routeMode: "horizontal-first",
                  shift: -22,
                  color: "#ef4444",
                }),
                n(i, "B", o, "B", "return", {
                  routeMode: "horizontal-first",
                  shift: 30,
                  color: "#22c55e",
                }),
                n(a.compressor, "P", s, "P", "pressure", {
                  shift: -70,
                  color: "#ef4444",
                }),
                n(i, "A", l, "P", "pressure", {
                  routeMode: "vertical-first",
                  shift: 55,
                  color: "#f59e0b",
                }),
                n(c, "E2", d, "I1", "electrical", {
                  routeMode: "horizontal-first",
                  shift: -15,
                  color: "#d946ef",
                }),
                n(p, "E2", d, "I2", "electrical", {
                  routeMode: "horizontal-first",
                  shift: 15,
                  color: "#d946ef",
                }),
                n(d, "Q1", u, "E1", "electrical", {
                  routeMode: "horizontal-first",
                  color: "#d946ef",
                }),
                n(m, "E1", d, "I1", "electrical", {
                  routeMode: "vertical-first",
                  shift: -50,
                  color: "#d946ef",
                }),
                n(g, "E1", d, "I2", "electrical", {
                  routeMode: "vertical-first",
                  shift: 50,
                  color: "#d946ef",
                }),
                (t.viewBox = { x: 40, y: 70, w: 1120, h: 760 }),
                t
              );
            })(e);
          const { project: r, add: n, connect: a } = vt(e),
            i = ft(n, 0, 500),
            o = n(
              "directionalValve",
              500,
              390,
              {
                ports: "5",
                positions: "3",
                center: "closed",
                spoolState: "left",
                leftActuation: "solenoid",
                rightActuation: "solenoid",
              },
              "V1",
            ),
            s = n(
              "cylinderDA",
              920,
              260,
              { boreMm: 63, rodMm: 36, strokeMm: 450, loadKg: 300 },
              "C1",
            ),
            l = n("plc", 470, 705, { program: "" }, "PLC1");
          (a(i.compressor, "P", o, "P", "pressure", { shift: -20 }),
            a(o, "T", i.exhaust, "T", "return", { shift: 20 }),
            a(o, "A", s, "A", "pressure", {
              routeMode: "horizontal-first",
              shift: -15,
            }),
            a(o, "B", s, "B", "return", {
              routeMode: "horizontal-first",
              shift: 25,
            }));
          const c = (e) =>
            (r.connections = r.connections.filter(
              (t) => !(t.from.componentId === o.id && t.from.portId === e),
            ));
          if (0 === t) {
            l.props.program =
              "AUTO-RETURN: B1 -> V1 right; B2 -> V1 left";
            const e = n(
                "cylinderReedSensor",
                920,
                140,
                {
                  linkedActuator: "C1",
                  triggerAt: "extended",
                  action: "none",
                  targetControl: "",
                },
                "B1",
              ),
              t = n(
                "cylinderReedSensor",
                920,
                395,
                {
                  linkedActuator: "C1",
                  triggerAt: "retracted",
                  action: "none",
                  targetControl: "",
                },
                "B2",
              );
            (a(e, "E1", l, "I1", "electrical", { color: "#d946ef" }),
              a(t, "E1", l, "I2", "electrical", { color: "#d946ef" }));
          } else if (2 === t) {
            l.props.program =
              "PRESSURE CLAMP: PS1 -> V1 right; B2 -> V1 center";
            const e = n(
                "pressureSwitch",
                650,
                520,
                {
                  switchBar: 5,
                  action: "none",
                  targetControl: "",
                },
                "PS1",
              ),
              t = n(
                "cylinderReedSensor",
                920,
                140,
                {
                  linkedActuator: "C1",
                  triggerAt: "extended",
                  action: "none",
                  targetControl: "",
                },
                "B1",
              ),
              u = n(
                "cylinderReedSensor",
                920,
                395,
                {
                  linkedActuator: "C1",
                  triggerAt: "retracted",
                  action: "none",
                  targetControl: "",
                },
                "B2",
              );
            (a(o, "A", e, "P", "pressure", {
              routeMode: "vertical-first",
              shift: 55,
              color: "#f59e0b",
            }),
              a(e, "E", l, "I1", "electrical", { color: "#d946ef" }),
              a(t, "E1", l, "I2", "electrical", { color: "#d946ef" }),
              a(u, "E1", l, "I2", "electrical", { color: "#d946ef" }));
          } else if (3 === t) {
            ((l.props.program =
              "DWELL: Q1 = SB1 OR Q1 AND NOT B1; Q2 = B1 AND NOT B2; Y2 = T1 OR Y2 AND NOT B2; B2 -> T1 reset"),
              (o.props.spoolState = "center"));
            const e = n(
                "pushButton",
                260,
                705,
                { contact: "NO", pressed: !1 },
                "SB1",
              ),
              tmrA = n(
                "timerRelay",
                660,
                560,
                { delayS: 3, mode: "on-delay" },
                "T1",
              ),
              u = n(
                "solenoid",
                820,
                645,
                { voltage: "24 VDC", energized: !1 },
                "Y1",
              ),
              m = n(
                "solenoid",
                820,
                755,
                { voltage: "24 VDC", energized: !1 },
                "Y2",
              ),
              y = n(
                "cylinderReedSensor",
                920,
                140,
                {
                  linkedActuator: "C1",
                  triggerAt: "extended",
                  action: "none",
                  targetControl: "",
                },
                "B1",
              ),
              g = n(
                "cylinderReedSensor",
                920,
                395,
                {
                  linkedActuator: "C1",
                  triggerAt: "retracted",
                  action: "none",
                  targetControl: "",
                },
                "B2",
              );
            (a(e, "E2", l, "I1", "electrical", { color: "#d946ef" }),
              a(y, "E1", l, "I2", "electrical", { color: "#d946ef" }),
              a(l, "Q1", u, "E1", "electrical", { color: "#d946ef" }),
              a(l, "Q2", tmrA, "IN", "electrical", { color: "#d946ef" }),
              a(tmrA, "OUT", m, "E1", "electrical", { color: "#d946ef" }));
          } else if (4 === t) {
            l.props.program =
              "SEQUENCE: B1 -> V1 right; B2 -> V1 center";
            const e = n("sequenceValve", 660, 420, { settingBar: 3 }, "SV1"),
              g = n("checkValve", 660, 545, { crackingBar: 0.3 }, "CV1"),
              t = n(
                "cylinderDA",
                920,
                520,
                { boreMm: 63, rodMm: 36, strokeMm: 400, loadKg: 200 },
                "C2",
              ),
              u = n(
                "cylinderReedSensor",
                920,
                400,
                {
                  linkedActuator: "C2",
                  triggerAt: "extended",
                  action: "none",
                  targetControl: "",
                },
                "B1",
              ),
              m = n(
                "cylinderReedSensor",
                920,
                350,
                {
                  linkedActuator: "C1",
                  triggerAt: "retracted",
                  action: "none",
                  targetControl: "",
                },
                "B2",
              );
            ((g.rotation = 180),
              a(o, "A", e, "P", "pressure", { shift: -60 }),
              a(e, "A", t, "A", "pressure", { shift: -60 }),
              a(t, "A", g, "A", "pressure", { shift: -80 }),
              a(g, "B", e, "P", "pressure", { shift: -80 }),
              a(e, "T", i.exhaust, "T", "drain", { shift: -95 }),
              a(o, "B", t, "B", "return", {
                routeMode: "horizontal-first",
                shift: 45,
              }),
              a(u, "E1", l, "I1", "electrical", { color: "#d946ef" }),
              a(m, "E1", l, "I2", "electrical", { color: "#d946ef" }));
          } else if (5 === t) {
            ((l.props.program =
              "MOTOR START/STOP: Q1 = PB-STOP AND PB-START OR PB-STOP AND Q1 AND FS1"),
              (o.props.spoolState = "center"),
              (r.connections = r.connections.filter(
                (e) => e.to.componentId !== s.id && e.from.componentId !== s.id,
              )),
              (r.components = r.components.filter((e) => e.id !== s.id)));
            const e = n(
                "pneumaticMotor",
                960,
                290,
                { displacementCcRev: 25, loadNm: 12 },
                "M1",
              ),
              t = n(
                "flowSwitch",
                700,
                270,
                { switchLpm: 120, action: "none", targetControl: "" },
                "FS1",
              ),
              u = n(
                "pushButton",
                260,
                650,
                { contact: "NO", pressed: !1 },
                "PB-START",
              ),
              m = n(
                "pushButton",
                260,
                760,
                { contact: "NC", pressed: !1 },
                "PB-STOP",
              ),
              y = n(
                "solenoid",
                790,
                705,
                { voltage: "24 VDC", energized: !1 },
                "Y1",
              );
            (a(o, "A", t, "A", "pressure", {
              routeMode: "horizontal-first",
              shift: -20,
            }),
              a(t, "B", e, "A", "pressure", {
                routeMode: "horizontal-first",
                shift: -20,
              }),
              a(e, "B", o, "B", "return", {
                routeMode: "horizontal-first",
                shift: 25,
              }),
              a(t, "E", l, "I1", "electrical", { color: "#d946ef" }),
              a(u, "E2", l, "I1", "electrical", { color: "#d946ef" }),
              a(m, "E2", l, "I2", "electrical", { color: "#d946ef" }),
              a(l, "Q1", y, "E1", "electrical", { color: "#d946ef" }));
          } else if (6 === t) {
            l.props.program =
              "ACCUMULATOR CLAMP: PS1 -> V1 center; B2 -> V1 left";
            const e = n("accumulator", 650, 220, { volumeL: 10 }, "REC1"),
              t = n("pilotCheckValve", 690, 310, { pilotRatio: 3 }, "PCV1"),
              u = n(
                "pressureSwitch",
                650,
                520,
                {
                  switchBar: 5,
                  action: "none",
                  targetControl: "",
                },
                "PS1",
              ),
              m = n(
                "cylinderReedSensor",
                920,
                395,
                {
                  linkedActuator: "C1",
                  triggerAt: "retracted",
                  action: "none",
                  targetControl: "",
                },
                "B2",
              );
            (c("A"),
              a(o, "A", t, "A", "pressure", {
                routeMode: "horizontal-first",
                shift: -20,
              }),
              a(t, "B", s, "A", "pressure", {
                routeMode: "horizontal-first",
                shift: -20,
              }),
              a(o, "B", t, "X", "pilot", { shift: -55 }),
              a(i.compressor, "P", e, "A", "pressure", { shift: -55 }),
              a(t, "B", u, "P", "pressure", {
                routeMode: "vertical-first",
                shift: 55,
                color: "#f59e0b",
              }),
              a(u, "E", l, "I1", "electrical", { color: "#d946ef" }),
              a(m, "E1", l, "I2", "electrical", { color: "#d946ef" }));
          } else if (7 === t) {
            ((l.props.program =
              "VERTICAL AXIS: LS1 -> V1 right; LS2 -> V1 center"),
              (o.props.spoolState = "center"),
              (s.props.loadKg = 400));
            const e = n(
                "counterbalanceValve",
                660,
                455,
                { settingBar: 5, pilotRatio: 3 },
                "CBV1",
              ),
              t = n(
                "limitSwitch",
                920,
                140,
                {
                  linkedActuator: "C1",
                  triggerAt: "extended",
                  action: "none",
                  targetControl: "",
                },
                "LS1",
              ),
              u = n(
                "limitSwitch",
                920,
                395,
                {
                  linkedActuator: "C1",
                  triggerAt: "retracted",
                  action: "none",
                  targetControl: "",
                },
                "LS2",
              );
            (c("B"),
              a(s, "B", e, "A", "return", { shift: 45 }),
              a(e, "B", o, "B", "return", { shift: 55 }),
              a(o, "A", e, "X", "pilot", { shift: -75 }),
              a(t, "E1", l, "I1", "electrical", { color: "#d946ef" }),
              a(u, "E1", l, "I2", "electrical", { color: "#d946ef" }));
          } else if (8 === t) {
            l.props.program =
              "METER-OUT JOG: Q1 = PB1 AND NOT PB2; Q2 = PB2 AND NOT PB1";
            const e = n("flowControl", 700, 430, { openingPercent: 40 }, "FC1"),
              t = n(
                "pushButton",
                260,
                650,
                { contact: "NO", pressed: !1 },
                "PB1",
              ),
              u = n(
                "pushButton",
                260,
                760,
                { contact: "NO", pressed: !1 },
                "PB2",
              ),
              m = n(
                "solenoid",
                790,
                650,
                { voltage: "24 VDC", energized: !1 },
                "Y1",
              ),
              y = n(
                "solenoid",
                790,
                760,
                { voltage: "24 VDC", energized: !1 },
                "Y2",
              );
            (c("B"),
              a(s, "B", e, "A", "return", {
                routeMode: "horizontal-first",
                shift: 30,
              }),
              a(e, "B", o, "B", "return", {
                routeMode: "horizontal-first",
                shift: 40,
              }),
              a(t, "E2", l, "I1", "electrical", { color: "#d946ef" }),
              a(u, "E2", l, "I2", "electrical", { color: "#d946ef" }),
              a(l, "Q1", m, "E1", "electrical", { color: "#d946ef" }),
              a(l, "Q2", y, "E1", "electrical", { color: "#d946ef" }));
          } else if (9 === t) {
            l.props.program =
              "REDUCED BRANCH: Q1 = PT1";
            const e = n("reducingValve", 640, 215, { outletBar: 3 }, "PRV1"),
              t = n(
                "cylinderDA",
                920,
                520,
                { boreMm: 80, rodMm: 45, strokeMm: 400, loadKg: 320 },
                "Main",
              ),
              u = n(
                "pressureTransducer",
                700,
                420,
                { rangeBar: 10, signal: "4-20 mA" },
                "PT1",
              );
            (c("A"),
              a(o, "A", e, "P", "pressure", { shift: -55 }),
              a(e, "A", s, "A", "pressure", { shift: -55 }),
              a(e, "T", i.exhaust, "T", "drain", { shift: -65 }),
              a(o, "A", t, "A", "pressure", {
                routeMode: "horizontal-first",
                shift: -40,
              }),
              a(o, "B", t, "B", "return", {
                routeMode: "horizontal-first",
                shift: 45,
              }),
              a(e, "A", u, "P", "pressure", {
                routeMode: "vertical-first",
                shift: 60,
                color: "#f59e0b",
              }),
              a(u, "E", l, "I1", "electrical", { color: "#d946ef" }));
          } else if (10 === t) {
            l.props.program =
              "FAST APPROACH: B1 -> V2 right; NOT B1 -> V2 left; B2 -> V1 right; B3 -> V1 center";
            const e = n("junction", 700, 430, {}, "J1"),
              t = n("flowControl", 880, 470, { openingPercent: 35 }, "FC1"),
              u = n("junction", 1050, 430, {}, "J2"),
              m = n(
                "directionalValve",
                700,
                580,
                {
                  ports: "3",
                  positions: "2",
                  center: "closed",
                  spoolState: "left",
                  leftActuation: "spring",
                  rightActuation: "solenoid",
                },
                "V2",
              ),
              y = n(
                "cylinderReedSensor",
                920,
                95,
                {
                  linkedActuator: "C1",
                  triggerAt: "custom",
                  triggerPosition: 0.7,
                  action: "none",
                  targetControl: "V2",
                },
                "B1",
              ),
              g = n(
                "cylinderReedSensor",
                920,
                140,
                {
                  linkedActuator: "C1",
                  triggerAt: "extended",
                  action: "none",
                  targetControl: "",
                },
                "B2",
              ),
              d = n(
                "cylinderReedSensor",
                920,
                395,
                {
                  linkedActuator: "C1",
                  triggerAt: "retracted",
                  action: "none",
                  targetControl: "",
                },
                "B3",
              );
            (c("B"),
              a(s, "B", e, "A", "return", {
                routeMode: "horizontal-first",
                shift: 30,
              }),
              a(e, "B", t, "A", "return", { shift: 25 }),
              a(t, "B", u, "A", "return", { shift: 25 }),
              a(u, "B", o, "B", "return", { shift: 40 }),
              a(e, "C", m, "P", "return", { shift: 60 }),
              a(m, "A", u, "C", "return", { shift: 65 }),
              a(m, "T", i.exhaust, "T", "return", { shift: 75 }),
              a(y, "E1", l, "I1", "electrical", { color: "#d946ef" }),
              a(g, "E1", l, "I2", "electrical", { color: "#d946ef" }),
              a(d, "E1", l, "I2", "electrical", { color: "#d946ef" }));
          } else if (11 === t) {
            l.props.program =
              "FLOW-DIVIDER SYNC: B1 AND B2 -> V1 right";
            const e = n("flowDivider", 650, 300, { splitPercentA: 50 }, "FD1"),
              t = n(
                "cylinderDA",
                920,
                520,
                { boreMm: 63, rodMm: 36, strokeMm: 450, loadKg: 300 },
                "C2",
              ),
              u = n(
                "cylinderReedSensor",
                920,
                95,
                {
                  linkedActuator: "C1",
                  triggerAt: "extended",
                  action: "none",
                  targetControl: "",
                },
                "B1",
              ),
              m = n(
                "cylinderReedSensor",
                920,
                355,
                {
                  linkedActuator: "C2",
                  triggerAt: "extended",
                  action: "none",
                  targetControl: "",
                },
                "B2",
              );
            (c("A"),
              a(o, "A", e, "P", "pressure", { shift: -30 }),
              a(e, "A", s, "A", "pressure", { shift: -30 }),
              a(e, "B", t, "A", "pressure", { shift: -30 }),
              a(o, "B", t, "B", "return", {
                routeMode: "horizontal-first",
                shift: 45,
              }),
              a(u, "E1", l, "I1", "electrical", { color: "#d946ef" }),
              a(m, "E1", l, "I2", "electrical", { color: "#d946ef" }));
          } else if (12 === t) {
            ((l.props.program =
              "LOAD-HOLD E-RELEASE: Q1 = NOT ES-STOP"),
              (o.props.spoolState = "center"),
              (s.props.loadKg = 350));
            const e = n("pilotCheckValve", 690, 310, { pilotRatio: 3 }, "PCV1"),
              t = n(
                "directionalValve",
                640,
                480,
                {
                  ports: "2",
                  positions: "2",
                  center: "closed",
                  spoolState: "right",
                  leftActuation: "solenoid",
                  rightActuation: "spring",
                },
                "V2",
              ),
              u = n(
                "pushButton",
                270,
                705,
                { contact: "NC", pressed: !1 },
                "ES-STOP",
              ),
              m = n(
                "solenoid",
                730,
                705,
                { voltage: "24 VDC", energized: !1, targetControl: "V2" },
                "Y1",
              );
            (c("A"),
              a(o, "A", e, "A", "pressure", {
                routeMode: "horizontal-first",
                shift: -20,
              }),
              a(e, "B", s, "A", "pressure", {
                routeMode: "horizontal-first",
                shift: -20,
              }),
              a(o, "B", e, "X", "pilot", { shift: -55 }),
              a(e, "B", t, "P", "pressure", {
                routeMode: "vertical-first",
                shift: 55,
              }),
              a(t, "A", i.exhaust, "T", "return", { shift: 65 }),
              a(u, "E2", l, "I1", "electrical", { color: "#d946ef" }),
              a(l, "Q1", m, "E1", "electrical", { color: "#d946ef" }));
          } else if (13 === t) {
            l.props.program =
              "COOLING: Q1 = TSH1";
            const e = n("junction", 320, 300, {}, "J1"),
              t = n("cooler", 500, 210, { coolingKw: 5 }, "HX1"),
              u = n("junction", 690, 300, {}, "J2"),
              m = n(
                "directionalValve",
                460,
                530,
                {
                  ports: "2",
                  positions: "2",
                  center: "closed",
                  spoolState: "left",
                  leftActuation: "spring",
                  rightActuation: "solenoid",
                },
                "V2",
              ),
              y = n("accumulator", 840, 210, { volumeL: 20 }, "REC1"),
              g = n(
                "temperatureSwitch",
                300,
                470,
                {
                  switchTempC: 60,
                  action: "none",
                  targetControl: "",
                },
                "TSH1",
              ),
              d = n(
                "solenoid",
                730,
                705,
                { voltage: "24 VDC", energized: !1, targetControl: "V2" },
                "Y1",
              );
            ((r.connections = r.connections.filter(
              (e) => !(e.from.componentId === i.compressor.id),
            )),
              (r.connections = r.connections.filter(
                (e) => !(e.from.componentId === o.id && "T" === e.from.portId),
              )),
              a(i.compressor, "P", e, "A", "pressure", { shift: -20 }),
              a(e, "B", t, "A", "pressure", { shift: -30 }),
              a(t, "B", u, "A", "pressure", { shift: -30 }),
              a(u, "B", y, "A", "pressure"),
              a(e, "C", m, "P", "pressure", { shift: 55 }),
              a(m, "A", u, "C", "pressure", { shift: 60 }),
              a(e, "D", g, "P", "pressure", { shift: 70 }),
              a(y, "A", o, "P", "pressure", { shift: -30 }),
              a(o, "T", i.exhaust, "T", "return", { shift: 30 }),
              a(g, "E", l, "I1", "electrical", { color: "#d946ef" }),
              a(l, "Q1", d, "E1", "electrical", { color: "#d946ef" }));
          } else if (14 === t) {
            ((l.props.program =
              "PRESS CYCLE: Q1 = ES-STOP AND PB-START OR ES-STOP AND Q1 AND NOT PS1; Q2 = ES-STOP AND PS1 OR ES-STOP AND Q2 AND NOT PB-START"),
              (o.props.spoolState = "center"),
              (s.props.loadKg = 600),
              (s.props.strokeMm = 400));
            const e = n(
                "pressureSwitch",
                650,
                520,
                {
                  switchBar: 5,
                  action: "none",
                  targetControl: "",
                },
                "PS1",
              ),
              t = n(
                "pushButton",
                260,
                650,
                { contact: "NO", pressed: !1 },
                "PB-START",
              ),
              u = n(
                "pushButton",
                260,
                760,
                { contact: "NC", pressed: !1 },
                "ES-STOP",
              ),
              m = n(
                "solenoid",
                790,
                650,
                { voltage: "24 VDC", energized: !1 },
                "Y1",
              ),
              y = n(
                "solenoid",
                790,
                760,
                { voltage: "24 VDC", energized: !1 },
                "Y2",
              );
            (a(o, "A", e, "P", "pressure", {
              routeMode: "vertical-first",
              shift: 55,
              color: "#f59e0b",
            }),
              a(e, "E", l, "I1", "electrical", { color: "#d946ef" }),
              a(t, "E2", l, "I1", "electrical", { color: "#d946ef" }),
              a(u, "E2", l, "I2", "electrical", { color: "#d946ef" }),
              a(l, "Q1", m, "E1", "electrical", { color: "#d946ef" }),
              a(l, "Q2", y, "E1", "electrical", { color: "#d946ef" }));
          }
          return ((r.viewBox = { x: 40, y: 40, w: 1120, h: 760 }), r);
        })(e, t),
    })),
    ...[
      "Packaging machine pick-and-place vacuum pneumatic circuit",
      "Automatic bottle filling pneumatic indexing station",
      "Press shop pneumatic clamp and ejector manifold",
      "Robotic gripper with vacuum ejector and blow-off",
      "Food processing pneumatic gate and diverter system",
      "Textile machine air-jet and cylinder control panel",
      "Bus door pneumatic control and safety interlock",
      "Rail vehicle pneumatic brake training circuit",
      "Automated assembly station with dual-hand safety start",
      "Pneumatic sorting line with sensors and PLC I/O",
      "Vacuum lifting table with receiver and pressure monitoring",
      "Compressed-air test bench with FRL and leak monitoring",
      "Pneumatic press with soft-start dump valve and guards",
      "Multi-cylinder transfer machine pneumatic sequence",
      "Large factory compressed-air manifold with service units",
    ].map((e, t) => ({
      level: "Advanced real-world class circuits",
      name: e,
      builder: () =>
        (function (e, t = 0) {
          const { project: r, add: n, connect: a } = vt(e);
          r.viewBox = { x: 0, y: 0, w: 1680, h: 1120 };
          const i = ft(n, 0, 620),
            o = n("junction", 360, 430, {}, "P-MAN"),
            s = n("junction", 360, 760, {}, "T-MAN"),
            l = n("filter", 260, 760, { ratingMicron: 10 }, "RF1"),
            c = n("cooler", 260, 870, { coolingKw: 8 + t }, "HX1"),
            p = n(
              "accumulator",
              360,
              250,
              { prechargeBar: 5, volumeL: 10 + t },
              "ACC1",
            );
          const g = n("silencer", 560, 870, { noiseReductionDb: 25 }, "SIL1");
          (a(i.compressor, "P", c, "A", "pressure", { shift: 40 }),
            a(c, "B", l, "A", "pressure", { shift: 30 }),
            a(l, "B", o, "A", "pressure", { shift: -35 }),
            a(s, "C", g, "E", "return", { shift: 60 }),
            a(s, "D", i.exhaust, "T", "return", { shift: 75 }),
            a(o, "C", p, "A", "pressure", { shift: -70 }));
          const d = t % 4 == 0 ? 4 : t % 4 == 1 ? 3 : 2,
            u = [];
          for (let e = 0; e < d; e++) {
            const r = 250 + 190 * e,
              i = n(
                "directionalValve",
                660,
                r,
                {
                  valveType: e % 2 ? "4/3 tandem center" : "4/3 closed center",
                  ports: "5",
                  positions: "3",
                  center: e % 2 ? "tandem" : "closed",
                  spoolState: "center",
                  leftActuation: "solenoid",
                  rightActuation: "solenoid",
                },
                `V${e + 1}`,
              );
            if (
              (a(o, "B", i, "P", "pressure", { shift: -30 - 12 * e }),
              a(i, "T", s, "B", "return", { shift: 30 + 12 * e }),
              e === d - 1 && t % 3 == 1)
            ) {
              const t = n(
                "pneumaticMotor",
                1110,
                r - 15,
                { displacementCcRev: 45, loadNm: 80 },
                `M${e + 1}`,
              );
              (a(i, "A", t, "A", "pressure", {
                routeMode: "horizontal-first",
                shift: -25,
              }),
                a(t, "B", i, "B", "return", {
                  routeMode: "horizontal-first",
                  shift: 25,
                }),
                u.push(t));
            } else {
              const t = n(
                  "cylinderDA",
                  1120,
                  r - 15,
                  {
                    boreMm: 80 + 15 * e,
                    rodMm: 45,
                    strokeMm: 600 + 100 * e,
                    loadKg: 700 + 250 * e,
                  },
                  `C${e + 1}`,
                ),
                o =
                  e % 2 == 0
                    ? n(
                        "counterbalanceValve",
                        900,
                        r + 55,
                        { settingBar: 130, pilotRatio: 3 },
                        `CBV${e + 1}`,
                      )
                    : null;
              (o
                ? (a(i, "A", t, "A", "pressure", {
                    routeMode: "horizontal-first",
                    shift: -30,
                  }),
                  a(t, "B", o, "A", "return", {
                    routeMode: "horizontal-first",
                    shift: 25,
                  }),
                  a(o, "B", i, "B", "return", {
                    routeMode: "horizontal-first",
                    shift: 35,
                  }),
                  a(i, "A", o, "X", "pilot", { shift: -70 }))
                : (a(i, "A", t, "A", "pressure", {
                    routeMode: "horizontal-first",
                    shift: -25,
                  }),
                  a(t, "B", i, "B", "return", {
                    routeMode: "horizontal-first",
                    shift: 25,
                  })),
                n(
                  "linearPositionSensor",
                  1120,
                  r - 95,
                  {
                    linkedActuator: t.label,
                    triggerAt: "custom",
                    triggerPosition: 0.8,
                    action: "set valve center",
                    targetControl: i.label,
                  },
                  `LVDT${e + 1}`,
                ),
                u.push(t));
            }
          }
          n(
            "plc",
            660,
            970,
            {
              program:
                "Advanced interlocked sequence: sensors -> PLC -> solenoid valves.",
            },
            "PLC1",
          );
          return (
            a(
              o,
              "D",
              n(
                "pressureTransducer",
                500,
                230,
                { rangeBar: 315, signal: "4-20 mA" },
                "PT1",
              ),
              "P",
              "pressure",
              { shift: -85, color: "#ef4444", routeMode: "vertical-first" },
            ),
            n(
              "temperatureSwitch",
              500,
              875,
              { switchTempC: 60, action: "set valve center" },
              "TS1",
            ),
            n(
              "levelSwitch",
              170,
              705,
              { levelPercent: 20, mode: "low level" },
              "LSH1",
            ),
            (r.metadata.notes = `${e}: advanced real-world class pneumatic layout with service unit, conditioning, air receiver, manifold valves, feedback sensors and PLC control.`),
            r
          );
        })(e, t),
    })),
    ...[
      "Direct control of a single-acting cylinder",
      "Indirect control of a double-acting cylinder",
      "Pneumatic AND logic with two-pressure valve",
      "Pneumatic OR logic with shuttle valve",
      "Time-delay valve cylinder return circuit",
      "Signal storage with pneumatic memory valve",
      "Electropneumatic relay latch with indicator lamp",
      "Valve terminal multi-actuator station",
    ].map((e, t) => ({
      level: "Festo pneumatic/electropneumatic training circuits",
      name: e,
      builder: () =>
        (function (e, t = 0) {
          const { project: r, add: n, connect: a } = vt(e),
            i = ft(n, 0, 500),
            o = n(
              "compressedAirDistributor",
              390,
              500,
              { pressureBar: 6 },
              "DIST1",
            );
          if (
            (a(i.compressor, "P", o, "P", "pressure", { shift: -30 }), 0 === t)
          ) {
            const e = n(
                "directionalValve",
                600,
                390,
                {
                  ports: "3",
                  positions: "2",
                  center: "closed",
                  spoolState: "left",
                  leftActuation: "push button",
                  rightActuation: "spring",
                },
                "V1",
              ),
              t = n(
                "cylinderSA",
                900,
                310,
                { boreMm: 32, strokeMm: 120, loadKg: 20 },
                "A1",
              );
            (a(o, "A", e, "P", "pressure"),
              a(e, "A", t, "A", "pressure"),
              a(e, "T", i.exhaust, "T", "return"));
          } else if (1 === t) {
            const e = n(
                "directionalValve",
                280,
                300,
                {
                  ports: "3",
                  positions: "2",
                  spoolState: "right",
                  leftActuation: "push button",
                  rightActuation: "spring",
                },
                "S1",
              ),
              t = n(
                "directionalValve",
                640,
                390,
                {
                  ports: "5",
                  positions: "2",
                  spoolState: "right",
                  leftActuation: "pneumatic pilot",
                  rightActuation: "spring",
                },
                "V1",
              ),
              r = n(
                "cylinderDA",
                980,
                310,
                { boreMm: 40, rodMm: 16, strokeMm: 200, loadKg: 35 },
                "A1",
              );
            (a(o, "A", e, "P", "pressure"),
              a(e, "A", t, "X", "pilot", { color: "#f59e0b" }),
              a(e, "T", i.exhaust, "T", "return"),
              a(o, "B", t, "P", "pressure"),
              a(t, "A", r, "A", "pressure"),
              a(t, "B", r, "B", "return"),
              a(t, "T", i.exhaust, "T", "return"));
          } else if (2 === t) {
            const e = n("twoPressureValve", 560, 390, {}, "AND1"),
              t = n(
                "directionalValve",
                240,
                315,
                {
                  ports: "3",
                  positions: "2",
                  spoolState: "left",
                  leftActuation: "push button",
                  rightActuation: "spring",
                },
                "S1",
              ),
              r = n(
                "directionalValve",
                390,
                660,
                {
                  ports: "3",
                  positions: "2",
                  spoolState: "left",
                  leftActuation: "push button",
                  rightActuation: "spring",
                },
                "S2",
              ),
              s = n(
                "directionalValve",
                740,
                390,
                {
                  ports: "3",
                  positions: "2",
                  spoolState: "left",
                  leftActuation: "pneumatic pilot",
                  rightActuation: "spring",
                },
                "V1",
              ),
              l = n(
                "cylinderSA",
                980,
                330,
                { boreMm: 32, strokeMm: 120 },
                "A1",
              );
            (a(o, "A", t, "P", "pressure"),
              a(o, "B", r, "P", "pressure"),
              a(t, "A", e, "A", "pilot"),
              a(r, "A", e, "B", "pilot"),
              a(t, "T", i.exhaust, "T", "return"),
              a(r, "T", i.exhaust, "T", "return"),
              a(e, "X", s, "X", "pilot"),
              a(o, "C", s, "P", "pressure"),
              a(s, "A", l, "A", "pressure"),
              a(s, "T", i.exhaust, "T", "return"));
          } else if (3 === t) {
            const e = n("shuttleValve", 560, 390, {}, "OR1"),
              t = n(
                "directionalValve",
                240,
                315,
                {
                  ports: "3",
                  positions: "2",
                  spoolState: "left",
                  leftActuation: "push button",
                  rightActuation: "spring",
                },
                "S1",
              ),
              r = n(
                "directionalValve",
                390,
                660,
                {
                  ports: "3",
                  positions: "2",
                  spoolState: "left",
                  leftActuation: "roller",
                  rightActuation: "spring",
                },
                "S2",
              ),
              s = n(
                "directionalValve",
                740,
                390,
                {
                  ports: "3",
                  positions: "2",
                  spoolState: "left",
                  leftActuation: "pneumatic pilot",
                  rightActuation: "spring",
                },
                "V1",
              ),
              l = n(
                "cylinderSA",
                980,
                330,
                { boreMm: 32, strokeMm: 120 },
                "A1",
              );
            (a(o, "A", t, "P", "pressure"),
              a(o, "B", r, "P", "pressure"),
              a(t, "A", e, "A", "pilot"),
              a(r, "A", e, "B", "pilot"),
              a(t, "T", i.exhaust, "T", "return"),
              a(r, "T", i.exhaust, "T", "return"),
              a(e, "X", s, "X", "pilot"),
              a(o, "C", s, "P", "pressure"),
              a(s, "A", l, "A", "pressure"),
              a(s, "T", i.exhaust, "T", "return"));
          } else if (4 === t) {
            const e = n(
                "pneumaticTimeDelayValve",
                660,
                470,
                { delayS: 1.5 },
                "TD1",
              ),
              t = n(
                "directionalValve",
                870,
                390,
                {
                  ports: "5",
                  positions: "2",
                  spoolState: "right",
                  leftActuation: "pneumatic pilot",
                  rightActuation: "pneumatic pilot",
                },
                "V1",
              ),
              r = n(
                "cylinderDA",
                1140,
                310,
                { boreMm: 40, rodMm: 16, strokeMm: 200 },
                "A1",
              ),
              s = n(
                "directionalValve",
                240,
                300,
                {
                  ports: "3",
                  positions: "2",
                  spoolState: "right",
                  leftActuation: "push button",
                  rightActuation: "spring",
                },
                "SET",
              ),
              l = n(
                "directionalValve",
                530,
                470,
                {
                  ports: "3",
                  positions: "2",
                  spoolState: "right",
                  leftActuation: "roller",
                  rightActuation: "spring",
                },
                "S1",
              );
            (a(o, "A", s, "P", "pressure"),
              a(s, "A", t, "X", "pilot", { color: "#f59e0b" }),
              a(s, "T", i.exhaust, "T", "return"),
              a(o, "B", l, "P", "pressure"),
              a(l, "A", e, "P", "pressure"),
              a(l, "T", i.exhaust, "T", "return"),
              a(e, "A", t, "Y", "pilot", { color: "#f59e0b" }),
              a(e, "R", i.exhaust, "T", "return", { shift: 45 }),
              a(o, "C", t, "P", "pressure"),
              a(t, "A", r, "A", "pressure"),
              a(t, "B", r, "B", "return"),
              a(t, "T", i.exhaust, "T", "return"));
          } else if (5 === t) {
            const e = n(
                "pneumaticMemoryValve",
                700,
                390,
                { spoolState: "left" },
                "MEM1",
              ),
              t = n(
                "cylinderDA",
                980,
                310,
                { boreMm: 40, rodMm: 16, strokeMm: 220 },
                "A1",
              ),
              r = n(
                "directionalValve",
                240,
                300,
                {
                  ports: "3",
                  positions: "2",
                  spoolState: "left",
                  leftActuation: "push button",
                  rightActuation: "spring",
                },
                "SET",
              ),
              s = n(
                "directionalValve",
                390,
                650,
                {
                  ports: "3",
                  positions: "2",
                  spoolState: "left",
                  leftActuation: "push button",
                  rightActuation: "spring",
                },
                "RESET",
              );
            (a(o, "A", e, "P", "pressure"),
              a(e, "A", t, "A", "pressure"),
              a(e, "B", t, "B", "return"),
              a(e, "R", i.exhaust, "T", "return"),
              a(e, "S", i.exhaust, "T", "return"),
              a(o, "B", r, "P", "pressure"),
              a(r, "A", e, "X", "pilot"),
              a(r, "T", i.exhaust, "T", "return"),
              a(o, "C", s, "P", "pressure"),
              a(s, "A", e, "Y", "pilot"),
              a(s, "T", i.exhaust, "T", "return"));
          } else if (6 === t) {
            const e = n("powerSupply24V", 250, 660, {}, "PSU1"),
              t = n("pushButton", 420, 660, { pressed: !1 }, "S1"),
              r = n("electricalRelay", 560, 660, { energized: !1 }, "K1"),
              s = n(
                "indicatorLamp",
                700,
                660,
                { colorLamp: "green", on: !1 },
                "H1",
              ),
              l = n(
                "solenoid",
                820,
                660,
                { voltage: "24 VDC", energized: !1 },
                "Y1",
              ),
              c = n(
                "directionalValve",
                650,
                390,
                {
                  ports: "5",
                  positions: "2",
                  spoolState: "left",
                  leftActuation: "solenoid",
                  rightActuation: "spring",
                },
                "V1",
              ),
              p = n(
                "cylinderDA",
                950,
                310,
                { boreMm: 40, rodMm: 16, strokeMm: 200 },
                "A1",
              ),
              d = n("relayContact", 410, 560, {}, "K1-1");
            (a(o, "A", c, "P", "pressure"),
              a(c, "A", p, "A", "pressure"),
              a(c, "B", p, "B", "return"),
              a(c, "T", i.exhaust, "T", "return"),
              a(e, "OUT", t, "E1", "electrical"),
              a(t, "E2", r, "A1", "electrical"),
              a(e, "OUT", d, "E1", "electrical", { shift: 40 }),
              a(d, "E2", r, "A1", "electrical", { shift: 40 }),
              a(r, "A2", s, "E1", "electrical"),
              a(r, "A2", l, "E1", "electrical"));
          } else {
            const e = n(
                "valveTerminal",
                650,
                390,
                { stations: 2, fieldbus: "multi-pin", supplyBar: 6 },
                "VT1",
              ),
              t = n(
                "cylinderDA",
                980,
                260,
                { boreMm: 32, rodMm: 12, strokeMm: 160 },
                "A1",
              ),
              r = n(
                "cylinderDA",
                980,
                470,
                { boreMm: 32, rodMm: 12, strokeMm: 160 },
                "B1",
              ),
              s = n("terminalStrip", 650, 660, { terminals: 12 }, "X1"),
              l = n("opticalSensor", 980, 610, { mode: "diffuse" }, "B1");
            (a(o, "A", e, "P", "pressure"),
              a(e, "R", i.exhaust, "T", "return"),
              a(e, "A1", t, "A", "pressure"),
              a(e, "B1", t, "B", "return"),
              a(e, "A2", r, "A", "pressure"),
              a(e, "B2", r, "B", "return"),
              a(e, "E", s, "Q1", "electrical"),
              a(l, "E1", s, "E1", "electrical"));
          }
          return ((r.viewBox = { x: 60, y: 130, w: 1160, h: 760 }), r);
        })(e, t),
    })),    {
      level: "Intermediate electropneumatic circuits",
      name: "Variable load — time-based load ramp on a 5/2 cylinder",
      builder: function () {
        const {
            project: e,
            add: t,
            connect: r,
          } = vt("Variable load — time-based load ramp on a 5/2 cylinder"),
          n = ft(t),
          a = t(
            "directionalValve",
            610,
            420,
            {
              ports: "5",
              positions: "2",
              center: "closed",
              spoolState: "left",
              leftActuation: "manual",
              rightActuation: "spring",
            },
            "V1",
          ),
          i = t(
            "cylinderDA",
            850,
            330,
            {
              boreMm: 40,
              rodMm: 16,
              strokeMm: 400,
              loadKg: 20,
              loadMode: "time-based",
              loadProfile: "0, 20\n2, 60\n4, 120",
              simPosition: 0.15,
            },
            "C1",
          ),
          o = t("pressureGauge", 750, 210, {}, "G1"),
          c = t(
            "textLabel",
            860,
            640,
            {
              text:
                "TIME-BASED LOAD — open C1 Properties:\n" +
                "1. Set 'Load over cycle' = time-based.\n" +
                "2. Profile rows are 'seconds, kg': 0,20 → 2,60 → 4,120 (linear interpolation between rows).\n" +
                "3. Simulate: required pressure rises during the cycle — plot pressure or position vs time in 📈 Charts.\n" +
                "TIP: 'formula (t & x)' mode takes real math, e.g. 40 + 30*sin(pi*t) — sin, cos, ramp, pulse, if(...) all work.",
              fontSize: 15,
            },
            "TXT1",
          );
        return (
          r(n.compressor, "P", a, "P", "pressure"),
          r(a, "T", n.exhaust, "T", "return"),
          r(a, "A", i, "A", "pressure"),
          r(a, "B", i, "B", "return"),
          r(a, "A", o, "P", "pressure"),
          e
        );
      },
    },

  ];
  function yt(t) {
    const r = ht[t] || ht[0],
      n = e.exampleOverrides && e.exampleOverrides[String(t)];
    if (n && Array.isArray(n.components) && Array.isArray(n.connections))
      return M(n);
    const a = r.builder();
    return (
      t < 15 &&
        (function (e, t = 0) {
          const r = e.components || [],
            n = (e, t, r) => {
              e && ((e.x = t), (e.y = r));
            },
            a = (e) => r.filter((t) => t.type === e),
            i = r.filter(
              (e) =>
                "directionalValve" === e.type ||
                String(e.type).startsWith("directionalValve"),
            ),
            o = a("powerPack")[0];
          (n(o, 150, 500), i.forEach((e, t) => n(e, 450, 390 + 115 * t)));
          const s = r.filter(
            (e) => "cylinderDA" === e.type || "cylinderSA" === e.type,
          );
          (s.forEach((e, t) => n(e, 870, 1 === s.length ? 270 : 220 + 230 * t)),
            a("pneumaticMotor").forEach((e, t) => n(e, 870, 270 + 170 * t)),
            a("flowControl").forEach((e, r) =>
              n(e, 650, 6 === t ? 455 : 270 + 105 * r),
            ),
            a("checkValve").forEach((e, t) => n(e, 660, 285 + 100 * t)),
            a("pilotCheckValve").forEach((e, t) => n(e, 650, 270 + 120 * t)),
            a("counterbalanceValve").forEach((e, t) =>
              n(e, 660, 455 + 110 * t),
            ),
            a("sequenceValve").forEach((e, t) => n(e, 640, 390 + 110 * t)),
            a("reducingValve").forEach((e, t) => n(e, 640, 270 + 110 * t)),
            a("flowDivider").forEach((e, t) => n(e, 650, 300 + 130 * t)),
            a("junction").forEach((e, t) => n(e, 650, 285 + 100 * t)),
            a("accumulator").forEach((e, t) => n(e, 650, 255 + 135 * t)),
            a("pressureSwitch").forEach((e, t) => n(e, 650, 430 + 105 * t)),
            a("pressureGauge").forEach((e, t) => n(e, 320, 310 + 110 * t)),
            a("filter").forEach((e, t) => n(e, 305, 565 + 80 * t)),
            a("cooler").forEach((e, t) => n(e, 305, 640 + 80 * t)),
            r
              .filter((e) =>
                [
                  "limitSwitch",
                  "cylinderReedSensor",
                  "linearPositionSensor",
                  "proximitySensor",
                  "inductiveSensor",
                  "capacitiveSensor",
                  "opticalSensor",
                ].includes(e.type),
              )
              .forEach((e, t) => {
                const r =
                  s.find(
                    (t) =>
                      e.props.linkedActuator &&
                      (t.id === e.props.linkedActuator ||
                        t.label === e.props.linkedActuator),
                  ) || s[0];
                n(
                  e,
                  r ? r.x : 870,
                  r ? r.y + (t % 2 ? 120 : -120) : 140 + 90 * t,
                );
              }),
            r
              .filter((e) =>
                [
                  "pressureTransducer",
                  "flowSwitch",
                  "temperatureSwitch",
                  "levelSwitch",
                ].includes(e.type),
              )
              .forEach((e, t) => n(e, 1030, 160 + 95 * t)),
            r.forEach((e) => {
              ((e.x = A(e.x, 10)), (e.y = A(e.y, 10)));
            }));
        })(a, t),
      (a.metadata.projectName = r.name),
      (a.metadata.notes = `Predesigned RGZ Pneumatic Studio example: ${r.name}.`),
      (function (e, t) {
        const r = `${t.level || "Circuit"}\n${t.name}`;
        e.components.some((e) => "TXT-TITLE" === e.id) ||
          e.components.push({
            id: "TXT-TITLE",
            type: "textLabel",
            label: "Title",
            x: 90,
            y: 90,
            rotation: 0,
            props: {
              text: r,
              color: "#e8793c",
              fontSize: 24,
              fontFamily: "Tahoma, Arial, sans-serif",
              fontWeight: "800",
              direction: "auto",
              align: "start",
            },
          });
      })(a, r),
      a
    );
  }
  function vt(e) {
    const n = {
      fileType: "rgz-pneumatic-project",
      formatVersion: 1,
      appVersion: t,
      createdBy: "RGZ Pneumatic Studio",
      website: r,
      metadata: {
        projectName: e,
        designer: "",
        standard: "ISO-style / RGZ educational template",
        revision: "A",
        notes: "",
      },
      viewBox: { x: 40, y: 60, w: 1160, h: 720 },
      components: [],
      connections: [],
    };
    let a = 1;
    return {
      project: n,
      add: (e, t, r, i = {}, o = null) => {
        const s = L(e),
          l = {
            id: `${s.prefix}-${a++}`,
            type: e,
            label: o || `${s.prefix}${a - 1}`,
            x: t,
            y: r,
            rotation: 0,
            props: Object.assign(M(s.defaults || {}), i),
          };
        return (n.components.push(l), l);
      },
      connect: (e, t, r, a, i = "pressure", o = {}) => {
        n.connections.push({
          id: `L-${n.connections.length + 1}`,
          from: { componentId: e.id, portId: t },
          to: { componentId: r.id, portId: a },
          lineType: i,
          properties: Object.assign(
            {
              tubeIdMm: 12,
              lengthM: 1,
              maxPressureBar: 10,
              color: "",
              strokeWidth: 3,
              routeMode: "auto",
              shift: 0,
            },
            o,
          ),
        });
      },
    };
  }
  function ft(e, t, r = 500) {
    const n = e(
      "powerPack",
      180,
      r,
      {
        flowLpm: 500,
        reliefSettingBar: 6,
        exhaustCapacityL: 50,
        pressureGauge: !0,
      },
      "HPU1",
    );
    return { exhaust: n, compressor: n, relief: n, gauge: n, hpu: n };
  }
  function oe(e, t) {
    const r = S(P(t.props.simPosition, 0.25), 0, 1),
      n = 40 * r - 44,
      a = 38 + 58 * r;
    (e.append(
      $("rect", {
        class: "symbol-fill",
        x: -78,
        y: -22,
        width: 112,
        height: 44,
        rx: 0,
      }),
    ),
      e.append(
        $("path", { class: "symbol-stroke", d: `M${n} -22 v44 M${n} 0 H${a}` }),
      ),
      e.append($("path", { class: "symbol-muted", d: `M${a} -14 v28` })),
      e.append(
        $("path", { class: "symbol-stroke", d: "M-82 34v-12M22 34v-12" }),
      ));
  }
  function se(e, t) {
    const r = S(P(t.props.simPosition, 0.15), 0, 1),
      n = 44 * r - 22,
      a = 24 + 66 * r;
    (e.append(
      $("rect", {
        class: "symbol-fill",
        x: -72,
        y: -22,
        width: 100,
        height: 44,
        rx: 0,
      }),
    ),
      e.append(
        $("path", { class: "symbol-stroke", d: `M${n} -22 v44 M${n} 0 H${a}` }),
      ),
      e.append(
        $("path", {
          class: "symbol-muted",
          d: "M-54 -13 l28 26M-26 -13l-28 26M-40 -13l28 26",
        }),
      ),
      e.append($("path", { class: "symbol-muted", d: `M${a} -14 v28` })),
      e.append($("path", { class: "symbol-stroke", d: "M-76 34v-12" })));
  }
  ((Array.isArray(e.customExamples) ? e.customExamples : []).forEach((e) => {
    e &&
      e.project &&
      Array.isArray(e.project.components) &&
      Array.isArray(e.project.connections) &&
      (ht.some((t) => t.customId && t.customId === e.id) ||
        ht.push({
          level: e.level || "Owner custom circuits",
          name: e.name || "Custom circuit",
          customId: e.id || `custom-${ht.length}`,
          builder: () => M(e.project),
        }));
  }),
    (function () {
      let e = document.querySelector('meta[name="viewport"]');
      if (
        (e ||
          ((e = document.createElement("meta")),
          e.setAttribute("name", "viewport"),
          document.head.appendChild(e)),
        e.setAttribute(
          "content",
          "width=device-width, initial-scale=1, viewport-fit=cover, maximum-scale=1",
        ),
        ["apple-mobile-web-app-capable", "mobile-web-app-capable"].forEach(
          (e) => {
            if (!document.querySelector(`meta[name="${e}"]`)) {
              const t = document.createElement("meta");
              (t.setAttribute("name", e),
                t.setAttribute("content", "yes"),
                document.head.appendChild(t));
            }
          },
        ),
        at(),
        document.getElementById("rgz-runtime-critical-style"))
      )
        return;
      const t = document.createElement("style");
      ((t.id = "rgz-runtime-critical-style"),
        (t.textContent =
          "\n      html.rgz-pneumatic-page, body.rgz-pneumatic-page { margin:0!important; padding:0!important; overflow:hidden!important; background:#070b16!important; }\n      .rgz-pneumatic-studio-root { position:fixed!important; inset:0!important; width:100vw!important; height:100dvh!important; z-index:999999!important; overflow:hidden!important; margin:0!important; }\n      .rgz-modal-backdrop { position:fixed!important; inset:0!important; z-index:1000005!important; display:grid!important; place-items:center!important; background:rgba(2,6,23,.72)!important; padding:20px!important; }\n      .rgz-mobile-landscape-bar { display:none; }\n      .rgz-orientation-blocker { display:none; }\n      @media (max-width: 920px) and (orientation: portrait) {\n        .rgz-orientation-blocker { position:fixed!important; inset:0!important; z-index:1000010!important; display:grid!important; place-items:center!important; background:#070b16!important; color:#fff!important; text-align:center!important; padding:24px!important; }\n      }\n    "),
        document.head.appendChild(t));
    })(),
    document.documentElement.classList.add("rgz-pneumatic-page"),
    document.body.classList.add("rgz-pneumatic-page"),
    (n.innerHTML = `\n      <div class="rgz-app" aria-label="RGZ Pneumatic Studio pneumatic schematic application">\n        <div class="rgz-orientation-blocker">\n          <div class="rgz-orientation-card">\n            <div class="rgz-phone-rotate"><span></span></div>\n            <h2>Turn your phone</h2>\n            <p>Please rotate your phone to landscape mode to use RGZ Pneumatic Studio.</p>\n          </div>\n        </div>\n        <header class="rgz-topbar">\n          <div class="rgz-brand">\n            <div class="rgz-mark">RGZ</div>\n            <div>\n              <h1>RGZ Pneumatic Studio</h1>\n              <p>Online ISO-style pneumatic schematic design, checking, simulation and pipe sizing</p>\n            </div>\n          </div>\n          <div class="rgz-mobile-landscape-bar">\n            <button class="rgz-btn" data-action="toggle-library">Symbols</button>\n            <button class="rgz-btn" data-action="toggle-actions">Actions</button>\n            <button class="rgz-btn" data-action="toggle-inspector">Properties</button>\n            <button class="rgz-btn rgz-mobile-zoom" data-action="zoom-in">+</button>\n            <button class="rgz-btn rgz-mobile-zoom" data-action="zoom-out">−</button>\n          </div>\n          <div class="rgz-actions">\n            <button class="rgz-btn" data-action="fullscreen">Fullscreen</button>\n            <button class="rgz-btn" data-action="new">New</button>\n            <button class="rgz-btn" data-action="insert-service-unit">Service unit</button>\n            <button class="rgz-btn" data-action="insert-text">Text</button>\n            <button class="rgz-btn" data-action="fit">Fit</button>\n            <button class="rgz-btn" data-action="rotate-selected">Rotate 90°</button>\n            <button class="rgz-btn blue" data-action="check">Check circuit</button>\n            <button class="rgz-btn green" data-action="simulate">Simulate</button>\n            <button class="rgz-btn danger" data-action="stop" disabled>Stop</button>\n            <button class="rgz-btn" data-action="open-charts" title="Record simulation data and design custom charts (X/Y of any channel)">📈 Charts</button>\n            <div class="rgz-file-menu" id="rgz-file-menu">\n              <button class="rgz-btn primary" data-action="toggle-file-menu">File ▾</button>\n              <div class="rgz-file-menu-list">\n                <button class="rgz-btn" data-action="export-rgz">Save / Export</button>\n                <button class="rgz-btn" data-action="import-rgz">Import</button>\n                <button class="rgz-btn" data-action="account">Account</button>\n                <button class="rgz-btn" data-action="print">Print / PDF</button>\n                <button class="rgz-btn" data-action="set-print-area">Set print area</button>\n                <button class="rgz-btn" data-action="clear-print-area">Clear print area</button>\n                ${e.canManageExamples ? '<hr><button class="rgz-btn blue" data-action="add-example-template">Add current as new example</button><button class="rgz-btn" data-action="save-example-template">Update opened example</button><button class="rgz-btn" data-action="reset-example-template">Reset opened example</button>' : ""}\n              </div>\n            </div>\n            <input type="file" id="rgz-import-input" accept=".rgz,application/octet-stream" hidden />\n          </div>\n        </header>\n        <main class="rgz-main">\n          <aside class="rgz-sidebar">\n            <div class="rgz-section-title"><h2>00 — Start Fast</h2><span class="rgz-badge">${ht.length} examples</span></div>\n            <div class="rgz-panel rgz-examples-panel">\n              <div class="rgz-panel-title">Pre-designed ready circuits</div>\n              <button class="rgz-btn primary" style="width:100%;margin-top:10px" data-action="browse-examples">Browse circuit library</button>\n              <p>Open a clean popup to explore Simple, Intermediate and Advanced examples without sidebar text overflow.</p>\n            </div>\n            <div class="rgz-section-title"><h2>01 — Symbol Library</h2><span class="rgz-badge">${i.length} components</span></div>\n            <div class="rgz-search"><input class="rgz-input" id="rgz-search" placeholder="Search compressors, valves, cylinders…" /></div>\n            <div id="rgz-library"></div>\n          </aside>\n          <section class="rgz-workspace">\n            <div class="rgz-canvas-toolbar">\n              <div class="rgz-tool-pill"><span class="rgz-status-dot" id="rgz-status-dot"></span><span id="rgz-sim-status">Idle</span></div>\n              <div class="rgz-tool-pill"><span id="rgz-coords">x: 0 · y: 0</span></div>\n              <div class="rgz-tool-pill">Click one port, then another port to connect.</div>\n            </div>\n            <div class="rgz-canvas-wrap">\n              <svg id="rgz-canvas" role="img" aria-label="Pneumatic schematic canvas"></svg>\n            </div>\n            <div class="rgz-mobile-sim-controls">\n              <button class="rgz-btn green" data-action="simulate">Run</button>\n              <button class="rgz-btn danger" data-action="stop">Stop</button>\n              <button class="rgz-btn" data-action="toggle-live-controls">Controls</button>\n            </div>\n            <div id="rgz-mobile-live-controls" class="rgz-mobile-live-controls"></div>\n            <div id="rgz-print-block" class="rgz-print-title-block"></div>\n            <div class="rgz-bottom-panel">\n              <div class="rgz-bottom-header">\n                <div class="rgz-panel-title">Validation / Simulation messages</div>\n                <div style="display:flex;gap:6px"><button class="rgz-btn" data-action="toggle-messages">Show/Hide</button><button class="rgz-btn" data-action="clear-messages">Clear</button></div>\n              </div>\n              <div id="rgz-messages" class="rgz-message-list"></div>\n            </div>\n          </section>\n          <aside class="rgz-inspector" id="rgz-inspector"></aside>\n        </main>\n        <div class="rgz-toast-wrap" id="rgz-toasts"></div>\n      </div>\n    `),
    (m = document.getElementById("rgz-canvas")),
    (v = document.getElementById("rgz-inspector")),
    (f = document.getElementById("rgz-library")),
    (b = document.getElementById("rgz-messages")),
    (x = document.getElementById("rgz-status-dot")),
    (w = document.getElementById("rgz-coords")),
    (k = document.getElementById("rgz-print-block")),
    (m.innerHTML =
      '\n      <defs>\n        <marker id="rgz-arrow" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto" markerUnits="strokeWidth">\n          <path d="M0,0 L0,6 L9,3 z" fill="#f8fafc" />\n        </marker>\n      </defs>\n      <rect class="rgz-canvas-bg" x="-5000" y="-5000" width="10000" height="10000" fill="#07101f"></rect>\n      <g id="rgz-print-area-layer"></g>\n      <g id="rgz-connections"></g>\n      <g id="rgz-components"></g>\n    '),
    (g = document.getElementById("rgz-print-area-layer")),
    (h = document.getElementById("rgz-connections")),
    (y = document.getElementById("rgz-components")),
    R(),
    n.addEventListener(
      "pointerdown",
      (e) => {
        const t = e.target.closest('[data-action="stop"]'),
          r = e.target.closest("[data-control-kind]");
        if (t) return (e.preventDefault(), e.stopPropagation(), void De());
        r &&
          (e.preventDefault(),
          e.stopPropagation(),
          (r.dataset.rgzPointerHandled = String(Date.now())),
          Le(r));
      },
      !0,
    ),
    n.addEventListener("click", (t) => {
      const r = t.target.closest("[data-control-kind]");
      if (r) {
        const e = Number(r.dataset.rgzPointerHandled || 0);
        if (e && Date.now() - e < 800) return;
        return (t.preventDefault(), t.stopPropagation(), void Le(r));
      }
      const a = t.target.closest("[data-action]");
      a &&
        (t.preventDefault(),
        (function (t) {
          switch (t) {
            case "toggle-library":
              nt("library");
              break;
            case "toggle-actions":
              nt("actions");
              break;
            case "toggle-inspector":
              nt("inspector");
              break;
            case "toggle-messages":
              !(function () {
                const e = n.querySelector(".rgz-bottom-panel");
                e && e.classList.toggle("rgz-open");
              })();
              break;
            case "toggle-live-controls":
              !(function () {
                const e = document.getElementById("rgz-mobile-live-controls");
                e && e.classList.toggle("rgz-collapsed");
              })();
              break;
            case "toggle-file-menu":
              !(function () {
                const e = document.getElementById("rgz-file-menu");
                e && e.classList.toggle("open");
              })();
              break;
            case "zoom-in":
              rt(0.78);
              break;
            case "zoom-out":
              rt(1.28);
              break;
            case "fullscreen":
              !(async function () {
                try {
                  if (document.fullscreenElement)
                    return (
                      await document.exitFullscreen(),
                      void n.classList.remove("rgz-fallback-fullscreen")
                    );
                  n.requestFullscreen
                    ? await n.requestFullscreen()
                    : n.classList.toggle("rgz-fallback-fullscreen");
                } catch (e) {
                  n.classList.toggle("rgz-fallback-fullscreen");
                }
                setTimeout(() => {
                  (R(), H());
                }, 120);
              })();
              break;
            case "new":
              (u.components.length &&
                !window.confirm(
                  "Start a new blank circuit? Unsaved changes will be lost unless exported.",
                )) ||
                (De(),
                (u.components = []),
                (u.connections = []),
                (u.selected = null),
                (u.pendingPort = null),
                (u.projectMeta.projectName = "Untitled pneumatic circuit"),
                (u.currentExampleGlobalIndex = null),
                (u.nextId = 1),
                H(),
                Me(),
                Ee(!1));
              break;
            case "insert-service-unit":
              U(
                "powerPack",
                u.viewBox.x + 160,
                u.viewBox.y + u.viewBox.h - 180,
              );
              break;
            case "insert-text":
              !(function () {
                const e = V(
                  "textLabel",
                  u.viewBox.x + 0.5 * u.viewBox.w,
                  u.viewBox.y + 100,
                  { props: { text: "متن / Custom text" } },
                );
                (u.components.push(e),
                  (u.selected = { kind: "component", id: e.id }),
                  H(),
                  Me(),
                  Pe(e.id));
              })();
              break;
            case "fit":
              lt();
              break;
            case "rotate-selected":
              ot(90);
              break;
            case "rotate-selected-ccw":
              ot(-90);
              break;
            case "check":
              Ee(!0);
              break;
            case "simulate":
              (it(),
                (function () {
                  if (u.sim.running) return;
                  if (Ee(!1).filter((e) => "error" === e.severity).length) {
                    Ie();
                    const e = n.querySelector(".rgz-bottom-panel");
                    return (
                      e && e.classList.add("rgz-open"),
                      void ct(
                        "Simulation blocked. Fix circuit errors first.",
                        "error",
                      )
                    );
                  }
                  ((function () {
                    if (!u.sim.worker)
                      try {
                        const e = new Blob(
                            [
                              `\n      function number(value, fallback){ const n = Number(value); return Number.isFinite(n) ? n : fallback; }\n      function clamp(v,min,max){ return Math.max(min, Math.min(max, v)); }\n      const fluidNet = ${rgzFluidSolve.toString()};\n      const solver = function(c, x, dt, tm){ return fluidNet({ fluid: 'air', components: c, connections: x, dt: dt, time: tm }); };\n      self.onmessage = function(event){\n        const d = event.data;\n        self.postMessage(solver(d.components || [], d.connections || [], d.dt || 0, d.time || 0));\n      };\n    `,
                            ],
                            { type: "application/javascript" },
                          ),
                          t = URL.createObjectURL(e);
                        ((u.sim.worker = new Worker(t)),
                          (u.sim.worker.onmessage = (e) => {
                            ((u.sim.workerBusy = !1), (u.sim.metrics = e.data));
                          }),
                          (u.sim.worker.onerror = () => {
                            ((u.sim.workerBusy = !1),
                              (u.sim.worker = null),
                              ct(
                                "Web Worker solver failed; using main-thread fallback.",
                                "warning",
                              ));
                          }));
                      } catch (e) {
                        u.sim.worker = null;
                      }
                  })(),
                    (u.sim.running = !0),
                    (u.inspectorTab = "simulation"),
                    (u.sim.time = 0),
                    (u.sim.last = performance.now()),
                    (u.sim.lastCanvasRender = 0),
                    n.classList.remove("rgz-show-actions"));
                  const e = document.getElementById("rgz-mobile-live-controls");
                  (e && e.classList.remove("rgz-collapsed"),
                    Fe(),
                    Me(),
                    Ce(),
                    ct(
                      "Simulation started. Use live valve controls or the Properties panel to change states.",
                      "ok",
                    ),
                    (u.sim.raf = requestAnimationFrame(Re)));
                })());
              break;
            case "stop":
              De();
              break;
            case "open-charts":
              chartApi().open();
              break;
            case "set-print-area":
              Ue();
              break;
            case "clear-print-area":
              He();
              break;
            case "print":
              Ge();
              break;
            case "export-rgz":
              We();
              break;
            case "import-rgz":
              document.getElementById("rgz-import-input").click();
              break;
            case "browse-examples":
              !(function () {
                const e = n.querySelector(".rgz-modal-backdrop");
                e && e.remove();
                const t = document.createElement("div");
                ((t.className = "rgz-modal-backdrop"),
                  (t.innerHTML =
                    '\n      <div class="rgz-modal rgz-examples-modal" role="dialog" aria-modal="true" aria-label="Pre-designed circuits">\n        <div class="rgz-modal-head">\n          <div><h3>Pre-designed circuit library</h3><p>Choose a level and an example. Each level contains 15 circuits numbered 01–15.</p></div>\n          <button class="rgz-btn icon" data-modal-close>×</button>\n        </div>\n        <div class="rgz-modal-body">\n          <div class="rgz-example-modal-grid">\n            <div class="rgz-field"><label>Level</label><select class="rgz-native-select" id="rgz-level-selectbox"></select></div>\n            <div class="rgz-field"><label>Example</label><select class="rgz-native-select" id="rgz-example-selectbox"></select></div>\n          </div>\n          <div class="rgz-panel"><div class="rgz-panel-title">Selected circuit</div><p id="rgz-example-preview" class="rgz-example-preview"></p></div>\n        </div>\n        <div class="rgz-modal-foot"><span>Symmetrical examples load as editable drawings.</span><button class="rgz-btn" data-modal-close>Cancel</button><button class="rgz-btn primary" data-modal-open-example>Open selected circuit</button></div>\n      </div>\n    '),
                  n.appendChild(t),
                  mt());
                const r = () => {
                  const e = ut(u.exampleLevel),
                    r = e[u.exampleIndex] || e[0],
                    n = t.querySelector("#rgz-example-preview");
                  n &&
                    r &&
                    (n.textContent = `${String(u.exampleIndex + 1).padStart(2, "0")} — ${r.name}`);
                };
                (r(),
                  t.addEventListener("click", (e) => {
                    if (e.target.closest("[data-modal-open-example]"))
                      return (gt(), void t.remove());
                    ((e.target === t ||
                      e.target.closest("[data-modal-close]")) &&
                      t.remove(),
                      setTimeout(r, 0));
                  }));
              })();
              break;
            case "load-example":
              gt();
              break;
            case "add-example-template":
              !(async function () {
                if (!e.canManageExamples)
                  return void ct(
                    "Only the site owner can add pre-designed circuits.",
                    "error",
                  );
                if (!u.components.length)
                  return void ct(
                    "Design something first, then add it as a new pre-designed circuit.",
                    "warning",
                  );
                const t = (
                  window.prompt("Title for the new pre-designed circuit:") || ""
                ).trim();
                if (!t) return;
                const r = dt(),
                  n = u.exampleLevel || r[0] || "Owner custom circuits",
                  a =
                    (
                      window.prompt(
                        `Level/category for this circuit:\n\nExisting levels:\n${r.join("\n")}\n\nYou can type a new level too.`,
                        n,
                      ) || ""
                    ).trim() || "Owner custom circuits",
                  i = I();
                ((i.metadata.projectName = t),
                  (i.metadata.notes = `Owner-added pre-designed RGZ circuit: ${t}.`));
                try {
                  const r = await Ze(
                    "rgz_pneumatic_add_example",
                    { name: t, level: a, project_json: JSON.stringify(i) },
                    e.saveNonce,
                  );
                  ((e.customExamples = e.customExamples || []),
                    e.customExamples.push(r.item),
                    ht.push({
                      level: r.item.level,
                      name: r.item.name,
                      customId: r.item.id,
                      builder: () => M(r.item.project),
                    }),
                    (u.exampleLevel = r.item.level),
                    (u.exampleIndex = ut(u.exampleLevel).length - 1),
                    ct("New pre-designed circuit added for all users.", "ok"));
                } catch (e) {
                  ct(e.message, "error");
                }
              })();
              break;
            case "save-example-template":
              !(async function () {
                if (!e.canManageExamples)
                  return void ct(
                    "Only the site owner can save pre-designed circuits.",
                    "error",
                  );
                const t = u.currentExampleGlobalIndex;
                if (null == t)
                  return void ct(
                    "Open a pre-designed circuit first, edit it, then save it as the shared template.",
                    "warning",
                  );
                const r = ht[t];
                if (!r) return;
                if (
                  !window.confirm(
                    `Save the current drawing as the shared pre-designed circuit for all users?\n\n${r.level} — ${r.name}`,
                  )
                )
                  return;
                const n = I();
                ((n.metadata.projectName = r.name),
                  (n.metadata.notes = `Owner-modified pre-designed RGZ circuit: ${r.name}.`));
                try {
                  const r = await Ze(
                    "rgz_pneumatic_save_example",
                    { index: t, project_json: JSON.stringify(n) },
                    e.saveNonce,
                  );
                  ((e.exampleOverrides = e.exampleOverrides || {}),
                    (e.exampleOverrides[String(t)] = r.project || n),
                    ct(
                      "Pre-designed circuit saved. Everyone will now load this version.",
                      "ok",
                    ));
                } catch (e) {
                  ct(e.message, "error");
                }
              })();
              break;
            case "reset-example-template":
              !(async function () {
                if (!e.canManageExamples) return;
                const t = u.currentExampleGlobalIndex;
                if (null == t)
                  return void ct(
                    "Open a pre-designed circuit first.",
                    "warning",
                  );
                const r = ht[t];
                if (
                  r &&
                  window.confirm(
                    `Reset this pre-designed circuit to the built-in version?\n\n${r.name}`,
                  )
                )
                  try {
                    (await Ze(
                      "rgz_pneumatic_reset_example",
                      { index: t },
                      e.saveNonce,
                    ),
                      e.exampleOverrides &&
                        delete e.exampleOverrides[String(t)],
                      D(yt(t)),
                      (u.currentExampleGlobalIndex = t),
                      ct(
                        "Pre-designed circuit reset to built-in version.",
                        "ok",
                      ));
                  } catch (e) {
                    ct(e.message, "error");
                  }
              })();
              break;
            case "account":
              Xe();
              break;
            case "clear-messages":
              ((u.messages = []), Ie());
              break;
            case "delete-selected":
              st();
              break;
            case "duplicate-selected":
              !(function () {
                if ("component" !== u.selected?.kind) return;
                const e = u.components.find((e) => e.id === u.selected.id);
                if (!e) return;
                const t = L(e.type),
                  r = V(e.type, e.x + 60, e.y + 60, { props: M(e.props) });
                ((r.label = `${t.prefix}${u.nextId - 1}`),
                  u.components.push(r),
                  (u.selected = { kind: "component", id: r.id }),
                  H(),
                  Me());
              })();
          }
          (["toggle-file-menu"].includes(t) ||
            (function () {
              const e = document.getElementById("rgz-file-menu");
              e && e.classList.remove("open");
            })(),
            [
              "toggle-library",
              "toggle-actions",
              "toggle-inspector",
              "toggle-messages",
            ].includes(t) ||
              (window.matchMedia(
                "(max-width: 920px) and (orientation: landscape)",
              ).matches &&
                n.classList.remove(
                  "rgz-show-library",
                  "rgz-show-actions",
                  "rgz-show-inspector",
                )));
        })(a.getAttribute("data-action")));
    }),
    m.addEventListener("dragover", (e) => e.preventDefault()),
    m.addEventListener("drop", (e) => {
      e.preventDefault();
      const t = e.dataTransfer.getData("application/rgz-component");
      if (!t) return;
      const r = j(e);
      U(t, r.x, r.y);
    }),
    m.addEventListener("pointerdown", (e) => {
      (e.ctrlKey ||
        e.metaKey ||
        e.target === m ||
        e.target.classList.contains("rgz-canvas-bg")) &&
        F(e);
    }),
    m.addEventListener("pointermove", (e) => {
      const t = j(e);
      if (
        ((w.textContent = `x: ${Math.round(t.x)} · y: ${Math.round(t.y)}`),
        u.drag)
      )
        if ("component" === u.drag.kind) {
          const t = u.components.find((e) => e.id === u.drag.id);
          if (!t) return;
          const r = j(e);
          ((t.x = A(u.drag.startX + (r.x - u.drag.startPoint.x))),
            (t.y = A(u.drag.startY + (r.y - u.drag.startPoint.y))),
            H());
        } else if ("pan" === u.drag.kind) {
          const t = u.viewBox.w / m.clientWidth,
            r = u.viewBox.h / m.clientHeight;
          ((u.viewBox.x =
            u.drag.startViewBox.x - (e.clientX - u.drag.startClientX) * t),
            (u.viewBox.y =
              u.drag.startViewBox.y - (e.clientY - u.drag.startClientY) * r),
            R());
        }
    }),
    m.addEventListener("pointerup", (e) => {
      if (u.drag) {
        u.drag = null;
        try {
          m.releasePointerCapture(e.pointerId);
        } catch (e) {}
      }
      e.ctrlKey || e.metaKey || m.classList.remove("rgz-ctrl-pan");
    }),
    m.addEventListener(
      "wheel",
      (e) => {
        e.preventDefault();
        const t = j(e),
          r = e.deltaY > 0 ? 1.12 : 0.88,
          n = u.viewBox;
        ((n.x = t.x - (t.x - n.x) * r),
          (n.y = t.y - (t.y - n.y) * r),
          (n.w = S(n.w * r, 300, 5e3)),
          (n.h = S(n.h * r, 200, 3500)),
          R());
      },
      { passive: !1 },
    ),
    document.addEventListener("keydown", (e) => {
      if (
        (("Control" !== e.key && "Meta" !== e.key) ||
          m.classList.add("rgz-ctrl-pan"),
        "Delete" === e.key || "Backspace" === e.key)
      ) {
        const e = String(document.activeElement?.tagName || "").toLowerCase();
        ["input", "textarea", "select"].includes(e) || st();
      }
      (e.ctrlKey || e.metaKey) &&
        "s" === e.key.toLowerCase() &&
        (e.preventDefault(), We());
    }),
    document.addEventListener("keyup", (e) => {
      ("Control" !== e.key && "Meta" !== e.key) ||
        m.classList.remove("rgz-ctrl-pan");
    }),
    window.addEventListener("blur", () => m.classList.remove("rgz-ctrl-pan")),
    document.getElementById("rgz-search").addEventListener("input", (e) => {
      ((u.search = e.target.value), O());
    }),
    document
      .getElementById("rgz-import-input")
      .addEventListener("change", (e) => {
        const t = e.target.files?.[0];
        t &&
          (async function (e) {
            await Je(new Uint8Array(await e.arrayBuffer()));
          })(t).finally(() => {
            e.target.value = "";
          });
      }),
    window.addEventListener("orientationchange", () => setTimeout(it, 450)),
    window.addEventListener("resize", () => {
      (at(), setTimeout(it, 150));
    }),
    window.visualViewport &&
      window.visualViewport.addEventListener("resize", at),
    n.addEventListener("pointerdown", it, { once: !1 }),
    O(),
    mt(),
    (u.components = []),
    (u.connections = []),
    (u.selected = null),
    (u.pendingPort = null),
    (u.currentExampleGlobalIndex = null),
    H(),
    Ie(),
    Me(),
    (async function () {
      if (u.accountToken)
        try {
          const e = await Ze("rgz_pneumatic_me");
          ((u.user = e.user || null),
            u.user ||
              ((u.accountToken = ""),
              localStorage.removeItem("rgzPneumaticAccountToken")));
        } catch (e) {
          ((u.user = null),
            (u.accountToken = ""),
            localStorage.removeItem("rgzPneumaticAccountToken"));
        }
    })(),
    setTimeout(it, 500),
    ct(
      "RGZ Pneumatic Studio loaded. Drag a symbol onto the canvas or load an example.",
      "ok",
    ));
})();


/*! RGZ Studio welcome + guided tour — first-visit popup ("Go to app" / "Start tutorial") and spotlight walkthrough. */
(() => {
  "use strict";
  function RgzTourEngine(appKey, rootEl) {
    const pne = appKey === "pneumatic";
    const fluid = pne ? "pneumatic" : "hydraulic";
    const appName = pne ? "RGZ Pneumatic Studio" : "RGZ Hydraulic Studio";
    const steps = [
      { sel: null, title: "Welcome to " + appName, text: "This short guided tour shows the main areas of the app — symbol library, canvas, validation and live simulation. It takes less than a minute. You can skip it at any time with the Skip button or the Esc key." },
      { sel: '[data-action="browse-examples"]', pos: "right", title: "Circuit library", text: "Start fast: open the pre-designed circuit library. Every example can be loaded, edited and simulated — from simple " + fluid + " circuits to advanced proportional and sequencing systems." },
      { sel: "#rgz-search", pos: "right", title: "Find components", text: "Type here to filter the symbol library — pumps, valves, cylinders, sensors and more, all drawn with ISO 1219 style symbols." },
      { sel: "#rgz-library", pos: "right", title: "Symbol library", text: "Drag any symbol from here onto the canvas (or double-click it). Click a component to edit its properties in the panel on the right." },
      { sel: "#rgz-canvas", pos: "top", title: "Design canvas", text: "Build your circuit here. Click one port, then a second port, to connect them with a pipe line. Drag to move, scroll to zoom, and use right-click or the toolbar for more actions." },
      { sel: "#rgz-inspector", pos: "left", title: "Properties", text: "Select any component or line and tune it here — cylinder bore and stroke, valve settings, pipe diameter, and the states used during simulation." },
      { sel: '[data-action="check"]', pos: "bottom", title: "Validate the circuit", text: "Check runs the built-in rule engine: it verifies ports, sources, returns and control wiring, and explains every problem it finds." },
      { sel: '[data-action="simulate"]', pos: "bottom", title: "Live simulation", text: "Simulate animates the circuit in real time: directional valve spools slide to their active position, cylinders extend and retract, and pressure, flow and power are computed live." },
      { sel: "#rgz-messages", pos: "top", title: "Messages & results", text: "Validation findings, warnings and simulation notes appear here — each one explains what to fix and why." },
      { sel: '[data-action="toggle-file-menu"]', pos: "bottom", title: "File menu", text: "Save / export your design as an .rgz file, import it later, print to PDF, or sign in to keep designs in your account. Enjoy " + appName + "!" },
    ];
    let overlay = null, dimT = null, dimB = null, dimL = null, dimR = null, ring = null, card = null, idx = 0, alive = false, onEnd = null;
    const valid = () => steps.filter((s) => !s.sel || rootEl.querySelector(s.sel));
    function destroy() {
      if (!alive) return;
      alive = false;
      window.removeEventListener("resize", layout, true);
      document.removeEventListener("keydown", onKey, true);
      window.removeEventListener("scroll", layout, true);
      if (overlay && overlay.parentNode) overlay.parentNode.removeChild(overlay);
      if (onEnd) { const f = onEnd; onEnd = null; f(); }
    }
    function onKey(ev) {
      if (ev.key === "Escape") { ev.preventDefault(); destroy(); }
      else if (ev.key === "ArrowRight" || ev.key === "Enter") { ev.preventDefault(); next(); }
      else if (ev.key === "ArrowLeft") { ev.preventDefault(); prev(); }
    }
    function next() { const list = valid(); if (idx >= list.length - 1) return destroy(); idx++; show(); }
    function prev() { if (idx > 0) { idx--; show(); } }
    function layout() {
      if (!alive) return;
      const list = valid(); if (!list.length) return destroy();
      if (idx >= list.length) idx = list.length - 1;
      const s = list[idx];
      const vw = window.innerWidth, vh = window.innerHeight;
      let r = null;
      if (s.sel) {
        const el = rootEl.querySelector(s.sel);
        if (el) r = el.getBoundingClientRect();
        if (r && (r.width < 2 || r.height < 2)) r = null;
      }
      const pad = 8;
      const bx = r ? Math.max(0, r.left - pad) : 0, by = r ? Math.max(0, r.top - pad) : 0,
        bw = r ? r.width + pad * 2 : 0, bh = r ? r.height + pad * 2 : 0;
      const put = (el, x, y, w, h) => {
        el.style.left = x + "px"; el.style.top = y + "px";
        el.style.width = Math.max(0, w) + "px"; el.style.height = Math.max(0, h) + "px";
      };
      if (r) {
        put(dimT, 0, 0, vw, by); put(dimB, 0, by + bh, vw, vh - by - bh);
        put(dimL, 0, by, bx, bh); put(dimR, bx + bw, by, vw - bx - bw, bh);
        ring.style.display = "block"; put(ring, bx, by, bw, bh);
      } else {
        put(dimT, 0, 0, vw, vh); put(dimB, 0, 0, 0, 0); put(dimL, 0, 0, 0, 0); put(dimR, 0, 0, 0, 0);
        ring.style.display = "none";
      }
      const cw = 340, chh = card.offsetHeight || 190, gap = 14;
      let cx, cy, pos = s.pos || "bottom";
      if (!r) { cx = (vw - cw) / 2; cy = Math.max(24, (vh - chh) / 2 - 30); }
      else if (pos === "bottom") { cx = bx + bw / 2 - cw / 2; cy = by + bh + gap; if (cy + chh > vh - 10) cy = by - chh - gap; }
      else if (pos === "top") { cx = bx + bw / 2 - cw / 2; cy = by - chh - gap; if (cy < 10) cy = by + bh + gap; }
      else if (pos === "left") { cx = bx - cw - gap; cy = by + bh / 2 - chh / 2; if (cx < 10) cx = bx + bw + gap; }
      else { cx = bx + bw + gap; cy = by + bh / 2 - chh / 2; if (cx + cw > vw - 10) cx = bx - cw - gap; }
      cx = Math.max(10, Math.min(vw - cw - 10, cx));
      cy = Math.max(10, Math.min(vh - chh - 10, cy));
      card.style.left = cx + "px"; card.style.top = cy + "px"; card.style.width = cw + "px";
    }
    function show() {
      const list = valid(); if (!list.length) return;
      const s = list[idx];
      const el = s.sel ? rootEl.querySelector(s.sel) : null;
      if (el && el.scrollIntoView) { try { el.scrollIntoView({ block: "center", inline: "center" }); } catch (e5) {} }
      card.querySelector(".rgz-tour-step").textContent = "Step " + (idx + 1) + " of " + list.length;
      card.querySelector(".rgz-tour-title").textContent = s.title;
      card.querySelector(".rgz-tour-text").textContent = s.text;
      card.querySelector(".rgz-tour-back").disabled = idx === 0;
      card.querySelector(".rgz-tour-next").textContent = idx === list.length - 1 ? "Finish" : "Next";
      const dots = card.querySelector(".rgz-tour-dots");
      dots.innerHTML = "";
      list.forEach((_, i) => {
        const d = document.createElement("span");
        d.className = "rgz-tour-dot" + (i === idx ? " on" : "");
        dots.appendChild(d);
      });
      setTimeout(layout, 60);
      layout();
    }
    return function start(done) {
      try {
        if (alive || !rootEl.querySelector(".rgz-app")) return false;
        if (!valid().length) return false;
        onEnd = done || null;
        alive = true;
        overlay = document.createElement("div");
        overlay.className = "rgz-tour";
        overlay.setAttribute("role", "dialog");
        overlay.setAttribute("aria-label", appName + " guided tour");
        dimT = document.createElement("div"); dimB = document.createElement("div");
        dimL = document.createElement("div"); dimR = document.createElement("div");
        [dimT, dimB, dimL, dimR].forEach((d) => { d.className = "rgz-tour-dim"; overlay.appendChild(d); });
        ring = document.createElement("div");
        ring.className = "rgz-tour-ring";
        overlay.appendChild(ring);
        card = document.createElement("div");
        card.className = "rgz-tour-card";
        card.innerHTML =
          '<div class="rgz-tour-step"></div><div class="rgz-tour-title"></div><div class="rgz-tour-text"></div><div class="rgz-tour-dots"></div>' +
          '<div class="rgz-tour-row"><button type="button" class="rgz-tour-skip">Skip tour</button><span class="rgz-tour-spacer"></span>' +
          '<button type="button" class="rgz-tour-back">Back</button><button type="button" class="rgz-tour-next">Next</button></div>';
        overlay.appendChild(card);
        card.querySelector(".rgz-tour-skip").addEventListener("click", destroy);
        card.querySelector(".rgz-tour-next").addEventListener("click", next);
        card.querySelector(".rgz-tour-back").addEventListener("click", prev);
        overlay.addEventListener("click", (ev) => {
          if (ev.target === dimT || ev.target === dimB || ev.target === dimL || ev.target === dimR) destroy();
        });
        document.body.appendChild(overlay);
        window.addEventListener("resize", layout, true);
        window.addEventListener("scroll", layout, true);
        document.addEventListener("keydown", onKey, true);
        idx = 0;
        show();
        return true;
      } catch (err) { return false; }
    };
  }

  function RgzStudioWelcome(appKey, rootId, cfg) {
    try {
      const rootEl = document.getElementById(rootId);
      if (!rootEl || !document.body) return;
      const pne = appKey === "pneumatic";
      const appName = pne ? "Pneumatic Studio" : "Hydraulic Studio";
      const storeKey = "rgz.welcome.v2." + appKey;
      const startTour = RgzTourEngine(appKey, rootEl);
      let q = "";
      try { q = new URLSearchParams(window.location.search).get("rgz_tour") || ""; } catch (e0) {}

      function markSeen() {
        try { window.localStorage && window.localStorage.setItem(storeKey, new Date().toISOString()); } catch (e1) {}
      }
      function wasSeen() {
        try { return !!(window.localStorage && window.localStorage.getItem(storeKey)); } catch (e2) { return false; }
      }
      function launchTour() {
        let tries = 0;
        (function wait() {
          if (startTour()) return;
          if (++tries > 40) return;
          setTimeout(wait, 200);
        })();
      }

      /* Forced launch for admins: ?rgz_tour=1 or ?rgz_tour=hydraulic — tour directly, no popup. */
      if (q === "1" || q.toLowerCase() === appKey) { launchTour(); return; }
      /* Tours disabled from the backend → nothing at all. */
      if (cfg && cfg.tutorial === false) return;
      /* Only the very first visit shows the welcome popup. */
      if (wasSeen()) return;

      const text = (cfg && cfg.tourText) ||
        ("Welcome to " + appName + "! Design, validate and simulate real " + (pne ? "pneumatic" : "hydraulic") +
          " circuits right here in your browser. New here? Take the 60-second guided tour — or jump straight into the app.");

      const back = document.createElement("div");
      back.className = "rgz-welcome";
      back.setAttribute("role", "dialog");
      back.setAttribute("aria-label", "Welcome to " + appName);
      back.innerHTML =
        '<div class="rgz-welcome-card">' +
        '<button type="button" class="rgz-welcome-x" aria-label="Close">×</button>' +
        '<div class="rgz-welcome-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' +
        (pne
          ? '<path d="M3 11h9.5a3 3 0 1 0-3-3"/><path d="M3 15.5h13.5a3 3 0 1 1-3 3"/>'
          : '<path d="M12 2.7s6.5 7.2 6.5 11.6a6.5 6.5 0 0 1-13 0C5.5 9.9 12 2.7 12 2.7Z"/>') +
        "</svg></div>" +
        '<h3>Welcome to ' + appName + "</h3>" +
        "<p></p>" +
        '<div class="rgz-welcome-btns">' +
        '<button type="button" class="rgz-welcome-go">Go to ' + appName + "</button>" +
        '<button type="button" class="rgz-welcome-tour">▶ Start tutorial</button>' +
        "</div></div>";
      back.querySelector("p").textContent = text;
      function close() { if (back.parentNode) back.parentNode.removeChild(back); }
      back.querySelector(".rgz-welcome-go").addEventListener("click", () => { markSeen(); close(); });
      back.querySelector(".rgz-welcome-x").addEventListener("click", () => { markSeen(); close(); });
      back.querySelector(".rgz-welcome-tour").addEventListener("click", () => {
        markSeen(); close(); launchTour();
      });
      back.addEventListener("click", (ev) => { if (ev.target === back) { markSeen(); close(); } });
      document.addEventListener("keydown", function esc(ev) {
        if (ev.key === "Escape") { document.removeEventListener("keydown", esc); markSeen(); close(); }
      });
      setTimeout(() => { try { document.body.appendChild(back); } catch (e3) {} }, 450);
    } catch (err) { /* welcome popup never breaks the app */ }
  }

  if (document.getElementById("rgz-hydraulic-studio"))
    RgzStudioWelcome("hydraulic", "rgz-hydraulic-studio", window.RGZHydraulicStudioConfig || {});
  else if (document.getElementById("rgz-pneumatic-studio"))
    RgzStudioWelcome("pneumatic", "rgz-pneumatic-studio", window.RGZPneumaticStudioConfig || {});
})();
