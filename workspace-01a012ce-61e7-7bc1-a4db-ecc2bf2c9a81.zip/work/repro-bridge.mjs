// Repro: slip-in logic 4-way bridge press — extend/deadhead/float-center/retract
import fs from "fs";
const src = fs.readFileSync(new URL("./solver.js", import.meta.url), "utf8");
eval(src + "\nglobalThis.rgzFluidSolve = rgzFluidSolve;");
const solve = globalThis.rgzFluidSolve;
const model = JSON.parse(fs.readFileSync(new URL("./models/hyd-cart-3-bridge.json", import.meta.url), "utf8"));
const comps = model.components.filter(c => c.type !== "textLabel");
[['GCA','C-4','A'],['GCB','C-4','B'],['X1','LCV-6','X'],['X2','LCV-7','X']].forEach(([g,ci,pi])=>{
  comps.push({id:g,type:'pressureGauge',label:g,x:0,y:0,rotation:0,props:{}});
  model.connections.push({id:g,from:{componentId:ci,portId:pi},to:{componentId:g,portId:'P'},lineType:'pressure',properties:{tubeIdMm:12,lengthM:1}});
});
const V = comps.find(c=>c.type==='directionalValve');
const CY = comps.find(c=>c.type==='cylinderDA');
CY.props.simPosition = 0.05;
solve._dyn = null;
let m, t=0; const dt=0.05;
function step(sec,label){
  for(let i=0,n=Math.round(sec/dt);i<n;i++){
    m=solve({fluid:'oil',components:comps,connections:model.connections,dt,time:t});t+=dt;
    const v=m.cylinders[0].speedMmS;
    CY.props.simPosition=Math.min(1,Math.max(0,CY.props.simPosition+v*dt/(CY.props.strokeMm||300)));
  }
  console.log(label,'pos=',(CY.props.simPosition*100).toFixed(0)+'%','v=',m.cylinders[0].speedMmS.toFixed(0),'capA=',m.comp.GCA.pressureBar.toFixed(1),'rodB=',m.comp.GCB.pressureBar.toFixed(1),'pumpP=',m.comp['PG-5'].pressureBar.toFixed(1),'X1=',m.comp.X1.pressureBar.toFixed(1),'X2=',m.comp.X2.pressureBar.toFixed(1),'kW=',(m.powerKw||0).toFixed(1));
}
V.props.spoolState='left';   step(3,'EXTEND      ');
step(3,'DEADHEAD    ');
const posA=CY.props.simPosition;
V.props.spoolState='center'; step(2,'CENTER float ');
const posB=CY.props.simPosition;
V.props.spoolState='right';  step(4,'RETRACT     ');
console.log('extend end pos',(posA*100).toFixed(0)+'% (expect 100)','center pos',(posB*100).toFixed(0)+'% (float: may drift down)','final',(CY.props.simPosition*100).toFixed(0)+'% (expect ~0)');
