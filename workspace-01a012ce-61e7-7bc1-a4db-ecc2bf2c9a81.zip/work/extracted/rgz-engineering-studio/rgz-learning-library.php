<?php
/**
 * RGZ Learning Library — the component encyclopedia for the Learning Hub.
 *
 * Two structured lesson series (hydraulics + pneumatics) that describe every
 * studio element, its key parameters, and its applications in real circuits.
 * Lessons are rendered from compact data rows through one professional
 * template, so all 250+ entries are consistent and easy to extend.
 *
 * Part of the RGZ Engineering Studio plugin. Version 1.0.0.
 */
if (!defined('ABSPATH')) { exit; }

/* ------------------------------------------------------------------ */
/* Renderer: one uniform, professional lesson layout                   */
/* ------------------------------------------------------------------ */
/* Animated GIF bundled with the lessons that really need motion to click.
   Files ship in assets/learn/ (tiny hand-drawn ISO-styled loops). */
function rgz_ll_anim_for($id) {
    static $map = null;
    if ($map === null) {
        $map = [
            'anim-hyd-dcv-spool.gif' => [
                'Solenoid energised: the spool slides and the port paths swap — exactly what the studio does when you toggle Y1/Y2.',
                ['hl-dcv-43', 'hl-dcv-42', 'hl-proportional-valve', 'hl-servo-valve'],
            ],
            'anim-hyd-cylinder-cycle.gif' => [
                'One full duty cycle of a 4/3-driven cylinder: extend, centre lock, retract.',
                ['hl-cylinder-da', 'hl-cylinder-sa', 'hl-cyl-cushion', 'hl-pos-cylinder'],
            ],
            'anim-hyd-relief-pops.gif' => [
                'Dead-headed pump: pressure climbs… and the relief cracks right at its setting. That orange bar is why the setting matters.',
                ['hl-relief-valve', 'hl-pressure-reducing', 'hl-sequence-valve', 'hl-unloading-valve', 'hl-brake-valve', 'hl-crossrelief'],
            ],
            'anim-hyd-pump-flow.gif' => [
                'The pump keeps the loop alive — flow never stops, valves only steer it.',
                ['hl-gear-pump', 'hl-vane-pump', 'hl-variable-pump', 'hl-screw-pump', 'hl-hand-pump', 'hl-pump-acceptance'],
            ],
            'anim-pne-52-switch.gif' => [
                'Y1 vs Y2 on a 5/2: ports 1→2 / 1→4 swap and the single cylinder drives out and back.',
                ['pl-cyl-da', 'pl-cyl-sa', 'pl-cyl-cushion', 'pl-cyl-rodless', 'pl-ckt-direct-sa', 'pl-ckt-indirect', 'pl-dump-valve', 'pl-ckt-latching-ma'],
            ],
            'anim-pne-sequence.gif' => [
                'A+ B+ B− A− as a living loop — the four steps any sequence circuit must guarantee in order.',
                ['pl-ckt-auto-return', 'pl-ckt-pressure-seq', 'pl-ckt-cascade', 'pl-ckt-stepper', 'pl-ckt-pick-place-full', 'pl-ckt-sequence-troubleshoot', 'pl-ckt-oscillating'],
            ],
        ];
    }
    foreach ($map as $file => $info) {
        if (in_array($id, $info[1], true)) return [$file, $info[0]];
    }
    return null;
}

function rgz_ll_render($r) {
    $h = '<figure class="rgzl-fig rgzl-draw">' . rgz_ll_figure($r) . '<figcaption>' . $r['t'] . '</figcaption></figure>';
    $h = '<p><em>' . $r['sm'] . '</em></p>' . $h;
    $anim = rgz_ll_anim_for(isset($r['id']) ? $r['id'] : '');
    if ($anim) {
        $h .= '<figure class="rgzl-fig rgzl-anim"><img src="' . esc_url(plugin_dir_url(__FILE__) . 'assets/learn/' . $anim[0]) . '" alt="' . esc_attr($anim[1]) . '" loading="lazy"><figcaption>' . esc_html($anim[1]) . '</figcaption></figure>';
    }
    $h .= '<h3>What it is</h3><p>' . $r['w'] . '</p>';
    $h .= '<h3>How it works</h3><p>' . $r['h'] . '</p>';
    if (!empty($r['f'])) { $h .= '<div class="rgzl-formula">' . $r['f'] . '</div>'; }
    if (!empty($r['s'])) { $h .= '<h3>Key parameters &amp; selection</h3><p>' . $r['s'] . '</p>'; }
    if (!empty($r['a']) && is_array($r['a'])) {
        $h .= '<h3>Typical applications in circuits</h3><ul>';
        foreach ($r['a'] as $li) { $h .= '<li>' . $li . '</li>'; }
        $h .= '</ul>';
    }
    if (!empty($r['x'])) { $h .= '<div class="rgzl-tip"><strong>Studio exercise:</strong> ' . $r['x'] . '</div>'; }
    return $h;
}

function rgz_ll_lesson($r, $topic) {
    return [
        'id'      => $r['id'],
        'cover'   => rgz_ll_cover($r['id'], $topic),
        'title'   => $r['t'],
        'summary' => $r['sm'],
        'topic'   => $topic,
        'level'   => $r['lv'],
        'minutes' => $r['min'],
        'enabled' => true,
        'content' => rgz_ll_render($r),
    ];
}

/* ------------------------------------------------------------------ */
/* HYDRAULICS — elements (library part 1)                              */
/* ------------------------------------------------------------------ */
function rgz_ll_hyd_elements() {
    $D = [];
    $D[] = ['id' => 'hl-powerpack', 't' => 'Hydraulic power pack (HPU)', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'The heart of every system: tank, motor, pump and relief valve in one unit.',
        'w' => 'The power pack converts electrical energy into hydraulic flow. In the Studio it is one symbol exposing P (pressure) and T (tank) ports, but physically it contains the tank, the electric motor, the pump, the pressure relief valve and usually the breather, level gauge and suction strainer.',
        'h' => 'The motor drives the pump at constant speed (4-pole ≈ 1450 rpm at 50 Hz). The pump draws oil from the tank through the suction line and delivers a fixed flow to P. When the actuators stop consuming flow, pressure climbs until the relief valve opens and dumps oil back to T — limiting the maximum system pressure.',
        'f' => 'P<sub>drive</sub> (kW) ≈ p (bar) × Q (l/min) / (600 · η<sub>total</sub>)',
        's' => 'Specify by pump flow (l/min), relief setting (bar, the system ceiling!) and motor power (kW). Tank volume is typically 2–4× the pump flow per minute for stationary units. Relief = 1.1–1.15× the highest working pressure.',
        'a' => ['Every stationary hydraulic machine: presses, lifts, clamps, test rigs.',
                'Compact "mini power packs" for docks, tail lifts and tools.',
                'In simulation: the single energy source of every circuit — gauges, temperature and efficiency metrics all trace back to it.'],
        'x' => 'Build a minimal circuit (power pack → 4/2 valve → cylinder), note pump pressure at idle vs under load, then set the relief 20 bar lower and watch the cylinder stall exactly at the new ceiling.'];
    $D[] = ['id' => 'hl-gear-pump', 't' => 'External gear pump', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'The workhorse: simple, cheap, robust fixed-displacement delivery.',
        'w' => 'Two meshing gears in a tight housing transport oil in the tooth gaps from suction to pressure side. It is the most common industrial pump because of its tolerance to dirt, low price and simple construction.',
        'h' => 'As the gears unmesh on the suction side, the expanding volume draws oil in; the oil travels around the housing wall (never between the teeth!) and is squeezed out where the gears mesh again. Flow per revolution is fixed by the tooth volume (displacement V<sub>g</sub>).',
        'f' => 'Q (l/min) = V<sub>g</sub> (cm³/rev) × n (rpm) × η<sub>vol</sub> / 1000',
        's' => 'Sizes 0.25–250 cm³/rev, continuous pressures to ~250 bar (300 peak). Volumetric efficiency 85–95 %, drops with wear and with low-viscosity hot oil. Noisy above ~2000 rpm.',
        'a' => ['Standard choice for cost-sensitive power packs up to medium pressure.',
                'Multiple-section gear pumps feed independent circuits from one shaft.',
                'As lubrication/scavenge pumps inside transmissions.'],
        'x' => 'In the Studio power pack, compare relief heating at full flow: simulate a blocked circuit 60 s and watch oil temperature climb — that is a gear pump working purely against the relief.'];
    $D[] = ['id' => 'hl-variable-pump', 't' => 'Variable-displacement piston pump', 'lv' => 'intermediate', 'min' => 6,
        'sm' => 'Swashplate control: flow follows demand instead of the relief valve.',
        'w' => 'An axial-piston pump whose displacement is adjustable while running — usually by tilting the swashplate. A compensator piston moves the plate against a spring, so the pump itself regulates its output.',
        'h' => 'When system pressure reaches the compensator setting, a small control spool admits pressure to the destroking piston: the swashplate flattens and the pump delivers only leakage/compensation flow. Pressure stays constant while flow follows the consumers — no relief throttling, far less heat.',
        'f' => 'Q<sub>max</sub> = V<sub>g,max</sub> × n / 1000 &nbsp;|&nbsp; standby loss ≈ 2–5 % of rated power',
        's' => 'Pressures to 350 bar continuous. Controls: pressure compensator, load-sensing, power limiting, electric proportional. More expensive and more sensitive to contamination (ISO 4406 class ~19/17/14 or better) than gear pumps.',
        'a' => ['Machines with long dwell phases (injection molding, presses) where a fixed pump would overheat the oil.',
                'Load-sensing mobile systems: flow on demand saves fuel.',
                'Servo-hydraulic test rigs needing fast pressure/stroke control.'],
        'x' => 'Compare idle behavior: simulate 30 s of dwell with a fixed pump (relief flow = full heat), then imagine the variable pump at standby — that contrast is why big machines are pressure-compensated.'];
    $D[] = ['id' => 'hl-hand-pump', 't' => 'Hand and emergency pumps', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'Muscle-powered pressure: for service, rescue and remote tools.',
        'w' => 'A lever-driven piston pump, often two-stage (large piston for fast prefill, small piston for high pressure). No electricity needed — the standard backup when the power pack fails or is unavailable.',
        'h' => 'The lever strokes a small piston; check valves rectify the motion so each stroke pushes a small volume toward the consumer. Two-stage designs switch automatically at a set pressure: high flow below ~20 bar, then a small plunger continues up to 700+ bar.',
        's' => 'Typical: 1–20 cm³ per stroke, 160–700 bar. Oil reservoir integrated. Handle effort ≤ 350 N at full pressure.',
        'a' => ['Emergency operation: retract a cylinder or release a clamp during power failure.',
                'Hydraulic rescue tools, crimpers, portable presses.',
                'Pre-charging and testing small circuits on the bench.'],
        'x' => 'Think through your own circuit: if the power pack dies mid-lift, where would a hand pump need to connect? That is exactly the "emergency release" study in the Studio examples.'];
    $D[] = ['id' => 'hl-hyd-motor', 't' => 'Hydraulic motor (gear type)', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'A pump in reverse: pressurized oil in, shaft torque out.',
        'w' => 'The gear motor converts flow back into rotation. Externally identical to a gear pump, internally modified (balanced bearings, case drain) because it starts under load and may rotate both directions.',
        'h' => 'Pressure acts on the tooth surfaces: the imbalance between the pressure and suction sides creates torque. Flow rate sets the speed; the pressure difference sets the torque. The third small port (case drain) returns internal leakage to tank without pressure.',
        'f' => 'M (Nm) ≈ Δp (bar) × V<sub>g</sub> (cm³/rev) / (20π · η<sub>hm</sub>) &nbsp;&nbsp;|&nbsp;&nbsp; n (rpm) = Q × 1000 / V<sub>g</sub>',
        's' => 'To 250 bar, 500–4000 rpm, modest starting torque (85–90 % of theoretical). Always connect the case drain directly to tank — back pressure kills the shaft seal within hours.',
        'a' => ['Conveyor and mixer drives, fan drives, winches.',
                'Rotary fixtures where an electric motor is impractical (ATEX zones).',
                'Series connection for synchronized multi-motor drives.'],
        'x' => 'Simulate a motor on a throttle-controlled supply: watch rpm follow flow linearly while pressure follows only the load torque — the two equations above, live.'];
    $D[] = ['id' => 'hl-piston-motor', 't' => 'Piston motors (axial & radial)', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'The heavyweights: high pressure, high starting torque, precise low speed.',
        'w' => 'Axial-piston motors (bent-axis or swashplate) and radial-piston motors deliver the highest torque densities. Radial designs (multi-lobe cam) rule LSHT duty: huge torque at a few rpm.',
        'h' => 'Pressure on the pistons creates force components against the swashplate or cam ring; the geometry converts them to shaft torque. Variable versions change displacement on demand — high displacement for starting, low for speed.',
        's' => 'To 450 bar; starting torque up to 95 %; radial LSHT units to several 10 000 Nm. Require clean oil (servo-grade filtration for high-speed axial types).',
        'a' => ['Winches and slew drives in cranes and excavators.',
                'Crawler/propel drives with two-speed or stepless variable motors.',
                'Mixers, crushers: steady torque at very low rpm.'],
        'x' => 'Compare gear vs piston motor in the Studio: same Δp and displacement — the piston unit holds torque at near-zero speed where the gear motor stalls (internal leakage).'];
    $D[] = ['id' => 'hl-cylinder-da', 't' => 'Double-acting hydraulic cylinder', 'lv' => 'beginner', 'min' => 6,
        'sm' => 'The universal linear actuator: force in both directions, asymmetric speeds.',
        'w' => 'A piston on a rod inside a tube, with a port on each chamber. Cap (piston) side area A<sub>K</sub> is larger than the annulus A<sub>R</sub> on the rod side — the source of unequal forces and speeds.',
        'h' => 'Pressure on the cap side extends the rod; pressure on the annulus retracts it. Same flow → faster retraction (smaller area). Same pressure → larger extend force (larger area). The ratio φ = A<sub>K</sub>/A<sub>R</sub> (1.25–2) must enter every sizing calculation.',
        'f' => 'F<sub>out</sub> = p · A<sub>K</sub> &nbsp;|&nbsp; F<sub>in</sub> = p · A<sub>R</sub> &nbsp;|&nbsp; v = Q / A &nbsp;|&nbsp; φ = A<sub>K</sub>/A<sub>R</sub>',
        's' => 'Bores 25–400 mm, rods 0.4–0.7× bore, strokes to 3+ m. Add end cushioning for kinetic energy above ~0.1 m/s with heavy loads; consider buckling for long push strokes (Studio inspector computes both).',
        'a' => ['Literally every linear task: presses, lifts, clamps, steering, tilting.',
                'Regenerative circuits exploit the area difference for fast approach + work stroke.',
                'Meter-out speed control protects against overrunning loads on vertical axes.'],
        'x' => 'In the Studio: feed 20 l/min to a Ø 63/36 cylinder, read 107 mm/s extend and ~159 mm/s retract — verify both numbers by hand (v = Q/A).'];
    $D[] = ['id' => 'hl-cylinder-sa', 't' => 'Single-acting cylinder & plunger ram', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'One port, one direction: returned by spring, load or gravity.',
        'w' => 'Only the cap chamber is pressurized; the rod side is vented. Retraction comes from a return spring, the load itself (press rams, car lifts) or external force. Plunger rams have no piston at all — the rod IS the pressure surface.',
        'h' => 'Oil in → extend (minus spring force in spring-return types). The 3/2 valve releases the chamber to tank → the spring or gravity pushes oil back. Simple, cheap, and needs no valve outlet management on the retract side.',
        's' => 'Force = p·A minus spring/gravity. Spring-return strokes limited to ~100 mm (spring packaging); plunger rams to 1 m+. Always provide a breather on the vented side — a plugged breather stalls the return.',
        'a' => ['Workshop presses and simple lifts (load-return).',
                'Clamps and ejectors (spring-return).',
                'Car hoists: one big plunger, descend on a flow control.'],
        'x' => 'Build a single-acting lift in the Studio with a 3/2 valve: extend full speed, then lower through a meter-out flow control and measure the difference.'];
    $D[] = ['id' => 'hl-telescopic', 't' => 'Telescopic cylinder', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'Long stroke from a short body: staged sleeves extend one after another.',
        'w' => 'Several nested stages (sleeves) extend in sequence — the retracted package is roughly 1/3 of the full stroke. Available single-acting (dump trucks) and double-acting.',
        'h' => 'Pressure first moves the largest sleeve (its cap area is biggest — highest force at lowest pressure); when it bottoms, the next sleeve moves. Forces step DOWN and speeds step UP with each stage, because the active area shrinks.',
        's' => 'Strokes to 10 m from ~3 m package. The largest stage sees the full stroke force; side loads are critical — the last (thin) stage tolerates almost none. Check tipping clearance and stage-seal accessibility.',
        'a' => ['Tippers/dump bodies (the classic single-acting use).',
                'Cranes, access platforms, dock levelers needing long travel in short space.',
                'Ejection cylinders in waste compactors.'],
        'x' => 'Reason it out: with pump constant, why does a telescopic tipper accelerate as it approaches full angle? (Active area shrinks per stage — same effect as annulus retraction.)'];
    $D[] = ['id' => 'hl-double-rod', 't' => 'Double-rod (through-rod) cylinder', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'A rod on both ends: equal areas, equal forces, equal speeds both ways.',
        'w' => 'The piston rod exits both end caps. Both chambers have identical annulus areas, so extend and retract are perfectly symmetric.',
        'h' => 'Because A is equal on both sides, F and v are identical in both directions — and a double-rod cylinder synchronizes naturally when two chambers are connected in series (volume in = volume out).',
        's' => 'Force is rod-side class only (no full-bore cap area!). Choose for symmetry, not for power. Excellent rigidity against bending since both ends are guided.',
        'a' => ['Synchronous drives: cable/chain-linked double-rod masters driving slave cylinders.',
                'Positioners and indexing tables where equal speeds matter.',
                'One rod for work, the other for position feedback/limits.'],
        'x' => 'Simulate two identical-motion axes: a double-rod cylinder with A-side piped into a second cylinder — the classic hydraulic series synchronization.'];
    $D[] = ['id' => 'hl-rotary-actuator', 't' => 'Rotary actuators (vane & rack-and-pinion)', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'Swiveling instead of stroking: torque through a limited angle.',
        'w' => 'Limited-rotation actuators: a vane in a circular chamber (≤ 270°, one or two vanes) or a piston driving a rack that turns a pinion (to 360°+). They replace cylinder + linkage when the motion is directly rotary.',
        'h' => 'Pressure on the vane face creates torque directly; in rack-and-pinion units, a short-stroke cylinder drives the rack, and the pinion converts stroke to angle. Adjustable end stops and cushioning are integral.',
        'f' => 'M = Δp · A<sub>vane</sub> · r &nbsp;(vane) &nbsp;|&nbsp; θ = s · 360° / (π · d<sub>pinion</sub>)',
        's' => 'Torque from a few Nm (bench grippers) to > 100 kNm (valve actuation in pipelines). Noisy T-fittings shorten vane seal life — use straight-through flow.',
        'a' => ['Indexing/tilting tables, flip units, valve actuators.',
                'Clamping arms that swing in then clamp.',
                'Where a motor would need gearing and end stops anyway.'],
        'x' => 'Note in the Studio how a rotary actuator pair can replace a linkage: compare parts count and end-stop behavior of both solutions.'];
    $D[] = ['id' => 'hl-dcv-43', 't' => '4/3 directional control valve', 'lv' => 'beginner', 'min' => 6,
        'sm' => 'The standard cylinder valve: four ports, three positions, three design blocks.',
        'w' => 'Four ports (P, T, A, B) and three spool positions. Each position connects the ports in a defined pattern — in the Studio you can now configure the left, center AND right block independently, from parallel to crossover, tandem, float, closed and regenerative.',
        'h' => 'A sliding spool with lands opens and closes port connections. Solenoids stroke it (electrohydraulics), springs return/center it. Flow forces grow with √Δp across the metering edge — the practical limit is thermal, so watch rated flow at the actual Δp.',
        'f' => 'Q<sub>valve</sub> ≈ Q<sub>nom</sub> · √(Δp<sub>actual</sub> / Δp<sub>nom</sub>)',
        's' => 'NG6 (to ~80 l/min), NG10 (~120), NG16+ per ISO 4401. Center block = machine state at rest: tandem unloads the pump while holding the load; closed locks everything; float frees the actuator.',
        'a' => ['Any reversible cylinder/motor drive.',
                'Tandem-center idle systems (energy saving between cycles).',
                'Regenerative left block + parallel right: fast approach then working stroke from one valve.'],
        'x' => 'Configure left = regenerative, center = tandem, right = parallel in the Studio: measure fast extend speed with regen vs parallel, and the idle pump pressure in center.'];
    $D[] = ['id' => 'hl-dcv-42', 't' => '4/2 & 3/2 directional valves', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'Two-position workhorses: on/off control for DA and SA actuators.',
        'w' => '4/2 valves drive double-acting cylinders with no mid position; 3/2 and 2/2 valves serve single-acting cylinders, pilot lines and function switching. Cartridge (seat) versions shift leak-free.',
        'h' => 'One solenoid strokes the spool; a spring returns it (monostable) or friction/detent holds it (bistable). Spool valves tolerate tiny leakage; seat valves seal absolutely — choose seats when a load must never creep.',
        's' => '2/2 seat valves: zero leakage, full flow both directions, the standard safety isolator. Spool 4/2 NG6 to 80 l/min. Always check "overlap at switching" for tight clamp circuits.',
        'a' => ['Bang-bang actuators: eject, clamp, simple lifts.',
                '2/2 normally-closed valves as safety dump/isolation in accumulator circuits.',
                'Pilot stages of large valves and unloading functions.'],
        'x' => 'Compare tightness: hold a load first on a 4/2 spool, then on a 2/2 seat valve — the creep difference appears on the position readout within seconds.'];
    $D[] = ['id' => 'hl-proportional-valve', 't' => 'Proportional directional valves', 'lv' => 'advanced', 'min' => 6,
        'sm' => 'Direction AND speed in one valve — spool position follows the command current.',
        'w' => 'A solenoid pair with position feedback strokes the spool proportionally to a 4–20 mA / 0–10 V command. Metering edges are shaped so flow (hence actuator speed) scales with spool travel.',
        'h' => 'The amplifier converts the command to a coil current; the spool balances magnetic force against a spring. Dither (100–200 Hz ripple) keeps the spool micro-sliding and kills friction hysteresis; ramps in the amplifier soften reversals.',
        'f' => 'Q ≈ k · x<sub>spool</sub> · √Δp — metered flow depends on command AND load pressure',
        's' => 'Hysteresis ≤ 1–3 %, deadband 10–30 % (overlapped) or near-zero (feedback spools). Demands filtered oil (ISO 4406 18/16/13 or better). Check natural-frequency margin: valve ~4× faster than the axis.',
        'a' => ['Feed axes with controlled velocity profiles and soft starts.',
                'Presses with pressure/speed transition points.',
                'Remote or joystick control of mobile functions.'],
        'x' => 'In the Studio, drive a proportional valve with the ramp generator: raise P-gain and watch the step response sharpen toward overshoot — loop tuning made visible.'];
    $D[] = ['id' => 'hl-relief-valve', 't' => 'Pressure relief valve', 'lv' => 'beginner', 'min' => 6,
        'sm' => 'The safety guardian: caps system pressure, dumps flow to tank at setting.',
        'w' => 'Normally closed, piloted from its own inlet. When inlet force exceeds the adjustable spring, the poppet/spool opens to tank. Direct-operated for small flows; pilot-operated for the main system protection.',
        'h' => 'Pilot stage (small poppet + spring) opens first; the tiny pilot flow creates a pressure drop across a spool orifice, lifting the main stage. That two-stage trick keeps the opening characteristic flat: full pump flow over setting with little overshoot.',
        's' => 'Set 1.1–1.15× max working pressure. Cracking vs full-flow pressure differ ~10 % (direct) / ~3 % (piloted). Every bar of relief-flow becomes heat: P = Δp·Q/600 kW. Vented versions enable remote/unload control.',
        'a' => ['Main protection directly after the pump — non-negotiable, always present.',
                'Branch pressure limiting instead of a second power pack.',
                'Vented: two-stage pressure selection or pump unloading via 2/2 valve.'],
        'x' => 'Studio: block the actuator, let the relief open and read total flow across it; then watch oil temperature rise in the metrics — relief flow is pure heat.'];
    $D[] = ['id' => 'hl-pressure-reducing', 't' => 'Pressure reducing valve', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Normally OPEN and piloted from its outlet: holds a branch at reduced pressure.',
        'w' => 'The mirror image of the relief: open at rest, it starts closing when its OUTLET reaches the setting, throttling the supply to hold downstream pressure constant — even with fluctuating inlet.',
        'h' => 'Outlet pressure pilot the spool against the spring. Exceed the setting → spool travels toward closed; below → fully open. Relieving versions also dump downstream overpressure to tank (important with thermal expansion in clamped volumes!).',
        's' => 'Outlet ranges typically 5–100 bar. Needs an external drain when relieving. Hysteresis ~1–3 bar; pilot flow 0.5–1 l/min continuous.',
        'a' => ['Clamp circuits: delicate workpiece needs 60 bar from a 160 bar network.',
                'Brake circuits and pilot supplies at fixed reduced pressure.',
                'Two pressures for two actuators from one power pack.'],
        'x' => 'Build the Studio example with a reduced clamp branch: run main 160 bar, clamp holds 60 — then block the pump and watch the reduced branch stay safe.'];
    $D[] = ['id' => 'hl-sequence-valve', 't' => 'Sequence valve', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Pressure logic in oil: step 2 starts only when step 1 has truly finished.',
        'w' => 'Like a relief valve, but its outlet feeds another actuator instead of tank. It opens when its inlet (the completed function’s pressure rise) proves the first step is done — a hydraulic IF/THEN.',
        'h' => 'During cylinder 1 extend, pressure is below the setting: the valve is closed, step 2 gets nothing. Cylinder 1 reaches its end stop/clamp force → pressure rises to the setting → valve opens → cylinder 2 moves. External drain is required because the outlet is pressurized.',
        's' => 'Set above the first step’s max running pressure (plus ~10–15 % margin). Combination with check valve = free reverse flow. Avoid chatter at the transition with small volumes (damped spools exist).',
        'a' => ['Clamp → drill/stamp sequences: work only starts on confirmed clamp pressure.',
                'Landing gear door → gear sequences in aircraft.',
                'Two-stage booms: extend stage 1 fully before stage 2.'],
        'x' => 'Run the Studio sequence example and read the event log: it literally prints "cylinder 1 complete → cylinder 2 starts" — pressure-based sequencing end-to-end.'];
    $D[] = ['id' => 'hl-counterbalance', 't' => 'Counterbalance (overcenter) valve', 'lv' => 'advanced', 'min' => 6,
        'sm' => 'The vertical-load valve: no runaway, no drift, controlled lowering.',
        'w' => 'A pilot-assisted relief valve mounted on the load side of a cylinder or motor. It stays CLOSED under the load pressure and opens only when the opposite side is actively driven — with back-pressure preventing runaway.',
        'h' => 'Load pressure alone cannot open it (setting chosen ~1.3× load pressure). Driving the other chamber pilots it open through the pilot piston (pilot ratio 3:1…10:1): the lowering pressure then modulates a smooth relief. Integral check valve gives free flow in the load-lifting direction.',
        'f' => 'p<sub>set</sub> ≥ 1.3 × p<sub>load</sub> &nbsp;|&nbsp; p<sub>pilot</sub> ≥ (p<sub>set</sub> − p<sub>load</sub>) / pilot-ratio',
        's' => 'Pilot ratio high (8–10): responsive, stable for static loads; low (3:1): for unstable/cycling loads. Mount directly on the cylinder port — hose-burst protection demands zero flexible line between valve and actuator.',
        'a' => ['Cranes, lifts, outriggers: every vertical or overrunning axis.',
                'Hose-burst safety: load physically trapped if a main line fails.',
                'Winches and slew motors against overspeed.'],
        'x' => 'Simulate lowering a 3200 kg load without counterbalance (runaway → cavitation warning), then add the valve and read the stable lowering pressure on the rod-side gauge.'];
    $D[] = ['id' => 'hl-brake-valve', 't' => 'Brake valve in the Studio (counterbalance family)', 'lv' => 'advanced', 'min' => 4,
        'sm' => 'The Studio implementation of load-holding valves — with a-side/b-side spring orientation.',
        'w' => 'The brake valve component models the counterbalance/brake function inside the simulator, including which port the spring side belongs to (a-side vs b-side spring) so the free-flow direction matches your circuit.',
        'h' => 'Free flow through the check in one direction; throttled/pilot-controlled relief in the other. The spring-side choice swaps which cylinder chamber is protected — exactly like choosing the mounting side of the physical valve.',
        's' => 'Set the cracking pressure ~1.3× the expected load pressure; choose the spring side toward the cylinder port that carries the load. Verify in both directions: free lift, controlled lower.',
        'a' => ['Vertical presses and lifts in Studio projects.',
                'Protecting meter-out circuits from pressure intensification spikes.',
                'Teaching: the clearest demonstration of load-induced pressure.'],
        'x' => 'Recreate it: vertical load, brake valve on the rod side, lowering command — log rod pressure vs lowering speed and find the setting where motion just stabilizes.'];
    $D[] = ['id' => 'hl-check-valve', 't' => 'Check valve (non-return)', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'One-way traffic: free flow one way, blocked the other.',
        'w' => 'A spring-loaded poppet or ball opens with a small cracking pressure (0.5–5 bar) in the free direction and seals metal-to-metal in the blocked direction.',
        'h' => 'Flow lifts the poppet against the spring; reverse pressure seats it harder (the sealing is pressure-assisted). Variants: without spring (any mounting orientation), with dashpot (anti-hammer), as cartridge inserts.',
        's' => 'Cracking pressure: low for suction/bypass duty, higher when it must hold against vibration. Δp at rated flow 1–6 bar. Seat leakage essentially zero — the standard choice where a load must not creep.',
        'a' => ['Bypass around flow controls: throttle extend, free retract.',
                'Pump outlet anti-backflow when several pumps share a header.',
                'Holding oil in accumulators, filters and coolers against backflow.'],
        'x' => 'Combine a check valve with a throttle in the Studio and you have built the legendary "flow control with bypass" — then observe free retract vs throttled extend.'];
    $D[] = ['id' => 'hl-pilot-check', 't' => 'Pilot-operated check valve', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Locked until permitted: leak-free load holding with a pilot key.',
        'w' => 'A check valve that can be opened from the OUTSIDE: a pilot piston driven by the opposite line pressure lifts the poppet, releasing otherwise trapped oil.',
        'h' => 'At rest it traps the cylinder leak-free (better than any spool valve). Driving the opposite side pressurizes the pilot port → the pilot piston (area ratio 3–4×) opens the held chamber → the load lowers in a controlled way through the driving valve’s metering.',
        'f' => 'p<sub>pilot</sub> ≥ (p<sub>held</sub> − p<sub>spring</sub>) / pilot-area-ratio',
        's' => 'Single and double versions (double locks BOTH cylinder chambers — standard on outriggers). Ratio 3:1 to 4:1 typical; high held pressures need staged/dampened poppets against shock opening.',
        'a' => ['Aerial platforms and outriggers: absolute no-drift holding.',
                'Presses that must hold tonnage without pump pressure.',
                'Position locks on transport (valve closed = mechanical lock in oil).'],
        'x' => 'Compare drift: hold a load for 30 s on a spool 4/3 (creeps visibly) versus a pilot-operated check (position readout stands still).'];
    $D[] = ['id' => 'hl-shuttle-valve', 't' => 'Shuttle valve (OR function)', 'lv' => 'beginner', 'min' => 3,
        'sm' => 'An OR gate in oil: the higher-pressure input wins the outlet.',
        'w' => 'Two inlets, one outlet. A free ball or spool seals the lower-pressure inlet and connects the higher-pressure one to the outlet — hydraulic OR logic in one fitting.',
        'h' => 'Pressure at inlet 1 shifts the ball against inlet 2’s seat: outlet = inlet 1. When inlet 2 becomes higher, the ball travels back. Response is fast; the idle side is vented through the active side if it leaks to tank.',
        's' => 'Both inlets must be pressure-free when unused, or return-flow paths defined. Small Δp (~1–3 bar) between inputs needed for reliable switching.',
        'a' => ['Control from two stations (local OR remote).',
                'Selecting the higher of two pressures for feedback/gauges.',
                'Emergency take-over: backup pump OR main pump feeds the consumers.'],
        'x' => 'Wire two buttons through a shuttle valve to one pilot: either button strokes the valve — then realize the electrical twin (parallel contacts) on the PLC side.'];
    $D[] = ['id' => 'hl-throttle-valve', 't' => 'Throttle / needle valve', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'A variable orifice: speed control whose price is load dependence.',
        'w' => 'An adjustable restriction (needle in seat, or slotted spool). Flow follows the orifice law — it depends on BOTH opening and pressure drop, which is why plain throttles change speed with load.',
        'h' => 'Reducing the opening raises Δp across the edge; the actuator gets less flow. Heat exacts payment: the pressure drop × flow converts to warmth. Double-acting use needs two throttles or one bypass-equipped unit.',
        'f' => 'Q = α · A(x) · √(2Δp/ρ) — hence: constant speed needs constant Δp',
        's' => 'Fine threads give resolution (turns-from-closed calibration!). Sharp-edged orifices are viscosity-insensitive; long-screen throttles drift with oil temperature.',
        'a' => ['Simple speed setting where load is roughly constant.',
                'Timing elements: charge/discharge delays with volumes.',
                'Snubbing gauge pulses (pressure gauge snubbers).'],
        'x' => 'Throttle a lift at 100/50/20 % screw with heavy and light loads, log the speeds: the spread you measure is precisely why the 2-way PC flow control was invented.'];
    $D[] = ['id' => 'hl-flow-pc', 't' => '2-way pressure-compensated flow control', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'The professional speed control: set flow stays constant whatever the load does.',
        'w' => 'An adjustable orifice IN SERIES with a compensator spool that keeps the Δp across the orifice at a constant 5–10 bar. Constant Δp + constant opening → constant flow, independent of load and supply pressure.',
        'h' => 'The compensator balances orifice inlet vs outlet pressure on its spool faces with a spring (the Δp setpoint). Rising load? Compensator opens. Rising supply pressure? Compensator throttles harder. Excess supply energy is burned at the compensator — or avoided with a bypass/3-way version.',
        's' => 'Flow ranges from 0.05 l/min to hundreds; minimal control Δp ~10 bar. Provide a free-flow check if reverse flow needed. Priority (3-way) versions dump excess flow without heating.',
        'a' => ['Feed drives whose speed must not wobble with cutting force.',
                'Identical speed on parallel machines from one supply.',
                'Winch lowering with constant descent speed.'],
        'x' => 'Swap the plain throttle in your earlier exercise for the PC flow control: rerun both loads — the near-zero spread across loads IS the spec sheet line "load independent".'];
    $D[] = ['id' => 'hl-flow-divider', 't' => 'Flow divider (spool type)', 'lv' => 'advanced', 'min' => 6,
        'sm' => 'One flow in, two equal flows out — synchronized cylinders without electronics.',
        'w' => 'A floating spool with metering notches splits the inlet into two (nearly) equal part flows regardless of branch pressures — or combines them in reverse. In the Studio it now models this faithfully: 50/50 metering including load-independent synchronization.',
        'h' => 'Each part flow crosses a fixed and a variable orifice; the spool shifts so both branches see equal Δp — hence equal flow. If one branch stalls, its pressure rises to the relief (a real spool divider is not a pressure equalizer: stall one side and the other side lifts double!).',
        'f' => 'Q<sub>A</sub> ≈ Q<sub>B</sub> ≈ Q<sub>in</sub>/2 &nbsp;(±2–5 %) &nbsp;|&nbsp; p<sub>stall branch</sub> → 2 × p<sub>working branch</sub> (danger!)',
        's' => 'Division accuracy 2–5 %; better with symmetric design and mid-loads. For long-stroke absolute sync use re-phasing (end-point correction valves) — dividers accumulate error over many strokes.',
        'a' => ['Two lift cylinders on one platform (dock levelers, presses).',
                'Equal speed motors from one supply.',
                'Reverse: combiner keeps returning flows synchronized (Studio models this with a fill-side anti-cavitation ceiling).'],
        'x' => 'Run the shipped synchronization example: loads 160/160, 160/60 and 320/40 kg — both cylinders stay at identical speed (106 mm/s) the whole stroke, exactly like the Festo demonstrator.'];
    $D[] = ['id' => 'hl-accumulator', 't' => 'Bladder accumulator', 'lv' => 'intermediate', 'min' => 6,
        'sm' => 'The hydraulic battery: oil stored against compressed nitrogen.',
        'w' => 'A pressure vessel with a rubber bladder: nitrogen pre-charge p₀ inside, oil outside. Working pressure compresses the gas; the stored volume is available on demand within milliseconds.',
        'h' => 'Below p₀ the bladder seals the oil port (it must NEVER be forced below). Between p₁ (min working) and p₂ (max), the usable volume follows Boyle’s law. Fast discharge is adiabatic, slow charging isothermal — the capacity differs.',
        'f' => 'V<sub>usable</sub> = V₀ · p₀ · (1/p₁ − 1/p₂) &nbsp;(isothermal) &nbsp;|&nbsp; p₀ ≈ 0.6–0.8 · p₁',
        's' => 'Sizes 0.1–50 l, to 330 bar. Pre-charge with NITROGEN ONLY (oxygen explodes with oil mist!). Check p₀ yearly; bladder fails fast if cycled below p₀.',
        'a' => ['Leak compensation: hold clamp pressure with the pump off.',
                'Peak-flow assistance: smaller pump covers short peaks.',
                'Emergency strokes after power failure; pulsation and shock damping.'],
        'x' => 'Charge 160 bar in the Studio, stop the pump, open an isolation to your clamp circuit and read the decay curve — then compare a 0.5 l vs a 2 l unit.'];
    $D[] = ['id' => 'hl-accumulator-safety', 't' => 'Accumulator safety block & charging', 'lv' => 'advanced', 'min' => 5,
        'sm' => 'Isolation, relief and drain: the mandatory hardware around stored energy.',
        'w' => 'DIN/ISO rules require every accumulator to be isolatable, depressurisable to tank, and protected by its own relief valve. The safety block packages all three functions plus the gauge port.',
        'h' => 'An isolation ball valve separates the accumulator from the system; a drain (manual or solenoid) vents the oil side to tank; a relief limits pressure AT the accumulator even if the system relief is set higher or isolated.',
        's' => 'Block relief ≤ accumulator rating. Before ANY work on the circuit: isolate, drain to tank, verify 0 bar at the gauge. Nitrogen pre-charge rigs are the only permitted way to set p₀.',
        'a' => ['Every accumulator installation, without exception.',
                'Automatic dump-on-stop: solenoid drain releases stored energy when the machine powers down.',
                'Test rigs that must prove depressurization before doors unlock.'],
        'x' => 'Add a drain valve to your accumulator circuit, power down "the machine" (stop simulation pump), drain and READ ZERO on the gauge — perform the true LOTO ritual in simulation.'];
    $D[] = ['id' => 'hl-filter-pressure', 't' => 'Pressure-line filter', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'High-pressure fortress: protects valves right after the pump.',
        'w' => 'A filter built for full system pressure, placed between pump and valve group. Its μ-rating and β-ratio decide what cleanliness your proportional/servo valves live in.',
        'h' => 'Flow passes outside-in through the element; a bypass valve opens if the element clogs (no-starvation rule) — unless a no-bypass version protects servo valves absolutely. A clogging indicator (visual/electrical) reports β-limit.',
        's' => 'β<sub>10</sub> = 200 means 99.5 % capture at 10 μm. Size for 1.5–2× pump flow at cold viscosity. Servo valves demand 3–5 μm absolute; gear pumps tolerate 25 μm.',
        'a' => ['Direct protection of proportional/servo valves.',
                'After repairs: flushing/filtering the whole charge to commissioning cleanliness.',
                'Anywhere ONE dirty actuator would poison the whole valve group.'],
        'x' => 'Deliberate design review: in your Studio circuit, mark which filter protects what, and read up on ISO 4406 classes — then justify a β10 vs β25 choice for a proportional axis.'];
    $D[] = ['id' => 'hl-filter-return', 't' => 'Return-line filter & suction strainer', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'The two quiet janitors: return filtration for all flow, strainers for pump life.',
        'w' => 'The return filter sees 100 % of circulating oil at low pressure — the standard plant-wide cleanup point. The suction strainer is a coarse screen (100–150 μm) protecting only the pump, NOT the system.',
        'h' => 'Return oil flows through the element to a clean tank; bypass at ~1.5–3 bar prevents back-pressure. Suction strainers sit below oil level; Δp limits are tight (≤ 0.05 bar at cold start) or the pump cavitates.',
        's' => 'Return filters: β10–25 with electrical clog indicator as standard. Strainers are NOT a substitute for filtration — they only stop rocks. Never starve the suction side with a fine filter.',
        'a' => ['Standard: one return filter at tank-entry of every power pack.',
                'Offline (kidney) loops: continuous polishing independent of duty cycle.',
                'Suction strainer + generous suction line = the anti-cavitation pair.'],
        'x' => 'Puzzle: your plan has only a suction-side fine filter. Find the two failure modes it creates (cavitation AND no protection downstream) and relocate filtration to the return line.'];
    $D[] = ['id' => 'hl-cooler', 't' => 'Oil cooler (air-blast & plate)', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Every throttle watt leaves as heat — the cooler exports it.',
        'w' => 'Air-blast units (fan over finned block) go into return or bypass lines; water-oil plate coolers squeeze heat into cooling water. Both extend oil and seal life — temperature is the oil’s aging clock.',
        'h' => 'Sizing starts from the heat balance: P<sub>loss</sub> ≈ 20–30 % of installed power in typical machines (100 % in relief dwell!). The cooler must dissipate that at the allowed oil temperature (≤ 60 °C shop standard) at the worst ambient.',
        'f' => 'P<sub>cool</sub> ≥ P<sub>loss</sub> − P<sub>tank radiation</sub> &nbsp;|&nbsp; rule: tank gives ~0.5–1 kW per 100 l',
        's' => 'Mount with a bypass check (cold-start protection) and after filtering. Fan noise scales with blade size at equal duty — two smaller fans are quieter.',
        'a' => ['Presses in dwell, power units in warm halls, mobile machines (standard).',
                'Return-line cooling as retro-fit: lowest-pressure, simplest loop.',
                'Off-line filter/cooler loops combine both jobs with a small dedicated pump.'],
        'x' => 'Force a relief-dwell cycle in the Studio and watch oil temperature climb; add the cooler component and read the stabilized temperature — the energy audit made visible.'];
    $D[] = ['id' => 'hl-heater', 't' => 'Tank heater & cold-start strategy', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'Cold oil cavitates and sticks: gentle pre-heating protects the pump and valves.',
        'w' => 'A screw-in electric element (or plate heat exchanger) that brings the tank to minimum start viscosity. It must stay submerged, and its surface loading must stay low to avoid cracking the oil.',
        'h' => 'Below ~10–15 °C, VG 46 oil thickens so much that suction Δp and valve response suffer — cavitation follows. The heater thermostat (typ. set 20–30 °C) pre-warms; a thermostat interlock can block the main motor until the tank is ready.',
        's' => 'Surface load ≤ 1–2 W/cm² (oil scorching starts local coking at hot spots). Use with level protection — a dry element burns out in minutes and contaminates the tank.',
        'a' => ['Outdoor units, cold halls, Monday-morning startups.',
                'Viscosity-critical servo systems that must be repeatable from minute one.',
                'Circulating via the filter loop for even warming.'],
        'x' => 'Set the Studio oil start temperature low, start the pump and watch the warm-up metrics; add the heater and interlock — repeat with instant readiness.'];
    $D[] = ['id' => 'hl-hose', 't' => 'Hydraulic hose assemblies', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'Flexible and replaceable — but only as strong as its routing rules.',
        'w' => 'Multi-layer: inner tube, 1–6 wire reinforcements (braid/spiral), cover. Rated by bore (DN), working pressure with ≥4:1 burst safety, and impulse endurance.',
        'h' => 'Under pressure the hose shortens up to 4 % and stiffens — routing must allow movement without twisting (torsion destroys wire layers fastest). Minimum bend radius and straight exits after fittings are non-negotiable.',
        's' => 'Choose by pressure (with peaks!), fluid compatibility, temperature and bend radius. Never combine bending with torsion in the same hose; protect against abrasion with sleeves/spacing; date-code and replace by age.',
        'a' => ['Any moving joint: cylinder to hard-line, door/pivot crossings.',
                'Vibration decoupling from power pack lines.',
                'Service-friendly replacement where tubes can’t reach.'],
        'x' => 'Trace a moving cylinder in one of your circuits: sketch where the flexing plane lies and which fittings need elbows — the layline-as-sightline rule decides it.'];
    $D[] = ['id' => 'hl-pipe', 't' => 'Rigid tube & pipe lines', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'Seamless precision tube, bent once — the cheap, clean default for fixed runs.',
        'w' => 'Cold-drawn seamless steel (or stainless) tube to DIN 2391/EN 10305, connected by cutting rings, flares or welds. Cheaper than hose, zero aging, no diffusion — the reference for stationary machines.',
        'h' => 'Bend radii ≥ 3× OD, clamp spacing by diameter (L = √(d) rules), and stress-free alignment prevent fatigue cracks. Galvanic isolation in clamps avoids corrosion points.',
        's' => 'Wall thickness from Barlow formula with fatigue factor; target velocities per line class (suction 0.5–1.5, pressure 3–6 m/s). Deburr and FLUSH all cut tube — assembly swarf kills valves downstream.',
        'a' => ['Power-unit to valve-manifold mains.',
                'Long gallery runs with welded flange blocks.',
                'Test-stand plumbing heat-cycled daily (no aging).'],
        'x' => 'Use the Studio pipe sizing report for your main legs: set DN per velocity classes, then hand-check one line with the Barlow formula for peace of mind.'];
    $D[] = ['id' => 'hl-quick-coupling', 't' => 'Quick couplings & test points', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'M16 test couplings: the 10-second pressure window into a live machine.',
        'w' => 'Quick-connect pairs (poppet or flat-face) and the tiny M16×2 test points with captive check. Flat-face versions minimize spill and air inclusion — the professional default.',
        'h' => 'Test points seal by an internal valve opened only by the mating test hose: connect, read, disconnect — no oil loss, no shutdown. Quick couplings for attachments lock by sleeve; rated for full system pressure.',
        's' => 'Flat-face for frequent cycles & cleanrooms; poppet for budget. Test points at every diagnostic location: pump, relief, valve P/A/B, cylinder ports.',
        'a' => ['Commissioning + periodic health logging (pressure/flow over time).',
                'Tool changes on press brakes and attachments.',
                'Temporary gauge hookup during troubleshooting (the Studio gauges mirror exactly this habit).'],
        'x' => 'Place test points in your Studio circuit like a commissioning plan, then use live gauges as their virtual counterparts when hunting an artificial fault (e.g., closed throttle).'];
    $D[] = ['id' => 'hl-manifold', 't' => 'Manifold blocks & cartridge (HIC) design', 'lv' => 'advanced', 'min' => 5,
        'sm' => 'Drilled blocks replace pipes: compact valve stations with gallery channels.',
        'w' => 'An aluminum/steel block with ISO 4401 surfaces on the faces and drilled galleries inside. Cartridge (logic) elements push the concept further: big flows inside the block, pilot valves on top.',
        'h' => 'Galleries connect P, T, A, B between stations; sandwich valves stack between DCV and block. Intersecting drillings are closed by tapered plugs. Rule: generous galleries (low Δp!), no crossing collisions, test points planned, expansion plugs allowed.',
        's' => 'Check Δp < 5–10 % at design flow through each gallery. Cartridge logic elements handle 1000+ l/min — way beyond any spool valve, with poppet tightness.',
        'a' => ['Machine-integrated valve stations with minimal leak points.',
                'Presses/injection machines: logic-cartridge manifolds for huge flows.',
                'Retrofit expansions via sandwich plates without new piping.'],
        'x' => 'Simulate the cartridge/HIC boundary concept in the Studio: group logic cartridges as a manifold; then read the ISO habit — enclosure dash-dot frame around grouped elements.'];
    $D[] = ['id' => 'hl-cartridge-22', 't' => 'Cartridge 2/2 solenoid valve', 'lv' => 'advanced', 'min' => 4,
        'sm' => 'Screw-in seat valve: electrically switched, zero-leakage isolation in manifolds.',
        'w' => 'A cartridge pushed into a manifold cavity: coil ON/OFF strokes a poppet. Normally closed forms act like safety gates inside blocks — with seat tightness where spools would leak.',
        'h' => 'The coil pulls an armature; the poppet lifts against spring and pressure. Damped two-stage versions avoid water hammer at large flows. The Studio’s cartridgeSolenoidValve22 with its energized property models exactly this actuation.',
        's' => 'Voltage 24 V DC standard; duty 100 %; manual override pin for service. Watch coil current → PLC output capacity (0.5–2 A).',
        'a' => ['Load-sensing unload, safety dump, isolation in HIC blocks.',
                'Electrohydraulic two-hand/PLC examples: the crisp ON/OFF muscle.',
                'Sequence steps where zero-leak holding matters.'],
        'x' => 'Drive a cartridge valve from a PLC rung (targetControl + energized): open at clamp pressure, hold with pump unpressurized — then verify the load does not creep (seat tightness).'];
    $D[] = ['id' => 'hl-gauge', 't' => 'Bourdon-tube pressure gauge', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'The mechanic’s window: coiled tube, pointer — and correct scale choice.',
        'w' => 'A flat C-tube straightens under pressure, moving a pointer over the dial. Glycerine filling damps vibration and pulsation — unfilled gauges rattle themselves into early death.',
        'h' => 'Choose full scale so working pressure sits at ~75 %. Reading = relative (bar gauge). With gauge isolators (6-port selector), one gauge serves many points without continuous exposure.',
        's' => 'Classes 1.0–2.5 % FS. Protect from pulses with snubber or isolator. A dead-needle gauge on a hammering relief circuit is a diagnostic signal in itself.',
        'a' => ['Every power unit outlet and actuator port group.',
                'Accumulated test points with selector isolator.',
                'The first instrument in EVERY troubleshooting drill (measure before you wrench).'],
        'x' => 'Instrument your Studio circuit: gauges at pump, valve P, cylinder A and B — then read your own machine during a full cycle like a commissioning report.'];
    $D[] = ['id' => 'hl-pressure-switch-h', 't' => 'Hydroelectric pressure switch', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'Pressure becomes a contact: the B1 of every electrohydraulic ladder.',
        'w' => 'A piston/diaphragm element that trips a microswitch at an adjustable threshold — with adjustable hysteresis on quality units. It turns "clamp pressure reached" into a PLC input.',
        'h' => 'Pressure strokes the sensing element against a spring; the trip point = spring preload. Reset at a lower value (the dead band) — in the Studio it now models proper Schmitt behavior (pickup at setting, dropout at ~95 %).',
        's' => 'Ranges 5–400 bar; repeatability ~1 %; hysteresis adjustable 3–10 %. Mount where the pressure proves the function (at the clamp port, not the pump!).',
        'a' => ['Clamp confirmation before a work stroke starts.',
                'Accumulator charge control (start/stop the pump at p_min/p_max).',
                'Overload alarms and safe-state switching.'],
        'x' => 'Wire PS1 → PLC: "extend only when PS1 proves clamp". Delete the rung afterward and watch the sequence honestly stop — control chains made transparent.'];
    $D[] = ['id' => 'hl-temperature-h', 't' => 'Temperature switch & oil condition guard', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'The oil’s guardian: alarm at 60, shutdown at 70 — before seals cook.',
        'w' => 'A bimetal or PT100-based switch in the tank with fixed/adjustable thresholds. Above 80 °C, oil oxidation rate doubles per 8–10 K and seals age in dog years — hence the strict guard rails.',
        'h' => 'Contact changes state at the setpoint (with a small built-in hysteresis). In the Studio it switches on the simulated oil temperature (metrics) with a −2 °C drop-side — exactly the field device behavior.',
        's' => 'Typical setpoints: warning 60 °C, cooler start 45–50 °C, shutdown 70–80 °C. Combine with level switch so a low tank cannot fake-cool system damage.',
        'a' => ['Cooler fan interlock: run only when needed.',
                'Alarm chains in unattended power units.',
                'Energy audits: logs of duty vs temperature curves.'],
        'x' => 'Let a relief dwell run hot in the Studio, read the temperature switch as it trips and use it in a PLC rung to start the cooler — full thermal management loop.'];
    $D[] = ['id' => 'hl-flow-meter', 't' => 'Flow meters (turbine/gear/oval)', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'The truth about delivery: pump wear and leakage visible in l/min.',
        'w' => 'Rotation-based meters — turbine for low-viscosity steady flow, positive displacement (gear/oval wheel) for oil. They turn "feels slow" into a measured number.',
        'h' => 'The rotor speed is proportional to flow; displacement meters count actual volumes (best accuracy for oil, tolerate the DP they need). Portable test meters link two points with pressure gauges: pump health under load in minutes.',
        's' => 'Accuracy 0.5–2 %; pressure drop 0.5–3 bar at rating. Always compare readings at same temperature — viscosity shifts turbine response.',
        'a' => ['Pump acceptance test: delivery vs relief pressure curve.',
                'Efficiency proof after repair (did we restore flow?).',
                'Permanent monitoring on critical axes.'],
        'x' => 'Virtual commissioning: in the Studio, raise pump internal leakage artificially (worn pump parameter) and re-run the acceptance check — the drop is exactly the field symptom.'];
    $D[] = ['id' => 'hl-electric-drive', 't' => 'Drive motor & pump coupling', 'lv' => 'beginner', 'min' => 4,
        'sm' => '1450 rpm into torque: bellhousing, flexible coupling, alignment discipline.',
        'w' => 'Standard IEC motors (4-pole ≈ 1450 rpm at 50 Hz) drive the pump through a bellhousing and an elastic jaw coupling. The assembly is rigid, quiet and self-aligning within limits.',
        'h' => 'The coupling tolerates small misalignments and damps torsional shocks (relief cracking is a torsional event!). Motor sizing: shaft power ≈ p·Q/(600·η) with service factor 1.1–1.25.',
        's' => 'Never oversize blindly: oversized motors run inefficiently far below rated load. Check rotation direction at first start (dry reverse running scars gear pumps for life).',
        'a' => ['Every stationary power pack.',
                'Two-pump shared-motor consortia (piggy-back).',
                'Silent packs with sub-frame + dampers for labs.'],
        'x' => 'Calculate the 20 l/min @ 160 bar drive of your project machine: P ≈ 5.9 kW before efficiency — pick the next motor and justify it like a real RFQ answer.'];
    $D[] = ['id' => 'hl-electro-interface', 't' => 'The electrohydraulic interface: coils, relays, PLC', 'lv' => 'intermediate', 'min' => 6,
        'sm' => 'Where oil meets logic: 24 V DC solenoids and how the Studio simulates real control.',
        'w' => 'Every solenoid valve is a border between power and signal. In the Studio the border is real: PLC rungs, relay contacts, timers and sensor inputs shift the valves — delete PLC1 and the machine honestly stops.',
        'h' => 'A PLC scan evaluates rungs (conditions) and writes outputs (solenoids via their target valve). Latched rules "COND -> V1 right" hold actions; combinatorial "Q1 = COND" recompute every scan. Timers add dwell, sensors (pressure, reed) close the loop.',
        's' => 'One coil per direction command, one relay/memory per state. Solenoid default de-energized = safe start. Check coil current vs PLC output rating.',
        'a' => ['All electrohydraulic examples (auto-return, two-hand, press cycle).',
                'Mixed systems: pure-pneumatic sensors + PLC sequences.',
                'Education: ladder thinking without touching a real bus.'],
        'x' => 'Program "B1 AND B2 -> V1 right; NOT(B1 AND B2) -> V1 left" on a two-cylinder jig, then prove the delete-PLC1 litmus yourself.'];
    $D[] = ['id' => 'hl-junction', 't' => 'Junction / T-piece & the blind plug', 'lv' => 'beginner', 'min' => 3,
        'sm' => 'Plumbing grammar: branch lines properly — and seal spare ports with blind plugs.',
        'w' => 'Junctions split or merge lines; the blind plug seals an unused port pressure-tight. In the Studio an unplugged valve port otherwise "vents to tank" invisibly — the plug makes sealing a deliberate design act.',
        'h' => 'T-pieces feed multiple consumers from one supply; sharp Ts add measurable Δp. The blind plug completes the symbol honesty: what you cap is what the simulation treats as closed.',
        's' => 'Seal every unused P/A/B port with rated plugs, never tape. In manifolds, expansion plugs close future stations — same principle, bigger scale.',
        'a' => ['Distributing one supply to two actuators.',
                'Sealing the spare work port of a 5-port valve converted to 4/3 duty.',
                'Service: capping lines opened for repair (cleanliness!).'],
        'x' => 'Take a 5-port valve in the Studio, plug the unused R/S port with the blind plug and verify the vent warning disappears — sealing as design, not luck.'];
    $D[] = ['id' => 'hl-tank', 't' => 'Reservoir design: the tank that works for a living', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Storage, cooling, de-aeration, settling: the quiet multitasker under the pump.',
        'w' => 'More than a bucket: sized volume, suction/return zones separated by a baffle, breather, level gauge, cleanout covers and drain. Good tanks make oil last; bad tanks churn bubbles and dirt.',
        'h' => 'Volume ≈ 2–4× pump flow/min gives residence time for air release and settling. Return oil enters submerged below surface (no foam!); suction draws from the quiet zone; the breather filters incoming air as level cycles.',
        's' => 'Fill level above suction strainer at all attitudes. Breather rating ≥ pump flow in air equivalent. Slope the bottom to the drain; paint-free interior (phosphate coating).',
        'a' => ['All stationary power packs.',
                'Mobile: smaller (1× flow/min) — cooling shifted to fan coolers.',
                'Suppressing foam: baffle + submerged returns solves chronic aeration.'],
        'x' => 'Review your Studio metrics: temperature stabilizes easier with bigger tanks in real life — justify the tank volume for your 160 bar / 20 l/min project from residence time.'];
    $D[] = ['id' => 'hl-iso-frame', 't' => 'Assembly frames & dash-dot enclosures (ISO 1219)', 'lv' => 'beginner', 'min' => 3,
        'sm' => 'The dash-dot line that says "these parts are bolted together".',
        'w' => 'ISO 1219 marks physically grouped components (power pack contents, manifold contents, FRL stages) with a dash-dot enclosure. It is a drawing convention that carries real assembly information.',
        'h' => 'Inside the frame: shared hardware, one article number. In the Studio the manifold/HIC boundary lets you group cartridges the same way — your schematic then matches the real manifold on the bench.',
        's' => 'Use enclosures generously: any purchased unit with one part number deserves one. Label the frame with the unit tag (B10, A2…).',
        'a' => ['Power pack internals drawn as one unit.',
                'Cartridge valve stations on a single manifold.',
                'Service units (FRL) shown as one assembly.'],
        'x' => 'Redraw one of your circuits with proper dash-dot enclosures around the power pack and valve manifold — documentation quality jumps immediately.'];
    $D[] = ['id' => 'hl-internal-gear', 't' => 'Internal gear & gerotor pumps', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'The quiet cousins: crescent-sealed tooth sets for low-noise duty.',
        'w' => 'An inner ring gear drives an outer ring with one more tooth, separated by a crescent. The design runs notably quieter and with less pulsation than external gears.',
        'h' => 'Teeth unmesh and mesh against the crescent seal: suction and pressure zones grow and shrink smoothly, so flow ripple is small. Tight internal clearances demand cleaner oil than external gears.',
        's' => 'Pressures to 300+ bar in premium lines; prized for servo-adjacent duty and low-noise halls. Sensitive to cavitation — watch suction conditions.',
        'a' => ['Low-noise power packs (laboratories, foundries with limits).',
                'Automatic transmissions (gerotor oil pumps).',
                'Compact in-tank pumps submerged in oil.'],
        'x' => 'Compare pump families in a spec exercise: same 20 l/min @ 160 bar as gear, internal gear, vane, piston — rank noise, price, dirt tolerance.'];
    $D[] = ['id' => 'hl-vane-pump', 't' => 'Vane pump (fixed & variable)', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'Sliding vanes in an eccentric ring: smooth, quiet, often adjustable.',
        'w' => 'A slotted rotor carries vanes that slide against a cam ring. Offset rotor-to-ring distance sets displacement — shifting the ring (variable type) changes volume per revolution.',
        'h' => 'Chambers between vanes grow at suction and shrink at pressure. A pressure-compensated variable vane pump destrokes at its setpoint: constant pressure, flow on demand — a budget alternative to piston compensators.',
        's' => 'To 160–210 bar; quiet; medium dirt tolerance. Variable versions to ~160 bar with compensator kits.',
        'a' => ['Machine tools (the classic quiet constant-pressure supply).',
                'Power steering pumps (the automotive niche).',
                'Plastics auxiliaries and clamping circuits.'],
        'x' => 'Design decision: pick variable vane vs fixed gear + relief for a machine with 60 % dwell — the energy math decides, do it on paper.'];
    $D[] = ['id' => 'hl-screw-pump', 't' => 'Screw pump', 'lv' => 'advanced', 'min' => 4,
        'sm' => 'Silent continuous transport: spindles rolling oil without pulsation.',
        'w' => 'Two or three meshing screw spindles form sealed axial chambers that travel steadily from suction to pressure — no pulsation, near silent, outstanding for lubrication circuits.',
        'h' => 'Axial piston forces are balanced; delivery is perfectly smooth. Tolerates moderate viscosity range; absolutely intolerant of dry running.',
        's' => 'To 250 bar (3-screw), best ≤ 40 bar for lube duty; quietest pump family; fixed only.',
        'a' => ['Lubrication and sealing-oil systems for turbines/compressors.',
                'Burner fuel-oil feed.',
                'Coolant/flushing pumps for tools.'],
        'x' => 'Where in a big power pack would an auxiliary screw pump earn its keep? (Off-line filtration/cooling loops — size one in principle.)'];
    $D[] = ['id' => 'hl-cyl-cushion', 't' => 'Cylinder end cushioning', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'The last 20 mm matter: braking the piston inside the cylinder.',
        'w' => 'A cushioning spear closes the main outlet near stroke end, forcing oil through an adjustable throttle — the piston decelerates on an oil brake instead of slamming the cap.',
        'h' => 'The spear enters the port, outflow crosses the cushion screw → pressure rises in the trapped volume → smooth deceleration. Set the screw so the rod arrives with ~0 speed without bouncing.',
        'f' => 'E<sub>kin</sub> = ½ · m<sub>moving</sub> · v² — the cushion must absorb most of it',
        's' => 'Use when m·v is meaningful (fast or heavy axes). Check max cushion pressure against port ratings; adjustable vs fixed cushions.',
        'a' => ['Fast clamp/press approaches (protect tooling and caps).',
                'Long-stroke cylinders cycled hourly.',
                'Where external stops are impractical.'],
        'x' => 'In the Studio, compare impact: run a heavy load at speed capped vs cushioned and note the end-pressure spike difference.'];
    $D[] = ['id' => 'hl-stop-tube', 't' => 'Stop tubes & side-load discipline', 'lv' => 'advanced', 'min' => 4,
        'sm' => 'A spacer inside the cylinder that saves rods and bearings on long strokes.',
        'w' => 'A stop tube lengthens the effective piston-to-bushing distance, reducing bushing loads from moments and side forces. Cheap insurance for long-stroke, high-moment installations.',
        'h' => 'Side load F·e concentrates where piston and bushing act as lever-points; the stop tube moves the piston farther from the bushing at full extension → lower bearing pressure.',
        's' => 'Rule of thumb: 25 mm stop tube per 250 mm stroke beyond ~600 mm. Better: eliminate side load with self-aligning couplings and proper mounts.',
        'a' => ['Long-stroke pushers with imperfect alignment.',
                'Horizontal cylinders guiding heavy fixtures.',
                'Retrofit when a machine eats rod seals.'],
        'x' => 'Failure review: a press eats one rod seal per month. List the three alignment checks and where a stop tube changes the load picture.'];
    $D[] = ['id' => 'hl-pos-cylinder', 't' => 'Position-measuring cylinders (magnetostrictive)', 'lv' => 'advanced', 'min' => 4,
        'sm' => 'The rod reports where it is: integrated stroke transducers for closed loops.',
        'w' => 'A magnetostrictive wire in a pressure-proof rod bore reads a ring-magnet attached to the piston: absolute position, 1–5 μm class resolution, no contact.',
        'h' => 'A current pulse travels the wire; the magnet’s field twists the return — the time-of-flight = position. Output analog 4–20 mA/0–10 V or bus (SSI, IO-Link).',
        's' => 'Strokes to 2+ m, pressure rating of the cylinder unchanged. The sensor port needs a clean connector; protect the pigtail.',
        'a' => ['Closed-loop positioning axes (press brakes, gap control).',
                'Feedback where external encoders get dirty or bent.',
                'Synchronized multi-axis press frames.'],
        'x' => 'Sketch the signal chain for a closed-loop press: transducer → controller → proportional valve — and mark where the Studio models the loop.'];
    $D[] = ['id' => 'hl-servo-valve', 't' => 'Servo valves & jet-pipe stages', 'lv' => 'advanced', 'min' => 5,
        'sm' => 'Micron-class metering for the fastest axes — and the cleanest oil requirement.',
        'w' => 'A torque-motor-driven pilot (flapper-nozzle or jet pipe) positions a lapped spool with micron precision. Step responses in the low milliseconds, hysteresis < 0.5 % — expensive, precise, fragile.',
        'h' => 'The pilot stage meters a tiny control flow that strokes the main spool proportionally to current — with mechanical or electrical feedback closing the position loop inside the valve itself.',
        's' => 'Absolute filtration 3–5 μm (β≥200). Rated flow at Δp = 70 bar over the metering edges (datasheet convention!). Null drift tracked with hours/temperature.',
        'a' => ['Fatigue test stands and vibration rigs.',
                'Position/force control where a proportional valve is too slow.',
                'Aerospace practice controls.'],
        'x' => 'Spec comparison: cylinder natural frequency vs valve response — compute the 4× rule for a Ø 63 axis and select prop vs servo accordingly.'];
    $D[] = ['id' => 'hl-amplifier', 't' => 'Proportional amplifier card', 'lv' => 'advanced', 'min' => 5,
        'sm' => 'Gain, ramps, deadband, dither: the four knobs that shape every proportional motion.',
        'w' => 'The amplifier converts a command voltage into a controlled coil current — with the parameters that make or break motion quality: gain (scaling), ramp up/down (slewing), deadband compensation, dither.',
        'h' => 'Command → reference (with ramps) → error amp → PWM current driver. Current control makes coil force independent of coil heating; dither (100–200 Hz ripple) keeps the spool micro-sliding to avoid stiction.',
        's' => 'Set ramps to kill pressure shocks first; then gain; THEN deadband. Dither amplitude highest value with no visible actuator tremble.',
        'a' => ['Every proportional axis — the Studio amplifier component exposes exactly these parameters.',
                'Two-slope profiles via called parameter sets (fast in, slow out).',
                'Machine modes: setup (small gain) vs production.'],
        'x' => 'Build the ramp-generator + amplifier + prop valve chain in the Studio: ramp 0 vs 500 ms on a heavy cylinder and WATCH the pressure spike difference at reversal.'];
    $D[] = ['id' => 'hl-unloading-valve', 't' => 'Unloading valve', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'Piloted from the accumulator: dump the pump when the store is full.',
        'w' => 'Externally piloted relief-family valve: pilot pressure from the accumulator (or another line) switches it open → pump unloads to tank at near zero pressure; a check isolates the charged consumer.',
        'h' => 'Below the setting the pump charges the accumulator through the check valve; at setting, pilot pressure trips the unload spool → pump idles while the accumulator feeds the circuit. Hysteresis band prevents chattering.',
        'f' => 'charge band ≈ 10–20 % between unload and reset',
        's' => 'Set unload ~10–15 bar above max consumer pressure; pair with safety block relief. The energy-efficient classic for intermittent demand.',
        'a' => ['Accumulator circuits with intermittent demand (presses, clamps).',
                'Hi-Lo pump systems: unload the big pump at pressure.',
                'Any duty where idling at full relief would cook the oil.'],
        'x' => 'Simulate charge→unload cycles in the Studio and read the relief-flow metric: unloading turns continuous heat into occasional bursts.'];
    $D[] = ['id' => 'hl-prefill-valve', 't' => 'Pre-fill valve (suction check for big rams)', 'lv' => 'advanced', 'min' => 4,
        'sm' => 'Gravity feeds the giant: filling press cylinders from an elevated tank.',
        'w' => 'A large check valve between an overhead tank and the press ram: during fast approach the ram draws oil directly by gravity; during pressing it closes; during return, pilot pressure opens it for decompression and refill return.',
        'h' => 'Approach: cylinder volume grows faster than the pump can feed → prefill opens, oil floods in. Press: pump pressure closes it, full tonnage builds. Return: the pilot opens it so the huge volume escapes to the tank.',
        's' => 'Sized by approach speed × area (hundreds of l/min). Must open softly (anti-cavitation/decompression staging) — slam causes audible bangs and line damage.',
        'a' => ['Large forging/forming presses with fast approach.',
                'Big ram return where pump flow would be absurd.',
                'Gravity-circuits in general (energy-free approach).'],
        'x' => 'Reason it through: why does a prefill press barely load its pump in approach? (a) paved by gravity flow — sketch the tank-line-up schematic.'];
    $D[] = ['id' => 'hl-crossrelief', 't' => 'Cross-line relief (motor braking) block', 'lv' => 'advanced', 'min' => 4,
        'sm' => 'Anti-shock pair across a motor: no pressure spike survives a reversal.',
        'w' => 'Two reliefs + two checks in antiparallel across a hydraulic motor: each direction has its own relief path and makeup feed. The standard protection for rotating inertia.',
        'h' => 'Closing the DCV with a spinning motor turns the motor into a pump: the starved side sucks through the check, the pressurized side relieves through its valve — deceleration without cavitation or spikes.',
        's' => 'Relief setting ~10–20 % above working pressure; makeup from tank via checks (never block anti-cavitation paths!).',
        'a' => ['Winches and slew drives (any inertial rotary axis).',
                'Fan drives stopping slowly after DCV closes.',
                'Same trick across cylinders for impact loads (cylinder cushion relief).'],
        'x' => 'Simulate reversing a loaded motor in the Studio without protection (watch the spike warnings), then place the braking concept and compare gauges.'];
    $D[] = ['id' => 'hl-hoseburst', 't' => 'Hose-burst safety valve', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'The parachute: locks the load if a line ruptures.',
        'w' => 'A small cartridge in the cylinder port that stays open in normal flow and slams shut when return flow exceeds a trigger rate — fusing the circuit mechanically at a burst.',
        'h' => 'Normal lowering flow passes; a burst accelerates flow → Δp on the sensing edge rises → the valve element seats → the load stops trapped at the cylinder port. Reset by lifting pressure.',
        's' => 'Trigger ~1.5× max professional lowering flow. Must sit directly ON the cylinder (internal leakage = slow descent, not drop). Test by procedure, not by rupture hope.',
        'a' => ['Man lifts and platforms (mandatory by regulation).',
                'Lift tables and dock equipment.',
                'Paralleling counterbalance: cheap burst-only safety.'],
        'x' => 'Trace the safety chain: hose burst valve + counterbalance — which protects against which failure? Map both on your vertical-axis project.'];
    $D[] = ['id' => 'hl-gauge-isolator', 't' => 'Gauge isolator & multi-point reading', 'lv' => 'intermediate', 'min' => 3,
        'sm' => 'One gauge, six truths: selector isolators for commissioning panels.',
        'w' => 'A rotary selector valve connecting one gauge to 2–6 measurement points — the gauge lives protected and offline until a measurement is dialed in.',
        'h' => 'Rotate to a point: the isolator admits that line to the gauge, venting the previous. Between readings the gauge stands at atmosphere: no pulsation fatigue, no stolen volume.',
        's' => 'Never leave it on a hammering point unattended. Mark points on the panel map (A1 = pump, A2 = clamp…).',
        'a' => ['Commissioning panels on power packs.',
                'Service gauges on infrequent points.',
                'Training benches (as in the Studio’s gauge habits).'],
        'x' => 'Plan six test points for your project circuit and assign the isolator map — then read all six in the Studio gauges through one cycle.'];
    $D[] = ['id' => 'hl-level-switch', 't' => 'Level & temperature combo switches', 'lv' => 'intermediate', 'min' => 3,
        'sm' => 'Low oil lies: float guards stop the pump before the pump stops itself.',
        'w' => 'Float switches at min. level plus bimetal temperature contacts — the standard tank interlocks. Low level means vortex air into the suction; high temperature cooks seals.',
        'h' => 'Magnets in the float trip reed contacts at thresholds; wired as NC chains so a broken wire reports safe. Temperature contacts warn (60 °C) and interlock (70–80 °C).',
        's' => 'Also size the visual level/temperature gauge — the redundant eye always wins. Mount accessible for cleaning (sludge kills floats).',
        'a' => ['Unattended power units (auto-shutdown chains).',
                'Cold-storage machines with big level swings.',
                'Commissioning checklists (prove every interlock).'],
        'x' => 'Add an oil-start-temperature interlock to your PLC logic in the Studio: no start below threshold, cooler on above — wires of a real guard chain.'];
    $D[] = ['id' => 'hl-breather', 't' => 'Breather filters & desiccant breathers', 'lv' => 'beginner', 'min' => 3,
        'sm' => 'The tank inhales too: filter what enters, or invite dust storms inside.',
        'w' => 'Every pump stroke cycles the level and breathes air through the cap. The breather element (3–10 μm) or desiccant cartridge (silica gel + filter) protects oil from dust and humidity.',
        'h' => 'Desiccant beads change color as they saturate with moisture; pleated elements capture particles. Undersize the breather and the tank puffs oil mist around the cap.',
        's' => 'Air rating ≥ 1.5× pump flow. Replace on schedule or color; in humid/coastal sites desiccant is mandatory.',
        'a' => ['Every reservoir, everywhere.',
                'Humid climates & washdown halls (desiccant).',
                'Mobile machines in dust clouds (spin-on fine versions).'],
        'x' => 'Failure story: a quarry machine eats pumps despite return filtration. Where did the dirt enter? (Answer: unprotected breather. Fix it in your checklist.)'];
    $D[] = ['id' => 'hl-ball-shutoff', 't' => 'Ball-type shutoff valves', 'lv' => 'beginner', 'min' => 3,
        'sm' => 'The honest isolator: full bore, quarter turn, visible ON/OFF by handle.',
        'w' => 'A drilled ball rotated by the handle: open = full bore (negligible Δp), closed = bubble-tight with seats. Two-way and three-way (selector/L or T port) versions for gauges and service.',
        'h' => 'Soft or metal seats seal; the handle ends in the flow direction indicator. Not for throttling — seats erode in a crack position.',
        's' => 'Rated by pressure class (PN 350/500 in hydraulics). Lockable dies exist for lockout-tagout discipline.',
        'a' => ['Isolating pumps/accumulators/branches for service.',
                'Gauge protection where no isolator exists.',
                'Drain and bypass lines.'],
        'x' => 'Audit your circuit: draw every ball valve a real technician would need to service the unit without draining the tank.'];
    $D[] = ['id' => 'hl-intensifier', 't' => 'Pressure intensifiers', 'lv' => 'advanced', 'min' => 4,
        'sm' => 'High pressure from low: the area-ratio transformer in oil.',
        'w' => 'Two linked pistons: low pressure drives a big piston, the small one delivers pressure × (A<sub>big</sub>/A<sub>small</sub>). Oscillating versions pump continuously; single-stroke for clamps.',
        'h' => 'Force balance: p<sub>out</sub> = p<sub>in</sub> × ratio. The trade is volume: out flow = in flow / ratio (power conserved minus losses). No relief needed on the HP side when correctly sized.',
        'f' => 'p<sub>out</sub> = p<sub>in</sub> · (A<sub>big</sub>/A<sub>small</sub>)  &nbsp;|&nbsp; Q<sub>out</sub> = Q<sub>in</sub> / ratio',
        's' => 'Ratios 1.5–20. HP side needs HP-rated fittings & hoses. Combine with accumulator for sustained HP flow.',
        'a' => ['700 bar tools (tensioners, crimpers) fed by shop 160 bar.',
                'Test-bench proof-pressure ramps.',
                'Clamping heads needing small HP volume per cycle.'],
        'x' => 'Size one: from 160 bar supply to 480 bar clamp. Which ratio, and how much oil reaches the clamp per liter in?'];
    $D[] = ['id' => 'hl-anti-cavitation', 't' => 'Anti-cavitation (makeup) valves', 'lv' => 'advanced', 'min' => 4,
        'sm' => 'Let the cylinder suck: feeding the starved chamber during overruns.',
        'w' => 'Check valves from tank/return into working lines, opening whenever local pressure collapses. They close the "pumping void" that inertial loads create — the partner piece to cross-line reliefs.',
        'h' => 'Overrunning load: driven side may cavitate as the actuator outruns the supply. Makeup checks admit return-side/tank oil into the starving chamber → no vapor bubbles, no diesel knock.',
        's' => 'Cracking as low as possible (0.2–0.5 bar). Size for the full chase flow, not the nominal bleed.',
        'a' => ['Hydraulic motors behind closed centers (with cross reliefs).',
                'Fast descending axes that can outpace the pump.',
                'Long-return-line circuits with high back-pressure risk.'],
        'x' => 'Reproduce the runaway case: heavy load, meter-out too open → watch the cavitation warning, then add the makeup concept and compare metrics.'];
    $D[] = ['id' => 'hl-pilot-joystick', 't' => 'Hydraulic pilot valves & joysticks', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'Finger power for big valves: 5–30 bar pilot circuits of mobile machines.',
        'w' => 'A small manual pressure-reducing valve per axis axis: joystick angle → proportional PILOT pressure → main spool stroke. The operator commands hydraulics through hydraulics.',
        'h' => 'Each axis has two reducing cartridges; the pilot signal pushes the main valve against its centering springs proportionally. An independent low-pressure pilot supply (gear pump + relief) feeds all joysticks.',
        's' => 'Pilot supply typically 20–40 bar, 5–15 l/min. Hysteresis/linearity of the joystick cartridge = the machine’s fingertip feel.',
        'a' => ['Excavators and all mobile multi-axis machines.',
                'Remote control of valves in hazardous zones (oil in oil).',
                'Backup/manual override for electrohydraulics.'],
        'x' => 'Compare architectures: cable, electric joystick + prop valve, hydraulic pilot — rank reliability, cost, feel for a crane.'];
    $D[] = ['id' => 'hl-inductive-sensor', 't' => 'Inductive proximity sensors (hydraulic use)', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'The end-position ear: metal nearby, contact closed, no touching.',
        'w' => 'A coil oscillator damped by metal in its field; the output flips at the rated distance (1–15 mm). Immune to oil, dirt, vibration — the standard position feedback on hydraulic cylinders and slides.',
        'h' => 'A target on the moving part approaches the face → oscillator damps → Schmitt stage switches PNP (+24 V) output. Sensing range derates for non-steel materials.',
        's' => 'PNP 24 V DC 3-wire is the shop standard; M12/M18 housings. Secure the air gap as specified (flush vs non-flush).',
        'a' => ['End-position and home detection on hydraulic axes.',
                'Clamp-open verification in fixtures.',
                'Counting strokes on presses.'],
        'x' => 'Wire an inductive sensor as the "extended" input in a Studio PLC rung and complete the auto-return cycle with zero manual logic.'];
    $D[] = ['id' => 'hl-solenoid-connector', 't' => 'Solenoid coils & connectors (EN 175301)', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'The 24 V muscle on every valve — voltage types, LEDs, manual overrides.',
        'w' => 'The wet-pin solenoid converts coil current to stroke force; the standardized plug (DIN A/B/C) carries power, the diagnostic LED and sometimes suppression diodes.',
        'h' => 'Energize: armature lifts, pin strokes the spool. De-energize: the spring returns. AC coils buzz when the armature can’t seat; DC coils are quiet and PLC-friendly — hence 24 V DC as the default.',
        's' => 'Duty 100 %; power 3–30 W; check inrush on big AC coils. The LED in the connector is the fitter’s first diagnostic — use it before touching tools.',
        'a' => ['Every electrohydraulic valve station.',
                'Manual override pin: commissioning without power.',
                'Suppression-diode versions protecting PLC outputs against inductive kick.'],
        'x' => 'Studio check: set a coil energized in the component inspector, watch the valve spool slide — then unwire it and confirm the spring side wins.'];
    $D[] = ['id' => 'hl-oil-cooler-water', 't' => 'Water-oil plate coolers', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'Water eats what fans cannot: compact heat export for dense halls.',
        'w' => 'Brazed plate packs route oil and water in alternate channels — extreme heat transfer per volume. Choose when ambient air is hot, dirty, or noise-capped.',
        'h' => 'Heat duty = water flow × ΔT water ≈ oil loss to export; a water-side thermostat valve keeps oil from overcooling at winter startups.',
        's' => 'Keep water pressure below oil pressure (leaks migrate to the safer side). Watch fouling on open towers; provide strainers both sides.',
        'a' => ['Power units in hot/process halls and engine rooms.',
                'Noise-critical installations (no fans).',
                'Retrofit when air coolers hit their physical limits.'],
        'x' => 'Energy audit: your fan cooler exports 3 kW at 15 kW pump drive — what water flow replaces it at ΔT 8 K?'];
    $D[] = ['id' => 'hl-tube-pressure-drop', 't' => 'Line Δp in practice: fittings, elbows, valves', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'The Σζ budget: where pressure goes besides the straight pipe.',
        'w' => 'Every fitting, elbow, coupling and valve contributes local loss ζ·ρv²/2. Real circuits lose more in fittings than in straight pipe — count them.',
        'h' => 'Catalog ζ-values rough: elbow 0.3–0.9, T-piece 0.5–1.8, coupling 0.1–0.3, open valve full-bore ~0.2, filters 0.5–3 bar full-scale. Sum with line friction; compare against the 5–10 % budget.',
        's' => 'Velocity-square again: doubling bore ÷32 the straight part and ~÷16 local parts. Sharp edges at manifold entries are silent watts.',
        'a' => ['Design verification alongside the Studio pipe-sizing report.',
                'Hunting the mysterious 15-bar loss in an existing line.',
                'Choosing sweep elbows over 90° blocks on critical legs.'],
        'x' => 'Pick the worst line in your Studio circuit (red in sizing report), rebuild Σζ on paper, then widen one DN step and re-read.'];
    $D[] = ['id' => 'hl-hyd-fluids-choice', 't' => 'Choosing the fluid: mineral vs HFC vs HFD', 'lv' => 'advanced', 'min' => 5,
        'sm' => 'Fire code, temperature band and seals decide the oil long before price.',
        'w' => 'HLP mineral oil is the default; HFC water-glycol and HFD-R/U synthetics serve fire-risk halls per ISO 12922. Each change touches seals, paints, filters and pump ratings.',
        'h' => 'HFC: ~45 % water — fire resistant, limited to ~50 °C, derate pump speeds; HFD phosphate ester: mineral-like performance, needs FKM/EPDM seals and special paint; HFD-U esters: biodegradable premium.',
        's' => 'Never mix; full flush on conversions incl. dead legs. Check pump maker approvals (bearing lubrication ratings differ).',
        'a' => ['Steel mills/die-casting: HFC or HFD mandatory zones.',
                'Offshore/marine: biodegradables requested more often.',
                'Standard machines: HLP VG 32/46 with HV additive.'],
        'x' => 'Write the "fluid change impact list" for an HFC conversion experiment: seals, filters, paints, pump rpm, cooler duty — every line item.'];
    $D[] = ['id' => 'hl-pump-acceptance', 't' => 'Pump acceptance test (pressure-flow curve)', 'lv' => 'advanced', 'min' => 4,
        'sm' => 'Load it against the relief, measure delivery, know your volumetric truth.',
        'w' => 'The field test for pump health: throttle the outlet against measured pressure, log flow at several points — the Q(p) droop exposes internal wear better than any listening.',
        'h' => 'With relief closed slowly via test rig: flow at 0 → system pressure points; drop from nominal = volumetric efficiency loss > 10 % → overhaul candidate. Temperature-logged for fairness.',
        's' => 'Measure at rated viscosity window (40 ± 5 °C); record motor current too. Compare to commissioning baseline — trends beat absolutes.',
        'a' => ['Annual health checks on critical power packs.',
                'Post-repair verification (did we restore the pump?).',
                'Troubleshooting "machine is slow" complaints honestly.'],
        'x' => 'Simulate a worn pump in the Studio (raise its internal leakage parameter) and repeat the acceptance flow check — failure signature in hand.'];
    $D[] = ['id' => 'hl-pressure-intens-risk', 't' => 'Pressure intensification: the hidden bar machine', 'lv' => 'advanced', 'min' => 4,
        'sm' => 'Area ratios multiply pressure where you do not expect it — return lines become pressure lines.',
        'w' => 'Pressure anywhere times area ratio appears somewhere: capped annulus with load, meter-out on big φ, sealed thermal volumes. Designers must find these pockets BEFORE the hose does.',
        'h' => 'Example: cap side 100 bar on a φ=2 cylinder traps 200 bar on the rod side when pushing against a blocked rod. Locked fluid + sunshine = 10 bar/K — every °C of thermal expansion adds pressure.',
        's' => 'Rate everything on intensifiable paths for the intensified value; provide relief/thermal valves on trapped volumes; paint-warning such lines.',
        'a' => ['Meter-out circuits with large area ratios.',
                'Outdoor locked circuits with temperature swings.',
                'Accumulator trap zones after valve closure.'],
        'x' => 'Find the intensification pocket in the Studio meter-out exercise: raise load and read the rod-side gauge exceeding inlet pressure — solder the lesson in.'];
    $D[] = ['id' => 'hl-water-hammer', 't' => 'Water hammer in oil, done right', 'lv' => 'advanced', 'min' => 4,
        'sm' => 'ρ·c·Δv: the thousand-bar kiss of the snapping valve.',
        'w' => 'Instantly stopped flow converts kinetic energy to a pressure wave traveling at c ≈ 1000–1400 m/s in oil. Long lines + fast valves + speed = spikes that flatten hoses.',
        'h' => 'Δp = ρ·c·Δv (Joukowsky): doubling speed doubles it; longer lines lengthen the wave duration until 2L/c passes. Slow the valve (proportional ramp!), soften with accumulators, shorten lines.',
        'f' => 'Δp (bar) ≈ ρ·c·Δv / 10⁵ ≈ 12 × Δv (m/s) in mineral oil',
        's' => 'The countermove list: ramps, slower cartridge stages, shock accumulators near the valve, hose elasticity sometimes helps (steel pipe worst case).',
        'a' => ['Big fast presses; railway long-line systems.',
                'Emergency stop circuits that must close fast but safe.',
                'Supply headers with frequent hard switching.'],
        'x' => 'In the Studio amplifier, crank ramps down to 0 and switch hard under full speed, then set 300 ms — compare the recorded pressure ceilings.'];
        return $D;
}

/* ------------------------------------------------------------------ */
/* HYDRAULICS — circuit patterns (library part 2)                      */
/* ------------------------------------------------------------------ */
function rgz_ll_hyd_patterns() {
    $D = [];
    $D[] = ['id' => 'hl-ckt-open-center', 't' => 'Open-center idle circulation circuit', 'lv' => 'intermediate', 'min' => 6,
        'sm' => 'The classic tractor circuit: at neutral the pump flow circulates at nearly zero pressure.',
        'w' => 'An open-center directional valve connects P to T in neutral. The pump delivers full flow back to tank with only line losses, so almost no heat is generated while the machine idles. Simple, cheap, robust.',
        'h' => 'Move the spool and the P→T path throttles shut while A or B opens. Because P is unloaded in neutral, a fixed pump plus a relief valve is enough — no unloading valve needed. The penalty: only one function moves comfortably at a time, because the flow takes the path of least resistance.',
        's' => 'Choose for simple machines with one movement at a time (log splitters, tail lifts). Avoid when several axes must run simultaneously: load disappears into the open center.',
        'a' => ['Log splitters, small presses, agricultural rear linkages.',
                'Any machine where idle heating must be minimized with a fixed pump.'],
        'x' => 'In the Studio compare idle pump pressure: open-center valve vs closed valve, 60 seconds — read the temperature difference on the tank.'];
    $D[] = ['id' => 'hl-ckt-closed-center', 't' => 'Closed-center with constant-pressure pump', 'lv' => 'intermediate', 'min' => 6,
        'sm' => 'Pressure always ready: a pressure-compensated variable pump keeps P at the stand-by setting.',
        'w' => 'Closed-center valves block P in neutral, so the pump must not be a dead-headed fixed pump. A pressure-compensated piston pump holds the line at its compensator setting, delivering only leakage flow.',
        'h' => 'When a spool opens, pressure at the pump outlet drops below the compensator setting and destrokes the swash plate until flow matches demand. The compensator is effectively a pressure regulator acting on displacement.',
        'f' => 'Q &asymp; demand; standby power = p<sub>c</sub> &times; leakage flow',
        's' => 'Standby pressure 20-30 bar below working peaks drains energy; keep compensator differential and response in mind. Each function sees full system pressure — check weakest component rating.',
        'a' => ['Machine tools and injection molding with long idle phases.',
                'Multi-axis machines where functions share one pump.'],
        'x' => 'Model a compensator pump as a variable pump plus unloading logic; measure standby kW against an open-center circuit.'];
    $D[] = ['id' => 'hl-ckt-hilo', 't' => 'Hi-lo circuit with unloading valve', 'lv' => 'intermediate', 'min' => 6,
        'sm' => 'Two pumps, two personalities: big flow for speed, small flow for force.',
        'w' => 'A large and a small pump work together into P. At low pressure both deliver (fast approach); when pressure rises past the unloading valve setting, the big pump is dumped to tank at near zero pressure and only the small pump finishes the high-pressure stroke.',
        'h' => 'The unloading valve opens at the switch pressure and connects the large pump outlet to T through a check-protected branch. The check valve keeps system pressure on the actuator while the big pump idles. Total installed motor power stays small because at high pressure only the small flow remains.',
        'f' => 'P<sub>motor</sub> &asymp; (p &times; Q<sub>small</sub> + &Delta;p<sub>unload</sub> &times; Q<sub>big</sub>) / (600 &eta;)',
        's' => 'Set the unloading valve above the fast-approach pressure plus margin, below the relief. Check valve on the high-pressure side is mandatory. Size small pump flow for the pressing speed.',
        'a' => ['Presses, clamping machines, broaching machines with long fast strokes.',
                'Any cycle with a clear speed phase and force phase.'],
        'x' => 'Simulate the cycle: watch pump pressure and total flow, mark the unloading snap, and compare cycle time against a single-pump design of equal motor kW.'];
    $D[] = ['id' => 'hl-ckt-unloading', 't' => 'Accumulator standby unload circuit', 'lv' => 'advanced', 'min' => 6,
        'sm' => 'Charge, unload, sleep: the accumulator holds the pressure while the pump rests.',
        'w' => 'The circuit charges an accumulator to the relief proximity, then an unloading valve dumps pump flow to tank at &asymp; 2 bar. The actuator holds pressure from the accumulator until its pressure drops to the reload threshold, then the cycle repeats.',
        'h' => 'A piloted unloading valve senses accumulator pressure across a check valve and switches the pump between load and dump. Differential pressure (typically 15-25 %) defines reload frequency and pump duty cycle.',
        's' => 'Size the accumulator from the usable volume between p2 (working) and p3 (load pressure), precharge p0 = 0.85-0.9 &times; p2. Pump duty cycle below 40 % saves energy but stress-cycles the relief hardware — verify with the machine duty profile.',
        'a' => ['Clamping fixtures that must hold force for minutes with zero pump noise.',
                'Emergency reserve for steering or brake circuits.'],
        'x' => 'In the Studio simulate a clamp-hold cycle with the accumulator; reduce gas precharge 10 % and observe the reload frequency skyrocket.'];
    $D[] = ['id' => 'hl-ckt-meter-in', 't' => 'Meter-in speed control', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'Throttle the oil INTO the cylinder: accurate speed, but dangerous with pulling loads.',
        'w' => 'A flow control valve sits between the directional valve and the cylinder inlet. The pump delivers constant flow; the throttle decides how much may enter the actuator, excess escapes over the relief valve.',
        'h' => 'Because the directional valve sees full pump delivery while the actuator receives less, the surplus oil crosses the relief at full system pressure — that is why throttling control is warm but wonderfully simple. Speed stays constant only while load stays constant.',
        's' => 'Use on loads that always push against the cylinder (resistive loads). Never on overrunning loads: the rod side can cavitate or the load runs away. Add a check branch for free reverse flow.',
        'a' => ['Simple feed units: drilling heads, pushing conveyors.',
                'Temperature-insensitive jobs where load is well known.'],
        'x' => 'Simulate meter-in with a hanging load: read the rod-side pressure fall below zero (cavitation!) and then swap to meter-out in the next exercise.'];
    $D[] = ['id' => 'hl-ckt-meter-out', 't' => 'Meter-out speed control', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'Throttle the oil OUT: back-pressure holds any load, at the cost of pressure intensification.',
        'w' => 'The flow control restricts the return line from the cylinder. The load always works against a pressurized cushion, so even overrunning loads move at controlled speed.',
        'h' => 'The restriction creates back-pressure on the rod side. With a differential cylinder (area ratio &phi; &asymp; 2) that back-pressure is multiplied on the rod side relative to the cap side — the rod seals and hose must survive up to &phi; &times; the inlet pressure.',
        'f' => 'p<sub>rod</sub> = p<sub>cap</sub> &times; &phi; (worst case, blocked load)',
        's' => 'Rule of thumb: meter-out as default for unknown or overrunning loads, then rate return-side components for the intensified pressure. Watch thermal growth: the throttled power becomes heat directly in the return line.',
        'a' => ['Vertical axes without counterbalance valves.',
                'Retracting loads that can pull (lifting, winches with cylinders).'],
        'x' => 'Run the two throttle positions side by side under a hanging load: the pressure gauges show why the machine got hot and where intensification lives.'];
    $D[] = ['id' => 'hl-ckt-bleed-off', 't' => 'Bleed-off speed control', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'Divert the surplus instead of blocking it: cooler throttling, mushier speed.',
        'w' => 'The flow control sits in a branch from P to T. Pump flow above the set value escapes through the throttle at the actual working pressure, not at relief pressure — substantial energy savings.',
        'h' => 'Speed equals pump flow minus bled flow, so any load change that shifts working pressure changes the bleed and therefore the speed: speed stiffness is poor. Only suitable where approximate speed is enough.',
        's' => 'Combine with a fixed orifice + adjustable needle for coarse-fine control. Never use where exact speed under varying load matters.',
        'a' => ['Cheap retrofit on machines that overheat with meter-in.',
                'Conveyor drives with forgiving speed tolerance.'],
        'x' => 'Compare oil temperature after 90 s: meter-in vs bleed-off at the same cycle and same load — read the kW that became degrees.'];
    $D[] = ['id' => 'hl-ckt-pc-flow', 't' => 'Pressure-compensated flow control', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Two valves in one: a throttling pin plus a compensator piston that keeps &Delta;p constant.',
        'w' => 'Because throttle flow follows &Delta;p, load changes would change speed. The pressure compensator senses the pressure drop across the metering orifice and opens or closes a second spool to hold that drop (typically 8-14 bar), making flow independent of both load and pump pressure.',
        'h' => 'Two-port (2-way PC) versions keep the excess on the pump (heat, like meter-in, but stiff); three-port versions dump surplus to tank at working pressure and act like bleed-off with load-insensitive speed.',
        'f' => 'Q = c<sub>d</sub> &middot; A(x) &middot; &radic;(2&Delta;p/&rho;) with &Delta;p fixed by the spring',
        's' => 'Check minimum pressure window: compensation needs the compensator &Delta;p plus throttle &Delta;p, so below &asymp; 20 bar supply the regulation dies. Prefer 3-port for energy, 2-port for simple plumbing.',
        'a' => ['Exact feed speeds on machine tools independent of the day (oil warm-up!).',
                'Hydraulic motor speed regulation on winches.'],
        'x' => 'Simulate a fixed throttle vs a PC valve with load swept 10-90 bar at 60 s; plot flow deviation — stiffness quantified.'];
    $D[] = ['id' => 'hl-ckt-regen', 't' => 'Regenerative (differential) fast approach', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Steal the return oil: rod-side flow joins the cap side and the cylinder flies.',
        'w' => 'During extension the oil expelled from the rod side is routed back into the cap side instead of tank. The cylinder extends with pump flow plus recycled rod flow at the cost of force (force works only on the annulus area).',
        'h' => 'With &phi; = 2 (cap area twice the rod area), regeneration doubles extension speed and halves extension force. At the end of approach a sequence or pressure switch kicks the circuit into normal mode for the working stroke.',
        'f' => 'v<sub>regen</sub> = Q<sub>pump</sub> / A<sub>rod</sub>; F = p &times; A<sub>rod</sub>',
        's' => 'Only useful with regenerative-capable valves (P→A, B→A paths) or dedicated regen check configurations. Verify buckling: the fast stroke still carries the full-load rod.',
        'a' => ['Presses and compacting machines with long approach, short force stroke.',
                'Forklift mast fast lift when empty.'],
        'x' => 'Flip the Studio valve into regeneration at mid-stroke: note the speed jump and force collapse; then let the pressure switch terminate regen automatically.'];
    $D[] = ['id' => 'hl-ckt-sequence', 't' => 'Sequence circuit: clamp, then work', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'Pressure is the clock: cylinder 2 starts only after cylinder 1 has built force.',
        'w' => 'A sequence valve in the supply of cylinder 2 stays closed until the pressure from cylinder 1 (the clamp) reaches its setting. Only then does flow reach the work cylinder. Order is guaranteed hydraulically, no sensors needed.',
        'h' => 'Pressure builds when a cylinder finds its end stop or the clamped part. The sequence valve opens at e.g. 70 bar, the second actuator runs, and on return both retract together (the sequence valve is bypassed by its integral check valve).',
        's' => 'Set the sequence value well above the travel pressure of cylinder 1, below the relief. Remember: a leak on cylinder 1 can drop pressure below the sequence setting mid-cycle — diagnose with the pressure gauge before blaming valves.',
        'a' => ['Clamp-then-drill or clamp-then-weld fixtures.',
                'Tool changers where grip must exist before motion.'],
        'x' => 'Build the clamp-drill sequence; mis-set the sequence valve 20 bar low and watch the drill start on a loose part — the classic shop-floor fault.'];
    $D[] = ['id' => 'hl-ckt-flowdiv', 't' => 'Flow divider synchronization', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Two cylinders share one pump — the divider forces each drop to split 50/50.',
        'w' => 'A rotary (gear) flow divider or a spool-type divider splits inlet flow into two nearly equal parts regardless of the individual loads, so two cylinders move in step with 2-5 % accuracy.',
        'h' => 'Two gear sections on a common shaft act as coupled motor-pump pairs: the faster (lighter loaded) side is throttled by the coupling, the slower side is boosted. Overrun conditions can even pass power from one branch to the other.',
        's' => 'Accuracy 2-4 % typical, pressure intensification possible on dead-headed branches (relief per outlet!). Synchronizing errors accumulate — re-phasing at stroke end via bypass orifice is standard practice.',
        'a' => ['Scissor lifts with two rams, wide press platens.',
                'Synchronized tilting of two-motor slewing drives.'],
        'x' => 'Build parallel cylinders with a flow divider in the Studio, load one side twice as hard, and measure the position spread at stroke end.'];
    $D[] = ['id' => 'hl-ckt-series-sync', 't' => 'Series cylinders synchronization', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'Rod-out oil of cylinder 1 feeds cylinder 2: geometric synchronism for zero cost.',
        'w' => 'The rod-side outlet of the first cylinder connects to the cap side of the second. If A<sub>cap,2</sub> = A<sub>rod,1</sub> exactly, both pistons move at identical speed — the transferred volume forces it.',
        'h' => 'Because the first pressure must drive two loads, system pressure sees the sum of both loads referred to the cap area of cylinder 1. Manufacturing tolerances and rod creep accumulate error, so end-stroke re-phasing valves or make-up check circuits are common.',
        's' => 'Perfect for two cylinders only, and only where exact area matching can be ordered. Make-up oil paths and bleed screws at the high points are mandatory.',
        'a' => ['Opening two halves of a mold or hatch.',
                'Compact lifts where a flow divider will not fit.'],
        'x' => 'Chain two cylinders in series in the Studio; watch pump pressure double and explain to yourself where the extra bar goes.'];
    $D[] = ['id' => 'hl-ckt-reducing', 't' => 'Pressure-reducing branch for clamping', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'One system, two pressure levels: delicate parts clamped at 40 bar from a 160 bar supply.',
        'w' => 'A pressure-reducing valve in a branch line limits downstream pressure to its setting, independent of the main system pressure. Upstream may fluctuate — the clamped workpiece feels only the reduced value.',
        'h' => 'The reducing valve is normally open: downstream pressure acts on the spool against the spring; when set pressure is reached the spool throttles or closes. Relieving versions can even vent downstream overpressure to T (important with thermal expansion).',
        's' => 'Always relieving-type for clamping circuits (sun on a fixture!). Take the pilot drain to tank separately if back-pressure exists. Reduced pressure costs energy: the dropped bar times flow becomes heat.',
        'a' => ['Work-holding on machine tools next to a high-pressure rapid traverse circuit.',
                'Brake circuits fed from the main hydraulic supply.'],
        'x' => 'Clamp a fragile part at 40 bar while the main axis uses 150 bar; then block the drain line and watch creep destroy the part — drain hygiene made visible.'];
    $D[] = ['id' => 'hl-ckt-dump', 't' => 'Emergency dump: designing pressure away', 'lv' => 'advanced', 'min' => 5,
        'sm' => 'Machine safety principle: one valve that makes pressure disappear on demand.',
        'w' => 'A normally-open solenoid valve piped from P to T (venting the relief spring chamber of the main relief or the compensator line) de-pressurizes the whole system when the safety chain breaks. Stored-energy accumulators need their own dump path.',
        'h' => 'Venting the relief drops system pressure to the vent-line back-pressure (few bar). Category 0/1 stops use dump + motor stop; monitored dump valves with feedback contacts satisfy performance levels in ISO 13849 circuits when dual-channel.',
        's' => 'Dump rate must de-energize the machine within the risk-assessment time. Manual dump for maintenance (LOTO) belongs at eye height with a lock facility.',
        'a' => ['Presses and robots inside guarded cells.',
                'Emergency retract: dump releases the load and a spring accumulator retracts the tool.'],
        'x' => 'Simulate a loaded press; open the dump valve mid-hold and record how fast pressure collapses — then size the dump line for the required time.'];
    $D[] = ['id' => 'hl-ckt-twohand', 't' => 'Two-hand anti-tie-down circuit', 'lv' => 'advanced', 'min' => 5,
        'sm' => 'Both hands or nothing — and re-press within 0.5 s if released.',
        'w' => 'Two manual valves in series (hydraulic AND) supply the directional valve pilot stage. Both must be pressed within the anti-tie-down window; releasing either one interrupts pilot pressure and returns the main spool to safe state.',
        'h' => 'Anti-tie-down logic uses a small pilot accumulator/valve block that outputs only on simultaneous fresh press events within e.g. 500 ms. Holding one button with a clamp generates no output because the timing element never completes.',
        's' => 'Buttons spaced &ge; 300 mm (inside edge) defeat one-hand-one-elbow operation. Prefer monitored pneumatic/hydraulic cartridges certified for the required PL over home-built spool logic on modern machines.',
        'a' => ['Manual press workstations.',
                'Riveting and clinching tools.'],
        'x' => 'In the Studio, press one button (nothing), press both correctly (cycle), release mid-stroke (safe stop): the three cases every auditor checks.'];
    $D[] = ['id' => 'hl-ckt-dwell', 't' => 'Press cycle: approach, press, dwell, decompress', 'lv' => 'intermediate', 'min' => 6,
        'sm' => 'The four-stroke of every serious press — and why decompression saves the machine.',
        'w' => 'Fast approach via regeneration or hi-lo, controlled pressing speed via flow control, dwell under pressure holding (closed center + pump unload), then a controlled pressure release BEFORE the fast return.',
        'h' => 'During dwell the cylinder stores elastic energy (compressed oil + stretched frame + compressed tooling). Opening the return path abruptly releases it as a pressure wave — the notorious press bang. Decompression circuits bleed the cap volume through a small orifice or a proportional ramp until &lt; 10 bar, then open fully.',
        's' => 'Dwell time comes from a timer or a pressure-maintaining circuit (pilot-operated check holds, accumulator tops up). Decompression time typically 0.5-3 s scaled by stored volume.',
        'a' => ['Forming, deep drawing, composite pressing.',
                'Clamp-hold-release cycles in test rigs.'],
        'x' => 'In the Studio, return without decompression and read the spike; engage the orifice path and watch the bang disappear at the price of cycle seconds.'];
    $D[] = ['id' => 'hl-ckt-counterbalance', 't' => 'Vertical axis with counterbalance valve', 'lv' => 'intermediate', 'min' => 6,
        'sm' => 'The load can never run away: it lowers only when pilot pressure invites it.',
        'w' => 'A counterbalance (load-holding) valve in the rod-side line of a vertical cylinder closes leak-free under the load. To lower, pressure on the cap side pilots the valve open with a defined pilot ratio (e.g. 3:1 or 10:1).',
        'h' => 'Pilot ratio is a lever: with ratio 3:1 and spring setting 1.3 &times; load pressure, cap pressure only needs one third of the margin to start lowering. Too stiff a spring = jerky starts; too soft = the valve never truly holds under hose-burst assumptions.',
        'f' => 'p<sub>pilot,needed</sub> = (p<sub>set</sub> - p<sub>load</sub>) / pilot ratio',
        's' => 'Mount ON the cylinder port — a burst hose between valve and cylinder is then harmless. Oversize setting 1.3 &times; maximum load pressure. External drain version when the return line carries back-pressure.',
        'a' => ['Booms, lifts, outriggers — any axis that hangs.',
                'Machine safety: load stays when power fails.'],
        'x' => 'Lower a hanging load with meter-out only, then with counterbalance: compare cap-side pressure demand and temperature over 10 cycles.'];
    $D[] = ['id' => 'hl-ckt-brake', 't' => 'Motor braking with crossline relief', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Stop a spinning motor by making it pump against a valve that says how hard.',
        'w' => 'Two relief valves mounted anti-parallel across the hydraulic motor ports limit pressure in both directions. When the directional valve closes, the spinning inertia drives the motor as a pump; the crossline relief absorbs the kinetic energy as heat.',
        'h' => 'Each relief covers one rotation direction; make-up check valves from tank prevent cavitation on the suction side while the motor coasts down. Braking torque follows the relief setting — the deceleration ramp is adjustable by bar.',
        's' => 'Size make-up flow for the full coast volume. Set braking relief above working peaks, below motor case and shaft limits. For frequent braking watch heat: each stop converts the full kinetic energy.',
        'a' => ['Winches, slew drives, conveyor drums.',
                'Emergency stops of high-inertia fans.'],
        'x' => 'Spin a flywheel motor, close the valve hard, and log the pressure spike with and without the crossline pair — then tune the setting for the target stopping time.'];
    $D[] = ['id' => 'hl-ckt-float', 't' => 'Float position circuits', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'Both cylinder ports to tank: the implement follows the ground by itself.',
        'w' => 'A valve float position connects A and B to T while P stays blocked (or unloaded). The cylinder moves freely with external forces — this is how a plow or a road grader blade hugs the terrain.',
        'h' => 'In float, the valve center is an H- or Y-like configuration. Selecting float releases the hydraulics completely: the cylinder becomes a gas-free, oil-damped sliding link. Anti-cavitation checks often accompany the valve to prevent vacuum when the load drives the piston fast.',
        's' => 'Never float over people-paths without mechanical support. In simulation, float is perfect for testing that a vertical load without counterbalance drops — a training moment.',
        'a' => ['Snow plows, dozer blades, follower rollers.',
                'Maintenance position: release pressure for manual adjustment.'],
        'x' => 'Use float on a simulated blade axis and feel (via the gauge) that pressure is gone; then engage work position and compare.'];
    $D[] = ['id' => 'hl-ckt-ls', 't' => 'Load-sensing fundamentals', 'lv' => 'advanced', 'min' => 6,
        'sm' => 'The pump listens to the load: it delivers what is needed, at &Delta;p constant.',
        'w' => 'A load-sensing pump compares its outlet pressure with the highest actuator load pressure reported through an LS shuttle network. Its controller holds a constant margin (stand-by &Delta;p &asymp; 15-25 bar), so flow follows valve opening, not pump ego.',
        'h' => 'Each valve includes a pressure compensator that keeps the local &Delta;p across its metering notch equal; therefore each function receives the flow proportional to spool travel, independent of load. The LS line is the nervous system returning the highest pressure to the pump regulator.',
        's' => 'Keep the LS line short, small-bore and damped; the compensator spring defines minimum &Delta;p — below it, control dies. LS saves 30-50 % energy versus constant-pressure systems in mixed duty.',
        'a' => ['Excavators: simultaneous boom, stick, bucket with one pump.',
                'Mobile cranes, telehandlers, agricultural tractors.'],
        'x' => 'Simulate two axes with different loads on one LS-type source: move both proportionally and note each keeps its set speed — the definition of load independence.'];
    $D[] = ['id' => 'hl-ckt-flowshare', 't' => 'Flow sharing (LUDV) when the pump saturates', 'lv' => 'advanced', 'min' => 5,
        'sm' => 'When oil runs out, LUDV shrinks all speeds proportionally instead of starving the light axis.',
        'w' => 'Conventional LS fails at saturation: the lightest function wins and the heavy function stops. LUDV compensators sense AFTER the metering notch against the highest load pressure, so a too-small pump simply scales every function down by the same percentage.',
        'h' => 'Because all compensators reference the same downstream pressure, the pressure ratios across notches stay identical — flows divide by notch area, not by load. The operator experiences graceful slow-down instead of sudden axis death.',
        's' => 'Standard on modern multi-function excavators. Diagnosis differs from classic LS: check compensator spool stiction first when functions move lazily under saturation.',
        'a' => ['Compact excavators working boom + track simultaneously.',
                'Any multi-axis mobile machine with driver-operated proportional joysticks.'],
        'x' => 'Demand 140 % pump flow from two axes; compare LS (light stops heavy) vs LUDV (both slow equally) in the Studio pressure strip-chart.'];
    $D[] = ['id' => 'hl-ckt-ramp', 't' => 'Proportional ramping against shock', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Ramp the spool, not the mechanics: 300 ms of electronics replaces liters of accumulator.',
        'w' => 'Proportional valves ramp spool travel electronically. Acceleration and deceleration times (separately for on and off edges) convert step-changing flow into smooth S-curves, killing water hammer and load sway.',
        'h' => 'The amplifier card multiplies the command by a time-limited slew rate. Load sway frequency (&asymp; 0.5-3 Hz for cranes) and cylinder natural frequency define the minimum ramp: faster than the system can follow only excites oscillation.',
        's' => 'Ramp long enough that peak pressure stays below hose impulse rating; short enough that takt time survives. Separate ramps per direction help asymmetric cylinders.',
        'a' => ['Cranes and concrete pumps (load sway).',
                'Press tables and lifting platforms with personnel nearby.'],
        'x' => 'In the Studio amplifier: ramp 0 ms vs 400 ms on a heavy cylinder, record pressure peak and rod-end vibration — write the trade-off as numbers.'];
    $D[] = ['id' => 'hl-ckt-servo-axis', 't' => 'Servo axis: stiffness, gain, stability', 'lv' => 'advanced', 'min' => 6,
        'sm' => 'Closed-loop positioning with oil: micron accuracy if you respect physics.',
        'w' => 'A servo or high-response proportional valve, position feedback transducer and controller close a loop around the cylinder. Control quality is governed by the hydraulic natural frequency &omega;<sub>h</sub> — loop gain must stay a comfortable factor below it.',
        'h' => 'Stiffness comes from oil compressibility over trapped volume: short hoses, thick walls, no entrained air. Damping is naturally low (0.05-0.2), so controller filters and valve overlap design carry the stability burden.',
        'f' => '&omega;<sub>h</sub> = &radic;(4 &middot; &beta; &middot; A&sup2; / (V &middot; m)) ',
        's' => 'Keep total trapped volume minimal (valve on the cylinder). Use accumulators? Never on axis lines. Expect valve sizing at 1/3 supply &Delta;p across the metering edge at design point.',
        'a' => ['Test rigs and fatigue machines.',
                'Injection molding axes, rolling mills (AGC).'],
        'x' => 'Build the position loop in the Studio amplifier; raise gain until ringing appears — you just found practical stability margin by hand.'];
    $D[] = ['id' => 'hl-ckt-kidney', 't' => 'Kidney (off-line) filtration loop', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'A small pump-filter circuit that polishes the tank 24/7, independent of the machine.',
        'w' => 'Off-line filtration circulates 5-10 % of tank volume per minute through a fine filter (e.g. &beta;<sub>6</sub> = 200) driven by its own small motor-pump. It runs while the main machine works, idles, or sleeps.',
        'h' => 'Because flow is constant and low, the filter works in its best efficiency window far from surges. Cooling can ride in the same loop (filter-cooler skid), cleaning while conditioning temperature.',
        's' => 'Size for the contamination generation rate of the system, not for tank size alone. Take suction from the dirty zone (opposite the return diffuser), return via clean side.',
        'a' => ['Servo and proportional systems needing ISO 15/13/10.',
                'Retrofits on machines whose main filters cannot be finer.'],
        'x' => 'Instrument the Studio tank cleanliness; run with and without the kidney loop and extrapolate element life — maintenance engineers love this math.'];
    $D[] = ['id' => 'hl-ckt-cooling', 't' => 'Cooling circuit sizing', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Every wasted kW must leave as heat — pick the radiator before the summer does.',
        'w' => 'Losses (relief flow, throttling, leakage) heat the oil; the cooler must dissipate the average loss power at the maximum ambient temperature while keeping oil below 60-65 &deg;C.',
        'h' => 'Air-blast coolers sit in the return line with a bypass check (cold morning start protection!). Water-oil plate coolers give compact performance where water exists. A thermostat bypass protects viscosity during warm-up.',
        'f' => 'P<sub>cooler</sub> &ge; P<sub>loss,average</sub> - P<sub>naturally dissipated</sub> (tank walls &asymp; 15 W/m&sup2;K)',
        's' => 'Place AFTER the filter? No: place the filter after the cooler (cooler dirties oil at high &Delta;p). Return-line coolers see pressure spikes — bypass accordingly or use off-line cooling.',
        'a' => ['Presses with long dwell under unload (marginal cooling need).',
                'Hot climates: every mobile machine.'],
        'x' => 'Simulate a relief-dominated cycle with the cooler disabled: watch the temperature drift 2 &deg;C/min and compute the required cooler kW from the slope.'];
    $D[] = ['id' => 'hl-ckt-flush', 't' => 'Flushing after repair or assembly', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'New pipes are dirty pipes: flush until the oil is cleaner than the machine needs.',
        'w' => 'Before commissioning, oil is circulated at high velocity through the new or repaired circuit with components bypassed (hoses jumpered), until particle counts meet class -2 of the target cleanliness.',
        'h' => 'High Reynolds numbers (turbulence) scrub walls: velocity 2-4 &times; operating speed, pulsating if possible. Dead legs and cylinders are flushed with temporary loops. Sampling valves verify progress.',
        's' => 'Never flush through servo valves — jumpers! Document patch-sample or online counts per line. Budget one full tank volume through the flush filter before judging.',
        'a' => ['Commissioning of new systems.',
                'After pump failure: the debris bomb cleanup.'],
        'x' => 'Trace in the Studio which lines sit behind the valve and would be skipped by lazy flushing — draw your jumper plan on the schematic.'];
    $D[] = ['id' => 'hl-ckt-bleed', 't' => 'Air bleeding procedure', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'Spongy actuators and banging pumps: air — the treatable disease.',
        'w' => 'Trapped air compresses, making cylinders spongy, noisy and position-drunk. Bleeding moves oil through every high point until bubble-free oil exits.',
        'h' => 'Procedure: low pressure first, stroke cylinders end to end 5-10 times with bleed screws open at the highest points, then the pump suction side, then the valve bodies with vent options. Never crack fittings under pressure: loosen at low pressure only.',
        's' => 'Cylinders mounted rod-down trap air at the cap — their bleed screws matter most. Foam in the sight glass = suction leak; find it with the smoke or shaving-cream test.',
        'a' => ['Every commissioning and every repair.',
                'Erratic cylinder motion with correct electrics: bleed before blaming the card.'],
        'x' => 'Find the high points in a Studio circuit and mark the bleed locations an auditor would expect.'];
    $D[] = ['id' => 'hl-ckt-commission', 't' => 'Commissioning checklist', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Start-up is a procedure, not a key switch.',
        'w' => 'Sequence: mechanical completion check, flushing class verified, oil and level correct, suction valve OPEN (the classic killer), case-drain lines first to tank, pump primed, relief backed out, inch the motor rotation, raise pressure in steps.',
        'h' => 'Rotation check with 1 s bumping; then pump pressure at 20 bar; listen for cavitation; then functions one by one at reduced speed; finally full pressure with relief calibration against a reference gauge of known class.',
        's' => 'Document every setting (relief, compensators, switches) with values and technician initials — these baselines are gold for later troubleshooting.',
        'a' => ['New machines and post-rebuild startups.',
                'Acceptance tests where payment milestones depend on witnessed readings.'],
        'x' => 'Walk a Studio circuit through the checklist order and note which three mistakes the simulation punishes first.'];
    $D[] = ['id' => 'hl-ckt-testpoints', 't' => 'Test point strategy', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'Plan measurement BEFORE doubt: one coupling per decade of pressure.',
        'w' => 'Minimess-style test couplings at pump outlet, after the main valve, at both cylinder ports and on pilot lines turn fault-finding from days into minutes. They connect under full pressure with the appropriate fitting.',
        'h' => 'Position matters more than count: upstream and downstream of each suspected throttling element lets &Delta;p be measured, not guessed. Permanent sensors feed the PLC trend; couplings serve the technician.',
        's' => 'Cap them (dust kills). Route hoses away from moving parts. A single gauge with quick coupler covers the whole machine.',
        'a' => ['Machines in continuous production where downtime costs dominate.',
                'Training rigs (the Studio demonstrates each point).'],
        'x' => 'Place test points in a Studio sequence circuit and find, with three readings, a valve stuck mid-way — the fastest diagnosis possible.'];
    $D[] = ['id' => 'hl-ckt-suction', 't' => 'Suction line design against cavitation', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'The pump feeds by atmosphere alone: give it a VIP corridor.',
        'w' => 'Atmospheric pressure pushes oil into the pump; any restriction consumes the tiny available head. Rules: large diameter (velocity 0.5-1.5 m/s), short, no sharp bends, no risk of air traps, strainer optional but generously sized.',
        'h' => 'Cavitation begins when local pressure falls below the vapor pressure of dissolved air — bubbles collapse at the pressure side with micro-jets that erode gears and vanes, sounding like gravel in the pump.',
        'f' => 'Available NPSH = p<sub>atm</sub> - &Delta;p<sub>line</sub> - &Delta;p<sub>strainer</sub> - p<sub>vapor</sub>',
        's' => 'Cold starts are the test: viscosity 1000 cSt multiplies losses. Shutoff valves in suction lines need interlocks or position switches (forgetting = pump death in minutes).',
        'a' => ['Every power pack design.', 'Cold-climate mobile machines.'],
        'x' => 'Restrict the suction line in the Studio tank model; watch volumetric efficiency fall and noise flag rise — repeat with 2x diameter.'];
    $D[] = ['id' => 'hl-ckt-filter-select', 't' => 'Filter placement: pressure, return, off-line', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'One machine, three philosophies — the great filter debate settled by failure modes.',
        'w' => 'Pressure filters protect expensive components directly (servo valves), return filters catch everything before the tank, off-line loops polish continuously. Most industrial machines combine return + component-protection pressure filters.',
        'h' => 'Pressure filters need high pressure rating and see full flow pulses; return filters see surge flows from differential cylinders (up to 2&times; pump flow!) and need bypass valves. Off-line filters never protect against sudden ingress.',
        's' => 'Never put the only fine filter in suction: the pump dies of starvation before the filter clogs. Indicator (visual + electrical) on every filter, wired to maintenance-not-required-but-logged.',
        'a' => ['Servo systems: 3-6 &micro;m pressure filter directly at the valve.',
                'Standard machines: 10 &micro;m return filter plus off-line polishing.'],
        'x' => 'Decide filter placement for a proportional press circuit and defend it against the three failure modes (wear debris, ingress, water).'];
    $D[] = ['id' => 'hl-ckt-thermal', 't' => 'Thermal expansion in locked volumes', 'lv' => 'intermediate', 'min' => 4,
        'sm' => '10-12 bar per degree Celsius: the sun pressurizes your parked machine.',
        'w' => 'Oil trapped between two closed valves expands with temperature. With bulk modulus 14000 bar and thermal expansion 0.0007/K, every +1 K adds roughly 10 bar to a rigid locked volume.',
        'h' => 'Overnight cooling or noon sun can push a clamp circuit from 120 to 250 bar — or drop it to vacuum. Thermal relief valves set just above working pressure protect hoses and fixtures.',
        's' => 'Any circuit that locks oil under load and sees weather or process heat needs a thermal valve or a relieving branch. Accumulator circuits already carry them if correctly designed.',
        'a' => ['Outdoor clamps and forklift attachments parked loaded.',
                'Hot presses with locked holding pressure.'],
        'x' => 'Lock a Studio cylinder under load, raise oil temperature 15 &deg;C, and read the gauge — then add the thermal valve and repeat.'];
    $D[] = ['id' => 'hl-ckt-intensifier', 't' => 'Work-holding with a pressure intensifier', 'lv' => 'advanced', 'min' => 5,
        'sm' => '600 bar clamping from a 200 bar machine — no second power pack.',
        'w' => 'Media separators and oscillating automatic intensifiers convert low-pressure flow into high-pressure micro-flow using area ratios. Clamping fixtures reach pressures the HPU never sees.',
        'h' => 'A large piston driven by system pressure pushes a small piston into the fixture volume; strokes reverse automatically through an internal pilot valve, pumping until the intensified pressure equals ratio &times; supply pressure.',
        'f' => 'p<sub>high</sub> = p<sub>low</sub> &times; (A<sub>big</sub>/A<sub>small</sub>) - losses',
        's' => 'High side must be dead-headed and leak-free: any leak drains the amplifier continuously and heats oil. Use only mineral-oil-rated seals on the HP side unless specially ordered.',
        'a' => ['Zero-point clamping systems and hydraulic fixtures.',
                'Bolt tensioning, hydro-test of components.'],
        'x' => 'Verify the ratio in the Studio amplifier exercise: measure both sides, compute areas, and predict the stall pressure before running.'];
    $D[] = ['id' => 'hl-ckt-motor-series', 't' => 'Hydraulic motors in series', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'Same flow through each shaft: equal speed, torque adds up.',
        'w' => 'Series-connected motors pass the same flow through each unit; each converts its share of the total pressure drop into torque. Speeds equalize naturally (like rollers on one belt of oil).',
        'h' => 'Because shaft seals on motor 1 see the outlet pressure feeding motor 2, case drains are mandatory and the first seal must survive intermediate pressure. Total available torque divides across stages.',
        's' => 'Use for synchronized drives with modest shock tolerances; unequal loads do not desynchronize (flow forces the speed) but do shift the torque split. Case drain pressure limits chain length.',
        'a' => ['Dual auger drives, synchronized feeder rolls.',
                'Simple approximate sync where flow dividers are too costly.'],
        'x' => 'Series two Studio motors, load one heavily, watch speeds stay matched and pressures split — then estimate the torque of each shaft from the &Delta;p.'];
    $D[] = ['id' => 'hl-ckt-motor-parallel', 't' => 'Hydraulic motors in parallel', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'Same pressure, flow finds the easy path: speed wanders with load.',
        'w' => 'Parallel motors see the same pressure; each takes the flow its load allows. The lighter-loaded unit accelerates and steals flow — inherent differential behavior, sometimes useful, often annoying.',
        'h' => 'Useful when mechanical coupling exists anyway (both wheels of an axle): the differential action is welcome in curves. Without coupling, speeds drift until loads re-balance.',
        's' => 'For forced equal speeds go to flow dividers or series connection. Check case drain and cross-line relief: a stalled motor in a parallel group is a relief-heating machine.',
        'a' => ['Vehicle wheel drives with open differential behavior.',
                'Two tool drives where individual speed control valves exist anyway.'],
        'x' => 'Parallel two motors, brake one shaft: observe speed redistribution and rehearse the differential diagnosis of "why is wheel A spinning".'];
    $D[] = ['id' => 'hl-ckt-decompression', 't' => 'Dedicated decompression circuit', 'lv' => 'advanced', 'min' => 5,
        'sm' => 'A small valve first, the big valve later: nobody hears the release.',
        'w' => 'Before opening the main return path of a large charged cylinder, a small parallel path (needle valve, proportional throttle or special decompression spool) releases the stored volume slowly to tank.',
        'h' => 'Stored energy = p&sup2;V/(2&beta;) in oil plus frame elasticity. Releasing through a big orifice in 50 ms converts it to a pressure wave; a 10 mm path over 2 s converts it to silence. Timers or pressure switches trigger the big spool only below a threshold (e.g. 10 bar).',
        's' => 'Size decompress time from volume and pressure: rule of thumb 0.3-0.5 s per liter at 200 bar. Interlock the main valve to pressure feedback, not to time alone.',
        'a' => ['Forming presses &gt; 500 kN.',
                'Test cylinders with high pre-load.'],
        'x' => 'Plot the stored-energy math for your Studio cylinder, then verify the spike difference with decompression on/off.'];
    $D[] = ['id' => 'hl-ckt-remote-relief', 't' => 'Remote relief venting and two-stage pressure', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'The pilot line is a remote control: switch between two pressure levels or go to unload.',
        'w' => 'The pilot spring chamber of a pilot-operated relief valve can be piped away to small remote valves: a second relief setting for reduced pressure, or a solenoid valve to dump the chamber to tank for full unload.',
        'h' => 'Venting drops main pressure to the crack pressure of the main stage (&asymp; 5-10 bar): pump flow goes to tank at idle pressure. The lower of the two pilot settings always governs; switching is fast and electrically cheap.',
        's' => 'Keep remote lines short (&lt; 3 m) and small: long lines oscillate. Use damped poppets where switching shock hurts. Fail-safe: vent on power loss = unload.',
        'a' => ['Two-speed clamping machines: working pressure vs setup pressure.',
                'Cycle-start unloading for soft motor start.'],
        'x' => 'Wire the vent solenoid in the Studio, watch idle power collapse, then mis-wire it normally-closed and explain the overheating complaint.'];
    $D[] = ['id' => 'hl-ckt-amplifier', 't' => 'Setting ramps on the electronic amplifier', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'The card is the machine behavior: dither, ramps, gains — tuned by screwdriver or software.',
        'w' => 'Proportional amplifier cards translate command voltage into solenoid current (PWM), offering ramp times per direction, min/max (Imin/Imax) trims, and dither frequency/amplitude to fight spool hysteresis.',
        'h' => 'Dither (e.g. 100-300 Hz, 5-20 % of rated current) keeps the spool vibrating microscopically so static friction never wins. Ramps limit command slew rate; Imax scales maximum speed; Imin compensates deadband for smooth creep.',
        's' => 'Tune in order: Imin with command at 1 %, then Imax at 100 %, then ramps against the mechanical reality, finally dither for hysteresis. Document trimmer positions — they wander.',
        'a' => ['Every proportional machine commissioning.',
                'Retrofitting smoothness into jerky old equipment.'],
        'x' => 'In the Studio amplifier module, kill the dither and measure hysteresis opening/closing the valve — restore it and quantify the cure.'];
    $D[] = ['id' => 'hl-ckt-switches-chain', 't' => 'Safety chain of pressure switches', 'lv' => 'advanced', 'min' => 5,
        'sm' => 'Every permission condition gets a contact; all contacts vote in series.',
        'w' => 'Filter clogging, low level, over-temperature, over-pressure: each monitored by a switch whose contacts form a series chain that cuts the motor contactor or dumps pressure when any link opens.',
        'h' => 'NC (closed when healthy) wiring is the safe philosophy: a broken wire looks like a fault, not a permission. Monitored (positively-driven) contacts and two-channel redundancy raise the performance level.',
        's' => 'Debounced PLC inputs or time relays prevent chatter from commissioning every pump start. Test each switch individually during maintenance — never assume the chain works.',
        'a' => ['Large power packs in continuous duty.',
                'Machines under ISO 13849 requirements.'],
        'x' => 'Model the chain logic against the Studio tank module: pull the level switch mid-run and trace which output must fall.'];
    $D[] = ['id' => 'hl-ckt-energy-audit', 't' => 'Energy audit of a running circuit', 'lv' => 'advanced', 'min' => 6,
        'sm' => 'Follow the kilowatts: relief, throttling, leakage — the three heating plants.',
        'w' => 'Every pressure drop times flow becomes heat: P<sub>loss</sub> = &Delta;p &times; Q / 600. Walk the cycle with gauges and flow readings, compute kW per station, and attack the biggest loss first.',
        'h' => 'Classic findings: idle flow over the relief (open-center missing), meter-in during high-force dwell (throttle at 100+ bar), undersized lines (&gt; 5 bar piping losses), leaking pump (&Delta;T across pump body).',
        'f' => 'P<sub>loss</sub> (kW) = &Delta;p (bar) &middot; Q (l/min) / 600',
        's' => 'A 3 kW saving at 6000 h/a and 0.15 currency/kWh pays most retrofits in a year. Bring numbers, not opinions — the temperature rise alone quantifies steady-state loss.',
        'a' => ['Energy-efficiency programs in plants.',
                'Justifying variable-speed pump retrofits.'],
        'x' => 'Run the Studio efficiency report on a meter-in circuit, then convert the same machine to bleed-off — the kW table writes your business case.'];
    $D[] = ['id' => 'hl-ckt-design-steps', 't' => 'Capstone: ten steps to design a hydraulic circuit', 'lv' => 'advanced', 'min' => 8,
        'sm' => 'From force and speed data to a numbered schematic — the complete professional workflow.',
        'w' => '1) List actuators with forces, speeds, directions and duty. 2) Choose system pressure class. 3) Size cylinders/motors (with x1.5 force margin). 4) Compute flows and peak/average power. 5) Select pump type and drive power. 6) Choose control philosophy (valve types, throttle vs displacement control). 7) Size valves, lines, cooler, filter, tank. 8) Add safety: relief, load-holding, dump, interlocks. 9) Instrument and document (gauges, test points, settings list). 10) Simulate and verify edge cases (load loss, hose burst, blocked rod).',
        'h' => 'The order matters: pressure class before cylinder size, flow before pump, cycle profile before cooler. Skipping steps produces the classic over-heated, over-powered machine — every shortcut returns as degrees Celsius.',
        'f' => 'P = F &middot; v / (&eta;); Q = A &middot; v; P<sub>kW</sub> = p &middot; Q / 600&eta;',
        's' => 'Simulate before building: an hour in the Studio finds sequence errors, intensification pockets and heat problems that would cost weeks on the floor.',
        'a' => ['Your next machine project.', 'Teaching juniors a repeatable method.'],
        'x' => 'Execute all ten steps on one of the Studio guided examples, screenshot the schematic and the settings list: that is a professional design dossier.'];
    return $D;
}

/* ------------------------------------------------------------------ */
/* HYDRAULICS — fundamentals & sizing (library part 3)                 */
/* ------------------------------------------------------------------ */
function rgz_ll_hyd_fundamentals() {
    $D = [];
    $D[] = ['id' => 'hl-f-power', 't' => 'Hydraulic power: the p times Q currency', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'Pressure times flow, divided by 600 — the one formula behind every kW decision.',
        'w' => 'Hydraulic power is flow against pressure. In field units: P (kW) = p (bar) &times; Q (l/min) / 600. Every design budget — motor size, cooler size, heat generation — converts through this single identity.',
        'h' => 'Double the pressure at equal force? Halve the cylinder and the flow halves; pump kW stays the same but the machine shrinks. This is why pressure classes exist: 70, 160, 250, 350 bar standards.',
        'f' => 'P (kW) = p &middot; Q / (600 &middot; &eta;)',
        's' => 'Always factor efficiency: a real power pack converts ~85 % of shaft power into useful hydraulic power; the rest is already heat at the source.',
        'a' => ['Motor selection for every power pack.',
                'Quick feasibility checks: can this 5.5 kW motor run my cycle?'],
        'x' => 'Compute the drive kW of a Studio circuit from its gauge and flow readings, then check against the nominal motor — practice the estimate engineers do in their heads.'];
    $D[] = ['id' => 'hl-f-efficiency', 't' => 'Volumetric vs hydromechanical efficiency', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Leaking oil and rubbing metal: the two thieves described by two numbers.',
        'w' => 'Volumetric efficiency &eta;<sub>vol</sub> measures internal leakage (delivered vs theoretical flow); hydromechanical efficiency &eta;<sub>hm</sub> measures friction losses. Overall &eta; = &eta;<sub>vol</sub> &times; &eta;<sub>hm</sub>.',
        'h' => 'A worn pump typically loses &eta;<sub>vol</sub> first (more leakage) — but watch temperature: hot thin oil fakes wear by increasing leakage 2-3 %. Friction losses dominate at high pressure and low speed (stick-slip zone).',
        'f' => '&eta;<sub>vol</sub> = Q<sub>actual</sub> / (V<sub>g</sub> &middot; n); &eta; = &eta;<sub>vol</sub> &middot; &eta;<sub>hm</sub>',
        's' => 'Compare like-for-like: state pressure, speed and viscosity with every efficiency figure. A datasheet &eta; at 1450 rpm says little about your 600 rpm duty.',
        'a' => ['Pump health trending.', 'Energy balance of complete machines.'],
        'x' => 'Measure volumetric efficiency of a Studio pump at 50 and 200 bar; the droop is the leakage story in two points.'];
    $D[] = ['id' => 'hl-f-naturalfreq', 't' => 'Natural frequency of cylinder drives', 'lv' => 'advanced', 'min' => 6,
        'sm' => 'Oil is a spring: mass on that spring rings — and limits every control loop.',
        'w' => 'The compressible oil column between valve and piston plus the moved mass forms a spring-mass oscillator. Its natural frequency &omega;<sub>h</sub> caps the achievable speed of position and force control loops.',
        'h' => 'Short lines, rigid pipes, no trapped air, valve on the cylinder: every measure raises &omega;<sub>h</sub>. Mid-stroke with equal volumes is usually the worst case. Damping ratios of 0.05-0.15 are typical — the system loves to ring.',
        'f' => '&omega;<sub>h</sub> = &radic;(4 &middot; &beta; &middot; A&sup2; / (V &middot; m)) [rad/s]',
        's' => 'Check &omega;<sub>h</sub> before promising positioning accuracy. Below 5 Hz, expect visible settling oscillation on heavy tables.',
        'a' => ['Servo press and test-rig sizing.',
                'Diagnosing a hunting pressure loop.'],
        'x' => 'Step a heavy Studio cylinder and measure the ring frequency from the pressure trace; compare with the formula prediction.'];
    $D[] = ['id' => 'hl-f-orifice', 't' => 'The orifice law: what pressure drop really means', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Q follows root of &Delta;p: the quadratic heart of every throttle.',
        'w' => 'Flow through a sharp-edged restriction follows Q = c<sub>d</sub> &middot; A &middot; &radic;(2&Delta;p/&rho;). Doubling speed through the same orifice quadruples the pressure loss — the source of many surprised faces.',
        'h' => 'Blind (long) orifices behave more linearly (laminar) and are temperature-sensitive; sharp-edged ones are viscosity-robust but quadratic. Datasheet &Delta;p-Q curves tell you which physics you bought.',
        'f' => 'Q = c<sub>d</sub> &middot; A &middot; &radic;(2&Delta;p/&rho;)',
        's' => 'Reading a valve datasheet: nominal flow defined at some &Delta;p (often 5 or 10 bar per edge) — running it at higher &Delta;p flows actually more than nominal.',
        'a' => ['Sizing flow controls and choosing spool notches.',
                'Estimating line losses from one measured &Delta;p.'],
        'x' => 'Sweep speed against &Delta;p on a Studio throttle; fit the square-root curve and extract c<sub>d</sub> — reverse-engineering a real datasheet point.'];
    $D[] = ['id' => 'hl-f-iso4406', 't' => 'ISO 4406 cleanliness codes', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'Three numbers that decide whether servo valves live or die.',
        'w' => ' ISO 4406 codes report particle counts per ml at &gt; 4, &gt; 6 and &gt; 14 &micro;m(c), coded on a logarithmic scale (each step = doubling). Example 18/16/13: typical clean industrial oil.',
        'h' => 'Servo/proportional systems want 16/14/11 or better; standard gear-pump systems are content with 19/17/14. One code step better roughly doubles component life in contaminated-sensitive hardware.',
        's' => 'Sample from a turbulent return line, mid-stream, not from the tank bottom. Trend counts — a jump of two codes overnight means ingress, not dirtiness.',
        'a' => ['Oil analysis programs.', 'Acceptance of new or rebuilt systems (flush to class!).'],
        'x' => 'In the Studio tank lesson, set target cleanliness and match filter &beta;-ratios until the predicted class is met.'];
    $D[] = ['id' => 'hl-f-beta', 't' => 'Beta ratio: reading filter datasheets', 'lv' => 'intermediate', 'min' => 5,
        'sm' => '&beta;<sub>x</sub> = 200 means 99.5 % capture — learn the one number that matters.',
        'w' => 'The &beta;-ratio counts particles upstream vs downstream at a given size: &beta;<sub>10&micro;m(c)</sub> = 200 means only 1 in 200 of 10-&micro;m particles passes (99.5 % efficiency).',
        'h' => 'Old &quot;nominal 10 &micro;m&quot; claims mean almost nothing; absolute ratings with &beta; &ge; 200 under ISO 16889 multipass testing are the professional language. Watch the (c): calibration changed particle sizing standards.',
        's' => 'Choose by component sensitivity: servo valves 3-6 &micro;m, proportional 6-10, standard 10-25. Finer filter = more frequent changes; balance with off-line polishing loops.',
        'a' => ['Filter element selection and comparison.',
                'Writing purchasing specs a supplier cannot game.'],
        'x' => 'Compare a &beta;<sub>10</sub>=75 vs &beta;<sub>10</sub>=200 element for a proportional circuit: compute passing particle counts at the same ingress rate.'];
    $D[] = ['id' => 'hl-f-cavitation', 't' => 'Cavitation physics in pumps and valves', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Bubbles born in low pressure, murdered in high pressure — and the damage they leave.',
        'w' => 'When local pressure falls below the oil vapor/air-release pressure, cavities form; transported into pressure zones they implode with micro-jets exceeding 1000 bar locally, eroding metal grain by grain.',
        'h' => 'Pump-side cavitation sounds like gravel; valve-side (sharp metering edges at high &Delta;p) shows as erosion tracks downstream. Dissolved air worsens everything: aerated oil cavitates earlier.',
        's' => 'Defenses: short fat suction lines, flooded inlet if possible, oil temperature in the 40-50 &deg;C window, and keeping metering-edge &Delta;p sane on gaseous duty.',
        'a' => ['Troubleshooting noisy pumps.', 'Designing high-&Delta;p throttles (use staged pressure drop).'],
        'x' => 'Starve a Studio pump suction and listen to the simulated noise flag while volumetric efficiency collapses — then fix the line.'];
    $D[] = ['id' => 'hl-f-viscosity', 't' => 'Viscosity, VI and the optimum window', 'lv' => 'intermediate', 'min' => 5,
        'sm' => '16-36 cSt optimum, 1000 cSt start limit, 10 cSt danger — viscosity rules everything.',
        'w' => 'Viscosity decides film thickness (lubrication) and leakage (efficiency). ISO VG grades name cSt at 40 &deg;C; the viscosity index VI describes how flat the curve stays across temperature.',
        'h' => 'Cold morning oil at 800 cSt cavitates pumps; hot afternoon oil at 12 cSt weeps past every clearance and lubricates poorly. High-VI oils (HVLP) flatten the swing for outdoor machines.',
        'f' => 'Optimum operating viscosity: 16-36 cSt; limit start &asymp; 1000, minimum &asymp; 10 cSt',
        's' => 'Choose VG class by your working temperature window, not by habit: many plants run VG 46 where VG 32 would cut energy losses measurably.',
        'a' => ['Oil selection for new machines.', 'Winterizing mobile equipment.'],
        'x' => 'Run the same Studio cycle at 20 and 55 &deg;C: watch leakage flow and bearing friction trade places.'];
    $D[] = ['id' => 'hl-f-fluids', 't' => 'Hydraulic fluids: HLP, HVLP, HFC, bio', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Mineral, synthetic, water-based, bio: each fluid rewrites seal and fire rules.',
        'w' => 'HLP (mineral with additives) is default. HVLP adds viscosity-index improvers. HFC (water-glycol) and HFD (synthetic ester) serve fire-risk zones; HEES/HETG are rapidly biodegradable for environmental sites.',
        'h' => 'Fire-resistant fluids penalize lubrication (HFC: derate pumps 20-30 %) or attack standard seals and paints (HFD: FKM seals, epoxy paint). Bio fluids oxidize faster — temperature discipline and shorter change intervals.',
        's' => 'Never mix fluid families: residues form gels. Conversion needs flushing procedures approved by both fluid and component makers.',
        'a' => ['Steel mills and foundries (fire).', 'Forestry and water-protection zones (bio).'],
        'x' => 'Given three sites (foundry, forest crane, workshop press), choose the fluid family and defend the derating consequences.'];
    $D[] = ['id' => 'hl-f-seals', 't' => 'Sealing principles and the extrusion gap', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Seals work by being squeezed into the gap — pressure feeds the seal or eats it.',
        'w' => 'Elastomer seals energize under pressure: lip seals open toward the pressure, O-rings deform into the extrusion gap. Above the gap tolerance for a given pressure, rubber extrudes and the seal is nibbled away.',
        'h' => 'Back-up rings close the extrusion gap for high pressure; PTFE step seals reduce friction and stick-slip on servo cylinders. Direction matters: a rod seal installed backwards becomes a pump.',
        's' => 'Check surface finish (Ra 0.1-0.4 &micro;m rods), hardness and gap against the pressure class in the seal catalog. Temperatures kill: NBR past 100 &deg;C, FKM for heat, PU for abrasion.',
        'a' => ['Cylinder repairs done right.', 'Specifying cylinders for 400 bar duty.'],
        'x' => 'In the Studio cylinder explorer, compare seal stack choices between a 160 bar workshop ram and a 400 bar press cylinder.'];
    $D[] = ['id' => 'hl-f-gaslaw', 't' => 'Gas laws for accumulators', 'lv' => 'intermediate', 'min' => 6,
        'sm' => 'Isothermal for storage, adiabatic for shocks: the exponent decides the volume.',
        'w' => 'Accumulator gas follows p &middot; V<sup>n</sup> = const. Slow charge/discharge (minutes): n &asymp; 1, isothermal. Fast events (seconds): n &asymp; 1.4 for nitrogen, adiabatic. Usable volume differs by 30 % between the two.',
        'h' => 'Precharge p<sub>0</sub> = 0.85-0.9 &times; minimum working pressure keeps some oil reserve; above that the bladder hits the poppet and flow dies abruptly. Too low precharge slams the bladder against the shell — early failure.',
        'f' => 'V<sub>usable</sub> = V<sub>0</sub> &middot; p<sub>0</sub> &middot; [(1/p<sub>2</sub>)<sup>1/n</sup> - (1/p<sub>3</sub>)<sup>1/n</sup>]',
        's' => 'Verify precharge annually with the machine depressurized (charging kit + N2 bottle, NEVER oxygen). Temperature swings change p<sub>0</sub> — recheck seasonally on outdoor machines.',
        'a' => ['Sizing standby and emergency accumulators.', 'Pulsation damping at piston pumps.'],
        'x' => 'Run the Studio accumulator charge curve; switch n between 1.0 and 1.4 and watch usable volume change by a third.'];
    $D[] = ['id' => 'hl-f-bulkmodulus', 't' => 'Oil compressibility: the hydraulic spring', 'lv' => 'advanced', 'min' => 5,
        'sm' => '7000-14000 bar bulk modulus: stiff, but a spring nonetheless.',
        'w' => 'Mineral oil compresses roughly 0.7 % per 100 bar (bulk modulus &beta; &asymp; 14000 bar); with 1 % entrained air the effective value collapses to a third or less. Every trapped volume is a spring — useful for shock absorption, troublesome for control.',
        'h' => 'Effective stiffness of a cylinder spring: C = &beta; &middot; A&sup2; / V. Big volumes (long hoses! accumulator-side lines) soften the axis and lower the natural frequency — the main reason servos hate hoses.',
        'f' => '&beta;<sub>eff</sub> &asymp; &beta; / (1 + air fraction &epsilon; &middot; p<sub>a</sub>/p)',
        's' => 'Bleed air religiously for stiff axes; hard-pipe servo lines; keep valve-to-actuator volume minimal.',
        'a' => ['Position control design.', 'Shock-absorber and suspension calculations.'],
        'x' => 'Measure the spring: pressurize a capped Studio cylinder, release a micro-volume and compute &beta; from &Delta;p/&Delta;V.'];
    $D[] = ['id' => 'hl-f-buckling', 't' => 'Euler buckling of piston rods', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Push force is limited by a noodle: long thin rods bend before they reach nominal force.',
        'w' => 'A pushing cylinder is a column. Buckling load falls with the square of free length; mounting (-guided vs free end) changes the effective length factor from 0.5 to 2.',
        'h' => 'Manufacturer tables give permissible push force vs stroke per mounting style. Stop tubes increase the effective rod diameter length inside the cylinder to reduce bearing span issues, extending allowable loads on long strokes.',
        'f' => 'F<sub>crit</sub> = &pi;&sup2;EI / (K &middot; L)&sup2;',
        's' => 'Check buckling whenever strokes exceed ~10 &times; rod diameter in push duty. Horizontal mounting with sagging rods worsens it — mid-supports help.',
        'a' => ['Long-stroke press feeders.', 'Selection of telescopic alternatives.'],
        'x' => 'Extend a long-rod Studio cylinder against rising force and read the buckling warning; add a stop tube and re-run.'];
    $D[] = ['id' => 'hl-f-tank', 't' => 'Tank design: volume, baffles, zones', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'The tank is a process device: settling, de-aeration, cooling — not a bucket.',
        'w' => 'Rules of thumb: stationary tank volume 2-4 &times; pump flow per minute; mobile 1-1.5 &times;. Return oil enters diffused below level opposite the suction, separated by a baffle that forces a calm settling path.',
        'h' => 'Residence time releases air and drops particles and water. Suction zone sits lowest and calmest; return diffuser slows jets that would stir sediment. Breather sizing must cover maximum level-change air flow without pressurizing the tank.',
        's' => 'Level switch + temperature sensor + breather filter are the minimum instrumentation. Sloped bottom with drain: water collects first, drain it weekly on humid sites.',
        'a' => ['Power pack design.', 'Troubleshooting foam and water emulsion complaints.'],
        'x' => 'Inspect the Studio tank module: identify baffle, diffuser and drain on the cut-away, then size a tank for a 60 l/min press.'];
    $D[] = ['id' => 'hl-f-hosedesign', 't' => 'Hose assembly rules that prevent failures', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'Bend radius, torsion, length margin: the STAAMP and routing discipline.',
        'w' => 'Hoses fail from abuse more than age: bend below minimum radius, twist under pressure, rub against steel, stretch under shrinkage (-4 % at pressure!). STAAMP: Size, Temperature, Application, Media, Pressure.',
        'h' => 'Pressure shrinks and stiffens hoses: leave 4-7 % slack and machine-motion margin. Route so flexing happens in one plane only; clamp where rubbing is unavoidable; never mix bend with torsion (the deadliest combination).',
        's' => 'Impulse rating matters: 4-spiral for shock duty, braided for gentle static. Date-code assemblies; replace by condition with a documented interval.',
        'a' => ['Every maintenance plan.', 'Mobile machine layout reviews.'],
        'x' => 'Review a Studio machine photo set: mark the three routing crimes and prescribe the fixes.'];
    $D[] = ['id' => 'hl-f-heat', 't' => 'Heat budget: where losses become degrees', 'lv' => 'intermediate', 'min' => 6,
        'sm' => 'Steady-state temperature = losses vs dissipation; compute it before summer.',
        'w' => 'All hydraulic losses become heat. Steady state balances loss power against dissipation through tank walls (&asymp; 0.015 kW/m&sup2;K &times; surface &times; &Delta;T), components, lines and the cooler.',
        'h' => 'Estimate losses: standby unload 2-3 % of drive power continuously; throttling &Delta;p &times; Q / 600; leakage flows at pressure; then check against cooler capacity at worst ambient (solar load for mobile!).',
        'f' => '&Delta;T<sub>oil-amb</sub> = P<sub>loss</sub> / (U &middot; A<sub>tank</sub> + cooler capacity curve)',
        's' => 'Oil ages per Arrhenius: every +10 K above 60 &deg;C halves oxidation life. Alarm at 70, trip at 80 &deg;C as common practice.',
        'a' => ['Cooler sizing verification.', 'Explaining why a machine overheats only in August.'],
        'x' => 'Run a Studio cycle, read oil temperature slope before the cooler engages, and back-calculate the loss kW — textbook thermography by simulation.'];
    $D[] = ['id' => 'hl-f-pumpselect', 't' => 'Pump selection decision matrix', 'lv' => 'intermediate', 'min' => 6,
        'sm' => 'Gear, vane, piston, screw: duty, pressure, noise and budget in one comparison.',
        'w' => 'Gear pumps: cheap, robust, fixed, to 250-280 bar. Vane: quiet, medium pressure (&le; 210 bar), variable versions exist. Axial piston: 350-450 bar, variable everything, expensive, dirt-sensitive. Screw: silent, for lubrication duty and low pulsation.',
        'h' => 'Selection flow: required pressure class excludes types; variable vs fixed by duty cycle (intermittent high force = variable earns money); noise limits (labs, theaters) point to vane/screw; dirty environments forgive gear pumps most.',
        's' => 'Do not oversize displacement: a 100 cm&sup3; pump at 30 % duty runs out of its efficient window and wears unevenly. Match displacement to average demand with margin.',
        'a' => ['Power-pack conceptual design.', 'Debates in front of customers (bring the matrix).'],
        'x' => 'Given three Studio scenarios (quiet lab press, excavator, cheap log splitter), pick the pump and write the rejection reason for the runners-up.'];
    $D[] = ['id' => 'hl-f-failures', 't' => 'Reading component failure modes', 'lv' => 'advanced', 'min' => 6,
        'sm' => 'Scoring, pitting, spalling, cavitation mapping — autopsy of pumps and motors.',
        'w' => 'Failed components talk: circumferential scratches = abrasive particles; pitting clusters = cavitation; smeared metal = lubrication breakdown; fatigue spalling = overload cycles; polymer deposits = varnish from hot oxidized oil.',
        'h' => 'Cut open (or inspect ports of) the dead pump before ordering its replacement: the failure signature tells whether the new one will die the same way. Filter element inspection (pleat contents under bright light) completes the picture.',
        's' => 'Photograph and log every autopsy; correlate with oil analysis trends. Warranty discussions become short when the evidence is a picture.',
        'a' => ['Root-cause analysis after catastrophic failures.', 'Building a site failure library.'],
        'x' => 'Match six failure photos in the Studio reference set to their root causes; then trace which Studio gauge symptom preceded each.'];
    $D[] = ['id' => 'hl-f-maintenance', 't' => 'Maintenance schedule done professionally', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'Weekly eyes, monthly senses, quarterly lab: oil tells the truth on a schedule.',
        'w' => 'Weekly: level, leaks, temperature, noise. Monthly: breather, cooler fins, hose condition, accumulator precharge plausibility. Quarterly/500 h: oil sample (particles, water, viscosity, TAN), filter indicator review. Annual: precharge check, relief re-calibration, pump flow test.',
        'h' => 'Oil analysis trending beats reactive change: viscosity drift, water ppm, ISO code and TAN curves predict problems months out. Change by condition, not calendar — economics and uptime both win.',
        's' => 'One responsible person owns the fluid; labels on filters with change dates; spare filter elements on site (a clogged bypass weekend is avoidable).',
        'a' => ['Plant reliability programs.', 'Warranty compliance documentation.'],
        'x' => 'Set the Studio simulation to accelerated wear; schedule interventions from the trend curves and watch unplanned stops vanish.'];
    $D[] = ['id' => 'hl-f-test-bench', 't' => 'Acceptance readings worth witnessing', 'lv' => 'advanced', 'min' => 5,
        'sm' => 'Which numbers belong in the FAT/SAT protocol — and their classes of gauge.',
        'w' => 'Record: motor current vs relief pressure curve, pump delivery at 3 pressures, cooler in/out &Delta;T over 30 min at worst-duty cycle, all valve settings against a class-1 reference gauge, response times of pressure switches.',
        'h' => 'Instrument classes matter: shop gauges (&plusmn;2.5 %) cannot verify a relief set within &plusmn;5 bar at 250 bar — use a class 0.6 test gauge or digital sensor for witnessed points.',
        's' => 'Freeze the protocol template: machine ID, oil type, temperature window, gauge IDs, signatures. Deviations get numbers, not adjectives.',
        'a' => ['Factory and site acceptance tests.', 'Dispute resolution with suppliers.'],
        'x' => 'Draft the SAT sheet for a Studio power pack: ten lines, each with a measured value and tolerance — professional documentation muscle.'];
    $D[] = ['id' => 'hl-f-burst-pressure', 't' => 'Safety factors: working vs burst pressure', 'lv' => 'beginner', 'min' => 4,
        'sm' => '4:1 for hoses, 4:1 for tubes by rule — know the numbers before signing.',
        'w' => 'Components carry rated (working) pressure and minimum burst pressure. Standards demand ratios: hoses and rigid lines commonly 4:1 against maximum working pressure including peaks; valves and cylinders per their ISO standards.',
        'h' => 'Pressure PEAKS count, not averages: recorded spikes of relief overshoot belong in the selection math. A 100-bar-rms system with 350 bar hammer peaks is a 350 bar selection exercise.',
        's' => 'Never uprate a system by tightening the relief without rechecking every downstream rating. Document peak measurements with fast recorders — slow gauges lie.',
        'a' => ['System uprates and retrofits.', 'Insurance investigations after hose bursts.'],
        'x' => 'Record a Studio pressure spike at valve slam; identify which component rating the spike violated.'];
    $D[] = ['id' => 'hl-f-noise-safety', 't' => 'Injection injuries and stored energy', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'A pinhole leak injects oil like a syringe — the injury you must fear most.',
        'w' => 'Oil jets from pinhole leaks penetrate skin at glove-level pressures and cause tissue necrosis hours later — surgical emergency, not a plaster job. Never search leaks with hands; use cardboard.',
        'h' => 'Stored energy: accumulators and suspended loads keep machines dangerous with the motor off. LOTO procedure: isolate, dump accumulators via the manual valve, verify zero energy on gauges, mechanically support loads.',
        's' => 'Personal protective: glasses always, gloves for oil work, faceshield for suspected leaks. Mark stored-energy zones on the machine with the standardized label.',
        'a' => ['Every maintenance task — the non-negotiable brief.', 'Safety induction for apprentices.'],
        'x' => 'Walk the Studio safety module: identify on the press schematic where energy remains after stop, and plan the dump sequence.'];
    $D[] = ['id' => 'hl-f-decision-var-pump', 't' => 'Fixed vs variable pump: the economics', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'When the expensive pump is the cheap machine.',
        'w' => 'Fixed pumps cost little but burn the same kW regardless of demand (heat at the relief). Variable pumps cost 3-5 &times; more but deliver on demand. The decision variable is the duty profile: hours per year at partial demand.',
        'h' => 'Payback math: saved kW = idle-ish pressure &times; surplus flow averaged over the year. Intermittent cycles (presses, clamps) repay variable displacement in 1-3 years; continuous full-load machines rarely.',
        'f' => 'E<sub>saved</sub> (kWh/a) = &Eta; (&Delta;p<sub>idle</sub> &middot; Q<sub>surplus</sub>/600) &middot; hours',
        's' => 'Variable pumps add control complexity (compensators, load-sense) — budget commissioning skill and dirt sensitivity into the decision.',
        'a' => ['Plant energy programs.', 'Specifying new power packs.'],
        'x' => 'Use the Studio efficiency report across a recorded shift to compute real payback for a variable-pump retrofit — evidence-based engineering.'];
    $D[] = ['id' => 'hl-f-intensification-map', 't' => 'Mapping intensification pockets systematically', 'lv' => 'advanced', 'min' => 5,
        'sm' => 'Before the hose bursts: enumerate every trapped volume and compute its worst pressure.',
        'w' => 'For every line section that can be closed at both ends, list the amplifiers connected: differential cylinder ratio, thermal expansion, external loads. Compute worst-case pressure per pocket and rate the segment accordingly.',
        'h' => 'Worksheet method: pocket, closing scenario, area ratio or &Delta;T, computed peak, relief provision, component ratings. Auditors increasingly ask for exactly this table on existing machines.',
        's' => 'Do not forget pilot lines behind check valves — the classic unnoticed pocket. Solve with thermal valves small and near the pocket.',
        'a' => ['Design reviews and CE risk assessments.', 'Post-incident machine audits.'],
        'x' => 'Finish the pocket table for a Studio meter-out example and place the two missing thermal valves on the schematic.'];
    $D[] = ['id' => 'hl-f-symbols', 't' => 'ISO 1219 symbols fluency (capstone)', 'lv' => 'beginner', 'min' => 6,
        'sm' => 'Read any schematic like a sentence: energy, control, actuation — in that order.',
        'w' => 'Method: find the energy source (circle with triangle), trace P to the consumers; identify each valve envelope count (positions) and port count (ways); identify actuation arrows (solenoid coil, pilot dash, spring); finish at the actuators and back through T.',
        'h' => 'Boxes = discrete positions; one box always drawn in rest state; proportional valves get parallel lines above/below; pilot lines dashed, drain dotted, enclosure boxes grouped by physical units. Flow direction arrows filled (hydraulic) or hollow (pneumatic).',
        's' => 'Practice with five real schematics from different industries — symbol dialects exist (detailedd vs simplified pumps), method stays.',
        'a' => ['Every troubleshooting session starts here.', 'Interview skill: reading a schematic live.'],
        'x' => 'Complete the Studio symbol quiz track until 100 %, then narrate a full schematic aloud — fluency proven.'];
    $D[] = ['id' => 'hl-f-capstone-build', 't' => 'Capstone build: drill press cell from scratch', 'lv' => 'advanced', 'min' => 10,
        'sm' => 'Clamp, drill, retract, eject — one circuit, every lesson applied.',
        'w' => 'Specification: clamp at 60 bar, drill feed 12 mm/s at up to 140 bar, fast approach 60 mm/s, eject on return. You design: cylinders &phi; and margins, pump and motor, valve selection (sequence + reducing + meter-out), relief at 160, cooling check, and the schematic.',
        'h' => 'Expected moves: sequence valve for clamp-before-feed; reducing valve for clamp force limit; regeneration if takt demands; meter-out on feed for finish quality; test points at four stations; settings list with witnessed values.',
        's' => 'Deliverables as a professional dossier: schematic, sizing calculations, settings list, bill of materials with ratings, and the sim-derived temperature estimate.',
        'a' => ['Certification-style project work.', 'Portfolio piece for job interviews.'],
        'x' => 'Build it in the Studio end to end, run the cycle with the report on, and export the schematic for your records.'];
    return $D;
}

/* ------------------------------------------------------------------ */
/* PNEUMATICS — elements: supply & treatment (library part 4)          */
/* ------------------------------------------------------------------ */
function rgz_ll_pne_elements() {
    $D = [];
    $D[] = ['id' => 'pl-piston-compressor', 't' => 'Piston compressor', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'The workshop classic: cheap, tough, intermittent service to 8-12 bar.',
        'w' => 'A crank-driven piston compresses air in one or two stages into a receiver. Single-stage reaches &asymp; 8-10 bar, two-stage with intercooling 12-15 bar. Duty cycle is limited (typically 50-60 %) — it is an intermittent machine.',
        'h' => 'Intake stroke draws filtered air through the suction valve; compression stroke pushes it through the pressure valve into the aftercooler/receiver. The pressure switch cycles the motor between upper and lower setpoints.',
        's' => 'Size by free air delivery (FAD) in l/min or Nl/min at working pressure, not by motor kW. Oil-lubricated units last longer; oil-free are mandatory for food/pharma air.',
        'a' => ['Workshop air networks with intermittent demand.',
                'Standalone machines where a small local compressor wins over line air.'],
        'x' => 'In the Studio, dimension a receiver for a piston unit: demand peaks 400 Nl/min for 3 s every 30 s — choose the tank so the compressor rests.'];
    $D[] = ['id' => 'pl-screw-compressor', 't' => 'Screw compressor', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Continuous flow for plants: quiet, efficient, 100 % duty.',
        'w' => 'Two meshing rotors (an oil-flooded male/female pair) compress air progressively along their axis. No inlet/outlet valves, no pulsation: ideal for continuous baseload air.',
        'h' => 'Capacity control via inlet throttle, blow-off, or speed control (VSD). Oil is injected for sealing and cooling, then separated to &lt; 3 ppm; dryers and filters downstream polish to the required class.',
        's' => 'Choose VSD when the demand profile varies widely — fixed-speed idling wastes 20-30 % of rated power blowing off. Heat recovery (70-90 % of input power available as warm water) often pays for itself.',
        'a' => ['Central compressed-air stations for production plants.',
                'Any network consuming more than ~1000 Nl/min on average.'],
        'x' => 'Compare kWh per Nm&sup3; for fixed-speed vs VSD at your simulated demand curve — energy audits start with this chart.'];
    $D[] = ['id' => 'pl-receiver', 't' => 'Air receiver (compressed-air tank)', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'Buffer, cooler, water separator and pulsation damper in one steel bottle.',
        'w' => 'The receiver stores compressed air to bridge demand peaks, lets the compressor run longer efficient cycles, cools the air (condensing water out first, where it belongs) and damps pulsation from piston compressors.',
        'h' => 'Rule of thumb: volume (l) &asymp; compressor delivery (l/min) for piston units; smaller for screw compressors. Peaks size it: V = &Delta;p window math over the peak duration.',
        'f' => 'V (l) &ge; Q<sub>peak</sub>&middot;t / (p<sub>max</sub> - p<sub>min</sub>) [with p in bar absolute]',
        's' => 'Drain daily (manual) or fit an automatic drain; corroding receivers are bombs — periodic inspection per local pressure-vessel rules with wall-thickness testing.',
        'a' => ['Every plant air station.', 'Local reserve tanks near big intermittent consumers (blast gates, large cylinders).'],
        'x' => 'Simulate demand peaks in the Studio and watch line pressure sag with and without a local receiver.'];
    $D[] = ['id' => 'pl-water-separator', 't' => 'Cyclone water separator', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'First defense: spin the air, throw the water at the wall, drain it away.',
        'w' => 'Wet compressed air enters tangentially; centrifugal force hurls droplets to the wall where they run down into the quiet zone of the bowl, removed by a float drain.',
        'h' => 'Removes bulk liquid (not vapor!) — typically 99 % of droplets &gt; 10 &micro;m. Sits directly after the aftercooler and before filters and dryers.',
        's' => 'Works poorly at low velocity: oversized separators lose spin. Keep the drain functional — a blocked drain refloods the line.',
        'a' => ['Every compressor outlet and branch take-off.',
                'Protection of fine coalescing filters from flooding.'],
        'x' => 'In the Studio service-unit lesson, place the separator wrongly after the dryer and explain why the efficiency math fails.'];
    $D[] = ['id' => 'pl-filter-coalescing', 't' => 'Coalescing micro-filter', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Borosilicate fibers catch aerosols; 0.01 &micro;m and 0.003 mg/m&sup3; oil claims, verified by ISO 8573.',
        'w' => 'Micro-glass fiber beds force sub-micron oil and water aerosols to collide, coalesce into drops and drain off the element. Grades: 1 &micro;m / 0.1 mg/m&sup3; (pre), 0.01 &micro;m / 0.01 mg/m&sup3; (micro), plus activated-carbon for vapor.',
        'h' => 'Depth filtration with Brownian motion capture: efficiency rises as fibers wet. &Delta;p grows with loading — change elements when &Delta;p passes 0.5 bar (energy cost of a dirty filter exceeds its price within weeks).',
        's' => 'Always in series coarse to fine after the dryer. A carbon stage does not replace the micro-filter — vapor removal needs its own cartridge.',
        'a' => ['Paint spraying, laser cutting purge gas, instrument air.',
                'Food-contact air requiring ISO 8573-1 class 1.2.1.'],
        'x' => 'Build the Studio treatment chain in the wrong order (micro before dryer) and explain the flooded-element failure.'];
    $D[] = ['id' => 'pl-dryer-refrigeration', 't' => 'Refrigeration dryer', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Cool the air to +3 &deg;C dew point: the plant-standard dryer for indoor networks.',
        'w' => 'A refrigeration circuit chills compressed air to a pressure dew point of +3 &deg;C; vapor condenses and is removed by the integrated separator/drain.',
        'h' => 'Remember: dew point applies AT LINE PRESSURE. +3 &deg;C PDP prevents condensation in any indoor pipe that stays warmer than 3 &deg;C — but outdoor winter lines still condense.',
        's' => 'Size for worst summer: inlet temperature, pressure and ambient all reduce capacity. An inlet coalescing filter protects the heat exchanger from oil fouling.',
        'a' => ['General plant air (ISO 8573-1 water class 4).',
                'Feed dryer before adsorption units is wrong — they go AFTER if both are used.'],
        'x' => 'Given 35 &deg;C inlet air at 90 % humidity, 7 bar: calculate condensate liters per 8 h shift in the Studio weather scenario.'];
    $D[] = ['id' => 'pl-dryer-adsorption', 't' => 'Adsorption (desiccant) dryer', 'lv' => 'intermediate', 'min' => 5,
        'sm' => '-40 &deg;C or -70 &deg;C dew point for outdoor lines, instruments and processes.',
        'w' => 'Twin towers filled with desiccant (alumina/molecular sieve) alternate between drying and regeneration. Regeneration wastes 15-20 % purge air (heatless type) or uses heater/blower energy.',
        'h' => 'Water vapor adheres physically to the desiccant surface; when the tower saturates, valves swap the flow and a dry purge stream strips the moisture to atmosphere.',
        's' => 'Oil destroys desiccant permanently — pre-filter to 0.01 mg/m&sup3; always. Undersized purge = creeping dew point; monitor with an online dew-point meter.',
        'a' => ['Outdoor installations in cold climates.',
                'Instrument and process air with strict dryness specs.'],
        'x' => 'Decide line by line which Studio machine needs -40 &deg;C and which is fine at +3 — over-drying is a purge-air energy bill.'];
    $D[] = ['id' => 'pl-membrane-dryer', 't' => 'Membrane dryer', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'Hollow fibers breathe water vapor out: compact, silent, no power — for small flows.',
        'w' => 'Water vapor permeates selectively through hollow fiber membranes to the outside, where a dry purge stream (~15-20 % of flow) carries it away. Point-of-use drying to -20 &deg;C PDP for small consumers.',
        'h' => 'Flow capacity is small (&lt; ~1000 Nl/min) and purge loss is permanent — a continuous consumption in your compressed-air balance.',
        's' => 'Requires an upstream 0.01 &micro;m filter (oil coats the membrane irreversibly). Place directly at the consumer.',
        'a' => ['Instrument cabinets and analytic devices.',
                'Remote cabinets where no power is available for a dryer.'],
        'x' => 'Add the purge loss of three membrane dryers to the Studio plant balance — the compressor notice it even if you do not.'];
    $D[] = ['id' => 'pl-frl', 't' => 'Service unit: filter, regulator, lubricator (FRL)', 'lv' => 'beginner', 'min' => 6,
        'sm' => 'The classic triplet at every machine inlet: clean it, set it, (rarely) oil it.',
        'w' => 'The air preparation unit conditions plant air for the machine: filter (5-40 &micro;m with water drain), pressure regulator (downstream pressure kept constant), optional lubricator (oil fog for old-style cylinders and tools).',
        'h' => 'Order is fixed: filter first (protect everything), regulator second (sets working pressure), lubricator last (oil would be filtered out upstream). Modern practice: skip the lubricator and use lifetime-lubricated cylinders; if used, never starve it and never fertilize tools with stainless internals.',
        's' => 'Bowl: polycarbonate needs guards in solvent atmospheres (metal bowl alternative). Set regulator under flow: static settings read 0.5-1 bar high (droop).',
        'a' => ['Every pneumatic machine inlet.',
                'Retrofitting unlubricated valves behind old lubricated lines: never — the oil history sticks.'],
        'x' => 'Assemble the Studio FRL backwards and list each downstream failure: learn the order by breaking it.'];
    $D[] = ['id' => 'pl-filter-regulator', 't' => 'Filter-regulator (piggyback)', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'Filter + regulator in one body: the modern default service module.',
        'w' => 'A compact combination: 5 &micro;m filter with auto or semi-auto drain plus relieving regulator with gauge port. Saves space and a joint — every joint is a future leak.',
        'h' => 'Relieving regulators vent downstream overpressure to atmosphere — a safety property: blockage does not trap pressure behind the consumer.',
        's' => 'Pick drain type by site: auto-drain where bowls fill unseen; semi-auto for maintenance-friendly boards. Gauge placement readable from the operator stance.',
        'a' => ['Machine-mounted preparation panels.',
                'Zone regulators creating different pressure levels per branch.'],
        'x' => 'In the Studio, set the zone regulator to 4 bar while the header runs 7 and watch actuator forces scale exactly with area &times; 4.'];
    $D[] = ['id' => 'pl-precision-regulator', 't' => 'Precision pressure regulator', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'Repeatability to millibars: for tensioning, balancing and lab air.',
        'w' => 'High-gain pilot-operated regulators hold set pressure within &plusmn;0.5 % with minimal droop, using a balanced poppet and sensitive diaphragm stacks.',
        'h' => 'Standard regulators droop 0.5-1 bar over the flow range; precision units hold their setpoint thanks to the amplified control loop and constant bleed design.',
        's' => 'Air consumption note: constant-bleed types consume ~2-6 Nl/min continuously. Keep inlet air clean (5 &micro;m) or the tiny nozzles foul.',
        'a' => ['Web tension control, counterbalance of robot arms.',
                'Calibration benches and leak-test stations.'],
        'x' => 'Plot droop curves of standard vs precision regulators in the Studio flow sweep — quantify what you pay for.'];
    $D[] = ['id' => 'pl-shutoff-slowstart', 't' => '3/2 shut-off valve with soft-start', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Pressurize gently: cylinders glide home instead of slamming at power-up.',
        'w' => 'At machine start the soft-start valve restricts filling until downstream pressure reaches ~50 % of supply; then it snaps fully open. On stop, the 3/2 quickly exhausts the machine.',
        'h' => 'Slow pressurization strokes all cylinders to their rest positions gently and predictably; the snap-through ensures full dynamics after the ramp. Adjustable needle sets fill time.',
        's' => 'Combine with the emergency-stop dump function in safety circuits. Note: soft-start is NOT a safety component by itself — the exhaust function is.',
        'a' => ['Every machine start after E-stop or shift start.',
                'Protection of tooling against unpredictable first strokes.'],
        'x' => 'Power up a Studio machine with and without soft-start and compare rod velocities during the first second — the loudest argument you can measure.'];
    $D[] = ['id' => 'pl-dump-valve', 't' => 'Safety exhaust (dump) valve', 'lv' => 'advanced', 'min' => 5,
        'sm' => 'Category 0 stop for pneumatics: remove the energy, monitored.',
        'w' => 'A 3/2 valve (often redundant, monitored) on the machine inlet exhausts all downstream air when the safety chain opens. Monitored versions feed spool position back to the safety relay for fault detection (ISO 13849 channels).',
        'h' => 'Exhaust capacity must depressurize the hazardous volume within the risk-assessment time; check Cv of the exhaust path, not just the inlet path. Soft-start + dump in one block is the modern integrated solution.',
        's' => 'Redundant + monitored for PL d/e; single valve acceptable only for lower categories. Verify exhaust time during commissioning — compute from volume and Cv if in doubt.',
        'a' => ['Robot cells and presses with pneumatic actuators in the danger zone.',
                'Machines whose risk assessment says: safe state = no pressure.'],
        'x' => 'Trigger the Studio E-stop with a raised load: watch the dump behavior and argue whether the mechanical rod lock must engage first.'];
    $D[] = ['id' => 'pl-lubricator', 't' => 'Oil-fog lubricator: when and when never', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'Legacy air tools love it; modern cylinders mostly hate needing it.',
        'w' => 'The lubricator meters oil drops into an air stream, creating a fog that coats downstream components. Essential for air motors, impact wrenches and older drill units.',
        'h' => 'Once used, always used: oil washes out factory grease, so removing the lubricator later starves components. Fog travels maybe 5-8 m and does not climb vertical lines — local lubricators for distant points.',
        's' => 'Modern practice: lifetime-lubricated valves/cylinders, no lubricator, exhaust air free of oil mist (workplace hygiene!). For tools: precision micro-fog units at the drop line.',
        'a' => ['Air tool stations in assembly lines.', 'Legacy machines grandfathered into service.'],
        'x' => 'Compare the Studio maintenance intervals of a lubricated vs lifetime-lubricated cylinder bank and plan the plant standard.'];
    $D[] = ['id' => 'pl-check-choke-silencer-supply', 't' => 'Manual drain and condensate management', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'Water always wins unless someone drains it: design the low points.',
        'w' => 'Condensate collects at every low point: receivers, dead legs, filter bowls, ring-main drops. Automatic float drains, timed solenoid drains or level-sensing zero-loss drains remove it without operator memory.',
        'h' => 'Timed drains blast expensive compressed air to atmosphere (2 s open every minute behaves like a continuous leak); level-controlled electronic drains open only when full — the small cost that pays back in compressor kWh.',
        's' => 'Route condensate through an oil-water separator before the sewer: 95 % of condensate from lubricated compressors is legally waste oil mixture.',
        'a' => ['Plant air systems of every size.', 'Outdoor installations with frost risk (heated drains).'],
        'x' => 'Add the drain losses of the whole Studio plant to the energy report and justify one zero-loss drain retrofit.'];
    $D[] = ['id' => 'pl-iso8573', 't' => 'ISO 8573-1 air quality classes', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Particles, water, oil: three numbers name your air — e.g. class 2.4.2.',
        'w' => 'The standard grades solids (1-7 by particle concentration), humidity (1-7 by pressure dew point) and oil (1-5 by mg/m&sup3;). Spec sheets list machine requirements in exactly this code.',
        'h' => 'General machinery: 2.4.2 is typical. Paint/food: 1.2.1 or better. Instrument air outdoors: water class 3 (-20 &deg;C PDP) at least. Class selection drives the entire treatment chain and its energy cost.',
        's' => 'Specifying better than needed costs purge air and filters forever; specifying worse costs downtime. Write the class into the machine requirement document — suppliers cannot argue with standards.',
        'a' => ['Tender documents and acceptance tests.',
                'Design of treatment chains (this course uses it everywhere).'],
        'x' => 'Assign ISO classes to the three Studio example machines and derive the exact filter/dryer chain for each.'];
    $D[] = ['id' => 'pl-header-layout', 't' => 'Air distribution: ring main and drops', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Rings beat trees: balance pressure by giving air two roads to every machine.',
        'w' => 'A closed ring main equalizes pressure across the plant (vs tree layout where the last consumer starves). Drops to machines come from the TOP of the main (water runs down!), with a shutoff and a drain leg pointing down.',
        'h' => 'Pipe sizing by velocity: mains 6-9 m/s, drops 10-15 m/s acceptable. Slopes of 1-2 % toward drain points. Every dead leg collects condensate: eliminate or drain it.',
        's' => 'Material choice: aluminum/stainless modular for clean air and easy change; galvanized steel economically; avoid plastic beyond point-of-use ratings. Pressure drop audit: &le; 0.3 bar main, &le; 0.6 bar total.',
        'a' => ['New plant air networks.', 'Diagnosis of the famous end-of-line pressure complaint.'],
        'x' => 'Given the Studio plant map, convert a tree to a ring and watch the end-machines recover 0.4 bar at peak demand.'];
    return $D;
}

function rgz_ll_pne_valves() {
    $D = [];
    $D[] = ['id' => 'pl-v-32-nc', 't' => '3/2-way valve, normally closed', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'The basic switching element: at rest the consumer is vented, actuated it is pressurized.',
        'w' => 'Two positions, three ports (1 supply, 2 output, 3 exhaust). At rest (NC) port 2 is connected to 3 — the cylinder is exhausted. Actuation connects 1 to 2 and blocks 3: the consumer receives air.',
        'h' => 'Spring return defines the rest state; actuation can be manual, mechanical, pneumatic pilot or solenoid. The exhaust port carries the silencer in control circuits.',
        's' => 'Choose NC when the safe state = depressurized (default for single-acting cylinders). Flow rate (Nl/min) must support the cylinder size — small 3/2 valves starve big cylinders.',
        'a' => ['Direct control of single-acting cylinders and air jets.',
                'Signal generation (start buttons, limit switches) in purely pneumatic controls.'],
        'x' => 'Wire a pushbutton 3/2 NC to a single-acting cylinder in the Studio; then move the supply to port 3 by rotation and watch the idle behavior invert.'];
    $D[] = ['id' => 'pl-v-32-no', 't' => '3/2-way valve, normally open', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'Rest = pressurized: air flows until you act — rare but decisive.',
        'w' => 'Same anatomy as NC but the rest position connects 1 to 2. Consumers stay pressurized until the valve is actuated.',
        'h' => 'Electrical analogy: a normally-open contact is a fail-closed wire — a broken spring or lost pilot leaves the consumer PRESSURIZED. That property is sometimes the hazard, sometimes the safety (clamps that stay clamped on air loss).',
        's' => 'Use deliberately: breakaway detection, clamping circuits that must hold during air loss, purge lines default-on. Document the rest state on the schematic clearly.',
        'a' => ['Holding clamps during air failure.',
                'Cooling/purge flows that must run unless intentionally stopped.'],
        'x' => 'Simulate air failure with an NO logic chain in the Studio: identify which actuators move and why that might be exactly what safety wants.'];
    $D[] = ['id' => 'pl-v-52-single', 't' => '5/2-way valve, single solenoid with spring return', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'The standard double-acting cylinder driver: one coil, one spring, two flow paths.',
        'w' => 'Five ports (1 supply, 2/4 cylinder ports, 3/5 exhausts). At rest, one cylinder side is pressurized and the other exhausted; energizing the solenoid flips the paths. Removing the signal returns the spool via spring.',
        'h' => 'Power failure = defined return (spring side) — this is the key difference to the double-solenoid version and the basis of many safety philosophies.',
        's' => 'Check power consumption and duty of the coil for long holding; for battery or heat-sensitive panels select low-power versions. Manual override (the small button) belongs in every commissioning ritual.',
        'a' => ['Default cylinder control where rest position is defined.',
                'Cycles that must end in a known state on power loss.'],
        'x' => 'Wire the Studio 5/2 to a double-acting cylinder; cut power mid-stroke and observe the defined return — then repeat with a double-solenoid valve.'];
    $D[] = ['id' => 'pl-v-52-double', 't' => '5/2-way double solenoid (memory valve)', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'Two coils, no spring: the valve remembers the last pulse.',
        'w' => 'Detented spool: a short pulse on coil A switches and stays; a pulse on coil B switches back. Both coils energized simultaneously is an undefined fight (interlock in the PLC!).',
        'h' => 'Power loss = the spool stays: the machine resumes where it stopped (desired for clamping hold, undesired where rest position is safety). This memory property also makes purely pneumatic step chains possible.',
        's' => 'PLC must interlock the two outputs and typically pulse (300-500 ms), not hold, to save coil heating. Commissioning: which coil extends? Mark cables — swapped coils are the classic start-up bug.',
        'a' => ['Position-holding pneumatic fixtures.',
                'Step-sequence logic in explosion-proof zones without electrics.'],
        'x' => 'Pulse the Studio memory valve, kill power, restore power: the cylinder continues from memory — now explain the risk to a colleague.'];
    $D[] = ['id' => 'pl-v-53-all', 't' => '5/3 mid positions: closed, exhausted, pressurized', 'lv' => 'intermediate', 'min' => 6,
        'sm' => 'Three personalities of one valve family — the mid position is the message.',
        'w' => '5/3 valves spring-center to a middle position. All-ports-closed stops the cylinder mid-stroke (approximately — air compresses, drift guaranteed!). Vented (center exhausted) relaxes both sides (free positioning, soft start). Pressurized (center to supply) balances both sides — holds a position roughly against external forces.',
        'h' => 'Center-exhausted is the favorite for commissioning and manual adjust modes. Center-pressurized gives pseudo-clamping: both piston areas pressurized, the differential area still creates net force on single-rod cylinders (they creep INTO the rod side — never forget area difference!).',
        's' => 'Holding precision mid-stroke is a hydraulic job; pneumatics + 5/3 closed = seconds to minutes of drift. For real stops use rod locks / clamping units.',
        'a' => ['Teach modes and manual intervention on handling axes.',
                'Emergency relax (center exhausted) for safe manual rescue.'],
        'x' => 'Stop a Studio cylinder with all three mid positions and log drift and creep for 60 s — the numbers end every specification debate.'];
    $D[] = ['id' => 'pl-v-solenoid-tech', 't' => 'Solenoid coil technology: power, duty, connectors', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Voltage, inrush, holding, IP class: the small electrical print that kills machines.',
        'w' => 'Coils come in 24 V DC (controls standard), 110/230 V AC (direct line), with DIN EN 175301 connectors (Form A/B/C) carrying LED + suppression options. AC coils draw heavy inrush until the armature seats — a stuck spool burns the coil.',
        'h' => 'DC coils need suppression diodes/varistors across switched contacts or the inductive kick eats PLC outputs and relays. LEDs in connectors speed diagnosis enormously (signal present? coil alive?).',
        's' => '100 % duty rating matters for held positions; check ambient temperature class with coil self-heating (T-classification in EX zones).',
        'a' => ['Control panel specification.', 'Troubleshooting burned coils and welded relay contacts.'],
        'x' => 'In the Studio electrics view, watch the diagnostic LED state against spool position and trace one simulated open-circuit coil.'];
    $D[] = ['id' => 'pl-v-pilot-types', 't' => 'Actuation types: manual, mechanical, pneumatic pilot, electric', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'How the valve gets told: buttons and rollers in the air world.',
        'w' => 'Manual actuators (pushbutton, mushroom, selector, foot) build human interfaces. Mechanical actuators (roller lever, idle-return roller, stem) sense machine positions. Pneumatic pilots amplify small signals into big spools; electric solenoids bridge control and power.',
        'h' => 'The idle-return roller actuates only in one travel direction — the classic element for end-position sensing in step chains (it must NOT trigger on the return pass). Three-way stem actuators sense precise positions.',
        's' => 'Roller lever placement rule: cam approaches with &asymp; 30 &deg;, never head-on. Pilot valves get clean air upstream of the power valve.',
        'a' => ['Purely pneumatic sequence controls (wet, EX, simple).',
                'End-position feedback without electrics.'],
        'x' => 'Build the Studio sequence A+ B+ A&minus; B&minus; using idle-return rollers only — the purest pneumatic thinking exercise.'];
    $D[] = ['id' => 'pl-throttle-check', 't' => 'One-way flow control (throttle-check)', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'Free flow one way, metered the other — the most-used fitting in pneumatics.',
        'w' => 'An adjustable needle in parallel with a check valve: in one direction air passes freely (check open), in the other only through the needle. Mounted directly at the cylinder port it controls speed in exactly one direction.',
        'h' => 'Rule: meter the air LEAVING the cylinder (exhaust-air throttling). The piston then works against a compressed air cushion — stiff, repeatable speed. Supply-air throttling lets the load lurch until pressure builds: spongy.',
        's' => 'Identify type by symbol orientation on the fitting; mark the adjusted needle paint after commissioning. Nearly closed needle + big piston = hours of confusion for the uninitiated.',
        'a' => ['Every cylinder speed setting in industry.', 'Slowing flap and lid motions.'],
        'x' => 'Set exhaust-air throttling on a Studio cylinder, then swap the fitting around (supply-air) and film the lurch — one orientation, two behaviors.'];
    $D[] = ['id' => 'pl-quick-exhaust', 't' => 'Quick exhaust valve', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'Exhaust at the cylinder, not 5 m away: the spring-return speed booster.',
        'w' => 'Mounted at the cylinder port, it exhausts locally through a large orifice when supply pressure collapses, instead of pushing the exhaust air back through the long line and the valve.',
        'h' => 'Especially effective for single-acting cylinders where return speed depends on exhausting the full chamber, and for long line runs whose resistance would slow retraction.',
        's' => 'Its exhaust port needs the silencer (it vents at the machine, loudly). Do not confuse with a shuttle valve — similar shape, different function.',
        'a' => ['Fast retract of spring-return cylinders.',
                'Remote actuators at the end of long tubing.'],
        'x' => 'Compare retract times with and without the quick exhaust on a long-line Studio bench — measure, then explain via line resistance.'];
    $D[] = ['id' => 'pl-shuttle-or', 't' => 'Shuttle valve (OR function)', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'Two inputs, one output, a ball that picks the stronger: pneumatic OR.',
        'w' => 'A free ball or spool inside seals the weaker inlet; the pressurized inlet reaches the output. Two buttons (or two automatic signals) can trigger the same actuator independent of each other.',
        'h' => 'Logic layers cascade: shuttle trees implement multi-way OR chains in pure pneumatics. The piston-type versions switch more crisply at low pressures than ball versions.',
        's' => 'Beware back-pressure tricks: a leaking second input path can hold the shuttle mid-way. Keep both input lines short and defined.',
        'a' => ['Start from two stations (e.g. both sides of a wide machine).',
                'OR-ing of sensor signals in sequence controls.'],
        'x' => 'OR two start buttons to one cylinder in the Studio; then hold one button and explain why the other still works — the essence of non-exclusive OR.'];
    $D[] = ['id' => 'pl-dual-pressure-and', 't' => 'Dual-pressure valve (AND function)', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'Only when BOTH inputs are live does the output breathe: pneumatic AND.',
        'w' => 'Two pistons oppose each other: pressure must reach BOTH sides so that the weaker one passes to the output while the stronger assists sealing. The building block of two-hand circuits and safety interlocks.',
        'h' => 'Output pressure equals the LOWER of the two inputs — mixing supply pressures creates surprises; feed both from the same regulator.',
        's' => 'Response time depends on both signals arriving; long line differences skew simultaneity — route symmetrically in two-hand circuits.',
        'a' => ['Two-hand control of cylinders.',
                'Guard-closed AND part-present AND start-permission chains.'],
        'x' => 'Build the dual-pressure two-hand for a Studio press; then try to cheat it by tying one input permanently — the AND says no.'];
    $D[] = ['id' => 'pl-time-delay', 't' => 'Time-delay valve', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'A needle, a small reservoir, a 3/2: pneumatic timers from 0.2 to 100 seconds.',
        'w' => 'Pilot air bleeds through an adjustable needle into a tiny accumulator; when its pressure crosses the 3/2 switching threshold, the output flips. Versions: ON-delay (signal appears after t), OFF-delay (signal persists t after removal).',
        'h' => 'Accuracy 5-10 %, temperature-dependent — plenty for process pauses (glue setting, blow-off duration), useless for precise takt. Reservoir volume times needle setting defines the range.',
        's' => 'Place near the pneumatic logic board with clean air: the micro-needle clogs gladly. Mark set times next to the valve.',
        'a' => ['Dwell times in press/bonding cycles.', 'Delayed restart interlocks.'],
        'x' => 'Simulate the glue-press dwell with an ON-delay timer; change the needle and watch the timing curve in the Studio data view.'];
    $D[] = ['id' => 'pl-pressure-seq-valve', 't' => 'Pressure sequence valve (pneumatic)', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'When force is reached pressure plateaus — and this valve converts that into the next step.',
        'w' => 'Pneumatic analog of the hydraulic sequence valve: it opens its output only when inlet pressure exceeds the set value. Classic use: clamp until full contact pressure, THEN advance the working cylinder.',
        'h' => 'Works because a stalled cylinder builds line pressure to regulator setting, whereas a moving one consumes it. The switching point setting sits between travel pressure and stall pressure.',
        's' => 'Needs &ge; 1.5-2 bar margin between travel and sequence pressure; slow cylinders with high friction make this margin vanish — then use travel sensing instead.',
        'a' => ['Clamp-then-process sequences without sensors.', 'Overload-triggered retract: stall pressure as fault signal.'],
        'x' => 'Tune a Studio clamp-drill sequence with a pressure valve; then simulate a worn clamp line (leak) and watch the sequence never advance — diagnosis skill.'];
    $D[] = ['id' => 'pl-counter', 't' => 'Pneumatic preset counter', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'N pulses in, one pulse out: batching pieces with pure air logic.',
        'w' => 'A preset counter decrements with each input pulse; at zero it emits an output signal and resets (or blocks until manual reset, by type). Counting ejected parts, strokes, or cycles without electricity.',
        'h' => 'Combined with shuttle/AND valves, counters build complete batch machines: press n times, index, repeat. Reset behavior (auto vs manual) defines the machine start conditions.',
        's' => 'Pulse length limits: signals shorter than ~8-15 ms may not register — debounce mechanical signal generators.',
        'a' => ['Packaging machines, batch filling.', 'Maintenance cycle counters on actuators.'],
        'x' => 'Program the Studio counter for a 6-piece batch and trace the end-of-batch signal into the index cylinder.'];
    $D[] = ['id' => 'pl-silencer', 't' => 'Exhaust silencers', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'From 95 dB bang to 75 dB breath: sintered bronze, the cheap hearing protector.',
        'w' => 'Porous elements (sintered bronze, PE, sintered metal felt) diffuse the exhaust jet, cutting noise 20-35 dB while keeping flow resistance modest. Every valve exhaust port deserves one.',
        'h' => 'Oversized silencers cost money; undersized ones throttle cycle time — the flow rating must match the valve. Oil mist from lubricated systems clogs silencers: rising back-pressure is the early warning.',
        's' => 'In safety-relevant exhaust paths (dump valves!) verify silencer flow explicitly — a clogged silencer can double exhaust time.',
        'a' => ['Every machine for operator comfort and legal noise levels.',
                'Clustered exhaust manifolds routing to one large rear silencer.'],
        'x' => 'Throttle an exhaust with a deliberately clogged silencer in the Studio and record cycle-time loss — maintenance made audible.'];
    $D[] = ['id' => 'pl-flow-silencer', 't' => 'Adjustable silencer / exhaust flow control', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'Silencer and needle in one: set cylinder speed right at the valve exhaust.',
        'w' => 'A sintered silencer with integrated throttle screw mounts in the valve exhaust ports (3 and 5). Adjusting it meters the exhaust air for BOTH or one direction depending on port.',
        'h' => 'Fine for simple fixtures; for precise cylinder speed prefer port-mounted throttle-checks (control per direction at the cylinder). Heat: the throttling happens at atmospheric expansion — icing can creep into heavily used silencers.',
        's' => 'Swapping needle settings between 3 and 5 swaps extension/retraction speeds — the classic commissioning mix-up. Label after tuning.',
        'a' => ['Compact machines without room at the cylinder.',
                'Retrofits where only the valve is accessible.'],
        'x' => 'Balance extend/retract speeds of a Studio cylinder from the valve side only; compare precision against cylinder-side throttle-checks.'];
    $D[] = ['id' => 'pl-nonreturn', 't' => 'Non-return and shuttle check valves in pneumatics', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'One-way discipline: protecting supply networks and holding pressure in reservoirs.',
        'w' => 'Simple poppet check valves stop backflow: between the machine and a drooping network (holding local reservoir pressure), on receiver inlets, and in logic circuits implementing path exclusivity.',
        'h' => 'Pilot-operated check versions trap cylinder air and release it on a pilot signal — the pneumatic relative of the hydraulic load-holding valve, used with 5/3 center-closed for longer (still imperfect) stops.',
        's' => 'Spring cracking pressures (0.2-0.5 bar) matter in vacuum and low-pressure circuits — select soft springs there.',
        'a' => ['Local air reservoirs protected from network dips.',
                'Anti-reverse-flow on combined exhaust manifolds.'],
        'x' => 'Trap a Studio cylinder with pilot checks, release on command, and compare hold time against the plain 5/3 closed-center case.'];
    $D[] = ['id' => 'pl-rod-lock', 't' => 'Rod locking / clamping units', 'lv' => 'advanced', 'min' => 5,
        'sm' => 'Spring-closed, air-released: the brake that makes pneumatic axes hold honest positions.',
        'w' => 'Clamping cartridges around the rod close by spring force and release at 4-8 bar pilot. On air loss the rod is mechanically locked — load stays, safety category satisfied with proper sizing.',
        'h' => 'Static holding: spec holding force 1.5-2 &times; the maximum axis load. Dynamic (emergency braking from speed) is a different, verified-rating business — few units are certified for frequent dynamic stops.',
        's' => 'Mount concentric, rod surface spec (hard chrome, tolerance f7/h6), and pilot air from the SAFE side of the control chain. Orderly release after air-loss recovery prevents jumps.',
        'a' => ['Vertical pneumatic axes (Z-axes of gantries).',
                'Position holding under PL-relevant risk assessments.'],
        'x' => 'Equip a Studio vertical axis with a lock; kill air with a raised load and verify the held position, then script the safe restart sequence.'];
    $D[] = ['id' => 'pl-valve-terminal', 't' => 'Valve terminals and fieldbus islands', 'lv' => 'intermediate', 'min' => 5,
        'sm' => '16 valves, one cable: the manifold grew a brain.',
        'w' => 'Modular terminals group 4-64 valve slices on common supply/exhaust galleries with a single fieldbus/Ethernet node (PROFINET, EtherNet/IP, IO-Link). Wiring shrinks from cables to addresses.',
        'h' => 'Diagnostics per slice (coil open/short, voltage faults, cycle counters) flow into the PLC — predictive maintenance for free. Pressure zones within one terminal (separated galleries) implement multiple pressure levels elegantly.',
        's' => 'Zoning and exhaust back-pressure sanity matter: a dump-safety slice should NOT share a gallery the E-stop cannot evacuate.',
        'a' => ['Every modern machine with &gt; 6 valves.', 'Retrofits: one valve terminal replacing a spaghetti panel.'],
        'x' => 'Assign slices and zones for a Studio machine with two pressure levels; then let one coil fail and read the PLC diagnostic message.'];
    $D[] = ['id' => 'pl-flow-rated', 't' => 'Valve flow ratings: Cv, Kv, sonic conductance C and b', 'lv' => 'intermediate', 'min' => 6,
        'sm' => '1300 Nl/min nominal, but at what &Delta;p? Learn the four languages of air flow.',
        'w' => 'Pneumatic flow is compressible: above the critical pressure ratio the valve chokes (sonic flow), after which downstream pressure no longer increases flow. Manufacturers state flow as nominal Nl/min (@6 bar 1 bar drop), Cv/Kv (imperial/metric liquid-like), or ISO 6358 sonic conductance C with critical ratio b.',
        'h' => 'C (dm&sup3;/(s·bar)) describes choked-state throughput; b says at which downstream/supply ratio choking ends. These two fully describe the valve for any condition — the modern datasheet form.',
        'f' => 'm&#775; = &rho;<sub>N</sub> &middot; C &middot; p<sub>1</sub> (choked); subsonic: with &radic;(1 - ((p<sub>2</sub>/p<sub>1</sub> - b)/(1-b))&sup2;)',
        's' => 'Never compare Cv against C directly (convert!). For cylinders, valve C should support the peak consumption; undersizing shows as slow return strokes first.',
        'a' => ['Valve sizing sheets.', 'Cross-brand replacement sourcing.'],
        'x' => 'Convert one Studio valve datasheet between all four rating systems and validate against the simulated peak-flow requirement.'];
    return $D;
}

function rgz_ll_pne_actuators() {
    $D = [];
    $D[] = ['id' => 'pl-cyl-sa', 't' => 'Single-acting cylinder', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'Air pushes out, a spring pushes back: one hose, one job.',
        'w' => 'One port, one power stroke; the return comes from an internal spring. Typical strokes to ~100 mm (longer = huge spring and housing).',
        'h' => 'Effective force = p &times; A minus spring force (which grows along the stroke — force at stroke end is notably lower than at start!). The spring-side chamber vents through a filtered breather.',
        's' => 'Economics: cheap valve (3/2), half the air of double-acting, slower return, spring force lost as usable force. Push-out versions common; pull-types exist.',
        'a' => ['Ejectors, clamps, stops, flaps — short strokes with defined rest position.',
                'Fail-return applications (power loss = spring home).'],
        'x' => 'In the Studio, chart force over stroke for a SA cylinder and see where the spring eats 30 % of your Newtons.'];
    $D[] = ['id' => 'pl-cyl-da', 't' => 'Double-acting cylinder', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'Air both ways: full force out, reduced force back (the rod occupies area).',
        'w' => 'Two chambers, alternating supply. Extension force uses full piston area; retraction uses the annulus (piston minus rod), roughly 75-85 % of extension force.',
        'h' => 'Speed at equal flow is FASTER in retraction (smaller volume!). Air consumption per cycle: both chamber volumes at supply pressure per stroke — the sizing sheet entry for compressor load.',
        'f' => 'F<sub>out</sub> = p &middot; &pi;D&sup2;/4; F<sub>in</sub> = p &middot; &pi;(D&sup2; - d&sup2;)/4',
        's' => 'Size bore from required force with 25-50 % margin at the chosen pressure, then check speed/charts for the flow side. Long strokes: buckling rules for thin rods apply just like in hydraulics.',
        'a' => ['Linear actuation everywhere in handling and packaging.',
                'Position-to-position movement with end cushioning.'],
        'x' => 'Measure extend vs retract force and speed on a Studio DA cylinder: two asymmetries explained by one rod.'];
    $D[] = ['id' => 'pl-cyl-cushion', 't' => 'End-position cushioning', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'The last 10-25 mm decide whether the machine sounds like a toolbox or a church.',
        'w' => 'Near stroke end a spear closes the main exhaust passage; the trapped air escapes only through an adjustable needle — a decelerating air cushion absorbs the kinetic energy of piston, rod and load.',
        'h' => 'Cushioning capacity relates to kinetic energy (mass &times; v&sup2;/2) relative to cushion volume and pressure. Too soft: end bang. Too hard: bounce/stick before end — the needle finds the sweet spot per load.',
        's' => 'For masses/speeds above the chart, order EXTERNAL shock absorbers — cylinders with overloaded cushions die young. Elastic seals (no cushion) only for tiny fast cycles.',
        'a' => ['Every cylinder faster than ~50 mm/s with significant load.',
                'Noise reduction programs on existing lines.'],
        'x' => 'Sweep the cushion needle on a loaded Studio cylinder from 0 to 100 % and find by measurement the setting of minimum end-impact without bounce.'];
    $D[] = ['id' => 'pl-cyl-guided', 't' => 'Guided and compact cylinders', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'When the load is not coaxial: guide rods or compact bodies share the job.',
        'w' => 'Guided cylinders integrate guide rods with plain or ball bearings beside the piston rod (taking side loads and torques); compact (ISO 21287) cylinders offer short overall length with similar bore force.',
        'h' => 'Side load on a plain cylinder wears the rod bearing and seal oval — premature leak. Guided versions convert side forces into guide-bearing forces with documented ratings.',
        's' => 'Ball bushings: precise, sensitive to side impact; plain (sintered) bushings: tough, more play. Eccentric load derating from the catalog graph, never from hope.',
        'a' => ['Pusher units, lifting tables, press-in stations.',
                'Tight machine spaces (compact series with sensor slots).'],
        'x' => 'Load a Studio plain cylinder 200 N sideways vs a guided twin; compare predicted bearing life from the catalog curves.'];
    $D[] = ['id' => 'pl-cyl-rodless', 't' => 'Rodless cylinders (magnetic and slot-sealed)', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Stroke as long as the body: gantry axes without telescopic tricks.',
        'w' => 'The piston couples to an external carriage either magnetically through the tube (clean, limited force) or mechanically via a slot sealed by a steel band (full force, fine dust vulnerable).',
        'h' => 'Footprint halves compared to a rod cylinder of equal stroke. Long strokes with external guides ride on linear rails; the cylinder only supplies the pull.',
        's' => 'Magnetic coupling decouples on overload (protection AND position loss — re-home after!). Slot versions need band inspection intervals in dirty halls.',
        'a' => ['Door and gate drives, long-stroke transfer axes.',
                'Spray booth traverses (magnetic: hermetic, paint-safe).'],
        'x' => 'Compare overall machine length of rod vs rodless solutions for a 1200 mm Studio transfer axis — space accounting in centimeters.'];
    $D[] = ['id' => 'pl-cyl-rotary', 't' => 'Rotary actuators: vane and rack-pinion', 'lv' => 'intermediate', 'min' => 4,
        'sm' => '90 or 180 or 270 degrees of air-driven torque for swivels, flaps and grippers.',
        'w' => 'Vane actuators: pressure on a vane in a round chamber gives direct rotation (compact, limited angle ~270 &deg;). Rack-pinion: a linear piston drives a gear rack over a pinion (higher torque, adjustable angle stops).',
        'h' => 'End cushioning via adjustable stops with elastomer or shock absorbers. Rack units allow mid-stroke multiple stops with accessory valves.',
        's' => 'Torque derating at angle extremes for rack types (mechanical advantage varies). Check radial loads on the pinion shaft from attached tooling.',
        'a' => ['Swivel units in pick-and-place gantries.', 'Valve automation (quarter-turn ball valves!).'],
        'x' => 'Size a swivel-jaw gripper station in the Studio: torque curve vs jaw weight at two pressures.'];
    $D[] = ['id' => 'pl-air-motor', 't' => 'Pneumatic motors (vane/piston)', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Stall it, drop it, soak it: the EX-proof continuous drive that simply refuses to die.',
        'w' => 'Air motors convert expansion into rotation (vane) or crank strokes (radial piston). Characteristic: max torque at stall, max power at ~50 % free speed — infinitely and safely stallable.',
        'h' => 'No electricity at the motor: intrinsically explosion-proof, sealed versions run underwater or in paint zones. Efficiency is poor (15-25 %) — use where robustness beats kWh.',
        's' => 'Speed control by exhaust throttling keeps torque behavior; supply throttling reduces both. Mufflers mandatory; expansion cooling can ice vanes at high continuous duty (dry the air!).',
        'a' => ['Mixers in ATEX zones, winches offshore, nutrunners.',
                'Drives that must restart under load daily.'],
        'x' => 'Stall a Studio air motor at full pressure and log torque + temperature trend — the stall-safe superpower, quantified.'];
    $D[] = ['id' => 'pl-stopper', 't' => 'Stopper cylinders for conveyor lines', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'Catch a moving pallet mid-air: the vertical fist in the roller conveyor.',
        'w' => 'Robust short-stroke cylinders (often with lever/roller heads) rise into the pallet path, absorb kinetic energy through damping versions, then retract to release the goods carrier.',
        'h' => 'Impact damping versions (air cushion plus shock absorber head) take the moving mass; simple versions suit gated (zero-pressure) accumulation. Sensor slots report the gate state.',
        's' => 'Rate by moving mass &times; conveyor speed from the nomogram — never by static weight! Rebound protection prevents pallet bounce on fast lines.',
        'a' => ['Pallet transfer systems, assembly line gating.',
                'Separation of piece flows before processing stations.'],
        'x' => 'Time a Studio accumulation zone: stopper sequence for singulating three pallets without collision.'];
    $D[] = ['id' => 'pl-grippers', 't' => 'Parallel, angular and concentric grippers', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'Two fingers, three fingers, or angled: choose by part geometry and access.',
        'w' => 'Parallel grippers move jaws straight (precise gripping, needs jaw access); angular grippers swing jaws (clearance above the part); three-jaw concentric centers round parts automatically.',
        'h' => 'Gripping force at given pressure from the jaw-length derating curve (lever effect!). Internal gripping (from inside a hole) uses the same bodies with reversed fingers.',
        's' => 'Safety: with air loss, parts drop — select spring-assist closing (fail-close) for held parts, or grip-rests in the station. Sensors (magnetic field) sense jaw position/proximity.',
        'a' => ['Pick-and-place stations of every size.', 'Machine tending (load/unload lathes, presses).'],
        'x' => 'Pick a Studio part family; compute required grip force with friction factor and 2x acceleration safety; select jaw type and pressure.'];
    $D[] = ['id' => 'pl-bellows-muscle', 't' => 'Air muscles and bellows actuators', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'Contract like a muscle, lift like a bag: unconventional linear drives.',
        'w' => 'Fluid muscles: a rubber tube in a fiber braid contracts up to 25 % when pressurized — enormous initial force, no stick-slip, no seals. Bellows cylinders: convoluted rubber chambers lift tons at 2-8 bar with short strokes.',
        'h' => 'Muscles behave like springs (force falls along contraction) — beautiful for human-collaborative clamping; bellows isolate vibration while lifting (vehicle leveling!).',
        's' => 'Muscles: watch braid damage (sharp edges), end fitting alignment only. Bellows: horizontal forces forbidden without guides.',
        'a' => ['Vibration-isolated lifts and presses.',
                'Collaborative clamping fixtures sensitive to operator fingers.'],
        'x' => 'Compare the force-stroke curve of a muscle versus a cylinder of equal diameter in the Studio characteristic viewer.'];
    $D[] = ['id' => 'pl-vacuum-ejector', 't' => 'Vacuum ejectors (Venturi)', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Compressed air in, vacuum out: single-stage and multi-stage Venturi physics.',
        'w' => 'A jet of compressed air through a nozzle entrains the connected volume (Bernoulli/ejector effect). Single-stage: simple, high vacuum flow. Multi-stage: higher efficiency at low vacuum levels — less air per suction liter.',
        'h' => 'Two specs matter: evacuation time for the connected volume (how fast the cup grips) and air consumption (running cost). Optimal working vacuum for porous parts vs dense parts differs (dense: 60-80 %, porous: low vacuum/high flow ejector).',
        's' => 'Energy saving units switch the ejector off once holding vacuum is reached (with check valve) — payback in months on 24/7 lines.',
        'a' => ['Pickup systems, carton handling, sheet feeders.',
                'Local vacuum where no central pump exists.'],
        'x' => 'Time a Studio cup gripping a part with single vs multi-stage ejector at equal supply: speed and liters compared.'];
    $D[] = ['id' => 'pl-vacuum-cups', 't' => 'Suction cups and vacuum switches', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'The interface to the workpiece: flat, bellows, oval, foam — and the switch that verifies the grip.',
        'w' => 'Cup shapes fit surfaces: flat for rigid sheets, bellows for uneven/curved (compensates height), oval for narrow parts, foam for rough surfaces. Materials: NBR general, silicone food/hot, PU wear, mark-free NBR for glass.',
        'h' => 'Holding force = &Delta;p &times; effective cup area; horizontal (shear) loads on smooth cups are friction-only — derate 4x and never trust shear at high acceleration. The vacuum switch confirms grip before motion (cycle permission!).',
        's' => 'Cup count with redundancy: never design a crane where one torn cup loses the load. Check valves per cup isolate a single failure.',
        'a' => ['Sheet metal and glass handling.',
                'Packaging: cartons, bags, bottles.'],
        'x' => 'Size a 4-cup lifter for a steel sheet with 3 g acceleration in the Studio calculator; then break one cup and verify the margin.'];
    $D[] = ['id' => 'pl-tubing-fittings', 't' => 'Tubing and fittings: PA, PU, push-in', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'DN by inner diameter, PU for energy chains, PA for precision — and why push-in joints decide leaks.',
        'w' => 'PA (nylon): rigid, precise, stable — panel builds. PU: flexible, kink-tolerant — moving applications, robots, energy chains. Push-in fittings grip the tube by an internal claw with an O-ring seal: fast assembly, demount cleanly by pressing the release ring.',
        'h' => 'Leak statistics: tubing cut with a dull knife at an angle is the top cause of micro-leaks. Tube cutters exist for a reason. Bend radius violations throttle flow permanently.',
        's' => 'Size by inner diameter from the flow consumption chart — &quot;6 mm tube&quot; means OD 6, ID 4! Pressure drop budget: keep tube length &lt; 3 m for fast cylinders or step up diameter.',
        'a' => ['Every pneumatic machine build.', 'Leak-hunting campaigns (the 30 % energy leak epidemic).'],
        'x' => 'In the Studio, compare response of a fast cylinder over 2 m vs 8 m of ID 2.7 tube — the missing milliseconds live in the hose.'];
    $D[] = ['id' => 'pl-manifold-distribution', 't' => 'Distribution blocks and multi-pressure branches', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'One supply, eight consumers, three pressure levels: the plumbing that keeps panels sane.',
        'w' => 'Distribution blocks fan out supply air; sandwich regulators under each valve slice create per-function pressure levels off the same manifold (saving separate lines).',
        'h' => 'Exhaust galleries similarly common: back-pressure from a choked common exhaust affects ALL slices — size exhaust chokes and consider silenced manifolds.',
        's' => 'Unused stations get blanking plates (and are documented spare capacity!). Line labels per consumer prevent the classic crossed-hose afternoon.',
        'a' => ['Valve terminal planning.', 'Machine retrofits with added functions.'],
        'x' => 'Plan the Studio terminal: 5 slices, two pressure zones, one spare — then price the plumbing against five standalone valves.'];
    $D[] = ['id' => 'pl-sensor-reed', 't' => 'Cylinder position sensors (reed vs solid-state)', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'A magnet rides the piston; a switch in the slot tells the PLC where it went.',
        'w' => 'Reed switches: two ferromagnetic tongues close in the piston magnet field (cheap, needs bounce debounce). Solid-state (GMR/magnetoresistive): bounce-free, precise switching point, longer life at high cycle rates.',
        'h' => 'Hysteresis and repeatability define usable accuracy: end-position sensing with &plusmn;0.2 mm solid-state is routine; mid-position multi-sensing uses several switches or continuous analog position sensors.',
        's' => 'Mind weld fields (migrated sensors lie!), strong external magnets, and correct slot/brand match. LED indicator = commissioning friend.',
        'a' => ['End-position feedback for every pneumatic sequence.',
                'Cycle counting for predictive maintenance.'],
        'x' => 'Place two sensors per cylinder in a Studio sequence and wire the PLC start conditions from them.'];
    $D[] = ['id' => 'pl-sensor-pressure', 't' => 'Electronic pressure switches and sensors', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'Mechanical snap switches gave birth to IO-Link transducers: pressure became data.',
        'w' => 'Mechanical pressure switches snap at a spring-set threshold (cheap, drift). Electronic switches offer two programmable thresholds with display; transducers output 4-20 mA / 0-10 V / IO-Link continuous values.',
        'h' => 'Modern practice: vacuum switches verify grip, pressure switches verify clamp force and regulator health, transducers trend leakage overnight (pressure decay = leak signature).',
        's' => 'Hysteresis setup prevents relay chatter at the threshold; peak-hold functions catch spikes the PLC cycle would miss.',
        'a' => ['Grip verification, clamp verification, network monitoring.',
                'Compressed-air leak supervision during off-shifts.'],
        'x' => 'Instrument a Studio gripper and clamp with switches and script the permission logic: no sensor OK, no cycle start.'];
    $D[] = ['id' => 'pl-sensor-flow', 't' => 'Flow sensors and consumption metering', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'You cannot manage what you do not meter: machine-level air accounting.',
        'w' => 'Thermal mass-flow or differential-pressure sensors measure Nl/min per machine, reporting to energy dashboards. Off-shift readings reveal base leakage with surgical honesty.',
        'h' => 'Placement at each production line feeder transforms leak hunting from annual campaigns to continuous management: consumption deltas after each fix quantify savings in currency.',
        's' => 'Bidirectional (charge/exhaust) confusion: measure supply leg only. Pipe diameter straight runs required for the flow profile.',
        'a' => ['ISO 50001 energy management systems.', 'Leak detection programs (the 25-35 % typical waste).'],
        'x' => 'Read the Studio plant overnight flow: identify the leak liters, price them, rank the business case.'];
    return $D;
}

function rgz_ll_pne_patterns() {
    $D = [];
    $D[] = ['id' => 'pl-ckt-direct-sa', 't' => 'Direct control of a single-acting cylinder', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'Button to valve to cylinder: the three-component hello-world of pneumatics.',
        'w' => 'A 3/2 NC pushbutton valve feeds the SA cylinder directly. Press: extend. Release: the valve springs home, the cylinder is exhausted through port 3, the return spring pulls the rod back.',
        'h' => 'Direct control works while the valve flow rate satisfies the cylinder demand; that is usually true up to &phi; 50 cylinders with short tubes. Speed setting via throttle-check at the cylinder (exhaust side).',
        's' => 'Valve close to the cylinder shortens exhaust path = faster spring return. Label the exhaust silencer: it IS the return path.',
        'a' => ['Ejectors, clamps, flag stops — everywhere simple spring-return motion lives.',
                'Manual stations where the operator IS the controller.'],
        'x' => 'Build it, then fit the throttle-check reversed by mistake: explain the lurch to yourself before the foreman does.'];
    $D[] = ['id' => 'pl-ckt-indirect', 't' => 'Indirect control: pilot valve and power valve', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'Small signal moves big spool: separating signal level from power level.',
        'w' => 'A small 3/2 signal valve pilots the large 5/2 power valve that feeds the cylinder. Long distances, big cylinders, weak sensors — the pilot stage solves all three.',
        'h' => 'Pilot pressure needs &ge; 2-3 bar reliably; long pilot lines delay switching (fill time). Internal vs external pilot supply: external pilot required for vacuum or &lt; 3 bar supply duties.',
        's' => 'Standardize pilot voltage and connector type plant-wide. The LED in the pilot connector is the first diagnostic reading on any dead station.',
        'a' => ['Every cylinder &gt; &phi; 63 or remote from its signal.',
                'PLC-controlled machines (PLC output = pilot).'],
        'x' => 'Pilot a big-bore Studio cylinder via a 5/2 power stage; measure switching delay vs pilot-line length.'];
    $D[] = ['id' => 'pl-ckt-latching-ma', 't' => 'Latching control with memory valve', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'Press once, it goes; press another, it returns: start/stop logic without holding.',
        'w' => 'Start button pulses the extend side of a double-pilot 5/2 memory valve; stop (or end-position sensor) pulses the retract side. The valve holds its last state with no signal applied.',
        'h' => 'The detent holds position through power/air interruptions — sophisticated behavior, but the safety audit asks: with air loss and recovery, what moves? Answer deliberately, document it.',
        's' => 'Signals must be pulses, not maintained levels: overlapping signals from both sides fight. Manage initial state at machine start (defined pulse or initialization routine).',
        'a' => ['Two-button clamp/release fixtures.',
                'Sequence bases (the step-chain VALVE in pure pneumatic controls).'],
        'x' => 'Wire start/stop latching in the Studio, kill air mid-cycle, restore it, and write the startup rule for your panel.'];
    $D[] = ['id' => 'pl-ckt-auto-return', 't' => 'Automatic return at end position', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'Reach the end, roll the lever, come home: the fundamental automation step.',
        'w' => 'A roller-lever valve (3/2) at the end position senses the extended cylinder and pulses the retract side of the memory valve — full cycles from a single start button.',
        'h' => 'Idle-return roller versions actuate in ONE direction only, so the returning cylinder passing by does not retrigger. Where to mount? End of stroke with overtravel margin of the adjustable lever.',
        's' => 'Cam approach angle &asymp; 30 &deg; for roller life: head-on hits destroy stems. Sensor alternative: reed switch + PLC equivalent.',
        'a' => ['Simple reciprocating fixtures (pressing, marking).',
                'Teaching rigs: the canonical second circuit in every Festo lab.'],
        'x' => 'Build the auto-return cycle; then demand double-stroke per press and derive the timer/counter solution yourself.'];
    $D[] = ['id' => 'pl-ckt-twohand', 't' => 'Pneumatic two-hand control', 'lv' => 'intermediate', 'min' => 6,
        'sm' => 'Both palms within 0.5 s or nothing — the pneumatic safety circuit par excellence.',
        'w' => 'Two 3/2 pushbuttons feed a dual-pressure (AND) valve; the AND output pilots the power valve. Anti-repeat and simultaneity supervision come from a purpose-built two-hand relay or a pneumatic timing block.',
        'h' => 'The 0.5 s simultaneity window and release-to-repeat requirements outlaw simple AND plumbing for press duties — certified two-hand devices implement them with monitored redundancy (type IIIC per EN 574).',
        's' => 'Distance buttons &ge; 300 mm (inside) against one-hand-one-elbow defeat; shrouded against knee/elbow tricks; position outside the danger zone reach (calculate stopping time!).',
        'a' => ['Presses, riveting, clinching machines.',
                'Any cycle whose start must guarantee both hands busy.'],
        'x' => 'Build the circuit in the Studio, pass all three cheat attempts (single press, tied button, hold-and-repeat) and justify the certified device to the auditor avatar.'];
    $D[] = ['id' => 'pl-ckt-time-dwell', 't' => 'Dwell at end position with time-delay', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Extend, wait three seconds while the glue sets, return — timed pneumatics.',
        'w' => 'The end-position signal starts a time-delay valve; its delayed output pulses retract. ON-delay topology: output appears after t; OFF-delay: output removed t after input falls.',
        'h' => 'Accuracy matters little for glue (10 % error tolerable), a lot for takt: balance needle setting against cycle time target, log actual dwell with the sensor data.',
        's' => 'Dust ruins the micro-needle: filtered pilot air and an occasional blowing-through during maintenance. Note temperature drift across seasons.',
        'a' => ['Bonding, marking, cooling dwells.',
                'Blow-off duration after eject cycles.'],
        'x' => 'Simulate the dwell-press cycle; shift ambient +20 &deg;C and quantify the timing drift against your tolerance.'];
    $D[] = ['id' => 'pl-ckt-quickexhaust-speed', 't' => 'High-speed return with quick exhaust', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'Steal 40 % of the cycle time back by venting at the cylinder.',
        'w' => 'A quick-exhaust valve at the cylinder inlet dumps the return chamber locally instead of through 5 m of tubing and the control valve. Retraction accelerates dramatically on single-acting setups.',
        'h' => 'Measure first: long lines, large bores and light springs benefit most. The effect stacks with port-size increases — but quick exhaust alone is the cheapest upgrade.',
        's' => 'Silence its exhaust (it vents at the machine, suddenly loud). Seal versions matter in dusty shops.',
        'a' => ['High-takt ejection stations.',
                'Retrofitting speed into existing slow fixtures.'],
        'x' => 'Benchmark retract times at 2 m and 8 m line with and without the quick exhaust in the Studio — the chart sells itself.'];
    $D[] = ['id' => 'pl-ckt-pressure-seq', 't' => 'Pressure-dependent sequence: clamp then process', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'No sensors: the clamp pressure itself authorizes the drill.',
        'w' => 'A pressure sequence valve monitors the clamp line; while the clamp cylinder is still traveling (pressure low), the drill branch waits. Once the clamp stalls on the part, pressure peaks, the sequence valve opens, the drill advances.',
        'h' => 'Travel pressure vs stall pressure margin defines reliable switching (&ge; 1.5 bar). Leaky clamps creep below the threshold mid-cycle — the drill aborts with cryptic irregularity (now you know why).',
        's' => 'Prefer sensor-based sequencing where margins are tight; pressure logic shines in harsh environments where sensors die.',
        'a' => ['Drill/rivet fixtures in dirty halls.',
                'Explosive atmospheres where electrics are costly.'],
        'x' => 'Set the Studio sequence valve 1 bar above travel pressure: watch it misfire, find the reliable setting, log the margin rule.'];
    $D[] = ['id' => 'pl-ckt-cascade', 't' => 'Cascade method: A+ B+ B&minus; A&minus; systematic', 'lv' => 'advanced', 'min' => 8,
        'sm' => 'The design method that makes ANY multi-cylinder sequence buildable without overlap errors.',
        'w' => 'Group division: split the motion sequence into groups so that no cylinder switches twice inside one group. Each group gets its own supply line, activated by a step (memory) valve; signals from other groups cannot disturb because their supply is off.',
        'h' => 'Example A+ B+ B&minus; A&minus;: groups [A+] / [B+ B&minus;] / [A&minus;]. The start signal enters group 1; the end-position of the LAST motion in a group enables the next group supply via a shuttle tree. Result: at every moment only ONE group has signal pressure — signal overlap is structurally impossible.',
        's' => 'This method scales to 6+ cylinders where intuition collapses. Modern translation: the PLC does the grouping in software, but understanding cascade makes you design correct PLC sequences faster.',
        'a' => ['Purely pneumatic control panels (EX zones, car wash).',
                'Design reviews of legacy pneumatic machines.'],
        'x' => 'Build the full 3-group cascade for A+ B+ B&minus; A&minus; in the Studio logic lab; then remove one group valve and watch the overlap fault appear in glorious red.'];
    $D[] = ['id' => 'pl-ckt-stepper', 't' => 'Step modules and relay sequencers', 'lv' => 'advanced', 'min' => 6,
        'sm' => 'Industrialized cascade: ready-made step-chain modules that snap together.',
        'w' => 'Commercial step-chain modules (pneumatic relays in a cascade-tolerant block) implement step i: output to actuator i active, plus input interlock requiring previous step completion. Machine sequence = wired module order.',
        'h' => 'Advantages over home plumbing: defined initial step, manual step override, fewer assembly errors. The same thinking survives into PLC ladder step logic (SFC/GRAPH).',
        's' => 'Documentation: the module map IS the control documentation. Spare modules on the shelf change MTTR dramatically in remote plants.',
        'a' => ['Medium-sized EX-zone machines lasting 20 years.',
                'Controls in locations where laptops are unwelcome.'],
        'x' => 'Convert your Studio cascade to a three-step module schematic; identify the manual override point for commissioning.'];
    $D[] = ['id' => 'pl-ckt-multi-pressure', 't' => 'Multi-pressure circuits with sandwich regulators', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Extend gentle, retract strong — or clamp soft on one side only: per-direction pressure levels.',
        'w' => 'Pressure regulators in the valve slice (or sandwich plates under individual valves) throttle the supply per cylinder port direction. The throttle-check valves still meter speed; pressure meters force.',
        'h' => 'Classic misconfiguration: reducing supply pressure on a meter-out circuit collapses the cushion stiffness — speed stability dies. Reduce pressure on the SIDE THAT PUSHES, keep exhaust cushion strong.',
        's' => 'Gauge per zone pays for itself in one troubleshooting session. Regulator droop under dynamic flow: verify at operating speed, not static.',
        'a' => ['Press-in stations (gentle force, fast return).',
                'Asymmetric grippers and tensioners.'],
        'x' => 'Configure extend=3 bar, retract=6 bar on a Studio axis; verify force asymmetrically on the gauge pair and explain the speed side effect.'];
    $D[] = ['id' => 'pl-ckt-oscillating', 't' => 'Continuous oscillating circuit', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Two sensors, one memory valve: endless reciprocation until told otherwise.',
        'w' => 'End-position sensors pulse the two sides of a memory valve alternately: reach A, retract; reach B, extend. A start/stop selector gates the chain.',
        'h' => 'Frequency from flow settings and stroke; duty cycles wear valves: solid-state sensors and high-cycle valves pay off at &gt; 10 cycles/min. Overrun of the sensor positions ends in travel-error — include margin or timeout supervision.',
        's' => 'Add a cycle counter to log wear for maintenance intervals; the timeout interlock (no end-signal after 2&times; expected time) catches slipping cams early.',
        'a' => ['Test rigs, polishing, spraying traverses.',
                'Cleaning and rinsing cycles.'],
        'x' => 'Build the oscillator in the Studio, bump a sensor clamp 10 mm, and let the timeout interlock catch your sabotage.'];
    $D[] = ['id' => 'pl-ckt-vacuum-pick', 't' => 'Vacuum pick-and-place circuit', 'lv' => 'intermediate', 'min' => 6,
        'sm' => 'Ejector on, verify grip, move, blow-off: the four-beat rhythm of vacuum handling.',
        'w' => 'Cycle: ejector generates vacuum, cups approach the part, vacuum switch confirms grip (&gt; threshold), axis moves, at destination the ejector stops and a short blow-off pulse frees the part positively.',
        'h' => 'Blow-off matters: elastic cups re-stick for 100-300 ms without it. Energy-saving ejectors hold vacuum with a check valve and cycle the jet on demand (70-90 % air saving).',
        's' => 'Grip verification BEFORE vertical motion is non-negotiable: drop detection mid-air is damage. Size blow-off gentle (0.5-1.5 bar) to avoid part launch.',
        'a' => ['Sheet loading, carton erectors, label applicators.',
                'Any robot EOAT story.'],
        'x' => 'Script the full pick cycle in the Studio with the grip-check interlock; sabotage one cup and prove the machine refuses to fly blind.'];
    $D[] = ['id' => 'pl-ckt-estop-chain', 't' => 'E-stop and restart interlock', 'lv' => 'advanced', 'min' => 6,
        'sm' => 'Dump now, restart only deliberately: safe-state pneumatics.',
        'w' => 'The safety chain energizes the dump/soft-start block: E-stop, guard door, pressure-OK, PLC-permission in series. Opening any link exhausts the machine; reclosing arms a monitored RESTART button — the machine restarts only on deliberate press.',
        'h' => 'After a dump, cylinders are relaxed and possibly mid-position: the restart philosophy must define behavior (hold position with locks? return home first?).

Monitored restart prevents the classic accident: guard closed &rarr; machine resumes unexpectedly.',
        's' => 'Soft-start ensures gentle repressurization after restart. Exhaust-time verification via risk assessment; rod locks where gravity holds hazards.',
        'a' => ['Every machine with safeguarding (ISO 13849/EN ISO 13850).',
                'Retrofitting restart interlocks on legacy benches.'],
        'x' => 'Simulate: E-stop with raised load, guard reclose (nothing moves — verify!), deliberate restart with soft start — and describe each pressure trace.'];
    $D[] = ['id' => 'pl-ckt-network-buffer', 't' => 'Local reservoir against network dips', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'The machine keeps its own lunch: buffer tank + check valve against plant sag.',
        'w' => 'A small receiver at the machine inlet, fed via a check valve, bridges short network pressure drops and peak demands that exceed the drop-line capacity.',
        'h' => 'Sizing like the central receiver: V covers the peak volume times (pmin margin) &mdash; with the check valve isolating the buffer from a collapsing header.',
        's' => 'Add a gauge and a relief per local codes. In leak math, remember the buffer hides sag during measurement — isolate it during audits.',
        'a' => ['Machines far from the compressor with bursty demand.',
                'Critical processes that must complete a cycle during dips.'],
        'x' => 'Dip the Studio network 2 bar for 3 s: with buffer the cycle completes; without, the clamp sensor protests — resilience engineered.'];
    $D[] = ['id' => 'pl-ckt-air-jet', 't' => 'Air jet and blow-off circuits', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'Cleaning with air: timed, aimed, and quieter than you learned in the workshop.',
        'w' => 'Blow-off via 3/2 valve and nozzle array, triggered by part-present sensors, timed by PLC or pneumatic timers. Engineered nozzles (laval/air-amplifier) halve consumption at equal force compared to open pipes.',
        'h' => 'Air-amplifier nozzles entrain ambient air 10-25&times; — the compressors favorite upgrade. Noise follows velocity power 6-8: laminar slots beat drill holes.',
        's' => 'OSHA-type rules: dead-end pressure &lt; 2 bar on open jets (skin safety), chip guards mandatory. Timed bursts (200 ms) usually beat continuous blow massively.',
        'a' => ['Chip removal, drying after washing stations, part ejection assist.',
                'Static elimination + dust removal before printing.'],
        'x' => 'A/B test open tube vs amplifier nozzle in the Studio: force equal, liters 50 % apart — retrofit memo written by data.'];
    $D[] = ['id' => 'pl-ckt-differential-reduce', 't' => 'Return-stroke pressure reduction (energy trick)', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Extend at 6 bar, retract at 2 bar: up to 30 % air saved on no-load returns.',
        'w' => 'A regulator or pressure-reduced branch feeds only the retract side; the full supply serves extension. Return force usually only overcomes friction — full pressure there is pure waste.',
        'h' => 'Savings = volume of retract chamber &times; &Delta;p fed. At 24/7 takt machines this is one of the top energy retrofits with months payback.',
        's' => 'Verify minimum retract force against friction and spring loads; reduced pressure also slows return unless the throttle-check is rebalanced.',
        'a' => ['High-cycle pusher/stopper stations.',
                'Compressed-air-saving initiatives.'],
        'x' => 'Instrument Studio consumption per cycle at both settings; compute the annual saving for 3-shift operation.'];
    $D[] = ['id' => 'pl-ckt-plc-mapping', 't' => 'Mapping a pneumatic sequence into PLC ladder', 'lv' => 'intermediate', 'min' => 6,
        'sm' => 'Sensors to inputs, valves to outputs, steps to flags: the honest translation method.',
        'w' => 'Method: 1) write the motion sequence (A+ B+ A&minus; B&minus;); 2) list sensors (a1, a0, b
1, b0) as inputs and valve coils (A+, A&minus;, ...) as outputs; 3) draw the step chain with transition conditions; 4) implement set/reset latches per step; 5) add start conditions (home positions, guards), 6) add fault timeouts.',
        'h' => 'The trap: feedthrough signals (sensor still true from previous step) fire steps early — the cascade insight returns as the software rule: transitions checked only in their step context.',
        's' => 'Simulation BEFORE wiring: replay the sequence in the Studio PLC tab line by line; a dry-run catches 80 % of translation errors.',
        'a' => ['Every control engineering job interview task.',
                'Converting air-logic legacy machines to PLC.'],
        'x' => 'Translate the Studio glue-press sequence to ladder, dry-run it, then swap two sensors and let the timeout catch the wiring error.'];
    $D[] = ['id' => 'pl-ckt-logic-review', 't' => 'Pure-air logic: when pneumatics IS the controller', 'lv' => 'advanced', 'min' => 6,
        'sm' => 'No PLC, no electricity at the machine: valves, sensors and logic elements run 30 years.',
        'w' => 'Car-wash gantries, ATEX conveyors and wet-area machines use valve logic exclusively: buttons = 3/2 valves, AND = dual-pressure, OR = shuttle, memory = 5/2 double, timer = delay valve, sequence = cascade.',
        'h' => 'Strengths: intrinsically safe, washdown-proof, EMP-indifferent, repair-with-wrench. Weaknesses: no easy logging, changes mean plumbing, diagnostics by ear and gauge.',
        's' => 'Design discipline: signal levels documented (signal vs working air separated by color), panel layout mirroring the schematic, every element labeled.',
        'a' => ['ATEX-heavy plants (paint, flour, chemicals).',
                'Backup modes where PLC failure must not stop production.'],
        'x' => 'Rebuild the Studio pick station in pure air logic; then list what the PLC version adds (and costs) — a technology choice with arguments.'];
    $D[] = ['id' => 'pl-ckt-failsafe-review', 't' => 'Fail-safe design patterns', 'lv' => 'advanced', 'min' => 6,
        'sm' => 'Air gone, power gone, hose burst: rehearse the three funerals per axis.',
        'w' => 'For each actuator ask: air failure behavior (spring return? memory? lock?), power failure (solenoid drop), hose burst (rod lock? counter-balance pneumatic?), and document the resulting machine pose.',
        'h' => 'Gravity axes fail DOWN without locks — people-space defines need. Clamps fail OPEN with air loss unless NO valves or mechanical lock hold them (do you WANT clamp-hold on failure? sometimes yes!).',
        's' => 'Risk assessment tables (hazard &times; failure mode) turn philosophy into checklists; simulate the failures — simulation makes the table honest.',
        'a' => ['Safety integrity work (ISO 13849 retrofits).',
                'HSE incident prevention reviews.'],
        'x' => 'Script the three failures on three Studio axes and capture the pose table — professional risk review in one afternoon.'];
    return $D;
}

function rgz_ll_pne_patterns2() {
    $D = [];
    $D[] = ['id' => 'pl-ckt-step-monitor', 't' => 'Sequence supervision with step timeouts', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Every step gets a timer: if the end sensor has not reported, stop and call maintenance.',
        'w' => 'Each motion step starts a watchdog timer (PLC or pneumatic). If the expected end-position sensor does not switch within 1.5-2&times; the normal step time, the machine stops with a step-specific fault message.',
        'h' => 'This converts vague machine hangs into exact diagnoses (which cylinder, which sensor, which valve). Pneumatic implementation: timing valves across step signals; PLC: TON per step with differentiated fault codes.',
        's' => 'Timeout values from measured step times + margin, tightened during production optimization. Too tight = nuisance stops; too loose = long jam time.',
        'a' => ['Every automated station beyond toy level.',
                'OEE improvement programs (fault Pareto from timeout codes!).'],
        'x' => 'Add timeout supervision to your Studio sequence; block the drill cylinder deliberately and read the exact fault code the system produces.'];
    $D[] = ['id' => 'pl-ckt-priority-mode', 't' => 'Manual / setup mode selection', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'A selector valve gives the commissioning engineer a legal back door.',
        'w' => 'A 3/2 (or PLC bit) mode switch routes signals either from the automatic chain or from manual pushbuttons, interlocked so that automatic start is dead in setup mode.',
        'h' => 'Pneumatic version: the setup line is a separate gallery pressurized only in setup mode (cascade thinking!). PLC version: mode bit gating the auto/routine outputs plus jog functions per axis.',
        's' => 'Mode selection must be key-supervised (keys to authorized people) and the mode displayed. Guards may be muted only under specified setup conditions (risk assessment!).',
        'a' => ['Setup and size change on production machines.',
                'Commissioning and maintenance procedure design.'],
        'x' => 'Retrofit setup mode into your Studio cell; verify by simulation that auto-start is impossible while a setup jog moves the axis.'];
    $D[] = ['id' => 'pl-ckt-emergency-retract', 't' => 'Emergency retract override', 'lv' => 'advanced', 'min' => 5,
        'sm' => 'Whatever the sequence thinks: one mushroom valve sends the tool home.',
        'w' => 'A manually actuated valve (often pneumatic pilot on the power stage or an electrical override path) forces the process cylinder to retract immediately, bypassing the normal chain — distinct from E-stop (which dumps air).',
        'h' => 'Use when dumping air would drop a load or lose an in-process part: powered retract is safer than depressurized drift. Combine: E-stop dumps; emergency-retract returns the tool first, THEN dumps.',
        's' => 'Override logic must survive PLC failure — hardwired pilot paths or dedicated safety relays. Drill the operators: retract first, dump second.',
        'a' => ['Presses over parts (die protection).',
                'Weld guns that must not freeze mid-material.'],
        'x' => 'Wire the override chain in the Studio; simulate PLC freeze mid-cycle and retract the tool with the hardwired path.'];
    $D[] = ['id' => 'pl-ckt-high-low-feed', 't' => 'Two-stage feed: fast approach, slow work', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Speed is sprints and surgeons: 60 mm/s to the part, 4 mm/s through it.',
        'w' => 'A second throttle path with a switching valve (or cam-actuated 3/2) changes the exhaust restriction mid-stroke: fast until the work point sensor, then precise slow feed for the process.',
        'h' => 'Classic drilling unit logic. Air-compressibility bump: the switching moment relaxes the air cushion — minimize with a properly pressurized meter-out design and short switching volumes.',
        's' => 'Place the sensor/cam with overrun margin; the speed change position tolerance adds directly to depth accuracy.',
        'a' => ['Pneumatic drilling and tapping units.',
                'Glue dispensers: fast travel, metered deposit.'],
        'x' => 'Tune the Studio drilling feed unit: switch point, slow speed and depth stop; measure the bump at transition and shrink it.'];
    $D[] = ['id' => 'pl-ckt-separate-exhaust', 't' => 'Independent exhaust throttling per direction', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'Extend slow, retract fast: one cylinder, two speed personalities.',
        'w' => 'Throttle-check valves at both cylinder ports, both oriented to meter OUT of the cylinder, give independent speed control per direction — the professional standard.',
        'h' => 'The common mistake of metering IN shows its usual symptoms: spongy starts and load-dependent speeds. Exhaust metering keeps the piston squeezed between two air cushions: stiff.',
        's' => 'Retraction quicker than extension is natural (annulus area gain) — expect asymmetric speeds even at equal settings.',
        'a' => ['Every process cylinder in the plant.',
                'Noise tuning: slower retraction halves impact sounds.'],
        'x' => 'Set extend 0.8 s and retract 0.4 s on the same Studio cylinder, verify with the chronometer view, and save the settings recipe.'];
    $D[] = ['id' => 'pl-ckt-synchronization', 't' => 'Synchronizing two cylinders (approximate)', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Air compresses: true pneumatic sync is a dream; useful sync is engineering.',
        'w' => 'Two cylinders fed from the same valve with individually balanced throttle-checks move approximately together (&plusmn;5-10 %). Mechanical coupling (shaft, bridge) or hydro-pneumatic feeds are needed for real synchronism.',
        'h' => 'Load differences translate directly into speed differences through the compressible medium — balance by throttle, verify by sensors, accept the spread or change technology.',
        's' => 'Never promise &lt; 5 % position spread without mechanical means. Guide the load so that skew jams are geometrically impossible even without sync.',
        'a' => ['Twin lifters and wide flaps.',
                'Cover openings on machines.'],
        'x' => 'Balance a Studio twin-lifter to minimal skew; then double the load on one side and measure the new spread — physics honesty.'];
    $D[] = ['id' => 'pl-ckt-tandem', 't' => 'Tandem cylinders for force doubling', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'Two pistons, one rod: twice the force in the same diameter.',
        'w' => 'A tandem cylinder stacks two pistons on a common rod with two pressure chambers for extension: force adds (nearly) double at stroke lengths of a single cylinder, in the tight envelopes where a bigger bore does not fit.',
        'h' => 'Air consumption doubles (both chambers feed) — the energy side of force doubling. Retraction works on the single annulus as usual.',
        's' => 'Consider instead: pressure booster circuits if the plant allows higher local pressure, or a lever. Compare envelope, energy and cost for the specific case.',
        'a' => ['Press-in and punching units with narrow mounting space.',
                'Cylinder upgrades where bore diameter is frozen by the frame.'],
        'x' => 'Fit a tandem into a Studio die station that cannot grow in diameter; verify the doubled eject force with the gauge.'];
    $D[] = ['id' => 'pl-ckt-counter-batch', 't' => 'Batch counter cycle machine', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Press five times, index, repeat: a counter orchestrates a small series automatically.',
        'w' => 'A preset counter receives end-of-stroke pulses; at zero it fires the index step and resets itself. The classic packaging rhythm without a single line of code.',
        'h' => 'Fault thinking: a missed pulse (sensor glitch) desynchronizes batch and counter — supervision via index sensor OR-ing the count ensures alignment, or the batch photoelectric check closes the loop.',
        's' => 'Manual reset and batch-display are operator essentials. For batches changed daily, PLC costs less than operator confusion.',
        'a' => ['Carton grouping, pill rows, label sets.',
                'Any n-of-these-then-that rhythm.'],
        'x' => 'Script batch-of-6 with all its fault checks in the Studio logic lab; sabotage one sensor and watch the supervision catch it.'];
    $D[] = ['id' => 'pl-ckt-pick-place-full', 't' => 'Complete pick-and-place cycle: vertical, horizontal, grip', 'lv' => 'intermediate', 'min' => 7,
        'sm' => 'Down, grip, up, across, down, release, up, back: the eight-step machine that teaches sequencing.',
        'w' => 'Three axes (Z-lift, X-transfer, gripper) run a complete handling cycle. Sequence design: Z&minus; grip Z+ X+ Z&minus; release Z+ X&minus; — each step sensor-confirmed, grip verified before Z+.',
        'h' => 'Energy and speed: simultaneous axes where geometrically independent (Z+ and X+ can overlap when clear!) halves cycle time — step-chain groupings reflect this.',
        's' => 'Grip verification, part-present at both stations, and vacuum-release blowoff timing are the three details that separate drawing board from line.',
        'a' => ['Machine tending kits.', 'Your first robotless automation cell.'],
        'x' => 'Build the full cycle with overlap optimization in the Studio; compare naive sequential vs overlapped cycle time and defend the safety of your overlap.'];
    $D[] = ['id' => 'pl-ckt-clamp-varying', 't' => 'Clamping varying workpieces without jams', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Parts vary; the fixture must forgive: compliance, travel margin, grip detect.',
        'w' => 'Design clamps with travel margin beyond nominal contact (spring-loaded jaws, bellows cylinders, telescoping stops) instead of dead-end positions, and verify clamp by pressure (sequence valve) or jaw-position sensor rather than by stroke end.',
        'h' => 'A clamp designed to touch exactly at its end-position jams on +1 mm parts and fails open on &minus;1 mm parts. Float in the mechanism plus verification signal solves both.',
        's' => 'Clamp-force window: sequence valve between minimum-safe-grip and part-deformation pressures — calibrate per part family, document on the setup sheet.',
        'a' => ['Cast and sawn parts (dimensional scatter).',
                'Mixed-model lines with quick size change.'],
        'x' => 'Feed the Studio clamp with parts of &plusmn;2 mm scatter; tune margin and detection until zero jams in 50 cycles.'];
    $D[] = ['id' => 'pl-ckt-vacuum-porous', 't' => 'Gripping porous workpieces', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Cardboard, wood, fabric: when the part breathes, vacuum flows instead of building.',
        'w' => 'Porous parts leak air through their surface: the ejector must supply high FLOW at modest vacuum level (multi-stage ejectors, oversized cups with flow paths) rather than high vacuum at low flow.',
        'h' => 'Sealing cups with soft lips, larger gripping area (more holes paralleled), and continuous flow holding (no check-valve energy savers!) characterize porous handling. Grip verification uses flow-compensated vacuum switches.',
        's' => 'Cup material hard-wearing (cardboard is sandpaper): PU lasts. Estimate leak flow empirically — datasheets help only after the first test.',
        'a' => ['Carton erectors and palletizers.',
                'Wood and insulation-board handling.'],
        'x' => 'Switch a Studio cup from steel sheet to corrugated: watch vacuum level collapse and cure it with flow logic.'];
    $D[] = ['id' => 'pl-ckt-depalletizr', 't' => 'Vacuum layer handling with reserve tank', 'lv' => 'advanced', 'min' => 5,
        'sm' => 'The layer must stay held even when the plant hiccups: reserve volume and check valves.',
        'w' => 'A vacuum reserve tank with check valve per cup array keeps grip during ejector off-phases or supply dips; the vacuum switch supervises and refuses motion if reserve integrity is lost.',
        'h' => 'Sizing: reserve volume &times; allowable &Delta;vacuum must cover the hold-time times the leak flow (sum of cup leaks + porosity). Measure, then double it.',
        's' => 'Test reserve decay weekly (stop ejector, log decay seconds); the decay time IS your safety margin reading.',
        'a' => ['Depalletizing, large panel handling.',
                'Robot EOAT with safety-held loads.'],
        'x' => 'Dimension the Studio reserve tank for a 10 s ride-through; sabotage the supply and verify your margin by measurement.'];
    $D[] = ['id' => 'pl-ckt-hydro-feed', 't' => 'Hydro-pneumatic feed unit', 'lv' => 'advanced', 'min' => 6,
        'sm' => 'Compressed-air supply, hydraulic smoothness: the drilling feed without stick-slip.',
        'w' => 'An air-over-oil unit: air pressure drives an oil-filled damper cylinder inline with the working cylinder. Oil incompressibility plus an adjustable hydraulic throttle yields feed smoothness air alone never reaches.',
        'h' => 'Rapid approach via air path bypass, work feed via closed oil circuit through a precision needle valve: mm/s stability at any load variation, with automatic re-coupling of chambers on return.',
        's' => 'Oil level and bleed ritual keep it honest: air in the oil leg = spongy feed, diagnosed in seconds by the bubble in the sight glass.',
        'a' => ['Precision drilling/reaming units.', 'Feeding grinding or polishing heads with force constancy.'],
        'x' => 'Compare surface-finish-relevant speed stability: pure pneumatic vs hydro feed under varying Studio load.'];
    $D[] = ['id' => 'pl-ckt-balancer-tension', 't' => 'Weight balancing with precision regulator', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Counterweight in a hose: the axis feels weightless at any position.',
        'w' => 'A continuous pressure (precision-regulated, relieving!) on one cylinder chamber offsets the dead weight: motors/tools become feather-light on their guides (tool balancers, Z-axis assist).',
        'h' => 'Force must equal weight within the travel: pressure set = weight / area, verified at mid-stroke. Relieving regulator vents compression-backpressure on lowering — that is why precision-relieving types, not standard reducers.',
        's' => 'Air failure = sudden weight: pair with rod lock in vertical safety cases. Hysteresis of cheap regulators makes the axis drift-hunting — precision regulator quality shows here.',
        'a' => ['Manual tool manipulators.', 'Vertical axis assists on gantries.'],
        'x' => 'Balance a Studio tool axis to &plusmn;2 N residual force across the stroke; document the regulator reading per load.'];
    $D[] = ['id' => 'pl-ckt-door-dual', 't' => 'Guard door + presence + start: the permission chain', 'lv' => 'advanced', 'min' => 6,
        'sm' => 'Three truths before motion: door closed, part present, operator clear — AND them properly.',
        'w' => 'Safety-rated door switch into the safety relay; part-present and operator presence as process sensors into the PLC; the cycle start requires all three plus the restart condition. Pneumatic equivalent: door valve + part valve + start valve through AND cascades.',
        'h' => 'Safety functions separate from process functions: guard = hardwired rated channel, process conditions = PLC. Mixing a convenience sensor into the safety channel is a design sin.',
        's' => 'Tongue switches lie with worn doors: coded or RFID sensors with monitoring defeat operator bypassing fantasies.',
        'a' => ['Every cell with human-machine interaction.',
                'Audit preparation for machinery safety inspections.'],
        'x' => 'Build the permission chain in layers on the Studio bench; try the defeated-guard scenario and identify why the coded sensor refuses.'];
    $D[] = ['id' => 'pl-ckt-airexpansion-cold', 't' => 'Winterproofing a pneumatic machine', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Exhaust freezes at -5 &deg;C ambient when expansion does the local cooling to -40.',
        'w' => 'Expansion in valves and cylinders chills locally below the line dew point: iced silencers, stuck spools, brittle seals. Defense: pressure dew point at least 10 K below the coldest point (adsorption dryer!), insulated panels, heated cabinets for outdoor valves.',
        'h' => 'Ice forms preferentially downstream of metering edges (fast exhaust!) and at silencers. The first frosty morning reveals every marginal drain in the plant.',
        's' => 'Cold-weather kit: heated drain lines, antifreeze-rated lubricants where lubricators exist, winter-grade seals for mobile machines.',
        'a' => ['Outdoor cranes, gates, dock equipment.',
                'Unheated halls and night shifts in January.'],
        'x' => 'Set the Studio climate chamber to &minus;10 &deg;C and watch which simulated component ices first at your dew point setting; fix it by drying, not by praying.'];
    $D[] = ['id' => 'pl-ckt-cleanroom', 't' => 'Cleanroom exhaust management', 'lv' => 'advanced', 'min' => 5,
        'sm' => 'Every exhaust is particle emission: route it, filter it, or stop making it.',
        'w' => 'Cleanroom adaptations: exhaust air extraction lines from valve manifolds and cylinders to filters, grease-free (cleanroom lubricant) components, low-abrasion materials, laminar-avoidant layouts.',
        'h' => 'Cylinder rod retraction drags contaminated hall air into the tube: vacuum-drawn extraction collars around rod seals keep the class. ISO-class counting audits apply per class target.',
        's' => 'Standard solenoid valves with silencers emit oils and particles — manifold extraction piping at the valve terminal is the cleanroom standard configuration.',
        'a' => ['Semiconductor, pharma, food packaging lines.',
                'Optics assembly benches.'],
        'x' => 'Convert a Studio cell to cleanroom spec: list every emission point and its collection path.'];
    $D[] = ['id' => 'pl-ckt-sequence-troubleshoot', 't' => 'Troubleshooting logic: isolate level by level', 'lv' => 'intermediate', 'min' => 6,
        'sm' => 'Signal or power? Air or electric? The four-question method ends random part-swapping.',
        'w' => 'Method: 1) does the command reach the valve (LED / pilot gauge)? 2) does the spool shift (override button test)? 3) does flow reach the cylinder (exhaust hiss / throttle position)? 4) does the cylinder move free (mechanics decoupled)? The first NO localizes the fault to one level.',
        'h' => 'LED on + override moves it = command path problem. Override does nothing = valve/air path. Cylinder decoupled moves = mechanics/jam. Each answer excludes half the machine.',
        's' => 'Carry: one gauge, one plug connector LED, one manual override tool, one ears. Log findings — repeat faults love pattern blindness.',
        'a' => ['Shift-lead fault-finding drills.',
                'Training apprentices to troubleshoot like engineers (this exact drill).'],
        'x' => 'Solve four seeded faults in the Studio clinic with the four-question method only: no guessing allowed, document your levels.'];
    $D[] = ['id' => 'pl-ckt-costs-tco', 't' => 'Total-cost view of a pneumatic station', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'The valve costs &euro;40, its air over ten years costs &euro;900: buy data, not boxes.',
        'w' => 'Compressed air costs roughly 1-2 currency cents per Nm&sup3;. Stations run millions of cycles: consumption per cycle &times; cycles maps directly to money. Seal friction class, dead volume in fittings, and oversized cylinders pay sleepless bills.',
        'h' => 'Oversizing cylinders one bore up wastes ~40 % air per cycle forever. Dead legs and long tubes between valve and cylinder add dead volume consumption without work.',
        's' => 'TCO comparison in quotes: list price + 7-year air + expected maintenance stops. The cheap supplier often loses only on paper.',
        'a' => ['Purchasing negotiations with numbers.',
                'Efficiency retrofit business cases.'],
        'x' => 'Price the Studio reference station two ways (bore 50 vs 63) across 5 years and write the one-line management summary.'];
    $D[] = ['id' => 'pl-ckt-shift-cascade-comment', 't' => 'Sequence documentation that survives handover', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Displacement-step diagrams on the panel door: the operator manual engineers actually read.',
        'w' => 'Document sequences as displacement-step diagrams (position vs step) plus the signal matrix (which end sensor + conditions fire which valve). One A4 glued inside the cabinet saves hours per fault for decades.',
        'h' => 'The diagram reveals design errors before steel: crossing conditions and unterminated loops jump out visually. Review it in the design meeting like code.',
        's' => 'Update on every retrofit — out-of-date documentation is worse than none. Photograph the finished panel next to its diagram.',
        'a' => ['Maintenance handover packages.',
                'Design review ceremonies.'],
        'x' => 'Produce the displacement-step diagram for your Studio pick station and pin a red pen to it for the review meeting.'];
    return $D;
}

function rgz_ll_pne_fundamentals() {
    $D = [];
    $D[] = ['id' => 'pl-f-normal-liter', 't' => 'Normal liters vs operating liters', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'Nl/min, DN: the gas bill is counted at 1.013 bar, 20 &deg;C — everything else converts.',
        'w' => 'Compressed gas throughput uses normal liters: the volume the air would occupy at reference conditions (1.013 bar absolute, 20 &deg;C, dry). At 6 bar(g) working pressure one operating liter equals ~7 normal liters of consumption.',
        'h' => 'Confusing Nl/min with l/min is the classic 7&times; sizing error in both directions. Compressor FAD, valve ratings and consumption calculations all speak normal units.',
        'f' => 'Q<sub>N</sub> = Q<sub>op</sub> &times; (p<sub>abs</sub>/1.013) &times; (293/T)',
        's' => 'Always convert before comparing two datasheets; the humidity and temperature corrections matter for dryer loads in summer.',
        'a' => ['Compressor and dryer sizing.', 'Air consumption accounting.'],
        'x' => 'Convert all consumers of a Studio machine to Nl/min and verify the main pipe diameter against the table.'];
    $D[] = ['id' => 'pl-f-consumption', 't' => 'Cylinder air consumption calculation', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'Volume &times; strokes &times; pressure ratio: the two-line formula behind compressor sizing.',
        'w' => 'Consumption per cycle (Nl) = (cap volume + annulus volume) &times; (p<sub>abs</sub>/p<sub>0</sub>) plus the filling of dead spaces (tubes!). Rates: multiply by cycles/min for average demand; peaks handled by receivers.',
        'h' => 'Dead volumes dominate short-stroke, high-frequency machines: the tube from valve to cylinder refills every cycle without doing work. Cut it or pay for it permanently.',
        'f' => 'Q<sub>N</sub> = n &times; [A&middot;s&middot;(1 + (1 - d&sup2;/D&sup2;)) + V<sub>dead</sub>] &times; 7/1000',
        's' => 'Typical sanity number: &phi;50 &times; 200 mm at 6 bar, 30 cycles/min &asymp; 80 Nl/min average. Learn to estimate this in your head.',
        'a' => ['Air balance sheets.', 'Cylinder size debates (bore one step down saves ~35 %).'],
        'x' => 'Compute the Studio pick-station consumption, then drop one cylinder bore and recompute the yearly bill.'];
    $D[] = ['id' => 'pl-f-energy-bar', 't' => 'The price of one bar', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Every unnecessary bar of line pressure costs 6-8 % compressor energy.',
        'w' => 'Compression work rises with pressure ratio: dropping line pressure from 7 to 6 bar saves ~6-8 % electrical energy plant-wide, before counting reduced air demand (leak flow scales with pressure!).',
        'h' => 'Leak rate scales roughly with absolute pressure; unregulated consumption devices (open jets, nozzles) consume more at every extra bar. Dual effect: a 1 bar reduction is often worth a small car payment annually.',
        's' => 'Identify the real maximum need (usually one legacy consumer), solve it locally (booster! upsizing!), then drop the header.',
        'a' => ['Energy programs and ISO 50001 actions.', 'Plant pressure-down proposals.'],
        'x' => 'Model a header reduction in the Studio plant: find the limiting consumer and justify a booster for exactly that one.'];
    $D[] = ['id' => 'pl-f-leak-cost', 't' => 'Leak economics: the hole table', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'A 1 mm hole at 7 bar &asymp; 60 Nm&sup3;/h &asymp; four-figure annual waste.',
        'w' => 'Leaks are consumption without counter-force: typical uncontrolled plants lose 25-35 % of generated air. The physics: choked flow at every hole, proportional to area and absolute pressure.',
        'h' => 'Detection: ultrasonic gun during quiet hours, soapy water for confirmations. Priorities by sound pitch and measured flow — fixing the top five leaks usually halves the loss.',
        's' => 'Off-shift flow measurement (production zero) shows base leakage honestly; tag leaks with repair tickets, re-measure after, bank the difference.',
        'a' => ['Every energy audit.', 'Weekend shutdown supervision.'],
        'x' => 'Read the Studio plant night flow, price the leaks, and rank the repair list by euros per hour of labor.'];
    $D[] = ['id' => 'pl-f-regulator-droop', 't' => 'Regulator droop and hysteresis', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Set 6 bar static, get 5.2 bar flowing: the curve nobody reads until takt slips.',
        'w' => 'Downstream pressure of a spring regulator falls with flow (droop) and differs between rising and falling flow (hysteresis). Datasheet curves at a given inlet pressure tell the story: at rated flow the drop may exceed 1 bar.',
        'h' => 'Consequences: cylinder forces sag exactly during motion (when flow peaks), pressure switches set close to working pressure chatter, and regulators sized by pipe thread (not flow) underperform dramatically.',
        's' => 'Size regulators by their flow curve at your consumption plus margin; pilot-operated models droop far less at high flow.',
        'a' => ['Force-critical stations (clamping, press-in).',
                'Complaint diagnosis: works at night on low demand, fails at noon.'],
        'x' => 'Sweep flow on the Studio regulator, plot droop, then re-set working pressure from the DYNAMIC curve value.'];
    $D[] = ['id' => 'pl-f-dewpoint', 't' => 'Pressure dew point physics', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Why air that leaves the dryer dry still rains in your coldest pipe.',
        'w' => 'Air holds water vapor in proportion to TEMPERATURE, not pressure. Cooling compressed air (expansion, winter pipe runs) condenses the vapor; the pressure dew point (PDP) names the temperature at which condensation begins at actual line pressure.',
        'h' => 'Refrigeration dryer gives +3 &deg;C PDP: safe indoors. Outdoor winter &minus;10 &deg;C needs adsorption. Vapor load itself scales with inlet temperature exponentially — summer sizing matters.',
        's' => 'Monitor PDP online: a drifting dryer shows as rising PDP long before bowls fill. PDP alarm margin: 5 K below the coldest service point.',
        'a' => ['Dryer selection and monitoring.', 'Frost-related valve failures.'],
        'x' => 'Use the Studio weather module: compute required PDP for a &minus;15 &deg;C gate valve and choose the dryer class.'];
    $D[] = ['id' => 'pl-f-water-sources', 't' => 'Where condensate actually comes from', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'One cubic meter of summer air carries two spoonfuls of water into your compressor.',
        'w' => 'At 35 &deg;C / 80 % RH, inlet air holds ~32 g/m&sup3; water. Compression cannot destroy it: cooling the compressed stream drops most of it as condensate at aftercooler, receiver and first filters.',
        'h' => 'Plants learn to predict condensate: compressor FAD &times; humidity function &times; hours. The remaining vapor (after dryer) condenses only if local temperature falls below PDP.',
        's' => 'Condensate from lubricated compressors is oil-contaminated waste: separator treatment before sewer is a legal must in most regions.',
        'a' => ['Drain sizing.', 'Complaints of wet air downstream despite dryer (wrong PDP spec!).'],
        'x' => 'Compute daily condensate of a Studio plant from its weather profile and size the zero-loss drain schedule.'];
    $D[] = ['id' => 'pl-f-choked', 't' => 'Choked (sonic) flow in valves and leaks', 'lv' => 'advanced', 'min' => 6,
        'sm' => 'Above the critical ratio, downstream no longer matters: flow is frozen at Mach 1.',
        'w' => 'When downstream/upstream absolute pressure ratio falls below the critical value b (&asymp; 0.528 for ideal air nozzles), velocity at the narrowest point hits sonic speed and flow depends ONLY on upstream pressure. Extra pressure drop buys nothing downstream.',
        'h' => 'Practical rules: exhausting to atmosphere from &gt; 0.9 bar(g) is always choked — every leak behaves like a choked nozzle; half-open valves under high &Delta;p enter choked regime with strong noise.',
        'f' => 'm&#775;<sub>max</sub> = C &middot; p<sub>1</sub> &middot; &rho;<sub>N</sub> (ISO 6358 notation)',
        's' => 'For consumption estimates use C and p<sub>1</sub> only in choked conditions; sonic conductance data belongs in every valve datasheet (ISO 6358).',
        'a' => ['Leak-sound physics and flow extrapolation.',
                'Valve and nozzle sizing calculations.'],
        'x' => 'Sweep a Studio valve from 1 to 7 bar upstream and find the choking point from the flow curve kink.'];
    $D[] = ['id' => 'pl-f-tube-sizing', 't' => 'Tube sizing and pressure-drop budget', 'lv' => 'intermediate', 'min' => 5,
        'sm' => '6/4 tube feeds &phi;63 happily; &phi;125 needs 12/9: the ID chart that decides speed.',
        'w' => 'Tube ID, length and fittings define the line resistance to the cylinder. Rules: keep total &Delta;p (header + drops + tube) below ~0.5 bar at peak flow, velocity in mains 6-9 m/s, drops 10-15 m/s, direct lines to cylinders under 3 m wherever possible.',
        'h' => 'Equivalent-length method: each fitting counts as straight tube (elbow &asymp; 0.5 m, tee &asymp; 1 m) — a short line full of elbows can throttle like 5 extra meters.',
        's' => 'When speed lacks, measure &Delta;p DURING motion (instantaneous!): static pressure readings hide everything.',
        'a' => ['Panel and manifold design.', 'Cycle-time recovery projects.'],
        'x' => 'Instrument two tube options on the Studio fast cylinder and harvest the lost milliseconds per fitting.'];
    $D[] = ['id' => 'pl-f-cylinder-size', 't' => 'Cylinder sizing: bore, buckling, speed charts', 'lv' => 'beginner', 'min' => 6,
        'sm' => 'Force &times; 1.3-1.5, check the rod, then the speed diagram: three steps, no regrets.',
        'w' => 'Bore from required force with load factor: static duty 1.3, dynamic 1.5, high dynamics 2. Rod diameter from buckling tables per mounting style. Speed capability from manufacturer nomograms relating bore/supply/valve size to achievable velocity.',
        'h' => 'Oversized cylinders waste air every stroke (your compressor bill) and slow the valve dynamics. Undersized ones stall at midday pressure sags. The load-factor margin absorbs seal friction and pressure variation.',
        's' => 'End cushioning capacity check for mass &times; v&sup2;: above chart values specify external absorbers. Long-stroke push: buckling first!',
        'a' => ['Every actuator selection.', 'Energy-efficient redesign conversations.'],
        'x' => 'Size the Studio drill feed cylinder fully: force, buckling, speed per nomogram; verify in simulation with load at noon pressure dip.'];
    $D[] = ['id' => 'pl-f-friction-stick', 't' => 'Breakaway pressure and stick-slip', 'lv' => 'advanced', 'min' => 5,
        'sm' => 'The piston hesitates, then jumps: friction physics at low speed.',
        'w' => 'Static seal friction exceeds dynamic: at creeping speeds the piston stores pressure until breakaway, then accelerates and re-sticks — jerk motion (stick-slip). Typical breakaway 0.5-1.5 bar depending on seal type.',
        'h' => 'Low-friction seals, hydro-pneumatic feeds, or higher minimum speeds avoid the phenomenon; lubricated legacy cylinders stick less but carry oil everywhere.',
        's' => 'Select low-friction variants for slow feeds (&lt; 20 mm/s); stick-slip in measurement fixtures ruins data quietly.',
        'a' => ['Slow precision feeds.', 'Force measurement fixtures with pneumatic loading.'],
        'x' => 'Crawl a Studio cylinder at 5 mm/s and record the velocity ripple; switch seal class and repeat.'];
    $D[] = ['id' => 'pl-f-pne-vs-elec', 't' => 'Pneumatic vs electric axis: the honest comparison', 'lv' => 'intermediate', 'min' => 6,
        'sm' => 'Air wins on power density and toughness; electricity wins on energy and flexibility: choose per axis.',
        'w' => 'Pneumatics: unbeatable for end-to-end motion, clamping, harsh environments, overload stall safety, cost per axis. Electric: better for multi-position, precise profiling, energy per useful work, data capture (torque/position traces).',
        'h' => 'Energy truth: end-to-end compressed-air efficiency is maybe 10-20 % while electric axes exceed 80 % — at 24/7 duty the kWh decide. Occasional motion: pneumatics still wins by simplicity.',
        's' => 'Hybrid decisions per axis: clamping pneumatic, positioning electric is the classic packaging-machine pattern.',
        'a' => ['Machine concept phase.', 'Retrofit debates in efficiency programs.'],
        'x' => 'Score the Studio handling cell axis by axis on a decision matrix and defend each choice in a mock design review.'];
    $D[] = ['id' => 'pl-f-vacuum-physics', 't' => 'Vacuum level vs flow: reading ejector curves', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Maximum vacuum and maximum suction flow are different knobs: read the characteristic map.',
        'w' => 'Ejector curves plot achievable vacuum against free suction flow: at zero flow the highest vacuum (~85-92 %), at zero vacuum the highest flow. Workpieces with leaks (porous) operate down the curve — flow matters, level little.',
        'h' => 'Evacuation time for a known volume from atmosphere to target level derives from the integral of the curve (datasheet tables give it per liter). Multi-stage ejectors shift the cork: better suction at moderate levels per consumed watt of compressed air.',
        's' => 'Never specify maximum-vacuum ejectors for porous duty; oversized supply pressure does not compensate a physics mismatch.',
        'a' => ['Gripper design.', 'Cycle-time optimization of vacuum handling.'],
        'x' => 'Pick ejector classes for the Studio steel-sheet and carton tasks from their curves; defend both choices in one paragraph each.'];
    $D[] = ['id' => 'pl-f-efficiency-chain', 't' => 'End-to-end efficiency of compressed air', 'lv' => 'advanced', 'min' => 6,
        'sm' => 'From wall socket to piston work: 10-20 % survives — see every station steal its share.',
        'w' => 'Chain: motor (95 %) &times; compression (50-65 %: heat!) &times; dryer/purge (85 %) &times; leaks (65-75 %) &times; distribution (90 %) &times; device end efficiency (throttling, friction). Multiplying honest numbers explains the infamous overall figure.',
        'h' => 'Heat recovery re-discounts compression losses (up to 70-90 % of drive power recoverable as warm water/space heat) — the best plants reclaim most of the loss back into the kettle.',
        's' => 'Energy-efficient pneumatics: right pressure level, right bore, no leaks, idle shutoff, heat recovery. In that order.',
        'a' => ['ISO 50001 audits.', 'Compressor room business cases.'],
        'x' => 'Build the Studio chain for your plant case; name the top two levers with payback estimates.'];
    $D[] = ['id' => 'pl-f-compressor-control', 't' => 'Load/unload vs start-stop control', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Idling screws burn 30 % power for air they never deliver: control philosophy matters.',
        'w' => 'Start-stop suits small piston units with receivers (rest is free). Load-unload keeps screw compressors spinning unloaded for fast response — at a shocking 25-35 % of rated power doing nothing. VSD tracks demand continuously and wins on variable profiles.',
        'h' => 'Unloaded hours &times; 30 % rated kW is your audit number; receivers smooth the demand so more hours fall into true stop.',
        's' => 'Air-system controllers cascade multiple compressors and pick the efficient unit per load; retrofitting them on carrier fleets pays back yearly.',
        'a' => ['Compressor room optimization.', 'Night and weekend savings campaigns.'],
        'x' => 'Read the Studio duty profile; choose control mode and justify with kWh arithmetic.'];
    $D[] = ['id' => 'pl-f-commissioning', 't' => 'Commissioning a pneumatic machine: the checklist', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Blow before connect, bleed before bolt, slow before fast.',
        'w' => 'Order: visual/mechanical check (tube pulls, fitting torque, sensor targets), blow out lines BEFORE connecting valves, mist-free memory: connect, set service unit pressures low, jog every axis with manual overrides slow, then automatic at reduced speed, then full pressure/speed with documented settings.',
        'h' => 'Record: regulator readings, throttle positions (painted marks), sensor actuation points, cycle time, noise baseline. These baselines convert future troubleshooting from archaeology to reading.',
        's' => 'The first 8 hours logbook (faults + fixes + settings) is the warranty bible. Signatures make it honest.',
        'a' => ['Site acceptance tests.', 'Post-maintenance restarts.'],
        'x' => 'Run the Studio commissioning wizard in order; skip the line-blow step and receive your seeded valve jam.'];
    $D[] = ['id' => 'pl-f-maintenance', 't' => 'Pneumatic maintenance schedule', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'Weekly drains, monthly silencers, quarterly sensors: the small print of uptime.',
        'w' => 'Weekly: drains/bowls, leaks by ear, gauge plausibility. Monthly: silencer back-pressure feel, tube rub points, regulator setpoints drift. Quarterly: sensor switching points, cylinder speed baseline vs record, filter &Delta;p. Annual: dryer service, receiver inspection dates, pressure-switch calibration.',
        'h' => 'Trend small numbers rather than wait for failures: rising cycle time = silencer or seal; falling regulator reading = filter; rising night flow = new leaks.',
        's' => 'Spare kit discipline: the five most-swapped parts (silencers, tubes, seals kit, connectors, one valve slice) live in the cabinet.',
        'a' => ['Reliability programs.', 'New-hire maintenance training.'],
        'x' => 'Pull the Studio machine trend lines, call the next failure early, and schedule it before it schedules you.'];
    $D[] = ['id' => 'pl-f-symbols', 't' => 'Pneumatic symbols fluency (capstone)', 'lv' => 'beginner', 'min' => 6,
        'sm' => 'Triangles hollow, lines dashed for pilots: reading air schematics at speed.',
        'w' => 'Same ISO 1219 grammar as hydraulics with pneumatic dialect: unfilled triangles (air), exhausted arrows to atmosphere, service-unit chained symbols (separator &rarr; filter &rarr; regulator &rarr; lubricator), and the classic 3/2 and 5/2 boxes with actuation stacks.',
        'h' => 'Reading method: find the service unit, trace supply to valves, identify each actuator control path, decode pilot signals, verify every exhaust has somewhere to go.',
        's' => 'Practice reading the Studio example schematics until you can narrate each cycle: explaining aloud is the fluency test.',
        'a' => ['Every troubleshooting session.', 'Interview and certification exams.'],
        'x' => 'Complete the pneumatic symbol quiz track to 100 %; then read an unknown machine schematic narrating start, cycle and fault paths.'];
    $D[] = ['id' => 'pl-f-capstone-sorting', 't' => 'Capstone: design a sorting-station circuit', 'lv' => 'advanced', 'min' => 10,
        'sm' => 'Feed, detect, lift, sort two ways, count: one complete machine designed by you.',
        'w' => 'Specification: singulate parts from a magazine, detect metal/plastic, pusher sorts to channel A/B, counter batches by 10. Design: cylinder/valve selection with sizing numbers, sequence with sensor confirmations, E-stop with dump AND restart interlock, batch counter, and the complete documented schematic.',
        'h' => 'Expected moves: pusher sizing with load factor; 5/2 memory valves or PLC mapping; idle-return sensor placement; supervision timeouts; consumption calculation and service-unit chain specified per ISO 8573 class.',
        's' => 'Deliverables: schematic, sensor/valve list with ratings, consumption math, sequence diagram, settings sheet. Build it in the Studio and defend it in review.',
        'a' => ['Certification-style project.', 'Portfolio-grade design evidence.'],
        'x' => 'Complete the whole build in the Studio PLC tab with the report active; export the schematic as your capstone piece.'];
    $D[] = ['id' => 'pl-f-response-time', 't' => 'Valve response times and cycle-rate limits', 'lv' => 'advanced', 'min' => 5,
        'sm' => '15 ms on, 40 ms off: at 30 cycles per minute, milliseconds are the budget.',
        'w' => 'Solenoid valves publish ON and OFF response times (millisecond range). With cylinder fill/exhaust time, these define the maximum cycle rate of a function; exhaust throttles and long tubes degrade the far side of the budget.',
        'h' => 'AC coils switch slower than DC; large valves shift slower than small ones (spool mass!). For &gt; 5 Hz cycling, select high-cycle valves with reduced spool travel and solid-state driver.',
        's' => 'Compute the timing budget BEFORE promising takt: valve ON + fill + work + exhaust + OFF + sensor settle. The Studio chronometer view is your verification tool.',
        'a' => ['High-speed packaging machines.', 'Debates about that one slow station.'],
        'x' => 'Budget a 40/min Studio station down to milliseconds, find the limiting term, and improve exactly it.'];
    return $D;
}

function rgz_ll_pne_extra() {
    $D = [];
    $D[] = ['id' => 'pl-x-gauge', 't' => 'Pressure gauges on pneumatic panels', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'A &phi;40 gauge at the regulator answers 80 % of first-look questions.',
        'w' => 'Bourdon-tube gauges display line and working pressure; at the service unit they verify regulator settings at a glance. Glycerine filling damps pointer vibration near pulsating consumers.',
        'h' => 'Gauge class (&plusmn;1.6 % typical) matters for settings: a 0-16 bar gauge reads &plusmn;0.26 bar — set the 6.0 bar regulator with that in mind. Green/red arcs marked on the dial turn checks into glances.',
        's' => 'Isolate gauges from permanent pulsation with a gauge cock or snubber. Marked arc rings: working range green, forbidden red.',
        'a' => ['Every service unit and zone regulator.', 'Commissioning records (photograph the dials!).'],
        'x' => 'Task in the Studio: verify three regulator settings against class-1.6 gauges and write the uncertainty next to each reading.'];
    $D[] = ['id' => 'pl-x-manual-lever', 't' => 'Manual lever valves and joysticks', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'Direct hand control of cylinders: rugged, immediate, honest.',
        'w' => '5/2 or 5/3 hand-lever valves drive actuators directly on jigs, maintenance rigs and mobile equipment. Detented versions stay in position; spring-centered versions return to neutral.',
        'h' => 'Lever effort and grip placement define daily operator strain; panel layouts put the dangerous function under a guard flap. Detents carry the memory-valve risk discussion (unexpected motion on air return).',
        's' => 'Choose spring-center for inching motions (release = stop), detent for hold-definite states. Label motion direction AT the lever.',
        'a' => ['Assembly jigs and repair fixtures.', 'Crane and winch local controls.'],
        'x' => 'Rig a Studio jig with a detented lever; simulate air recovery after a break and debate the detent choice.'];
    $D[] = ['id' => 'pl-x-estop-mushroom', 't' => 'E-stop mushroom valves (pneumatic)', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'Red mushroom, yellow ring, latching: hit it and the machine exhales.',
        'w' => 'A large latching 3/2 valve on the panel dumps downstream air when struck; twist or key release re-arms it. It is an air-logic E-stop that works with zero electricity.',
        'h' => 'Behavior equals the electrical category-0 stop: exhausting is the safe state. Restart requires deliberate manual reset — accidental bump restarts are impossible by design.',
        's' => 'Size the exhaust path for the dump-time budget; downstream stored volumes (receivers!) need their own consideration. Position within reach but outside swing zones.',
        'a' => ['Pure pneumatic machines (ATEX, washdown).',
                'Supplementary local stops beside electrical systems.'],
        'x' => 'Place the mushroom valve on the Studio rig, run the cycle, strike, and verify both dump behavior and reset discipline.'];
    $D[] = ['id' => 'pl-x-impact', 't' => 'Impact (stamping) cylinders', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'Store pressure, release violently: tons of force for 20 milliseconds.',
        'w' => 'A large differential chamber is precharged; releasing the fast poppet fires the piston forward, converting stored gas energy into kinetic impact for stamping, marking, and punching.',
        'h' => 'Impact energy = stored pressure volume product over the reactable distance; repeated short-stroke hammering beats slow press force for brittle marking materials.',
        's' => 'Mounting must survive reaction shock (rigid, guided); NEVER at hand-near stations without two-hand + guard logic. Seals see spectaculaire wear — stock the kit.',
        'a' => ['Date/lot stamping presses.', 'Small punching stations.'],
        'x' => 'Cycle the Studio stamper; compute impact energy from chamber state and compare against the rivet requirement.'];
    $D[] = ['id' => 'pl-x-rotary-union', 't' => 'Rotary unions and rotary distributors', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'Air through the spinning joint: feeding actuators on rotating tables.',
        'w' => 'A sealed rotating interface passes one or more air channels across a continuously rotating joint (multi-channel coaxial designs for independent circuits). Leakage flows (controlled, small) are normal.',
        'h' => 'Channels keep pressure separation between circuits; the slip surfaces define life (speed &times; pressure derating curves). Air preparation upstream decides seal life more than the catalog does.',
        's' => 'Mount with a flexible link preventing torque; never let hoses carry the union. Spare-leakage budget belongs in the compressor balance.',
        'a' => ['Rotary indexing tables with clamped fixtures.',
                'Wind turbine pitch air service.'],
        'x' => 'Design the air routing for a Studio 4-station rotary table: count channels and justify each.'];
    $D[] = ['id' => 'pl-x-booster', 't' => 'Pneumatic pressure boosters', 'lv' => 'intermediate', 'min' => 5,
        'sm' => '10 bar locally from 6 bar plant air: the amplifier that saves the header pressure debate.',
        'w' => 'A double-piston amplifier compresses plant air to &asymp; 2&times; line pressure for one dedicated consumer (test rigs, clamping, valve actuation). Driven by air itself — no electrics, intrinsically stall-safe.',
        'h' => 'Driving consumption runs continuously while pumping; output flow is small (high ratio = low flow). A small receiver downstream stabilizes bursts.',
        's' => 'Perfect for one demanding consumer so the whole plant can drop one bar (the energy-accounting lesson in hardware). Outlet pressure regulation via pilot air pressure.',
        'a' => ['Leak-test stands and pressure proofing.', 'Local clamp circuits needing &gt; header.'],
        'x' => 'Power a Studio 10 bar test-bench consumer from the 6 bar network via booster; compute the drive-air cost versus header upgrade.'];
    $D[] = ['id' => 'pl-x-air-saver', 't' => 'Automatic air-saver units', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'Machine asleep, air asleep: pressure switches that cut supply after inactivity.',
        'w' => 'Battery/self-powered modules monitor flow or machine state and close the supply after X minutes of zero activity, restoring on demand signal. Standby leakage dies at the valve.',
        'h' => 'Plants with hundreds of branched stations harvest 10-20 % of total consumption by killing standby leaks at the branch level — payback months, logic trivial.',
        's' => 'Choose versions without continuous bleed. Integrate restart soft-start so wake-up does not slam the machine.',
        'a' => ['Three-shift plants with real resting periods.',
                'ISO 50001 quick wins.'],
        'x' => 'Fit air-savers in the Studio plant simulation, then compare the weekend consumption before and after.'];
    $D[] = ['id' => 'pl-x-ejector-control', 't' => 'Vacuum ejector control valves (suction/blow-off)', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'Two coils govern grip elegance: generate, hold, release with positive puff.',
        'w' => 'Compact vacuum valve blocks integrate ejector supply valve, blow-off valve, vacuum switch and optional check hold in one slice on the terminal: grip, transit, release with a timed positive pulse.',
        'h' => 'Blow-off pulse lengths of 50-150 ms free the part without launching it; the integrated switch gives grip confirmation as a PLC input.',
        's' => 'One slice per cup group (zone isolation!): one failed cup must not blind the rest. Flow restrictions per channel tame strong cups on small parts.',
        'a' => ['High-speed pick units.', 'Robot end-effectors with zone control.'],
        'x' => 'Configure a Studio vacuum slice with grip check + 80 ms blow-off; disrupt one cup and watch zone isolation earn its place.'];
    $D[] = ['id' => 'pl-x-vacuum-filter', 't' => 'Vacuum-side filters and inline screens', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'Dust rides the gripped surface into your ejector unless a filter says otherwise.',
        'w' => 'Inline vacuum filters between cups and ejector catch dust and debris before they clog the Venturi nozzle (whose bore is a millimeter-scale masterpiece of precision).',
        'h' => 'Filter resistance subtracts from suction capacity: select generously sized bodies, and check elements in dusty duty weekly. Transparent bowls show loading at a glance.',
        's' => 'Wood, cardboard, powder handling: filters are not optional there. Position accessible — a hidden filter is a forgotten filter.',
        'a' => ['Wood/carton handling.', 'Powder and granulate environments.'],
        'x' => 'Pollute a Studio cup stream with dust; observe evacuation-time decay and the restoration after element change.'];
    $D[] = ['id' => 'pl-x-inline-flow', 't' => 'Inline flow controllers and needle valves', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'The panel needle: coarse speed control and deliberate bleeds.',
        'w' => 'Simple needle valves throttle both directions (no check). Uses: approximate speed caps on non-critical motions, bleed-down rates for reservoirs, damping of gauge lines.',
        'h' => 'Temperature and oil-film shift their characteristic over weeks; for any speed that appears in a takt calculation, choose throttle-checks instead (repeatability + one-direction discipline).',
        's' => 'Mount with direction arrow? There is none — inline throttles are direction-blind, unlike throttle-checks. Paint the set screw after commissioning.',
        'a' => ['Reservoir charge/discharge timing.', 'Non-critical flap dampers.'],
        'x' => 'Time a Studio reservoir bleed through two needle settings; then repeat with a throttle-check and pick your standard.'];
    $D[] = ['id' => 'pl-x-breather', 't' => 'Panel breather/vents and exhaust routing', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'The cabinet must breathe: silenced, downward, and never into the photocell.',
        'w' => 'Valve exhausts inside panels vent through silencers or routed manifolds; the cabinet itself needs filtered breather paths so pressure pulses do not pop doors or push dust.',
        'h' => 'Exhaust aimed at optics/sensors fogs them with oil mist (lubricated systems!) — route down and away. In cleanroom or food zones exhaust leaves the enclosure entirely via hose.',
        's' => 'Sizing breathers: sum of worst-case exhaust flows must pass without +0.05 bar cabinet pressure (door seals!).',
        'a' => ['Control panel builds.', 'Food-zone machine retrofits.'],
        'x' => 'Audit a Studio cabinet photo: mark every exhaust and draw its route; fix the two silent crimes you will find there.'];
    $D[] = ['id' => 'pl-x-logic-family', 't' => 'Logic element family: AND, OR, NOT, YES, flip-flop', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Five blocks that build any Boolean machine out of air.',
        'w' => 'Beyond shuttle (OR) and dual-pressure (AND): NOT elements invert signals (output = supply when input absent), YES elements gate supply (output = supply when input present), and memory/flip-flop blocks latch states with set/reset ports.',
        'h' => 'With supply rails and these five blocks, any logic function is constructible: sequences, interlocks, alarms — the computational substrate for pure pneumatic controls.',
        's' => 'Signal pressure losses accumulate across cascaded elements: after three OR/AND stages, re-amplify via a YES relay fed from the rail.',
        'a' => ['Pure pneumatic control design.', 'Teaching digital logic with visible physics.'],
        'x' => 'Construct (start AND guard) OR (service key) logic from physical elements in the Studio logic lab; then read its truth table live.'];
    $D[] = ['id' => 'pl-x-low-friction', 't' => 'Low-friction and high-speed cylinder variants', 'lv' => 'advanced', 'min' => 4,
        'sm' => 'When 0.2 bar breakaway or 3 m/s matters, ordinary cylinders stay home.',
        'w' => 'Low-friction cylinders (special seals, polished tubes, grease filling) reach breakaway &lt; 0.2 bar for servo-pneumatic and regulation duty; high-speed variants (special cushioning, seals, guides) run to 3 m/s continuously.',
        'h' => 'These trade leakage and lifetime for performance: low-friction leaks more (regulation circuits accept it), high-speed seals wear to a plan (spares on the shelf).',
        's' => 'Servo-pneumatic positioning loops specify low-friction always — the hysteresis of standard seals destabilizes any control effort.',
        'a' => ['Servo-pneumatic fence/position axes.', 'Rapid reject flaps on 600/min lines.'],
        'x' => 'Try standard vs low-friction in the Studio servo-pneumatic axis; log the positioning error band.'];
    $D[] = ['id' => 'pl-x-datasheets', 't' => 'Reading pneumatic datasheets like a lawyer', 'lv' => 'intermediate', 'min' => 5,
        'sm' => 'Nominal flow at WHICH dp, force at WHICH pressure, life at WHICH side load — footnotes rule.',
        'w' => 'Headline numbers hide conditions: nominal flow at 6&rarr;5 bar differs from Cv; theoretical force ignores friction (&asymp; 10 %); cushioning ratings assume specific mass and speed; sensor repeatability presumes clean supply.',
        'h' => 'Method: find the test condition behind every number (pressure, temperature, side load, mounting), convert to YOUR condition, apply margin honestly. Two brands until now have never meant the same thing by the same word.',
        's' => 'When the footnote is missing, ASK. The answer (or silence) is supplier intelligence worth more than the number.',
        'a' => ['Cross-brand replacements.', 'Quote comparisons and dispute defense.'],
        'x' => 'Compare two Studio datasheets for a &phi;63 cylinder; extract the real comparable numbers and write a one-page verdict.'];
    $D[] = ['id' => 'pl-x-airquality-monitor', 't' => 'Air-quality monitoring points', 'lv' => 'advanced', 'min' => 4,
        'sm' => 'Dew point, particles, oil vapor: sensors where the ISO class must be proven.',
        'w' => 'Continuous monitors (PDP sensor after dryer, particle counter at critical class-1 points, oil-vapor analyzer for food lines) document quality continuously instead of audit-eve sampling.',
        'h' => 'Alarm philosophy: PDP rising = dryer degrading; particle step = filter breakthrough; trend lines justify maintenance with evidence rather than schedule folklore.',
        's' => 'Sampling points per ISO 8573 methodology: isokinetic, short lines, stainless where required — sloppy sampling certifies fiction.',
        'a' => ['Food/pharma validated lines.', 'Compressors rooms with borrowed credibility.'],
        'x' => 'Place monitors in the Studio plant where each ISO class must be proven; write the alarm thresholds into the audit plan.'];
    $D[] = ['id' => 'pl-x-tension-web', 't' => 'Web tensioning with cylinders', 'lv' => 'advanced', 'min' => 5,
        'sm' => 'Constant force over a moving roll: precision regulators keeping paper humble.',
        'w' => 'A cylinder loads the dancer roll with constant force = half the desired web tension (dancer geometry); the precision relieving regulator holds pressure against load changes, converting air into spring-free constant force.',
        'h' => 'Relieving capability is the trick: dancer movement charges and discharges the chamber without hysteresis piles. Damping via throttle in the pilot path calms web flutter.',
        's' => 'Low-friction cylinders hysteresis-free preferred; keep rod guidance clean (web dust!). Force-integrity scales with regulator quality.',
        'a' => ['Printing and converting lines.', 'Wire/foil winding machines.'],
        'x' => 'Set the Studio dancer to 40 N web tension; induce a roll-speed step and watch the regulator hold force within its characteristic.'];
    $D[] = ['id' => 'pl-x-hydraulic-versus-cheat', 't' => 'When pneumatics borrows hydraulics: air-over-oil systems', 'lv' => 'advanced', 'min' => 5,
        'sm' => 'Air plant, oil cylinder: 10,000 smooth Newtons without a hydraulic power pack.',
        'w' => 'Air-over-oil converters pressurize a closed oil volume from plant air: double-acting-ish hydraulic performance (rigidity, smoothness, high force via intensifier versions) at machines without hydraulic infrastructure.',
        'h' => 'Classic architectures: converter + oil cylinder for single pushes; hydro-check tandem unit for constant feed speeds; air-hydraulic intensifier + small cylinder for clamping kN ranges.',
        's' => 'Bleed points, oil quality (ISO VG 32-46), and temperature effects inherit from hydraulics — the relevant lessons apply unchanged.',
        'a' => ['Clamping fixtures on air-only plants.', 'Upgrade path before buying a hydraulic station.'],
        'x' => 'Compare installs: air-over-oil vs small HPU for the Studio 15 kN clamp case; pick with a total-cost one-liner.'];
    $D[] = ['id' => 'pl-x-parameter-sticky', 't' => 'Settings discipline: paint, plates and sealable covers', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'A found needle position is an asset: protect it from thumbs.',
        'w' => 'Every tuned throttle/regulator gets: paint mark or sticker on the set position, the value on the settings sheet in the cabinet door, and where abuse is likely a cover or administrator-locked knob.',
        'h' => 'Half of the operator-induced downtime comes from adjusted-never-restored knobs. Settings sheets turn Thursday-night faults into three-minute recoveries.',
        's' => 'Photograph panels after commissioning: the photo IS version control. Setup sheets list only what changes between product variants.',
        'a' => ['Shift-dense plants.', 'Multi-variant machines with changeovers.'],
        'x' => 'Write the settings sheet for your Studio capstone machine: every needle, every regulator, every threshold, marked.'];
    $D[] = ['id' => 'pl-x-first-spare', 't' => 'The strategic spare parts shelf', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'Five boxes that save five nights: silencers, coil, sensor, seals, one valve slice.',
        'w' => 'Analysis of downtime on pneumatic machines points at a tiny set: clogged silencers, dead coils, drifted sensors, worn cylinder seals, broken connectors/tubes. Stocking exactly these covers most incidents at trivial cost.',
        'h' => 'Consumables with defined service lives belong in the maintenance plan with quantities (silencers per year!). Critical single-sourced valves deserve one backup each if lead time &gt; 3 days.',
        's' => 'Shelf discipline: labeled, quantities visible, withdrawal logged — a ransacked shelf is a false friend.',
        'a' => ['Spare-part policy.', 'Insurance against supply-chain mood swings.'],
        'x' => 'Define the shelf for the Studio capstone machine from its component count and lead times.'];
    return $D;
}

function rgz_ll_pne_bonus() {
    $D = [];
    $D[] = ['id' => 'pl-x-cushion-chart', 't' => 'Reading cushioning capacity charts', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'Mass versus speed at the end stop: two axes that decide between cushion and shock absorber.',
        'w' => 'Every cylinder datasheet includes a cushioning diagram: allowed moving mass against impact speed for built-in cushions. Points above the curve demand external shock absorbers or speed reduction.',
        'h' => 'Chart reading ritual: compute your mass &times; v&sup2;/2, find the speed on the diagram (with load!), if above the line — walk to the absorber catalog. Pressure reductions shift curves down derating at lower supply.',
        's' => 'Horizontal vs vertical mounting matters (gravity adds energy!). Vertical downward impact gets weight &times; stroke added to kinetic energy.',
        'a' => ['Every cylinder selection with speed.', 'Damage investigations of end-cap cracks.'],
        'x' => 'Plot three Studio cases on a real cushion chart: pass the chart test twice, fail once, and know exactly why.'];
    $D[] = ['id' => 'pl-x-festo-trainer', 't' => 'Laboratory hygiene: air discipline in training rigs', 'lv' => 'beginner', 'min' => 4,
        'sm' => 'A tidy panel with labeled ports teaches more than the component list.',
        'w' => 'Training-rig lessons for life: tubes cut square with the cutter, push-in verified by pull test, ports labeled with destination, exhausts silenced, schematic pinned to the rig, tools returned.',
        'h' => 'Lab discipline mirrors plant discipline: the person who labels the test bench labels the machine; the one who blows lines before connecting saves seals in both worlds.',
        's' => 'Rituals: 60-second end-of-session reset (valves to rest, pressure released, regulator backed out) means the next session starts at zero energy — safety as habit.',
        'a' => ['Every Festo/HPG workshop.', 'Internal company academies.'],
        'x' => 'Adopt the reset ritual in the Studio lab mode; the checklist at session end is part of the grade.'];
    $D[] = ['id' => 'pl-x-error-clinic', 't' => 'Error clinic: the twelve classic pneumatic faults', 'lv' => 'intermediate', 'min' => 7,
        'sm' => 'Slow retract, weekend pressure loss, jitter, midnight fault: recognize each by signature.',
        'w' => 'Field-proven signatures: slow retract = clogged silencer or crushed exhaust tube; weekend loss = leak; jitter at start = dried cylinder or dead volume; midnight fault = pressure sag when a neighbor machine starts; random stop = chattering pressure switch; water in bowls Monday = dryer duty undersized; cylinder drifts = 5/3 closed center reality; gripper drops = vacuum switch threshold; soft handles everywhere = meter-in throttling; banging ends = cushion needle open; coil death weekly = AC inrush on sticking spool; phantom sensor signals = weld field or crosstalk.',
        'h' => 'Each signature maps to ONE subsystem check first. Build your site list from these twelve and MTTR halves.',
        's' => 'Write them on the maintenance-room wall; add your site-specific thirteenth when discovered.',
        'a' => ['On-call troubleshooting.', 'Apprentice final exam scenarios.'],
        'x' => 'Run the Studio fault clinic: identify 12 out of 12 seeded faults from their signatures alone.'];
    return $D;
}

/* ------------------------------------------------------------------ */
/* Merge helper: all rows of one topic as hub lessons                  */
/* ------------------------------------------------------------------ */
function rgz_ll_lessons($topic) {
    if ($topic === 'cad') { $map = ['rgz_ll_cad_lessons']; }
    else { $map = ($topic === 'hydraulics')
        ? ['rgz_ll_hyd_elements', 'rgz_ll_hyd_patterns', 'rgz_ll_hyd_fundamentals']
        : ['rgz_ll_pne_elements', 'rgz_ll_pne_valves', 'rgz_ll_pne_actuators', 'rgz_ll_pne_patterns', 'rgz_ll_pne_patterns2', 'rgz_ll_pne_fundamentals', 'rgz_ll_pne_extra', 'rgz_ll_pne_bonus']; }
    $out = [];
    foreach ($map as $fn) {
        if (function_exists($fn)) {
            foreach ((array) $fn() as $r) { $out[] = rgz_ll_lesson($r, $topic); }
        }
    }
    return $out;
}

function rgz_ll_cover($id, $topic) {
    $base = plugin_dir_url(__FILE__) . 'assets/learn/';
    if ($topic === 'cad') { return $base . 'cov-cad-elements.svg'; }
    $kind = 'elements';
    if (strpos($id, '-ckt-') !== false) { $kind = 'circuits'; }
    elseif (strpos($id, 'hl-f-') === 0 || strpos($id, 'pl-f-') === 0) { $kind = 'fundamentals'; }
    return $base . 'cov-' . ($topic === 'hydraulics' ? 'hyd' : 'pne') . '-' . $kind . '.svg';
}

/* ------------------------------------------------------------------ */
/* Illustration engine: blueprint-style SVG figure for every lesson    */
/* (component lessons get their ISO-style symbol, pattern lessons a    */
/*  mini schematic, fundamentals a concept glyph — all drawn inline)   */
/* ------------------------------------------------------------------ */
function rgz_ll_svg_open($label) {
    return '<svg viewBox="0 0 340 210" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="' . esc_attr($label) . ' illustration" preserveAspectRatio="xMidYMid meet">'
        . '<rect x="0.5" y="0.5" width="339" height="209" rx="12" fill="#f3f7fc" stroke="#d4e0ee"/>'
        . '<g stroke="#dde8f4" stroke-width="1">'
        . '<path d="M20 0V210M60 0V210M100 0V210M140 0V210M180 0V210M220 0V210M260 0V210M300 0V210M0 30H340M0 70H340M0 110H340M0 150H340M0 190H340"/></g>'
        . '<text x="13" y="200" font-family="system-ui,sans-serif" font-size="9" font-weight="700" letter-spacing="1.5" fill="#93a8c4">' . esc_html(strtoupper(strlen($label) > 42 ? substr($label, 0, 41) . '…' : $label)) . '</text>';
}
function rgz_ll_sz($x, $y, $s, $inner) {
    return '<g transform="translate(' . $x . ' ' . $y . ') scale(' . $s . ')">' . $inner . '</g>';
}
/* Mini ISO-style symbol painters — each draws inside a 0..60 × 0..60 box.
   $acc = highlight accent color for the element the lesson is about. */
function rgz_ll_sym($type, $acc = '#EB4E3C') {
    $I = '#22405f'; // ink
    $T = '#8fb0d4'; // thin blue
    $W = '#ffffff';
    $A = $acc;
    $tri = function ($filled, $flip) use ($I) {
        $d = $flip ? 'M20 20 L42 30 L20 40 Z' : 'M40 20 L18 30 L40 40 Z';
        return '<path d="' . $d . '" fill="' . ($filled ? $I : 'none') . '" stroke="' . $I . '" stroke-width="2" stroke-linejoin="round"/>';
    };
    $spring = '<path d="M52 14 l5 5 -10 6 10 6 -10 6 7 7" fill="none" stroke="' . $I . '" stroke-width="1.8"/>';
    switch ($type) {
        case 'pump':
            return '<circle cx="30" cy="30" r="17" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>' . $tri(true, true) . '<path d="M30 5 V-6 M13 30 H-8 M47 30 H68" stroke="' . $I . '" stroke-width="2"/><title>Pump</title>';
        case 'vpump':
            return '<circle cx="30" cy="30" r="17" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>' . $tri(true, true) . '<path d="M18 48 L44 12 M42 10 l4 0 -2 4" fill="none" stroke="' . $A . '" stroke-width="2"/><path d="M13 30 H-8 M47 30 H68" stroke="' . $I . '" stroke-width="2"/><title>Variable pump</title>';
        case 'motor':
            return '<circle cx="30" cy="30" r="17" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>' . $tri(true, false) . '<path d="M30 5 V-6 M13 30 H-8 M47 30 H68" stroke="' . $I . '" stroke-width="2"/><title>Hydraulic motor</title>';
        case 'compressor':
            return '<circle cx="30" cy="30" r="17" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>' . $tri(false, true) . '<path d="M30 5 V-6 M13 30 H-8 M47 30 H68" stroke="' . $I . '" stroke-width="2"/><title>Compressor</title>';
        case 'airmotor':
            return '<circle cx="30" cy="30" r="17" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>' . $tri(false, false) . '<path d="M13 30 H-8 M47 30 H68" stroke="' . $I . '" stroke-width="2"/><title>Air motor</title>';
        case 'cyl': case 'cylda':
            return '<rect x="4" y="18" width="34" height="24" rx="2" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<rect x="16" y="20" width="4" height="20" fill="' . $I . '"/>'
                . '<path d="M20 30 H56" stroke="' . $I . '" stroke-width="3.4"/>'
                . '<path d="M4 24 h-8 M4 36 h-8" stroke="' . $T . '" stroke-width="2" stroke-dasharray="3 2"/><title>Double-acting cylinder</title>';
        case 'cylsa':
            return '<rect x="6" y="18" width="32" height="24" rx="2" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<rect x="16" y="20" width="4" height="20" fill="' . $I . '"/>'
                . '<path d="M20 30 H50" stroke="' . $I . '" stroke-width="3.2"/>'
                . '<path d="M34 22 l6 8 -6 8 6 -8" fill="none" stroke="' . $A . '" stroke-width="1.6"/><title>Single-acting cylinder</title>';
        case 'telescopic':
            return '<rect x="4" y="16" width="14" height="28" rx="2" fill="' . $W . '" stroke="' . $I . '" stroke-width="2"/>'
                . '<rect x="18" y="20" width="14" height="20" fill="' . $W . '" stroke="' . $I . '" stroke-width="2"/>'
                . '<rect x="32" y="24" width="14" height="12" fill="' . $W . '" stroke="' . $I . '" stroke-width="2"/>'
                . '<path d="M46 30 H58" stroke="' . $I . '" stroke-width="3"/><title>Telescopic cylinder</title>';
        case 'rotary':
            return '<circle cx="28" cy="30" r="16" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M28 30 V14 M28 30 L40 38" stroke="' . $I . '" stroke-width="2.4"/>'
                . '<path d="M50 22 a16 16 0 1 1 -6 18" fill="none" stroke="' . $A . '" stroke-width="2" marker-end=""/>'
                . '<path d="M44 40 l2 6 -6 -2" fill="none" stroke="' . $A . '" stroke-width="2"/><title>Rotary actuator</title>';
        case 'gripper':
            return '<circle cx="30" cy="38" r="9" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M26 32 L16 12 M34 32 L44 12" stroke="' . $I . '" stroke-width="3" stroke-linecap="round"/>'
                . '<path d="M16 12 l6 2 M44 12 l-6 2" stroke="' . $I . '" stroke-width="3" stroke-linecap="round"/><title>Gripper</title>';
        case 'dcv22':
            return '<rect x="14" y="16" width="20" height="28" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<rect x="34" y="16" width="20" height="28" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M18 20 L30 40 M18 40 L30 20 M38 20 V40" stroke="' . $I . '" stroke-width="1.8"/>'
                . '<path d="M42 20 v20" stroke="' . $I . '" stroke-width="0"/><path d="M40 22 h6 v6 h-6 z" fill="none"/><title>2/2-way valve</title>';
        case 'dcv43':
            return '<rect x="4" y="16" width="17" height="28" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<rect x="21" y="16" width="17" height="28" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<rect x="38" y="16" width="17" height="28" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M25 20 L34 40 M34 20 L25 40" stroke="' . $I . '" stroke-width="1.8"/>'
                . '<path d="M8 20 L17 34 M8 40 V24 M42 20 L51 34 M51 20 V40 M46 20 V40" stroke="' . $I . '" stroke-width="1.6"/>'
                . '<path d="M-2 14 v-8 M61 14 v-8" stroke="' . $T . '" stroke-width="2"/><title>4/3-way valve</title>';
        case 'dcv52':
            return '<rect x="13" y="16" width="17" height="28" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<rect x="30" y="16" width="17" height="28" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M16 20 L27 38 M16 38 L27 20 M33 20 L44 38 M33 38 L44 20" stroke="' . $I . '" stroke-width="1.6"/>'
                . '<path d="M20 44 v8 M24 44 v8 M36 44 v8 M40 44 v8" stroke="' . $I . '" stroke-width="1.4"/><title>5/2-way valve</title>';
        case 'dcv53':
            return '<rect x="4" y="16" width="17" height="28" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<rect x="21" y="16" width="17" height="28" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<rect x="38" y="16" width="17" height="28" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M24 22 h4 v4 h-4 z M24 34 h4 v4 h-4 z M31 22 h4 v4 h-4 z M31 34 h4 v4 h-4 z" fill="' . $I . '"/>'
                . '<path d="M8 20 L17 38 M8 38 V20 M42 20 L51 38 M51 20 V38" stroke="' . $I . '" stroke-width="1.6"/><title>5/3-way valve</title>';
        case 'prop':
            return '<rect x="4" y="16" width="51" height="28" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M25 20 L34 40 M34 20 L25 40" stroke="' . $I . '" stroke-width="1.8"/>'
                . '<path d="M4 10 h51 M4 50 h51" stroke="' . $A . '" stroke-width="1.6"/>'
                . '<rect x="-8" y="24" width="12" height="12" fill="' . $W . '" stroke="' . $I . '" stroke-width="1.8"/>'
                . '<path d="M-8 24 l12 12" stroke="' . $I . '" stroke-width="1.4"/><title>Proportional valve</title>';
        case 'servo':
            return '<rect x="16" y="18" width="28" height="24" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M24 22 L36 38 M36 22 L24 38" stroke="' . $I . '" stroke-width="1.8"/>'
                . '<path d="M16 12 h28 M16 48 h28" stroke="' . $A . '" stroke-width="1.6"/>'
                . '<circle cx="8" cy="30" r="5" fill="' . $W . '" stroke="' . $I . '" stroke-width="1.8"/><title>Servo valve</title>';
        case 'relief':
            return '<rect x="14" y="16" width="26" height="28" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M18 38 L36 22" stroke="' . $I . '" stroke-width="2"/><path d="M36 22 l-8 2 4 6 z" fill="' . $I . '"/>'
                . '<path d="M46 14 l4 5 -8 5 8 5 -8 5 6 7" fill="none" stroke="' . $I . '" stroke-width="1.6"/>'
                . '<path d="M27 46 V56" stroke="' . $T . '" stroke-width="2" stroke-dasharray="3 2"/><title>Relief valve</title>';
        case 'reducing':
            return '<rect x="14" y="16" width="26" height="28" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M18 32 L36 32" stroke="' . $I . '" stroke-width="2"/><path d="M36 30 l6 2 -6 2 z" fill="' . $I . '"/>'
                . '<path d="M46 14 l4 5 -8 5 8 5 -8 5 6 7" fill="none" stroke="' . $I . '" stroke-width="1.6"/>'
                . '<path d="M34 44 q6 8 0 12 l-8 6" fill="none" stroke="' . $T . '" stroke-width="1.6" stroke-dasharray="3 2"/><title>Pressure reducing valve</title>';
        case 'sequence':
            return '<rect x="14" y="16" width="26" height="28" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M18 38 L36 22" stroke="' . $I . '" stroke-width="2"/><path d="M36 22 l-8 2 4 6 z" fill="' . $I . '"/>'
                . '<path d="M46 14 l4 5 -8 5 8 5 -8 5 6 7" fill="none" stroke="' . $A . '" stroke-width="1.6"/>'
                . '<path d="M10 46 q10 8 22 4" fill="none" stroke="' . $T . '" stroke-width="1.6" stroke-dasharray="3 2"/><title>Sequence valve</title>';
        case 'check':
            return '<circle cx="24" cy="30" r="6" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M31 22 L42 38 M31 38 L42 22" stroke="none"/><path d="M32 24 l10 12 M42 24 l-10 12" stroke="none"/>'
                . '<path d="M32 22 v16 h10" fill="none" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M4 30 H18 M42 30 H56" stroke="' . $I . '" stroke-width="2.2"/><title>Check valve</title>';
        case 'pcheck':
            return '<circle cx="24" cy="30" r="6" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M32 22 v16 h10" fill="none" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M4 30 H18 M42 30 H56" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M24 36 v10 h20" fill="none" stroke="' . $A . '" stroke-width="1.8" stroke-dasharray="3 2"/>'
                . '<rect x="38" y="44" width="12" height="8" fill="' . $W . '" stroke="' . $A . '" stroke-width="1.8"/><title>Pilot-operated check</title>';
        case 'throttle':
            return '<path d="M4 30 H56" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M18 22 q12 -8 24 0 M18 38 q12 8 24 0" fill="none" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M16 44 L44 16 M42 14 l4 0 -2 4" fill="none" stroke="' . $A . '" stroke-width="2"/><title>Throttle valve</title>';
        case 'flowpc':
            return '<rect x="12" y="14" width="36" height="32" fill="' . $W . '" stroke="' . $I . '" stroke-width="2"/>'
                . '<path d="M18 24 q6 -5 12 0 M18 32 q6 5 12 0" fill="none" stroke="' . $I . '" stroke-width="1.8"/>'
                . '<path d="M6 30 H12 M48 30 H54" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M30 46 v6 h18" fill="none" stroke="' . $A . '" stroke-width="1.6" stroke-dasharray="3 2"/><title>PC flow control</title>';
        case 'shuttle':
            return '<path d="M18 16 L42 16 L52 30 L42 44 L18 44 L8 30 Z" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<circle cx="30" cy="30" r="5" fill="' . $W . '" stroke="' . $I . '" stroke-width="2"/>'
                . '<path d="M4 30 H8 M52 30 H56 M18 16 V8 M42 16 V8" stroke="' . $I . '" stroke-width="2"/><title>Shuttle valve (OR)</title>';
        case 'and':
            return '<path d="M18 16 L42 16 L52 30 L42 44 L18 44 L8 30 Z" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<rect x="24" y="24" width="12" height="12" fill="' . $W . '" stroke="' . $A . '" stroke-width="2"/>'
                . '<path d="M4 30 H8 M52 30 H56 M18 44 v8 M42 44 v8" stroke="' . $I . '" stroke-width="2"/><title>Dual pressure valve (AND)</title>';
        case 'qexhaust':
            return '<path d="M18 16 L42 16 L52 30 L42 44 L18 44 L8 30 Z" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<circle cx="30" cy="30" r="6" fill="' . $W . '" stroke="' . $I . '" stroke-width="2"/>'
                . '<path d="M30 44 v8" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M22 54 h16 l-8 8 z" fill="' . $I . '"/><title>Quick exhaust</title>';
        case 'accum':
            return '<circle cx="30" cy="26" r="14" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M20 20 q10 12 20 0" fill="none" stroke="' . $A . '" stroke-width="2"/>'
                . '<rect x="26" y="40" width="8" height="14" fill="' . $W . '" stroke="' . $I . '" stroke-width="2"/>'
                . '<path d="M18 54 h24" stroke="' . $I . '" stroke-width="2.2"/><title>Accumulator</title>';
        case 'filter':
            return '<path d="M30 10 L50 30 L30 50 L10 30 Z" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M34 16 L16 44 M40 22 L20 44" stroke="' . $T . '" stroke-width="1.6" stroke-dasharray="2 2"/><title>Filter</title>';
        case 'cooler':
            return '<path d="M30 10 L50 30 L30 50 L10 30 Z" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M20 30 h20 M30 20 v20 M23 23 l14 14 M37 23 l-14 14" stroke="' . $A . '" stroke-width="1.6"/><title>Cooler</title>';
        case 'heater':
            return '<path d="M30 10 L50 30 L30 50 L10 30 Z" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M18 34 q6 -8 12 0 q6 8 12 0" fill="none" stroke="' . $A . '" stroke-width="2"/><title>Heater</title>';
        case 'gauge':
            return '<circle cx="30" cy="28" r="16" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M30 28 L38 18" stroke="' . $A . '" stroke-width="2.4" stroke-linecap="round"/>'
                . '<circle cx="30" cy="28" r="2.4" fill="' . $I . '"/>'
                . '<path d="M30 16 v4 M20 20 l3 3 M40 20 l-3 3" stroke="' . $I . '" stroke-width="1.4"/>'
                . '<path d="M30 44 V56" stroke="' . $I . '" stroke-width="2.2"/><title>Pressure gauge</title>';
        case 'tank':
            return '<path d="M12 14 h36 v30 h-36 z" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M12 14 h36" stroke="' . $I . '" stroke-width="0"/><path d="M16 34 q8 -5 14 0 q8 5 14 0" fill="none" stroke="#3b82c4" stroke-width="2"/>'
                . '<path d="M8 44 h44" stroke="' . $I . '" stroke-width="2.4"/>'
                . '<path d="M30 44 V56" stroke="' . $I . '" stroke-width="2.2"/><title>Tank</title>';
        case 'receiver':
            return '<ellipse cx="30" cy="30" rx="22" ry="16" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M30 46 v12 M20 52 h20" stroke="' . $I . '" stroke-width="2.2"/><title>Air receiver</title>';
        case 'frl':
            return '<rect x="2" y="16" width="16" height="26" fill="' . $W . '" stroke="' . $I . '" stroke-width="2"/>'
                . '<rect x="22" y="16" width="16" height="26" fill="' . $W . '" stroke="' . $I . '" stroke-width="2"/>'
                . '<rect x="42" y="16" width="16" height="26" fill="' . $W . '" stroke="' . $I . '" stroke-width="2"/>'
                . '<path d="M10 22 v12 M30 20 l0 6 M50 24 v10" stroke="' . $A . '" stroke-width="1.6"/>'
                . '<path d="M18 29 H22 M38 29 H42" stroke="' . $I . '" stroke-width="2"/><title>FRL service unit</title>';
        case 'lubricator':
            return '<rect x="16" y="14" width="28" height="30" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M30 20 q-6 10 0 12 q6 -2 0 -12 z" fill="' . $A . '"/>'
                . '<path d="M4 29 H16 M44 29 H56" stroke="' . $I . '" stroke-width="2.2"/><title>Lubricator</title>';
        case 'silencer':
            return '<path d="M22 16 h16 l8 28 h-32 z" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M26 24 h8 M25 30 h10 M24 36 h12" stroke="' . $T . '" stroke-width="1.6"/>'
                . '<path d="M30 44 v10" stroke="' . $I . '" stroke-width="2.2"/><title>Silencer</title>';
        case 'ejector':
            return '<path d="M8 26 h14 l8 -8 v24 l-8 -8 H8" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M38 26 h14 M45 26 l-6 12 M48 12 v10 M52 16 v6" stroke="' . $A . '" stroke-width="1.8"/>'
                . '<path d="M30 14 v-6" stroke="' . $I . '" stroke-width="2"/><title>Vacuum ejector</title>';
        case 'cup':
            return '<path d="M30 8 v10" stroke="' . $I . '" stroke-width="2.4"/>'
                . '<path d="M18 18 h24 v6 q0 14 -12 14 q-12 0 -12 -14 z" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M20 40 h20" stroke="' . $A . '" stroke-width="2"/><title>Suction cup</title>';
        case 'sensor':
            return '<path d="M30 12 L48 30 L30 48 L12 30 Z" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M22 30 h-10 M38 30 h10" stroke="' . $I . '" stroke-width="2"/>'
                . '<path d="M26 30 a4 4 0 1 1 8 0" fill="none" stroke="' . $A . '" stroke-width="2"/><title>Position sensor</title>';
        case 'pswitch':
            return '<circle cx="30" cy="28" r="14" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M30 28 l8 -8" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M44 28 h12 M50 24 v8 M53 26 v4" stroke="' . $A . '" stroke-width="2"/><title>Pressure switch</title>';
        case 'flowmeter':
            return '<circle cx="30" cy="28" r="14" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M22 32 q8 -12 16 0" fill="none" stroke="' . $A . '" stroke-width="2"/>'
                . '<path d="M30 50 V58 M16 28 H4 M44 28 H56" stroke="' . $I . '" stroke-width="2"/><title>Flow meter</title>';
        case 'dryer':
            return '<rect x="14" y="12" width="32" height="36" rx="3" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M30 18 v18 M24 24 l12 12 M36 24 l-12 12" stroke="' . $A . '" stroke-width="1.6"/>'
                . '<path d="M4 30 H14 M46 30 H56" stroke="' . $I . '" stroke-width="2.2"/><title>Dryer</title>';
        case 'shutoff':
            return '<circle cx="30" cy="30" r="14" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M21 30 h18" stroke="' . $I . '" stroke-width="2.6"/>'
                . '<path d="M30 16 v-6 M4 30 h12 M56 30 H44" stroke="' . $I . '" stroke-width="2.2"/><title>Shut-off valve</title>';
        case 'manifold':
            return '<rect x="8" y="14" width="44" height="20" rx="2" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M14 34 v14 M24 34 v10 M34 34 v14 M44 34 v10" stroke="' . $I . '" stroke-width="2"/>'
                . '<circle cx="14" cy="50" r="2.4" fill="' . $A . '"/><circle cx="24" cy="46" r="2.4" fill="' . $A . '"/><circle cx="34" cy="50" r="2.4" fill="' . $A . '"/><circle cx="44" cy="46" r="2.4" fill="' . $A . '"/><title>Manifold</title>';
        case 'cartridge':
            return '<rect x="18" y="8" width="24" height="14" fill="' . $W . '" stroke="' . $I . '" stroke-width="2"/>'
                . '<path d="M18 22 h24 l-4 22 h-16 z" fill="' . $W . '" stroke="' . $I . '" stroke-width="2"/>'
                . '<path d="M24 44 l6 -10 6 10" fill="' . $A . '"/>'
                . '<path d="M30 16 v-8" stroke="' . $T . '" stroke-width="2" stroke-dasharray="3 2"/><title>Cartridge valve</title>';
        case 'solenoid':
            return '<rect x="18" y="20" width="28" height="20" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M22 24 h20 M22 28 h20 M22 32 h20 M22 36 h20" stroke="' . $T . '" stroke-width="1.4"/>'
                . '<path d="M46 30 h12" stroke="' . $A . '" stroke-width="2.4"/>'
                . '<path d="M12 30 H18 M6 30 h0" stroke="' . $I . '" stroke-width="2.2"/><title>Solenoid coil</title>';
        case 'edrive':
            return '<circle cx="30" cy="30" r="16" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<text x="30" y="36" font-family="system-ui,sans-serif" font-size="14" font-weight="800" fill="' . $I . '" text-anchor="middle">M</text>'
                . '<path d="M30 46 v8 M46 30 h8" stroke="' . $A . '" stroke-width="2"/><title>Electric drive</title>';
        case 'button':
            return '<rect x="14" y="26" width="32" height="16" rx="3" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<circle cx="30" cy="22" r="8" fill="' . $A . '" stroke="' . $I . '" stroke-width="2"/>'
                . '<path d="M30 42 v8" stroke="' . $I . '" stroke-width="2.2"/><title>Push button</title>';
        case 'roller':
            return '<rect x="20" y="24" width="20" height="18" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<circle cx="30" cy="16" r="8" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M30 24 v-4" stroke="' . $I . '" stroke-width="2"/><title>Roller lever valve</title>';
        case 'timer':
            return '<circle cx="30" cy="30" r="17" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M30 30 V19 M30 30 l8 5" stroke="' . $A . '" stroke-width="2.4" stroke-linecap="round"/>'
                . '<circle cx="30" cy="30" r="2.2" fill="' . $I . '"/><title>Time delay valve</title>';
        case 'counter':
            return '<rect x="12" y="16" width="36" height="28" rx="3" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<text x="30" y="36" font-family="system-ui,sans-serif" font-size="15" font-weight="800" fill="' . $A . '" text-anchor="middle">5</text>'
                . '<path d="M18 44 v8 M42 44 v8" stroke="' . $I . '" stroke-width="2"/><title>Preset counter</title>';
        case 'junction':
            return '<path d="M30 30 m-3 0 a3 3 0 1 0 6 0 a3 3 0 1 0 -6 0" fill="' . $I . '"/>'
                . '<path d="M30 30 V8 M30 30 V52 M30 30 H8 M30 30 H52" stroke="' . $I . '" stroke-width="2.2"/><title>Junction</title>';
        case 'hose':
            return '<path d="M8 44 q10 -28 24 -22 q16 6 20 -14" fill="none" stroke="' . $I . '" stroke-width="4" stroke-linecap="round"/>'
                . '<path d="M8 44 q10 -28 24 -22 q16 6 20 -14" fill="none" stroke="' . $T . '" stroke-width="1.4" stroke-dasharray="4 4" stroke-linecap="round"/>'
                . '<circle cx="8" cy="44" r="3" fill="' . $A . '"/><circle cx="52" cy="8" r="3" fill="' . $A . '"/><title>Hose line</title>';
        case 'pipe':
            return '<path d="M6 44 H40 V16 H54" fill="none" stroke="' . $I . '" stroke-width="4"/>'
                . '<path d="M6 44 H40 V16 H54" fill="none" stroke="' . $T . '" stroke-width="1.2"/><title>Rigid pipe</title>';
        case 'intensifier':
            return '<rect x="6" y="18" width="22" height="24" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<rect x="34" y="22" width="14" height="16" fill="' . $W . '" stroke="' . $A . '" stroke-width="2.2"/>'
                . '<path d="M28 30 H34" stroke="' . $I . '" stroke-width="3"/>'
                . '<path d="M48 30 h8" stroke="' . $A . '" stroke-width="2.2"/><title>Pressure intensifier</title>';
        case 'lock':
            return '<rect x="16" y="24" width="28" height="22" rx="3" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M22 24 v-4 a8 8 0 0 1 16 0 v4" fill="none" stroke="' . $I . '" stroke-width="2.4"/>'
                . '<circle cx="30" cy="35" r="3.4" fill="' . $A . '"/><title>Rod lock</title>';
        case 'stopper':
            return '<rect x="8" y="34" width="44" height="10" rx="2" fill="' . $W . '" stroke="' . $I . '" stroke-width="2"/>'
                . '<path d="M16 34 V16 h10 v18 z" fill="' . $A . '" stroke="' . $I . '" stroke-width="2"/>'
                . '<path d="M44 20 h10" stroke="' . $I . '" stroke-width="2.4"/><circle cx="54" cy="20" r="4" fill="' . $W . '" stroke="' . $I . '" stroke-width="2"/><title>Stopper cylinder</title>';
        case 'flowdiv':
            return '<circle cx="20" cy="30" r="12" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>' 
                . '<circle cx="42" cy="30" r="12" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M14 30 h-8 M48 30 h8 M31 12 v-6" stroke="' . $I . '" stroke-width="2"/>'
                . '<path d="M14 36 l6 -12 6 12 6 -12 6 12 6 -12" fill="none" stroke="' . $A . '" stroke-width="1.4"/><title>Flow divider</title>';
        case 'emotor-dyn': // generic electric
            return '<circle cx="30" cy="30" r="16" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<path d="M34 18 l-10 14 h8 l-4 12 12 -16 h-8 z" fill="' . $A . '" stroke="' . $I . '" stroke-width="1.2"/><title>Electric element</title>';
        default:
            return '<circle cx="30" cy="30" r="17" fill="' . $W . '" stroke="' . $I . '" stroke-width="2.2"/>'
                . '<text x="30" y="36" font-family="system-ui,sans-serif" font-size="18" font-weight="800" fill="' . $T . '" text-anchor="middle">?</text>';
    }
}

/* Keyword → lesson illustration mapping */
function rgz_ll_single_symbol($id) {
    $map = [
        // hydraulics elements
        'powerpack' => 'vpump', 'gear-pump' => 'pump', 'internal-gear' => 'pump', 'vane-pump' => 'pump', 'screw-pump' => 'pump',
        'variable-pump' => 'vpump', 'hand-pump' => 'pump', 'pump-acceptance' => 'gauge',
        'hyd-motor' => 'motor', 'piston-motor' => 'motor',
        'double-rod' => 'cylda', 'cyl-cushion' => 'cylda', 'pos-cylinder' => 'cylda', 'stop-tube' => 'cylda',
        'cylinder-da' => 'cylda', 'cylinder-sa' => 'cylsa', 'telescopic' => 'telescopic', 'rotary-actuator' => 'rotary',
        'dcv-43' => 'dcv43', 'dcv-42' => 'dcv52', 'proportional-valve' => 'prop', 'servo-valve' => 'prop', 'amplifier' => 'emotor-dyn',
        'crossrelief' => 'relief', 'unloading-valve' => 'relief', 'relief-valve' => 'relief',
        'pressure-reducing' => 'reducing', 'sequence-valve' => 'sequence', 'counterbalance' => 'pcheck', 'brake-valve' => 'pcheck',
        'hoseburst' => 'pcheck', 'anti-cavitation' => 'check', 'pilot-check' => 'pcheck', 'check-valve' => 'check',
        'shuttle-valve' => 'shuttle', 'throttle-valve' => 'throttle', 'flow-pc' => 'flowpc', 'flow-divider' => 'flowdiv',
        'accumulator-safety' => 'accum', 'accumulator' => 'accum',
        'filter-pressure' => 'filter', 'filter-return' => 'filter', 'cooler' => 'cooler', 'oil-cooler-water' => 'cooler', 'heater' => 'heater',
        'level-switch' => 'tank', 'breather' => 'tank', 'tank' => 'tank',
        'hose' => 'hose', 'pipe' => 'pipe', 'tube-pressure-drop' => 'pipe', 'quick-coupling' => 'hose',
        'manifold' => 'manifold', 'cartridge-22' => 'cartridge', 'iso-frame' => 'manifold',
        'gauge-isolator' => 'gauge', 'gauge' => 'gauge', 'pressure-switch-h' => 'pswitch', 'temperature-h' => 'pswitch',
        'flow-meter' => 'flowmeter', 'electric-drive' => 'edrive', 'electro-interface' => 'solenoid', 'solenoid-connector' => 'solenoid',
        'inductive-sensor' => 'sensor', 'pilot-joystick' => 'roller', 'ball-shutoff' => 'shutoff', 'intensifier' => 'intensifier',
        'prefill-valve' => 'check', 'junction' => 'junction',
        // pneumatics elements
        'piston-compressor' => 'compressor', 'screw-compressor' => 'compressor', 'receiver' => 'receiver',
        'water-separator' => 'filter', 'filter-coalescing' => 'filter',
        'dryer-refrigeration' => 'dryer', 'dryer-adsorption' => 'dryer', 'membrane-dryer' => 'dryer',
        'frl' => 'frl', 'filter-regulator' => 'frl', 'precision-regulator' => 'reducing', 'lubricator' => 'lubricator',
        'shutoff-slowstart' => 'shutoff', 'dump-valve' => 'dcv22',
        'v-32-nc' => 'dcv22', 'v-32-no' => 'dcv22', 'v-52-single' => 'dcv52', 'v-52-double' => 'dcv52', 'v-53-all' => 'dcv53',
        'solenoid-tech' => 'solenoid', 'pilot-types' => 'roller', 'manual-lever' => 'button', 'estop-mushroom' => 'button',
        'throttle-check' => 'throttle', 'quick-exhaust' => 'qexhaust', 'shuttle-or' => 'shuttle', 'dual-pressure-and' => 'and',
        'time-delay' => 'timer', 'pressure-seq-valve' => 'sequence', 'counter' => 'counter',
        'silencer' => 'silencer', 'flow-silencer' => 'silencer', 'nonreturn' => 'check', 'rod-lock' => 'lock',
        'valve-terminal' => 'manifold', 'flow-rated' => 'flowmeter',
        'cyl-sa' => 'cylsa', 'cyl-da' => 'cylda', 'cyl-cushion' => 'cylda', 'cyl-guided' => 'cylda',
        'cyl-rodless' => 'cylda', 'cyl-rotary' => 'rotary', 'air-motor' => 'airmotor', 'stopper' => 'stopper',
        'grippers' => 'gripper', 'bellows-muscle' => 'cylsa',
        'vacuum-ejector' => 'ejector', 'vacuum-cups' => 'cup', 'ejector-control' => 'ejector', 'vacuum-filter' => 'filter',
        'tubing-fittings' => 'pipe', 'manifold-distribution' => 'manifold',
        'sensor-reed' => 'sensor', 'sensor-pressure' => 'pswitch', 'sensor-flow' => 'flowmeter',
        'booster' => 'intensifier', 'air-saver' => 'shutoff', 'inline-flow' => 'throttle', 'breather' => 'silencer',
        'logic-family' => 'and', 'low-friction' => 'cylda', 'impact' => 'cylsa', 'rotary-union' => 'rotary',
        'air-gauge' => 'gauge', 'tension-web' => 'cylda', 'hydraulic-versus-cheat' => 'intensifier',
        'datasheets' => 'gauge', 'airquality-monitor' => 'gauge', 'cushion-chart' => 'cylda', 'festo-trainer' => 'frl',
        'error-clinic' => 'gauge', 'parameter-sticky' => 'throttle', 'first-spare' => 'manifold',
    ];
    foreach ($map as $k => $sym) { if (strpos($id, $k) !== false) return $sym; }
    return null;
}
function rgz_ll_figure($r) {
    $id = $r['id'];
    $acc = '#EB4E3C';
    $label = isset($r['t']) ? $r['t'] : $id;
    $svg = rgz_ll_svg_open($label);
    if (strpos($id, 'cad-') === 0) {
        /* CAD & Design lessons: isometric cube with a dimension line + arrows. */
        $svg .= '<circle cx="170" cy="103" r="63" fill="#ffffff" stroke="#d4e0ee" stroke-width="1.5"/>'
            . '<g fill="none" stroke-linecap="round" stroke-linejoin="round">'
            . '<path d="M170 62 218 90v38l-48 28-48-28V90l48-28Z" stroke="#22405f" stroke-width="2.2"/>'
            . '<path d="M122 90l48 28 48-28M170 118v38" stroke="#22405f" stroke-width="1.4"/>'
            . '<path d="M122 90v38" stroke="#8fb0d4" stroke-width="1.4" stroke-dasharray="4 4"/>'
            . '<g stroke="' . $acc . '" stroke-width="1.6">'
            . '<path d="M128 152v12M212 152v12M128 158h84"/>'
            . '<path d="M136 154l-8 4 8 4M204 154l8 4-8 4"/>'
            . '</g><text x="170" y="146" text-anchor="middle" font-family="system-ui,sans-serif" font-size="12" font-weight="700" fill="' . $acc . '">Ø 25 ±0.1</text>'
            . '</g></svg>';
        return $svg;
    }
    $isPattern = (strpos($id, '-ckt-') !== false);
    $isFund = (strpos($id, 'hl-f-') === 0 || strpos($id, 'pl-f-') === 0);
    if (!$isPattern && !$isFund) {
        $sym = rgz_ll_single_symbol($id);
        if ($sym) {
            $svg .= '<circle cx="170" cy="103" r="63" fill="#ffffff" stroke="#d4e0ee" stroke-width="1.5"/>';
            $svg .= rgz_ll_sz(113, 46, 1.9, rgz_ll_sym($sym, $acc));
            $svg .= '</svg>';
            return $svg;
        }
    }
    if ($isFund) {
        /* concept glyph card: axis chart with topic icon */
        $chart = '<g stroke="#22405f" stroke-width="2" fill="none">'
            . '<path d="M78 160 V70 h0 M78 160 h190"/></g>'
            . '<path d="M84 148 C120 145 140 96 172 92 C204 88 220 128 262 78" fill="none" stroke="' . $acc . '" stroke-width="3" stroke-linecap="round"/>'
            . '<circle cx="172" cy="92" r="4" fill="' . $acc . '"/>'
            . '<path d="M84 148 C120 145 140 96 172 92" fill="none" stroke="#8fb0d4" stroke-width="2" stroke-dasharray="4 4"/>';
        $glyph = 'gauge';
        foreach (['power' => 'gauge', 'efficiency' => 'pump', 'frequency' => 'rotary', 'cleanl' => 'filter', 'iso4406' => 'filter',
            'beta' => 'filter', 'cavitation' => 'pump', 'viscosity' => 'tank', 'fluid' => 'tank', 'seal' => 'cylsa',
            'gaslaw' => 'accum', 'bulkmodulus' => 'cyl', 'buckling' => 'cyl', 'tank' => 'tank', 'hose' => 'hose',
            'heat' => 'heater', 'cooling' => 'cooler', 'pumpselect' => 'pump', 'failures' => 'pump', 'maintenance' => 'gauge',
            'test-bench' => 'gauge', 'burst' => 'relief', 'noise' => 'silencer', 'symbols' => 'dcv43',
            'normal-liter' => 'compressor', 'fad' => 'compressor', 'consumption' => 'flowmeter', 'energy-bar' => 'gauge',
            'leak' => 'pipe', 'droop' => 'reducing', 'dewpoint' => 'dryer', 'water' => 'dryer', 'choked' => 'qexhaust',
            'tube' => 'pipe', 'cylinder' => 'cylda', 'friction' => 'cylda', 'pne-vs-elec' => 'edrive',
            'vacuum' => 'cup', 'chain' => 'junction', 'compressor' => 'compressor', 'commission' => 'timer',
            'response' => 'timer', 'decision' => 'vpump', 'intensification' => 'intensifier', 'maintenance' => 'gauge',
            'safety' => 'relief', 'energy' => 'gauge', 'capstone' => 'dcv43'] as $k => $g2) {
            if (strpos($id, $k) !== false) { $glyph = $g2; break; }
        }
        $svg .= rgz_ll_sz(40, 60, 0.62, rgz_ll_sym($glyph, $acc)) . $chart . '</svg>';
        return $svg;
    }
    /* circuit-pattern scene: pump → valve → actuators on a mini schematic; the
       lesson-critical element is drawn with the accent color */
    $keyEl = 'dcv43'; $second = null; $third = null; $pumpSym = 'vpump';
    $pairs = [
        ['sg' => 'open-center', 'el' => 'dcv43'], ['sg' => 'closed-center', 'el' => 'dcv43'],
        ['sg' => 'hilo', 'el' => 'relief'], ['sg' => 'unloading', 'el' => 'relief'],
        ['sg' => 'meter-in', 'el' => 'throttle'], ['sg' => 'meter-out', 'el' => 'throttle'], ['sg' => 'bleed-off', 'el' => 'throttle'],
        ['sg' => 'pc-flow', 'el' => 'flowpc'], ['sg' => 'regen', 'el' => 'dcv43'],
        ['sg' => 'sequence', 'el' => 'sequence', 'a2' => 'cylda'],
        ['sg' => 'flowdiv', 'el' => 'flowdiv', 'a2' => 'cylda'], ['sg' => 'series-sync', 'el' => 'junction', 'a2' => 'cylda'],
        ['sg' => 'reducing', 'el' => 'reducing'], ['sg' => 'dump', 'el' => 'dcv22'], ['sg' => 'twohand', 'el' => 'and'],
        ['sg' => 'dwell', 'el' => 'timer'], ['sg' => 'counterbalance', 'el' => 'pcheck'], ['sg' => 'brake', 'el' => 'motor'],
        ['sg' => 'float', 'el' => 'dcv43'], ['sg' => 'ls-flowsharing', 'el' => 'vpump'], ['sg' => 'ls', 'el' => 'vpump'],
        ['sg' => 'ramp', 'el' => 'prop'], ['sg' => 'servo-axis', 'el' => 'prop'],
        ['sg' => 'kidney', 'el' => 'filter'], ['sg' => 'cooling', 'el' => 'cooler'], ['sg' => 'flush', 'el' => 'filter'],
        ['sg' => 'bleed', 'el' => 'cylsa'], ['sg' => 'commission', 'el' => 'gauge'], ['sg' => 'testpoints', 'el' => 'gauge'],
        ['sg' => 'suction', 'el' => 'pump'], ['sg' => 'filter-select', 'el' => 'filter'], ['sg' => 'thermal', 'el' => 'heater'],
        ['sg' => 'intensifier', 'el' => 'intensifier'], ['sg' => 'motor-series', 'el' => 'motor', 'a2' => 'motor'],
        ['sg' => 'motor-parallel', 'el' => 'motor', 'a2' => 'motor'],
        ['sg' => 'decompression', 'el' => 'throttle'], ['sg' => 'remote-relief', 'el' => 'relief'],
        ['sg' => 'amplifier', 'el' => 'prop'], ['sg' => 'switches-chain', 'el' => 'pswitch'],
        ['sg' => 'energy-audit', 'el' => 'gauge'], ['sg' => 'design-steps', 'el' => 'dcv43'],
        // pneumatic patterns
        ['sg' => 'direct-sa', 'el' => 'dcv22'], ['sg' => 'indirect', 'el' => 'dcv52'],
        ['sg' => 'latching', 'el' => 'dcv52'], ['sg' => 'auto-return', 'el' => 'roller'],
        ['sg' => 'twohand', 'el' => 'and'], ['sg' => 'time-dwell', 'el' => 'timer'],
        ['sg' => 'quickexhaust', 'el' => 'qexhaust'], ['sg' => 'pressure-seq', 'el' => 'sequence', 'a2' => 'cylda'],
        ['sg' => 'cascade', 'el' => 'junction', 'a2' => 'cylda'], ['sg' => 'stepper', 'el' => 'counter'],
        ['sg' => 'multi-pressure', 'el' => 'reducing'], ['sg' => 'oscillating', 'el' => 'dcv52'],
        ['sg' => 'vacuum-pick', 'el' => 'cup'], ['sg' => 'estop-chain', 'el' => 'button'],
        ['sg' => 'network-buffer', 'el' => 'receiver'], ['sg' => 'air-jet', 'el' => 'ejector'],
        ['sg' => 'differential-reduce', 'el' => 'reducing'], ['sg' => 'plc-mapping', 'el' => 'emotor-dyn'],
        ['sg' => 'logic-review', 'el' => 'and'], ['sg' => 'failsafe-review', 'el' => 'relief'],
        ['sg' => 'step-monitor', 'el' => 'timer'], ['sg' => 'priority-mode', 'el' => 'button'],
        ['sg' => 'emergency-retract', 'el' => 'button'], ['sg' => 'high-low-feed', 'el' => 'throttle'],
        ['sg' => 'separate-exhaust', 'el' => 'throttle'], ['sg' => 'synchronization', 'el' => 'junction', 'a2' => 'cylda'],
        ['sg' => 'tandem', 'el' => 'cylda'], ['sg' => 'counter-batch', 'el' => 'counter'],
        ['sg' => 'pick-place-full', 'el' => 'gripper'], ['sg' => 'clamp-varying', 'el' => 'cylsa'],
        ['sg' => 'vacuum-porous', 'el' => 'cup'], ['sg' => 'depalletizr', 'el' => 'receiver'],
        ['sg' => 'hydro-feed', 'el' => 'intensifier'], ['sg' => 'balancer-tension', 'el' => 'reducing'],
        ['sg' => 'door-dual', 'el' => 'and'], ['sg' => 'airexpansion-cold', 'el' => 'dryer'],
        ['sg' => 'cleanroom', 'el' => 'silencer'], ['sg' => 'sequence-troubleshoot', 'el' => 'gauge'],
        ['sg' => 'costs-tco', 'el' => 'gauge'], ['sg' => 'shift-cascade-comment', 'el' => 'junction'],
    ];
    $lnk = '#22405f';
    $isAir = (strpos($id, 'pl-') === 0);
    $pumpSym = $isAir ? 'compressor' : 'vpump';
    $act = 'cylda';
    foreach ($pairs as $pr) {
        if (strpos($id, $pr['sg']) !== false) { $keyEl = $pr['el']; if (!empty($pr['a2'])) $second = $pr['a2']; break; }
    }
    /* key element highlighted with accent; support element in ink */
    $svg .= rgz_ll_sz(40, 130, 0.55, rgz_ll_sym($pumpSym, '#22405f'));
    $svg .= rgz_ll_sz(132, 78, 0.8, rgz_ll_sym('dcv43' === $keyEl || 'dcv52' === $keyEl || 'dcv22' === $keyEl ? $keyEl : $keyEl, $acc));
    $svg .= rgz_ll_sz(238, 60, 0.8, rgz_ll_sym($act, '#22405f'));
    if ($second) $svg .= rgz_ll_sz(238, 132, 0.8, rgz_ll_sym($second, $acc));
    /* connecting pipe run */
    $svg .= '<g stroke="' . $lnk . '" stroke-width="2.4" fill="none" stroke-linecap="round">'
        . '<path d="M74 132 V54 H132"/><path d="M184 96 H238"/><path d="M184 150 H238" stroke="#8fb0d4"/></g>'
        . '<circle cx="110" cy="54" r="3" fill="' . $lnk . '"/>'
        . '<text x="30" y="196" font-family="system-ui,sans-serif" font-size="10" font-weight="800" letter-spacing="1" fill="' . $acc . '">' . ($isAir ? 'AIR SUPPLY' : 'OIL SUPPLY') . '</text>';
    $svg .= '</svg>';
    return $svg;
}

/* ------------------------------------------------------------------ */
/* CAD & DESIGN — drafting standards for the RGZ 3D CAD Studio         */
/* (levels: beginner → advanced; content mirrors ISO practice used     */
/*  live inside the app so theory and tooling agree)                   */
/* ------------------------------------------------------------------ */
function rgz_ll_cad_lessons() {
    $D = [];
    $D[] = ['id' => 'cad-f-sketch-lines', 't' => 'Sketch lines that mean something — ISO 128 line types', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'Why some edges are wide, some narrow, and why hidden edges are dashed — the alphabet of technical drawings.',
        'w' => 'Every technical drawing is a sentence written in lines. ISO 128 standardizes the <strong>types, widths and application of lines</strong> so that a drawing made in Hamburg reads the same in Tehran or Tokyo. Get these three right and 90% of sketch communication is solved.',
        'h' => 'Wide solid line <strong>type 01.2</strong> — visible outlines and edges, the silhouette you can touch. Narrow solid <strong>01.1</strong> — dimension lines, extension lines, leaders, hatching. Narrow dashed <strong>02.1</strong> — hidden edges behind the part. Narrow chain (long dash–dot) <strong>04.1</strong> — center lines and hole axes. Widths follow the ratio narrow : wide = 1 : 2 (typ. 0.25 / 0.5 mm on A4).',
        'f' => 'narrow = 0.25 mm · wide = 0.5 mm (ISO 128-20, ratio 1:2)',
        's' => 'Choose line type by <em>meaning</em>, never by look: an edge you could touch = wide solid; an edge behind material = narrow dashed; an axis of rotation or symmetry = chain thin. Do not dash a center line and do not chain a hidden edge.',
        'a' => ['Sketching a bracket: outer rectangle = 01.2 wide.', 'Dimension and extension lines around it = 01.1 narrow.', 'A hole seen from the side = two 02.1 dashed lines + one 04.1 center line.'],
        'x' => 'In the 3D CAD Studio drawing step, switch hidden lines off and on and watch how the sheet keeps wide/narrow/dashed exactly per this lesson.'];
    $D[] = ['id' => 'cad-f-dimensioning', 't' => 'Dimensioning rules — ISO 129-1 & the tolerance text of ISO 406', 'lv' => 'beginner', 'min' => 6,
        'sm' => 'Where dimension lines sit, how arrows and text are placed, and how limit deviations are written next to a size.',
        'w' => 'A drawing without dimensions is decoration. <strong>ISO 129-1</strong> defines the geometry of dimensioning; <strong>ISO 406</strong> defines how tolerances are written with the dimension. Together they make a size unambiguous for the machinist.',
        'h' => 'Each dimension is given <strong>once</strong> — the shape stays dimension-free. Extension lines start with a small gap from the outline and pass slightly beyond the dimension line; arrows are filled and touch the dimension line ends; text sits above the line, readable from the bottom or right (aligned method). Tolerances: symmetric <code>50 ±0.1</code> or bilateral with the upper deviation first <code>50 +0.1/−0.0</code>.',
        'f' => '50 ±0.1 &nbsp;or&nbsp; 50 +0.1 / −0.0 (ISO 406)',
        's' => 'Dimension to <strong>functional surfaces</strong> first. Keep dimension lines ≈ 7–10 mm from the outline and 6–8 mm apart from each other. Never let a dimension line cross another line if avoidable, and never use an outline as a dimension line.',
        'a' => ['Plate 60 × 40: both sizes on the outline\'s outside, text above the line.', 'Ø dimension with leader to the hole, center marks as chain cross.'],
        'x' => 'Flip a tolerance on for one dimension in the app (ISO 406 switch) and export the drawing: only that dimension prints deviations.'];
    $D[] = ['id' => 'cad-f-iso-2768', 't' => 'General tolerances — ISO 2768-1 (f · m · c · v)', 'lv' => 'intermediate', 'min' => 6,
        'sm' => 'Every dimension without its own tolerance still has one — the table that quietly controls your whole sheet.',
        'w' => 'No workshop can produce an exact 50.000 mm, and writing ±0.05 on every dimension would bury the drawing in numbers. <strong>ISO 2768-1</strong> defines <em>general tolerances</em>: four classes (fine, medium, coarse, very coarse) applied to every dimension that carries no explicit deviation — declared once in the title block.',
        'h' => 'For linear dimensions (mm), class <strong>m (medium)</strong>: up to 3 mm → ±0.1; over 6–30 → ±0.2; over 30–120 → ±0.3; over 120–400 → ±0.5; over 400–1000 → ±0.8. Class <strong>f (fine)</strong> halves most of these; <strong>c</strong> and <strong>v</strong> relax them for flame-cut or rough parts. Angles and radii/chamfers have their own rows in the same standard.',
        'f' => 'm @ 30–120 mm → ±0.3 · m @ 6–30 mm → ±0.2',
        's' => 'Use ISO 2768-m as the house standard for machined parts; switch to f for gauge-fine work. Dimensions where function demands tighter control get their own ISO 406 deviation — the app calls this "tolerance on request".',
        'a' => ['Cover plate: only the bolt pattern gets explicit tolerances; the rest rides on ISO 2768-m.', 'Laser-cut armor plate: ISO 2768-c.'],
        'x' => 'The app\'s ISO 406 block has an "Auto (ISO 2768-m)" button — compare the value it fills with the table above for the size you entered.'];
    $D[] = ['id' => 'cad-f-iso-286', 't' => 'Limits & fits — ISO 286 (IT grades, H7/g6)', 'lv' => 'intermediate', 'min' => 6,
        'sm' => 'Hole-basis fits in five minutes: what H7 for a hole and g6 for a shaft actually guarantee at assembly.',
        'w' => '<strong>ISO 286</strong> defines the IT tolerance system: a letter for the position relative to nominal (holes capital, shafts lowercase) and a grade number for the width (IT number). In the hole-basis system the hole is always H (lower deviation 0) and the desired clearance is dialed in through the shaft letter.',
        'h' => 'Every +1 IT grade widens the tolerance ≈ ×1.6. Everyday pairs: <strong>H7/g6</strong> sliding fit, <strong>H7/k6</strong> slight transition (taps in by hand/hammer), <strong>H7/s6</strong> press fit. Example Ø 10: H7 = +15/0 µm on the hole, g6 = −5/−14 µm on the shaft → guaranteed clearance 5–29 µm.',
        'f' => 'Ø10 H7 = +0.015/0 · Ø10 g6 = −0.005/−0.014 (mm)',
        's' => 'Put the hole tolerance on the hole dimension and the shaft tolerance on the shaft dimension — never both on one number. For one-off prototypes, H7 with reaming is the cheapest precise hole; below H7 you enter grinding territory.',
        'a' => ['Locating pin in a jig plate: Ø 10 H7 hole.', 'Oil-impregnated bushing pressed into a gearbox housing: H7/s6.'],
        'x' => 'Give one of the app\'s holes the tolerance +0.015 / 0 — that is exactly Ø 10 H7 on the drawing.'];
    $D[] = ['id' => 'cad-f-iso-1101', 't' => 'GD&T basics — ISO 1101 (+ ISO 5459 datums)', 'lv' => 'advanced', 'min' => 6,
        'sm' => 'When a size tolerance is not enough: flat faces, perpendicular holes, true position — the feature control frame.',
        'w' => 'Size tolerances control <strong>how big</strong>; geometrical tolerances control <strong>form, orientation, location and run-out</strong>. ISO 1101 defines the symbol frames (feature control frames) you see on professional drawings; <strong>ISO 5459</strong> defines the datums they refer to. ASME Y14.5 is the US twin — the two are ~95% aligned.',
        'h' => 'A feature control frame reads left to right: <em>symbol | tolerance zone | datum references</em>. Flatness ▭: surface between two planes t apart. Perpendicularity ⊥ t|A: axis or face within a zone 90° to datum A. Position ◎ Øt|A|B|C: axis inside a cylinder Øt at the theoretically exact (boxed) location. Circular run-out ↗: surface variation per revolution.',
        'f' => '□ zone = two planes t apart · ◎ zone = cylinder Øt at true position',
        's' => 'Datum first: pick functional surfaces as A, B, C before tolerancing anything. GD&T controls only what function demands — every frame has a cost in manufacturing and inspection.',
        'a' => ['Manifold face sealing with an O-ring: flatness 0.05.', 'Dowel-pin bore through a face: perpendicularity then position to datums.'],
        'x' => 'Start clean: dimension normally (ISO 129-1 + ISO 406) and add GD&T only where the part would fail without it.'];
    $D[] = ['id' => 'cad-f-projection-sheets', 't' => 'Projection methods — ISO 128-30 & sheet formats — ISO 216', 'lv' => 'beginner', 'min' => 5,
        'sm' => 'First vs third angle, the projection symbol, isometric vs axonometric views, and why your sheet is A4/A3.',
        'w' => 'A flat drawing must say <em>from which side</em> each view was taken. Europe works mostly in <strong>first-angle</strong> projection, North America in <strong>third-angle</strong>. ISO 128-30 requires the projection symbol (truncated cone with circles) on every sheet where confusion is possible. Sheets themselves follow <strong>ISO 216</strong>: A4 = 210 × 297 mm, A3 = 420 × 297 mm.',
        'h' => 'Third angle = the view is placed on the side it is seen from; symbol: trapezoid left, two circles right. First angle mirrors that. An <strong>isometric view</strong> foreshortens all three axes equally at 120° apart: measuring along any axis reads true at scale 1:1 — exactly the (1,1,1) projection the app draws.',
        'f' => 'A-series: each half = next format · A4 = 210×297 · A3 = 420×297',
        's' => 'One sheet = one format, title block bottom right (ISO 7200). For reading: always check the projection symbol before assigning left/right views — it is the cheapest mistake on imported drawings.',
        'a' => ['Exporting the app drawing at A3 for a large part: same layout, only the frame grows.', 'US supplier drawings: third angle symbol present.'],
        'x' => 'Find the projection symbol in the bottom-left of the app\'s sheet and compare it with an ISO 128-30 reference.'];
    $D[] = ['id' => 'cad-f-titleblock-scales', 't' => 'Title blocks, preferred scales & drawing numbers — ISO 7200 + ISO 5455', 'lv' => 'intermediate', 'min' => 4,
        'sm' => 'The minimum data every workshop expects in the corner: title, scale, material, projection, tolerances, date.',
        'w' => '<strong>ISO 7200</strong> fixes the title-block content and its position (bottom right). Essential fields: title/identification, scale, units, projection method, general-tolerance reference, owner, date. <strong>ISO 5455</strong> lists the preferred scales: 1:1, 1:2, 1:5, 1:10, 2:1, 5:1, 10:1 …',
        'h' => 'A drawing must scale within the preferred ladder — "1:1.37" is not a scale, it is a screenshot. Natural scale 1:1 whenever the part fits; enlarge small details on a detail view (II) instead of shrinking the sheet. Every revision bumps an index letter with a one-line change description.',
        'f' => 'scales: … 1:5 · 1:2 · 1:1 · 2:1 · 5:1 … (ISO 5455)',
        's' => 'Never scale a dimension off the paper: the number rules, the print is the packaging. Keep the general tolerance + projection symbol inside the block, standard notes outside it.',
        'a' => ['App sheet: name, material, scale, A-format, third-angle symbol, ISO 2768-mK note — the same skeleton ISO 7200 asks for.'],
        'x' => 'Export two sizes of the same part in the app (A4 vs A3) and watch the scale snap down the preferred ladder automatically.'];
    return $D;
}
