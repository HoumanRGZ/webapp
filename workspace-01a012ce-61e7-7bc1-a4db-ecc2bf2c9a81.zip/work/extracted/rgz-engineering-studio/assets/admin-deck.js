/* RGZ admin — Mechanical Deck app editor + tabs + copy buttons (vanilla) */
(function () {
  "use strict";
  function qs(r, s) { return r.querySelector(s); }
  function qsa(r, s) { return Array.prototype.slice.call(r.querySelectorAll(s)); }
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  /* ---------- tabs ---------- */
  qsa(document, "[data-rgza-tabs]").forEach(function (tabs) {
    var scope = tabs.closest(".rgza") || document;
    qsa(tabs, ".rgza-tab").forEach(function (tab) {
      tab.addEventListener("click", function () {
        qsa(tabs, ".rgza-tab").forEach(function (t) { t.classList.remove("on"); });
        tab.classList.add("on");
        var id = tab.getAttribute("data-tab");
        qsa(scope, ".rgza-pane").forEach(function (p) {
          p.classList.toggle("on", p.id === id);
        });
        if (history.replaceState) history.replaceState(null, "", "#" + id);
      });
    });
    var h = (location.hash || "").replace("#", "");
    if (h && qs(scope, ".rgza-pane#" + h)) {
      qsa(tabs, ".rgza-tab").forEach(function (t) { t.classList.toggle("on", t.getAttribute("data-tab") === h); });
      qsa(scope, ".rgza-pane").forEach(function (p) { p.classList.toggle("on", p.id === h); });
    }
  });

  /* ---------- copy buttons ---------- */
  qsa(document, "[data-copy]").forEach(function (btn) {
    btn.addEventListener("click", function (ev) {
      ev.preventDefault();
      var txt = btn.getAttribute("data-copy") || "";
      function done() { var o = btn.textContent; btn.textContent = "Copied!"; setTimeout(function () { btn.textContent = o; }, 1200); }
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(txt).then(done, done);
      else {
        var ta = document.createElement("textarea");
        ta.value = txt; document.body.appendChild(ta); ta.select();
        try { document.execCommand("copy"); } catch (e) {}
        document.body.removeChild(ta); done();
      }
    });
  });

  /* ---------- apps editor ---------- */
  var editor = qs(document, "[data-rgza-apps]");
  if (!editor) return;
  var cfg = window.rgzaDeckEditor || {};
  var ICONS = cfg.icons || {};
  var CATS = cfg.categories || [];
  var LEARNS = cfg.learnTopics || [];
  var data = [];
  try { data = JSON.parse(qs(editor, "#rgz-apps-json").value || "[]"); } catch (e) { data = []; }

  var list = qs(editor, "[data-rows]");
  var hidden = qs(editor, "#rgz-apps-json");
  var preview = qs(editor, "[data-preview]") || qs(document, "[data-preview]");

  function uid() { return "app-" + Math.random().toString(36).slice(2, 9); }
  function sync() {
    hidden.value = JSON.stringify(data);
    renderPreview();
  }
  function iconSvg(key) { return ICONS[key] || ICONS.generic || ""; }

  function catOptions(cur) {
    var out = "";
    CATS.forEach(function (c) { out += '<option value="' + esc(c) + '"' + (c === cur ? " selected" : "") + ">" + esc(c) + "</option>"; });
    if (cur && CATS.indexOf(cur) === -1) out += '<option value="' + esc(cur) + '" selected>' + esc(cur) + "</option>";
    out += '<option value="__custom">+ Custom category…</option>';
    return out;
  }
  function learnOptions(cur) {
    var out = '<option value="">None</option>';
    LEARNS.forEach(function (t) { out += '<option value="' + esc(t.key) + '"' + (t.key === cur ? " selected" : "") + ">" + esc(t.label) + "</option>"; });
    return out;
  }

  function render() {
    list.innerHTML = "";
    data.forEach(function (app, i) {
      var row = document.createElement("div");
      row.className = "rgza-app-row" + (app.enabled ? "" : " rgz-off");
      row.setAttribute("draggable", "true");
      row.innerHTML =
        '<div class="rgza-app-head">' +
        '<span class="rgza-handle" title="Drag to reorder">⋮⋮</span>' +
        '<span class="mini" style="color:' + esc(app.accent || "#38bdf8") + '">' + iconSvg(app.icon) + "</span>" +
        '<span class="tt"><b>' + esc(app.title || "Untitled app") + "</b><span>" + esc(app.category || "") + (app.badge ? " · " + esc(app.badge) : "") + (app.url ? "" : " · not linked") + "</span></span>" +
        '<span class="tog"><span class="rgza-pill ' + (app.enabled ? "on" : "off") + '">' + (app.enabled ? "enabled" : "hidden") + "</span></span>" +
        "</div>" +
        '<div class="rgza-app-body"><div class="cols">' +
        '<div class="fld"><label class="lbl">Title</label><input type="text" data-f="title" value="' + esc(app.title) + '"></div>' +
        '<div class="fld"><label class="lbl">Badge (optional)</label><input type="text" data-f="badge" value="' + esc(app.badge || "") + '" placeholder="Simulator"></div>' +
        '<div class="fld" style="grid-column:1/-1"><label class="lbl">Description</label><input type="text" data-f="desc" value="' + esc(app.desc || "") + '"></div>' +
        '<div class="fld"><label class="lbl">Category</label><select data-f="category">' + catOptions(app.category) + "</select></div>" +
        '<div class="fld"><label class="lbl">Launch URL</label><input type="url" data-f="url" value="' + esc(app.url || "") + '" placeholder="https://… (empty = coming soon)"></div>' +
        '<div class="fld"><label class="lbl">Accent color</label><input type="color" data-f="accent" value="' + esc(app.accent || "#38bdf8") + '"></div>' +
        '<div class="fld"><label class="lbl">Learning topic</label><select data-f="learnTopic">' + learnOptions(app.learnTopic) + '</select><p class="hint">Adds a “📖 Learning” button that opens the deck’s Learning tab pre-filtered to the topic.</p></div>' +
        '<div class="fld" style="grid-column:1/-1"><label class="lbl">Icon</label><div class="rgza-icons">' +
        Object.keys(ICONS).map(function (k) {
          return '<span class="rgza-iconopt' + (k === app.icon ? " on" : "") + '" data-icon="' + esc(k) + '" title="' + esc(k) + '">' + ICONS[k] + "</span>";
        }).join("") +
        "</div></div>" +
        '<div class="fld"><label class="rgza-switch"><input type="checkbox" data-f="enabled"' + (app.enabled ? " checked" : "") + '><span class="tr"></span><span class="ts">Visible on the deck page</span></label></div>' +
        '<div class="fld" style="grid-column:1/-1;margin-top:4px;display:flex;gap:8px">' +
        '<button type="button" class="rgza-btn danger small" data-del>Delete app</button>' +
        '<button type="button" class="rgza-btn ghost small" data-dup>Duplicate</button>' +
        "</div>" +
        "</div></div>";
      /* events */
      qs(row, ".rgza-app-head").addEventListener("click", function (ev) {
        if (ev.target.closest(".rgza-switch") || ev.target.closest("input")) return;
        row.classList.toggle("open");
      });
      qsa(row, "[data-f]").forEach(function (inp) {
        inp.addEventListener("change", apply);
        if (inp.type === "text" || inp.type === "url") inp.addEventListener("input", apply);
        function apply() {
          var f = inp.getAttribute("data-f");
          if (inp.type === "checkbox") app[f] = inp.checked;
          else app[f] = inp.value;
          if (f === "category" && inp.value === "__custom") {
            var custom = window.prompt("Custom category name:", app.category || "");
            if (custom) {
              app.category = custom;
              CATS.indexOf(custom) === -1 && CATS.push(custom);
            } else app.category = app.category || CATS[0] || "";
            render(); sync(); return;
          }
          if (f === "icon") {}
          row.querySelector(".tt b").textContent = app.title || "Untitled app";
          row.querySelector(".tt span").textContent = (app.category || "") + (app.badge ? " · " + app.badge : "") + (app.url ? "" : " · not linked");
          row.querySelector(".mini").innerHTML = iconSvg(app.icon);
          row.querySelector(".mini").style.color = app.accent || "#38bdf8";
          row.classList.toggle("rgz-off", !app.enabled);
          row.querySelector(".rgza-pill").className = "rgza-pill " + (app.enabled ? "on" : "off");
          row.querySelector(".rgza-pill").textContent = app.enabled ? "enabled" : "hidden";
          sync();
        }
      });
      qsa(row, ".rgza-iconopt").forEach(function (opt) {
        opt.addEventListener("click", function () {
          app.icon = opt.getAttribute("data-icon");
          qsa(row, ".rgza-iconopt").forEach(function (o) { o.classList.toggle("on", o === opt); });
          row.querySelector(".mini").innerHTML = iconSvg(app.icon);
          sync();
        });
      });
      qs(row, "[data-del]").addEventListener("click", function () {
        if (!window.confirm("Delete “" + (app.title || "this app") + "”?")) return;
        data.splice(i, 1); render(); sync();
      });
      qs(row, "[data-dup]").addEventListener("click", function () {
        var copy = JSON.parse(JSON.stringify(app));
        copy.id = uid(); copy.title += " (copy)";
        data.splice(i + 1, 0, copy); render(); sync();
      });
      /* drag reorder */
      row.addEventListener("dragstart", function (ev) {
        ev.dataTransfer.setData("text/plain", String(i));
        row.classList.add("dragging");
      });
      row.addEventListener("dragend", function () { row.classList.remove("dragging"); });
      row.addEventListener("dragover", function (ev) { ev.preventDefault(); });
      row.addEventListener("drop", function (ev) {
        ev.preventDefault();
        var from = parseInt(ev.dataTransfer.getData("text/plain"), 10);
        if (isNaN(from) || from === i) return;
        var item = data.splice(from, 1)[0];
        data.splice(i, 0, item);
        render(); sync();
      });
      list.appendChild(row);
    });
  }

  function renderPreview() {
    if (!preview) return;
    var visible = data.filter(function (a) { return a.enabled; });
    if (!visible.length) { preview.innerHTML = '<p style="color:#64748b;font-size:13px">No visible apps — enable at least one.</p>'; return; }
    preview.innerHTML =
      '<div class="rgzd" style="--rgzd-accent:#38bdf8"><div class="rgzd-grid">' +
      visible.slice(0, 6).map(function (a) {
        return '<article class="rgzd-card" style="--card-accent:' + esc(a.accent || "#38bdf8") + '">' +
          '<div class="rgzd-card-top"><div class="rgzd-icon">' + iconSvg(a.icon) + "</div>" +
          '<div class="rgzd-badges"><span class="rgzd-badge cat">' + esc(a.category || "") + "</span>" + (a.badge ? '<span class="rgzd-badge">' + esc(a.badge) + "</span>" : "") + "</div></div>" +
          "<h3>" + esc(a.title || "Untitled") + "</h3><p>" + esc(a.desc || "") + "</p>" +
          '<div class="rgzd-card-foot">' + (a.url ? '<span class="rgzd-btn primary">Open app →</span>' : '<span class="rgzd-btn soon">Coming soon</span>') +
          (a.learnTopic ? '<span class="rgzd-btn ghost">📖 Learning</span>' : "") + "</div></article>";
      }).join("") + "</div></div>" + (visible.length > 6 ? '<p style="margin-top:10px;color:#64748b;font-size:12px">+ ' + (visible.length - 6) + " more app(s)</p>" : "");
  }

  qs(editor, "[data-add-app]").addEventListener("click", function () {
    data.push({ id: uid(), title: "New app", desc: "", category: CATS[0] || "General", icon: Object.keys(ICONS)[0] || "gear", accent: "#eb4e3c", badge: "", url: "", learnTopic: "", enabled: false });
    render(); sync();
    var rows = qsa(list, ".rgza-app-row");
    rows[rows.length - 1].classList.add("open");
  });

  /* ＋ Add app (starter template): pre-filled example row the user can edit —
     teaches the field semantics better than a blank row. */
  var starterBtn = qs(editor, "[data-add-app-starter]");
  if (starterBtn) {
    starterBtn.addEventListener("click", function () {
      data.push({
        id: "mechatronics-studio",
        title: "Mechatronics Studio",
        desc: "Describe in one or two sentences what users can design, simulate or learn with this app — and why it is worth opening.",
        category: CATS.indexOf("Mechanics") >= 0 ? "Mechanics" : (CATS[0] || "General"),
        icon: "gear",
        accent: "#f59e0b",
        badge: "New",
        url: "",
        learnTopic: "",
        enabled: false
      });
      render(); sync();
      var rows = qsa(list, ".rgza-app-row");
      rows[rows.length - 1].classList.add("open");
    });
  }

  render();
  sync();
})();

/* ---------- Learning Hub lesson form: WP media library + content templates ---------- */
(function () {
  "use strict";
  function qs(r, s) { return r.querySelector(s); }
  var contentArea = qs(document, 'textarea[name="content"]');

  /* media library picker (works when wp_enqueue_media() was called on the page) */
  function openMedia(onPick) {
    if (!window.wp || !wp.media) {
      window.alert("Media library is not available on this screen.");
      return;
    }
    var frame = wp.media({ title: "Choose an image", button: { text: "Use this image" }, multiple: false, library: { type: "image" } });
    frame.on("select", function () {
      var att = frame.state().get("selection").first().toJSON();
      if (att && att.url) onPick(att.url, att.alt || att.title || "");
    });
    frame.open();
  }

  var coverBtn = qs(document, "[data-media-cover]");
  if (coverBtn) {
    coverBtn.addEventListener("click", function (ev) {
      ev.preventDefault();
      var input = coverBtn.parentNode.querySelector('input[name="cover"]');
      openMedia(function (url) { if (input) input.value = url; });
    });
  }

  function insertAtCursor(ta, text) {
    var s = ta.selectionStart != null ? ta.selectionStart : ta.value.length;
    var e = ta.selectionEnd != null ? ta.selectionEnd : s;
    ta.value = ta.value.slice(0, s) + text + ta.value.slice(e);
    var pos = s + text.length;
    try { ta.setSelectionRange(pos, pos); } catch (err) {}
    ta.focus();
  }

  var imgBtn = qs(document, "[data-media-content]");
  if (imgBtn && contentArea) {
    imgBtn.addEventListener("click", function (ev) {
      ev.preventDefault();
      openMedia(function (url, alt) {
        insertAtCursor(contentArea,
          '\n<figure class="rgzl-fig"><img src="' + url + '" alt="' + String(alt).replace(/"/g, "&quot;") + '"><figcaption>caption</figcaption></figure>\n');
      });
    });
  }

  /* small block templates so admins can build styled lessons fast */
  var TPL = {
    formula: '\n<div class="rgzl-formula">p = F / A</div>\n',
    tip: '\n<div class="rgzl-tip">Tip text…</div>\n',
    steps: '\n<ol>\n<li><strong>Step 1</strong> — description…</li>\n<li><strong>Step 2</strong> — description…</li>\n<li><strong>Step 3</strong> — description…</li>\n</ol>\n'
  };
  Array.prototype.forEach.call(document.querySelectorAll("[data-tpl]"), function (btn) {
    btn.addEventListener("click", function (ev) {
      ev.preventDefault();
      if (contentArea && TPL[btn.getAttribute("data-tpl")]) insertAtCursor(contentArea, TPL[btn.getAttribute("data-tpl")]);
    });
  });
})();
