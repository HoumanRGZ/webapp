/* RGZ Mechanical Deck + Learning Hub — frontend behaviour (vanilla, no deps) */
(function () {
  "use strict";

  function qsa(root, sel) { return Array.prototype.slice.call(root.querySelectorAll(sel)); }

  /* ---------------- Learning hub: filters + reader modal ---------------- */
  qsa(document, "[data-rgz-learn]").forEach(function (hub) {
    var cards = qsa(hub, ".rgzl-card");
    var search = hub.querySelector(".rgzl-search input");
    var topicChips = qsa(hub, "[data-topic-chip]");
    var levelChips = qsa(hub, "[data-level-chip]");
    var empty = hub.querySelector(".rgzl-empty");
    var topic = hub.getAttribute("data-default-topic") || "all", level = "all";
    if (["all", "hydraulics", "pneumatics", "general"].indexOf(topic) === -1) topic = "all";

    var READ_KEY = "rgz.learn.read.v1";
    function readSet() {
      try { return new Set(JSON.parse(window.localStorage.getItem(READ_KEY) || "[]")); }
      catch (e) { return new Set(); }
    }
    function saveRead(set) {
      try { window.localStorage.setItem(READ_KEY, JSON.stringify(Array.from(set))); } catch (e) {}
    }
    function paintRead() {
      var set = readSet();
      cards.forEach(function (card) {
        card.classList.toggle("is-read", set.has(card.getAttribute("data-lesson")));
      });
    }
    hub.__rgzRepaintRead = function (ids) {
      var set = readSet();
      (ids || []).forEach(function (id) { set.add(id); });
      saveRead(set);
      paintRead();
    };
    paintRead();

    function apply() {
      var term = search ? search.value.trim().toLowerCase() : "";
      var visible = 0;
      cards.forEach(function (card) {
        var okT = topic === "all" || card.getAttribute("data-topic") === topic;
        var okL = level === "all" || card.getAttribute("data-level") === level;
        var okTerm = !term || card.textContent.toLowerCase().indexOf(term) !== -1;
        var show = okT && okL && okTerm;
        card.style.display = show ? "" : "none";
        if (show) visible++;
      });
      if (empty) empty.style.display = visible ? "none" : "";
    }
    if (search) search.addEventListener("input", apply);
    topicChips.forEach(function (chip) {
      chip.addEventListener("click", function () {
        topicChips.forEach(function (c) { c.classList.remove("on"); });
        chip.classList.add("on");
        topic = chip.getAttribute("data-topic-chip") || "all";
        apply();
      });
    });
    levelChips.forEach(function (chip) {
      chip.addEventListener("click", function () {
        levelChips.forEach(function (c) { c.classList.remove("on"); });
        chip.classList.add("on");
        level = chip.getAttribute("data-level-chip") || "all";
        apply();
      });
    });
    apply();

    /* modal reader */
    var backdrop = hub.querySelector(".rgzl-modal-backdrop");
    if (!backdrop) return;
    var modalTitle = backdrop.querySelector(".rgzl-modal-head h2");
    var modalMeta = backdrop.querySelector(".rgzl-modal-meta");
    var modalBody = backdrop.querySelector(".rgzl-modal-body");
    var modalFoot = backdrop.querySelector(".rgzl-modal-foot");
    var markBtn = backdrop.querySelector("[data-mark-read]");
    var currentId = null;

    function openLesson(card) {
      var id = card.getAttribute("data-lesson");
      var tpl = hub.querySelector('template[data-content="' + id + '"]');
      if (!tpl) return;
      currentId = id;
      modalTitle.textContent = card.getAttribute("data-title") || "";
      modalMeta.innerHTML = card.querySelector(".rgzl-card-top").innerHTML;
      var bodyHtml = tpl.innerHTML;
      /* cover picture on top of the reader (unless the text already includes it) */
      var cover = card.getAttribute("data-cover") || "";
      if (cover) {
        var fname = cover.split("/").pop();
        if (bodyHtml.indexOf(fname) === -1) {
          bodyHtml = '<figure class="rgzl-fig rgzl-modal-cover"><img src="' + cover +
            '" alt="' + (card.getAttribute("data-title") || "") + '"></figure>' + bodyHtml;
        }
      }
      modalBody.innerHTML = bodyHtml;
      modalFoot.querySelector(".rgzl-minutes").textContent = card.querySelector(".rgzl-minutes").textContent;
      syncMarkBtn();
      backdrop.classList.add("open");
      document.body.style.overflow = "hidden";
    }
    function close() {
      backdrop.classList.remove("open");
      document.body.style.overflow = "";
      currentId = null;
    }
    function syncMarkBtn() {
      if (!markBtn || !currentId) return;
      var on = readSet().has(currentId);
      markBtn.textContent = on ? "✓ Read" : "Mark as read";
      markBtn.classList.toggle("primary", !on);
      markBtn.classList.toggle("ghost", on);
    }
    if (markBtn) {
      markBtn.addEventListener("click", function () {
        if (!currentId) return;
        var set = readSet();
        var isRead = !set.has(currentId);
        isRead ? set.add(currentId) : set.delete(currentId);
        saveRead(set);
        paintRead();
        syncMarkBtn();
        /* persist to the server-side profile when the visitor is signed in */
        if (window.rgzDeckProgressSync) window.rgzDeckProgressSync(currentId, isRead);
      });
    }
    cards.forEach(function (card) {
      qsa(card, "[data-read-lesson]").forEach(function (btn) {
        btn.addEventListener("click", function () { openLesson(card); });
      });
    });
    backdrop.addEventListener("click", function (ev) { if (ev.target === backdrop) close(); });
    var closeBtn = backdrop.querySelector(".rgzl-close");
    if (closeBtn) closeBtn.addEventListener("click", close);
    document.addEventListener("keydown", function (ev) {
      if (ev.key === "Escape" && backdrop.classList.contains("open")) close();
    });
  });


  /* ---------------- Mechanical deck: tabs + search + category chips ---------------- */
  qsa(document, "[data-rgz-deck]").forEach(function (deck) {
    /* --- tabs (Apps / Learning) --- */
    var tabs = qsa(deck, "[data-deck-tab]");
    var panes = qsa(deck, "[data-deck-pane]");
    function showTab(name) {
      tabs.forEach(function (t) { t.classList.toggle("on", t.getAttribute("data-deck-tab") === name); });
      panes.forEach(function (p) { p.classList.toggle("on", p.getAttribute("data-deck-pane") === name); });
    }
    tabs.forEach(function (t) {
      t.addEventListener("click", function () { showTab(t.getAttribute("data-deck-tab")); });
    });

    /* --- open the Learning tab, optionally pre-filtered to a topic --- */
    function openLearn(topic, fromLink) {
      if (panes.length) showTab("learn");
      var hub = deck.querySelector('[data-deck-pane="learn"] [data-rgz-learn]') || deck.querySelector("[data-rgz-learn]");
      if (hub && topic) {
        var chip = hub.querySelector('[data-topic-chip="' + topic + '"]');
        if (chip) chip.click();
      }
      if (!fromLink || panes.length) {
        var target = deck.querySelector(".rgzd-tabsbar") || deck;
        if (target.scrollIntoView) target.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    }
    qsa(deck, "[data-learn-topic]").forEach(function (link) {
      link.addEventListener("click", function (ev) {
        ev.preventDefault();
        var topic = link.getAttribute("data-learn-topic") || "";
        openLearn(topic, true);
        var hash = "#learn" + (topic ? "-" + topic : "");
        try {
          if (history.replaceState) history.replaceState(null, "", hash);
          else location.hash = hash;
        } catch (e) {}
      });
    });

    /* --- hash deep links: #learn / #learn-hydraulics … --- */
    function fromHash() {
      var h = (location.hash || "").replace("#", "");
      if (h === "learn") { openLearn("", false); }
      else if (h.indexOf("learn-") === 0) {
        var t = h.slice(6);
        if (["hydraulics", "pneumatics", "general"].indexOf(t) !== -1) openLearn(t, false);
      }
    }
    fromHash();
    window.addEventListener("hashchange", fromHash);

    /* --- apps pane filter (scoped so the learn pane's own chips/search are untouched) --- */
    var pane = deck.querySelector('[data-deck-pane="apps"]') || deck;
    var cards = qsa(pane, ".rgzd-card");
    var search = pane.querySelector(".rgzd-search input");
    var chips = qsa(pane, ".rgzd-chip");
    var empty = pane.querySelector(".rgzd-empty");
    var cat = "all";

    function apply() {
      var term = search ? search.value.trim().toLowerCase() : "";
      var visible = 0;
      cards.forEach(function (card) {
        var okCat = cat === "all" || card.getAttribute("data-cat") === cat;
        var okTerm = !term || card.textContent.toLowerCase().indexOf(term) !== -1;
        var show = okCat && okTerm;
        card.style.display = show ? "" : "none";
        if (show) visible++;
      });
      if (empty) empty.style.display = visible ? "none" : "";
    }

    if (search) search.addEventListener("input", apply);
    chips.forEach(function (chip) {
      chip.addEventListener("click", function () {
        chips.forEach(function (c) { c.classList.remove("on"); });
        chip.classList.add("on");
        cat = chip.getAttribute("data-cat") || "all";
        apply();
      });
    });
    apply();
  });


  /* ---------------- Account: studio tokens, auth, profile, designs ---------------- */
  var TOKENS = { hydraulic: "rgzHydraulicAccountToken", pneumatic: "rgzPneumaticAccountToken" };
  function getTokens() {
    var out = {};
    try {
      Object.keys(TOKENS).forEach(function (app) {
        var t = window.localStorage.getItem(TOKENS[app]) || "";
        if (t) out[app] = t;
      });
    } catch (e) {}
    return out;
  }
  function signedIn() { return Object.keys(getTokens()).length > 0; }
  function deckPost(action, extra) {
    var cfg = window.RGZDeckConfig || {};
    if (!cfg.ajaxUrl) return Promise.reject(new Error("AJAX is not configured."));
    var body = new URLSearchParams();
    body.set("action", action);
    body.set("nonce", cfg.nonce || "");
    var tokens = getTokens();
    if (tokens.hydraulic) body.set("htoken", tokens.hydraulic);
    if (tokens.pneumatic) body.set("ptoken", tokens.pneumatic);
    Object.keys(extra || {}).forEach(function (k) { body.set(k, extra[k]); });
    return fetch(cfg.ajaxUrl, { method: "POST", credentials: "same-origin", body: body })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (!j || !j.success) throw new Error((j && j.data && j.data.message) || "Request failed.");
        return j.data;
      });
  }
  function studioPost(action, fields) {
    var cfg = window.RGZDeckConfig || {};
    var body = new URLSearchParams();
    body.set("action", action);
    Object.keys(fields || {}).forEach(function (k) { body.set(k, fields[k]); });
    return fetch(cfg.ajaxUrl, { method: "POST", credentials: "same-origin", body: body })
      .then(function (r) { return r.json(); });
  }
  /* sign in / register against BOTH studio account systems; success when at least one works */
  function studioAuth(kind, fields) {
    var apps = ["hydraulic", "pneumatic"];
    var tokens = {}, errors = [];
    function one(app) {
      return studioPost("rgz_" + app + "_" + kind, fields).then(function (j) {
        if (j && j.success && j.data && j.data.token) {
          try { window.localStorage.setItem(TOKENS[app], j.data.token); } catch (e) {}
          tokens[app] = j.data.token;
          return true;
        }
        errors.push((j && j.data && j.data.message) || "Request failed.");
        if (kind === "register") {
          return studioPost("rgz_" + app + "_login", { login: fields.email, password: fields.password }).then(function (j2) {
            if (j2 && j2.success && j2.data && j2.data.token) {
              try { window.localStorage.setItem(TOKENS[app], j2.data.token); } catch (e) {}
              tokens[app] = j2.data.token;
              return true;
            }
            return false;
          });
        }
        return false;
      }).catch(function () { errors.push("Network error."); return false; });
    }
    return one(apps[0]).then(function () { return one(apps[1]); }).then(function () {
      if (Object.keys(tokens).length) return { tokens: tokens };
      throw new Error(errors[0] || "Sign in failed.");
    });
  }
  function signOut() {
    try {
      Object.keys(TOKENS).forEach(function (app) { window.localStorage.removeItem(TOKENS[app]); });
    } catch (e) {}
  }

  /* ---------------- avatars: 60 presets = 15 icons x 4 palettes ---------------- */
  var AVATAR_ICONS = [
    '<circle cx="12" cy="8" r="3.6"/><path d="M4.5 20.5c1.6-3.6 4.3-5.4 7.5-5.4s5.9 1.8 7.5 5.4"/>',
    '<path d="M4 15a8 8 0 0 1 16 0Z"/><path d="M10 7V4.5A1.5 1.5 0 0 1 11.5 3h1A1.5 1.5 0 0 1 14 4.5V7"/><path d="M3 15h18v2H3z"/>',
    '<circle cx="12" cy="12" r="3.4"/><path d="M12 2.8v3M12 18.2v3M4.5 6.5l2.1 2.1M17.4 15.4l2.1 2.1M2.8 12h3M18.2 12h3M4.5 17.5l2.1-2.1M17.4 8.6l2.1-2.1"/>',
    '<path d="M14.5 6.5a4 4 0 0 0-5.6 5L3 17.4V21h3.6l5.9-5.9a4 4 0 0 0 5-5.6L14 13l-3-3 3.5-3.5Z"/>',
    '<path d="M12 2.7s6.5 7.2 6.5 11.6a6.5 6.5 0 0 1-13 0C5.5 9.9 12 2.7 12 2.7Z"/><path d="M9 14.5a3.2 3.2 0 0 0 3 3"/>',
    '<path d="M3 11h9.5a3 3 0 1 0-3-3"/><path d="M3 15.5h13.5a3 3 0 1 1-3 3"/><path d="M3 19.5h5"/>',
    '<path d="M13 2.5 4.5 13.5H11l-1 8 8.5-11H12l1-8Z"/>',
    '<circle cx="12" cy="13" r="8.5"/><path d="M12 13l4-4.5M6.5 19.5h11"/>',
    '<path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v17.5H6.5A2.5 2.5 0 0 0 4 22V4.5Z"/><path d="M8 6.5h8M8 10h6"/>',
    '<rect x="5" y="8" width="14" height="10" rx="2"/><path d="M12 4v4M8.5 18v3M15.5 18v3"/><circle cx="9.3" cy="12.5" r="1.1" fill="currentColor" stroke="none"/><circle cx="14.7" cy="12.5" r="1.1" fill="currentColor" stroke="none"/>',
    '<path d="M12 15c-2-1-3.5-4-3.5-7C8.5 4 10 2.5 12 2.5S15.5 4 15.5 8c0 3-1.5 6-3.5 7Z"/><path d="M8.5 11 6 15l3.5-.8M15.5 11 18 15l-3.5-.8"/>',
    '<path d="M9 3h6M10 3v6.5L4.5 19a2 2 0 0 0 1.8 3h11.4a2 2 0 0 0 1.8-3L14 9.5V3"/><path d="M7.5 15h9"/>',
    '<rect x="2.5" y="9" width="13" height="6"/><path d="M15.5 12h6M7 4v5M7 20v-5"/>',
    '<rect x="3" y="8" width="18" height="8"/><path d="M9 8v8M15 8v8M12 4v4M5 12h2M17 12h2"/>',
    '<path d="m12 2 3 6.6 7 .8-5.2 4.8 1.5 7L12 17.7 5.7 21.2l1.5-7L2 9.4l7-.8Z"/>'
  ];
  var AVATAR_PALS = [
    ["#f97362", "#b3402f"], ["#56ccf2", "#1d6fb8"], ["#4ade80", "#0e7a55"], ["#c4b5fd", "#6d28d9"]
  ];
  function avatarKeyOk(k) { return /^a([0-9]|[1-5][0-9])$/.test(k || ""); }
  function avatarSvg(key) {
    if (!avatarKeyOk(key)) key = "a0";
    var n = parseInt(key.slice(1), 10);
    var icon = AVATAR_ICONS[Math.floor(n / 4) % AVATAR_ICONS.length];
    var pal = AVATAR_PALS[n % 4];
    var id = "rgzav" + n;
    return '<svg viewBox="0 0 24 24" aria-hidden="true">' +
      '<defs><linearGradient id="' + id + '" x1="0" y1="0" x2="1" y2="1">' +
      '<stop offset="0" stop-color="' + pal[0] + '"/><stop offset="1" stop-color="' + pal[1] + '"/></linearGradient></defs>' +
      '<circle cx="12" cy="12" r="11.4" fill="url(#' + id + ')"/>' +
      '<g fill="none" stroke="#fff" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' + icon + "</g></svg>";
  }

  /* ---------------- deck modals ---------------- */
  function pmOpen(name) {
    var b = document.querySelector('.rgzpm-backdrop[data-rgzpm="' + name + '"]');
    if (b) { b.classList.add("open"); document.body.style.overflow = "hidden"; }
    return b;
  }
  function pmClose(b) {
    if (b) { b.classList.remove("open"); document.body.style.overflow = ""; }
  }
  qsa(document, ".rgzpm-backdrop").forEach(function (b) {
    b.addEventListener("click", function (ev) { if (ev.target === b || ev.target.closest("[data-rgzpm-close]")) pmClose(b); });
    document.addEventListener("keydown", function (ev) { if (ev.key === "Escape" && b.classList.contains("open")) pmClose(b); });
  });

  /* ---------------- profile state + UI ---------------- */
  var PROFILE = null;
  var DESIGN_CACHE = null;

  function paintUserChip() {
    var nameEl = document.querySelector("[data-rgz-user-name]");
    var avaEl = document.querySelector("[data-rgz-user-ava]");
    if (!nameEl || !avaEl) return;
    if (PROFILE && PROFILE.email) {
      var p = PROFILE.profile || {};
      nameEl.textContent = (p.first_name || "").trim() || PROFILE.email.split("@")[0];
      avaEl.innerHTML = avatarSvg(p.avatar || "a0");
    } else {
      nameEl.textContent = signedIn() ? "My account" : "Sign in / Sign up";
      avaEl.innerHTML = signedIn() ? avatarSvg("a0") :
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="3.6"/><path d="M4.5 20.5c1.6-3.6 4.3-5.4 7.5-5.4s5.9 1.8 7.5 5.4"/></svg>';
    }
    var head = document.querySelector("[data-rgz-user-head]");
    if (head) {
      if (PROFILE && PROFILE.email) {
        var pr = PROFILE.profile || {};
        head.querySelector("[data-rgz-user-fullname]").textContent = ((pr.first_name || "") + " " + (pr.last_name || "")).trim() || "(no name yet)";
        head.querySelector("[data-rgz-user-mail]").textContent = PROFILE.email;
        head.hidden = false;
      } else { head.hidden = true; }
    }
  }

  function paintProgress() {
    var bar = document.querySelector("[data-rgzp-bar]");
    if (!bar) return;
    var label = document.querySelector("[data-rgzp-barlabel]");
    var list = document.querySelector("[data-rgzp-readlist]");
    var total = document.querySelectorAll("[data-lesson]").length;
    var read = (PROFILE && PROFILE.progress) || [];
    var inLib = read.filter(function (id) { return document.querySelector('[data-lesson="' + id + '"]'); });
    bar.style.width = total ? Math.round((inLib.length / total) * 100) + "%" : "0%";
    if (label) label.textContent = inLib.length + " / " + total + " lessons read";
    if (list) {
      list.innerHTML = "";
      if (!inLib.length) {
        list.innerHTML = '<li class="none">No lessons finished yet — open the Learning tab and start the designer track.</li>';
      } else {
        inLib.slice(0, 6).forEach(function (id) {
          var card = document.querySelector('[data-lesson="' + id + '"]');
          var li = document.createElement("li");
          li.textContent = "✓ " + ((card && card.getAttribute("data-title")) || id);
          list.appendChild(li);
        });
        if (inLib.length > 6) {
          var more = document.createElement("li");
          more.className = "more"; more.textContent = "+ " + (inLib.length - 6) + " more — keep going!";
          list.appendChild(more);
        }
      }
    }
  }

  var pickedAvatar = "a0";
  function paintAvatarPicker(current) {
    var grid = document.querySelector("[data-rgzp-avatars]");
    if (!grid) return;
    if (!grid.children.length) {
      for (var n = 0; n < 60; n++) {
        var b = document.createElement("button");
        b.type = "button";
        b.className = "rgzp-ava-opt";
        b.setAttribute("data-ava", "a" + n);
        b.innerHTML = avatarSvg("a" + n);
        grid.appendChild(b);
      }
      grid.addEventListener("click", function (ev) {
        var btn = ev.target.closest("[data-ava]");
        if (!btn) return;
        pickedAvatar = btn.getAttribute("data-ava");
        qsa(grid, "[data-ava]").forEach(function (o) { o.classList.toggle("on", o === btn); });
      });
    }
    pickedAvatar = avatarKeyOk(current) ? current : "a0";
    qsa(grid, "[data-ava]").forEach(function (o) { o.classList.toggle("on", o.getAttribute("data-ava") === pickedAvatar); });
  }

  function fillProfileModal() {
    if (!PROFILE) return;
    var p = PROFILE.profile || {};
    qsa(document, "[data-rgzp-f]").forEach(function (inp) {
      inp.value = p[inp.getAttribute("data-rgzp-f")] || "";
    });
    var em = document.querySelector("[data-rgzp-email]");
    if (em) em.textContent = PROFILE.email + ((PROFILE.sources || []).length ? " · signed in via " + PROFILE.sources.join(" + ") : "");
    paintAvatarPicker(p.avatar || "a0");
    paintProgress();
  }

  function refreshProfile() {
    if (!signedIn()) { PROFILE = null; paintUserChip(); return Promise.resolve(null); }
    return deckPost("rgz_deck_profile").then(function (d) {
      PROFILE = d;
      DESIGN_CACHE = null;
      paintUserChip();
      /* merge the server copy of reading progress into the lesson cards */
      if (d && d.progress && d.progress.length) {
        qsa(document, "[data-rgz-learn]").forEach(function (hub) {
          if (hub.__rgzRepaintRead) hub.__rgzRepaintRead(d.progress);
        });
      }
      return d;
    }).catch(function () { PROFILE = null; paintUserChip(); return null; });
  }

  function escapeHtml(s) {
    return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; });
  }

  /* top bar chip + dropdown */
  (function () {
    var wrap = document.querySelector("[data-rgz-user-wrap]");
    if (!wrap) return;
    var chip = wrap.querySelector("[data-rgz-user-chip]");
    var menu = wrap.querySelector("[data-rgz-user-menu]");
    function toggleMenu(show) { if (menu) menu.hidden = !show; }
    chip.addEventListener("click", function (ev) {
      ev.stopPropagation();
      if (!(PROFILE && PROFILE.email)) {
        if (signedIn()) {
          refreshProfile().then(function (d) { if (!d) pmOpen("auth"); else toggleMenu(true); });
          return;
        }
        pmOpen("auth");
        return;
      }
      toggleMenu(menu ? menu.hidden : false);
    });
    document.addEventListener("click", function (ev) { if (!ev.target.closest("[data-rgz-user-wrap]")) toggleMenu(false); });
    qsa(wrap, "[data-rgz-user-action]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        var act = btn.getAttribute("data-rgz-user-action");
        toggleMenu(false);
        if (act === "logout") { signOut(); PROFILE = null; DESIGN_CACHE = null; paintUserChip(); return; }
        if (act === "profile") {
          refreshProfile().then(function (d) { if (d) { fillProfileModal(); pmOpen("profile"); } else pmOpen("auth"); });
          return;
        }
        if (act === "designs") { openDesignsModal(); }
      });
    });
  })();

  /* auth modal */
  (function () {
    var modal = document.querySelector('.rgzpm-backdrop[data-rgzpm="auth"]');
    if (!modal) return;
    var status = modal.querySelector("[data-rgz-auth-status]");
    function setStatus(msg, ok) {
      status.textContent = msg || "";
      status.classList.toggle("ok", !!ok);
      status.classList.toggle("err", !!msg && !ok);
    }
    qsa(modal, "[data-rgz-auth-tab]").forEach(function (t) {
      t.addEventListener("click", function () {
        var tab = t.getAttribute("data-rgz-auth-tab");
        qsa(modal, "[data-rgz-auth-tab]").forEach(function (o) { o.classList.toggle("on", o === t); });
        qsa(modal, "[data-rgz-auth-pane]").forEach(function (p) { p.classList.toggle("on", p.getAttribute("data-rgz-auth-pane") === tab); });
        var title = modal.querySelector("[data-rgzpm-auth-title]");
        if (title) title.textContent = tab === "signup" ? "Create account" : "Sign in";
        setStatus("");
      });
    });
    qsa(modal, "[data-rgz-auth-go]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        var mode = btn.getAttribute("data-rgz-auth-go");
        btn.disabled = true;
        setStatus(mode === "signup" ? "Creating your account…" : "Signing in…", true);
        var fields = mode === "signup"
          ? {
              name: (modal.querySelector("[data-rgz-auth-name]") || {}).value || "",
              email: (modal.querySelector("[data-rgz-auth-email]") || {}).value || "",
              password: (modal.querySelector("[data-rgz-auth-pass2]") || {}).value || "",
            }
          : {
              login: (modal.querySelector("[data-rgz-auth-login]") || {}).value || "",
              password: (modal.querySelector("[data-rgz-auth-pass]") || {}).value || "",
            };
        studioAuth(mode === "signup" ? "register" : "login", fields)
          .then(function () { setStatus("Welcome! Loading your profile…", true); return refreshProfile(); })
          .then(function (d) {
            btn.disabled = false;
            if (d && d.email) { pmClose(modal); fillProfileModal(); pmOpen("profile"); }
            else setStatus("Signed in, but the profile could not be loaded — reload the page.", false);
          })
          .catch(function (err) {
            btn.disabled = false;
            setStatus(err.message || "Sign in failed.", false);
          });
      });
    });
  })();

  /* profile modal save */
  (function () {
    var saveBtn = document.querySelector("[data-rgzp-save]");
    if (!saveBtn) return;
    var st = document.querySelector("[data-rgzp-status]");
    function setSt(txt, cls) { if (st) { st.textContent = txt; st.className = "rgzp-status " + (cls || ""); } }
    saveBtn.addEventListener("click", function () {
      var extra = { avatar: pickedAvatar };
      qsa(document, "[data-rgzp-f]").forEach(function (inp) { extra[inp.getAttribute("data-rgzp-f")] = inp.value; });
      saveBtn.disabled = true;
      setSt("Saving…");
      deckPost("rgz_deck_profile_save", extra).then(function (d) {
        PROFILE = d;
        saveBtn.disabled = false;
        setSt("✓ Saved to your account", "ok");
        paintUserChip();
        fillProfileModal();
      }).catch(function (err) {
        saveBtn.disabled = false;
        setSt(err.message || "Save failed", "err");
      });
    });
  })();

  /* ---------------- My designs modal with blueprint previews ---------------- */
  function thumbSVG(thumb, app) {
    if (!thumb || !thumb.comps || !thumb.comps.length) return "";
    var x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    thumb.comps.forEach(function (c) {
      var swap = (c[3] % 180) !== 0;
      var w = swap ? c[5] : c[4], h = swap ? c[4] : c[5];
      x0 = Math.min(x0, c[1] - w / 2); x1 = Math.max(x1, c[1] + w / 2);
      y0 = Math.min(y0, c[2] - h / 2); y1 = Math.max(y1, c[2] + h / 2);
    });
    (thumb.conns || []).forEach(function (l) {
      x0 = Math.min(x0, l[0], l[2]); x1 = Math.max(x1, l[0], l[2]);
      y0 = Math.min(y0, l[1], l[3]); y1 = Math.max(y1, l[1], l[3]);
    });
    var pad = 26;
    x0 -= pad; y0 -= pad; x1 += pad; y1 += pad;
    var accent = app === "pneumatic" ? "#e8793c" : "#38bdf8";
    var s = "";
    (thumb.conns || []).forEach(function (l) {
      var ecl = l[4] === "electrical" ? "#4ade80" : (l[4] === "pilot" ? "#c4b5fd" : "#8ea6c8");
      s += '<line x1="' + l[0] + '" y1="' + l[1] + '" x2="' + l[2] + '" y2="' + l[3] + '" stroke="' + ecl + '" stroke-width="7" stroke-linecap="round"' + (l[4] === "electrical" ? ' stroke-dasharray="16 12"' : "") + "/>";
    });
    thumb.comps.forEach(function (c) {
      var swap = (c[3] % 180) !== 0;
      var w = swap ? c[5] : c[4], h = swap ? c[4] : c[5];
      s += '<rect x="' + (c[1] - w / 2) + '" y="' + (c[2] - h / 2) + '" width="' + w + '" height="' + h + '" rx="14" fill="rgba(226,238,255,.08)" stroke="' + accent + '" stroke-width="6"/>';
    });
    return '<svg viewBox="' + x0 + " " + y0 + " " + (x1 - x0) + " " + (y1 - y0) + '" preserveAspectRatio="xMidYMid meet">' + s + "</svg>";
  }
  function renderDesignList(grid, list, app) {
    if (!grid) return;
    if (!list || !list.length) {
      grid.innerHTML = '<div class="rgzdsg-none">No saved circuits yet — open the ' + (app === "pneumatic" ? "Pneumatic" : "Hydraulic") + " Studio, design something and save it to your account.</div>";
      return;
    }
    grid.innerHTML = "";
    list.forEach(function (d) {
      var a = document.createElement(d.open ? "a" : "div");
      a.className = "rgzdsg-card";
      if (d.open) a.href = d.open;
      var thumb = thumbSVG(d.thumb, app);
      a.innerHTML =
        '<span class="rgzdsg-thumb">' + (thumb ||
          '<span class="rgzdsg-ph"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="14" rx="2"/><path d="M3 9h18M8 4v5"/></svg></span>') +
        "</span>" +
        '<span class="rgzdsg-meta"><b>' + escapeHtml(d.name || "design.rgz") + "</b>" +
        "<span>" + escapeHtml((d.date || "").slice(0, 16).replace("T", " ")) + " · " + Math.max(1, Math.round((d.size || 0) / 1024)) + " KB</span></span>" +
        '<span class="rgzdsg-open">Open in ' + (app === "pneumatic" ? "Pneumatics" : "Hydraulics") + " →</span>";
      grid.appendChild(a);
    });
  }
  function openDesignsModal() {
    var modal = pmOpen("designs");
    if (!modal) return;
    var gh = modal.querySelector('[data-rgz-designs="hydraulic"]');
    var gp = modal.querySelector('[data-rgz-designs="pneumatic"]');
    function paint(designs) {
      renderDesignList(gh, (designs && designs.hydraulic) || [], "hydraulic");
      renderDesignList(gp, (designs && designs.pneumatic) || [], "pneumatic");
    }
    if (DESIGN_CACHE) { paint(DESIGN_CACHE); return; }
    if (gh) gh.innerHTML = '<div class="rgzdsg-none">Loading your designs…</div>';
    if (gp) gp.innerHTML = "";
    deckPost("rgz_deck_designs").then(function (d) {
      DESIGN_CACHE = d.designs || {};
      paint(DESIGN_CACHE);
    }).catch(function (err) {
      if (gh) gh.innerHTML = '<div class="rgzdsg-none">' + escapeHtml(err.message || "Could not load designs.") + "</div>";
      if (gp) gp.innerHTML = "";
    });
  }

  /* server-side learning progress sync */
  window.rgzDeckProgressSync = function (lessonId, isRead) {
    if (!signedIn()) return;
    deckPost("rgz_deck_progress_save", { lesson: lessonId, read: isRead ? "1" : "0" })
      .then(function (d) { PROFILE = d; paintProgress(); })
      .catch(function () {});
  };

  /* initial paint */
  refreshProfile();

  /* ---------------- unit converter (every instance: hero + mobile) ---------------- */
  Array.prototype.slice.call(document.querySelectorAll("[data-rgz-conv]")).forEach(function (box) {
    var GROUPS = [
      ["Fluid power & flow", [
        ["pressure", "Pressure", {
          Pa: 1, kPa: 1e3, MPa: 1e6, GPa: 1e9, bar: 1e5, mbar: 100, psi: 6894.757, "psf (lbf/ft²)": 47.88026, atm: 101325,
          "at (kgf/cm²)": 98066.5, mmHg: 133.322, inHg: 3386.389, "in H₂O": 249.082, "m H₂O": 9806.65, Torr: 133.322
        }],
        ["flow", "Volume flow", {
          "m³/s": 1, "L/min": 1e-3 / 60, "L/s": 1e-3, "m³/h": 1 / 3600, "mL/s": 1e-6,
          "GPM (US)": 6.30902e-5, "GPM (UK)": 7.57682e-5, "CFM (ft³/min)": 4.71947e-4, "ft³/s": 0.02831685
        }],
        ["massflow", "Mass flow", {
          "kg/s": 1, "kg/min": 1 / 60, "kg/h": 1 / 3600, "g/s": 1e-3, "t/h": 1000 / 3600,
          "lb/s": 0.4535924, "lb/min": 0.4535924 / 60, "lb/h": 0.4535924 / 3600,
          "Nm³/h (air)": 1.2041 / 3600, "Nl/min (air)": 1.2041 / 60000
        }],
        ["disp", "Pump / motor displacement", { "cm³/rev": 1e-6, "mL/rev": 1e-6, "in³/rev": 1.6387064e-5, "L/rev": 1e-3 }]
      ]],
      ["Mechanics", [
        ["length", "Length / distance", {
          m: 1, mm: 0.001, cm: 0.01, km: 1000, "in": 0.0254, ft: 0.3048, yd: 0.9144, mi: 1609.344, "mil (thou)": 2.54e-5, "µm": 1e-6
        }],
        ["area", "Area", { "m²": 1, "mm²": 1e-6, "cm²": 1e-4, "dm²": 0.01, ha: 1e4, "in²": 6.4516e-4, "ft²": 0.092903, "yd²": 0.836127 }],
        ["volume", "Volume", {
          "m³": 1, L: 1e-3, mL: 1e-6, "cm³": 1e-6, "mm³": 1e-9,
          "in³": 1.6387064e-5, "ft³": 0.0283168, "gal (US)": 0.00378541, "gal (UK)": 0.00454609, "bbl (oil)": 0.1589873
        }],
        ["mass", "Mass", { kg: 1, g: 0.001, mg: 1e-6, t: 1000, lb: 0.4535924, oz: 0.02834952, "ton (US)": 907.1847 }],
        ["density", "Density", { "kg/m³": 1, "g/cm³": 1000, "kg/L": 1000, "lb/ft³": 16.01846, "lb/in³": 27679.9 }],
        ["force", "Force", {
          N: 1, mN: 1e-3, kN: 1000, MN: 1e6, kgf: 9.80665, lbf: 4.448222, ozf: 0.2780139, dyn: 1e-5, "tf (metric)": 9806.65, "pdl (poundal)": 0.138255
        }],
        ["torque", "Torque", {
          "N·m": 1, "kN·m": 1000, "N·mm": 1e-3, "daN·m": 10, "kgf·m": 9.80665, "kgf·cm": 0.0980665, "lbf·ft": 1.355818, "lbf·in": 0.1129848, "ozf·in": 0.00706155
        }],
        ["speed", "Speed / velocity", {
          "m/s": 1, "mm/s": 0.001, "cm/s": 0.01, "m/min": 1 / 60, "km/h": 1 / 3.6, "ft/s": 0.3048, "ft/min": 0.00508, mph: 0.44704, kn: 0.514444
        }],
        ["accel", "Acceleration", { "m/s²": 1, "cm/s²": 0.01, "ft/s²": 0.3048, "g (standard)": 9.80665, "Gal": 0.01 }],
        ["inertia", "Moment of inertia", { "kg·m²": 1, "kg·cm²": 1e-4, "g·cm²": 1e-7, "lb·ft²": 0.0421401, "lb·in²": 2.9264e-4, "oz·in²": 1.829e-5 }],
        ["power", "Power", {
          W: 1, mW: 1e-3, kW: 1000, MW: 1e6, "hp (metric/PS)": 735.4988, "hp (US)": 745.6999, "kcal/h": 1.163, "BTU/h": 0.2930711, "ft·lbf/s": 1.355818
        }],
        ["energy", "Energy / work", {
          J: 1, kJ: 1000, MJ: 1e6, Wh: 3600, kWh: 3.6e6, cal: 4.1868, kcal: 4186.8, BTU: 1055.056, "ft·lbf": 1.355818, "N·m": 1
        }],
        ["rotation", "Rotational speed", { "rad/s": 1, rpm: 0.1047198, Hz: 6.283185, "deg/s": 0.01745329 }],
        ["angle", "Angle", { "rad": 1, "° (deg)": 0.01745329, gon: 0.01570796, rev: 6.283185, mrad: 0.001 }]
      ]],
      ["Thermal", [
        ["temperature", "Temperature", { "°C": 1, "°F": 1, K: 1 }],
        ["specheat", "Specific heat capacity", { "J/(kg·K)": 1, "kJ/(kg·K)": 1000, "cal/(g·°C)": 4186.8, "kcal/(kg·°C)": 4186.8, "BTU/(lb·°F)": 4186.8 }],
        ["heatflux", "Heat flux density", { "W/m²": 1, "kW/m²": 1000, "W/cm²": 1e4, "BTU/(h·ft²)": 3.154591, "kcal/(h·m²)": 1.163 }]
      ]],
      ["Electrical & magnetic", [
        ["current", "Electric current", { A: 1, mA: 1e-3, kA: 1000, "µA": 1e-6 }],
        ["voltage", "Electric voltage", { V: 1, mV: 1e-3, kV: 1000, "µV": 1e-6 }],
        ["resistance", "Electric resistance", { "Ω": 1, "mΩ": 1e-3, "kΩ": 1000, "MΩ": 1e6 }],
        ["efreq", "Frequency", { Hz: 1, kHz: 1000, MHz: 1e6, GHz: 1e9, "rpm": 1 / 60 }],
        ["charge", "Electric charge", { C: 1, mC: 1e-3, Ah: 3600, mAh: 3.6 }],
        ["capacitance", "Capacitance", { F: 1, "µF": 1e-6, nF: 1e-9, pF: 1e-12, mF: 1e-3 }],
        ["inductance", "Inductance", { H: 1, mH: 1e-3, "µH": 1e-6 }],
        ["magflux", "Magnetic flux density", { T: 1, mT: 1e-3, "µT": 1e-6, "G (gauss)": 1e-4 }]
      ]],
      ["Light & optics", [
        ["lumflux", "Luminous flux", { lm: 1, "cd·sr": 1 }],
        ["lumint", "Luminous intensity", { cd: 1, "mcd": 1e-3, Hefnerkerze: 0.92 }],
        ["illuminance", "Illuminance", { lx: 1, klx: 1000, "fc (foot-candle)": 10.76391, "ph (phot)": 1e4 }],
        ["luminance", "Luminance", { "cd/m²": 1, nit: 1, knits: 1000, "fL (foot-lambert)": 3.426259, "sb (stilb)": 1e4 }],
        ["radiantflux", "Radiant flux", { W: 1, mW: 1e-3, kW: 1000 }],
        ["dosage", "Optical power density", { "W/m²": 1, "mW/m²": 1e-3, "W/cm²": 1e4, "mW/cm²": 10 }]
      ]]
    ];
    var Q = [];
    GROUPS.forEach(function (g) { g[1].forEach(function (q) { Q.push(q); }); });
    var qtyWrap = box.querySelector("[data-rgzc-qty]");
    var inp = box.querySelector("[data-rgzc-in]");
    var from = box.querySelector("[data-rgzc-from]");
    var to = box.querySelector("[data-rgzc-to]");
    var out = box.querySelector("[data-rgzc-out]");
    var formula = box.querySelector("[data-rgzc-formula]");
    var qty = Q[0];

    function fillUnits() {
      var names = Object.keys(qty[2]);
      from.innerHTML = names.map(function (u) { return '<option value="' + u + '">' + u + "</option>"; }).join("");
      to.innerHTML = from.innerHTML;
      var defs = {
        pressure: ["bar", "psi"], flow: ["L/min", "GPM (US)"], massflow: ["kg/h", "lb/min"], disp: ["cm³/rev", "in³/rev"],
        volume: ["L", "gal (US)"], length: ["mm", "in"], force: ["kN", "lbf"], power: ["kW", "hp (metric/PS)"],
        temperature: ["°C", "°F"], kinvisc: ["mm²/s (cSt)", "m²/s"], rotation: ["rpm", "rad/s"], mass: ["kg", "lb"],
        accel: ["g (standard)", "m/s²"], illuminance: ["lx", "fc (foot-candle)"], luminance: ["nit", "fL (foot-lambert)"],
        voltage: ["V", "mV"], current: ["A", "mA"], specheat: ["kJ/(kg·K)", "BTU/(lb·°F)"], density: ["kg/m³", "lb/ft³"]
      };
      var d = defs[qty[0]] || [names[0], names[Math.min(1, names.length - 1)]];
      from.value = names.indexOf(d[0]) >= 0 ? d[0] : names[0];
      to.value = names.indexOf(d[1]) >= 0 ? d[1] : (names[1] || names[0]);
    }
    function fmt(x) {
      if (!isFinite(x)) return "—";
      var ax = Math.abs(x);
      if (ax !== 0 && (ax >= 1e9 || ax < 1e-6)) return x.toExponential(5);
      return String(parseFloat(x.toPrecision(ax >= 100 ? 6 : 7)));
    }
    function calc() {
      var v = parseFloat(inp.value);
      if (isNaN(v)) { out.textContent = "—"; formula.textContent = "Enter a number…"; return; }
      var res, inv = null;
      if (qty[0] === "temperature") {
        var c = from.value === "°F" ? (v - 32) * 5 / 9 : (from.value === "K" ? v - 273.15 : v);
        res = to.value === "°F" ? c * 9 / 5 + 32 : (to.value === "K" ? c + 273.15 : c);
      } else {
        res = v * qty[2][from.value] / qty[2][to.value];
        inv = qty[2][from.value] / qty[2][to.value];
      }
      out.textContent = fmt(res);
      formula.textContent = inv === null
        ? "°C ↔ °F ↔ K (temperature offset conversion)"
        : "1 " + from.value + " = " + fmt(inv) + " " + to.value;
    }
    function selectQty(key) {
      qty = Q.filter(function (q) { return q[0] === key; })[0] || Q[0];
      if (qtyWrap && qtyWrap.tagName === "SELECT" && qtyWrap.value !== qty[0]) qtyWrap.value = qty[0];
      fillUnits();
      calc();
    }
    /* build the classified dropdown (optgroup per category) */
    GROUPS.forEach(function (g) {
      var og = document.createElement("optgroup");
      og.label = g[0];
      g[1].forEach(function (q) {
        var op = document.createElement("option");
        op.value = q[0]; op.textContent = q[1];
        og.appendChild(op);
      });
      qtyWrap.appendChild(og);
    });
    qtyWrap.value = qty[0];
    qtyWrap.addEventListener("change", function () { selectQty(qtyWrap.value); });
    fillUnits();
    inp.addEventListener("input", calc);
    from.addEventListener("change", calc);
    to.addEventListener("change", calc);
    box.querySelector("[data-rgzc-swap]").addEventListener("click", function () {
      var f = from.value; from.value = to.value; to.value = f; calc();
    });
    box.querySelector("[data-rgzc-copy]").addEventListener("click", function () {
      var txt = out.textContent + " " + to.value;
      var btn = box.querySelector("[data-rgzc-copy]");
      function done() { btn.classList.add("copied"); setTimeout(function () { btn.classList.remove("copied"); }, 1100); }
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(txt).then(done, done);
      else done();
    });
    calc();
  });
})();