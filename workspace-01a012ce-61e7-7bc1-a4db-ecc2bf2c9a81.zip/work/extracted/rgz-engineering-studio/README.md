# RGZ Engineering Studio (v1.0.0)

Combined WordPress plugin for **RGZ Hydraulic Studio** and **RGZ Pneumatic Studio**, plus the
**Mechanical Engineering Deck** landing page, guided onboarding tours and the
**Learning Hub** encyclopedia with 320+ lessons (>=150 per subject): every studio element, real circuit-design patterns and engineering fundamentals, with reader modal and read progress.

## Shortcodes

| Shortcode | What it renders |
|---|---|
| `[rgz_mechanical_deck]` | Landing page ("deck") with all engineering apps — searchable, filterable, admin-configurable |
| `[rgz_learning_hub]` | Learning encyclopedia (>=150 lessons per subject) about hydraulics and pneumatics with reader modal and read progress |
| `[rgz_hydraulic_studio]` | The Hydraulic Studio app |
| `[rgz_pneumatic_studio]` | The Pneumatic Studio app |

## Admin

* **RGZ Engineering Studio → Overview** — dashboard with stats, links and shortcode reference.
* **RGZ Engineering Studio → Mechanical Deck** — app manager (add/reorder/brand apps),
  landing-page appearance, guided tutorial switches, JSON export/import.
* **RGZ Engineering Studio → Learning Hub** — lesson editor (topic, level, reading time, HTML content).

Guided tours run automatically the first time a visitor opens a studio (skippable with
*Skip* or *Esc*; remembered per visitor). Replay any time with `?rgz_tour=1` appended to
the studio page URL — or via the *▶ Guided tour* button on the deck.

## Extending the deck (adding apps)

* **Site owners:** `docs/ADDING-AN-APP.md` — install an app the developer sent you as one
  `.zip` package in *Mechanical Deck → Apps → Install app package*, then create a page with
  the shortcode it declares. Also: simple link-cards (＋ Add app), backup/restore, troubleshooting.
* **Developers & AI agents:** `docs/APP-DEVELOPMENT-GUIDE.md` — the app-package format
  (`rgz-app.json` + `app.php`, developer-chosen shortcode auto-registered by the plugin),
  contracts, coding rules, build/test/ship workflow, plus the `rgz_deck_*` extension hooks.
* **Starter scaffold:** `docs/app-package-template.zip` (sources in `docs/app-package-template/`) —
  a ready, working app package the developer edits and zips.

Installed packages live in `wp-content/uploads/rgz-apps/`, so plugin updates never remove them.
Their PHP is only ever `include`d by WordPress (direct web execution is blocked where honored),
their entry files are test-loaded during install, and load failures surface as admin badges — never fatal errors.

## Notes

* Circuit symbols follow ISO 1219; cartridge/logic valves use the widely used DIN poppet style.
* Requires WordPress 5.8+ and PHP 7.4+.
* Deactivate the old separate plugins before activating this combined plugin.
