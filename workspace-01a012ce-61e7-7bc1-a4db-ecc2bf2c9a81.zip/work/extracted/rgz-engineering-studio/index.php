<?php
// Silence is golden.
if (!defined('ABSPATH')) {
    http_response_code(403);
    exit;
}
