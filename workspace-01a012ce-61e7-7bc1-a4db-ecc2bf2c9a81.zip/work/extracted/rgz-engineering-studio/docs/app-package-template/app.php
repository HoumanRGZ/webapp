<?php
/**
 * RGZ app package — demo entry file.
 *
 * Rename the class + shortcode in rgz-app.json, keep the ABSPATH guard line,
 * and build your app inside render_shortcode(). Full contract:
 * docs/APP-DEVELOPMENT-GUIDE.md (section "The app package format").
 *
 * What this demo shows:
 *  1. the manifest auto-registers [rgz_mechatronics_demo] to ::render_shortcode
 *     (no add_shortcode call needed here — the plugin does it);
 *  2. enqueueing assets from the package folder via package_url()/package_path()
 *     (commented example for style.css / app.js — create the files to use it);
 *  3. a self-contained demo app (inline assets localized config, AJAX ping)
 *     so the package works the second it is installed.
 */
if (!defined('ABSPATH')) { exit; } /* REQUIRED — never remove */

final class RGZ_Mechatronics_Demo {
    const NONCE = 'rgz_mechatronics_demo_public';

    /* ---------------------------------------------------------------
     * Front-end entry — the plugin calls this for [rgz_mechatronics_demo].
     * A shortcode must RETURN its markup (never echo).
     * --------------------------------------------------------------- */
    public static function render_shortcode($atts = []) {
        $atts = shortcode_atts(['title' => 'Mechatronics Demo'], $atts, 'rgz_mechatronics_demo');

        /* (2) Asset pattern — files live next to this app.php in your package:
        $css = RGZ_Mech_App_Packages::package_path('mechatronics-demo') . 'style.css';
        $js  = RGZ_Mech_App_Packages::package_path('mechatronics-demo') . 'app.js';
        if (file_exists($css)) {
            wp_enqueue_style('rgz-mechatronics-demo', RGZ_Mech_App_Packages::package_url('mechatronics-demo') . 'style.css', [], '1.0.0-' . filemtime($css));
        }
        if (file_exists($js)) {
            wp_enqueue_script('rgz-mechatronics-demo', RGZ_Mech_App_Packages::package_url('mechatronics-demo') . 'app.js', [], '1.0.0-' . filemtime($js), true);
        }
        */

        /* (3) Demo keeps its assets inline so a single file works out of the box. */
        wp_register_style('rgz-mechatronics-demo-inline', false, [], '1.0.0');
        wp_add_inline_style('rgz-mechatronics-demo-inline', self::css());
        wp_enqueue_style('rgz-mechatronics-demo-inline');
        wp_register_script('rgz-mechatronics-demo-inline', false, [], '1.0.0', true);
        wp_add_inline_script('rgz-mechatronics-demo-inline', self::js());
        wp_enqueue_script('rgz-mechatronics-demo-inline');
        wp_localize_script('rgz-mechatronics-demo-inline', 'RGZMechaDemo', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce(self::NONCE),
        ]);

        ob_start();
        ?>
        <div class="rgzmd" style="--rgzmd-accent:#f59e0b">
          <div class="rgzmd-head">
            <h2><?php echo esc_html($atts['title']); ?></h2>
            <p class="rgzmd-sub">Installed from an app package — replace this shell with the real app (see app.php in your package).</p>
          </div>
          <div class="rgzmd-body">
            <p>The wiring already works: scoped styles, localized AJAX config (<code>RGZMechaDemo.ajaxUrl</code>) and a nonce-secured endpoint.</p>
            <p><button type="button" class="rgzmd-btn" data-rgzmd-ping>Ping the server (AJAX demo)</button> <span class="rgzmd-out" data-rgzmd-out aria-live="polite"></span></p>
          </div>
        </div>
        <?php
        return ob_get_clean();
    }

    private static function css() {
        return '.rgzmd{max-width:880px;margin:0 auto;color:#0f172a}'
            . '.rgzmd-head h2{margin:0 0 4px;font-size:1.6rem}'
            . '.rgzmd-sub{margin:0;color:#64748b;font-size:.95rem}'
            . '.rgzmd-body{margin-top:14px;padding:18px;border:1.5px solid #e2e8f0;border-radius:16px;background:#fff}'
            . '.rgzmd-btn{background:var(--rgzmd-accent,#f59e0b);color:#fff;border:0;border-radius:999px;padding:10px 18px;font-weight:700;cursor:pointer}'
            . '.rgzmd-btn:focus-visible{outline:3px solid rgba(0,0,0,.25);outline-offset:2px}'
            . '.rgzmd-out{margin-left:10px;color:#16a34a;font-weight:600}';
    }

    private static function js() {
        return 'document.addEventListener("click",function(e){'
            . 'var b=e.target.closest("[data-rgzmd-ping]");if(!b)return;'
            . 'var out=document.querySelector("[data-rgzmd-out]");'
            . 'var cfg=window.RGZMechaDemo||{};'
            . 'var fd=new FormData();'
            . 'fd.append("action","rgz_mechatronics_demo_ping");'
            . 'fd.append("nonce",cfg.nonce||"");'
            . 'fetch(cfg.ajaxUrl,{method:"POST",credentials:"same-origin",body:fd})'
            . '.then(function(r){return r.json();})'
            . '.then(function(j){out.textContent=(j&&j.success)?("pong @ "+j.data.time):"request failed";})'
            . '.catch(function(){out.textContent="network error";});'
            . '});';
    }

    /* Nonce-secured AJAX sample. Registered below (entry files load early
       enough for wp_ajax_* hooks on both front and back end). */
    public static function ajax_ping() {
        if (!wp_verify_nonce(isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '', self::NONCE)) {
            wp_send_json_error(['message' => 'bad nonce'], 403);
        }
        wp_send_json_success(['time' => current_time('mysql')]);
    }
}

add_action('wp_ajax_rgz_mechatronics_demo_ping', ['RGZ_Mechatronics_Demo', 'ajax_ping']);
add_action('wp_ajax_nopriv_rgz_mechatronics_demo_ping', ['RGZ_Mechatronics_Demo', 'ajax_ping']);
