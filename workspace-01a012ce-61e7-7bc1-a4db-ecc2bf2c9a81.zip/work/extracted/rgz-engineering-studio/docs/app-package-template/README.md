# RGZ App Package — template

This folder is the starting point for building a new app for the **RGZ Engineering Studio** plugin
(the Mechanical Deck on houmanrgz.ir). Read `docs/APP-DEVELOPMENT-GUIDE.md` — section
"The app package format" — for the full contract.

## Build & deliver (5 minutes)

1. Copy this folder and rename things:
   - `rgz-app.json` → new `id` (folder name of the installed app), `name`,
     **`shortcode` (you choose it — e.g. `rgz_mechatronics_studio`)**, `class`, `render`, `card` texts.
   - `app.php` → rename the class to match the manifest, keep the `ABSPATH` guard line, build your app
     inside `render_shortcode()`.
2. Zip **the folder contents** so `rgz-app.json` sits at the zip root (a single wrapping folder is also OK):

   ```bash
   cd my-app && zip -r ../my-app.zip . && cd ..
   ```

3. Send the site owner **that one zip**.

## What the site owner does

WP Admin → RGZ Engineering Studio → Mechanical Deck → Apps → **Install app package (.zip)** →
choose the zip → *Install package*. Then: Pages → Add New → paste `[your_shortcode]` → Publish.
Your deck card appears and links to that page automatically.

## Rules that will cause a rejection if broken

- `id`: 2–49 chars of `a-z 0-9 -` · `shortcode`: 3–40 chars of `a-z 0-9 _`, not already taken, not reserved.
- `entry`: a `.php` filename in the package root (no subfolders for the entry).
- Entry file MUST start with `if (!defined('ABSPATH')) { exit; }` and must load without errors
  (the installer test-loads it in a sandboxed include — parse/crash = rejected with a message).
- Zip ≤ 5 MB, ≤ 200 files, ≤ 20 MB unpacked; entries with `..`/absolute paths are rejected.
- Keep `version` at `1.0.0` (project rule), no external CDN requests at runtime.
