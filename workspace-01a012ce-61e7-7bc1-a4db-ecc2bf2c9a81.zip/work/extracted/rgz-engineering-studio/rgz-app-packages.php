<?php
/**
 * RGZ App Packages — uploadable app installer for the Mechanical Deck.
 *
 * A developer delivers ONE zip (see docs/app-package-template.zip):
 *
 *     rgz-app.json   manifest — id, name, developer-chosen shortcode, entry file, deck card
 *     app.php        entry file — defines the render callback (ABSPATH guard required)
 *     assets/…       optional css/js/images referenced via the package_url() helper
 *
 * The site owner uploads the zip in
 *     WP Admin → RGZ Engineering Studio → Mechanical Deck → Apps → Install app package
 *
 * The plugin extracts it safely into  wp-content/uploads/rgz-apps/<id>/  (so it
 * survives plugin updates), registers the developer's shortcode automatically
 * (class + render from the manifest, or the entry file registers it itself),
 * and merges a deck card that auto-links to the page containing the shortcode.
 * Broken packages never take the site down: the loader catches Throwables and
 * reports them as red status badges in the admin instead.
 *
 * Part of the RGZ Engineering Studio plugin. Version 1.0.0.
 */
if (!defined('ABSPATH')) { exit; }

final class RGZ_Mech_App_Packages {
    const OPT          = 'rgz_mech_deck_app_packages';
    const MAX_ZIP      = 5242880;    /* 5 MB uploaded zip */
    const MAX_UNPACKED = 20971520;   /* 20 MB extracted */
    const MAX_FILES    = 200;

    /* Shortcodes a package may never claim (ours + WordPress built-ins). */
    const RESERVED_SHORTCODES = [
        'rgz_hydraulic_studio', 'rgz_pneumatic_studio', 'rgz_mechanical_deck', 'rgz_learning_hub',
        'gallery', 'caption', 'embed', 'video', 'audio', 'playlist', 'code',
    ];

    private static $runtime    = [];  /* id => ['status' => 'ok|warning|error', 'error' => msg] (this request) */
    private static $loaded     = false;
    private static $page_cache = [];  /* shortcode => detected page url ('' = none) */

    public static function boot() {
        add_action('admin_post_rgz_app_package_upload', [__CLASS__, 'handle_upload']);
        add_action('admin_post_rgz_app_package_remove', [__CLASS__, 'handle_remove']);
        self::load_apps();
    }

    /* ============================================================ */
    /* Locations                                                    */
    /* ============================================================ */

    /* Files live OUTSIDE the plugin folder (uploads/rgz-apps/<id>/) on purpose:
       updating/re-installing the plugin then never deletes installed apps. */
    public static function apps_root($id = '') {
        $up = wp_upload_dir();
        $root = rtrim($up['basedir'], '/') . '/rgz-apps/';
        if ('' !== $id) { $root .= sanitize_file_name($id) . '/'; }
        return $root;
    }

    /* Base URL of a package folder — for developers to enqueue their assets:
       wp_enqueue_style('my-app', RGZ_Mech_App_Packages::package_url('my-app') . 'assets/app.css', ...); */
    public static function package_url($id) {
        $up = wp_upload_dir();
        return rtrim($up['baseurl'], '/') . '/rgz-apps/' . sanitize_file_name($id) . '/';
    }

    public static function package_path($id) {
        return self::apps_root($id);
    }

    private static function ensure_root() {
        $root = self::apps_root();
        if (!is_dir($root)) { @mkdir($root, 0755, true); }
        if (is_dir($root) && !file_exists($root . 'index.php')) {
            @file_put_contents($root . 'index.php', "<?php // Silence is golden.\n");
        }
        /* PHP files in packages are only ever include()d by WordPress — never
           fetched over HTTP. Block direct execution where .htaccess is honored. */
        $ht = $root . '.htaccess';
        if (is_dir($root) && !file_exists($ht)) {
            @file_put_contents($ht, "# RGZ app packages: PHP is included by WordPress, never executed directly.\n<FilesMatch \"\\.php$\">\n    Require all denied\n</FilesMatch>\n");
        }
        return is_dir($root) && is_writable($root);
    }

    /* ============================================================ */
    /* Registry                                                     */
    /* ============================================================ */

    public static function registry() {
        $r = get_option(self::OPT, []);
        return is_array($r) ? $r : [];
    }

    private static function save_registry($r) {
        update_option(self::OPT, $r);
    }

    public static function runtime_status($id) {
        return isset(self::$runtime[$id]) ? self::$runtime[$id] : ['status' => 'ok', 'error' => ''];
    }

    /* Is the developer's shortcode free to use? ($exclude_id = package being re-installed) */
    public static function shortcode_available($shortcode, $exclude_id = '') {
        foreach (self::registry() as $rid => $pkg) {
            if (isset($pkg['shortcode']) && $pkg['shortcode'] === $shortcode) {
                return $rid === $exclude_id;
            }
        }
        return !shortcode_exists($shortcode);
    }

    /* ============================================================ */
    /* Manifest validation (also unit-tested)                       */
    /* ============================================================ */

    public static function validate_manifest($m, &$error = null) {
        $error = '';
        if (!is_array($m)) { $error = 'Manifest is not a JSON object.'; return false; }

        $id = isset($m['id']) ? sanitize_key(str_replace('_', '-', (string) $m['id'])) : '';
        if (!preg_match('/^[a-z0-9][a-z0-9\-]{1,48}$/', $id)) {
            $error = '"id" must be 2–49 characters of a-z, 0-9 and dashes (e.g. mechatronics-demo).';
            return false;
        }
        $name = isset($m['name']) ? trim((string) $m['name']) : '';
        if ('' === $name || strlen($name) > 80) {
            $error = '"name" is required (max 80 characters).';
            return false;
        }
        $shortcode = isset($m['shortcode']) ? strtolower(trim((string) $m['shortcode'])) : '';
        if (!preg_match('/^[a-z0-9_]{3,40}$/', $shortcode)) {
            $error = '"shortcode" must be 3–40 characters of a-z, 0-9 and underscores (e.g. rgz_mechatronics_studio).';
            return false;
        }
        if (in_array($shortcode, self::RESERVED_SHORTCODES, true)) {
            $error = 'shortcode "' . $shortcode . '" is reserved — the developer must choose another one.';
            return false;
        }
        $entry = (isset($m['entry']) && '' !== $m['entry']) ? (string) $m['entry'] : 'app.php';
        if (basename($entry) !== $entry || !preg_match('/^[A-Za-z0-9_\-\.]+\.php$/', $entry)) {
            $error = '"entry" must be a .php file name in the package root (no folders).';
            return false;
        }
        $version = (isset($m['version']) && preg_match('/^\d+\.\d+\.\d+$/', (string) $m['version'])) ? (string) $m['version'] : '1.0.0';
        $class  = isset($m['class'])  ? preg_replace('/[^A-Za-z0-9_\\\\]/', '', (string) $m['class'])  : '';
        $render = isset($m['render']) ? preg_replace('/[^A-Za-z0-9_]/', '', (string) $m['render']) : '';

        $card = [];
        if (isset($m['card']) && is_array($m['card'])) {
            foreach (['title', 'desc', 'category', 'icon', 'accent', 'badge', 'learnTopic'] as $k) {
                if (isset($m['card'][$k]) && is_string($m['card'][$k])) { $card[$k] = $m['card'][$k]; }
            }
        }

        return [
            'id'        => $id,
            'name'      => $name,
            'version'   => $version,
            'shortcode' => $shortcode,
            'entry'     => $entry,
            'class'     => $class,
            'render'    => $render,
            'card'      => $card,
        ];
    }

    /* ============================================================ */
    /* Loader — include every installed package, register shortcode */
    /* ============================================================ */

    public static function load_apps($force = false) {
        if (self::$loaded && !$force) { return; }
        self::$loaded = true;
        foreach (self::registry() as $id => $pkg) {
            $entry = isset($pkg['entry']) ? $pkg['entry'] : 'app.php';
            $file = self::apps_root($id) . $entry;
            self::$runtime[$id] = ['status' => 'ok', 'error' => ''];
            if (!file_exists($file)) {
                self::$runtime[$id] = ['status' => 'error', 'error' => 'Entry file missing: ' . $entry];
                continue;
            }
            try {
                include_once $file;
            } catch (\Throwable $e) {
                self::$runtime[$id] = ['status' => 'error', 'error' => $e->getMessage()];
                continue;
            }
            $sc = isset($pkg['shortcode']) ? $pkg['shortcode'] : '';
            if ('' === $sc || shortcode_exists($sc)) { continue; }
            $cb = null;
            $class  = isset($pkg['class'])  ? $pkg['class']  : '';
            $render = isset($pkg['render']) ? $pkg['render'] : '';
            if ($class && $render && method_exists($class, $render)) {
                $cb = [$class, $render];
            } elseif ($render && function_exists($render)) {
                $cb = $render;
            }
            if ($cb) {
                add_shortcode($sc, $cb);
            } else {
                self::$runtime[$id] = [
                    'status' => 'warning',
                    'error'  => 'Shortcode not registered (no "' . ($render ? $render : 'render') . '" callback found and the entry file did not register it).',
                ];
            }
        }
    }

    /* ============================================================ */
    /* Deck integration: auto-created cards for installed packages  */
    /* ============================================================ */

    public static function deck_cards() {
        $cards = [];
        foreach (self::registry() as $id => $pkg) {
            $st = self::runtime_status($id);
            $cm = (isset($pkg['card']) && is_array($pkg['card'])) ? $pkg['card'] : [];
            $cards[] = [
                'id'       => $id,
                'title'    => !empty($cm['title']) ? $cm['title'] : (isset($pkg['name']) ? $pkg['name'] : $id),
                'desc'     => isset($cm['desc']) ? $cm['desc'] : '',
                'category' => !empty($cm['category']) ? $cm['category'] : 'Apps',
                'icon'     => !empty($cm['icon']) ? $cm['icon'] : 'generic',
                'accent'   => !empty($cm['accent']) ? $cm['accent'] : '#38bdf8',
                'badge'    => isset($cm['badge']) ? $cm['badge'] : '',
                'url'      => self::detect_page(isset($pkg['shortcode']) ? $pkg['shortcode'] : ''),
                'learnTopic' => isset($cm['learnTopic']) ? $cm['learnTopic'] : '',
                'enabled'  => 'error' !== $st['status'],
            ];
        }
        return $cards;
    }

    private static function detect_page($shortcode) {
        if ('' === $shortcode) { return ''; }
        if (array_key_exists($shortcode, self::$page_cache)) { return self::$page_cache[$shortcode]; }
        $url = '';
        if (class_exists('RGZ_Mechanical_Deck') && method_exists('RGZ_Mechanical_Deck', 'find_page_with_shortcode')) {
            $found = RGZ_Mechanical_Deck::find_page_with_shortcode($shortcode);
            if (is_string($found)) { $url = $found; }
        }
        self::$page_cache[$shortcode] = $url;
        return $url;
    }

    /* ============================================================ */
    /* Install / remove                                             */
    /* ============================================================ */

    private static function go($code, $msg = '') {
        $args = ['page' => 'rgz-mechanical-deck', 'saved' => $code, '_' => time()];
        if ('' !== $msg) { $args['rgz_err'] = $msg; }
        wp_safe_redirect(add_query_arg($args, admin_url('admin.php')));
        /* Test seam: the integration harness defines RGZ_PKG_TEST so it can drive
           several install scenarios in one request; on the site this always exits. */
        if (defined('RGZ_PKG_TEST')) { throw new \Exception('__REDIRECT__'); }
        exit;
    }

    public static function handle_upload() {
        if (!current_user_can('manage_options')) { wp_die('Permission denied.'); }
        check_admin_referer('rgz_mech_app_upload');

        if (!class_exists('ZipArchive')) { self::go('app_pkg_err', 'The PHP Zip extension is not available on this server.'); }
        if (empty($_FILES['rgz_app_package']) || !is_array($_FILES['rgz_app_package'])) { self::go('app_pkg_err', 'No file was uploaded.'); }
        $f = $_FILES['rgz_app_package'];
        if (!empty($f['error'])) { self::go('app_pkg_err', 'Upload failed (server error ' . (int) $f['error'] . ').'); }
        if (!preg_match('/\.zip$/i', (string) $f['name'])) { self::go('app_pkg_err', 'Please upload a .zip app package.'); }
        if ($f['size'] > self::MAX_ZIP) { self::go('app_pkg_err', 'Package is larger than ' . round(self::MAX_ZIP / 1048576, 1) . ' MB.'); }

        $zip = new \ZipArchive();
        if (true !== $zip->open($f['tmp_name'])) { self::go('app_pkg_err', 'Could not open the ZIP file.'); }

        /* Locate rgz-app.json — at the zip root or inside the single top-level folder. */
        $prefix = '';
        if (false === $zip->statName('rgz-app.json')) {
            $tops = [];
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $parts = explode('/', trim($zip->getNameIndex($i), '/'));
                if (count($parts) > 1 && '' !== $parts[0]) { $tops[$parts[0]] = true; }
            }
            if (1 === count($tops) && false !== $zip->statName(key($tops) . '/rgz-app.json')) {
                $prefix = key($tops) . '/';
            }
        }
        if (false === $zip->statName($prefix . 'rgz-app.json')) {
            $zip->close();
            self::go('app_pkg_err', 'rgz-app.json was not found at the package root.');
        }

        $error = '';
        $manifest = self::validate_manifest(json_decode($zip->getFromName($prefix . 'rgz-app.json'), true), $error);
        if (!$manifest) { $zip->close(); self::go('app_pkg_err', 'Invalid rgz-app.json: ' . $error); }
        $id = $manifest['id'];

        $overwrite = !empty($_POST['rgz_app_overwrite']);
        $registry = self::registry();
        $already = isset($registry[$id]) || is_dir(self::apps_root($id));
        if ($already && !$overwrite) { $zip->close(); self::go('app_pkg_exists'); }
        if (!self::shortcode_available($manifest['shortcode'], $id)) {
            $zip->close();
            self::go('app_pkg_err', 'Shortcode [' . $manifest['shortcode'] . '] is already in use — the developer must choose another one.');
        }

        /* Safe manual extraction (zip-slip protected, limits enforced). */
        self::ensure_root();
        $tmp = self::apps_root() . '.tmp-' . wp_generate_password(8, false, false) . '/';
        @mkdir($tmp, 0755, true);
        $files = 0; $bytes = 0; $fail = '';
        for ($i = 0; $i < $zip->numFiles && '' === $fail; $i++) {
            $name = $zip->getNameIndex($i);
            if ($prefix && 0 !== strpos($name, $prefix)) { continue; }
            $rel = $prefix ? substr($name, strlen($prefix)) : $name;
            $rel = str_replace('\\', '/', $rel);
            if ('' === $rel || '/' === substr($rel, -1)) { continue; }
            if (false !== strpos($rel, '..') || '/' === $rel[0] || preg_match('#(^|/)\.($|/)#', $rel)) {
                $fail = 'Unsafe path inside the ZIP: ' . $rel; break;
            }
            $files++;
            if ($files > self::MAX_FILES) { $fail = 'Too many files in the package (max ' . self::MAX_FILES . ').'; break; }
            $stat = $zip->statIndex($i);
            $bytes += is_array($stat) && isset($stat['size']) ? (int) $stat['size'] : 0;
            if ($bytes > self::MAX_UNPACKED) { $fail = 'Package unpacks larger than ' . round(self::MAX_UNPACKED / 1048576, 0) . ' MB.'; break; }
            $dir = dirname($tmp . $rel);
            if (!is_dir($dir) && !@mkdir($dir, 0755, true)) { $fail = 'Could not create folder for ' . $rel; break; }
            $data = $zip->getFromIndex($i);
            if (false === $data || false === @file_put_contents($tmp . $rel, $data)) { $fail = 'Could not write ' . $rel; break; }
        }
        $zip->close();
        if ('' !== $fail) { self::rrmdir($tmp); self::go('app_pkg_err', $fail); }

        if (!file_exists($tmp . $manifest['entry'])) {
            self::rrmdir($tmp);
            self::go('app_pkg_err', 'Entry file "' . $manifest['entry'] . '" is missing in the package.');
        }

        /* Test-load the entry so a crashing file never reaches production.
           (Skipped on re-install: the previous copy of its code is already in memory.) */
        if (!$already) {
            try {
                include_once $tmp . $manifest['entry'];
            } catch (\Throwable $e) {
                self::rrmdir($tmp);
                self::go('app_pkg_err', 'The entry file crashed when loaded: ' . $e->getMessage());
            }
        }

        $dest = self::apps_root($id);
        if (is_dir($dest)) { self::rrmdir($dest); }
        if (!@rename($tmp, $dest)) {
            self::rrmdir($tmp);
            self::go('app_pkg_err', 'Could not move the package into place (folder permissions?).');
        }

        $manifest['installed'] = time();
        $registry[$id] = $manifest;
        self::save_registry($registry);
        self::go('app_pkg', $id);
    }

    public static function handle_remove() {
        if (!current_user_can('manage_options')) { wp_die('Permission denied.'); }
        $id = isset($_GET['app']) ? sanitize_key($_GET['app']) : '';
        check_admin_referer('rgz_app_package_remove_' . $id);
        $registry = self::registry();
        if (isset($registry[$id])) { unset($registry[$id]); self::save_registry($registry); }
        self::rrmdir(self::apps_root($id));
        self::go('app_pkg_removed');
    }

    private static function rrmdir($dir) {
        $dir = rtrim($dir, '/');
        if (!is_dir($dir)) { return; }
        $items = scandir($dir);
        if (is_array($items)) {
            foreach ($items as $it) {
                if ('.' === $it || '..' === $it) { continue; }
                $p = $dir . '/' . $it;
                if (is_dir($p)) { self::rrmdir($p); } else { @unlink($p); }
            }
        }
        @rmdir($dir);
    }

    /* ============================================================ */
    /* Admin UI — upload form + installed packages table            */
    /* ============================================================ */

    public static function render_manager() {
        if (!current_user_can('manage_options')) { return; }
        $docs = plugin_dir_url(__FILE__) . 'docs/';
        $registry = self::registry();
        ?>
        <div class="rgza-card" data-rgz-app-packages>
          <h2>Install app package (.zip)</h2>
          <p class="sub">Received an app from a developer? Upload it here — one zip with <code>rgz-app.json</code> + <code>app.php</code> inside. The plugin registers the developer's shortcode and creates the deck card automatically. Tell the developer to start from <a href="<?php echo esc_url($docs . 'app-package-template.zip'); ?>" target="_blank" rel="noopener"><b>docs/app-package-template.zip</b></a> and <a href="<?php echo esc_url($docs . 'APP-DEVELOPMENT-GUIDE.md'); ?>" target="_blank" rel="noopener"><b>docs/APP-DEVELOPMENT-GUIDE.md</b></a>.</p>
          <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" enctype="multipart/form-data" style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin:10px 0 0">
            <input type="hidden" name="action" value="rgz_app_package_upload">
            <?php wp_nonce_field('rgz_mech_app_upload'); ?>
            <input type="file" name="rgz_app_package" accept=".zip,application/zip" required>
            <label class="hint" style="display:flex;align-items:center;gap:6px;margin:0"><input type="checkbox" name="rgz_app_overwrite" value="1"> Overwrite if an app with the same ID exists</label>
            <button type="submit" class="rgza-btn primary">Install package</button>
          </form>
          <p class="hint" style="margin:10px 0 0">Safety: max 5&nbsp;MB, manifest + entry validated, unsafe ZIP paths rejected, the entry file is test-loaded before going live, and PHP inside packages is never executed directly from the web. Packages live in <code>uploads/rgz-apps/</code>, so updating the plugin never deletes them.</p>
        </div>

        <div class="rgza-card">
          <h2>Installed app packages</h2>
          <p class="sub">Each package ships its own shortcode (developer-chosen). Create a page with that shortcode and the deck card links itself to it automatically.</p>
          <?php if (!$registry) : ?>
            <div class="rgzd-empty">No app packages installed yet — the built-in studios need none. Install a developer's .zip above or add simple link cards with “＋ Add app”.</div>
          <?php else : ?>
            <div style="overflow:auto">
            <table style="width:100%;border-collapse:collapse;font-size:13.5px">
              <thead>
                <tr style="text-align:left;color:#64748b;border-bottom:2px solid #e2e8f0">
                  <th style="padding:8px 10px 8px 0">App</th>
                  <th style="padding:8px 10px 8px 0">Shortcode (paste into a page)</th>
                  <th style="padding:8px 10px 8px 0">Status</th>
                  <th style="padding:8px 10px 8px 0">App page</th>
                  <th style="padding:8px 0"></th>
                </tr>
              </thead>
              <tbody>
              <?php foreach ($registry as $id => $pkg) :
                  $st = self::runtime_status($id);
                  $sc = isset($pkg['shortcode']) ? $pkg['shortcode'] : '';
                  $colors = ['ok' => '#16a34a', 'warning' => '#d97706', 'error' => '#dc2626'];
                  $col = isset($colors[$st['status']]) ? $colors[$st['status']] : '#64748b';
                  $url = self::detect_page($sc);
                  $remove = wp_nonce_url(admin_url('admin-post.php?action=rgz_app_package_remove&app=' . rawurlencode($id)), 'rgz_app_package_remove_' . $id);
              ?>
                <tr style="border-bottom:1px solid #eef2f7">
                  <td style="padding:10px 10px 10px 0">
                    <b><?php echo esc_html(isset($pkg['name']) ? $pkg['name'] : $id); ?></b>
                    <span style="color:#94a3b8">v<?php echo esc_html(isset($pkg['version']) ? $pkg['version'] : '1.0.0'); ?></span><br>
                    <span class="hint" style="margin:0"><?php echo esc_html($id); ?></span>
                  </td>
                  <td style="padding:10px 10px 10px 0">
                    <?php if ('' !== $sc) : ?>
                      <span class="rgza-code">[<?php echo esc_html($sc); ?>] <button type="button" data-copy="[<?php echo esc_attr($sc); ?>]">Copy</button></span>
                    <?php else : ?><span class="hint" style="margin:0">—</span><?php endif; ?>
                  </td>
                  <td style="padding:10px 10px 10px 0">
                    <span style="display:inline-block;padding:3px 10px;border-radius:999px;font-weight:700;font-size:12px;color:#fff;background:<?php echo esc_attr($col); ?>"><?php echo esc_html($st['status']); ?></span>
                    <?php if (!empty($st['error'])) : ?><div class="hint" style="margin:4px 0 0;max-width:280px"><?php echo esc_html($st['error']); ?></div><?php endif; ?>
                  </td>
                  <td style="padding:10px 10px 10px 0">
                    <?php if ($url) : ?><a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener">✓ linked ↗</a>
                    <?php else : ?><span class="hint" style="margin:0">create a page with [<?php echo esc_html($sc); ?>]</span><?php endif; ?>
                  </td>
                  <td style="padding:10px 0;white-space:nowrap;text-align:right">
                    <a class="rgza-btn danger" href="<?php echo esc_url($remove); ?>" onclick="return confirm('Remove package <?php echo esc_attr($id); ?>? Files, the shortcode and the deck card will be removed.');">Remove</a>
                  </td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
            </div>
          <?php endif; ?>
        </div>
        <?php
    }
}
