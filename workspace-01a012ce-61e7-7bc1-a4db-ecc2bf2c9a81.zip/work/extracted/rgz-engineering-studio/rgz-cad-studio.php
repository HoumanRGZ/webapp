<?php
/**
 * RGZ 3D CAD Studio — backend module.
 *
 * The front-end app ships as an app package (docs/app-package-template); this
 * module is its server side, mirroring RGZ Hydraulic/Pneumatic Studio:
 *   - RGZ account sign-in (same token/HMAC flow, own table rgz_cad_accounts)
 *   - per-account design storage (rgz_cad_designs, plain JSON — CAD sketches
 *     are not encrypted the way circuit .rgz files are)
 *   - admin submenu "RGZ 3D CAD" (stats, accounts, designs, delete/download)
 *   - Learning Hub topic "CAD & Design" + deck "My designs" merge
 *     (both via the deck's documented connector filters)
 *
 * Front-end <-> backend contract (ajax actions, all POST to admin-ajax.php):
 *   nonce:  wp_create_nonce('rgz_cad_public')  (field "nonce", actions save only)
 *   auth:   field "token" (HMAC bearer, from rgz_cad_login / rgz_cad_register)
 *   rgz_cad_me | rgz_cad_login | rgz_cad_register | rgz_cad_logout
 *   rgz_cad_save_design {design_name, design_json, token}   → {id}
 *   rgz_cad_my_designs {token}                              → {designs:[{id,design_name,file_size,created_at}]}
 *   rgz_cad_get_design {id, token}                          → {design:{id,design_name,file_size,created_at,design_json}}
 *   rgz_cad_delete_design {id, token}                       → {}
 */
if (!defined('ABSPATH')) { exit; }

final class RGZ_CAD_Studio_Plugin {
    const VERSION        = '1.0.0';
    const MAX_JSON_BYTES = 131072; /* 128 KB per CAD design (a parametric JSON is ~2–20 KB) */
    const DB_OPTION      = 'rgz_cad_studio_db_schema';
    const DB_SCHEMA      = 'cad_tables_1';

    /* ------------------------------------------------------------------ */
    public static function init() {
        add_action('init', [__CLASS__, 'maybe_install']);
        add_action('admin_menu', [__CLASS__, 'admin_menu']);

        foreach (['wp_ajax_', 'wp_ajax_nopriv_'] as $prefix) {
            add_action($prefix . 'rgz_cad_me',            [__CLASS__, 'ajax_me']);
            add_action($prefix . 'rgz_cad_login',         [__CLASS__, 'ajax_login']);
            add_action($prefix . 'rgz_cad_register',      [__CLASS__, 'ajax_register']);
            add_action($prefix . 'rgz_cad_logout',        [__CLASS__, 'ajax_logout']);
            add_action($prefix . 'rgz_cad_save_design',   [__CLASS__, 'ajax_save_design']);
            add_action($prefix . 'rgz_cad_my_designs',    [__CLASS__, 'ajax_my_designs']);
            add_action($prefix . 'rgz_cad_get_design',    [__CLASS__, 'ajax_get_design']);
            add_action($prefix . 'rgz_cad_delete_design', [__CLASS__, 'ajax_delete_design']);
        }
        add_action('admin_post_rgz_cad_download_design', [__CLASS__, 'download_design']);
        add_action('admin_post_rgz_cad_delete_design',   [__CLASS__, 'delete_design']);

        /* Deck connectors (documented rgz_deck_* hooks). */
        add_filter('rgz_deck_learn_topics',     [__CLASS__, 'learn_topics']);
        add_filter('rgz_deck_topic_accents',    [__CLASS__, 'topic_accents']);
        add_filter('rgz_deck_profile_designs',  [__CLASS__, 'deck_profile_designs'], 10, 3);
    }

    /* ------------------------------------------------------------------ */
    public static function accounts_table() { global $wpdb; return $wpdb->prefix . 'rgz_cad_accounts'; }
    public static function designs_table()  { global $wpdb; return $wpdb->prefix . 'rgz_cad_designs'; }

    public static function maybe_install() {
        if (get_option(self::DB_OPTION) === self::DB_SCHEMA) { return; }
        self::install();
        update_option(self::DB_OPTION, self::DB_SCHEMA, false);
    }

    public static function install() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        dbDelta("CREATE TABLE " . self::accounts_table() . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(190) NOT NULL,
            email VARCHAR(190) NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            created_at DATETIME NOT NULL,
            last_login DATETIME NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY email (email),
            KEY created_at (created_at)
        ) {$charset_collate};");

        dbDelta("CREATE TABLE " . self::designs_table() . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            account_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            design_name VARCHAR(190) NOT NULL,
            file_size INT UNSIGNED NOT NULL DEFAULT 0,
            design_json LONGTEXT NOT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY account_id (account_id),
            KEY created_at (created_at)
        ) {$charset_collate};");
    }

    /* ---------------- auth (mirrors the studio modules) ---------------- */
    private static function b64url_encode($data) { return rtrim(strtr(base64_encode($data), '+/', '-_'), '='); }
    private static function b64url_decode($data) {
        $pad = strlen($data) % 4;
        if ($pad) { $data .= str_repeat('=', 4 - $pad); }
        return base64_decode(strtr($data, '-_', '+/'), true);
    }
    private static function token_secret() { return wp_salt('auth') . '|rgz-cad-account-token'; }
    private static function create_token($account) {
        $payload = ['id' => (int) $account->id, 'email' => (string) $account->email, 'exp' => time() + 30 * DAY_IN_SECONDS, 'rnd' => bin2hex(random_bytes(8))];
        $body = self::b64url_encode(wp_json_encode($payload));
        return $body . '.' . self::b64url_encode(hash_hmac('sha256', $body, self::token_secret(), true));
    }
    private static function verify_token($token) {
        global $wpdb;
        $token = is_string($token) ? trim($token) : '';
        if ('' === $token || false === strpos($token, '.')) { return null; }
        [$body, $sig] = explode('.', $token, 2);
        if (!hash_equals(self::b64url_encode(hash_hmac('sha256', $body, self::token_secret(), true)), $sig)) { return null; }
        $payload = json_decode(self::b64url_decode($body), true);
        if (!is_array($payload) || empty($payload['id']) || empty($payload['email']) || empty($payload['exp']) || (int) $payload['exp'] < time()) { return null; }
        $account = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::accounts_table() . ' WHERE id = %d AND email = %s', (int) $payload['id'], sanitize_email($payload['email'])));
        return $account ?: null;
    }
    private static function request_token() { return isset($_POST['token']) ? sanitize_text_field(wp_unslash($_POST['token'])) : ''; }
    private static function auth_account() { return self::verify_token(self::request_token()); }
    private static function account_payload($account) {
        return $account ? ['id' => (int) $account->id, 'name' => (string) $account->name, 'email' => (string) $account->email] : null;
    }
    private static function check_nonce() {
        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
        return (bool) wp_verify_nonce($nonce, 'rgz_cad_public');
    }

    /* ---------------- public ajax: accounts ---------------- */
    public static function ajax_me() {
        $account = self::auth_account();
        wp_send_json_success(['user' => self::account_payload($account), 'token' => $account ? self::request_token() : '']);
    }
    public static function ajax_register() {
        global $wpdb;
        $name  = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
        $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
        $pass  = isset($_POST['password']) ? (string) wp_unslash($_POST['password']) : '';
        if ('' === $name || !is_email($email) || strlen($pass) < 6) {
            wp_send_json_error(['message' => 'Name, a valid email and a password with at least 6 characters are required.'], 400);
        }
        if ($wpdb->get_var($wpdb->prepare('SELECT id FROM ' . self::accounts_table() . ' WHERE email = %s', $email))) {
            wp_send_json_error(['message' => 'This email is already registered — please sign in.'], 409);
        }
        $ok = $wpdb->insert(self::accounts_table(), [
            'name' => $name, 'email' => $email, 'password_hash' => wp_hash_password($pass),
            'created_at' => current_time('mysql'), 'last_login' => current_time('mysql'),
        ], ['%s', '%s', '%s', '%s', '%s']);
        if (!$ok) { wp_send_json_error(['message' => 'Could not create the RGZ 3D Studio account.'], 500); }
        $account = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::accounts_table() . ' WHERE id = %d', (int) $wpdb->insert_id));
        wp_send_json_success(['user' => self::account_payload($account), 'token' => self::create_token($account)]);
    }
    public static function ajax_login() {
        global $wpdb;
        $login = isset($_POST['login']) ? sanitize_text_field(wp_unslash($_POST['login'])) : '';
        $pass  = isset($_POST['password']) ? (string) wp_unslash($_POST['password']) : '';
        $email = is_email($login) ? sanitize_email($login) : '';
        if (!$email || '' === $pass) { wp_send_json_error(['message' => 'Email and password are required.'], 400); }
        $account = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::accounts_table() . ' WHERE email = %s', $email));
        if (!$account || !wp_check_password($pass, $account->password_hash)) {
            wp_send_json_error(['message' => 'Wrong email or password.'], 401);
        }
        $wpdb->update(self::accounts_table(), ['last_login' => current_time('mysql')], ['id' => (int) $account->id], ['%s'], ['%d']);
        wp_send_json_success(['user' => self::account_payload($account), 'token' => self::create_token($account)]);
    }
    public static function ajax_logout() { wp_send_json_success(['ok' => true]); }

    /* ---------------- public ajax: designs ---------------- */
    public static function ajax_save_design() {
        if (!self::check_nonce()) { wp_send_json_error(['message' => 'Bad session. Reload the page.'], 403); }
        $account = self::auth_account();
        if (!$account) { wp_send_json_error(['message' => 'Please sign in first.', 'auth_required' => true], 401); }
        $name = isset($_POST['design_name']) ? sanitize_text_field(wp_unslash($_POST['design_name'])) : '';
        $json = isset($_POST['design_json']) ? (string) wp_unslash($_POST['design_json']) : '';
        if ('' === $name) { $name = 'Untitled design'; }
        $name = mb_substr($name, 0, 190);
        if ('' === $json || strlen($json) > self::MAX_JSON_BYTES) {
            wp_send_json_error(['message' => 'Design payload is empty or too large (max 128 KB).'], 400);
        }
        $decoded = json_decode($json, true);
        /* v1: single outer profile · v2+: feature tree (sketches + features) */
        if (!is_array($decoded) || !isset($decoded['v']) || (!isset($decoded['outer']) && !isset($decoded['sketches']))) {
            wp_send_json_error(['message' => 'That is not a valid RGZ 3D Studio design.'], 400);
        }
        /* Update-in-place when the app re-saves the same design id it loaded. */
        $update_id = isset($_POST['design_id']) ? absint($_POST['design_id']) : 0;
        global $wpdb;
        if ($update_id) {
            $owner = $wpdb->get_var($wpdb->prepare('SELECT account_id FROM ' . self::designs_table() . ' WHERE id = %d', $update_id));
            if ((int) $owner === (int) $account->id) {
                $wpdb->update(self::designs_table(), [
                    'design_name' => $name, 'design_json' => $json, 'file_size' => strlen($json), 'created_at' => current_time('mysql'),
                ], ['id' => $update_id], ['%s', '%s', '%d', '%s'], ['%d']);
                wp_send_json_success(['message' => 'Design updated in your account.', 'id' => $update_id]);
            }
        }
        $ok = $wpdb->insert(self::designs_table(), [
            'account_id'  => (int) $account->id,
            'user_id'     => get_current_user_id(),
            'design_name' => $name,
            'file_size'   => strlen($json),
            'design_json' => $json,
            'created_at'  => current_time('mysql'),
        ], ['%d', '%d', '%s', '%d', '%s', '%s']);
        if (!$ok) { wp_send_json_error(['message' => 'Could not store the design.'], 500); }
        wp_send_json_success(['message' => 'Design stored in your RGZ 3D Studio account.', 'id' => (int) $wpdb->insert_id]);
    }

    public static function ajax_my_designs() {
        $account = self::auth_account();
        if (!$account) { wp_send_json_error(['message' => 'Please sign in first.', 'auth_required' => true], 401); }
        global $wpdb;
        $rows = $wpdb->get_results($wpdb->prepare(
            'SELECT id, design_name, file_size, created_at FROM ' . self::designs_table() . ' WHERE account_id = %d ORDER BY created_at DESC LIMIT 100',
            (int) $account->id
        ));
        wp_send_json_success(['designs' => $rows]);
    }

    public static function ajax_get_design() {
        $account = self::auth_account();
        if (!$account) { wp_send_json_error(['message' => 'Please sign in first.', 'auth_required' => true], 401); }
        $id = isset($_POST['id']) ? absint($_POST['id']) : 0;
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare(
            'SELECT id, design_name, file_size, design_json, created_at FROM ' . self::designs_table() . ' WHERE id = %d AND account_id = %d',
            $id, (int) $account->id
        ));
        if (!$row) { wp_send_json_error(['message' => 'Design not found.'], 404); }
        wp_send_json_success(['design' => [
            'id' => (int) $row->id, 'design_name' => $row->design_name,
            'file_size' => (int) $row->file_size, 'created_at' => $row->created_at, 'design_json' => $row->design_json,
        ]]);
    }

    public static function ajax_delete_design() {
        $account = self::auth_account();
        if (!$account) { wp_send_json_error(['message' => 'Please sign in first.', 'auth_required' => true], 401); }
        $id = isset($_POST['id']) ? absint($_POST['id']) : 0;
        global $wpdb;
        $wpdb->query($wpdb->prepare('DELETE FROM ' . self::designs_table() . ' WHERE id = %d AND account_id = %d', $id, (int) $account->id));
        wp_send_json_success(['ok' => true]);
    }

    /* ---------------- deck connectors ---------------- */
    public static function learn_topics($topics) {
        if (!isset($topics['cad'])) { $topics['cad'] = 'CAD & Design'; }
        return $topics;
    }
    public static function topic_accents($accents) {
        if (!isset($accents['cad'])) { $accents['cad'] = '#eb4e3c'; }
        return $accents;
    }
    public static function deck_profile_designs($designs, $identity, $with_thumbs) {
        global $wpdb;
        if (!isset($wpdb) || !is_object($wpdb)) { return $designs; }
        $email = isset($identity['email']) ? sanitize_email($identity['email']) : '';
        if (!$email) { return $designs; }
        $rows = $wpdb->get_results($wpdb->prepare(
            'SELECT d.id, d.design_name, d.file_size, d.created_at FROM ' . self::designs_table() . ' d'
            . ' JOIN ' . self::accounts_table() . ' a ON a.id = d.account_id'
            . ' WHERE a.email = %s ORDER BY d.created_at DESC LIMIT 50',
            $email
        ), ARRAY_A);
        if (!is_array($rows)) { $rows = []; }
        $app_url = self::app_url();
        $items = [];
        foreach ($rows as $row) {
            $id = (int) $row['id'];
            $items[] = [
                'id'   => $id,
                'name' => (string) $row['design_name'] . '.rgzcad',
                'size' => (int) $row['file_size'],
                'date' => (string) $row['created_at'],
                'open' => $app_url ? $app_url . '#rgz-open=' . $id : '',
            ];
        }
        $designs['cad'] = $items;
        return $designs;
    }

    public static function app_url() {
        $pages = get_posts(['post_type' => 'page', 'post_status' => 'publish', 'posts_per_page' => 20, 's' => '[rgz_3d_cad_studio']);
        foreach ($pages as $page) {
            if (has_shortcode($page->post_content, 'rgz_3d_cad_studio')) { return get_permalink($page); }
        }
        return '';
    }

    /* ---------------- admin ---------------- */
    public static function admin_menu() {
        add_submenu_page('rgz-engineering-studio', 'RGZ 3D CAD', 'RGZ 3D CAD', 'manage_options', 'rgz-3d-cad', [__CLASS__, 'render_admin_page']);
    }

    public static function download_design() {
        if (!current_user_can('manage_options')) { wp_die('Permission denied.'); }
        check_admin_referer('rgz_cad_download_design');
        $id = isset($_GET['id']) ? absint($_GET['id']) : 0;
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare('SELECT design_name, design_json FROM ' . self::designs_table() . ' WHERE id = %d', $id));
        if (!$row) { wp_die('Design not found.'); }
        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . sanitize_file_name(strtolower(preg_replace('/[^a-zA-Z0-9]+/', '-', $row->design_name)) . '-cad-design.json') . '"');
        echo $row->design_json;
        exit;
    }

    public static function delete_design() {
        if (!current_user_can('manage_options')) { wp_die('Permission denied.'); }
        check_admin_referer('rgz_cad_delete_design');
        $id = isset($_GET['id']) ? absint($_GET['id']) : 0;
        global $wpdb;
        $wpdb->query($wpdb->prepare('DELETE FROM ' . self::designs_table() . ' WHERE id = %d', $id));
        wp_safe_redirect(add_query_arg(['page' => 'rgz-3d-cad', 'deleted' => $id], admin_url('admin.php')));
        exit;
    }

    public static function render_admin_page() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to access this page.', 'rgz-engineering-studio'));
        }
        global $wpdb;
        $accounts_table = self::accounts_table();
        $designs_table  = self::designs_table();

        $search      = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
        $account_id  = isset($_GET['account_id']) ? absint($_GET['account_id']) : 0;

        $total_accounts = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$accounts_table}");
        $total_designs  = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$designs_table}");
        $total_storage  = (int) $wpdb->get_var("SELECT COALESCE(SUM(file_size),0) FROM {$designs_table}");
        $latest_design  = $wpdb->get_var("SELECT MAX(created_at) FROM {$designs_table}");

        $where = '1=1'; $args = [];
        if ('' !== $search) {
            $like = '%' . $wpdb->esc_like($search) . '%';
            $where .= ' AND (a.name LIKE %s OR a.email LIKE %s)';
            $args = [$like, $like];
        }
        $account_sql = "SELECT a.*, COUNT(d.id) AS design_count, COALESCE(SUM(d.file_size),0) AS storage_bytes, MAX(d.created_at) AS last_design
            FROM {$accounts_table} a LEFT JOIN {$designs_table} d ON d.account_id = a.id
            WHERE {$where} GROUP BY a.id ORDER BY last_design DESC, a.created_at DESC LIMIT 250";
        $accounts = $args ? $wpdb->get_results($wpdb->prepare($account_sql, $args)) : $wpdb->get_results($account_sql);

        $dwhere = '1=1'; $dargs = [];
        if ($account_id) { $dwhere .= ' AND account_id = %d'; $dargs[] = $account_id; }
        $design_sql = "SELECT id, account_id, design_name, file_size, created_at FROM {$designs_table} WHERE {$dwhere} ORDER BY created_at DESC LIMIT 300";
        $designs = $dargs ? $wpdb->get_results($wpdb->prepare($design_sql, $dargs)) : $wpdb->get_results($design_sql);
        ?>
        <div class="wrap rgz-admin-wrap">
            <style>
                .rgz-admin-wrap{--rgz-border:#e5e7eb;--rgz-muted:#64748b}
                .rgz-admin-hero{background:linear-gradient(135deg,#0f172a,#1e293b);color:#fff;border-radius:18px;padding:22px 24px;margin:18px 0;display:flex;justify-content:space-between;gap:18px;align-items:center;box-shadow:0 16px 40px rgba(15,23,42,.18)}
                .rgz-admin-hero h1{color:#fff;margin:0 0 6px;font-size:28px;font-weight:800}.rgz-admin-hero p{margin:0;color:#cbd5e1;max-width:780px}
                .rgz-admin-hero .button{border-color:rgba(255,255,255,.25);color:#fff;background:rgba(255,255,255,.08)}
                .rgz-stats{display:grid;grid-template-columns:repeat(4,minmax(160px,1fr));gap:14px;margin:16px 0}
                .rgz-stat{background:#fff;border:1px solid var(--rgz-border);border-radius:16px;padding:16px;box-shadow:0 8px 24px rgba(15,23,42,.05)}
                .rgz-stat span{display:block;color:var(--rgz-muted);font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.06em}
                .rgz-stat strong{display:block;margin-top:8px;font-size:24px;color:#0f172a}
                .rgz-admin-grid{display:grid;grid-template-columns:minmax(280px,360px) minmax(0,1fr);gap:16px;align-items:start}
                .rgz-panel-admin{background:#fff;border:1px solid var(--rgz-border);border-radius:18px;box-shadow:0 8px 24px rgba(15,23,42,.05);overflow:hidden}
                .rgz-panel-head{padding:15px 16px;border-bottom:1px solid var(--rgz-border)}.rgz-panel-head h2{font-size:15px;margin:0;color:#0f172a}
                .rgz-account-list{display:grid;gap:8px;max-height:620px;overflow:auto;padding:12px}
                .rgz-account-card{display:block;text-decoration:none;border:1px solid #e5e7eb;border-radius:14px;padding:12px;background:#fff;color:#0f172a;transition:.15s}
                .rgz-account-card:hover{border-color:#eb9b8c;box-shadow:0 8px 24px rgba(235,78,60,.12)}
                .rgz-account-card.active{border-color:#eb4e3c;background:#fef3f2}
                .rgz-account-card strong{display:block;font-size:14px}.rgz-account-card small{display:block;color:var(--rgz-muted);overflow-wrap:anywhere;margin-top:3px}
                .rgz-pill{display:inline-flex;border-radius:999px;background:#f1f5f9;color:#334155;font-size:11px;font-weight:700;padding:4px 8px;margin:6px 6px 0 0}
                .rgz-pill.red{background:#fee4e2;color:#b42318}
                .rgz-table-wrap{overflow:auto}
                .rgz-modern-table{width:100%;border-collapse:separate;border-spacing:0 8px}
                .rgz-modern-table th{text-align:left;color:var(--rgz-muted);font-size:11px;text-transform:uppercase;letter-spacing:.06em;padding:0 10px}
                .rgz-modern-table td{background:#fff;border-top:1px solid #e5e7eb;border-bottom:1px solid #e5e7eb;padding:12px 10px;vertical-align:top}
                .rgz-modern-table td:first-child{border-left:1px solid #e5e7eb;border-radius:12px 0 0 12px}
                .rgz-modern-table td:last-child{border-right:1px solid #e5e7eb;border-radius:0 12px 12px 0}
                .rgz-empty{padding:28px;text-align:center;color:var(--rgz-muted);background:#f8fafc;border-radius:14px}
                .rgz-search-form{display:grid;gap:8px;padding:12px}.rgz-search-form input{width:100%;border-radius:10px;border:1px solid #cbd5e1;padding:8px 10px}
                .rgz-danger-link{color:#b91c1c!important}
                .rgz-muted{color:var(--rgz-muted);font-size:12px}
                @media(max-width:1100px){.rgz-stats{grid-template-columns:repeat(2,1fr)}.rgz-admin-grid{grid-template-columns:1fr}}
            </style>

            <div class="rgz-admin-hero">
                <div>
                    <h1>RGZ 3D CAD</h1>
                    <p>Students' parametric CAD designs from the 3D CAD Studio app — accounts, storage and per-user design history. The front-end app itself is installed and updated as an app package (Mechanical Deck → Apps).</p>
                </div>
                <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=rgz-mechanical-deck')); ?>">Deck installer</a>
            </div>

            <div class="rgz-stats">
                <div class="rgz-stat"><span>Accounts</span><strong><?php echo number_format_i18n($total_accounts); ?></strong></div>
                <div class="rgz-stat"><span>Stored designs</span><strong><?php echo number_format_i18n($total_designs); ?></strong></div>
                <div class="rgz-stat"><span>Storage</span><strong><?php echo esc_html(size_format($total_storage, 1)); ?></strong></div>
                <div class="rgz-stat"><span>Latest design</span><strong style="font-size:15px"><?php echo $latest_design ? esc_html($latest_design) : '—'; ?></strong></div>
            </div>

            <div class="rgz-admin-grid">
                <div class="rgz-panel-admin">
                    <div class="rgz-panel-head"><h2>3D Studio accounts</h2></div>
                    <form class="rgz-search-form" method="get">
                        <input type="hidden" name="page" value="rgz-3d-cad">
                        <input type="search" name="s" value="<?php echo esc_attr($search); ?>" placeholder="Search name or email…">
                        <button class="button" type="submit">Search</button>
                    </form>
                    <div class="rgz-account-list">
                        <?php if (!$accounts) : ?>
                        <div class="rgz-empty">No 3D Studio accounts yet. They appear when a student signs up inside the app.</div>
                        <?php else : foreach ($accounts as $a) : ?>
                        <a class="rgz-account-card <?php echo $account_id === (int) $a->id ? 'active' : ''; ?>" href="<?php echo esc_url(admin_url('admin.php?page=rgz-3d-cad&account_id=' . (int) $a->id)); ?>">
                            <strong><?php echo esc_html($a->name); ?></strong>
                            <small><?php echo esc_html($a->email); ?></small>
                            <div>
                                <span class="pill">🧊 <?php echo number_format_i18n((int) $a->design_count); ?> designs</span>
                                <span class="pill"><?php echo esc_html(size_format((int) $a->storage_bytes, 1)); ?></span>
                            </div>
                        </a>
                        <?php endforeach; endif; ?>
                    </div>
                </div>

                <div class="rgz-panel-admin">
                    <div class="rgz-panel-head"><h2>Stored designs <?php if ($account_id) : ?>— <a href="<?php echo esc_url(admin_url('admin.php?page=rgz-3d-cad')); ?>">clear account filter</a><?php endif; ?></h2></div>
                    <div class="rgz-table-wrap">
                        <table class="rgz-modern-table">
                            <thead><tr><th>Design</th><th>Size</th><th>Saved</th><th>Actions</th></tr></thead>
                            <tbody>
                            <?php if (!$designs) : ?>
                                <tr><td colspan="4"><div class="rgz-empty">No designs stored yet.</div></td></tr>
                            <?php else : foreach ($designs as $d) : ?>
                                <tr>
                                    <td><strong><?php echo esc_html($d->design_name); ?></strong><br><span class="rgz-muted">#<?php echo (int) $d->id; ?> · account #<?php echo (int) $d->account_id; ?></span></td>
                                    <td><?php echo esc_html(size_format((int) $d->file_size, 1)); ?></td>
                                    <td><span class="rgz-muted"><?php echo esc_html($d->created_at); ?></span></td>
                                    <td>
                                        <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=rgz_cad_download_design&id=' . (int) $d->id), 'rgz_cad_download_design')); ?>">Download JSON</a>
                                        ·
                                        <a class="rgz-danger-link" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=rgz_cad_delete_design&id=' . (int) $d->id), 'rgz_cad_delete_design')); ?>" onclick="return confirm('Delete this design permanently?');">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
}

RGZ_CAD_Studio_Plugin::init();
