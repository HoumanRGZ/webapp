// Repro: Sequence valve clamp-and-work — retract path through SV (with position integration like the app)
import fs from "fs";
const src = fs.readFileSync(new URL("./solver.js", import.meta.url), "utf8");
eval(src + "\nglobalThis.rgzFluidSolve = rgzFluidSolve;");
const solve = globalThis.rgzFluidSolve;

function simPhase(comps, conns, seconds, dt = 0.05) {
  const ticks = Math.round(seconds / dt);
  let m, t = 0, hist = [];
  for (let i = 0; i < ticks; i++) {
    m = solve({ fluid: "oil", components: comps, connections: conns, dt, time: t });
    t += dt;
    // app-equivalent position integration
    for (const cy of m.cylinders) {
      const c = comps.find(x => x.id === cy.id);
      const strokeMm = Number(c.props.strokeMm || 300);
      c.props.simPosition = Math.min(1, Math.max(0, Number(c.props.simPosition ?? 0.2) + (cy.speedMmS * dt) / strokeMm));
    }
    if (i % Math.round(1.0 / dt) === 0 || i === ticks - 1)
      hist.push(m.cylinders.map(c => `${c.label}=${c.speedMmS.toFixed(1)}mm/s@${((comps.find(x => x.id === c.id).props.simPosition) * 100).toFixed(0)}%`).join("  "));
  }
  return { m, hist };
}

function run(name, model) {
  solve._dyn = null;
  const comps = model.components.filter(c => c.type !== "textLabel");
  for (const c of comps) if (c.type === "cylinderDA") c.props.simPosition = 0.1;
  const conns = model.connections;
  const V = comps.find(c => c.type === "directionalValve");
  console.log("\n### " + name);
  V.props.spoolState = "left";
  const ext = simPhase(comps, conns, 8);
  console.log("  EXTEND trace:", ext.hist.slice(0, 7).join(" | "));
  console.log("  EXTEND end:  ", ext.hist[ext.hist.length - 1]);
  V.props.spoolState = "right";
  const ret = simPhase(comps, conns, 16);
  console.log("  RETRACT trace:", ret.hist.slice(0, 6).join(" | "));
  console.log("  RETRACT ...  ", ret.hist.slice(6).join(" | "));
  console.log("  RETRACT end: ", ret.hist[ret.hist.length - 1]);
  return { ext, ret };
}

const cur = JSON.parse(fs.readFileSync(new URL("./models/hyd-simple-8-sequence.json", import.meta.url), "utf8"));
run("CURRENT circuit (SV only in work-cap line)", cur);

// Redesigned: add bypass check valve parallel to SV (free flow Work.A -> V1.A during retract)
const mod = JSON.parse(JSON.stringify(cur));
mod.components.push({ id: "CV-9", type: "checkValve", label: "CV1", x: 640, y: 530, rotation: 0, props: { crackingBar: 0.5 } });
const LP = { tubeIdMm: 12, lengthM: 1, maxPressureBar: 250, color: "", strokeWidth: 3, routeMode: "auto", shift: 0 };
mod.connections.push({ id: "L-91", from: { componentId: "C-5", portId: "A" }, to: { componentId: "CV-9", portId: "A" }, lineType: "pressure", properties: { ...LP } });
mod.connections.push({ id: "L-92", from: { componentId: "CV-9", portId: "B" }, to: { componentId: "SV-4", portId: "P" }, lineType: "pressure", properties: { ...LP } });
const res2 = run("REDESIGNED circuit (+ bypass check CV1 parallel to SV1)", mod);

// Assertions
const retEnd = res2.ret.m.cylinders.map(c => `${c.label}:${c.speedMmS.toFixed(1)}`);
const clampEnd = res2.ret.m.cylinders.find(c => c.label === "Clamp");
const workEnd = res2.ret.m.cylinders.find(c => c.label === "Work");
console.log("\n== CHECKS ==");
console.log((Math.abs(clampEnd.speedMmS) < 1 ? "PASS" : "FAIL") + " clamp fully retracted at end", clampEnd.speedMmS.toFixed(1));
console.log((Math.abs(workEnd.speedMmS) < 1 ? "PASS" : "FAIL") + " work fully retracted at end", workEnd.speedMmS.toFixed(1));
