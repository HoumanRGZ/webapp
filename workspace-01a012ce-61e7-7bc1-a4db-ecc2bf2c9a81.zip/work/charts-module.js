/* ---------------- user-defined simulation charts (both studios) ----------------
   Records simulation telemetry automatically while a simulation runs
   (one sample every 10 ms of sim time, capped at 30 000 samples) and lets the
   user define custom X/Y charts, render them as SVG and export SVG or CSV.
   One instance per studio is created with rgzChartsFactory({root,state,toast,fluid,name}). */
function rgzChartsFactory(opts) {
  "use strict";
  var root = opts.root,
    S = opts.state,
    toast = opts.toast || function () {},
    fluid = opts.fluid || "oil",
    name = opts.name || (fluid === "oil" ? "hydraulic" : "pneumatic");
  var PALETTE = ["#EB4E3C", "#2563eb", "#059669", "#d97706", "#7c3aed", "#0891b2", "#be185d", "#65a30d"];
  var chart = { rows: [], lastT: -1, stride: 0.01, cap: 30000 };
  var liveTimer = null;

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function fin(v, d) {
    var n = Number(v);
    return Number.isFinite(n) ? n : d == null ? 0 : d;
  }

  /* Build the channel catalogue from the current circuit + last metrics.
     Channels: system values, per-cylinder position/speed/force/pressure,
     per-motor rpm/flow/rotation, per-gauge pressure, per-flowmeter flow. */
  function buildChannels() {
    var m = (S.sim && S.sim.metrics) || {};
    var list = [];
    function add(id, label, unit, get) { list.push({ id: id, label: label, unit: unit, get: get }); }
    add("sys.p", "System pressure", "bar", function (mm) { return fin(mm.pressureBar); });
    add("sys.q", "Total flow", "L/min", function (mm) { return fin(mm.totalFlowLpm); });
    add("sys.qa", "Active flow", "L/min", function (mm) { return fin(mm.activeFlowLpm); });
    add("sys.kw", "Power", "kW", function (mm) { return fin(mm.powerKw); });
    if (fluid === "oil") add("sys.temp", "Oil temperature", "°C", function (mm) { return fin(mm.oilTempC); });
    function cyOf(mm, id) {
      var a = (mm && mm.cylinders) || [];
      for (var i = 0; i < a.length; i++) if (a[i].id === id) return a[i];
      return null;
    }
    function moOf(mm, id) {
      var a = (mm && mm.motors) || [];
      for (var i = 0; i < a.length; i++) if (a[i].id === id) return a[i];
      return null;
    }
    (S.components || []).forEach(function (c) {
      var lab = String(c.label || c.id), t = c.type;
      if (t === "cylinderDA" || t === "cylinderSA") {
        add(c.id + ":pos", lab + " · position", "%", function () {
          return 100 * Math.max(0, Math.min(1, fin(c.props && c.props.simPosition)));
        });
        add(c.id + ":spd", lab + " · speed", "mm/s", function (mm) {
          var cy = cyOf(mm, c.id); return cy ? fin(cy.speedMmS) : 0;
        });
        add(c.id + ":f", lab + " · force", "kN", function (mm) {
          var cy = cyOf(mm, c.id); return cy ? fin(cy.forceKN) : 0;
        });
        add(c.id + ":p", lab + " · cap-end pressure", "bar", function (mm) {
          var cy = cyOf(mm, c.id); return cy ? fin(cy.pressureBar) : 0;
        });
      } else if (t === "hydraulicMotor" || t === "pneumaticMotor") {
        add(c.id + ":rpm", lab + " · speed", "rpm", function (mm) {
          var mo = moOf(mm, c.id); return mo ? fin(mo.rpm) : 0;
        });
        add(c.id + ":q", lab + " · flow", "L/min", function (mm) {
          var mo = moOf(mm, c.id); return mo ? fin(mo.flowLpm) : 0;
        });
        add(c.id + ":ang", lab + " · rotation", "deg", function () {
          return (fin(c.props && c.props.simAngle) * 180) / Math.PI;
        });
      } else if (t === "pressureGauge" || t === "pressureSwitch" || t === "pressureTransducer" || t === "testPoint" || t === "accumulator") {
        add(c.id + ":p", lab + " · pressure", "bar", function (mm) {
          var cv = mm && mm.comp ? mm.comp[c.id] : null;
          return cv ? fin(cv.pressureBar) : 0;
        });
        if (t === "accumulator")
          add(c.id + ":q", lab + " · charge flow", "L/min", function (mm) {
            var cv = mm && mm.comp ? mm.comp[c.id] : null;
            return cv ? fin(cv.flowLpm) : 0;
          });
      } else if (t === "flowMeter" || t === "flowSwitch") {
        add(c.id + ":q", lab + " · flow", "L/min", function (mm) {
          var cv = mm && mm.comp ? mm.comp[c.id] : null;
          return cv ? fin(cv.flowLpm) : 0;
        });
      }
    });
    return list;
  }

  /* ---- recorder: called once per sim frame from the app render loop ---- */
  function rec() {
    if (!S.sim || !S.sim.running || !S.sim.metrics) return;
    var t = fin(S.sim.time);
    if (t < chart.lastT - 1e-6) chart.rows = []; // a new run restarts the record
    if (chart.rows.length && t - chart.lastT < chart.stride) { chart.lastT = t; return; }
    chart.lastT = t;
    var m = S.sim.metrics, chans = buildChannels(), row = { t: t };
    for (var i = 0; i < chans.length; i++) {
      try { row[chans[i].id] = fin(chans[i].get(m)); } catch (e) { row[chans[i].id] = 0; }
    }
    chart.rows.push(row);
    if (chart.rows.length > chart.cap) chart.rows.splice(0, chart.rows.length - chart.cap);
  }
  function clear() {
    chart.rows = [];
    chart.lastT = -1;
  }

  /* ---- nice axis ticks (1 / 2 / 2.5 / 5 × 10^k) ---- */
  function niceTicks(lo, hi, count) {
    lo = fin(lo); hi = fin(hi);
    if (hi === lo) {
      if (hi === 0) hi = 1;
      else { var pad = Math.abs(hi) * 0.1; lo -= pad; hi += pad; }
    }
    var raw = (hi - lo) / Math.max(2, count || 6);
    var mag = Math.pow(10, Math.floor(Math.log10(raw)));
    var step = 10 * mag, steps = [1, 2, 2.5, 5, 10];
    for (var i = 0; i < steps.length; i++) if (steps[i] * mag >= raw - 1e-12) { step = steps[i] * mag; break; }
    var lo2 = Math.floor(lo / step) * step, hi2 = Math.ceil(hi / step) * step;
    if (hi2 === lo2) hi2 = lo2 + step;
    var ticks = [];
    for (var v = lo2, k = 0; v <= hi2 + step * 0.5 && k < 60; v += step, k++) ticks.push(v);
    return { lo: lo2, hi: hi2, ticks: ticks };
  }
  function fmtTick(v) {
    var r = Number(v.toFixed(6));
    return Math.abs(r) >= 1000 ? String(Math.round(r)) : String(r);
  }

  /* ---- render the selected series into an SVG string (also used for export) ---- */
  function renderSVG(xId, yIds, rId) {
    var rows = chart.rows;
    if (!rows.length)
      return { error: "No samples recorded yet. Start the simulation — recording is automatic — then render again." };
    var chans = buildChannels();
    function chOf(id) {
      for (var i = 0; i < chans.length; i++) if (chans[i].id === id) return chans[i];
      return null;
    }
    var xIsTime = !xId || xId === "time";
    var xCh = xIsTime ? { id: "time", label: "Time", unit: "s" } : chOf(xId);
    if (!xCh) return { error: "Pick a valid X axis channel." };
    yIds = (yIds || []).filter(function (id) { return id && id !== rId && chOf(id); });
    if (rId && !chOf(rId)) rId = null;
    if (!yIds.length && !rId) return { error: "Select at least one Y series (left or right axis)." };
    var xVal = function (r) { return xIsTime ? r.t : fin(r[xCh.id]); };
    var W = 840, H = 430, mL = 66, mR = rId ? 66 : 26, mT = 40, mB = 56;
    var iw = W - mL - mR, ih = H - mT - mB;
    var xMin = Infinity, xMax = -Infinity;
    rows.forEach(function (r) { var v = xVal(r); if (v < xMin) xMin = v; if (v > xMax) xMax = v; });
    if (!Number.isFinite(xMin)) { xMin = 0; xMax = 1; }
    if (xMax === xMin) xMax = xMin + 1;
    var xt = niceTicks(xMin, xMax, 7);
    function extent(ids) {
      var lo = Infinity, hi = -Infinity;
      rows.forEach(function (r) {
        ids.forEach(function (id) {
          var v = fin(r[id]);
          if (v < lo) lo = v;
          if (v > hi) hi = v;
        });
      });
      if (!Number.isFinite(lo)) { lo = 0; hi = 1; }
      return [lo, hi];
    }
    var yE = extent(yIds.length ? yIds : [xCh.id]), yt = niceTicks(yE[0], yE[1], 6);
    var rt = rId ? niceTicks.apply(null, extent([rId]).concat([6])) : null;
    var px = function (v) { return mL + ((v - xt.lo) / (xt.hi - xt.lo)) * iw; };
    var pyL = function (v) { return mT + ih - ((v - yt.lo) / (yt.hi - yt.lo)) * ih; };
    var pyR = rt ? function (v) { return mT + ih - ((v - rt.lo) / (rt.hi - rt.lo)) * ih; } : pyL;
    var out = [];
    out.push('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + W + " " + H + '" role="img" aria-label="RGZ custom chart">');
    out.push('<rect x="0" y="0" width="' + W + '" height="' + H + '" fill="#ffffff" rx="10"/>');
    var i, v;
    // grid + x ticks
    for (i = 0; i < xt.ticks.length; i++) {
      v = xt.ticks[i];
      var gx = px(v).toFixed(1);
      out.push('<line x1="' + gx + '" y1="' + mT + '" x2="' + gx + '" y2="' + (mT + ih) + '" stroke="#e2e8f0" stroke-width="1"/>');
      out.push('<text x="' + gx + '" y="' + (mT + ih + 18) + '" text-anchor="middle" font-family="system-ui,Segoe UI,Arial,sans-serif" font-size="11" fill="#64748b">' + esc(fmtTick(v)) + "</text>");
    }
    // y ticks left
    for (i = 0; i < yt.ticks.length; i++) {
      v = yt.ticks[i];
      var gy = pyL(v).toFixed(1);
      out.push('<line x1="' + mL + '" y1="' + gy + '" x2="' + (mL + iw) + '" y2="' + gy + '" stroke="#e2e8f0" stroke-width="1"/>');
      out.push('<text x="' + (mL - 8) + '" y="' + (fin(gy) + 4) + '" text-anchor="end" font-family="system-ui,Segoe UI,Arial,sans-serif" font-size="11" fill="#64748b">' + esc(fmtTick(v)) + "</text>");
    }
    // y ticks right
    if (rt) {
      for (i = 0; i < rt.ticks.length; i++) {
        v = rt.ticks[i];
        out.push('<text x="' + (mL + iw + 8) + '" y="' + (fin(pyR(v).toFixed(1)) + 4) + '" text-anchor="start" font-family="system-ui,Segoe UI,Arial,sans-serif" font-size="11" fill="#64748b">' + esc(fmtTick(v)) + "</text>");
      }
    }
    // frame
    out.push('<rect x="' + mL + '" y="' + mT + '" width="' + iw + '" height="' + ih + '" fill="none" stroke="#cbd5e1" stroke-width="1.4"/>');
    // series
    var all = yIds.map(function (id) { return { id: id, right: false }; });
    if (rId) all.push({ id: rId, right: true });
    all.forEach(function (s, k) {
      var col = PALETTE[k % PALETTE.length];
      var pts = [];
      for (var i2 = 0; i2 < rows.length; i2++) {
        var r = rows[i2];
        pts.push(px(xVal(r)).toFixed(1) + "," + (s.right ? pyR(fin(r[s.id])) : pyL(fin(r[s.id]))).toFixed(1));
      }
      out.push('<polyline fill="none" stroke="' + col + '" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" points="' + pts.join(" ") + '"/>');
    });
    // legend
    var lx = mL + 10;
    all.forEach(function (s, k) {
      var col = PALETTE[k % PALETTE.length];
      var cch = chOf(s.id);
      var lab = (cch ? cch.label : s.id) + (cch ? " (" + cch.unit + ")" : "") + (s.right ? " — right" : "");
      out.push('<line x1="' + lx + '" y1="' + (mT - 22) + '" x2="' + (lx + 18) + '" y2="' + (mT - 22) + '" stroke="' + col + '" stroke-width="3"/>');
      out.push('<text x="' + (lx + 24) + '" y="' + (mT - 18) + '" font-family="system-ui,Segoe UI,Arial,sans-serif" font-size="11" fill="#334155">' + esc(lab) + "</text>");
      lx += 34 + lab.length * 6.2;
    });
    // axis labels
    var xLab = xCh.label + " (" + xCh.unit + ")";
    out.push('<text x="' + (mL + iw / 2) + '" y="' + (H - 12) + '" text-anchor="middle" font-family="system-ui,Segoe UI,Arial,sans-serif" font-size="12" font-weight="600" fill="#334155">' + esc(xLab) + "</text>");
    var lch = yIds.length ? chOf(yIds[0]) : null;
    var lUnits = [];
    yIds.forEach(function (id) { var c = chOf(id); if (c && lUnits.indexOf(c.unit) < 0) lUnits.push(c.unit); });
    out.push('<text x="18" y="' + (mT + ih / 2) + '" text-anchor="middle" font-family="system-ui,Segoe UI,Arial,sans-serif" font-size="12" font-weight="600" fill="#334155" transform="rotate(-90 18 ' + (mT + ih / 2) + ')">' + esc("left (" + lUnits.join(" · ") + ")") + "</text>");
    if (rId) {
      var rch = chOf(rId);
      out.push('<text x="' + (W - 14) + '" y="' + (mT + ih / 2) + '" text-anchor="middle" font-family="system-ui,Segoe UI,Arial,sans-serif" font-size="12" font-weight="600" fill="#334155" transform="rotate(90 ' + (W - 14) + " " + (mT + ih / 2) + ')">' + esc("right (" + (rch ? rch.unit : "") + ")") + "</text>");
    }
    out.push('<text x="' + (W - 10) + '" y="' + (H - 6) + '" text-anchor="end" font-family="system-ui,Segoe UI,Arial,sans-serif" font-size="9" fill="#94a3b8">HoumanRGZ · ' + esc(name) + " studio</text>");
    out.push("</svg>");
    return { svg: out.join("\n"), xCh: xCh, yIds: yIds, rId: rId };
  }

  function csvText(xId, yIds, rId) {
    var chans = buildChannels();
    function chOf(id) {
      for (var i = 0; i < chans.length; i++) if (chans[i].id === id) return chans[i];
      return null;
    }
    var xIsTime = !xId || xId === "time";
    var xCh = xIsTime ? { id: "time", label: "Time", unit: "s" } : chOf(xId);
    var cols = (yIds || []).slice();
    if (rId && cols.indexOf(rId) < 0) cols.push(rId);
    var head = [(xCh.label + " [" + xCh.unit + "]")].concat(
      cols.map(function (id) {
        var c = chOf(id);
        return c ? c.label + " [" + c.unit + "]" : id;
      })
    );
    var lines = [head.join(",")];
    chart.rows.forEach(function (r) {
      var line = [String(xIsTime ? Number(fin(r.t).toFixed(4)) : fin(r[xCh.id]))];
      cols.forEach(function (id) { line.push(String(Number(fin(r[id]).toFixed(6)))); });
      lines.push(line.join(","));
    });
    return lines.join("\n");
  }

  function download(fileName, mime, text) {
    try {
      var b = new Blob([text], { type: mime });
      var url = URL.createObjectURL(b);
      var a = document.createElement("a");
      a.href = url;
      a.download = fileName;
      (root.ownerDocument.body || root).appendChild(a);
      a.click();
      setTimeout(function () { try { URL.revokeObjectURL(url); a.remove(); } catch (e) {} }, 400);
    } catch (e) {
      toast("Download failed in this browser: " + e, "error");
    }
  }

  /* ---- the modal ---- */
  function open() {
    var old = root.querySelector(".rgz-modal-backdrop");
    if (old) old.remove();
    var chans = buildChannels();
    var firstCyl = null, firstGauge = null;
    chans.forEach(function (c) {
      if (!firstCyl && /:pos$/.test(c.id)) firstCyl = c;
      if (!firstGauge && /:p$/.test(c.id) && c.id.indexOf("sys.") !== 0) firstGauge = c;
    });
    var optHtml = chans
      .map(function (c) { return '<option value="' + esc(c.id) + '">' + esc(c.label) + " (" + esc(c.unit) + ")</option>"; })
      .join("");
    var yHtml = chans
      .map(function (c) {
        var def = c.id === "sys.p" || (firstCyl && c.id === firstCyl.id);
        return (
          '<label class="rgz-ch-row"><input type="checkbox" data-rgzch-y="' +
          esc(c.id) + '"' + (def ? " checked" : "") + "><span>" + esc(c.label) +
          '</span><span class="rgz-ch-unit">' + esc(c.unit) + "</span></label>"
        );
      })
      .join("");
    var bd = document.createElement("div");
    bd.className = "rgz-modal-backdrop";
    bd.innerHTML =
      '\n      <div class="rgz-modal rgz-chart-modal" role="dialog" aria-modal="true" aria-label="Custom charts">\n        <div class="rgz-modal-head">\n          <div><h3>Custom charts</h3><p><span data-rgzch-count>' +
      chart.rows.length +
      '</span> samples recorded · recording is automatic while the simulation runs (every 10 ms of sim time).</p></div>\n          <button class="rgz-btn icon" data-modal-close>×</button>\n        </div>\n        <div class="rgz-modal-body rgz-chart-body">\n          <div class="rgz-panel rgz-chart-setup">\n            <div class="rgz-panel-title">Chart definition</div>\n            <div class="rgz-field" style="margin-top:8px"><label>X axis</label><select class="rgz-input rgz-select" data-rgzch-x><option value="time" selected>Time (s)</option>' +
      optHtml +
      '</select></div>\n            <div class="rgz-field"><label>Y series — left axis</label><div class="rgz-ch-list">' +
      yHtml +
      '</div></div>\n            <div class="rgz-field"><label>Y series — right axis (optional)</label><select class="rgz-input rgz-select" data-rgzch-r><option value="">None</option>' +
      optHtml +
      '</select></div>\n            <div class="rgz-field-grid" style="margin-top:10px">\n              <button class="rgz-btn primary" data-rgzch-render>Render chart</button>\n              <button class="rgz-btn" data-rgzch-svg>Export SVG</button>\n              <button class="rgz-btn" data-rgzch-csv>Export CSV</button>\n              <button class="rgz-btn danger" data-rgzch-clear>Clear data</button>\n            </div>\n            <p>Example: tick a cylinder “position” channel, leave X = Time, and render a position–time curve. Use the right axis to overlay a differently-scaled channel such as pressure vs. position.</p>\n          </div>\n          <div class="rgz-panel rgz-chart-view-panel">\n            <div class="rgz-panel-title">Preview</div>\n            <div class="rgz-chart-view" data-rgzch-view><div class="rgz-message info">Define X and Y on the left, then press “Render chart”.</div></div>\n          </div>\n        </div>\n        <div class="rgz-modal-foot"><span>Starting a new simulation run clears the previous record.</span><button class="rgz-btn" data-modal-close>Close</button></div>\n      </div>';
    root.appendChild(bd);

    function sel() {
      var xEl = bd.querySelector("[data-rgzch-x]");
      var rEl = bd.querySelector("[data-rgzch-r]");
      var ys = [];
      bd.querySelectorAll("[data-rgzch-y]:checked").forEach(function (el) {
        ys.push(el.getAttribute("data-rgzch-y"));
      });
      return {
        x: xEl ? xEl.value : "time",
        ys: ys,
        r: rEl && rEl.value ? rEl.value : null,
      };
    }
    function setCount() {
      var c = bd.querySelector("[data-rgzch-count]");
      if (c) c.textContent = String(chart.rows.length);
    }
    function render() {
      var s = sel();
      var view = bd.querySelector("[data-rgzch-view]");
      var res = renderSVG(s.x, s.ys, s.r);
      if (res.error) {
        if (view) view.innerHTML = '<div class="rgz-message info">' + esc(res.error) + "</div>";
        toast(res.error, "warning");
        return false;
      }
      if (view) view.innerHTML = res.svg;
      setCount();
      return true;
    }
    function close() {
      if (liveTimer) { clearInterval(liveTimer); liveTimer = null; }
      bd.remove();
    }
    bd.addEventListener("click", function (e) {
      if (e.target === bd || e.target.closest("[data-modal-close]")) return void close();
      if (e.target.closest("[data-rgzch-render]")) return void render();
      if (e.target.closest("[data-rgzch-clear]")) {
        clear();
        setCount();
        var view = bd.querySelector("[data-rgzch-view]");
        if (view) view.innerHTML = '<div class="rgz-message info">Record cleared. Run the simulation to capture new samples.</div>';
        return void toast("Chart record cleared.", "info");
      }
      if (e.target.closest("[data-rgzch-svg]")) {
        var s = sel(), res = renderSVG(s.x, s.ys, s.r);
        if (res.error) return void toast(res.error, "warning");
        download("rgz-" + name + "-chart.svg", "image/svg+xml", '<?xml version="1.0" encoding="UTF-8"?>\n' + res.svg);
        return void toast("Chart SVG exported.", "ok");
      }
      if (e.target.closest("[data-rgzch-csv]")) {
        if (!chart.rows.length) return void toast("No samples recorded yet — run the simulation first.", "warning");
        var s2 = sel();
        download("rgz-" + name + "-chart.csv", "text/csv", csvText(s2.x, s2.ys, s2.r));
        return void toast("Chart data exported as CSV.", "ok");
      }
    });
    // gentle live refresh while the modal is open and the sim is running
    liveTimer = setInterval(function () {
      if (!document.contains(bd)) { clearInterval(liveTimer); liveTimer = null; return; }
      setCount();
      if (S.sim && S.sim.running && bd.querySelector("[data-rgzch-view] svg")) render();
    }, 700);
  }

  return { rec: rec, open: open, clear: clear, renderSVG: renderSVG, csvText: csvText, rows: function () { return chart.rows; }, buildChannels: buildChannels };
}
