const fs = require("fs");
const app = fs.readFileSync("/home/user/work/app-formatted.js", "utf8");
const solver = fs.readFileSync("/home/user/work/solver.js", "utf8");
function block(src, startIdx) {
  const firstBrace = src.indexOf("{", startIdx);
  let depth = 0, i = firstBrace, inStr = null, inCom = null;
  for (; i < src.length; i++) {
    const ch = src[i], nx = src[i + 1];
    if (inStr) { if (ch === "\\") i++; else if (ch === inStr) inStr = null; continue; }
    if (inCom === "//") { if (ch === "\n") inCom = null; continue; }
    if (inCom === "/*") { if (ch === "*" && nx === "/") { inCom = null; i++; } continue; }
    if (ch === '"' || ch === "'" || ch === "`") { inStr = ch; continue; }
    if (ch === "/" && nx === "/") { inCom = "//"; i++; continue; }
    if (ch === "/" && nx === "*") { inCom = "/*"; i++; continue; }
    if (ch === "{") depth++;
    if (ch === "}") { depth--; if (depth === 0) return i; }
  }
  throw new Error("no close");
}
const aStart = app.indexOf("function rgzFluidSolve(");
if (aStart < 0) throw new Error("solver not in app");
const aEnd = block(app, aStart);
if (!/function rgzFluidSolve/.test(solver)) throw new Error("bad solver");
const out = app.slice(0, aStart) + solver.trimEnd() + "\n" + app.slice(aEnd + 1);
fs.writeFileSync("/home/user/work/app-formatted.js", out);
console.log("synced. app block chars:", aEnd - aStart, "-> solver:", solver.trimEnd().length);
