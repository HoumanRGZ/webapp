// Verify sequence clamp-and-work circuits from live dumps: extend order + retract speed
import fs from "fs";
const src = fs.readFileSync(new URL("./solver.js", import.meta.url), "utf8");
eval(src + "\nglobalThis.rgzFluidSolve = rgzFluidSolve;");
const solve = globalThis.rgzFluidSolve;

function simPhase(comps, conns, seconds, dt, fluid) {
  const ticks = Math.round(seconds / dt);
  let m, t = 0, hist = [];
  for (let i = 0; i < ticks; i++) {
    m = solve({ fluid, components: comps, connections: conns, dt, time: t });
    t += dt;
    for (const cy of m.cylinders) {
      const c = comps.find(x => x.id === cy.id);
      const strokeMm = Number(c.props.strokeMm || 300);
      c.props.simPosition = Math.min(1, Math.max(0, Number(c.props.simPosition ?? 0.2) + (cy.speedMmS * dt) / strokeMm));
    }
    if (i % Math.round(1 / dt) === 0 || i === ticks - 1)
      hist.push(m.cylinders.map(c => `${c.label}=${c.speedMmS.toFixed(1)}@${((comps.find(x => x.id === c.id).props.simPosition) * 100).toFixed(0)}%`).join(" "));
  }
  return { m, hist };
}

function run(name, file, fluid = "oil") {
  solve._dyn = null;
  const model = JSON.parse(fs.readFileSync(new URL("./models/" + file, import.meta.url), "utf8"));
  const comps = model.components.filter(c => c.type !== "textLabel");
  for (const c of comps) if (c.type === "cylinderDA" || c.type === "cylinderSA") c.props.simPosition = 0.05;
  const conns = model.connections;
  const V = comps.find(c => c.type === "directionalValve");
  const dt = fluid === "air" ? 0.02 : 0.05;
  console.log("\n### " + name);
  V.props.spoolState = "left";
  const ext = simPhase(comps, conns, fluid === "air" ? 14 : 9, dt, fluid);
  console.log("  EXT:", ext.hist.slice(0, 8).join(" | "));
  const extEnd = comps.filter(c => c.type === "cylinderDA").map(c => `${c.label}@${(c.props.simPosition * 100).toFixed(0)}%`);
  console.log("  EXTEND END positions:", extEnd.join(" "));
  V.props.spoolState = "right";
  const ret = simPhase(comps, conns, fluid === "air" ? 18 : 12, dt, fluid);
  console.log("  RET:", ret.hist.slice(0, 8).join(" | "));
  const work = ret.m.cylinders[ret.m.cylinders.length - 1];
  const clamp = ret.m.cylinders[0];
  const allHome = ret.m.cylinders.every(c => Math.abs(c.speedMmS) < 1) && comps.filter(c => c.type === "cylinderDA").every(c => c.props.simPosition < 0.02);
  console.log("  RETRACT END:", ret.m.cylinders.map(c => `${c.label}=${c.speedMmS.toFixed(1)}`).join(" "), "->", allHome ? "PASS both fully retracted" : "FAIL not home");
  return allHome;
}

let ok = true;
ok &= run("HYD Simple: Sequence clamp-and-work + CV1 bypass", "hyd-simple-8-sequence.json");
ok &= run("HYD Intermediate: PLC sequential 2-cylinder + CV1", "hyd-inter-4-sequence.json");
ok &= run("HYD Cartridge: cartridge sequence + CCV1", "hyd-cart-2-sequence.json");
console.log("\n" + (ok ? "ALL PASS" : "SOME FAILED"));
process.exit(ok ? 0 : 1);
