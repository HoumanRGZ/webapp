// Repro: pilot-operated check valve load holding — extend/hold/retract
import fs from "fs";
const src = fs.readFileSync(new URL("./solver.js", import.meta.url), "utf8");
eval(src + "\nglobalThis.rgzFluidSolve = rgzFluidSolve;");
const solve = globalThis.rgzFluidSolve;

const model = JSON.parse(fs.readFileSync(new URL("./models/hyd-simple-11-pcheck.json", import.meta.url), "utf8"));
const comps = model.components.filter(c => c.type !== "textLabel");
[['GCA', 'C-4', 'A'], ['GCB', 'C-4', 'B'], ['GPX', 'PCV-3', 'X'], ['GPA', 'PCV-3', 'A']].forEach(([g, ci, pi]) => {
  comps.push({ id: g, type: 'pressureGauge', label: g, x: 0, y: 0, rotation: 0, props: {} });
  model.connections.push({ id: g, from: { componentId: ci, portId: pi }, to: { componentId: g, portId: 'P' }, lineType: 'pressure', properties: { tubeIdMm: 12, lengthM: 1 } });
});
const V = comps.find(c => c.type === 'directionalValve');
const CY = comps.find(c => c.type === 'cylinderDA');
CY.props.simPosition = 0.1;
solve._dyn = null;
let m, t = 0, dt = 0.05;
function step(sec, label) {
  for (let i = 0, n = Math.round(sec / dt); i < n; i++) {
    m = solve({ fluid: 'oil', components: comps, connections: model.connections, dt, time: t }); t += dt;
    CY.props.simPosition = Math.min(1, Math.max(0, CY.props.simPosition + m.cylinders[0].speedMmS * dt / (CY.props.strokeMm || 300)));
  }
  console.log(label, 'pos=', (CY.props.simPosition * 100).toFixed(0) + '%', 'v=', m.cylinders[0].speedMmS.toFixed(1), 'capA=', m.comp.GCA.pressureBar.toFixed(1), 'rodB=', m.comp.GCB.pressureBar.toFixed(1), 'pilotX=', m.comp.GPX.pressureBar.toFixed(1), 'pcvA=', m.comp.GPA.pressureBar.toFixed(1));
}
V.props.spoolState = 'left'; step(3, 'EXTEND   ');
V.props.spoolState = 'center'; step(2, 'HOLD 1   ');
const posHold = comps.find(c => c.id === 'C-4').props.simPosition;
step(2, 'HOLD 2   ');
const posHold2 = comps.find(c => c.id === 'C-4').props.simPosition;
V.props.spoolState = 'right'; step(1, 'RETRACT t+0.5');
step(2, 'RETRACT t+2.5');
step(2, 'RETRACT t+4.5');
console.log('\nhold drift:', ((posHold2 - posHold) * 100).toFixed(2) + '% (should be ~0)');
console.log('final pos:', (comps.find(c => c.id === 'C-4').props.simPosition * 100).toFixed(0) + '% (should be ~0-10)');
